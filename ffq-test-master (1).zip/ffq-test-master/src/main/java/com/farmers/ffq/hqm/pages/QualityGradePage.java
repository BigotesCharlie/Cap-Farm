package com.farmers.ffq.hqm.pages;

import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.PrefillResponseHQM;
import com.farmers.ffq.datatransferobjects.hqm.StaticContentHQM;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Home Quote Modernization (HQM) - Quality Grade Page.
 */

public class QualityGradePage extends HqmBasePage {

    private static final String VERIFY_QUALITY_GRADE_SELECTED_CORRECTLY = "Verify Quality Grade selected correctly.";
	private static final String QUALITY_GRADE_PAGE_TITLE = "HOW WOULD\nYOU DESCRIBE\nYOUR HOME?";
    private static final String QUALITY_GRADE_PAGE_SUBTITLE = "Construction quality strongly affects reconstruction cost. " +
            "Select the grade that comes closest to describing your home. *";
    @FindBy(xpath = "//mat-card//mat-radio-button[@radiogroup='quality']")
    private WebElement radioButton;

	@FindBy(xpath = "//mat-card//input[@id='economy-input']")
	private WebElement radioEconomy;

    @FindBy(xpath = "//mat-card[.//mat-radio-button[@id='economy']]")
    private WebElement cardEconomy;

	@FindBy(xpath = "//mat-card//input[@id='standard-input']")
	private WebElement radioStandard;

    @FindBy(xpath = "//mat-card[.//mat-radio-button[@id='standard']]")
    private WebElement cardStandard;

    @FindBy(xpath = "//mat-card//input[@id='aboveaverage-input']")
	private WebElement radioAboveAverage;

    @FindBy(xpath = "//mat-card[.//mat-radio-button[@id='aboveaverage']]")
    private WebElement cardAboveAverage;

	@FindBy(xpath = "//mat-card//input[@id='custom-input']")
	private WebElement radioCustom;

    @FindBy(xpath = "//mat-card[.//mat-radio-button[@id='custom']]")
    private WebElement cardCustom;

	@FindBy(xpath = "//mat-card//input[@id='premium-input']")
	private WebElement radioPremium;

    @FindBy(xpath = "//mat-card[.//mat-radio-button[@id='premium']]")
    private WebElement cardPremium;

    @FindBy(xpath = "//button[@id='expandCollapse' and contains(.,'See more details')]")
    private WebElement buttonSeeMoreDetails;

    @FindBy(xpath = "//button[@id='expandCollapse' and contains(.,'See less details')]")
    private WebElement buttonSeeLessDetails;

    private static final String HELP_ECONOMY_XPATH = "//mat-expansion-panel//h2[text()='Economy']";
    @FindBy(xpath = HELP_ECONOMY_XPATH)
    private WebElement helpEconomyWe;

    @FindBy(xpath = HELP_ECONOMY_XPATH+"/../p")
    private WebElement helpEconomyContent;

    private static final String HELP_STANDARD_XPATH = "//mat-expansion-panel//h2[text()='Standard']";
    @FindBy(xpath = HELP_STANDARD_XPATH)
    private WebElement helpStandardWe;

    @FindBy(xpath = HELP_STANDARD_XPATH+"/../p")
    private WebElement helpStandardContent;

    private static final String HELP_ABOVE_AVERAGE_XPATH = "//mat-expansion-panel//h2[text()='Above average']";
    @FindBy(xpath = HELP_ABOVE_AVERAGE_XPATH)
    private WebElement helpAboveAverageWe;

    @FindBy(xpath = HELP_ABOVE_AVERAGE_XPATH+"/../p")
    private WebElement helpAboveAverageContent;

    private static final String HELP_CUSTOM_XPATH = "//mat-expansion-panel//h2[text()='Custom']";
    @FindBy(xpath = HELP_CUSTOM_XPATH)
    private WebElement helpCustomWe;

    @FindBy(xpath = HELP_CUSTOM_XPATH+"/../p")
    private WebElement helpCustomContent;

    private static final String HELP_PREMIUM_XPATH = "//mat-expansion-panel//h2[text()='Premium']";
    @FindBy(xpath = HELP_PREMIUM_XPATH)
    private WebElement helpPremiumWe;

    @FindBy(xpath = HELP_PREMIUM_XPATH+"/../p")
    private WebElement helpPremiumContent;

    private static final String HELP_ECONOMY_TEXT = "Basic home features and design. Simple construction layout and floor plan. " +
            "Inexpensive fixtures and features. Lower grade, but functional, construction materials (for example: roofing, flooring, cabinets, and countertops).";
    private static final String HELP_STANDARD_TEXT = "Typical of common tract style home construction. Home design is produced throughout the area. " +
            "Features come as part of the packaged construction design and are made of solid and quality conventional materials. " +
            "Typical designs may include slightly higher ceilings with occasional vaulted ceilings. Some upgraded features but not prevalent.";
    private static final String HELP_ABOVE_AVERAGE_TEXT = "Tract style home construction with upgraded features. Home design is produced throughout the area. " +
            "Many rooms, including the kitchen, bathrooms, and bedrooms have been upgraded from the standard construction design and have features " +
            "that are made of higher quality materials. Typical designs include raised ceilings. Many upgraded features include the wall and floor coverings, " +
            "lighting fixtures and kitchen and master bath countertops.";
    private static final String HELP_CUSTOM_TEXT = "These homes can be recognized by the unique style and/or shape which vary from the other homes in the area. " +
            "They are typically quite large homes. Custom homes are distinguished by style and shape as well as by the finishes, though they may contain " +
            "both Above Average and/or Premium quality finishes. Includes features such as highly upgraded kitchen and bath countertops, floor and wall " +
            "coverings, built-in bookshelves, and wet bars.";
    private static final String HELP_PREMIUM_TEXT = "Unique style and/or shape which vary from the other homes in the area. They are typically very large homes, " +
            "generally at least 5,000 square feet. Vaulted ceilings (9 ' - 12') typically throughout. Highest grade materials used throughout " +
            "(countertops, cabinets, flooring, wall coverings etc.). Contains unique features such as wall safes, built-in movie theaters, " +
            "and other luxury constructions.";

    @FindBy(xpath = "//farmers-home-quality-grade//h1[@aria-label='HOW WOULD YOU DESCRIBE YOUR HOME?']")
    private WebElement textPageTitle;

    @FindBy(xpath = "//farmers-home-quality-grade//span[@class='sub-title-one']")
    private WebElement textPageSubTitle;

    private static final By pageFooters = By.xpath("//farmers-home-quality-grade//div/p[contains(@class,'tui-caption-text')]");

    private final List<String> footersQualityGradePage = Collections.singletonList("* The following definitions are general guidelines to help with your review. " +
            "Your home can have elements of more than one specific Dwelling Quality Grade.Therefore, you should determine " +
            "the Quality Grade by choosing the one that comes closest to describing your home.");

    @FindBy(xpath = "//farmers-home-quality-grade//farmers-home-quote-discount-journey//img[@id='clock-img']/../p")
    private WebElement discountSubTitleClock;

    private static final String DISCOUNT_CLOCK_TEXT = "For your convenience, we used your address to pre-fill some information.";

    @FindBy(xpath = "//farmers-home-quality-grade//farmers-home-quote-discount-journey//img[@id='lock-img']/../p")
    private WebElement discountSubTitlePiggy;

    private static final String DISCOUNT_PIGGY_TEXT = "otential savings/discounts. Let's find some more.";

    @FindBy(xpath ="//farmers-home-quality-grade//div[@class='discount-journey-card']//mat-icon[text()='info']")
    private WebElement discountHelpButtonPiggy;

    @FindBy(xpath = "//farmers-home-quote-discount-journey-dialog//h4")
    private WebElement discountHelpDialogTitle;

    private static final String DISCOUNT_HELP_DIALOG_TITLE = "Potential savings/discounts ($)";

    private static final String DISCOUNT_HELP_DIALOG_CONTENT_XPATH = "//farmers-home-quote-discount-journey-dialog//li";
    @FindBy(xpath = DISCOUNT_HELP_DIALOG_CONTENT_XPATH)
    private WebElement discountHelpDialogContent;

    @FindBy(xpath = "//mat-dialog-actions//button[.='CLOSE']")
    private WebElement buttonCloseDialog;


    /**
     * Constructor.
     *
     * @throws Exception
     */
    public QualityGradePage() throws Exception {
        super();
        waitElementBeVisible(radioButton);
    }

    public void clickEconomy() {
        waitAndClickElement(cardEconomy);
    }

    public void clickStandard() {
    	waitAndClickElement(cardStandard);
    }

    public void clickAboveAverage() {
    	waitAndClickElement(cardAboveAverage);
    }

    public void clickCustom() {
    	waitAndClickElement(cardCustom);
    }

    public void clickPremium() {
    	waitAndClickElement(cardPremium);
    }

    public String getSelected() throws Exception {
        List<WebElement> radioButtons = driver().findElements(By.xpath("//mat-card//mat-radio-button[@radiogroup='quality' and contains(@class,'mat-radio-checked')]"));
        StringBuilder radioSelected = new StringBuilder();
        for (WebElement rb : radioButtons) {
            radioSelected.append(getAttributeData(rb, LOWERCASE_ID));
        }
        return radioSelected.toString();
    }

    public boolean isEconomyAvailable() throws Exception {
        List<WebElement> radioButtons = driver().findElements(By.xpath("//mat-card//mat-radio-button[@radiogroup='quality']"));
        boolean economyGrade = false;
        for (WebElement rb : radioButtons) {
            if (getAttributeData(rb, LOWERCASE_ID).equalsIgnoreCase("economy")) {
                economyGrade = true;
            }
        }
        return economyGrade;
    }

    public void selectQualityGrade(ApplicantHQM applicant, @Nullable PrefillResponseHQM propertyData) throws Exception {
        if (!applicant.keep360Prefill) {
            switch (applicant.qualityGrade.toLowerCase().replace(SPACE,EMPTY_STRING)) {
                case "economy":
                    clickEconomy();
                    break;
                case "standard":
                    clickStandard();
                    break;
                case "aboveaverage":
                    clickAboveAverage();
                    break;
                case "custom":
                    clickCustom();
                    break;
                case "premium":
                    clickPremium();
                    break;
                default:
                    break;
            }
        } else if (getSelected().isEmpty()){
            Log.warn("Quality Grade page - no quality grade radio-button was selected, going to select Standard.");
            clickStandard();
        }
        Log.info("Quality Grade Selected: " + getSelected());
        if (propertyData != null) {
            verifyPageFields(applicant, propertyData);
        }
    }

    public void verifyPageFields(ApplicantHQM applicant, @Nullable PrefillResponseHQM propertyData) throws Exception {
        if ((propertyData != null) && (propertyData.getQualityGrade() != null)) {
            if (applicant.keep360Prefill) {
                String qualityGrade = propertyData.getQualityGrade().replaceAll(SPACE, EMPTY_STRING);
                if (qualityGrade.equalsIgnoreCase("Economy") && !isEconomyAvailable()) {
                    qualityGrade = STANDARD;
                }
                Assert.assertEquals(getSelected(), qualityGrade.toLowerCase(), VERIFY_QUALITY_GRADE_SELECTED_CORRECTLY);
            } else {
                Assert.assertEquals(getSelected(), applicant.qualityGrade.toLowerCase().replaceAll(SPACE, ""),
                        VERIFY_QUALITY_GRADE_SELECTED_CORRECTLY);
            }
        } else {
            if (applicant.keep360Prefill) {
                Assert.assertEquals(getSelected(), STANDARD.toLowerCase(), VERIFY_QUALITY_GRADE_SELECTED_CORRECTLY);
            } else {
                Assert.assertEquals(getSelected(), applicant.qualityGrade.toLowerCase().replaceAll(SPACE, EMPTY_STRING),
                        VERIFY_QUALITY_GRADE_SELECTED_CORRECTLY);
            }
            if (applicant.qualityGrade != null) {
                if (applicant.qualityGrade.equalsIgnoreCase("Economy")) {
                    Assert.assertTrue(isEconomyAvailable(), "Economy option should be available");
                } else {
                    Assert.assertEquals(isEconomyAvailable(), Integer.parseInt(applicant.squareFeet) <= 1500, "Economy option is available");
                }
            }
        }
    }

    public void validateHelpDialogs(FarmersSoftAssert fsa) throws Exception {
        waitAndClickElement(buttonSeeMoreDetails);
        if (isEconomyAvailable()) {
            waitElementBeVisible(helpEconomyWe);
            fsa.assertEquals(getTextFromElement(helpEconomyContent), HELP_ECONOMY_TEXT, "Help Text for Economy validated.");
        }
        waitElementBeVisible(helpStandardWe);
        fsa.assertEquals(getTextFromElement(helpStandardContent), HELP_STANDARD_TEXT, "Help Text for Standard validated.");
        //
        waitElementBeVisible(helpAboveAverageWe);
        fsa.assertEquals(getTextFromElement(helpAboveAverageContent), HELP_ABOVE_AVERAGE_TEXT, "Help Text for Above Average validated.");
        //
        waitElementBeVisible(helpCustomWe);
        fsa.assertEquals(getTextFromElement(helpCustomContent), HELP_CUSTOM_TEXT, "Help Text for Custom validated.");
        //
        waitElementBeVisible(helpPremiumWe);
        fsa.assertEquals(getTextFromElement(helpPremiumContent), HELP_PREMIUM_TEXT, "Help Text for Premium validated.");
    }

    public void validatePageTitles(FarmersSoftAssert fsa, @Nullable StaticContentHQM staticContent) {
        fsa.assertEquals(getTextFromElement(textPageTitle), QUALITY_GRADE_PAGE_TITLE, "Quality Grade page - page Title");
        fsa.assertEquals(getTextFromElement(textPageSubTitle), QUALITY_GRADE_PAGE_SUBTITLE, "Quality Grade page - page Sub-Title");
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getQualityTitle(), QUALITY_GRADE_PAGE_TITLE, "Quality Grade page - page Title (AEM).");
            fsa.assertEquals(staticContent.getQualityCaption(), QUALITY_GRADE_PAGE_SUBTITLE, "Quality Grade page - page Sub-Title (AEM).");
        }
    }

    public void validateSubtitlesDiscountJourney(List<String> discounts, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(discountSubTitleClock), DISCOUNT_CLOCK_TEXT,
                "Quality Grade page - Discount Journey Subtitle Clock image.");
        int discountCount = discounts.size();
        ArrayList<String> discountsAvailable = new ArrayList<>(discounts);
        String textDiscount = discountCount > 0? discountCount + " p" : "P";
        fsa.assertEquals(getTextFromElement(discountSubTitlePiggy), textDiscount + DISCOUNT_PIGGY_TEXT,
                "Quality Grade page - Discount Journey Subtitle Lock image.");
        if (discountCount > 0) {
            waitAndClickElement(discountHelpButtonPiggy);
            waitElementBeVisible(discountHelpDialogTitle);
            fsa.assertEquals(getTextFromElement(discountHelpDialogTitle), DISCOUNT_HELP_DIALOG_TITLE.replace("($)", "(" + discountCount + ")"),
                    "Quality Grade page - Discount Journey Help Dialog Title.");
            List<String> listDiscounts = driver().findElements(By.xpath(DISCOUNT_HELP_DIALOG_CONTENT_XPATH)).stream()
                    .map(this::getTextFromElement).sorted(Comparator.naturalOrder()).collect(Collectors.toList());
            discountsAvailable.sort(Comparator.naturalOrder());
            fsa.assertEquals(listDiscounts, discountsAvailable, "Quality Grade page - Discount Journey Help Dialog Content.");
            waitAndClickElement(buttonCloseDialog);
        }
    }

    public void validatePageFooters(@Nullable StaticContentHQM staticContent) throws Exception {
        List<String> listPageFooters = driver().findElements(pageFooters).stream().map(this::getTextFromElement)
                .filter(item -> !item.isEmpty()).collect(Collectors.toList());
        Log.info("Found Quality Grade page footers:" + listPageFooters);
        Assert.assertEquals(listPageFooters, footersQualityGradePage, "Validate Quality Grade page footers.");
        if (staticContent != null) {
            Assert.assertEquals(Collections.singletonList(staticContent.getQualityDisclaimer()), footersQualityGradePage,
                    "Validate Quality Grade page footers (AEM).");
        }
    }

    public void verifyPageFieldsNotReadonly(FarmersSoftAssert fsa) throws Exception {
        if (isEconomyAvailable()) {
            fsa.assertEquals(getAttributeData(radioEconomy, READONLY), EMPTY_STRING, "Quality Grade page - Economy is not read-only.");
        }
        fsa.assertEquals(getAttributeData(radioStandard, READONLY), EMPTY_STRING, "Quality Grade page - Standard is not read-only.");
        fsa.assertEquals(getAttributeData(radioAboveAverage, READONLY), EMPTY_STRING, "Quality Grade page - Above average is not read-only.");
        fsa.assertEquals(getAttributeData(radioCustom, READONLY), EMPTY_STRING, "Quality Grade page - Custom is not read-only.");
        fsa.assertEquals(getAttributeData(radioPremium, READONLY), EMPTY_STRING, "Quality Grade page - Premium is not read-only.");
    }
}
