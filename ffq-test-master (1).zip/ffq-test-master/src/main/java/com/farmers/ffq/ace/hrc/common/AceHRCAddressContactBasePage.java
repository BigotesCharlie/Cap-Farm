package com.farmers.ffq.ace.hrc.common;

import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Reporter;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.invisibilityOfElementLocated;

public class AceHRCAddressContactBasePage extends AceHRCBasePage {

	@FindBy(xpath = "//app-personal-info//div[contains(@class,'personal-info_address_h1')]//h1")
    protected WebElement addressPageTitle;

    @FindBy(xpath = "//app-personal-info//div[@id='auto-personal-info_address-subheading']")
    protected WebElement addressSubtitle;

    private static final String ADDRESS_INPUT_FIELD_XPATH = "//app-personal-info//input[@id='auto-manual-street__input-section']";
    @FindBy(xpath = ADDRESS_INPUT_FIELD_XPATH)
    protected WebElement formFieldAddressInput;

    @FindBy(xpath = "//app-personal-info//mat-form-field[@id='auto-manual-address-street__input-field']//mat-icon[contains(text(),'close')]")
    private WebElement addressFieldCrossIcon;

    @FindBy(xpath = "//app-personal-info//div[@id='formField_apartment']//input")
    protected WebElement formFieldUnitInput;

    @FindBy(xpath = "//app-personal-info//div[@id='formField_city']//input")
    protected WebElement formFieldCityInput;

    @FindBy(xpath = "//app-personal-info//div[@id='formField_zipCode']//input")
    protected WebElement formFieldZipCodeInput;

    @FindBy(xpath = "//app-personal-info//h2[@id='contact-info-heading']")
    protected WebElement contactInfoLabel;
    private static final String CONTACT_INFO_SECTION_SUBTITLE = "Contact information";

    private static final String EMAIL_ADDRESS_XPATH = "//app-personal-info//input[@name='email']";
    @FindBy(xpath = EMAIL_ADDRESS_XPATH)
    private WebElement formFieldEmailInput;

    @FindBy(xpath = "//app-personal-info//label[contains(@for,'email')]")
    private WebElement emailAddressFieldLabel;

    @FindBy(xpath = "//div[contains(@class,'email-address')]//mat-error")
    private WebElement emailAddressError;

    @FindBy(xpath = "//app-personal-info//input[@name='phone_number']")
    private WebElement formFieldPhoneNumberInput;

    @FindBy(xpath = "//app-personal-info//label[contains(@for,'phoneNumber')]")
    private WebElement mobilePhoneFieldLabel;

    @FindBy(xpath = "//div[contains(@class,'phone-number')]//mat-error")
    private WebElement phoneNumberError;

    @FindBy(xpath = "//app-personal-info//button[text()='Agree and submit']")
    private WebElement agreeAndSubmitButton;

    @FindBy(xpath = "//h1")
    private WebElement electronicSignHeader;

    @FindBy(xpath = "//span[@class='h1']")
    private WebElement ourCompaniesHeader;

    @FindBy(xpath = "//app-personal-info//button[text()='Agree and submit']/ancestor::div/p[contains(@class,'tui-body-text-1')]")
    private WebElement pageFooterSectionSubtitle;

    @FindBy(xpath = "//div[contains(@class,'tui-stacking-top-md')]")
    private WebElement pageFooterDisclaimer;

    @FindBy(linkText = "ESIGN terms and conditions")
    private WebElement linkDisclaimerEsign;

    @FindBy(linkText = "associated entities")
    private WebElement linkAssociatedEntities;

    /**
     * Default Constructor
     */
    public AceHRCAddressContactBasePage() throws Exception {
    }

    public boolean isOnAddressContactPage(boolean longWait) throws Exception {
        int timeout = longWait ? Property.PAGELOADTIMEOUT : 5;
        return isElementDisplayed(formFieldAddressInput, timeout);
    }

    public String getAddress() {
        return getElementValue(formFieldAddressInput, "Home Address").trim();
    }

    public String getAddressManualInput() {
        return getElementValue(formFieldAddressInput, "Home Address").trim();
    }

    public void enterAddress(ApplicantAceHome applicant) throws Exception {
        scrollToTopOfPage();
        enterGoogleAddressAceHome(formFieldAddressInput, formFieldCityInput, applicant);
        if (getCity().isBlank()) {
            sendKeysToElement(formFieldCityInput, applicant.getCity());
        }
        if (!applicant.getUnit().isBlank()) {
            sendKeysToElement(formFieldUnitInput, applicant.getUnit());
        }
    }

    public void fillOutAddressContactPage(ApplicantAceHome applicant) throws Exception {
        enterAddress(applicant);
        enterContactInfo(applicant);
        clickAgreeAndSubmit();
        waitForSpinnerToBeGone();
        waitElementBeInvisible(formFieldPhoneNumberInput);
    }

    public void enterContactInfo(ApplicantAceHome applicant) {
        waitAndClickElement(formFieldEmailInput);
        sendKeysToElement(formFieldEmailInput, applicant.getEmailAddress());
        sleep(2);
        waitAndClickElement(formFieldPhoneNumberInput);
        sendKeysOneByOne(formFieldPhoneNumberInput, applicant.getPhoneNumber());
        sendKeysToElement(formFieldPhoneNumberInput, Keys.TAB);
        sleep(2);
    }

    public void validateAddressContactPageFieldsMatchInput(ApplicantAceHome applicant, FarmersSoftAssert fsa) {
        fsa.assertEquals(getAddress().split(COMMA)[0].toUpperCase(), applicant.getAddress().toUpperCase(), "Address Contact page - Street address");
        fsa.assertEquals(getCity().toUpperCase(), applicant.getCity().toUpperCase(), "Address Contact page - City name");
        fsa.assertEquals(getZipCode(), applicant.getZipCode(), "Address Contact page - Zip code");
        fsa.assertEquals(getEmail(), applicant.getEmailAddress(), "Address Contact page - Email");
        fsa.assertEquals(getPhoneNumber().replaceAll("\\D",""), applicant.getPhoneNumber(), "Address Contact page - Phone number");
    }

    public String getCity() {
        return getElementValue(formFieldCityInput, "City").trim();
    }

    public String getZipCode() {
        return getElementValue(formFieldZipCodeInput, "ZIP Code").trim();
    }

    public void enterZipCode(String zipCode) {
        waitAndClickElement(formFieldZipCodeInput);
        sendKeysToElement(formFieldZipCodeInput, zipCode);
        sendKeysToElement(formFieldZipCodeInput, Keys.TAB);
    }

    public String getState() {
        return getTextFromElement(addressSubtitle).split(SPACE)[3];
    }

    public String getEmail() {
        return getElementValue(formFieldEmailInput, "Email").trim();
    }

    public String getPhoneNumber() {
        return getElementValue(formFieldPhoneNumberInput, "Phone number").trim();
    }

    public void validatePageFormFields(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getAttributeData(formFieldAddressInput, ARIA_LABEL), "Home Address (No Post Office Boxes)", "Address Contact page - Address field text.");
        fsa.assertEquals(getTextFromElement(formFieldAddressInput), EMPTY_STRING, "Address Contact page - Address field is blank.");
        fsa.assertEquals(getAttributeData(formFieldUnitInput, ARIA_LABEL), "Apartment ID", "Address Contact page - Unit # field text.");
        fsa.assertEquals(getTextFromElement(formFieldUnitInput), EMPTY_STRING, "Address Contact page - Unit # field is blank.");

        fsa.assertEquals(getTextFromElement(emailAddressFieldLabel), "Email address", "Address Contact page - Email field label.");
        fsa.assertEquals(getTextFromElement(formFieldEmailInput), EMPTY_STRING, "Address Contact page - Email field is blank.");
        fsa.assertEquals(getTextFromElement(mobilePhoneFieldLabel), "Mobile phone", "Address Contact page - Phone field label.");
        fsa.assertEquals(getTextFromElement(formFieldPhoneNumberInput), EMPTY_STRING, "Address Contact page - Phone field is blank.");
    }

    public void validatePageTitlesFooters(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception {
        final String PAGE_TITLE_TEXT = "Hi %s";
        final String PAGE_SUBTITLE_TEXT = "Please enter your %s address.";
        final String PAGE_CONTACT_INFO_TEXT = "Contact information";
        final String EXPECTED_EMAIL_ADDRESS_FIELD_LABEL = "Email address";
        final String EXPECTED_MOBILE_PHONE_FIELD_LABEL = "Mobile phone";

        fsa.assertTrue(isElementInViewport(addressPageTitle), "Address page - Page title is in Viewport");

        // Address data
        String pageTitleText = String.format(PAGE_TITLE_TEXT, applicant.getFirstName());
        fsa.assertEquals(getTextFromElement(addressPageTitle), pageTitleText, "Address Contact page - Page title (h1).");
        String pageSubtitleText = String.format(PAGE_SUBTITLE_TEXT, applicant.getState());
        fsa.assertEquals(getTextFromElement(addressSubtitle), pageSubtitleText, "Address Contact page - Page subtitle text.");

        // Validate contact info fields content
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(contactInfoLabel)), PAGE_CONTACT_INFO_TEXT, "Address Contact page - Contact information subtitle");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(emailAddressFieldLabel)), EXPECTED_EMAIL_ADDRESS_FIELD_LABEL, errorMessage(EXPECTED_EMAIL_ADDRESS_FIELD_LABEL));

        scrollToElement(waitElementBeVisible(mobilePhoneFieldLabel));
        fsa.assertEquals(getTextFromElement(mobilePhoneFieldLabel), EXPECTED_MOBILE_PHONE_FIELD_LABEL, errorMessage(EXPECTED_MOBILE_PHONE_FIELD_LABEL));

        verifyFooterContent(fsa);
    }

    public void verifyFooterContent(FarmersSoftAssert fsa) {
        final String EXPECTED_FOOTER_SECTION_SUBTITLE = "By clicking 'Agree and submit', you agree to terms below.";
        final String EXPECTED_FOOTER_DISCLAIMER = "By clicking \"Agree and submit\", you agree to these ESIGN terms and conditions and to receive marketing calls and texts as detailed below." + SEPARATOR + "We call and/or text " +
                "consumers with information about products and services. By clicking \"Agree and submit\", you consent to receive marketing calls and texts on behalf of Farmers\u00ae, Foremost\u00ae, " +
                "Bristol West\u00ae, and Farmers Life\u00ae associated entities and their representatives using an automated telephone dialing system, AI-generated and artificial or pre-recorded voice, " +
                "even for numbers listed on national, state, or business do-not-call registries. Consent is not a condition of purchase. Go to Farmers.com for alternative contact options. Message and data rates may apply.";
        final String EXPECTED_ESIGN_TERMS_CONDITIONS = "ESIGN terms and conditions";
        final String EXPECTED_ASSOCIATED_ENTITIES = "associated entities";

        scrollToElement(agreeAndSubmitButton);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageFooterSectionSubtitle, 5)), EXPECTED_FOOTER_SECTION_SUBTITLE, "Address Contact page - Footer section subtitle");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageFooterDisclaimer, 5)), EXPECTED_FOOTER_DISCLAIMER, "Address Contact page - Disclaimers verification");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(linkDisclaimerEsign, 5)), EXPECTED_ESIGN_TERMS_CONDITIONS, "Address Contact page - Esign disclaimer link verification");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(linkAssociatedEntities, 5)), EXPECTED_ASSOCIATED_ENTITIES, "Address Contact page - Association entities disclaimer link verification");
    }

    public void validatePageErrors(FarmersSoftAssert sa, ApplicantAceHome applicant) throws Exception {
        final String ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR = "Please enter street number and name.";
        final String ADDRESS_FIELD_ENTER_YOUR_CITY_ERROR = "Please enter your city.";
        final String ADDRESS_FIELD_CONTACT_EMAIL_ERROR = "Please enter your email address";
        final String ADDRESS_FIELD_CONTACT_PHONE_ERROR = "Please enter your phone number";
        final String PAGE_ALERT = "One or more required fields are incomplete or incorrect. Please review.";
        clickAgreeAndSubmit();
        waitForSpinnerToBeGone();
        List<String> listOfErrorsFoundInPage = getPageErrors();
        Reporter.pass("Reported errors:\n " + listOfErrorsFoundInPage);
        sa.assertTrue(listOfErrorsFoundInPage.contains(ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR), ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR + ERROR_FOUND);
        sa.assertTrue(listOfErrorsFoundInPage.contains(ADDRESS_FIELD_ENTER_YOUR_CITY_ERROR), ADDRESS_FIELD_ENTER_YOUR_CITY_ERROR + ERROR_FOUND);
        sa.assertTrue(listOfErrorsFoundInPage.contains(ADDRESS_FIELD_CONTACT_EMAIL_ERROR), ADDRESS_FIELD_CONTACT_EMAIL_ERROR + ERROR_FOUND);
        sa.assertTrue(listOfErrorsFoundInPage.contains(ADDRESS_FIELD_CONTACT_PHONE_ERROR), ADDRESS_FIELD_CONTACT_PHONE_ERROR + ERROR_FOUND);
        sa.assertTrue(getPageAlerts().contains(PAGE_ALERT), "Expected page alert(s) found.");
        waitAndClickElement(formFieldAddressInput);
        sendKeysToElement(formFieldAddressInput,SPECIALCHARS);
        clickAgreeAndSubmit();
        waitForSpinnerToBeGone();
        sa.assertTrue(getPageErrors().contains(ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR), ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR + ERROR_FOUND);
        sa.assertTrue(getPageAlerts().contains(PAGE_ALERT), "Expected page alert(s) found.");
        driver().navigate().refresh();
        enterGoogleAddressAceHome(formFieldAddressInput, formFieldCityInput, applicant);
        wait.until(invisibilityOfElementLocated(By.xpath("//mat-error")));
        sa.assertTrue(getPageErrors().isEmpty(), "Page error(s) should not be found.");
        sa.assertTrue(getPageAlerts().isEmpty(), "Page alert(s) should not be found.");
    }

    public void clickAgreeAndSubmit() {
        waitAndClickElement(agreeAndSubmitButton);
    }
}
