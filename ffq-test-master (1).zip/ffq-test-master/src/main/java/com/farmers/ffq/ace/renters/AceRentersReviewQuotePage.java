package com.farmers.ffq.ace.renters;

import com.farmers.ffq.ace.condo.AceCondoReviewQuotePage;
import com.farmers.ffq.common.enums.CoverageNameAceRenters;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCAdditionalCoveragesBasePage.*;
import static com.farmers.ffq.common.enums.CoveragesNameAceHome.Coverage.IDENTITY_FRAUD;
import static com.farmers.ffq.utils.CurrencyFormat.convertCurrencyStringToDouble;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersReviewQuotePage extends AceCondoReviewQuotePage {
    private static final String BUILDING_ADDITIONS_ALTERATIONS = "Building additions & alterations";
    private static final String  buildingAdditionsAlterationsXpath = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + BUILDING_ADDITIONS_ALTERATIONS + "')]";
    @FindBy(xpath = buildingAdditionsAlterationsXpath)
    private WebElement buildingAdditionsAlterationsLabelInEditCoverageSideSheet;
    @FindBy(xpath = buildingAdditionsAlterationsXpath + COVERAGE_DESCRIPTION_XPATH)
    private WebElement buildingAdditionsAlterationsDescriptionWebElement;

    @FindBy(xpath = buildingAdditionsAlterationsXpath + "//ancestor::coverage-data-card//app-stepper-input//input")
    private WebElement buildingAdditionsAlterationsCoverageAmoutInputWebElement;

    @FindBy(xpath = buildingAdditionsAlterationsXpath + "//ancestor::coverage-data-card//app-stepper-input//mat-button-toggle[1]")
    private WebElement buildingAdditionsAlterationsMinusAmoutWebElement;
    @FindBy(xpath = buildingAdditionsAlterationsXpath + "//ancestor::coverage-data-card//app-stepper-input//mat-button-toggle[2]")
    private WebElement buildingAdditionsAlterationsPlusAmoutWebElement;

    @FindBy(xpath = buildingAdditionsAlterationsXpath + "//ancestor::coverage-data-card//mat-hint")
    private WebElement buildingAdditionsAlterationsHintWebElement;

    @FindBy(xpath = "//button[@id='editPersonalPropertyLink']")
    private WebElement editPersonalPropertyButton;
    private static final String  PERSONAL_PROPERTY_LIMIT_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + PERSONAL_PROPERTY_LIMIT + "')]";
    @FindBy(xpath = PERSONAL_PROPERTY_LIMIT_XPATH)
    private WebElement personalPropertyLimitLabelInEditCoverageSideSheet;
    @FindBy(xpath = PERSONAL_PROPERTY_LIMIT_XPATH + COVERAGE_DESCRIPTION_XPATH)
    private WebElement personalPropertyDescription;
    @FindBy(xpath = PERSONAL_PROPERTY_LIMIT_XPATH + "//ancestor::coverage-data-card//app-stepper-input//input")
    private WebElement personalPropertyAmountInput;
    @FindBy(xpath = PERSONAL_PROPERTY_LIMIT_XPATH + "//ancestor::coverage-data-card//app-stepper-input//mat-label")
    private WebElement personalPropertyAmountInputLabel;
    @FindBy(xpath = PERSONAL_PROPERTY_LIMIT_XPATH + "//ancestor::coverage-data-card//app-stepper-input//mat-button-toggle[contains(.,'remove')]")
    private WebElement personalPropertyMinusAmount;
    @FindBy(xpath = PERSONAL_PROPERTY_LIMIT_XPATH + "//ancestor::coverage-data-card//app-stepper-input//mat-button-toggle[contains(.,'add')]")
    private WebElement personalPropertyPlusAmount;
    @FindBy(xpath = PERSONAL_PROPERTY_LIMIT_XPATH + "//ancestor::coverage-data-card//mat-hint")
    private WebElement personalPropertyHint;

    private static final String LOSS_SETTLEMENT_LABEL = "Loss settlement";
    private static final String  PERSONAL_PROPERTY_LOSS_SETTLEMENT_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + LOSS_SETTLEMENT_LABEL + "')]";
    @FindBy(xpath = PERSONAL_PROPERTY_LOSS_SETTLEMENT_XPATH + COVERAGE_DESCRIPTION_XPATH)
    private WebElement personalPropertyLossSettlementDescription;
    @FindBy(xpath = PERSONAL_PROPERTY_LOSS_SETTLEMENT_XPATH +  "/ancestor::coverage-data-card//mat-button-toggle[contains(.,'RCV')]")
    private WebElement lossSettlementToggleRCV;
    @FindBy(xpath = PERSONAL_PROPERTY_LOSS_SETTLEMENT_XPATH +  "/ancestor::coverage-data-card//mat-button-toggle[contains(.,'ACV')]")
    private WebElement lossSettlementToggleACV;
    @FindBy(xpath = "//mat-dialog-container//mat-icon[text()='close']")
    private WebElement closeSidesheetButton;

    private static final String CHILD_CARE_LIABILITY = "Child care liability";
    private static final String IDENTITY_SHIELD = "Identity shield";
    private static final String ENHANCED_PERSONAL_PROPERTY = "Enhanced personal property";
    private static final String PERSONAL_INJURY = "Personal injury";

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceRentersReviewQuotePage() throws Exception {
    }

    public boolean isOnReviewQuotePageAceRenters() {
        try {
            wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOf(editDeductibleButton),
                    ExpectedConditions.visibilityOf(tryAgainButton)));
        } catch (TimeoutException te) {
            //Let the iselementvisible call happen
        }
        return isElementVisible(editDeductibleButton, 3);
    }

    public boolean isOnReviewQuotePageAceRenters(int seconds) {
        return isElementVisible(editDeductibleButton, seconds);
    }

    public void validatePageTitle(FarmersSoftAssert fsa) {
        fsa.assertEquals(getPageTitle(), PAGE_TITLE, "Ace Renters Review quote page - Title.");
    }

    public void validateContentOfCoverageSectionRentersLob(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome, String lobType) throws Exception {

        // F89863 - Loss of Use coverage defaults to 20% of CovC value for VA, CT, NC and 10% for all other states
        validateLossOfUseCoverageAmountOnMainScreen(fsa, applicantAceHome);

        //get the expected coverage and coverage amount from app store
        Map<String,String> coverageAmountKeyValuePair = getExpectedCoverageAndCoverageAmountFromAppStoreRentersLob(applicantAceHome);

        // fetch the found coverage name and coverage amount from the web elements
        List<String> foundPrimaryCoverageNames = getCondoRentersCoveragesNamesOnReviewQuotePage(lobType);
        List<String> expectedPrimaryCoverageNames = getSortedList(new ArrayList<>(coverageAmountKeyValuePair.keySet()));
        List<String> foundPrimaryCoverageAmounts = getCondoRentersCoveragesAmountOnReviewQuotePage();
        List<String> expectedPrimaryCoverageAmounts = new ArrayList<>(coverageAmountKeyValuePair.values());

        fsa.assertEquals(foundPrimaryCoverageNames, expectedPrimaryCoverageNames, "Renters coverage names verification.");
        fsa.assertEquals(getSortedList(foundPrimaryCoverageAmounts), getSortedList(expectedPrimaryCoverageAmounts), "Renters coverage amount values verification.");
        Log.info("Validating if found coverages and coverages amount lists are matching with expected coverages and coverages amount found from app store.");
    }

    public Map<String, String> getExpectedCoverageAndCoverageAmountFromAppStoreRentersLob(ApplicantAceHome applicantAceHome) throws Exception {
        String stateCode = applicantAceHome.getStateCode();
        AppStore appStore = getSessionStorageAppStore();
        String selectedPaymentMode = appStore.getHome().getQuote().getSelectedPaymentMode();
        List<AppStore.Home.CvgInfo> listOfPrimaryCoverageFromAppStore = getCovInfoFromAppStore(appStore, selectedPaymentMode, stateCode);
        List<String> expectedPrimaryCoverageAmountFromAppStore = listOfPrimaryCoverageFromAppStore.stream().map(AppStore.Home.CvgInfo::getCvgAmt).collect(Collectors.toList());

        // setting the coverage amount where we get values in terms of %
        int personalPropertyValueInt = getPersonalPropertyValueFromAppStore();
        String valueToSet;
        for (int i = 0; i < expectedPrimaryCoverageAmountFromAppStore.size(); i++){
            if(expectedPrimaryCoverageAmountFromAppStore.get(i).contains("%")){
                int multiplier = Integer.parseInt(expectedPrimaryCoverageAmountFromAppStore.get(i).replace("%", ""));
                valueToSet = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf((multiplier*personalPropertyValueInt)/100));
                expectedPrimaryCoverageAmountFromAppStore.set(i, valueToSet);
            }
        }

        // setting the expected coverage
        List<String> primaryCoverageNames = CoverageNameAceRenters.RENTERS_COVERAGE.getCoverages();
        List<String> expectedPrimaryCoverageNames = new ArrayList<>(primaryCoverageNames);
        if (stateCode.equals(CT)) {
            expectedPrimaryCoverageNames.replaceAll(coverageName -> coverageName.equals(LOSS_OF_USE) ? LOSS_OF_USE_TEXT : coverageName);
        } else if (List.of(KY,LA,MA,MS).contains(stateCode)) {
            expectedPrimaryCoverageNames.remove(BUILDING_ADDITIONS_ALTERATIONS);
        } else if (stateCode.equals(VA)) {
            expectedPrimaryCoverageNames.remove(LOSS_SETTLEMENT_LABEL);
        } else if (stateCode.equals(NC)) {
            expectedPrimaryCoverageNames.remove(LOSS_SETTLEMENT_LABEL);
            expectedPrimaryCoverageNames.remove(BUILDING_ADDITIONS_ALTERATIONS);
        }

        if(!List.of(NC,VA).contains(stateCode)){
            String livingExpenseTerm = expectedPrimaryCoverageAmountFromAppStore.get(2);
            if (livingExpenseTerm.contains("mos")) {
                livingExpenseTerm = " (" + livingExpenseTerm.split(SPACE)[0] + " months)";
                expectedPrimaryCoverageAmountFromAppStore.remove(2);
            }
            expectedPrimaryCoverageAmountFromAppStore.set(1, expectedPrimaryCoverageAmountFromAppStore.get(1).concat(livingExpenseTerm));
            expectedPrimaryCoverageAmountFromAppStore = expectedPrimaryCoverageAmountFromAppStore.stream().filter(i -> !i.equals("On")).collect(Collectors.toList());
            AppStore.Home.CvgInfo lossSettlementFromAppStore = listOfPrimaryCoverageFromAppStore.stream().filter(c -> c.getCvgCode().equals("23100")).findFirst().orElse(null);
            expectedPrimaryCoverageAmountFromAppStore.add(1, lossSettlementFromAppStore.getCvgDesc());
        }

        Map<String, String> coverageAmountKeyValuePair = new HashMap<>();
        for (int i = 0; i < expectedPrimaryCoverageAmountFromAppStore.size(); i++) {
            coverageAmountKeyValuePair.put(expectedPrimaryCoverageNames.get(i), expectedPrimaryCoverageAmountFromAppStore.get(i));
        }

        Log.info("Preparing the expected coverages and coverages amount from app store value");
        return coverageAmountKeyValuePair;
    }

    public Map<String, String> getCoverageNamesAndCoverageLimitsFromPage(String lobType) {
        List<String> foundPrimaryCoverageName = getCondoRentersCoveragesNamesOnReviewQuotePage(lobType);
        List<String> foundPrimaryCoverageAmount = getCondoRentersCoveragesAmountOnReviewQuotePage();

        Map<String, String> coverageAmountKeyValuePair = new HashMap<>();
        for (int i = 0; i < foundPrimaryCoverageAmount.size(); i++) {
            coverageAmountKeyValuePair.put(foundPrimaryCoverageName.get(i), foundPrimaryCoverageAmount.get(i));
        }
        Log.info("Getting Coverage names and Coverage limits from UI.");
        for (int i = 0; i < coverageAmountKeyValuePair.size(); i++) {
            Log.info(foundPrimaryCoverageName.get(i) + ": " + coverageAmountKeyValuePair.get(foundPrimaryCoverageName.get(i)));
        }
        return coverageAmountKeyValuePair;
    }

    public void clickOnEditPersonalPropertyButton() {
        waitAndClickElement(editPersonalPropertyButton);
        Log.info("Clicking edit personal property link for Renters lob.");
    }

    public String getPersonalPropertyLimit() {
        return getAttributeData(personalPropertyAmountInput, VALUE);
    }

    public void selectPersonalPropertyLimit(String limit) {
        clickOnEditPersonalPropertyButton();
        Double currentLimit = convertCurrencyStringToDouble(getPersonalPropertyLimit());
        Double limitToSelect = convertCurrencyStringToDouble(limit);
        Double previousLimit;
        if (currentLimit < limitToSelect) {
            while (convertCurrencyStringToDouble(getPersonalPropertyLimit()) < limitToSelect) {
                previousLimit = currentLimit;
                clickPlusSignOnPersonalProperty();
                currentLimit = convertCurrencyStringToDouble(getPersonalPropertyLimit());
                if (currentLimit.equals(previousLimit)) {
                    Log.info("Personal property limit is not increasing on click of plus button, even though the button is enabled. Current limit: " + currentLimit);
                    break;
                }
            }
        } else if (currentLimit > limitToSelect) {
            while (convertCurrencyStringToDouble(getPersonalPropertyLimit()) > limitToSelect) {
                previousLimit = currentLimit;
                clickMinusSignOnPersonalProperty();
                currentLimit = convertCurrencyStringToDouble(getPersonalPropertyLimit());
                if (currentLimit.equals(previousLimit)) {
                    Log.info("Personal property limit is not decreasing on click of minus button, even though the button is enabled. Current limit: " + currentLimit);
                    break;
                }
            }
        }
        if (convertCurrencyStringToDouble(getPersonalPropertyLimit()).equals(limitToSelect)) {
            Log.info("Selected personal property limit: " + limit);
            clickRecalculateButtonCondoRentersInSideSheet();
            waitForSpinnerToBeGone();
        }
    }

    public void validateSewerAndDrainForPropertyLimit(FarmersSoftAssert fsa, String stateCode) throws Exception {
        String PERSONAL_PROPERTY_LIMIT = "$5,000";
        Log.info("Validating sewer and drain availability for state: " + stateCode);

        fsa.assertTrue(!getListOfOptionalCoverageNames().contains(SEWER_AND_DRAIN), "Sewer and drain is not available on the main page, as expected.");
        selectPersonalPropertyLimit(PERSONAL_PROPERTY_LIMIT);
        fsa.assertTrue(getListOfOptionalCoverageNames().contains(SEWER_AND_DRAIN), "Sewer and drain is available on the main page, after Personal property limit is increased to 5K.");
        int sewerAndDrainIndex = getListOfOptionalCoverageNames().indexOf(SEWER_AND_DRAIN);
        fsa.assertEquals(getListOfOptionalCoverageValues().get(sewerAndDrainIndex), "---", "Sewer and drain is available on the main page, but it's off, as expected.");

        clickEditOptionalCoveragesLink();
        fsa.assertFalse(isOptionalCoverageToggleSelected(SEWER_AND_DRAIN), "Sewer and drain toggle is not selected in side-sheet, as expected.");
        clickOptionalCoverageToggle(SEWER_AND_DRAIN);
        clickRecalculateButtonCondoRentersInSideSheet();
        waitForSpinnerToBeGone();
        fsa.assertTrue(getListOfOptionalCoverageNames().contains(SEWER_AND_DRAIN), "Sewer and drain is available on the main page, after it was selected.");
        fsa.assertEquals(getListOfOptionalCoverageValues().get(sewerAndDrainIndex), "Included", "Sewer and drain is available on the main page, after it was selected.");
    }

    public void validatePersonalPropertySideSheetRenters(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome) throws Exception {
        clickOnEditPersonalPropertyButton();
        validateCommonContentFromEditCoverageSideSheetCondoRentersLob(fsa, RENTERS, "Edit personal property");
        String minPersonalPropertyValue;
        String stateCode = applicantAceHome.getStateCode();
        if (stateCode.equals(VA)) {
            minPersonalPropertyValue = "$5,000";
        } else if (stateCode.equals(KS)) {
            minPersonalPropertyValue = "$25,000";
        } else {
            minPersonalPropertyValue = "$4,000";
        }
        String defaultPersonalPropertyValue = minPersonalPropertyValue;
        String maxPersonalPropertyValue = "$150,000";
        validatePersonalPropertyLimitSection(fsa, minPersonalPropertyValue, defaultPersonalPropertyValue, maxPersonalPropertyValue);
        if (!List.of(NC,VA).contains(stateCode)) {
            validatePersonalPropertyLossSettlement(fsa, "RCV");
        } else {
            waitAndClickElement(closeSidesheetButton);
        }
    }

    private void validatePersonalPropertyLimitSection(FarmersSoftAssert fsa, String minPPCoverage, String defaultPPCoverage, String maxPPCoverage) {
        scrollToElement(personalPropertyLimitLabelInEditCoverageSideSheet);
        fsa.assertTrue(personalPropertyLimitLabelInEditCoverageSideSheet.isDisplayed(), "Limit label displayed in edit Personal property coverage side sheet - Renters.");
        String expectedPersonalPropertyDescription = "This coverage, also known as Coverage C, can help replace your possessions owned or used by an insured anywhere in the world subject to the policy provisions and special limits for things like jewelry, watches, furs, firearms and computers. For a complete list, please check with your Farmers agent.";
        fsa.assertEquals(getTextFromElement(personalPropertyDescription), expectedPersonalPropertyDescription, "Personal property description is verified - Renters.");

        // Validate the Personal property value
        fsa.assertTrue(personalPropertyAmountInput.isDisplayed(), "Personal property input webElement is displayed - Renters.");
        fsa.assertEquals(getTextFromElement(personalPropertyAmountInputLabel), "Personal property value", "Personal property input label verification - Renters.");
        fsa.assertEquals(getAttributeData(personalPropertyAmountInput, VALUE), defaultPPCoverage, "Personal property default value verification - Renters.");

        fsa.assertEquals(getTextFromElement(personalPropertyMinusAmount), "remove", "Personal property minus coverage web element displayed - Renters.");
        fsa.assertEquals(getTextFromElement(personalPropertyPlusAmount), "add", "Personal property add coverage web element displayed - Renters.");
        String expectedPersonalPropertyHintText = minPPCoverage + " - " + maxPPCoverage;
        fsa.assertEquals(getTextFromElement(personalPropertyHint), expectedPersonalPropertyHintText, "Personal property hint text displayed - Renters.");

        // Validate if coverage amount value is increased by 1K when clicking on (+)
        double minPersonalPropertyValue = convertCurrencyStringToDouble(minPPCoverage);
        String personalPropertyValue = EMPTY_STRING;
        for (int i = 4; i < 30; i++) {
            clickPlusSignOnPersonalProperty();
            personalPropertyValue = getAttributeData(personalPropertyAmountInput,VALUE);
            String expectedPersonalPropertyValue = CurrencyFormat.convertDoubleToCurrencyString(minPersonalPropertyValue + (i-3)*1000).replace(".00", EMPTY_STRING);
            fsa.assertEquals(personalPropertyValue, expectedPersonalPropertyValue, "Personal property coverage value, after (+) clicked: " + (i - 3) + " time(s)");
        }

        String expectedPersonalPropertyValue = personalPropertyValue;

        // Validate if coverage amount value is decreased by 1K when clicking on (-) until 4K
        for (int i = 30; i > 0; i--) {
            clickMinusSignOnPersonalProperty();
            personalPropertyValue = getAttributeData(personalPropertyAmountInput,VALUE);
            expectedPersonalPropertyValue = CurrencyFormat.convertDoubleToCurrencyString(convertCurrencyStringToDouble(expectedPersonalPropertyValue) - 1000).replace(".00", EMPTY_STRING);
            expectedPersonalPropertyValue = convertCurrencyStringToDouble(expectedPersonalPropertyValue) < minPersonalPropertyValue ? minPPCoverage : expectedPersonalPropertyValue;
            fsa.assertEquals(personalPropertyValue, expectedPersonalPropertyValue, "Personal property coverage value, after (-) clicked: " + (30 - i + 1) + " time(s)");
        }

        // Reset changes
        clickResetChangesButtonCondoRentersInSideSheet();
        clickResetValueButton();

        Log.info("Validating Personal property coverage header/description, coverage amount input field, add/remove icons, validate if value is increased in 1000 on click of plus icon," +
                " validate if value is decreased in 1000 on click of minus icon, coverage hint text");
    }

    public void validatePersonalPropertyLossSettlement(FarmersSoftAssert fsa, String lossSettlement) throws Exception {
	String separator = Property.getTestProperty("driver").equals(SAFARI)? EMPTY_STRING : SPACE;
        String lossSettlementDescription = "Replacement cost value (RCV) - The amount we pay for repair or replacement does not deduct for depreciation." + separator +
        	"Actual cash value (ACV) - The amount we may pay for repair or replacement is reduced to account for depreciation.";
        fsa.assertEquals(getTextFromElement(personalPropertyLossSettlementDescription), lossSettlementDescription, "Personal property Loss settlement description validation.");
        if (lossSettlement.equals("RCV")) {
            fsa.assertTrue(getAttributeData(lossSettlementToggleRCV, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED), "Personal property Loss settlement toggle - RCV is selected.");
            fsa.assertFalse(getAttributeData(lossSettlementToggleACV, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED), "Personal property Loss settlement toggle - ACV is not selected.");
            waitAndClickElement(lossSettlementToggleACV);
        } else {
            fsa.assertFalse(getAttributeData(lossSettlementToggleRCV, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED), "Personal property Loss settlement toggle - RCV is not selected.");
            fsa.assertTrue(getAttributeData(lossSettlementToggleACV, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED), "Personal property Loss settlement toggle - ACV is selected.");
            waitAndClickElement(lossSettlementToggleRCV);
        }
        clickRecalculateButtonCondoRentersInSideSheet();

        String expectedLossSettlement = lossSettlement.equals("RCV") ? "Actual cash value" : "Replacement cost value";
        fsa.assertEquals(getCoveragePriceByNameFromScreen(LOSS_SETTLEMENT_LABEL), expectedLossSettlement, "Review quote page - Personal property Loss settlement type.");
    }

    public void validateEditCoverageSideSheetRentersLob(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome, String lobType) throws Exception {
        String stateCode = applicantAceHome.getStateCode();
        clickOnAddEditCoverageLinkButton();
        // validate common content of cond edit coverage side sheet
        validateCommonContentFromEditCoverageSideSheetCondoRentersLob(fsa, lobType, "Renters coverages");

        Map<String, String> coverageAmountKeyValuePair = getExpectedCoverageAndCoverageAmountFromAppStoreRentersLob(applicantAceHome);

        // validate Loss of use coverage amount on edit coverage side sheet
        validateLossOfUseSection(fsa, coverageAmountKeyValuePair, stateCode, lobType);

        // validate personal liability section
        validatePersonalLiabilitySection(fsa, coverageAmountKeyValuePair, lobType);

        // validate medical payment to others section
        validateMedicalPaymentToOthersSection(fsa, coverageAmountKeyValuePair, lobType);

        // validate content of building ordinance and alterations section
        if (!List.of(KY,LA,MA,MS,NC).contains(applicantAceHome.getStateCode())) {
            validateBuildingAdditionsAndAlterationSection(fsa, coverageAmountKeyValuePair, lobType);
        } else {
            clickElement(unselectedMedicalPaymentToOthersRadioButtonElement);
        }

        // Validate content of reset value pop up and reset coverage value in side sheet
        validateRecalculateResetButtonTextInSideSheet(fsa, lobType);
        clickResetChangesButtonCondoRentersInSideSheet();
        validateContentOfResetChangesPopUp(fsa);
        clickKeepEditingButton();
        clickResetChangesButtonCondoRentersInSideSheet();
        clickResetValueButton();
        validateIfCoverageIsResetInCoverageSideSheetRentersLob(fsa, coverageAmountKeyValuePair, lobType, applicantAceHome.getStateCode());

        // randomly update the coverage value from condo side sheet
        editTheRentersCoveragesAndValidateContentOnMainPage(coverageAmountKeyValuePair, applicantAceHome.getStateCode());

        // validate randomly edited coverage values are updated on main screen
        waitForSpinnerToBeGone();
        validateEditedCoverageValueUpdatedOnMainScreen(fsa, coverageAmountKeyValuePair, lobType);

    }

    private void validateBuildingAdditionsAndAlterationSection(FarmersSoftAssert fsa, Map<String, String> coverageAmountKeyValuePair, String lobType){
        scrollToElement(buildingAdditionsAlterationsLabelInEditCoverageSideSheet);
        fsa.assertTrue(buildingAdditionsAlterationsLabelInEditCoverageSideSheet.isDisplayed(), BUILDING_ADDITIONS_ALTERATIONS + " label displayed in edit coverage side sheet - " + lobType );
        String expectedBuildingAdditionsAlterationsDescription = "This coverage can pay to repair or replace alterations, fixtures, improvements or installation made at your expense before covered loss or damage occurs, to the part of the residence used exclusively by you.";
        fsa.assertEquals(getTextFromElement(buildingAdditionsAlterationsDescriptionWebElement), expectedBuildingAdditionsAlterationsDescription, MINE_SUBSIDENCE + " description verification - " + lobType);
        String buildingAdditionsAlterationsCoverageValue = coverageAmountKeyValuePair.get(BUILDING_ADDITIONS_ALTERATIONS);

        // Validate the building ordinance and alteration value is as per app store
        fsa.assertTrue(buildingAdditionsAlterationsCoverageAmoutInputWebElement.isDisplayed(), BUILDING_ADDITIONS_ALTERATIONS + " input web element displayed - " + lobType);
        fsa.assertEquals(getAttributeData(buildingAdditionsAlterationsCoverageAmoutInputWebElement, VALUE), buildingAdditionsAlterationsCoverageValue, BUILDING_ADDITIONS_ALTERATIONS + " value verification - " + lobType);


        fsa.assertEquals(getTextFromElement(buildingAdditionsAlterationsMinusAmoutWebElement), "remove", BUILDING_ADDITIONS_ALTERATIONS + " minus coverage web element displayed - " + lobType);
        fsa.assertEquals(getTextFromElement(buildingAdditionsAlterationsPlusAmoutWebElement), "add", BUILDING_ADDITIONS_ALTERATIONS + " add coverage web element displayed - " + lobType);
        String expectedBuildingAlterationAndAdditionsHintText = getBuildingAlterationAdditionsValueFromInputField() + " - $100,000";
        fsa.assertEquals(getTextFromElement(buildingAdditionsAlterationsHintWebElement), expectedBuildingAlterationAndAdditionsHintText, BUILDING_ADDITIONS_ALTERATIONS + " hint text displayed - " + lobType);

        // Validate if coverage amount value is increase as per the requirement
        int buildingAdditionAlterationValueBeforeClickingPlusSign = getIntCurrencyValueFromStringCurrencyValue(getBuildingAlterationAdditionsValueFromInputField());
        clickPlusOnBuildingAdditionsAlterationsSign();
        if(!buildingAdditionsAlterationsCoverageValue.equals("$100,000")){
            int expectedNewBuildingAdditionsAlterationsValue = buildingAdditionAlterationValueBeforeClickingPlusSign + 1000;
            fsa.assertEquals(getBuildingAlterationAdditionsValueFromInputField(), CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(expectedNewBuildingAdditionsAlterationsValue)),
                    BUILDING_ADDITIONS_ALTERATIONS + " value is not increased even though the plus button is enabled - " + lobType);
        }else{
            fsa.assertEquals(getBuildingAlterationAdditionsValueFromInputField(), buildingAdditionsAlterationsCoverageValue, BUILDING_ADDITIONS_ALTERATIONS + " value is not staying as original even through the plus button is disabled - " + lobType);
        }

        // Validate if coverage amount value is not decreased as per the requirement
        int buildingAdditionAlterationValueBeforeClickingMinusSign = getIntCurrencyValueFromStringCurrencyValue(getBuildingAlterationAdditionsValueFromInputField());
        clickMinusOnBuildingAdditionsAlterationsSign();
        if(!(buildingAdditionAlterationValueBeforeClickingMinusSign == 2000)){
            int expectedNewBuildingAdditionsAlterationsValue = buildingAdditionAlterationValueBeforeClickingMinusSign - 1000;
            sleep(2);
            fsa.assertEquals(getBuildingAlterationAdditionsValueFromInputField(), CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(expectedNewBuildingAdditionsAlterationsValue)),
                    BUILDING_ADDITIONS_ALTERATIONS + " value is not decreased even though the minus button is enabled - " + lobType);
        }else{
            fsa.assertEquals(getBuildingAlterationAdditionsValueFromInputField(), buildingAdditionsAlterationsCoverageValue, BUILDING_ADDITIONS_ALTERATIONS + " value is not staying as original even through the minus button is disabled - " + lobType);
        }
        Log.info("Validating " + BUILDING_ADDITIONS_ALTERATIONS + " coverage header/description, coverage amount input field, add/remove icons, validate if value is increased in 1000 on click of plus icon," +
                " validate if value is decreased in 1000 on click of minus icon, coverage hint text");
    }

    private void clickPlusSignOnPersonalProperty(){
        waitAndClickElement(personalPropertyPlusAmount);
    }

    private void clickMinusSignOnPersonalProperty(){
        waitAndClickElement(personalPropertyMinusAmount);
    }

    private void clickPlusOnBuildingAdditionsAlterationsSign(){
        waitAndClickElement(buildingAdditionsAlterationsPlusAmoutWebElement);
    }

    private void clickMinusOnBuildingAdditionsAlterationsSign(){
        waitAndClickElement(buildingAdditionsAlterationsMinusAmoutWebElement);
    }

    private String getBuildingAlterationAdditionsValueFromInputField(){
        return getAttributeData(buildingAdditionsAlterationsCoverageAmoutInputWebElement, VALUE);
    }

    private void validateIfCoverageIsResetInCoverageSideSheetRentersLob(FarmersSoftAssert fsa, Map<String, String> coverageAmountKeyValuePair, String lobType, String stateCode){
        String originalSelectedLossOfUseOption = getTextFromElement(lossOfUseDropDownWebElement);
        String originalSelectedBuildingAdditionsAlterationsValue = null;
        if (coverageAmountKeyValuePair.get(BUILDING_ADDITIONS_ALTERATIONS) != null) {
            originalSelectedBuildingAdditionsAlterationsValue = getBuildingAlterationAdditionsValueFromInputField();
        }
        String originalSelectedMedicalPaymentToOthersValue = getTextFromElement(selectedMedicalPaymentToOthersRadioButtonElement);
        String originalSelectedPersonalLiabilityValue = getTextFromElement(selectedPersonalLiabilityRadioButtonElement);

        fsa.assertEquals(originalSelectedLossOfUseOption.replace("/ ", ""), coverageAmountKeyValuePair.get(getLossOfUseCoverageName(stateCode)).replaceAll("[()]", ""),
                getLossOfUseCoverageName(stateCode) + " drop down selected values verification - " + lobType);
        fsa.assertEquals(originalSelectedPersonalLiabilityValue, coverageAmountKeyValuePair.get(PERSONAL_LIABILITY),
                PERSONAL_LIABILITY + " selected radio button value verification - " + lobType);

        fsa.assertEquals(originalSelectedMedicalPaymentToOthersValue, coverageAmountKeyValuePair.get(MEDICAL_PAYMENT_TO_OTHERS),
                MEDICAL_PAYMENT_TO_OTHERS + " selected radio button value verification - " + lobType);

        fsa.assertEquals(originalSelectedBuildingAdditionsAlterationsValue, coverageAmountKeyValuePair.get(BUILDING_ADDITIONS_ALTERATIONS),
                BUILDING_ADDITIONS_ALTERATIONS + " default input element value verification - " + lobType);

        Log.info("Validate if coverage values are reset in coverage side sheet on click of reset button in coverage side sheet for " + lobType + ".");
    }

    // edit the coverage value in renters coverage side sheet
    public void editTheRentersCoveragesAndValidateContentOnMainPage(Map<String, String> coverageAmountKeyValuePair, String stateCode) {
        String newlySelectedLossOfUseValue = randomlySelectLossOfUseFromDropDown();
        coverageAmountKeyValuePair.put(getLossOfUseCoverageName(stateCode), newlySelectedLossOfUseValue);

        String newlySelectedPersonalLiabilityValue = randomlySelectPersonalLiabilityRadioButton();
        coverageAmountKeyValuePair.put(PERSONAL_LIABILITY, newlySelectedPersonalLiabilityValue);

        String newlySelectedMedicalPaymentValue = randomlySelectMedicalPaymentRadioButton();
        coverageAmountKeyValuePair.put(MEDICAL_PAYMENT_TO_OTHERS, newlySelectedMedicalPaymentValue);

        // update Building alteration and addition value
        if((coverageAmountKeyValuePair.get(BUILDING_ADDITIONS_ALTERATIONS) != null) &&
                !getBuildingAlterationAdditionsValueFromInputField().equals("$100,000")){
            clickPlusOnBuildingAdditionsAlterationsSign();
            coverageAmountKeyValuePair.put(BUILDING_ADDITIONS_ALTERATIONS, getBuildingAlterationAdditionsValueFromInputField());
        }

        clickRecalculateButtonCondoRentersInSideSheet();
        waitForSpinnerToBeGone();
        scrollToTopOfPage();
    }

    ////
    //// TODO: Optional coverages side-sheet elements
    //// these are separated from the rest of the class as they might move to a page base class later on, if Home/Condo are updated similarly
    ////
    private static final String OPTIONAL_COVERAGES_LABEL = "Optional coverages";
    private static final String OPTIONAL_COVERAGES_SUBTITLE = "Pick and choose optional coverages you want for your property. (optional)";
    @FindBy(xpath = "//app-condo-renters-quote-review//h2[contains(text(),'" + OPTIONAL_COVERAGES_LABEL + "')]")
    private WebElement optionalCoveragesHeader;
    private static final String OPTIONAL_COVERAGES_SIDESHEET_HEADER_XPATH = "//app-renters-optional-coverages//div[@id='additionalCoveragesDialogHeading']";
    @FindBy(xpath = OPTIONAL_COVERAGES_SIDESHEET_HEADER_XPATH)
    private WebElement optionalCoveragesSidesheetHeader;
    @FindBy(xpath = "//app-renters-optional-coverages//div[contains(@class,'subheading-class')]")
    protected WebElement additionalCoveragesSidesheetSubheading;
    @FindBy(xpath = "//app-condo-renters-quote-review//div[contains(@class,'coverage-name')]")
    private List<WebElement> optionalCoverageNames;
    @FindBy(xpath = "//app-condo-renters-quote-review//div[contains(@class,'coverage-name')]//following-sibling::div[contains(@class,'coverage-price-column')]")
    private List<WebElement> optionalCoverageAmounts;
    @FindBy(xpath = "//button[@id='editOptionalCoverageLink']")
    private WebElement editOptionalCoverages;

    private final List<String> ADDITIONAL_COVERAGES_TITLES = Arrays.asList(ENHANCED_PERSONAL_PROPERTY, IDENTITY_SHIELD, PERSONAL_INJURY,
            LIMITED_MOLD, INCREASED_LIMITS_FOR_VALUABLES_TITLE);
    private static final String TOGGLE_TEXT_XPATH = "//mat-slide-toggle[contains(.,'%s')]/following-sibling::div[contains(@class,'tui-caption-text')]";
    private static final String TOGGLE_PRICE_XPATH = "//mat-slide-toggle[contains(.,'%s')]/following-sibling::div[contains(@class,'tui-subtitle-text')]";
    private static final String TOGGLE_BUTTON_XPATH = "//mat-slide-toggle[contains(.,'%s')]";
    @FindBy(xpath="//mat-slide-toggle")
    private List<WebElement> toggleButtons;

    @FindBy(xpath = "//div[@id='Limitedmold']//label")
    protected WebElement headerLimitedMold;
    @FindBy(xpath = "//div[@id='Limitedmold']//mat-radio-button")
    protected List<WebElement> radioButtonsLimitedMold;
    @FindBy(xpath = "//div[@id='Limitedmold']//mat-form-field//input")
    protected WebElement yearBuiltInputLimitedMold;

    @FindBy(xpath = "//div[@id='IncreasedlimitsforLimitedmold']//label[contains(@class,'tui-input-text-2')]")
    protected WebElement headerIncreasedLimitsForLimitedMold;
    @FindBy(xpath = "//div[@id='IncreasedlimitsforLimitedmold']//mat-radio-button")
    protected WebElement radioButtonIncreasedLimitsForLimitedMold;
    @FindBy(xpath = "//div[@id='IncreasedlimitsforLimitedmold']//mat-form-field//input")
    protected WebElement yearBuiltInputIncreasedLimitsForLimitedMold;

    @FindBy(xpath = "//div[@id='increasedValuables']//label[contains(@class,'tui-input-text-2')]")
    private WebElement headerIncreasedValuables;
    @FindBy(xpath = "//div[@id='increasedValuables']//button[contains(@aria-label,'info icon')]")
    private WebElement headerIncreasedValuablesInfoIcon;
    private static final String INCREASED_VALUABLES_CHECKBOX_XPATH = "//div[@id='increasedValuables']//mat-slide-toggle";
    @FindBy(xpath = INCREASED_VALUABLES_CHECKBOX_XPATH)
    private List<WebElement> checkboxesIncreasedValuables;
    @FindBy(xpath = INCREASED_VALUABLES_CHECKBOX_XPATH)
    private WebElement checkboxesIncreasedValuable;
    @FindBy(xpath = "//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]")
    private WebElement footerIncreasedValuables;
    @FindBy(xpath = "//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]/descendant::div[contains(.,'*')]")
    protected WebElement footerIncreasedValuablesStarText;
    @FindBy(xpath = "(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[1]")
    private WebElement inputIncreasedCoverageJewelry;
    @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[1]")
    private WebElement increaseCoverageJewelry;
    @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[1]")
    private WebElement decreaseCoverageJewelry;
    @FindBy(xpath = "(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[2]")
    private WebElement inputIncreasedCoverageSilverware;
    @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[2]")
    private WebElement increaseCoverageSilverware;
    @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[2]")
    private WebElement decreaseCoverageSilverware;
    @FindBy(xpath = "(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[3]")
    private WebElement inputIncreasedCoverageFirearms;
    @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[3]")
    private WebElement increaseCoverageFirearms;
    @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[3]")
    private WebElement decreaseCoverageFirearms;
    @FindBy(xpath = "(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[4]")
    private WebElement inputIncreasedCoverageSecurities;
    @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[4]")
    private WebElement increaseCoverageSecurities;
    @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[4]")
    private WebElement decreaseCoverageSecurities;
    @FindBy(xpath = "(//div[@id='increasedValuables']//div[contains(@class,'checkbox-input-group')]//input)[5]")
    private WebElement inputIncreasedCoverageOffPremisesElectronics;
    @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])[5]")
    private WebElement increaseCoverageOffPremisesElectronics;
    @FindBy(xpath = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])[5]")
    private WebElement decreaseCoverageOffPremisesElectronics;
    @FindBy(xpath = "//app-additional-coverage-card//mat-error")
    protected List<WebElement> errorsIncreasedCoverageSection;

    @FindBy(xpath = "//app-increase-valuables-info-dialog//h1")
    protected WebElement increasedValuablesInfoDialogHeader;
    @FindBy(xpath = "//app-increase-valuables-info-dialog//button[@aria-label='Close']")
    protected WebElement increasedValuablesInfoDialogCloseButton;
    // Increased limits for certain valuables Info dialog elements
    @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[1]")
    private WebElement increasedValuablesInfoDialogMainContent;
    @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[2]")
    private WebElement increasedValuablesInfoDialogSubtitle;
    @FindBy(xpath = "//app-increase-valuables-info-dialog//div[@class='tui-body-text-1']//li")
    private List<WebElement> increasedValuablesInfoDialogPoints;

    @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][2]")
    // Other articles
    private WebElement increasedValuablesInfoDialogOtherArticles;
    @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][2]/following-sibling::div[1]")
    // Firearms, Security, Silverware, Fine arts
    private WebElement increasedValuablesInfoDialogOtherArticlesTextFirearms;
    @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//div[contains(@class,'tui-subtitle-text-2')][2]/following-sibling::div[2]")
    private WebElement increasedValuablesInfoDialogOtherArticlesTextWatches;
    @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[1]")
    private WebElement increasedValuablesInfoDialogDivider1;
    @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[2]")
    private WebElement increasedValuablesInfoDialogDivider2;
    @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-body-text-1')]//mat-divider[3]")
    private WebElement increasedValuablesInfoDialogDivider3;

    @FindBy(xpath = "//div[@id='Earthquake']//mat-slide-toggle")
    protected WebElement headerEarthquake;
    @FindBy(xpath = "//div[@id='Earthquake']//mat-radio-button")
    private List<WebElement> radioButtonsEarthquake;
    @FindBy(xpath = "//div[@id='Earthquake']//mat-radio-button//label")
    protected List<WebElement> radioButtonsEarthquakeLabels;
    @FindBy(xpath = "//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]/following-sibling::div//li")
    private List<WebElement> listFoundationsEarthquakeSection;
    @FindBy(xpath = "//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]")
    private List<WebElement> headersEarthquakeSection;
    @FindBy(xpath = "//div[@id='Earthquake']//mat-button-toggle")
    private List<WebElement> toggleButtonsEarthquake;
    @FindBy(xpath = "//div[@id='Earthquake']//button[contains(@aria-label,'info icon')]")
    private List<WebElement> earthquakeInfoIcons;
    @FindBy(xpath = "//div[@id='Earthquake']//mat-form-field//label")
    private WebElement earthquakeYearBuiltLabel;
    @FindBy(xpath = "//div[@id='Earthquake']//button[contains(@aria-label,'info icon')]")
    private WebElement earthquakeInfoIcon;
    @FindBy(xpath = "//app-earthquake-coverage-dialog//h4")
    protected WebElement earthquakeCoverageInfoDialogHeader;
    @FindBy(xpath = "//app-earthquake-coverage-dialog//div/span[contains(@class,'tui-subtitle-2')]")
    private List<WebElement> earthquakeInfoDialogSubheaders;
    @FindBy(xpath = "//app-earthquake-coverage-dialog//div[contains(@class,'tui-body')]")
    private List<WebElement> earthquakeInfoDialogParagraphs;
    @FindBy(xpath = "//mat-dialog-container[contains(@aria-label,'earthquake')]//mat-icon[text()='close']")
    private WebElement closeEarthquakeInfoSidesheetButton;
    @FindBy(xpath = "//div[@id='Earthquake']//mat-form-field//input")
    protected WebElement yearBuiltInputEarthquake;

    @FindBy(xpath = "//mat-dialog-container/span[contains(@class,'tui-subtitle')]")
    protected WebElement watercraftCoverageDialogTitle;
    @FindBy(xpath = "//mat-dialog-container/mat-dialog-content")
    protected WebElement watercraftCoverageDialogContent;
    @FindBy(xpath = "//mat-dialog-container/mat-dialog-actions/a")
    protected WebElement buttonRemoveCoverage;
    @FindBy(xpath = "//mat-dialog-container/mat-dialog-actions/button")
    protected WebElement buttonOk;

    @FindBy(xpath = "//app-additional-coverages-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]//mat-icon[@aria-label='expand quote card']")
    protected WebElement expandQuoteCard;
    @FindBy(xpath = "//app-additional-coverages-page//mat-card[contains(@class,'tui-quote-presentment-mobile')]//mat-icon[@aria-label='minimize quote card']")
    protected WebElement minimizeQuoteCard;

    public void clickEditOptionalCoveragesLink(){
        waitAndClickElement(editOptionalCoverages);
        Log.info("Clicking on 'Edit optional coverages' link for Renters lob.");
    }

    public boolean isOptionalCoverageToggleSelected(String coverage) throws Exception {
        return getAttributeData(driver().findElement(By.xpath(String.format(TOGGLE_BUTTON_XPATH, coverage))), CLASS).contains(MAT_TOGGLE_CHECKED);
    }

    public boolean isOptionalCoverageSidesheetOpen() throws Exception {
        return isElementDisplayed(By.xpath(OPTIONAL_COVERAGES_SIDESHEET_HEADER_XPATH));
    }

    public String getOptionalCoverageText(String coverage) throws Exception {
        String toggleTextXpath = String.format(TOGGLE_TEXT_XPATH, coverage);
        WebElement toggleTextWe = driver().findElement(By.xpath(toggleTextXpath));
        return getTextFromElement(toggleTextWe);
    }

    public String getOptionalCoveragePrice(String coverage) throws Exception {
        String toggleTextXpath = String.format(TOGGLE_PRICE_XPATH, coverage);
        String optionalCoveragePrice = EMPTY_STRING;
        if (isElementDisplayed(By.xpath(toggleTextXpath))) {
            WebElement togglePriceWe = driver().findElement(By.xpath(toggleTextXpath));
            optionalCoveragePrice = getTextFromElement(togglePriceWe);
        }
        return optionalCoveragePrice;
    }

    public void clickOptionalCoverageToggle(String coverage) throws Exception {
        waitAndClickElement(driver().findElement(By.xpath(String.format(TOGGLE_BUTTON_XPATH + "//label", coverage))));
    }

    public List<String> getListOfOptionalCoverageNames() {
        return optionalCoverageNames.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public List<String> getListOfOptionalCoverageValues() {
        return optionalCoverageAmounts.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    private static LinkedHashMap<String, String> getTogglesTextLinkedHashMap() {
        LinkedHashMap<String, String> additionalCoveragesDescriptionMap = new LinkedHashMap<>();
        additionalCoveragesDescriptionMap.put("Identity shield", "Helps you resolve identity fraud, provides compensation for time and loss up to " +
                "the stated limits, performs credit monitoring, provided assistance with notifying credit bureaus of the fraud, and assists in " +
                "replacing important documents. Identity shield also provides access to an advocate who will guide you through the identity recovery process.");
        additionalCoveragesDescriptionMap.put("Identity Fraud","Helps with the costs of repairing credit integrity that was compromised by identity theft.");
        additionalCoveragesDescriptionMap.put("Personal injury", "This coverage can pay for personal injury damages which you are legally obligated " +
                "to pay as a result of a covered occurrence.");
        additionalCoveragesDescriptionMap.put("Sewer and drain", "This coverage can pay to repair or replace covered property resulting from a sudden " +
                "and accidental water loss from a system within the residence premises and is either a water - reverse flow or from below the " +
                "surface of the ground.");
        additionalCoveragesDescriptionMap.put("Increased limits for Limited mold", "This coverage can pay for expenses required to remediate any mold which results from " +
                "the repair or replacement of a covered loss.");
        additionalCoveragesDescriptionMap.put("Limited mold", "This coverage can pay for expenses required to remediate any mold which results from " +
                "the repair or replacement of a covered loss.");
//        additionalCoveragesDescriptionMap.put("Increased limits for certain valuables", "This is in addition to what's included in your policy for your " +
//                "jewelry ($1,000 per item / $2,500 total), silverware ($2,500), firearms ($2,500), securities ($1,000), and off-premises " +
//                "portable electronic equipment($5,000).");
        additionalCoveragesDescriptionMap.put("Earthquake", "Provides coverage for direct physical loss or damage caused by earthquake subject to the " +
                "coverage provided in the endorsement and the earthquake deductible selected. The underlying property policies exclude loss caused by " +
                "all earth movements, including earthquakes.");
        additionalCoveragesDescriptionMap.put("Child care liability", "Provides coverage for bodily injury and property damage arising from, during the course of, " +
                "or in connection with any licensed home child care services for no more than the number of children indicated.");
        additionalCoveragesDescriptionMap.put("Enhanced personal property", "Loss or damage to property is covered under this policy if it is caused by one of " +
                "the named perils, such as hail, vandalism or wild deer. With the Enhanced Personal Property endorsement, coverage is broadened beyond the named perils, " +
                "subject to exclusions.");
        additionalCoveragesDescriptionMap.put("Watercraft liability - family protection", "This coverage is for bodily injury to family and household members other than " +
                "the Named Insured, that results from an occurrence involving watercraft. (Unselecting this option will deduct $2.00 from your Package price. If you " +
                "choose to decline this coverage, you must sign and return the Declination of Family Protection Liability Coverage form.)");
        return additionalCoveragesDescriptionMap;
    }

    public void validateAdditionalCoveragesTogglesText(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception {
        LinkedHashMap<String, String> additionalCoveragesDescriptionMap = getTogglesTextLinkedHashMap();
        final String INCREASED_LIMITS_FOR_VALUABLES_INFO_TITLE = "Increased limits for certain valuables";
        final String INCREASED_LIMITS_FOR_VALUABLES_INFO_TEXT = "Each policy automatically includes some coverage for valuable items, but some people " +
                "need more coverage than what is automatically included. If you need more coverage, you can add additional coverage by type of valuable " +
                "item in increments of $1,000. There is a maximum combined coverage limit available depending on your Personal Property coverage limit.";
        final String INCREASED_LIMITS_FOR_VALUABLES_INFO_SUBTITLE = "The automatically included coverage limits are:";
        final List<String> INCREASED_LIMITS_FOR_VALUABLES_INFO_ITEMS = List.of("Jewelry is covered up $1,000 for any one article and up to $2,500 total " +
                "limit for loss by theft.", "Silverware, goldware, platinumware and pewterware, are covered up to $2,500 for loss by theft.",
                "Firearms are covered up to $2,500 for loss by theft.", "Securities, deeds, valuable papers, personal records, and stamps are covered up " +
                "to $1,000 for loss or damage.", "Portable electronic equipment, including computers, personal electronics, entertainment equipment, " +
                "communication equipment, and accessories necessary are covered up to $5,000 for repair or replacement due to a covered loss while the " +
                "property was away from your home.");
        final List<String> EARTHQUAKE_RADIO_TEXT = Arrays.asList("10%", "15%", "20%", "25%");
        final List<String> EARTHQUAKE_INFO_DIALOG_PARAGRAPHS = List.of(
                // Coverage
                "Coverage for direct physical loss or damage caused by earthquake subject to the Coverage C (Personal Property) and Coverage D (Loss of Use) limits.",
                // Deductible
                "This deductible applies to each earthquake event. This deductible will apply separately to loss under Coverage C (Personal Property) and " +
                        "Building Additions and Alterations.");

        String allOtherCoveragesPrice;
        String totalPriceOnCard = getQuotePriceOnCard();
        Double dTotalPriceOnCard = convertCurrencyStringToDouble(totalPriceOnCard);
        List<String> additionalCoverages = getAdditionalCoverageNames(applicant.getStateCode());
        for (String coverageTitle : additionalCoverages) {
            String coveragePrice = EMPTY_STRING;
            if (!isOptionalCoverageSidesheetOpen()) {
                clickEditOptionalCoveragesLink();
            }
            Log.info(">> Validating Additional coverage: " + coverageTitle);
            fsa.assertTrue(isElementDisplayed(By.xpath(String.format(TOGGLE_BUTTON_XPATH, coverageTitle))),
                    "Ace Renters Additional Coverage page - coverage toggle: " + coverageTitle + " is displayed.");
            if (coverageTitle.equalsIgnoreCase("Watercraft liability - family protection")) {
                fsa.assertTrue(isOptionalCoverageToggleSelected(coverageTitle), "Optional coverage toggle (MN - Watercraft liability) is turned On by default.");
            }
            clickOptionalCoverageToggle(coverageTitle);
            if (!coverageTitle.equals(INCREASED_LIMITS_FOR_VALUABLES_TITLE)) {
                fsa.assertEquals(getOptionalCoverageText(coverageTitle), additionalCoveragesDescriptionMap.get(coverageTitle),
                        "Ace Renters Review quote page - optional coverage description text: " + coverageTitle + " is displayed.");
            }
            switch (coverageTitle) {
                case INCREASED_LIMITS_FOR_VALUABLES_TITLE:
                    // check Increased limits info side-sheet
                    fsa.assertEquals(getTextFromElement(headerIncreasedValuables), "Select which coverages to increase limits for*",
                            "Increased limits for certain valuables section header.");
                    fsa.assertEquals(getAttributeData(headerIncreasedValuablesInfoIcon, ARIA_LABEL), "info icon for Select which coverages to increase limits for*",
                            "Increased limits for certain valuables section header Info icon.");
                    fsa.assertEquals(getTextFromElement(headerIncreasedValuables), "Select which coverages to increase limits for*",
                            "Increased limits for certain valuables section header.");
                    // validating Info section side-sheet Content
                    waitAndClickElement(headerIncreasedValuablesInfoIcon);
                    fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogHeader), INCREASED_LIMITS_FOR_VALUABLES_INFO_TITLE, "Increased limits for valuables info section title");
                    fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogMainContent), INCREASED_LIMITS_FOR_VALUABLES_INFO_TEXT,
                            "Increased limits for valuables info section text main content");
                    fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogSubtitle), INCREASED_LIMITS_FOR_VALUABLES_INFO_SUBTITLE,
                            "Increased limits for valuables info section sub-title");
                    int i = 0;
                    for (String infoPoint : INCREASED_LIMITS_FOR_VALUABLES_INFO_ITEMS) {
                        fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogPoints.get(i)), infoPoint,
                                "Increased limits for valuables info section items - item: " + i);
                        i++;
                    }
                    waitAndClickElement(increasedValuablesInfoDialogCloseButton);
                    break;
                case LIMITED_MOLD:
                    if (isElementVisible(yearBuiltInputLimitedMold, 2)) {
                        waitAndClickElement(yearBuiltInputLimitedMold);
                        sendKeysToElement(yearBuiltInputLimitedMold, applicant.getYearBuilt());
                    }
                    break;
                case EARTHQUAKE:
                    List<String> sectionHeaders = List.of("Deductible", "Is the structure attached to the foundation?",
                            "Does the foundation include any of the following:");
                    fsa.assertEquals(headersEarthquakeSection.stream().map(this::getTextFromElement).collect(Collectors.toList()), sectionHeaders,
                            "Earthquake section headers.");
                    fsa.assertEquals(radioButtonsEarthquake.size(), 4, "Earthquake section number of radio-buttons.");
                    List<String> listFoundatioms = List.of("Elevated post/pier and beam (stilts)", "Stilts with sweep-away walls, or", "Deep pilings");
                    fsa.assertEquals(listFoundationsEarthquakeSection.stream().map(this::getTextFromElement).collect(Collectors.toList()), listFoundatioms,
                            "Earthquake section list foundations.");
                    List<String> sectionToggleButtons = List.of(YES, NO, YES, NO);
                    fsa.assertEquals(toggleButtonsEarthquake.stream().map(this::getTextFromElement).collect(Collectors.toList()), sectionToggleButtons,
                            "Earthquake section toggle buttons.");
                    i = 0;
                    for (WebElement matRadio : radioButtonsEarthquake) {
                        fsa.assertEquals(getTextFromElement(matRadio), EARTHQUAKE_RADIO_TEXT.get(i),
                                "Earthquake section radio button: " + (i + 1)+ " text.");
                        i++;
                    }
                    fsa.assertEquals(getTextFromElement(earthquakeYearBuiltLabel), "Year built", "Earthquake section - Year built input label");
                    //
                    String infoIconText = "info icon for Deductible";
                    fsa.assertEquals(getAttributeData(earthquakeInfoIcon, ARIA_LABEL), infoIconText, "Earthquake section info icon.");
                    waitAndClickElement(earthquakeInfoIcon);
                    waitElementBeVisible(earthquakeCoverageInfoDialogHeader,3);
                    fsa.assertEquals(getTextFromElement(earthquakeCoverageInfoDialogHeader), "Earthquake coverage", "Earthquake info dialog side-sheet header.");
                    List<String> infoDialogSubheaders = List.of("Coverage", "Deductible");
                    fsa.assertEquals(earthquakeInfoDialogSubheaders.stream().map(this::getTextFromElement).collect(Collectors.toList()), infoDialogSubheaders,
                            "Earthquake info dialog sub-headers.");
                    fsa.assertEquals(earthquakeInfoDialogParagraphs.stream().map(this::getTextFromElement).collect(Collectors.toList()),
                            EARTHQUAKE_INFO_DIALOG_PARAGRAPHS, "Earthquake info dialog paragraphs text content.");
                    waitAndClickElement(closeEarthquakeInfoSidesheetButton);
                    //
                    waitAndClickElement(radioButtonsEarthquakeLabels.get(0)); // Deductible = 10%
                    waitAndClickElement(toggleButtonsEarthquake.get(0)); // Attached to the foundation = Yes
                    waitAndClickElement(toggleButtonsEarthquake.get(3)); // Does the foundation includes any = No
                    waitAndClickElement(yearBuiltInputEarthquake);
                    sendKeysToElement(yearBuiltInputEarthquake, applicant.getYearBuilt());
                    break;
                case INCREASED_LIMITS_FOR_LIMITED_MOLD:
                    if (isElementVisible(yearBuiltInputIncreasedLimitsForLimitedMold, 2)) {
                        waitAndClickElement(yearBuiltInputIncreasedLimitsForLimitedMold);
                        sendKeysToElement(yearBuiltInputIncreasedLimitsForLimitedMold, applicant.getYearBuilt());
                    }
                    break;
                case WATERCRAFT_LIABILITY_FAMILY_PROTECTION:
                    String DIALOG_CONTENT = "In your state, this coverage is automatically included in your quote. Unselecting this option " +
                            "will deduct $2.00 from your Package price. If you choose to decline this coverage, you must sign and return " +
                            "the Declination of Family Protection Liability Coverage form.";
                    fsa.assertEquals(getTextFromElement(watercraftCoverageDialogTitle), coverageTitle, "Additional coverage toggle (MN) confirmation dialog title");
                    fsa.assertEquals(getTextFromElement(watercraftCoverageDialogContent), DIALOG_CONTENT, "Additional coverage toggle (MN) confirmation dialog content");
                    waitAndClickElement(buttonOk);
                    fsa.assertTrue(isOptionalCoverageToggleSelected(coverageTitle), "Optional coverage toggle (MN - Watercraft liability) has to remain On if Ok is clicked.");
                    clickOptionalCoverageToggle(coverageTitle);
                    waitAndClickElement(buttonRemoveCoverage);
                    fsa.assertFalse(isOptionalCoverageToggleSelected(coverageTitle), "Optional coverage toggle (MN - Watercraft liability) has to be Off if Remove button is clicked.");
                    String paymentMode = getSessionStorageAppStore().getHome().getQuote().getSelectedPaymentMode();
                    coveragePrice = paymentMode.equals("PIF") ? "$-2/year" : "$-0.17/month";
                    break;
            }
            List<String> pageErrors = getPageErrors();
            if (!pageErrors.isEmpty()) {
                Log.error("Found error(s) on the page before recalculate.");
                for (String errorMsg : pageErrors) {
                    Log.error("Found error message: " + errorMsg);
                }
            }
            if (!coverageTitle.equalsIgnoreCase(WATERCRAFT_LIABILITY_FAMILY_PROTECTION)) {
                coveragePrice = getOptionalCoveragePrice(coverageTitle);
            }
            double dCoveragePrice;
            if (!coveragePrice.isEmpty()) {
                coveragePrice = coveragePrice.split("/")[0]; // removing /month or /year from the price
                dCoveragePrice = !coveragePrice.startsWith("$-") ? convertCurrencyStringToDouble(coveragePrice) : -convertCurrencyStringToDouble(coveragePrice);
                clickRecalculateButtonCondoRentersInSideSheet();
                waitForSpinnerToBeGone();
                fsa.assertEquals(convertCurrencyStringToDouble(getAllOtherCoveragesPriceOnCard()), dCoveragePrice, .01d,
                        "Ace Renters Review quote page - coverage price: " + coverageTitle + " is correctly displayed on card.");
                fsa.assertEquals(convertCurrencyStringToDouble(getQuotePriceOnCard().split("/")[0]),
                        Math.round((dTotalPriceOnCard + dCoveragePrice) * 100.0)/100.0, .02d, "Ace Renters Review quote page - toggle: "
                                + coverageTitle + " Total price on Presentment card is within expected delta=.02");
            } else {
                clickRecalculateButtonCondoRentersInSideSheet();
                waitForSpinnerToBeGone();
                fsa.assertTrue(convertCurrencyStringToDouble(getQuotePriceOnCard().split("/")[0]) >= dTotalPriceOnCard,
                        "Ace Renters Review quote page - toggle: " + coverageTitle + " Total price on Presentment card is more or equal to the one without it.");
            }
            allOtherCoveragesPrice = getAllOtherCoveragesPriceOnCard();
            clickEditOptionalCoveragesLink();
            String coveragePrice2 = getOptionalCoveragePrice(coverageTitle);
            if (!coveragePrice2.isBlank()) {
                coveragePrice2 = coveragePrice2.split("/")[0]; // removing /month or /year from the price
                Double dCoveragePrice2 = convertCurrencyStringToDouble(coveragePrice2);
                fsa.assertEquals(dCoveragePrice2, convertCurrencyStringToDouble(allOtherCoveragesPrice),
                        "Ace Renters Review quote page - toggle: " + coverageTitle + " price on Presentment card and in Sidesheet match.");
            }
            Log.info(">> Removing Additional coverage: " + coverageTitle);
            clickOptionalCoverageToggle(coverageTitle);
        }
        if (isOptionalCoverageSidesheetOpen()) {
            clickRecalculateButtonCondoRentersInSideSheet();
            waitForSpinnerToBeGone();
        }
    }

    private List<String> getAdditionalCoverageNames(String stateCode) {
        List<String> additionalCoverages = new ArrayList<>(ADDITIONAL_COVERAGES_TITLES);
        switch (stateCode) {
            case AR:
                additionalCoverages.remove(LIMITED_MOLD);
                additionalCoverages.add(EARTHQUAKE);
                break;
            case GA:
                additionalCoverages.add(INCREASED_LIMITS_FOR_LIMITED_MOLD);
                additionalCoverages.remove(LIMITED_MOLD);
                break;
            case MD:
                additionalCoverages.add(CHILD_CARE_LIABILITY);
                break;
            case MN:
                additionalCoverages.add(WATERCRAFT_LIABILITY_FAMILY_PROTECTION);
                break;
            case VA:
                additionalCoverages.add(SEWER_AND_DRAIN);
                break;
            case MI:
            case WA:
            case CT:
                additionalCoverages.remove(LIMITED_MOLD);
                break;
            case LA:
            case MA:
            case MS:
                additionalCoverages.remove(LIMITED_MOLD);
                additionalCoverages.remove(IDENTITY_SHIELD);
                break;
            case NC:
                additionalCoverages.remove(LIMITED_MOLD);
                additionalCoverages.remove(IDENTITY_SHIELD);
                additionalCoverages.add(IDENTITY_FRAUD);
                break;
        }
        return getSortedList(additionalCoverages);
    }

    public double getPremiumAmountFromQuotePresentmentCard(){
        return convertCurrencyStringToDouble(getQuotePriceOnCard());
    }

    public void validateDefaultDeductibleAmount(FarmersSoftAssert fsa, ApplicantAceHome applicant, String scenarioText){
        if (STATE_WITH_500_DEFAULT_DEDUCTIBLE.contains(applicant.getStateCode())) {
            String defaultDeductibleAmount = getDeductibleAmountFromWebElement();
            fsa.assertEquals(defaultDeductibleAmount, "$500", "Validating default deductible amount " + scenarioText);
        }
    }

    // F89863 - Loss of Use coverage defaults to 20% of CovC value for VA, CT, NC and 10% for all other states
    public void validateLossOfUseCoverageAmountOnMainScreen(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception {
        String lossOfUseCovAmount = getCoveragePriceByNameFromScreen(LOSS_OF_USE_TEXT).replaceAll(" .*$", EMPTY_STRING); // replacing anything after 1st space with Empty string to get real price
        double defaultCoverageAmount = convertCurrencyStringToDouble(lossOfUseCovAmount);
        double coverageLimit = convertCurrencyStringToDouble(getCoveragePriceByNameFromScreen(PERSONAL_PROPERTY_LIMIT));
        double tolerance = 0.01; // Acceptable delta for comparison
        if(!isTwentyPerLossOfUseStateRenters(applicant.getStateCode())){
            fsa.assertEquals(defaultCoverageAmount, coverageLimit * 0.1, tolerance, "Validating default coverage amount - " + LOSS_OF_USE);
        } else {
            fsa.assertEquals(defaultCoverageAmount, coverageLimit * 0.2, tolerance, "Validating default coverage amount - " + LOSS_OF_USE);
        }
    }
}

