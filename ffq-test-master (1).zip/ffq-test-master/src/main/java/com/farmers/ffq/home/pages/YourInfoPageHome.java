package com.farmers.ffq.home.pages;


import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.ApplicantHome;
import com.farmers.ffq.datatransferobjects.SqlAddress;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import com.farmers.framework.soapui.SoapUI;

import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.*;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOfElementLocated;


/**
 * Farmers Fast Quote (FFQ) - Your Info Page - Home.
 */

public class YourInfoPageHome extends BasePage {
	private static final String ACTIVE = "A";
	private static final String CANCELED = "C";
	private static final String AUTO_POLICIES = "p631:autoPolicies";
	private static final String HOME_POLICIES = "p631:homePolicies";

	private static final String ADD_HOME_PROP_YEAR_BUILT = "AddHome:propYearBuilt";
	private static final String ADDRESS_SHOULD_CONTAIN_NAME_AND_NUMBER = "Residential Address should include both a Street Number and a Street Name.";
	private static final String CHECK_EXISTING_CUSTOMER = "checkExistingCustomer";
	private static final String NAV_BAR_ITEM_VERIFICATION = "Navigation bar item verification ";
	private static final String IS_A_REQUIRED_FIELD = " is a required field";
	private static final String IS_A_REQUIRED_FIELD_PERIOD = IS_A_REQUIRED_FIELD + PERIOD;
	private static final String SINGLE_NUMBER_STRING = "4";
	private static final String DOB_ERROR_MSG = "Date of birth is a required field.";
	private static final String DOB_RANGE_ERROR_MSG = "Online quotes are only available for applicants between the age of 18 and 108.";

	private static final String FIRSTNAME_LABEL = "First Name";
	private static final String LASTNAME_LABEL = "Last Name";
	private static final String DOB_LABEL = "Date of birth";
	private static final String OCCUPATION_LABEL = "Occupation";
	private static final String MARITAL_SATUS_LABEL = "Marital Status";
	private static final String SPOUSE_FIRSTNAME_LABEL = "Spouse First Name";
	private static final String SPOUSE_LASTNAME_LABEL = "Spouse Last Name";
	private static final String SPOUSE_DOB_LABEL = "Spouse date of birth";
	private static final String SPOUSE_OCCUPATION_LABEL = "Spouse Occupation";
	private static final String ADDRESS_LABEL = "Street address";
	private static final String CITY_LABEL = "City";
	private static final String MAILING_ADDRESS_LABEL = "Address";
	private static final String STATE_LABEL = "State";
	private static final String MAILING_ZIPCODE_LABEL = "Mailing zip code";

	private static final String WAIT_SPINNER_XPATH = "//mat-spinner";

	@FindBy(id = "preapp:FirstName")
	protected WebElement firstNameTextBox;

	@FindBy(id = "FFQHome_Yourinfo_firstName")
	protected WebElement firstNameTextBoxRedesigned;

	@FindBy(id = "FirstNameError")
	private WebElement firstNameTextBoxErrorMsg;

	@FindBy(id = "preapp:LastName")
	private WebElement lastNameTextBox;

	@FindBy(id = "FFQHome_Yourinfo_lastName")
	private WebElement lastNameTextBoxRedesigned;

	@FindBy(id = "LastNameError")
	private WebElement lastNameTextBoxErrorMsg;

	@FindBy(id = "preapp:datepicker")
	private WebElement dateOfBirthTextBox;

	@FindBy(id = "FFQHome_Yourinfo_Dob")
	private WebElement dateOfBirthTextBoxRedesigned;

	@FindBy(id = "datepickerError")
	private WebElement dateOfBirthTextBoxErrorMsg;

	@FindBy(id = "preapp:maritalStatus")
	public WebElement maritalStatusDropDown;

	@FindBy(id = "maritalStatusError")
	public WebElement maritalStatusDropDownErrorMsg;

	@FindBy(id = "preapp:StreetAddress")
	private WebElement addressTextBox;

	@FindBy(id = "FFQHome_Yourinfo_ResedentialAddress")
	private WebElement addressTextBoxRedesigned;

	@FindBy(id = "StreetAddressError")
	private WebElement addressTextBoxErrorMsg;

	@FindBy(id = "preapp:apartment")
	private WebElement apartmentTextBox;

	@FindBy(id = "preapp:City")
	private WebElement cityTextBox;

	@FindBy(id = "FFQHome_Yourinfo_City")
	private WebElement cityTextBoxRedesigned;

	@FindBy(id = "CityError")
	private WebElement cityTextBoxErrorMsg;

	@FindBy(id = "preapp:ZipCode")
	private WebElement zipCodeTextBox;

	@FindBy(id = "FFQHome_Yourinfo_Zipcode")
	private WebElement zipCodeTextBoxRedesigned;

	@FindBy(id = "ZipCodeError")
	private WebElement zipCodeErrorMsg;

	@FindBy(id = "txtMailingZipError")
	private WebElement txtMailingZipErrorMsg;

	@FindBy(id = "FFQHome_Yourinfo_Zipcode")
	private WebElement zipCodeTextBoxFLState;

	@FindBy(id = "preapp:propType")
	public WebElement propertyTypeDropDown;

	private static final String START_QUOTE_BUTTON_ID = "preapp:donexttbuttonid";
	@FindBy(id = START_QUOTE_BUTTON_ID)
	public WebElement startQuoteButton;

	@FindBy(id = "preapp:chkMailingAdd")
	private List<WebElement> mailingAddressDifferentCheckBox;

	@FindBy(id = "preapp:txtMailingStreet")
	private WebElement mailingAddressTextBox;

	@FindBy(id = "txtMailingStreetError")
	private WebElement txtMailingStreetErrorMsg;

	@FindBy(id = "preapp:txtMailCity")
	private WebElement mailingCityTextBox;

	@FindBy(id = "txtMailCityError")
	private WebElement txtMailCityErrorMsg;

	@FindBy(id = "preapp:txtMailState")
	private WebElement mailingStateDropDown;

	@FindBy(id = "preapp:txtMailingZip")
	private WebElement mailingZipCodeTextBox;

	@FindBy(id = "preapp:SpouseFirstName")
	private WebElement spouseFirstNameTextBox;

	@FindBy(id = "SpouseFirstNameError")
	private WebElement spouseFirstNameTextBoxErrorMsg;

	@FindBy(id = "preapp:SpouseLastName")
	private WebElement spouseLastNameTextBox;

	@FindBy(id = "SpouseLastNameError")
	private WebElement spouseLastNameTextBoxErrorMsg;

	@FindBy(id = "preapp:spouseDatepicker")
	private WebElement spouseDateOfBirthTextBox;

	@FindBy(id = "spouseDatepickerError")
	private WebElement spouseDateOfBirthTextBoxErrorMsg;

	@FindBy(xpath = "//*[@id='fsphConsentAcrossAffiliate']/div[4]/button[1]")
	private WebElement consumeReportPopUpYesButton;

	@FindBy(xpath = "//*[@id='fsphConsentAcrossAffiliate']/div[4]/button[2]")
	private WebElement consumeReportPopUpNoButton;

	@FindBy(id = "fsphConsentAcrossAffiliate")
	private WebElement consumeReportPopUp;

	@FindBy(id = "preapp:State1")
	private WebElement stateTextBox;

	@FindBy(id = "FFQHome_Yourinfo_State")
	private WebElement stateTextBoxFLState;

	@FindBy(css = ".ToolErrorText1")
	private WebElement retrieveFirstNameMissingInputMessage;

	@FindBy(css = ".ToolErrorText1")
	private WebElement retrieveFirstNameInvalidInputMessage;

	@FindBy(id = "toolTipadd")
	public WebElement toolTipElement;

	@FindBy(xpath = "//*[@id='toolTipadd']/span/span[2]")
	public WebElement toolTipText;

	@FindBy(id = "preapp:creditReportDisLbl")
	public List<WebElement> creditReportNotification;

	@FindBy(id = "preapp:lblMailingAddress")
	public WebElement mailingAddressCheckBoxText;

	@FindBy(xpath = "//*[@id='MailingCheck']")
	public WebElement mailingAddressCheckBox;

	@FindBy(xpath = "//*[@id='zipCodeChange:states']/input")
	public WebElement zipCodePopUpOKButton;

	@FindBy(id = "zipCodeChange:statess")
	public WebElement zipCodePopUpCloseButton;

	@FindBy(xpath = "//*[@id='jsAlert99_popupBody']/div/div[2]/h2")
	private List<WebElement> attentionHomeOwnersPopUp;

	@FindBy(xpath = "//button[@title = 'Continue']")
	private WebElement homeOwnContinueBtn;

	@FindBy(xpath = "//button[@title = 'Cancel']")
	private WebElement homeOwnCancelBtn;

	@FindBy(xpath = "//*[@id='hasBasicInfo']/h4")
	private WebElement willLoveFarmersStaticText;

	@FindBy(xpath = "//*[@id='hasBasicInfo']/ul/li[1]")
	private WebElement personalServiceStaticText;

	@FindBy(xpath = "//*[@id='hasBasicInfo']/ul/li[2]")
	private WebElement helpPointStaticText;

	@FindBy(xpath = "//*[@id='hasBasicInfo']/ul/li[3]")
	private WebElement dozenDiscountsStaticText;

	@FindBy(xpath = "//div[@id='summaryAgentInfoBuy']/div[@class='Mon']/h3[@class='farmersAgent']")
	private WebElement yourFarmersAgentStaticText;

	@FindBy(xpath = "//*[@id='existingCustForm']/div/div[2]/div/h2")
	private WebElement exsistingCustomerTitleText;

	@FindBy(xpath = "//*[@id='existingCustForm']/div/div[3]/div/p[1]")
	private WebElement exsistingCustomerBodyText;

	@FindBy(xpath = "//*[@id='existingCustForm']/div/div[3]/div/p[2]")
	private WebElement exsistingCustomerBodyText2;

	@FindBy(xpath = "//*[@id='existingCustForm']/div/div[1]")
	private WebElement exsistingCustomerFormDismissBtn;

	@FindBy(id = "image4")
	private WebElement exsistingCustomerFormOKBtn;

	@FindBy(id = "preapp:propOccupation")
	private WebElement occupationDropDown;

	@FindBy(id = "propOccupationError")
	private WebElement occupationDropDownErrorMsg;

	@FindBy(id = "preapp:spouseOccupation")
	private WebElement spouseOccupationDropDown;

	@FindBy(id = "spouseOccupationError")
	private WebElement spouseOccupationDropDownErrorMsg;

	@FindBy(xpath = "//*[@id='preapp:propType']/tbody/tr/td[1]/label")
	private WebElement propertyTypeHouseRadioBtn;

	@FindBy(xpath = "//*[@id='preapp:propType']/tbody/tr/td[2]/label")
	private WebElement propertyTypeTownHouseRadioBtn;

	@FindBy(css = "#bgWhite")
	private WebElement blankSpace;

	@FindBy(id = "preapp:propCityMtpl")
	private List<WebElement> cityDropDown;

	@FindBy(id = "preapp:FirstNameLbl")
	private WebElement firstNameLbl;

	@FindBy(id = "preapp:LastNameLbl")
	private WebElement lastNameLbl;

	@FindBy(id = "preapp:dateOfBirthLbl")
	private WebElement dateOfBirthLbl;

	@FindBy(id = "preapp:propOccupationLbl")
	private WebElement propOccupationLbl;

	@FindBy(id = "preapp:maritalStatusLbl")
	private WebElement maritalStatusLbl;

	@FindBy(id = "preapp:StreetAddressLbl")
	private WebElement addressLbl;

	@FindBy(id = "preapp:SrtApartmentLbl")
	private WebElement apartmentLbl;

	@FindBy(id = "preapp:CityLbl")
	private WebElement cityLbl;

	@FindBy(id = "preapp:StateLbl")
	private WebElement stateLbl;

	@FindBy(id = "preapp:ZipCodeLbl")
	private WebElement zipCodeLbl;

	@FindBy(xpath = "//label[@for='preapp:propType:0']")
	private WebElement propTypeHouseLbl;

	@FindBy(xpath = "//label[@for='preapp:propType:1']")
	private WebElement propTypeTownHouseLbl;

	@FindBy(id = "preapp:SrtApartmentLbl")
	private WebElement srtApartmentLbl;

	@FindBy(xpath = "//*[@id='preapp:progress:1:basic']/span[2]")
	private WebElement propertyNavBarText;

	@FindBy(xpath = "//*[@id='preapp:progress:2:basic']/span[2]")
	protected WebElement coverageNavBarText;

	@FindBy(xpath = "//*[@id='preapp:progress:3:basic']/span[2]")
	private WebElement quoteNavBarText;

	@FindBy(xpath = "//span[@id='preapp:progress:0:basic']//span[@title='Step 1: Your Info'][contains(text(),'Your Info')]")
	private WebElement yourInfoNavBarText;

	@FindBy(id = "pbMenuPlaceHolder")
	private WebElement blueNavBar;

	@FindBy(id = "HeaderLogo")
	private WebElement headerLogo;

	@FindBy(xpath = "//*[@id='Intropreapp']/h1")
	private WebElement tellAboutYourselfText;

	@FindBy(xpath = "//*[@id='Intropreapp']/p")
	private WebElement toProvideYouSubTitleText;

	@FindBy(id = "txtMailingStreetError")
	private WebElement txtMailingStreetError;

	@FindBy(id = "txtMailCityError")
	private WebElement txtMailCityError;

	@FindBy(id = "txtMailStateError")
	private WebElement txtMailStateError;

	@FindBy(id = "txtMailingZipError")
	private WebElement txtMailingZipError;

	@FindBy(id = "occQ")
	private WebElement occupationToolTip;

	@FindBy(xpath = "//*[@id='occupation-popup']/div/input")
	private WebElement occupationToolTipCloseBtn;

	@FindBy(css = ".AddPopup>p")
	private WebElement occupationToolTipText;

	@FindBy(id = "toolTipadd")
	private WebElement addressToolTip;

	@FindBy(xpath = "//*[@id='resAddPopup']/input")
	private WebElement addressToolTipCloseBtn;

	@FindBy(xpath = "//*[@id='resAddPopup']/p")
	private WebElement addressToolTipText;

	@FindBy(xpath = "//*[@id='Background']/input[3]")
	private WebElement summaryBtn;

	@FindBy(xpath = "//div[@id='pbMenuPlaceHolder']//div[@id='pbMenu']//div[@id='pbTitleMobile']//span[@id='pbCarat']")
	private WebElement cartBtn;

	@FindBy(xpath = "//div[@id='ContainerNew']//div[@id='pbTitleMobile']//span[@id='pbActiveStep']")
	private WebElement blueNavBarStep1of4Text;

	@FindBy(xpath = "//*[@id='pbMenuPlaceHolder']")
	private WebElement blueNavBarSmall;

	@FindBy(id = "summaryquoteSmall")
	private WebElement summaryquoteSmall;

	@FindBy(xpath = "//*[@id='summaryAgentInfoBuy']/div[2]/h3")
	private WebElement summaryYourFarmersAgentStaticText;

	@FindBy(xpath = "//div[@id='summaryLB']//form[@id='agentForm1']//div[@id='NoAgentInfo']")
	private WebElement summaryAgentNearYouStaticText;

	@FindBy(xpath = "//*[@id='#summaryPopup']/div[1]/h1")
	private WebElement summaryTitleStaticText;

	@FindBy(id = "summaryCloseBtn")
	private WebElement summaryCloseBtn;

	@FindBy(xpath = "//*[@id='preapp:progress:0:basic']")
	private WebElement step1Text;

	@FindBy(xpath = "//*[@id='preapp:progress:1:basic']")
	private WebElement step2Text;

	@FindBy(xpath = "//*[@id='preapp:progress:2:basic']")
	private WebElement step3Text;

	@FindBy(xpath = "//*[@id='preapp:progress:3:basic']")
	private WebElement step4Text;

	@FindBy(id = "FirstNameError")
	private WebElement firstNameError;

	@FindBy(id = "LastNameError")
	private WebElement lastNameError;

	private static final String HQM_ELEMENT_XPATH = "//*[@data-gtm]";
	@FindBy(xpath = HQM_ELEMENT_XPATH)
	private WebElement hqmElement;

	private List<String> homePolicyTypeCode;
	private List<String> condoPolicyTypeCode;
	private List<String> rentersPolicyTypeCode;
	private String exiCustomerResponse;

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public YourInfoPageHome() throws Exception {
		super();
	}

	/**
	 * Enter first name.
	 *
	 * @param name
	 */
	private void enterFirstName(String name) {
		enterValueInField(name, firstNameTextBox, "Entering First Name: ");
	}

	/**
	 * Enter last name.
	 *
	 * @param lastName
	 */
	private void enterLastName(String lastName) {
		enterValueInField(lastName, lastNameTextBox, "Entering Last Name: ");
	}

	/**
	 * Enter Date of Birth.
	 *
	 * @param age
	 */
	private void enterDateOfBirth(int age, WebElement dateOfBirthTextField) {
		Log.info("Entering Date of Birth based on age of: " + age);
		enterDateOfBirth(calculateDateOfBirthFromAge(age), dateOfBirthTextField);
	}

	private void enterDateOfBirth(String dob, WebElement dateOfBirthTextField) {
		Log.info("Entering Date of Birth: " + dob);
		waitElementBeVisible(dateOfBirthTextField);
		// Weird browser issue where date field does not respond properly
		sendKeysToElement(dateOfBirthTextField, dob);
	}

	/**
	 * Enter Residential Address.
	 *
	 * @param address
	 */
	private void enterResidentialAddress(String address) {
		enterValueInField(address, addressTextBox, "Entering Residential Address: ");
	}

	private void enterApartmentNumber(String apartmentNumber) {
		enterValueInField(apartmentNumber, apartmentTextBox, "Entering apartment number: ");
	}

	/**
	 * Enter City.
	 *
	 * @param city
	 */
	private void enterCityName(String city) {
		enterValueInField(city, cityTextBox, "Entering City: ");
	}

	/**
	 * Select Marital Status.
	 *
	 * @param status
	 */
	public void selectMaritalStatus(String status) {
		Log.info("Selecting Marital Status: " + status);
		waitElementBeVisible(maritalStatusDropDown);
		selectFromDropDown(maritalStatusDropDown, status);
	}

	/**
	 * Select Property Type.
	 *
	 * @param propertyType
	 */
	private void selectPropertyType(String propertyType) {
		Log.info("Selecting Property Type: " + propertyType);
		waitElementBeVisible(propertyTypeHouseRadioBtn);
		switch (propertyType) {
		case HOUSE:
			waitAndClickElement(propertyTypeHouseRadioBtn);
			break;
		case TOWNHOUSE:
			waitAndClickElement(propertyTypeTownHouseRadioBtn);
			break;
		default:
			throw new IllegalArgumentException("Wrong property type argument " + propertyType);
		}
	}

	/**
	 * Click Start Quote Button.
	 */
	public void clickStartQuoteButton() {
		Log.info("Clicking Start Quote Button");
		clickElement(startQuoteButton);
	}

	/**
	 * Select Different Mailing Address Option.
	 */
	public void selectMailingAddressDifferentOption() {
		Log.info("Selecting Different Mailing Address Option");
		clickElement(mailingAddressDifferentCheckBox.get(0));
	}

	/**
	 * Enter Mailing Address And Apartment.
	 *
	 * @param address
	 */
	private void enterMailingAddressAndApartment(String address) {
		enterValueInField(address, mailingAddressTextBox, "Entering Mailing Address: ");
	}

	/**
	 * Enter Mailing Address City.
	 *
	 * @param city
	 */
	private void enterMailingAddressCity(String city) {
		enterValueInField(city, mailingCityTextBox, "Entering Mailing Address City: ");
	}

	/**
	 * Enter Mailing Address City.
	 *
	 * @param zip
	 */
	private void enterMailingAddressZip(String zip) {
		enterValueInField(zip, mailingZipCodeTextBox, "Entering Mailing Address Zip: ");
	}

	/**
	 * Select Mailing Address State.
	 *
	 * @param state
	 */
	private void selectMailingAddressState(String state) {
		Log.info("Selecting Mailing Address State: " + state);
		selectFromDropDown(mailingStateDropDown, state);
	}

	/**
	 * @return true if Credit check notification is displayed.
	 * @throws Exception
	 */
	public boolean isCreditCheckNotificationShown() {
		try {
			return !creditReportNotification.isEmpty();
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	/**
	 * @return true if Mailing address different checkbox is displayed.
	 * @throws Exception
	 */
	public boolean isMailingAddressDifferentCheckBoxDisplayed() {
		try {
			return getTextFromElement(mailingAddressCheckBoxText).contains("If mailing address differs from residence address")
					&& mailingAddressCheckBox.isDisplayed()
					&& mailingAddressCheckBox.isEnabled();
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	/**
	 * Enter Spouse First Name.
	 *
	 * @param name
	 */
	private void enterSpouseFirstName(String name) {
		enterValueInField(name, spouseFirstNameTextBox, "Entering Spouse First Name: ");
	}

	/**
	 * Enter Spouse Last Name.
	 *
	 * @param lastName
	 */
	private void enterSpouseLastName(String lastName) {
		enterValueInField(lastName, spouseLastNameTextBox, "Entering Spouse Last Name: ");
	}

	/**
	 * Select May we use the consumer report information?
	 *
	 * @param share
	 */
	public void selectShareConsumerReportInformationNotification(boolean share) {
		Log.info("Selecting May we use the consumer report information?: " + share);
		waitElementBeVisible(consumeReportPopUpNoButton);
		if (share) {
			clickElement(consumeReportPopUpYesButton);
		} else {
			clickElement(consumeReportPopUpNoButton);
		}
	}

	/**
	 * Get value from First Name text box.
	 */
	public String getFirstNameFromTextBox() {
		return getElementValue(firstNameTextBox, "First name: ");
	}

	/**
	 * Get value from Last Name text box.
	 */
	public String getLastNameFromTextBox() {
		return getElementValue(lastNameTextBox, "Last name: ");
	}

	/**
	 * Get value from Date Of Birth text box.
	 */
	public String getDateOfBirthFromTextBox() {
		return getElementValue(dateOfBirthTextBox, "Date of Birth: ");
	}

	/**
	 * Check if State text box is Disabled.
	 */
	public boolean isStateDisabled() {
		Log.info("Checking if State text box is Disabled");
		return !stateTextBox.isEnabled();
	}

	/**
	 * Get value from State text box.
	 */
	public String getStateNameValueFromTextBox() {
		return getElementValue(stateTextBox, "State: ");
	}

	/**
	 * Get value from State text box.
	 */
	public String getStateNameValueFromTextBoxFL() {
		return getElementValue(stateTextBoxFLState, "State: ");
	}

	/**
	 * Get value from Address/Apartment text box.
	 */
	public String getAddressApartmentFromTextBox() {
		return getElementValue(addressTextBox, "Address/Apt: ");
	}

	/**
	 * Get value from City text box.
	 */
	public String getCityFromTextBox() {
		return getElementValue(cityTextBox, "City: ");
	}

	/**
	 * Get value from Zip Code text box.
	 */
	public String getZipCodeFromTextBox() {
		return getElementValue(zipCodeTextBox, "Zip code: ");
	}

	/**
	 * Get value from Zip Code text box.
	 */
	public String getZipCodeFromTextBoxFL() {
		return getElementValue(zipCodeTextBoxFLState, "Zip code: ");
	}

	/**
	 * Get value from mailing Address/Apartment text box.
	 */
	public String getMailingAddressApartmentFromTextBox() {
		Log.info("Getting value from mailing Address/Apartment text box");
		return getElementValue(mailingAddressTextBox, "Mailing address: ");
	}

	/**
	 * Get value from mailing City text box.
	 */
	public String getMailingCityFromTextBox() {
		Log.info("Getting value from mailing City text box");
		return getElementValue(mailingCityTextBox, "Mailing city: ");
	}

	/**
	 * Get value from mailing Zip Code text box.
	 */
	public String getMailingZipCodeFromTextBox() {
		return getElementValue(mailingZipCodeTextBox, "Mailing zip code: ");
	}

	private String getMaritalStatus() {
		return getTextFromElement(new Select(maritalStatusDropDown).getFirstSelectedOption());
	}

	public boolean isMissingFieldMessageForFirstNameVisible() {
		Log.info("Verifying Missing Field Message for First Name Text Box");
		waitElementBeVisible(retrieveFirstNameMissingInputMessage);
		return getTextFromElement(retrieveFirstNameMissingInputMessage).contains("First Name\" is a required field.");
	}

	public boolean isInvalidFieldMessageForFirstNameVisible() {
		Log.info("Verifying Invalid Field Message for First Name Text Box");
		waitElementBeVisible(retrieveFirstNameInvalidInputMessage);
		return getTextFromElement(retrieveFirstNameInvalidInputMessage).contains("is not a valid entry.");
	}

	public void clearZipField() {
		Log.info("Clearing ZipCode Field");
		zipCodeTextBox.clear();
	}

	/**
	 * Get List with your info page Elements.
	 *
	 * @return List<WebElement>
	 */
	private LinkedHashMap<WebElement, WebElement> getMapWithYourInfoPageElements() {
		Log.info("Getting List with your info page Elements");
		LinkedHashMap<WebElement, WebElement> elements = new LinkedHashMap<>();
		elements.put(firstNameTextBox, firstNameTextBoxErrorMsg);
		elements.put(lastNameTextBox, lastNameTextBoxErrorMsg);
		elements.put(dateOfBirthTextBox, dateOfBirthTextBoxErrorMsg);
		elements.put(occupationDropDown, occupationDropDownErrorMsg);
		elements.put(maritalStatusDropDown, maritalStatusDropDownErrorMsg);
		elements.put(spouseFirstNameTextBox, spouseFirstNameTextBoxErrorMsg);
		elements.put(spouseLastNameTextBox, spouseLastNameTextBoxErrorMsg);
		elements.put(spouseDateOfBirthTextBox, spouseDateOfBirthTextBoxErrorMsg);
		elements.put(spouseOccupationDropDown, spouseOccupationDropDownErrorMsg);
		elements.put(addressTextBox, addressTextBoxErrorMsg);
		elements.put(cityTextBox, cityTextBoxErrorMsg);
		if (isMailingCheckBoxDisplayed()) {
			elements.put(mailingAddressCheckBox, txtMailingStreetError);
			elements.put(mailingCityTextBox, txtMailCityError);
			elements.put(mailingStateDropDown, txtMailStateError);
			elements.put(mailingZipCodeTextBox, txtMailingZipError);
		}
		return elements;
	}

	/**
	 * Get Map where Key is text box element and Value is error message associated with this text box.
	 *
	 * @return Map<WebElement, String>
	 */
	private LinkedHashMap<WebElement, List<String>> getMapWithErrorMessages() {
		Log.info("Getting Map with error messages");
		LinkedHashMap<WebElement, List<String>> errorMessages = new LinkedHashMap<>();
		errorMessages.put(firstNameTextBox, new ArrayList<>(Arrays.asList(FIRSTNAME_LABEL + IS_A_REQUIRED_FIELD, INVALID_ENTRY)));
		errorMessages.put(lastNameTextBox, new ArrayList<>(Arrays.asList(LASTNAME_LABEL + IS_A_REQUIRED_FIELD, INVALID_ENTRY)));
		errorMessages.put(dateOfBirthTextBox, new ArrayList<>(Arrays.asList(DOB_LABEL + IS_A_REQUIRED_FIELD_PERIOD, INVALID_ENTRY)));
		errorMessages.put(occupationDropDown, new ArrayList<>(Collections.singletonList(OCCUPATION_LABEL + IS_A_REQUIRED_FIELD_PERIOD)));
		errorMessages.put(maritalStatusDropDown, new ArrayList<>(Collections.singletonList(MARITAL_SATUS_LABEL + IS_A_REQUIRED_FIELD_PERIOD)));
		errorMessages.put(spouseFirstNameTextBox, new ArrayList<>(Arrays.asList(SPOUSE_FIRSTNAME_LABEL + IS_A_REQUIRED_FIELD_PERIOD, INVALID_ENTRY)));
		errorMessages.put(spouseLastNameTextBox, new ArrayList<>(Arrays.asList(SPOUSE_LASTNAME_LABEL + IS_A_REQUIRED_FIELD_PERIOD, INVALID_ENTRY)));
		errorMessages.put(spouseDateOfBirthTextBox, new ArrayList<>(Arrays.asList(SPOUSE_DOB_LABEL + IS_A_REQUIRED_FIELD_PERIOD, INVALID_ENTRY)));
		errorMessages.put(spouseOccupationDropDown, new ArrayList<>(Collections.singletonList(SPOUSE_OCCUPATION_LABEL + IS_A_REQUIRED_FIELD_PERIOD)));
		errorMessages.put(addressTextBox, new ArrayList<>(Arrays.asList("Residential " + ADDRESS_LABEL + IS_A_REQUIRED_FIELD_PERIOD, ADDRESS_SHOULD_CONTAIN_NAME_AND_NUMBER)));
		errorMessages.put(cityTextBox, new ArrayList<>(Arrays.asList(CITY_LABEL + IS_A_REQUIRED_FIELD_PERIOD, INVALID_ENTRY)));
		if (isMailingCheckBoxDisplayed()) {
			errorMessages.put(mailingAddressCheckBox, new ArrayList<>(Collections.singletonList(MAILING_ADDRESS_LABEL + IS_A_REQUIRED_FIELD_PERIOD)));
			errorMessages.put(mailingCityTextBox, new ArrayList<>(Collections.singletonList(CITY_LABEL + IS_A_REQUIRED_FIELD_PERIOD)));
			errorMessages.put(mailingStateDropDown, new ArrayList<>(Collections.singletonList(STATE_LABEL + IS_A_REQUIRED_FIELD_PERIOD)));
			errorMessages.put(mailingZipCodeTextBox, new ArrayList<>(Collections.singletonList(MAILING_ZIPCODE_LABEL + IS_A_REQUIRED_FIELD)));
		}
		return errorMessages;
	}

	/**
	 * Get Map with Your Info Tool Tips Elements.
	 *
	 * @return Map<WebElement, WebElement>
	 */
	private Map<WebElement, WebElement> getMapWithYourInfoToolTipsElements() {
		Log.info("Getting Map with Your Info Tool Tips Elements");
		Map<WebElement, WebElement> elements = new LinkedHashMap<>();
		elements.put(occupationToolTip, occupationToolTipCloseBtn);
		elements.put(addressToolTip, addressToolTipCloseBtn);
		return elements;
	}

	/**
	 * Get Map with Your Info Tool Tips Text.
	 *
	 * @return Map<WebElement, String>
	 */
	private Map<WebElement, LinkedHashMap<WebElement, String>> getMapWithToolTipsText() {
		Log.info("Getting Map with Your Info Page Tool Tips text");
		Map<WebElement, LinkedHashMap<WebElement, String>> mapToolTipsText = new LinkedHashMap<>();

		LinkedHashMap<WebElement, String> map = new LinkedHashMap<>();
		map.put(occupationToolTipText, "Farmers offers discounts for these professions. To qualify, please submit proper documentation when you purchase your policy.");

		LinkedHashMap<WebElement, String> map1 = new LinkedHashMap<>();
		map1.put(addressToolTipText, "Please provide the address where you\u2019d like to get a quote for home insurance.");

		mapToolTipsText.put(occupationToolTip, map);
		mapToolTipsText.put(addressToolTip, map1);
		return mapToolTipsText;
	}

	/**
	 * Get List with your info page Drop Downs Elements.
	 *
	 * @return A list of all Your Info page Drop Down {@link WebElement}s, or an empty list if nothing matches.
	 */
	public List<WebElement> getListWithYourInfoPageDropDownsElements() {
		Log.info("Getting List with your info page Drop Downs Elements");
		List<WebElement> elements = new ArrayList<>();
		elements.add(maritalStatusDropDown);
		return elements;
	}

	/**
	 * Get Map where Key is drop down element and Value is List of values associated with this drop down.
	 *
	 * @return A map of all Your Info page Drop Downs and their expected values.
	 */
	public Map<WebElement, List<String>> getMapWithDropDownsValues() {
		Log.info("Getting Map with drop downs values");
		Map<WebElement, List<String>> dropDownValues = new HashMap<>();
		dropDownValues.put(maritalStatusDropDown, new ArrayList<>(Arrays.asList(MARRIED, SEPARATED, SINGLE, WIDOWED, MARITAL_STATUS)));
		return dropDownValues;
	}

	private void enterZipCode(String zip) {
		Log.info("Entering Zip Code: " + zip);
		sendKeysToElement(zipCodeTextBox, zip);
	}

	private void verifyFirstAndLastNameTextFields(FarmersSoftAssert fsa) {
		enterFirstName(ALPHA_SPACE_HYPHEN); // input limited to 15 characters alphabets hyphen and space.
		fsa.assertEquals(getAttributeData(firstNameTextBox, VALUE).length(), 15, "First name text field acceptable length");
		enterFirstName(SPECIALCHARS_DIGITS); // input special characters and numbers ,space.
		fsa.assertEquals(getAttributeData(firstNameTextBox, VALUE).length(), 2, "First name text field special character and numerical values verifivation");

		enterLastName(ALPHA_SPACE_HYPHEN); // input limited to 20 characters alphabets hyphen and space.
		fsa.assertEquals(getAttributeData(lastNameTextBox, VALUE).length(), 20, "Last name text field acceptable length vefrification");
		enterLastName(SPECIALCHARS_DIGITS); // input special characters and numbers ,space.
		fsa.assertEquals(getAttributeData(lastNameTextBox, VALUE).length(), 2, "Last name text field special character and numerical values verification");

		enterFirstName(SINGLE_CHAR);
		clickStartQuoteButton();
		fsa.assertEquals(getTextFromElement(firstNameError), FIRSTNAME_LABEL + IS_A_REQUIRED_FIELD_PERIOD, "First name error message verification");
		sendKeysToElement(firstNameTextBox, EMPTY_STRING);

		enterLastName(SINGLE_CHAR);
		clickStartQuoteButton();
		fsa.assertEquals(getTextFromElement(lastNameError), LASTNAME_LABEL + IS_A_REQUIRED_FIELD, "Last name error message verification");
		sendKeysToElement(lastNameTextBox, EMPTY_STRING);
	}

	private void verifyDateOfBBirthField(FarmersSoftAssert fsa) {
		enterDateOfBirth(VALID_DOB, dateOfBirthTextBox); // input 8 numbers.
		fsa.assertEquals(getAttributeData(dateOfBirthTextBox, VALUE).length(), 10, "Date of birth acceptable length verification");
		enterDateOfBirth(SPECIALCHARS_ALPHA, dateOfBirthTextBox); // input special characters and numbers ,space.
		fsa.assertEquals(getAttributeData(dateOfBirthTextBox, VALUE).length(), 0, "Date of birth field acceptable input verification");
	}

	private void verifyAddressTextField(FarmersSoftAssert fsa) {
		enterResidentialAddress(ALPHA_SPACE_NUMERIC); // input limited to 42 characters alphabets hyphen and space and numbers.
		fsa.assertEquals(getAttributeData(addressTextBox, VALUE).length(), 42, "Address text field acceptable length vefrification");
		addressTextBox.clear();
		clickStartQuoteButton();
		enterResidentialAddress(SINGLE_CHAR);
		clickStartQuoteButton();
		clickStartQuoteButton();
		fsa.assertEquals(getTextFromElement(addressTextBoxErrorMsg), ADDRESS_SHOULD_CONTAIN_NAME_AND_NUMBER, "Address text field error message vefrification");
		addressTextBox.clear();
	}

	private void verifyCityTextField(FarmersSoftAssert fsa) {
		enterCityName(ALPHA); // input limited to 20 characters alphabets hyphen and space and numbers.
		fsa.assertEquals(getAttributeData(cityTextBox, VALUE).length(), 20, "Address text field acceptable length verification");
		enterCityName(SINGLE_CHAR);
		clickStartQuoteButton();
		clickStartQuoteButton();
		fsa.assertEquals(getTextFromElement(cityTextBoxErrorMsg), SINGLE_CHAR + INVALID_ENTRY_NO_PERIOD, "City text field error message verification");
		cityTextBox.clear();
	}

	private void verifyStateTextField(String applicantState, FarmersSoftAssert fsa) {
		fsa.assertEquals(getAttributeData(stateTextBox, VALUE).toLowerCase(), applicantState.toLowerCase(), "State text field text verification");
		fsa.assertTrue(!stateTextBox.isEnabled(), "State text field should be disabled");
	}

	private void verifyZipCodeTextField(String applicantZipCode, FarmersSoftAssert fsa) {
		fsa.assertEquals(applicantZipCode, getAttributeData(zipCodeTextBox, VALUE), "Zip code text field text verification");
		enterZipCode(SINGLE_NUMBER_STRING);
		clickStartQuoteButton();
		clickStartQuoteButton();
		fsa.assertEquals(getTextFromElement(zipCodeErrorMsg), SINGLE_NUMBER_STRING + " is a not valid entry.", "Zip code text field error message verification");
		sendKeysToElement(zipCodeTextBox, EMPTY_STRING);
	}

	private void verifyMailingAddressTextField(FarmersSoftAssert fsa) {
		enterMailingAddressAndApartment(ALPHA_SPACE_NUMERIC); // input limited to 42 characters.
		fsa.assertEquals(getAttributeData(mailingAddressTextBox, VALUE).length(), 42, "Mailing address acceptable length verification");
		enterMailingAddressAndApartment(ALPHA);
		clickStartQuoteButton();
		fsa.assertEquals(getTextFromElement(txtMailingStreetErrorMsg), ADDRESS_SHOULD_CONTAIN_NAME_AND_NUMBER, "Mailing address text field error message verification");
		sendKeysToElement(mailingAddressTextBox, EMPTY_STRING);
	}

	private void verifyMailingAddressCityTextField(FarmersSoftAssert fsa) {
		enterMailingAddressCity(ALPHA); // input limited to 20 numbers.
		fsa.assertEquals(getAttributeData(mailingCityTextBox, VALUE).length(), 20, "Mailing address city acceptable length verification");
		enterMailingAddressCity(SINGLE_CHAR);
		clickStartQuoteButton();
		fsa.assertEquals(getTextFromElement(txtMailCityErrorMsg), SINGLE_CHAR + INVALID_ENTRY_NO_PERIOD, "Mailing address city text field error message verification");
		sendKeysToElement(mailingCityTextBox, EMPTY_STRING);
	}

	private void verifyMailingZipCodeTextField(FarmersSoftAssert fsa) {
		enterMailingAddressZip(ALPHA); // input characters.
		fsa.assertEquals(getAttributeData(mailingZipCodeTextBox, VALUE).length(), 0, "Mailing address zip code text field should'n accept alpha characters");
		enterMailingAddressZip(SINGLE_NUMBER_STRING);
		clickStartQuoteButton();
		fsa.assertEquals(getTextFromElement(txtMailingZipErrorMsg), SINGLE_NUMBER_STRING + INVALID_ENTRY_NO_PERIOD, "Mailing Zip code text field error message verification");
		sendKeysToElement(mailingZipCodeTextBox, EMPTY_STRING);
	}

	private void verifyNavBarTitle(FarmersSoftAssert fsa) {
		waitElementBeVisible(yourInfoNavBarText);
		fsa.assertEquals(getTextFromElement(yourInfoNavBarText), "YOUR INFO", NAV_BAR_ITEM_VERIFICATION);
		fsa.assertEquals(getTextFromElement(propertyNavBarText), "PROPERTY", NAV_BAR_ITEM_VERIFICATION);
		fsa.assertEquals(getTextFromElement(coverageNavBarText), "COVERAGE", NAV_BAR_ITEM_VERIFICATION);
		fsa.assertEquals(getTextFromElement(quoteNavBarText), "QUOTE", NAV_BAR_ITEM_VERIFICATION);
		fsa.assertTrue(blueNavBar.isDisplayed(), "Blue navigation bar isn't displayed ");
		fsa.assertTrue(headerLogo.isDisplayed(), "Header logo not displayed");
		fsa.assertTrue(tellAboutYourselfText.isDisplayed(), "\"Tell us about yourself\" text not displayed");
		fsa.assertEquals(getTextFromElement(tellAboutYourselfText), "Tell us about yourself", "Header text verification");
		fsa.assertEquals(getTextFromElement(toProvideYouSubTitleText), "To provide you with an accurate quote, we need to ask you for some information.", "Sub header text verification");
	}

	private void verifyDateOfBirthFieldErrorMsg(FarmersSoftAssert fsa) {
		dateOfBirthTextBox.clear();
		clickStartQuoteButton();
		waitElementBeVisible(dateOfBirthTextBoxErrorMsg);
		fsa.assertEquals(getTextFromElement(dateOfBirthTextBoxErrorMsg), DOB_ERROR_MSG);
		enterDateOfBirth(110, dateOfBirthTextBox);
		clickStartQuoteButton();
		fsa.assertEquals(getTextFromElement(dateOfBirthTextBoxErrorMsg), DOB_RANGE_ERROR_MSG);
		enterDateOfBirth(25, dateOfBirthTextBox);
		clickStartQuoteButton();
		fsa.assertAll();
	}

	public void yourInfoPageValidationHome(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		waitForLegacySpinnerToBeGone();
		verifyAllToolTipsInPage(getMapWithYourInfoToolTipsElements(), getMapWithToolTipsText());
		verifyHomeHelpLinks(getListWithHomeLOBFooterLinks(), getListWithHomeLOBFooterURLDestinationsTitle());
		verifyFirstAndLastNameTextFields(fsa);
		verifyDateOfBBirthField(fsa);
		verifyAddressTextField(fsa);
		verifyCityTextField(fsa);
		verifyStateTextField(applicant.getState(), fsa);
		verifyZipCodeTextField(applicant.getZipCode(), fsa);
		if (isMailingCheckBoxDisplayed()) {
			selectMailingAddressDifferentOption();
			verifyMailingAddressTextField(fsa);
			verifyMailingAddressCityTextField(fsa);
			verifyMailingZipCodeTextField(fsa);
			selectMailingAddressDifferentOption();
		}
		verifyNavBarTitle(fsa);
		verifyDropDownListValues(getListWithYourInfoPageDropDownsElements(), getMapWithDropDownsValues(), fsa);
		checkAllURLsAndImages(findAllURLsAndImages());
	}

	public PropertyPage yourInfoPageErrorValidationHome(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		waitForLegacySpinnerToBeGone();
		clickStartQuoteButton();
		verifyIsMissingFieldsErrorMessagesVisible(getMapWithErrorMessages(), getMapWithYourInfoPageElements(), applicant);
		enterYourInfo(applicant);
		clearZipField();
		enterYourInfo(applicant);
		verifyDateOfBirthFieldErrorMsg(fsa);
		return new PropertyPage();
	}

	public List<WebElement> getListWithYourInfoPageElementsForInvalidInput() {
		Log.info("Getting List with your info page Elements");
		List<WebElement> elements = new ArrayList<>();
		elements.add(firstNameTextBox);
		elements.add(lastNameTextBox);
		elements.add(spouseFirstNameTextBox);
		elements.add(spouseLastNameTextBox);
		elements.add(spouseLastNameTextBox);
		elements.add(addressTextBox);
		elements.add(cityTextBox);
		elements.add(zipCodeTextBox);
		return elements;
	}

	public boolean isMailingCheckBoxDisplayed() {
		return !mailingAddressDifferentCheckBox.isEmpty();
	}

	private void verifyYourFarmersAgentStaticText(FarmersSoftAssert fsa) throws Exception {
		Log.info("Verifying \"Your Farmers Agent\" static text");
		waitElementBeVisible(firstNameTextBox);
		String pageSource = driver().getPageSource();
		fsa.assertTrue(getTextFromElement(yourFarmersAgentStaticText).contains("Your Farmers Agent:"), "\"Your Farmers Agent:\" text found in page");
		if (isElementPresent(By.xpath("//div[@id='summaryLB']//form[@id='agentForm1']//div[@id='NoAgentInfo']"), 5)) {
			fsa.assertTrue(pageSource.contains("There's a Farmers agent near you!"), "\"There's a Farmers agent near you!\" text found in page");
			fsa.assertTrue(pageSource.contains("Work with a knowledgeable, friendly insurance professional right in your neighborhood."),
					"\"Work with a knowledgeable, friendly insurance professional\" text found in page");
		}
	}

	private String checkExistingCustomer(ApplicantHome applicant) throws Exception {
		homePolicyTypeCode = new ArrayList<>(Arrays.asList("SPHO", "SPTH", "HO", "HOP", "NGHO", "DP3", "TFHP"));
		condoPolicyTypeCode = new ArrayList<>(Arrays.asList("CNDO", "CONB", "HO6", "CONR", "HO6R", "TC"));
		rentersPolicyTypeCode = new ArrayList<>(Arrays.asList("HOBT", "RENT", "RNRV", "TCR"));

		StringBuilder builder = new StringBuilder();
		TemporalAccessor temporal = DateTimeFormatter.ofPattern(MM_DD_YYYY).parse(calculateDateOfBirthFromAge(applicant.getAge()));
		String dateOfBirth = DateTimeFormatter.ofPattern("yyyy-MM-dd").format(temporal);
		JSONObject json;

		SoapUI.setProject("FFQHomeWebServices.xml");
		SoapUI.project().properties().setTestCaseProperty(CHECK_EXISTING_CUSTOMER, "dateOfBirth", dateOfBirth);
		SoapUI.project().properties().setTestCaseProperty(CHECK_EXISTING_CUSTOMER, "firstName", applicant.getFirstName());
		SoapUI.project().properties().setTestCaseProperty(CHECK_EXISTING_CUSTOMER, "lastName", applicant.getLastName());
		SoapUI.project().properties().setTestCaseProperty(CHECK_EXISTING_CUSTOMER, "zipCode", applicant.getZipCode());
		SoapUI.project().properties().displayTestCaseProperties();
		try {
			json = SoapUI.executeTestStep(CHECK_EXISTING_CUSTOMER, "retrieveExistingCustomer");
		} catch (Exception e) {
			Log.error("SoapUI call existing customer failed, " + e);
			return null;
		}
		JSONObject jsonEnvelop = (JSONObject) json.get("soapenv:Envelope");
		JSONObject jsonBody = (JSONObject) jsonEnvelop.get("soapenv:Body");
		JSONObject existingCustResp = (JSONObject) jsonBody.get("p631:retrieveInsurancePoliciesForPartyResponse");
		JSONObject transactionResponse = (JSONObject) existingCustResp.get("p631:transactionNotification");

		if (transactionResponse.has("p277:remark")) {
			JSONObject messageResponse = (JSONObject) transactionResponse.get("p277:remark");
			String transactionStatus = (String) transactionResponse.get("p277:transactionStatus");
			String messageText = (String) messageResponse.get("p277:messageText");
			if (messageText.equals(NO_MATCHES_FOUND) && transactionStatus.equals(SUCCESS)) {
				Log.info(String.format("Transaction status is: %s and response message is: %s", transactionStatus, messageText));
				return builder.append(messageText).toString();
			}
		} else {
			boolean responseHasAutoPolicies = existingCustResp.has(AUTO_POLICIES);
			boolean responseHasHomePolicies = existingCustResp.has(HOME_POLICIES);
			if (responseHasAutoPolicies && (existingCustResp.get(AUTO_POLICIES) instanceof JSONArray)) {
				JSONArray autoPolicies = existingCustResp.getJSONArray(AUTO_POLICIES);
				if (autoPolicies.length() > 0) {
					for (int i = 0; i < autoPolicies.length(); i++) {
						JSONObject autoPolicy = autoPolicies.getJSONObject(i);
						checkAndAddAutoPolicies(autoPolicy, builder);
					}
				} else {
					throw new Exception("Existing customer auto policies array is empty. Policies count is: " + autoPolicies.length());
				}
			} else if (responseHasAutoPolicies && (existingCustResp.get(AUTO_POLICIES) instanceof JSONObject)) {
				JSONObject autoPolicy = existingCustResp.getJSONObject(AUTO_POLICIES);
				checkAndAddAutoPolicies(autoPolicy, builder);
			}
			// Under Home policies considered also Condo, Renters LOB.
			if (responseHasHomePolicies && (existingCustResp.get(HOME_POLICIES) instanceof JSONArray)) {
				JSONArray policies = existingCustResp.getJSONArray(HOME_POLICIES);
				if (policies.length() > 0) {
					for (int i = 0; i < policies.length(); i++) {
						JSONObject policy = policies.getJSONObject(i);
						checkAndAddHomePolicies(policy, builder);
					}
				} else {
					throw new Exception("Existing customer home policies array is empty. Policies count is: " + policies.length());
				}
			} else if (responseHasHomePolicies && (existingCustResp.get(HOME_POLICIES) instanceof JSONObject)) {
				JSONObject policy = existingCustResp.getJSONObject(HOME_POLICIES);
				checkAndAddHomePolicies(policy, builder);
			}
		}
		return builder.toString();
	}

	private void checkAndAddHomePolicies(JSONObject policy, StringBuilder builder) {
		String policyStatus = (String) policy.get("p771:status");
		if (policyStatus.equals(ACTIVE)) {
			String productType = (String) policy.get("p771:productType");
			if (homePolicyTypeCode.contains(productType)) {
				builder.append(HOME + COMMA);
			} else if (rentersPolicyTypeCode.contains(productType)) {
				builder.append(RENTERS + COMMA);
			} else if (condoPolicyTypeCode.contains(productType)) {
				builder.append(CONDO + COMMA);
			}
		}
		if (policyStatus.equals(CANCELED)) {
			String productType = (String) policy.get("p771:productType");
			String cancellationDateString = (String) policy.get("p771:cancellationDate");
			LocalDate cancellationDate = LocalDate.parse(cancellationDateString);
			if (homePolicyTypeCode.contains(productType) && cancellationDate.isAfter(LocalDate.now())) {
				builder.append(HOME + COMMA);
			} else if (rentersPolicyTypeCode.contains(productType) && cancellationDate.isAfter(LocalDate.now())) {
				builder.append(RENTERS + COMMA);
			} else if (condoPolicyTypeCode.contains(productType) && cancellationDate.isAfter(LocalDate.now())) {
				builder.append(CONDO + COMMA);
			}
		}
	}

	private void checkAndAddAutoPolicies(JSONObject policy, StringBuilder builder) {
		JSONObject basicPolicy = (JSONObject) policy.get("p771:basicPolicy");
		String effectiveDateString = (String) policy.get("p771:effectiveDate");
		String policyStatus = (String) basicPolicy.get("p771:policyStatus");
		LocalDate effectiveDate = LocalDate.parse(effectiveDateString);
		if (policyStatus.equals(ACTIVE) || (policyStatus.equals(CANCELED) && effectiveDate.isAfter(LocalDate.now()))) {
			builder.append(AUTO + COMMA);
		}
	}

	/**
	 * Select Occupation.
	 *
	 * @param occupation
	 */
	private void selectOccupation(String occupation) {
		Log.info("Selecting Occupation: " + occupation);
		waitElementBeVisible(occupationDropDown);
		selectFromDropDown(occupationDropDown, occupation);
	}

	/**
	 * Select  Spouse Occupation.
	 *
	 * @param occupation
	 */
	private void selectSpouseOccupation(String occupation) {
		Log.info("Selecting Spouse  Occupation: " + occupation);
		waitElementBeVisible(spouseOccupationDropDown);
		selectFromDropDown(spouseOccupationDropDown, occupation);
	}

	private void verifyPageInSmallDimension(String applicantState, FarmersSoftAssert fsa) throws Exception {
		Log.info("Verifying page in dimension size: " + driver().manage().window().getSize());
		waitElementBeVisible(summaryBtn);
		fsa.assertTrue(summaryBtn.isDisplayed() && summaryBtn.isEnabled(), "Summary button is not displayed");
		waitAndClickElement(summaryBtn);
		waitElementBeVisible(summaryCloseBtn);
		fsa.assertTrue(getTextFromElement(summaryTitleStaticText).contains("SUMMARY"), "\"SUMMARY\" title text verification");
		fsa.assertTrue(getTextFromElement(summaryquoteSmall).contains("Home Insurance for " + applicantState), "Home Insurance for " + applicantState + " text verification");
		fsa.assertTrue(getTextFromElement(summaryAgentNearYouStaticText).contains("There's a Farmers agent near you!"), "There's a Farmers agent near you! text verification");
		clickElement(summaryCloseBtn);
		fsa.assertTrue(blueNavBarSmall.isDisplayed(), "Blue navigation bar is not displayed");
		fsa.assertTrue(getHiddenText(blueNavBarStep1of4Text).contains("Step 1 of 4: Your Info"), "Blue navigation bar doesn't contain text \"Step 1 of 4: Your Info\"");
		clickOnHiddenElement(cartBtn);
		waitElementBeVisible(step1Text);
		fsa.assertTrue(getTextFromElement(step1Text).contains("STEP 1: YOUR INFO"), "Blue navigation bar drop down  doesn't contain text \"STEP 1: YOUR INFO\"");
		fsa.assertTrue(getTextFromElement(step2Text).contains("STEP 2: PROPERTY"), "Blue navigation bar drop down  doesn't contain text \"STEP 2: PROPERTY\"");
		fsa.assertTrue(getTextFromElement(step3Text).contains("STEP 3: COVERAGE"), "Blue navigation bar drop down  doesn't contain text \"STEP 3: COVERAGE\"");
		fsa.assertTrue(getTextFromElement(step4Text).contains("STEP 4: QUOTE"), "Blue navigation bar drop down  doesn't contain text \"STEP 4: QUOTE\"");
		clickOnHiddenElement(cartBtn);
		fsa.assertTrue(headerLogo.isDisplayed(), "Header logo doesn't displayed ");
		fsa.assertTrue(tellAboutYourselfText.isDisplayed(), "\"Tell us about yourself\" text  doesn't displayed ");
		fsa.assertEquals(getTextFromElement(tellAboutYourselfText), "Tell us about yourself", "Header text verification ");
		fsa.assertEquals(getTextFromElement(toProvideYouSubTitleText), "To provide you with an accurate quote, we need to ask you for some information.", "Sub header text verification ");

		for (WebElement link : getListWithHomeLOBFooterLinks()) {
			fsa.assertTrue(link.isDisplayed() && link.isEnabled(), "Link is not displayed " + link);
		}
	}

	/**
	 * Add Applicant "Your Info" section. Handles every
	 * option and questions based on State.
	 *
	 * @param applicant
	 * @return Property Page
	 * @throws Exception
	 */
	public PropertyPage enterYourInfoAndContinue(ApplicantHome applicant, boolean waitForPropertyPage, FarmersSoftAssert fsa) throws Exception {
		waitForLegacySpinnerToBeGone();
		checkForGatewayError();
		waitElementBeVisible(startQuoteButton);
		if ((applicant.isBackSaveInPropPage() && findInCallStack(SAVE_AND_RETRIEVE_HOME_QUOTE))) {
			return validateYourInfoPageHomeAndContinue(applicant, fsa);
		} else {
			if (applicant.isExistingCustomerScenario()) {
				exiCustomerResponse = checkExistingCustomer(applicant);
			}
			if (applicant.isChangeBrowserDimensionScenario()) {
				verifyPageInSmallDimension(applicant.getState(), fsa);
				return null;
			} else if (!findInCallStack("apex")) {
				verifyYourFarmersAgentStaticText(fsa);
			}
		}
		enterYourInfo(applicant);
		clickStartQuoteButton();
		if (applicant.isExistingCustomerScenario() && (!exiCustomerResponse.equals(NO_MATCHES_FOUND) && exiCustomerResponse.contains(HOME))) {
			waitElementBeVisible(exsistingCustomerTitleText);
			for (String policy : exiCustomerResponse.split(COMMA)) {
				Log.info(String.format("Applicant has active %s policy", policy));
				fsa.assertTrue(getTextFromElement(exsistingCustomerTitleText).contains(policy), "Existing customer popup should display " + policy + " policy");

			}
			fsa.assertTrue(getTextFromElement(exsistingCustomerBodyText).contains("As an existing customer, we appreciate your business."), "Existing customer popup content");
			fsa.assertTrue(getTextFromElement(exsistingCustomerBodyText2).contains("Please contact your agent directly to make any changes or additions to your"), "Existing customer popup content");
			clickElement(exsistingCustomerFormDismissBtn);
			return null;
		}
		if (waitForPropertyPage) {
			waitForLegacySpinnerToBeGone();
			longWaitForElementToBeGoneByID(START_QUOTE_BUTTON_ID);
			checkForGatewayError();
			wait.until(visibilityOfElementLocated(By.id(ADD_HOME_PROP_YEAR_BUILT)));
		}
		return new PropertyPage();
	}

	private void checkForGatewayError() throws Exception {
		if (isElementPresent(By.xpath("//h1[text()='504 Gateway Time-out']"))) {
			Assert.fail("Gateway timeout error");
		}
	}

	private void enterYourInfo(ApplicantHome applicant) {
		enterFirstName(applicant.getFirstName());
		enterLastName(applicant.getLastName());
		enterDateOfBirth(applicant.getAge(), dateOfBirthTextBox);
		String applicantState = applicant.getState();
		selectOccupation(applicant.getOccupation());
		selectMaritalStatus(applicant.getMaritalStatus());
		String maritalStatus = applicant.getMaritalStatus();
		if (maritalStatus.equals(MARRIED) || maritalStatus.equals(CIVIL_UNION) || maritalStatus.equals(CIVIL_UNION_PARTNER)) {
			enterSpouseFirstName(applicant.getSpouseFirstName());
			enterSpouseLastName(applicant.getSpouseLastName());
			enterDateOfBirth(applicant.getSpouseAge(), spouseDateOfBirthTextBox);
			if (!applicantState.equals(NEW_YORK)) {
				selectSpouseOccupation(applicant.getSpouseOccupation());
			}
		}
		enterValueInField(applicant.getAddressApt(), addressTextBox, "Enter address");
		if (getCityFromTextBox().isBlank()) {
			enterCityName(applicant.getCity());
		}
		if (applicant.isMailingAddressDifferent() && isMailingCheckBoxDisplayed()) {
			selectMailingAddressDifferentOption();
			enterMailingAddressAndApartment(applicant.getMailingAddress());
			enterMailingAddressCity(applicant.getMailingCity());
			selectMailingAddressState(applicant.getMailingState());
			enterMailingAddressZip(applicant.getMailingZipCode());
		}
		if (applicant.isErrorScenario()) {
			enterZipCode(applicant.getZipCode());
		}
		selectPropertyType(applicant.getPropertyType());
	}

	public PropertyPage validateYourInfoPageHomeAndContinue(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		fsa.assertEquals(applicant.getApplicantRetQuote().getQuoteNumber(), getLegacyQuoteNumber(), "Quote number verification ");
		fsa.assertEquals(getFirstNameFromTextBox(), applicant.getFirstName(), FIRSTNAME_LABEL);
		fsa.assertEquals(getLastNameFromTextBox(), applicant.getLastName(), LASTNAME_LABEL);
		fsa.assertEquals(getAddressApartmentFromTextBox(), applicant.getAddressApt(), ADDRESS_LABEL);
		fsa.assertEquals(getMaritalStatus(), applicant.getMaritalStatus(), MARITAL_SATUS_LABEL);
		clickStartQuoteButton();
		longWaitForElementToBeGoneByXpath(WAIT_SPINNER_XPATH);
		Assert.assertTrue(noErrorsPresentInHomeQuote(), "No errors found on Your Info page");
		return new PropertyPage();
	}

	public PropertyPage enterYourInfoAndContinue(SqlAddress address) throws Exception {
		waitForLegacySpinnerToBeGone();
		enterFirstName(address.getFirstName());
		enterLastName(address.getLastName());
		enterDateOfBirth(address.getDateOfBirth(), dateOfBirthTextBox);
		selectOccupation(OTHER);
		selectMaritalStatus(address.getMaritalStatus());
		if (address.getMaritalStatus().equals(MARRIED)) {
			enterSpouseFirstName(address.getFirstName());
			enterSpouseLastName(address.getLastName());
			enterDateOfBirth(address.getDateOfBirth(), spouseDateOfBirthTextBox);
			selectSpouseOccupation(DENTIST);
		}
		enterResidentialAddress(address.getAddress1());
		enterApartmentNumber(address.getAddress2());
		enterCityName(address.getCity());
		if (address.isMailingAddressDifferent() && isMailingCheckBoxDisplayed()) {
			selectMailingAddressDifferentOption();
			enterMailingAddressAndApartment(address.getMailingAddress1() + (address.getMailingAddress2() != null ? SPACE + address.getMailingAddress2() : EMPTY_STRING));
			enterMailingAddressCity(address.getMailingCity());
			selectMailingAddressState(address.getMailingStateName());
			enterMailingAddressZip(address.getMailingZipCode());
		}
		selectPropertyType(address.getPropertyType());
		clickStartQuoteButton();
		wait.until(visibilityOfElementLocated(By.id(ADD_HOME_PROP_YEAR_BUILT)));
		return new PropertyPage();
	}

	public boolean onYourInfoPageHome() {
		waitForLegacySpinnerToBeGone();
		return isElementPresentByID(dateOfBirthTextBox);
	}

	public boolean isHQMInfoPage() {
		return isElementPresent(By.xpath(HQM_ELEMENT_XPATH), 15);
	}

	public void dismissMonetizationDialog() throws Exception {
		if (isElementPresent(By.xpath(CONTINUE_TO_DIGITAL_MONETIZATION_BUTTON_XPATH))) {
			waitAndClickElement(continueToDigitalMonetization);
			waitForLegacySpinnerToBeGone();
		}
	}

	public PropertyPage enterCrossSellYourInfoAndContinue(ApplicantHome applicant) throws Exception {
		waitForLegacySpinnerToBeGone();
		selectOccupation(applicant.getOccupation());
		selectPropertyType(applicant.getPropertyType());
		clickStartQuoteButton();
		wait.until(visibilityOfElementLocated(By.id(ADD_HOME_PROP_YEAR_BUILT)));
		return new PropertyPage();
	}

}
