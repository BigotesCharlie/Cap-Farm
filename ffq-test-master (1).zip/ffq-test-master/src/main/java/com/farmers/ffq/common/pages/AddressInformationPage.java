package com.farmers.ffq.common.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AddressInformationPage extends BasePage {
	@FindBy(className = "personal-info_address_h1")
	WebElement addressPageTitle;
	
	@FindBy(xpath = "//address-autocomplete-input//input")
	WebElement addressEntryField;
	
	@FindBy(xpath = "//address-autocomplete-input//mat-error")
	WebElement addressEntryFieldErrorLabel;
	
	@FindBy(xpath = "//div[@id='formField_apartment']//input")
	WebElement unitNumberEntryField;
	
	@FindBy(xpath = "//div[@id='formField_apartment']//mat-hint")
	WebElement unitNumberHintLabel;

	@FindBy(xpath = "//div[@id='formField_noOfPropertyLosses']//label")
	WebElement propertyLossesLabel;
	
	private static final String PROPERTY_LOSSES_GROUP_XPATH = "//mat-button-toggle-group[@id='noOfPropertyLosses']";
	protected static final String BUTTON_ONE = "/mat-button-toggle[1]/button";
	protected static final String BUTTON_TWO = "/mat-button-toggle[2]/button";
	protected static final String BUTTON_THREE = "/mat-button-toggle[3]/button";
	protected static final String XPATH_TO_BUTTON_LABEL = "/span[@class='mat-button-toggle-label-content']";

	private static final String TWO_OR_MORE = "Two or more";
	
	@FindBy(xpath = PROPERTY_LOSSES_GROUP_XPATH + BUTTON_ONE)
	WebElement noPropertyLossesButton;

	@FindBy(xpath = PROPERTY_LOSSES_GROUP_XPATH + BUTTON_ONE + XPATH_TO_BUTTON_LABEL)
	WebElement noPropertyLossesButtonLabel;

	@FindBy(xpath = PROPERTY_LOSSES_GROUP_XPATH + BUTTON_TWO)
	WebElement onePropertyLossButton;

	@FindBy(xpath = PROPERTY_LOSSES_GROUP_XPATH + BUTTON_TWO + XPATH_TO_BUTTON_LABEL)
	WebElement onePropertyLossButtonLabel;

	@FindBy(xpath = PROPERTY_LOSSES_GROUP_XPATH + BUTTON_THREE)
	WebElement twoOrMorePropertyLossesButton;

	@FindBy(xpath = PROPERTY_LOSSES_GROUP_XPATH + BUTTON_THREE + XPATH_TO_BUTTON_LABEL)
	WebElement twoOrMorePropertyLossesButtonLabel;

	@FindBy(xpath = "//div[contains(@class, 'disclaimer__credit-report')]")
	WebElement creditReportDisclaimer;
	
	@FindBy(xpath = "//div[contains(@class, 'disclaimer__color')]")
	WebElement ctaDisclaimer;
	
	@FindBy(xpath = "//p[contains(@class, 'multiple-fields-missing')]")
	WebElement requiredFieldsErrorLabel;
	
	@FindBy(xpath = "//div[@class='address-form__continue-button']/button")
	WebElement continueButton;
	
	public AddressInformationPage() throws Exception {
		super();
	}

	public boolean isOnAddressInformationPage() {
		return isElementPresent(By.xpath(PROPERTY_LOSSES_GROUP_XPATH), 3);
	}

	public String getAddressInformationPageTitle() {
		return getTextFromElement(addressPageTitle);
	}
	
	public String getPropertyLossesGroupLabel() {
		return getTextFromElement(propertyLossesLabel);
	}
	
	public List<String> getListOfPropertyLossesButtonLabelsText() {
		return new ArrayList<> (Arrays.asList(getTextFromElement(noPropertyLossesButtonLabel), getTextFromElement(onePropertyLossButtonLabel), getTextFromElement(twoOrMorePropertyLossesButtonLabel)));
	}

	public List<String> getListOfDisclaimerText() {
		return new ArrayList<> (Arrays.asList(getTextFromElement(creditReportDisclaimer), getTextFromElement(ctaDisclaimer)));
	}

	public List<String> getListOfErrorTexts() {
		return new ArrayList<> (Arrays.asList(getTextFromElement(addressEntryFieldErrorLabel), getTextFromElement(requiredFieldsErrorLabel)));
	}

	public void enterHomeAddresss(String address, String city) {
		enterGoogleAddress(addressEntryField, address, city);
	}

	public void enterInvalidHomeAddresss(String invalidAddress) {
		enterValueInField(invalidAddress, addressEntryField, "entering invalid address");
	}

	public void enterUnitNumber(String unitNumber) {
		enterValueInField(unitNumber, unitNumberEntryField, "Unit Number");
	}
	
	public void selectPropertyLosses(String numberOfPropertyLosses) {
		switch (numberOfPropertyLosses) {
		case ZERO: 
			scrollAndClickOnElement(noPropertyLossesButton);
			break;
		case ONE:
			scrollAndClickOnElement(onePropertyLossButton);
			break;
		case TWO_OR_MORE:
			scrollAndClickOnElement(twoOrMorePropertyLossesButton);
			break;
		default: 
			throw new IllegalArgumentException("Invalid number of property losses value: " + numberOfPropertyLosses);
		}
	}

	public void clickContinueButton() {
		scrollAndClickOnElement(continueButton);
	}

}
