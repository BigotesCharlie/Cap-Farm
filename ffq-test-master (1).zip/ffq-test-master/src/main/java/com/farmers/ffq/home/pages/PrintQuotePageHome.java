package com.farmers.ffq.home.pages;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.MONTHLY_AMOUNT_TEXT;
import static com.farmers.ffq.utils.GlobalVariables.QUOTE_DISCLAIMER_STATIC_TEXT2;
import static org.openqa.selenium.support.ui.ExpectedConditions.*;

public class PrintQuotePageHome extends BasePage {
    @FindBy(xpath = "//*[@id='Header']/h1")
    private WebElement printQuotePageHeaderText;

    @FindBy(xpath = "//*[@id='Header']/p[string-length(@class)=0]")
    private WebElement subHeaderContent;

    @FindBy(xpath = "//*[@id='Premium']/tr[2]/td")
    private WebElement premiumAmountPayInFull;

    @FindBy(xpath = "//*[@id='Premium']/tr[1]/td")
    private WebElement premiumAmountPayMonthly;

    @FindBy(xpath = "//th[@class='cover' and text()='Type']/../../../tbody/tr/td")
    private List<WebElement> discountList;

    @FindBy(xpath = "//table[@id='SummarySplit']/tbody[1]/tr/td/table/tbody/tr[not(contains(@style,'display:none'))]/td[1]")
    private List<WebElement> propertyCoveragesList;

    @FindBy(xpath = "//table[@id='SummarySplit']/tbody[1]/tr/td/table/tbody/tr[not(contains(@style,'display:none'))]/td[2]")
    private List<WebElement> propertyCoveragesLimitsList;

    @FindBy(xpath = "//*[@id='homeAlingn']/span/span")
    private List<WebElement> liabilityCoveragesList;

    @FindBy(xpath = "//*[@id='homesAlingn']/span")
    private List<WebElement> liabilityCoveragesLimitsList;

    @FindBy(xpath = "//td[@id='homeAlingn' and @class='Coverage' and not(descendant::span)]")
    private List<WebElement> policyFeaturesAndBenefitsList;

    @FindBy(xpath = "//div[@class='Disclaimer']")
    private WebElement disclamerText;

    private static final String DISPLAYED = "> displayed.";
    private static final String FARMERS_INSURANCE = "FARMERS INSURANCE\u00ae";
    
    /**
     * Constructor.
     *
     * @throws Exception
     */
    public PrintQuotePageHome() throws Exception {
        super();
    }

    private void verifyContentOfThePage() {
        wait.until(visibilityOf(printQuotePageHeaderText));
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(getTextFromElement(printQuotePageHeaderText).contains(FARMERS_INSURANCE), FARMERS_INSURANCE + " matches " + getTextFromElement(printQuotePageHeaderText));
        fsa.assertTrue(getTextFromElement(subHeaderContent).contains("for choosing Farmers. Below is a summary of your online Home insurance quote. Please refer to your quote number to purchase your quote online or purchase your policy with one of our friendly Farmers insurance agents."), "Print quote page sub header text doesn't match ");
        fsa.assertTrue(premiumAmountPayInFull.isDisplayed(), "Premium amount pay in full not displayed");
        fsa.assertTrue(premiumAmountPayMonthly.isDisplayed(), "Premium amount pay monthly not displayed");

        for (WebElement discount: discountList) {
        	String discountString = getTextFromElement(discount);
            fsa.assertTrue(discount.isDisplayed(), "Discount <" + discountString + DISPLAYED);
        }

        for (WebElement coverage: propertyCoveragesList) {
        	String coverageString = getTextFromElement(coverage);
            fsa.assertTrue(coverage.isDisplayed(), "Coverage <" + coverageString + DISPLAYED);
        }

        for (WebElement coverageLimit: propertyCoveragesLimitsList) {
        	String coverageLimitString = getTextFromElement(coverageLimit);
            fsa.assertTrue(coverageLimit.isDisplayed(), "Coverage limit <" + coverageLimitString + DISPLAYED);
        }

        for (WebElement liabilityCoverage: liabilityCoveragesList) {
        	String liabilityCoverageString = getTextFromElement(liabilityCoverage);
            fsa.assertTrue(liabilityCoverage.isDisplayed(), "Liability coverage <" + liabilityCoverageString + DISPLAYED);
        }

        for (WebElement liabilityCoverageLimit: liabilityCoveragesLimitsList) {
        	String liabilityCoverageLimitString = getTextFromElement(liabilityCoverageLimit);
            fsa.assertTrue(liabilityCoverageLimit.isDisplayed(), "Liability coverage limit <" + liabilityCoverageLimitString + DISPLAYED);
        }
        String disclaimerString = getTextFromElement(disclamerText);
        fsa.assertTrue(disclaimerString.contains(MONTHLY_AMOUNT_TEXT), "Disclaimer contains: " + MONTHLY_AMOUNT_TEXT);
        fsa.assertTrue(disclaimerString.contains(QUOTE_DISCLAIMER_STATIC_TEXT2), "Disclaimer contains: " +  QUOTE_DISCLAIMER_STATIC_TEXT2);
        fsa.assertAll();
    }

    protected void verifyPrintQuotePage() {
        Log.info("Verifying print quote page...");
        verifyContentOfThePage();
    }
}
