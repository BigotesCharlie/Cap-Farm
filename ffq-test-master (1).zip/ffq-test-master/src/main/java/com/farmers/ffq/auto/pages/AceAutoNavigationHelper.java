package com.farmers.ffq.auto.pages;

import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.auto.pages.bw.BwPaymentSummaryPage;
import com.farmers.ffq.common.pages.BristolWestLandingPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.common.pages.PaymentSelectionBasePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;

import lombok.Getter;
import lombok.Setter;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.SkipException;

import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Setter
@Getter
public class AceAutoNavigationHelper extends AutoBasePage {
    private static final String FOR_QUOTE = " for quote ";
    private static final String DID_NOT_REACH = "Did not reach ";
    private static final String NAVIGATED_TO = "Navigated to ";

    public enum quoteFlow {DEFAULT, AGENT, BDQ, SPECIAL, UNIONPLUS}

    private quoteFlow flowType;
    private String aceAutoQuoteNumber;
    private String resumeFromPage = EMPTY_STRING;
    private boolean isProgressbarChecked = false;
    private boolean isPhoneNumberChecked = false;
    private boolean removeQualtricsPopup = true;
    private String quoteDetails = EMPTY_STRING;
    private boolean checkForPagesEnabled = false;

    @FindBy(xpath = "//mat-progress-bar")
    private WebElement progressbarAceAuto;
    private FarmersSoftAssert fsa = new FarmersSoftAssert();

    // override the default resumeFromPage so we can set the boolean too
    public void setResumeFromPage(String pageToResumeNavigationFrom) {
		resumeFromPage = pageToResumeNavigationFrom;
		checkForPagesEnabled = true;
	}

    /**
     * No-arg constructor – flow type is left unspecified (null).
     * The actual flow (DEFAULT, AGENT, BDQ …) will be auto-detected
     * in {@link #processLandingPage} based on state and configuration.
     *
     * @throws Exception
     */
    public AceAutoNavigationHelper() throws Exception {
        this((quoteFlow) null);
    }

    /**
     * Constructor with explicit flow type.
     *
     * <p>Flow resolution priority:
     * <ol>
     *   <li>BDQ system config is enabled → always uses {@code BDQ}, regardless of the requested flow.</li>
     *   <li>Caller explicitly requests {@code BDQ} → enables BDQ mode.</li>
     *   <li>Caller explicitly requests {@code AGENT} → uses AGENT flow.</li>
     *   <li>Otherwise → defaults to {@code DEFAULT} flow.</li>
     * </ol>
     *
     * Pass {@code null} (or use the no-arg constructor) to request auto-detection in
     * {@link #processLandingPage}.
     *
     * @param flow the desired quote flow, or {@code null} for auto-detect
     * @throws Exception
     */
    public AceAutoNavigationHelper(quoteFlow flow) throws Exception {
        super();
        if (isBDQFlowEnabled()) {
            // BDQ is a system-level override; it takes precedence over any caller-requested flow
            setFlowType(quoteFlow.BDQ);
        } else if (quoteFlow.BDQ == flow) {
            setBDQEnabled(true);
            setFlowType(quoteFlow.BDQ);
        } else if (quoteFlow.AGENT == flow) {
            setFlowType(quoteFlow.AGENT);
        } else if (quoteFlow.UNIONPLUS == flow) {
            setFlowType(quoteFlow.UNIONPLUS);
        } else {
            setFlowType(quoteFlow.DEFAULT);
        }
    }

    private String getQuoteNumberFromStorage() throws Exception {
        String quoteNumber = EMPTY_STRING;
        if (getItemFromSessionStorage("appStore") != null) {
            quoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
            if (quoteNumber == null) {
                quoteNumber = EMPTY_STRING;
            }
        }
        return quoteNumber;
    }

    public void processLandingPage(AutoApplicant applicant) throws Exception {
        // Auto-detect only when the flow was NOT explicitly set by the caller (null = unspecified).
        // If the caller passed a concrete flow value (DEFAULT, AGENT, SPECIAL …) it is always honoured.
        if (getFlowType() == null) {
            if (isBDQFlowEnabled()) {
                setFlowType(quoteFlow.BDQ);
            } else if (isAgentFlowState(applicant.getStateCode())) {
                if (applicant.getTestScenario().contains("FGS")) {
                    setFlowType(quoteFlow.DEFAULT);
                } else {
                    setFlowType(quoteFlow.AGENT);
                    applicant.setTestScenario("Agent Flow =>" + applicant.getTestScenario());
                }
            } else {
                setFlowType(quoteFlow.DEFAULT);
            }
        }
        Reporter.pass("Launching Ace Auto application in " + getFlowType() + " mode");
        switch (getFlowType()) {
            case DEFAULT:
                new LandingPage(isUseMobileViewEnabled(), true).enterLandingPageData(LOB_AUTO, applicant.getZipCode());
                break;
            case AGENT:
                new LandingPage(applicant);
                break;
            case BDQ:
            case UNIONPLUS:
            	String testScenario = applicant.getTestScenario();
                if (!testScenario.startsWith("UNION") && (testScenario.startsWith("BW ->") || !testScenario.startsWith("BW"))) {
                    List<String> listOfTestScenarios = new ArrayList<>(Arrays.asList(BW_ORGANIC_FLOW, BW_CLICK_TO_BUY_FULL_FLOW, BW_CLICK_TO_BUY_LITE_FLOW, BW_MARKETING_ID_FLOW));
                    if (!listOfTestScenarios.stream().anyMatch(each -> applicant.getTestScenario().contains(each))) {
                        applicant.setTestScenario(BW_ORGANIC_FLOW);
                    }
                }
                openBDQStartingPage(applicant.getTestScenario(), applicant.getZipCode(), applicant.getStateCode());
                break;
			default:
				break;
        }
        setCheckForPagesEnabled(true);
        waitForSpinnerToBeGone();
    }

    public void processLandingPage(ADPFApplicant adpfApplicant) throws Exception {
        // Auto-detect only when the flow was NOT explicitly set by the caller (null = unspecified).
        if (getFlowType() == null) {
            if (isBDQFlowEnabled()) {
                setFlowType(quoteFlow.BDQ);
            } else if (isAgentFlowState(adpfApplicant.getStateCode())) {
                setFlowType(quoteFlow.AGENT);
            } else {
                setFlowType(quoteFlow.DEFAULT);
            }
        }

        Reporter.pass("Launching Ace Auto application in " + getFlowType() + " mode");
        switch (getFlowType()) {
            case DEFAULT:
                new LandingPage(isUseMobileViewEnabled(), true).enterLandingPageData(LOB_AUTO, adpfApplicant.getZipCode());
                break;
            case AGENT:
                new LandingPage(adpfApplicant);
                break;
            case BDQ:
                List<String> listOfTestScenarios = new ArrayList<>(Arrays.asList(BW_ORGANIC_FLOW, BW_CLICK_TO_BUY_LITE_FLOW, BW_MARKETING_ID_FLOW));
                Collections.shuffle(listOfTestScenarios);
                openBDQStartingPage(listOfTestScenarios.get(FIRST_AVAILABLE_OPTION), adpfApplicant.getZipCode(), adpfApplicant.getStateCode());
                break;
			default:
				break;
        }
        setCheckForPagesEnabled(true);
        waitForSpinnerToBeGone();
    }

    private boolean isAgentFlowState(String stateCode) {
        boolean agentFlowState = Arrays.asList(CT, NC, NV, NY, PA, MO, CO, NE, WA).contains(stateCode);
        if (agentFlowState) {
            Log.info("State Code for agent flow -> " + stateCode);
        }
        return agentFlowState;
    }

    private void openBDQStartingPage(String testScenario, String zipCode, String applicantStateCode) throws Exception {
        String bdqUrl = EMPTY_STRING;
        String navigationMessage = EMPTY_STRING;
        if (testScenario.startsWith("UNION")) {
            bdqUrl = String.format(Property.getUri().replace("fastquote", "quote") + "?Source_Indicator=BW&Zip=%s&Lob=APV&SRC=DJ7&showView=default", zipCode);
            navigationMessage = "Union Plus url used";
        } else {
        	setBDQEnabled(true);
        	AutoDataProviders autoDataProviders = new AutoDataProviders();
        	List<BDQFlowData> bdqData = autoDataProviders.getBdqData();
        	BDQFlowData stateSpecificBdqData = bdqData.stream().filter(each -> each.getStateAbb().strip().equals(applicantStateCode.strip())).collect(Collectors.toList()).get(0);
        	boolean usingSaucelabs = Property.getTestProperty("remote").equals("saucelabs");
        	if (!usingSaucelabs) {
        		driver().manage().window().setSize(new Dimension(1920, 1080));
        	} else if (isUseMobileViewEnabled()) {
        		setBrowserDimensionToMobileBreakPoint();
        	}
        	if (testScenario.contains(BW_ORGANIC_FLOW)) {
        		if (isRA11Environment() && !usingSaucelabs) {
        			new BristolWestLandingPage().launchBristolWestLandingPage("https://newdev.bristolwest.com", zipCode);
        		} else {
        			bdqUrl = String.format(Property.getUri().replace("fastquote", "quote") + "?Source_Indicator=BW&Lob=Auto&SRC=BW000000001&zip=%s", zipCode);
        		}
        		navigationMessage = BW_ORGANIC_FLOW;
        	} else if (testScenario.contains(BW_CLICK_TO_BUY_LITE_FLOW)) {
        		bdqUrl = Property.getUri().replace("fastquote", "quote") + "/?Source_Indicator=BDQI&Zip=" + zipCode + "&Lob=Auto&SRC=C2BL&showView=default&AOR=" + stateSpecificBdqData.getStateCode() + "99999&DsplayPhn=&Agent_Name=Swat%20Team";
        		navigationMessage = BW_CLICK_TO_BUY_LITE_FLOW;
        	} else if (testScenario.contains(BW_CLICK_TO_BUY_FULL_FLOW)) {
        		bdqUrl = stateSpecificBdqData.getBdqFullUrl();
        		navigationMessage = BW_CLICK_TO_BUY_FULL_FLOW;
        		if (isMA11Environment()) {
        			bdqUrl = bdqUrl.replace("ffqautouiuat", "ffqautouiqa");
        		}
        	} else if (testScenario.contains(BW_MARKETING_ID_FLOW)) {
        		bdqUrl = Property.getUri().replace("fastquote", "quote") + "?Source_Indicator=BW&Zip=" + zipCode + "&Lob=Auto&SRC=PERAAAAAAAA";
        		navigationMessage = BW_MARKETING_ID_FLOW;
        	} else {
        		throw new IllegalStateException("Please make sure to pass an expected test scenario: " + testScenario);
        	}
        }
        if (!bdqUrl.isBlank()) {
            driver().navigate().to(bdqUrl);
        } else {
            bdqUrl = "https://newdev.bristolwest.com";
        }
        setCheckForPagesEnabled(true);
        setAceAutoQuoteNumber(getQuoteNumberFromStorage());
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        if (nameAndDobPage.isOnNameAndDobPage() && nameAndDobPage.isOnBristolWest()) {
            Reporter.pass((isBDQFlowEnabled()? "BDQ url for " : EMPTY_STRING) + navigationMessage + ": " + bdqUrl);
        } else {
            throw new IllegalStateException(DID_NOT_REACH + nameAndDobPage.getClass().getSimpleName() + " in Bristol West" + FOR_QUOTE + getAceAutoQuoteNumber() + NEWLINE);
        }
    }

    public CurrentlyInsuredPage navigateToCurrentlyInsuredPage(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario("FGS " + applicant.getTestScenario());
        processLandingPage(applicant);
        CurrentlyInsuredPage currentlyInsuredPage = new CurrentlyInsuredPage();
        if (isRedState(applicant)) {
            System.out.println("Applicant is from Red States : ");
        }
        if (currentlyInsuredPage.isOnCurrentlyInsuredPage()) {
            Reporter.pass(NAVIGATED_TO + "Currently Insured page");
            return currentlyInsuredPage;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + currentlyInsuredPage.getClass().getSimpleName() + NEWLINE);
        }
    }

    private NameAndDobPage navigateToNameAndDobPage(ADPFApplicant adpfApplicant) throws Exception {
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        if (isCheckForPagesEnabled() && nameAndDobPage.isOnNameAndDobPage()) {
            return nameAndDobPage;
        }
        processLandingPage(adpfApplicant);
        InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
        if ((adpfApplicant.getStateCode().equals(CA) && !getFlowType().equals(quoteFlow.AGENT)) || interstitialBundlePage.isOnInterstitialBundlePage()) {
            interstitialBundlePage.continueWithAutoMonoLine();
        }
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnGetAQuoteFromBristolWestPage()) {
            //FL always displays BW dialog, so click on Continue to BW and resume normal flow
            continueWithBristolWestPage.continueWithBWPage(true);
            waitForSpinnerToBeGone();
        }
        nameAndDobPage.waitForNameAndDobPageToRender();
        setAceAutoQuoteNumber(getQuoteNumberFromStorage());
        if (nameAndDobPage.isOnNameAndDobPage()) {
            setQuoteDetails(getAceAutoQuoteNumber() + SPACE + adpfApplicant);
            writeCreatedQuoteInformationToFile("Ace Auto: " + getQuoteDetails());
            Reporter.pass(NAVIGATED_TO + "Name and DOB page" + FOR_QUOTE + getAceAutoQuoteNumber());
            return nameAndDobPage;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + nameAndDobPage.getClass().getSimpleName() + FOR_QUOTE + getAceAutoQuoteNumber() + NEWLINE);
        }
    }

    public NameAndDobPage navigateToNameAndDobPage(AutoApplicant applicant) throws Exception {
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
        if (isCheckForPagesEnabled() && interstitialBundlePage.isOnInterstitialBundlePage()) {
            interstitialBundlePage.continueWithAutoMonoLine();
        }
        if (isCheckForPagesEnabled() && nameAndDobPage.isOnNameAndDobPage()) {
            return nameAndDobPage;
        }
        processLandingPage(applicant);
        if (isADATestingEnabled()) {
            performADATesting(nameAndDobPage.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
        }
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnGetAQuoteFromBristolWestPage()) {
            applicant.setTestScenario("BW -> " + applicant.getTestScenario());
            //FL always displays BW dialog, so click on Continue to BW and resume normal flow
            continueWithBristolWestPage.continueWithBWPage(true);
            waitForSpinnerToBeGone();
        }
        if ((!getFlowType().equals(quoteFlow.AGENT) && applicant.getStateCode().equals(CA)) || interstitialBundlePage.isOnInterstitialBundlePage()) {
            interstitialBundlePage.continueWithAutoMonoLine();
        }
        nameAndDobPage.waitForNameAndDobPageToRender();
        setAceAutoQuoteNumber(getQuoteNumberFromStorage());
        if (nameAndDobPage.isOnNameAndDobPage()) {
            setQuoteDetails(getAceAutoQuoteNumber() + SPACE + applicant.getDetails());
            writeCreatedQuoteInformationToFile("Ace Auto: " + getQuoteDetails());
            Reporter.pass(NAVIGATED_TO + "Name and DOB page" + FOR_QUOTE + getAceAutoQuoteNumber());
            if (isProgressbarChecked()) {
                validateProgressbarStatus(nameAndDobPage.getClass().getSimpleName(), progressbarAceAuto, fsa);
            }
            if (isPhoneNumberChecked()) {
            	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT), nameAndDobPage.getClass().getSimpleName(), fsa);
            }
            return nameAndDobPage;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + nameAndDobPage.getClass().getSimpleName() + FOR_QUOTE + getAceAutoQuoteNumber() + NEWLINE);
        }
    }

    public AutoEnterAddressPage navigateToAutoEnterAddressPage(AutoApplicant applicant) throws Exception {
        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        if (isCheckForPagesEnabled() && (getResumeFromPage().equals(autoEnterAddressPage.getClass().getSimpleName()) || autoEnterAddressPage.isOnEnterAddressPage())) {
            return autoEnterAddressPage;
        } else {
            NameAndDobPage nameAndDobPage = navigateToNameAndDobPage(applicant);
            nameAndDobPage.filloutApplicantForm(applicant);
            waitForSpinnerToBeGone();
            if (autoEnterAddressPage.isOnEnterAddressPage()) {
                Reporter.pass(NAVIGATED_TO + "Enter Addresss page");
                if (isProgressbarChecked()) {
                    validateProgressbarStatus(autoEnterAddressPage.getClass().getSimpleName(), progressbarAceAuto, fsa);
                }
                if (isPhoneNumberChecked()) {
                	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT), autoEnterAddressPage.getClass().getSimpleName(), fsa);
                }
               return autoEnterAddressPage;
            } else {
                throw new IllegalStateException(DID_NOT_REACH + autoEnterAddressPage.getClass().getSimpleName() + NEWLINE);
            }
        }
    }

    private AutoEnterAddressPage navigateToAutoEnterAddressPage(ADPFApplicant adpfApplicant) throws Exception {
        NameAndDobPage nameAndDobPage = navigateToNameAndDobPage(adpfApplicant);
        nameAndDobPage.filloutApplicantFormWithValues(adpfApplicant.getFirstName(), adpfApplicant.getLastName(), adpfApplicant.getDateOfBirth());
        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        if (autoEnterAddressPage.isOnEnterAddressPage()) {
            Reporter.pass(NAVIGATED_TO + "Enter Addresss page");
            if (isProgressbarChecked()) {
                validateProgressbarStatus(autoEnterAddressPage.getClass().getSimpleName(), progressbarAceAuto, fsa);
            }
            if (isPhoneNumberChecked()) {
            	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT), autoEnterAddressPage.getClass().getSimpleName(), fsa);
            }
            return autoEnterAddressPage;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + autoEnterAddressPage.getClass().getSimpleName() + NEWLINE);
        }
    }

    public AutoRecentMoverPage navigateToAutoRecentMoverPage(ADPFApplicant adpfApplicant) throws Exception {
        AutoEnterAddressPage autoEnterAddressPage = navigateToAutoEnterAddressPage(adpfApplicant);
        autoEnterAddressPage.fillOutAddressPage(adpfApplicant);
        waitForSpinnerToBeGone();
        InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
        if (interstitialBundlePage.isOnInterstitialBundlePage()) {
            interstitialBundlePage.continueWithAutoMonoLine();
        }
        return new AutoRecentMoverPage();
    }

    public OneMomentPage navigateToOneMomentPage(AutoApplicant applicant) throws Exception {
        navigateToAutoEnterAddressPage(applicant).fillOutAddressPage(applicant);
        ContinueWithBristolWestPage continueWithBristolWestPage=new ContinueWithBristolWestPage();
        if(continueWithBristolWestPage.isOnGetAQuoteFromBristolWestPage()){
            continueWithBristolWestPage.continueWithBWPage(true);
            waitForSpinnerToBeGone();
        }
        InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
        if (interstitialBundlePage.isOnInterstitialBundlePage()) {
            interstitialBundlePage.continueWithAutoMonoLine();
        }
        OneMomentPage oneMomentPage = new OneMomentPage();
        if (oneMomentPage.isOnOneMomentPage()) {
            Reporter.pass(NAVIGATED_TO + "One moment page");
            if (isProgressbarChecked()) {
                validateProgressbarStatus(oneMomentPage.getClass().getSimpleName(), progressbarAceAuto, fsa);
            }
        }
        return oneMomentPage;
    }

    public AutoBasePage navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(AutoApplicant applicant) throws Exception {
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
        if (isCheckForPagesEnabled()) {
        	if (getResumeFromPage().equals(whoShouldWeInsurePage.getClass().getSimpleName()) || whoShouldWeInsurePage.isOnWhoShouldWeInsurePage()) {
        		return whoShouldWeInsurePage;
        	} else if (getResumeFromPage().equals(heresWhatWeFoundPage.getClass().getSimpleName()) || heresWhatWeFoundPage.isOnHeresWhatWeFoundPageShort()) {
        		return heresWhatWeFoundPage;
        	}
        }
        navigateToOneMomentPage(applicant);
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnGetAQuoteFromBristolWestPage()) {
            continueWithBristolWestPage.continueWithBWPage(true);
        }

        if (whoShouldWeInsurePage.isOnWhoShouldWeInsurePage()) {
            Reporter.pass(NAVIGATED_TO + "Who should we insure page");
            if (isProgressbarChecked()) {
                validateProgressbarStatus(whoShouldWeInsurePage.getClass().getSimpleName(), progressbarAceAuto, fsa);
            }
            if (isPhoneNumberChecked()) {
            	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT), whoShouldWeInsurePage.getClass().getSimpleName(), fsa);
            }
            return whoShouldWeInsurePage;
        } else if (heresWhatWeFoundPage.isOnHeresWhatWeFoundPageShort()) {
            Reporter.pass(NAVIGATED_TO + "Here's what we found page");
            if (isProgressbarChecked()) {
                if (isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
                    validateProgressbarStatus("VehiclesDriversInfoPage", progressbarAceAuto, fsa);
                } else {
                    validateProgressbarStatus(heresWhatWeFoundPage.getClass().getSimpleName(), progressbarAceAuto, fsa);
                }
            }
            if (isPhoneNumberChecked()) {
            	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT), heresWhatWeFoundPage.getClass().getSimpleName(), fsa);
            }
           return heresWhatWeFoundPage;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + whoShouldWeInsurePage.getClass().getSimpleName() + " or " + heresWhatWeFoundPage.getClass().getSimpleName());
        }
    }

    public HeresWhatWeFoundPage navigateToHeresWhatWeFoundPage(ADPFApplicant adpfApplicant) throws Exception {
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
        if (getResumeFromPage().equals(heresWhatWeFoundPage.getClass().getSimpleName())) {
            return heresWhatWeFoundPage;
        }
        AutoRecentMoverPage autoRecentMoverPage = navigateToAutoRecentMoverPage(adpfApplicant);
        if (autoRecentMoverPage.isOnRecentMoverPage()) {
            Reporter.pass(NAVIGATED_TO + "Recent movers page");
            autoRecentMoverPage.processRecentMoverPage(adpfApplicant, false, false, false);
            waitForSpinnerToBeGone();
        }
        if (heresWhatWeFoundPage.isOnHeresWhatWeFoundPage()) {
            Reporter.pass(NAVIGATED_TO + "Here's what we found page");
            return heresWhatWeFoundPage;
        } else {
            testStep("Skipping this test as the ADPF data was not able to land on the Here's What we found page", true);
            throw new SkipException("Skipping this test as the ADPF data was not able to land on the Here's What we found page");
        }
    }

    public VehicleReviewPage navigateToVehicleReviewPage(AutoApplicant applicant) throws Exception {
        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        if (getResumeFromPage().equals(vehicleReviewPage.getClass().getSimpleName())) {
            return vehicleReviewPage;
        }
        Object autoPage = navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        // fetching random vin number for the flow as we have been getting your vehicle is already in our system error a lot :)
        for (int i = 0; i < applicant.getVehicles().size(); i++) {
            Vehicle vehicle = applicant.getVehicles().get(i);
            if (vehicle.isUseVIN()) {
                if (applicant.getTestScenario().contains(HIGH_END_VEHICLE)) {
                    vehicle.setVehicleVIN("ZFF99SLA1P0295005");
                } else if (applicant.getTestScenario().contains(NO_FAST_TRACK)) {
                    vehicle.setVehicleVIN("KMHDN45D01U151996");
                }  else if (!applicant.getTestScenario().contains(USE_VEHICLE_INFO)){
                    vehicle.setVehicleVIN(getRandomVinNumber(5));
                }
            }
        }
        if (autoPage.getClass().getSimpleName().equals("WhoShouldWeInsurePage")) {
            WhoShouldWeInsurePage whoShouldWeInsurePage = WhoShouldWeInsurePage.class.cast(autoPage);

            if (isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
                VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
                if (!applicant.getTestScenario().contains(BW_CLICK_TO_BUY_FULL_FLOW) && vehiclesDriversInfoPage.getDisplayedVehicles().isEmpty()) {
                    vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
                    vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
                } else {
                    vehiclesDriversInfoPage.selectAndEditDefaultAdpfDrivers(List.of(applicant.getFinancialFiling(), applicant.getCurrentlyInsuredStatus()));
                }
                if (isProgressbarChecked()) {
                	validateProgressbarStatus(vehiclesDriversInfoPage.getClass().getSimpleName(), progressbarAceAuto, fsa);
                }
                if (isPhoneNumberChecked()) {
                	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT), vehiclesDriversInfoPage.getClass().getSimpleName(), fsa);
                }
                vehiclesDriversInfoPage.clickContinueButton();
                return new VehicleReviewPage();
            } else {
                whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
                whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
                whoShouldWeInsurePage.enterEmailAndPhoneNumber(applicant);
                whoShouldWeInsurePage.clickContinueButton();
            }
        } else {
            HeresWhatWeFoundPage heresWhatWeFoundPage = HeresWhatWeFoundPage.class.cast(autoPage);
            if (isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
                VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
                if (isProgressbarChecked()) {
                    validateProgressbarStatus(vehiclesDriversInfoPage.getClass().getSimpleName(), progressbarAceAuto, fsa);
                }
                if (isPhoneNumberChecked()) {
                	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT), vehiclesDriversInfoPage.getClass().getSimpleName(), fsa);
                }
                vehiclesDriversInfoPage.selectAndEditDefaultAdpfVehicles();
                vehiclesDriversInfoPage.selectAndEditDefaultAdpfDrivers(List.of(applicant.getFinancialFiling(), applicant.getCurrentlyInsuredStatus()));
                vehiclesDriversInfoPage.clickContinueButton();
                return new VehicleReviewPage();
            } else {
                String fullName = applicant.getFirstName() + SPACE + applicant.getLastName();
                if (heresWhatWeFoundPage.getListOfCheckedVehicles().isEmpty()) {
                    heresWhatWeFoundPage.addVehiclesWhenNoneAreFound(applicant);
                } else if (applicant.getStateCode().equals(CA)) {
                    heresWhatWeFoundPage.updateVinsForVehicles(getRandomVinNumber(3));
                    sleep(1);
                }
                heresWhatWeFoundPage.addADPFApplicant(Optional.of(applicant), fullName, applicant.getGender(), applicant.getDateOfBirth());
                heresWhatWeFoundPage.clickOnDoneAddingDriversButton();
                int vehicleCountFromDataProvider = applicant.getVehicles().size();
                if (vehicleCountFromDataProvider == 1) {
                    heresWhatWeFoundPage.uncheckVehiclesOnlyForOne();
                }
                List<WebElement> listOfCheckedVehicles = heresWhatWeFoundPage.getListOfCheckedVehicles();
                int numberOfElements = listOfCheckedVehicles.size();
                for (int i = 5; i < numberOfElements; i++) {
                    setCheckboxTo(listOfCheckedVehicles.get(i), false);
                }
                heresWhatWeFoundPage.excludeDriversEqualOrLessThan15();
                if (heresWhatWeFoundPage.isOnHeresWhatWeFoundPage() && applicant.getTestScenario().contains(DIFFERENT_STATE_DL) || applicant.getTestScenario().contains(SUSPENDED_DL)) {
                    heresWhatWeFoundPage.clickAddAnotherDriverButton();
                    heresWhatWeFoundPage.enterAdditionalDriverData(applicant, applicant.getAdditionalDrivers().get(0));
                    heresWhatWeFoundPage.clickOnSaveButton();
                    heresWhatWeFoundPage.clickOnDoneAddingDriversButton();
                }
                heresWhatWeFoundPage.clickContinueButton();
            }
        }
        waitForSpinnerToBeGone();
        if (vehicleReviewPage.isOnVehiclesReviewPage()) {
            Reporter.pass(NAVIGATED_TO + "Vehicles review page");
            if (isProgressbarChecked()) {
                validateProgressbarStatus(vehicleReviewPage.getClass().getSimpleName(), progressbarAceAuto, fsa);
            }
            if (isPhoneNumberChecked()) {
            	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT), vehicleReviewPage.getClass().getSimpleName(), fsa);
            }
            return vehicleReviewPage;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + vehicleReviewPage.getClass().getSimpleName() + NEWLINE);
        }
    }

    public DriverReviewPage navigateToDriverReviewPage(AutoApplicant applicant) throws Exception {
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        if (getResumeFromPage().equals(driverReviewPage.getClass().getSimpleName())) {
            return driverReviewPage;
        }
        VehicleReviewPage vehicleReviewPage = navigateToVehicleReviewPage(applicant);
        if (isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            return driverReviewPage;
        }
        vehicleReviewPage.addVehicleDetails(applicant);
        vehicleReviewPage.clickOnContinueButton();
        if (areElementsDisplayed(driver().findElements(By.xpath(vehicleReviewPage.getCTA_ERROR_MESSAGE_XPATH())), 2)) {
            vehicleReviewPage.setGarageAddressesToDefault();
            if (isSafariBrowser() && applicant.getStateCode().equals(CA)) {
                vehicleReviewPage.setVehicleUsagesToPersonal();
            }
            vehicleReviewPage.clickOnContinueButton();
        }
        if (driverReviewPage.isOnDriverReviewPage()) {
            Reporter.pass(NAVIGATED_TO + "Drivers review page");
            if (isProgressbarChecked()) {
                validateProgressbarStatus(driverReviewPage.getClass().getSimpleName(), progressbarAceAuto, fsa);
            }
            if (isPhoneNumberChecked()) {
            	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT), driverReviewPage.getClass().getSimpleName(), fsa);
            }
            return driverReviewPage;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + driverReviewPage.getClass().getSimpleName() + NEWLINE);
        }
    }

    public SignalPageOneUI navigateToSignalPage(AutoApplicant applicant) throws Exception {
        SignalPageOneUI signalPage = new SignalPageOneUI();
        if (getResumeFromPage().equals(signalPage.getClass().getSimpleName())) {
            return signalPage;
        }
        DriverReviewPage driverReviewPage = navigateToDriverReviewPage(applicant);
        if (!isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
            driverReviewPage.clickContinueButton();
            waitForSpinnerToBeGone();
            if (driverReviewPage.isOnBristolWest()) {
                return signalPage;
            }
        }
        if (signalPage.isOnSignalPage()) {
            Reporter.pass(NAVIGATED_TO + "Signal page");
            if (isProgressbarChecked()) {
                validateProgressbarStatus(signalPage.getClass().getSimpleName(), progressbarAceAuto, fsa);
            }
            if (isPhoneNumberChecked()) {
            	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT), signalPage.getClass().getSimpleName(), fsa);
            }
            return signalPage;
        } else {
            return signalPage; // signal page is skipped for Signal Discount disabled states and with BW
        }
    }

    public ContactInfoAutoPage navigateToContactInfoAutoPage(AutoApplicant applicant) throws Exception {
        SignalPageOneUI signalPageOneUI = navigateToSignalPage(applicant);
        // Check signal page in case of Signal Discount disabled states, it is already BW flow, or it is not already on the contact info page
        if (signalPageOneUI.isOnSignalPage()) {
            signalPageOneUI.processSignalPage(applicant.getDiscounts().get(0).isSignalSignup());
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        if (contactInfoAutoPage.isOnContactInfoAutoPage()) {
            Reporter.pass(NAVIGATED_TO + "Contact information page");
            if (isProgressbarChecked()) {
                validateProgressbarStatus(contactInfoAutoPage.getClass().getSimpleName(), progressbarAceAuto, fsa);
            }
            if (isPhoneNumberChecked()) {
            	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT), contactInfoAutoPage.getClass().getSimpleName(), fsa);
            }
            return contactInfoAutoPage;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + contactInfoAutoPage.getClass().getSimpleName() + NEWLINE);
        }
    }

    public VehicleDriverAssignmentPage navigateToVehicleDriverAssignmentPage(AutoApplicant applicant) throws Exception {
        return navigateToVehicleDriverAssignmentPage(applicant, true);
    }

    public VehicleDriverAssignmentPage navigateToVehicleDriverAssignmentPage(AutoApplicant applicant, boolean pageExpected) throws Exception {
        ContactInfoAutoPage contactInfoAutoPage = navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        contactInfoAutoPage.waitForSpinnerToBeGone();
        if (contactInfoAutoPage.isOnContactInfoAutoPage()) {
            contactInfoAutoPage.clickContactInfoPageCTAButton();
            waitForSpinnerToBeGone();
        }
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (!pageExpected || vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            // Navigation successful message is in vehicleDriverAssignmentPage.processVehiclesDriversAssignmentPage(applicant)
            return vehicleDriverAssignmentPage;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + vehicleDriverAssignmentPage.getClass().getSimpleName() + NEWLINE);
        }
    }

    public ContinueWithBristolWestPage navigateToContinueWithBristolWestPage(AutoApplicant applicant) throws Exception {
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = navigateToVehicleDriverAssignmentPage(applicant, false);
        vehicleDriverAssignmentPage.processVehiclesDriversAssignmentPageIfNeeded();
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage() || isOnBristolWest()) {
            Reporter.pass(NAVIGATED_TO + "Continue with Bristol West page");
            return continueWithBristolWestPage;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + continueWithBristolWestPage.getClass().getSimpleName() + NEWLINE);
        }
    }

    public QuoteSummaryAutoPage navigateToQuoteSummaryAutoPage(AutoApplicant applicant) throws Exception {
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = navigateToVehicleDriverAssignmentPage(applicant, false);
        vehicleDriverAssignmentPage.processVehiclesDriversAssignmentPageIfNeeded();
        SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
        if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
            Reporter.pass(NAVIGATED_TO + "Select a quote to review page");
            selectAQuoteToReviewPage.clickContinueMyQuote();
        }
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if (bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            Reporter.pass(NAVIGATED_TO + "BW/Farmers quote presentment page");
            if (applicant.getTestScenario().contains("BW")) {
                bwFarmersQuotePresentmentPage.continueWithBw();
            } else {
                bwFarmersQuotePresentmentPage.continueWithFarmers();
            }
            waitForSpinnerToBeGone();
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        quoteSummaryAutoPage.removeQualtricsPopUp();
        if (quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            closeQualtricsPopUp();
            return returnTheQuoteSummaryPage(quoteSummaryAutoPage);
        } else {
            throw new IllegalStateException(DID_NOT_REACH + quoteSummaryAutoPage.getClass().getSimpleName() + NEWLINE);
        }
    }

    public QuoteSummaryAutoPage navigateToEitherQuoteSummaryPage(AutoApplicant applicant) throws Exception {
        QuoteSummaryAutoPage quoteSummaryPage = new QuoteSummaryAutoPage();
        if (getResumeFromPage().equals(quoteSummaryPage.getClass().getSimpleName())) {
            return returnTheQuoteSummaryPage(quoteSummaryPage);
        }
        ContactInfoAutoPage contactInfoAutoPage = navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        contactInfoAutoPage.waitForSpinnerToBeGone();
        if (quoteSummaryPage.isOnQuoteSummaryAutoPage()) {
            return returnTheQuoteSummaryPage(quoteSummaryPage);
        }
        String quoteNumber = quoteSummaryPage.getSessionStorageAppStore().getData().getQuoteNumber();

        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        vehicleDriverAssignmentPage.processVehiclesDriversAssignmentPageIfNeeded();
        if (quoteSummaryPage.isOnQuoteSummaryAutoPage()) {
            return returnTheQuoteSummaryPage(quoteSummaryPage);
        }
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        BristolWestAdditionalDiscountsPage bwAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();

        if (applicant.getTestScenario().contains("BW")) {
            if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
                continueWithBristolWestPage.continueWithBwPopUp();
                if (bwAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
                    quoteSummaryPage = bwAdditionalDiscountsPage.clickContinue();
                }
                vehicleDriverAssignmentPage.processVehiclesDriversAssignmentPageIfNeeded();
            }
            if (quoteSummaryPage.isOnQuoteSummaryAutoPage()) {
                return returnTheQuoteSummaryPage(quoteSummaryPage);
            }
        }
        if (bwAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
            bwAdditionalDiscountsPage.clickContinue();
            vehicleDriverAssignmentPage.processVehiclesDriversAssignmentPageIfNeeded();
        }

        AutoRentersBundleOfferingPage autoRentersBundleOfferingPage = new AutoRentersBundleOfferingPage();
        if (autoRentersBundleOfferingPage.quickIsOnAutoRentersBundleOfferingPage()) {
            autoRentersBundleOfferingPage.processRentersBundleOfferingPage(false);
        }

        if (quoteSummaryPage.isOnQuoteSummaryAutoPage()) {
            return returnTheQuoteSummaryPage(quoteSummaryPage);
        }

        SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        if (knockoutInconveniencePage.isOnKnockOutPage() && knockoutInconveniencePage.getPageTitle().equals(KnockoutInconveniencePage.EXPECTED_SPECIAL_ATTENTION_TITLE)) {
            throw new SkipException("Can't finish your quote online at quote summary page");
        } else if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            quoteSummaryPage = continueWithBristolWestPage.continueWithBwPopUp();
            vehicleDriverAssignmentPage.processVehiclesDriversAssignmentPageIfNeeded();
            if (bwAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
                quoteSummaryPage = bwAdditionalDiscountsPage.clickContinue();
            }
            if (quoteSummaryPage.getSessionStorageAppStore().getData().getProjectCodeData().getAuto().isBWImplemented()) {
                testStepAssert(knockoutInconveniencePage.isOnInconveniencePage(), "User should reach KO page for a state where BW is not available");
            }
            if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
                quoteSummaryPage = selectAQuoteToReviewPage.clickContinueMyQuote();
            }
            if (quoteSummaryPage.isOnQuoteSummaryAutoPage() && quoteSummaryPage.isBristolWestQuote()) {
                return returnTheQuoteSummaryPage(quoteSummaryPage);
            }
            if (!getSessionStorageAppStore().getKnockouts().isEmpty()) {
                testStepAssert(knockoutInconveniencePage.isOnKnockOutPage(), "User should land on the knockout page", true);
                return quoteSummaryPage;
            }
            if (knockoutInconveniencePage.isOnInconveniencePage()) {
                testStep("User landed on the Inconvenience page. Quote number: " + getAceAutoQuoteNumber(), true);
                throw new SkipException("User landed on the Inconvenience page instead of BW quote summary page");
            }
        } else if (knockoutInconveniencePage.isOnInconveniencePage()) { // when user gets we are sorry page and retrieves the quote to continue
            testStep("User landed on the KO/Inconvenience page, please check the DB for details. Quote Number => " + quoteNumber, true);
            new LandingPage(isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, quoteNumber);
            WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
            if (quoteSummaryPage.quickIsOnQuoteSummaryAutoPage()) {
                return quoteSummaryPage;
            } else if (whoShouldWeInsurePage.isOnWhoShouldWeInsurePage()) {
                if (whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
                	new VehiclesDriversInfoPage().clickContinueButton();
                	waitForSpinnerToBeGone();
                } else {
                    whoShouldWeInsurePage.clickOnContinueButton();
                    VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
                    vehicleReviewPage.setVehicleUsagesToPersonal();
                    vehicleReviewPage.clickOnContinueButton();
                    DriverReviewPage driverReviewPage = new DriverReviewPage();
                    driverReviewPage.validatePageHeaderAndDescription();
                    driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
                    driverReviewPage.clickContinueButton();
                }
                SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
                if ((!signalPageOneUI.isSignalDiscountDisabledState(applicant.getStateCode())) && !signalPageOneUI.isOnBristolWest()) {
                    signalPageOneUI.processSignalPage(true);
                }
                new ContactInfoAutoPage().setValuesAndContinue(applicant);
                if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
                    String stateCode = applicant.getStateCode();
                    if (stateCode.equals(VA)) {
                        vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
                    } else {
                        vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
                    }
                }
                waitForSpinnerToBeGone();
                QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
                if (quoteSummaryAutoPage.quickIsOnQuoteSummaryAutoPage()) {
                    return quoteSummaryPage;
                }
                ContinueWithBristolWestPage continueWithBristolWest = new ContinueWithBristolWestPage();
                if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
                    selectAQuoteToReviewPage.clickContinueMyQuote();
                }
                if (continueWithBristolWest.isOnContinueWithBristolWestPage()) {
                    continueWithBristolWest.continueWithBwPopUp();
                    BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
                    if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
                        bristolWestAdditionalDiscountsPage.clickContinue();
                    }
                }
                BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
                if (bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
                    bwFarmersQuotePresentmentPage.continueWithFarmers();
                }
            } else {
                throw new IllegalStateException(DID_NOT_REACH + quoteSummaryPage.getClass().getSimpleName() + NEWLINE);
            }
        } else if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
            selectAQuoteToReviewPage.clickContinueMyQuote();
        }

        if (quoteSummaryPage.quickIsOnQuoteSummaryAutoPage()) {
            if (isRemoveQualtricsPopup()) {
                quoteSummaryPage.removeQualtricsPopUp();
            }
            return returnTheQuoteSummaryPage(quoteSummaryPage);
        } else {
            throw new IllegalStateException(DID_NOT_REACH + "QuoteSummaryAutoPage" + NEWLINE);
        }
    }

    private QuoteSummaryAutoPage returnTheQuoteSummaryPage(QuoteSummaryAutoPage quoteSummaryPage) throws Exception {
        Reporter.pass(NAVIGATED_TO + "Auto quote summary page");
        writeRatedQuoteInformationToFile("Ace Auto - " + getQuoteDetails());
        if (isProgressbarChecked()) {
            validateProgressbarStatus(quoteSummaryPage.getClass().getSimpleName(), progressbarAceAuto, fsa);
        }
        if (isPhoneNumberChecked()) {
        	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT) && !isBristolWestQuote(), quoteSummaryPage.getClass().getSimpleName(), fsa);
        }
        removeQualtricsPopUp();
        return quoteSummaryPage;
    }

    public QuoteSummaryAutoPage navigateToQuoteSummaryAutoPageUsingDefaults(ADPFApplicant adpfApplicant) throws Exception {
        if (!getResumeFromPage().equals(new VehicleReviewPage().getClass().getSimpleName())) {
            HeresWhatWeFoundPage heresWhatWeFoundPage = navigateToHeresWhatWeFoundPage(adpfApplicant);
            removeQualtricsPopUp();
            if (isVehiclesDriversConsolidationImpl(adpfApplicant.getStateCode())) {
                VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
                if (vehiclesDriversInfoPage.isOnVehiclesDriversInfoPage()) {
                    Reporter.pass(NAVIGATED_TO + "Vehicles and Drivers review page");
                    vehiclesDriversInfoPage.selectAndEditDefaultAdpfVehicles();
                    vehiclesDriversInfoPage.selectAndEditDefaultAdpfDrivers(Collections.emptyList());
                    vehiclesDriversInfoPage.clickContinueButton();
                } else {
                    throw new IllegalStateException(DID_NOT_REACH + vehiclesDriversInfoPage.getClass().getSimpleName() + NEWLINE);
                }
            } else {
                if (heresWhatWeFoundPage.getListOfCheckedVehicles().isEmpty()) {
                    heresWhatWeFoundPage.addRandomNewVehicle(getRandomVinNumber(3));
                    heresWhatWeFoundPage.clickOnDoneAddingVehiclesButton();
                }
                String fullName = adpfApplicant.getFirstName() + SPACE + adpfApplicant.getLastName();
                heresWhatWeFoundPage.addADPFApplicant(Optional.empty(), fullName, adpfApplicant.getGender(), adpfApplicant.getDateOfBirth());
                heresWhatWeFoundPage.uncheckVehiclesOnlyForOne();
                heresWhatWeFoundPage.clickContinueButton();
            }
        }
        return navigateFromVehicleReviewToQuoteSummaryPage(adpfApplicant);
    }

    public QuoteSummaryAutoPage navigateFromVehicleReviewToQuoteSummaryPage(ADPFApplicant adpfApplicant) throws Exception {
        if (!isVehiclesDriversConsolidationImpl(adpfApplicant.getStateCode())) {
            VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
            if (vehicleReviewPage.isOnVehiclesReviewPage()) {
                if (adpfApplicant.getStateCode().equals(CA)) {
                    List<WebElement> personalToggles = vehicleReviewPage.getPersonalToggles();
                    for (WebElement personalToggle : personalToggles) {
                        scrollAndClickOnHiddenElement(personalToggle);
                    }
                }
                vehicleReviewPage.clickOnContinueButton();
            }
            DriverReviewPage driverReviewPage = new DriverReviewPage();
            if (driverReviewPage.isOnDriverReviewPage()) {
                driverReviewPage.fillOutDriverLicenseAges();
                driverReviewPage.fillOutDriverLicenseNumbers();
                driverReviewPage.fillOutOccupationAffinitySection();
                driverReviewPage.clickContinueButton();
            }
        }

        if (!isSignalDiscountDisabledState(adpfApplicant.getStateCode()) && !isBDQFlowEnabled()) {
            SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
            if (signalPageOneUI.isOnSignalPage()) {
                signalPageOneUI.processSignalPage(true);
            }
        }
        new ContactInfoAutoPage().setValuesAndContinue();
        waitForSpinnerToBeGone();
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            if (adpfApplicant.getStateCode().equals(VA)) {
                vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
            } else {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave(adpfApplicant);
            }
        }
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
            waitForSpinnerToBeGone();
            BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
            if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
                bristolWestAdditionalDiscountsPage.clickContinue();
            }
        }
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        if (knockoutInconveniencePage.isOnInconveniencePage()) {
            testStep("Skipped as user is not able to land on the quote summary page. Quote number: " + getAceAutoQuoteNumber(), true);
            throw new SkipException("Quote landed on the Inconvenience page instead of Quote summary page");
        }
        SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
        if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
            selectAQuoteToReviewPage.clickContinueMyQuote();
        }
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if (bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            bwFarmersQuotePresentmentPage.continueWithFarmers();
        }

        AutoRentersBundleOfferingPage autoRentersBundleOfferingPage = new AutoRentersBundleOfferingPage();
        if (autoRentersBundleOfferingPage.isOnAutoRentersBundleOfferingPage()) {
            autoRentersBundleOfferingPage.processRentersBundleOfferingPage(false);
        }

        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        removeQualtricsPopUp();
        if (quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            testStep("User is on the quote summary page", true);
            return returnTheQuoteSummaryPage(quoteSummaryAutoPage);
        } else {
            throw new IllegalStateException(DID_NOT_REACH + quoteSummaryAutoPage.getClass().getSimpleName() + NEWLINE);
        }
    }

    public DriverMismatchPage navigateToDriverMismatchPage(ADPFApplicant adpfApplicant) throws Exception {
        navigateToQuoteSummaryAutoPageUsingDefaults(adpfApplicant);
        return navigateFromQuoteSummaryPageToDriverMismatchPage(adpfApplicant);
    }

    public DriverMismatchPage navigateToDriverMismatchPage(AutoApplicant applicant) throws Exception {
        //This is one of those pages that may not show up, so the caller has to check again of it's there
        AnnualMileagePage annualMileagePage = navigateToAnnualMileagePage(applicant);
        if (annualMileagePage.isOnAnnualMilagePage()) {
            annualMileagePage.fillAnnualMileageAndContinue("10000");
        }
        DriverMismatchPage driverMismatchPage = new DriverMismatchPage();
        if (driverMismatchPage.isOnDriverMismatchPage()) {
            Reporter.pass(NAVIGATED_TO + "Driver Mismatch page");
        }
        return driverMismatchPage;
    }

    public DriverMismatchPage navigateFromQuoteSummaryPageToDriverMismatchPage(ADPFApplicant adpfApplicant) throws Exception {
        new QuoteSummaryAutoPage().clickOnStartCheckoutButton();
        waitForSpinnerToBeGone();
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        if (additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage()) {
            removeQualtricsPopUp();
            additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage();
        }
        removeQualtricsPopUp();
        waitForSpinnerToBeGone();
        DriverMismatchPage driverMismatchPage = new DriverMismatchPage();
        if (driverMismatchPage.isOnDriverMismatchPage()) {
            Reporter.pass(NAVIGATED_TO + "Driver Mismatch page");
            return driverMismatchPage;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + driverMismatchPage.getClass().getSimpleName() + NEWLINE);
        }
    }

    public AdditionalInfoPolicyStartDateOneUI navigateToAdditionalInfoPage(AutoApplicant applicant) throws Exception {
        QuoteSummaryAutoPage quoteSummaryAutoPage = navigateToEitherQuoteSummaryPage(applicant);
        String quoteNumber = quoteSummaryAutoPage.getSessionStorageAppStore().getData().getQuoteNumber();
        //update the MI bi limit from sidesheet
        if (applicant.getStateCode().equals(MI)) {
            quoteSummaryAutoPage.updateLiabilityBiOnly("$250,000/$500,000");
        }
        DriverMismatchPage driverMismatchPage = new DriverMismatchPage();
        if (driverMismatchPage.isOnDriverMismatchPage()) {
            if (isPhoneNumberChecked()) {
            	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT), driverMismatchPage.getClass().getSimpleName(), fsa);
            }
            driverMismatchPage.dontIncludeAnyMismatchedDriversInQuote();
            waitForSpinnerToBeGone();
        }
        boolean bindDisabled = false;
        try {
            bindDisabled = new ApiHelper().getAutoRateQuote(quoteNumber).getAutoRateQuoteResponseBean().getRateQuoteResponses().get(0).getBuyEnableInd().equals("N");
        } catch (Exception e) {
            Log.warn("Connection to the postgres failed. Error message: " + e.getMessage());
        }
        if (bindDisabled) {
            closeQualtricsPopUp();
            quoteSummaryAutoPage.clickContinueButton();
            waitForSpinnerToBeGone();
            testStepAssert(new ThankYouPageAce().isOnThankYouPage(), "User should get thank you page when bind is disabled");
            throw new SkipException("Skipping as bind is not enabled");
        }
        return getAdditionalInfoPolicyStartDateOneUI(isRemoveQualtricsPopup(), false, quoteSummaryAutoPage);
    }

    public AnnualMileagePage navigateToAnnualMileagePage(AutoApplicant applicant) throws Exception {
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = navigateToAdditionalInfoPage(applicant);
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
        //not throwing navigation error as the page randomly appears for some data, so the caller has to check if it's there
        return new AnnualMileagePage();
    }

    public AdditionalInfoPolicyStartDateOneUI navigateToAdditionalInfoPageWithAdpfData(ADPFApplicant adpfApplicant) throws Exception {
        QuoteSummaryAutoPage quoteSummaryAutoPage = navigateToQuoteSummaryAutoPageUsingDefaults(adpfApplicant);
        return getAdditionalInfoPolicyStartDateOneUI(isRemoveQualtricsPopup(), true, quoteSummaryAutoPage);
    }

    public AdditionalInfoPolicyStartDateOneUI getAdditionalInfoPolicyStartDateOneUI(boolean shouldRemoveQualtricsPopUp, boolean usedADPF, QuoteSummaryAutoPage quoteSummaryAutoPage) throws Exception {
        List<AppStore.KnockOut> knockouts = quoteSummaryAutoPage.getSessionStorageAppStore().getKnockouts();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        if (!knockouts.isEmpty()) {
            testStepAssert(knockoutInconveniencePage.isOnKnockOutPage(), "User successfully landed on the KO page");
        }
        quoteSummaryAutoPage.clickOnStartCheckoutButton();
        quoteSummaryAutoPage.waitForSpinnerToBeGone();
        if (usedADPF) {
            DriverMismatchPage driverMismatchPage = new DriverMismatchPage();
            if (driverMismatchPage.isOnDriverMismatchPage()) {
                if (isPhoneNumberChecked()) {
                	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT), driverMismatchPage.getClass().getSimpleName(), fsa);
                }
               driverMismatchPage.dontIncludeAnyMismatchedDriversInQuote();
                driverMismatchPage.waitForSpinnerToBeGone();
            }
        }
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        AppStore sessionStorageAppStore = additionalInfoPolicyStartDateOneUI.getSessionStorageAppStore();
        AppStore.Data data = sessionStorageAppStore.getData();
        if (!data.getCustomerData().getAddress().getIsStandardized().equals("Y")) {
            testStepAssert(new ThankYouPageAce().isOnThankYouPage(), "User should land on the thank you page as the state is not bind enabled", true);
            throw new SkipException("Skipping test as the bind is not enabled for given state");
        }
        if (shouldRemoveQualtricsPopUp) {
            additionalInfoPolicyStartDateOneUI.removeQualtricsPopUp();
        }
        if (additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage()) {
            Reporter.pass(NAVIGATED_TO + "Additional Information page");
            if (isPhoneNumberChecked()) {
            	isFarmersPhoneNumberCorrect(getFlowType().equals(quoteFlow.AGENT) && !isBristolWestQuote(), additionalInfoPolicyStartDateOneUI.getClass().getSimpleName(), fsa);
            }
            return additionalInfoPolicyStartDateOneUI;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + additionalInfoPolicyStartDateOneUI.getClass().getSimpleName() + NEWLINE);
        }
    }

    public PaymentSelectionBasePage navigateToPaymentSelectionPage(AutoApplicant applicant) throws Exception {
        DriverMismatchPage driverMismatchPage = navigateToDriverMismatchPage(applicant);
        String quoteNumber = driverMismatchPage.getSessionStorageAppStore().getData().getQuoteNumber();
        if (driverMismatchPage.isOnDriverMismatchPage()) {
            driverMismatchPage.randomlySelectReasonForNonInclusion();
            driverMismatchPage.clickContinueButton();
            waitForSpinnerToBeGone();
        }

        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
            BristolWestAdditionalDiscountsPage additionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
            if (additionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
                additionalDiscountsPage.clickContinue();
                waitForSpinnerToBeGone();
            }
            QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
            testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page", true);
            quoteSummaryAutoPage.clickOnStartCheckoutButton();
            AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
            additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
            if (driverMismatchPage.isOnDriverMismatchPage()) {
                driverMismatchPage.dontIncludeAnyMismatchedDriversInQuote();
                driverMismatchPage.clickContinueButton();
                waitForSpinnerToBeGone();
            }
            if (additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage()) {
                throw new IllegalStateException("Problems encountered on JFMT page" + NEWLINE);
            }
        }
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        if (autoPolicyPaymentBasePage.isOnContinueToPaymentPage()
                || bwPaymentSummaryPage.isOnBwPaymentSummaryPage()
                || bwPaymentSummaryPage.isRateChangePopUpDisplayed()) {
            Reporter.pass(NAVIGATED_TO + "Payment page");
            bwPaymentSummaryPage.closeRateChangePopUpIfPresent();
            return autoPolicyPaymentBasePage;
        } else if (new ConsolidatedPaymentPage().isOnConsolidatedPaymentPage()) {
            Reporter.pass(NAVIGATED_TO + "Consolidated Payment page");
            return autoPolicyPaymentBasePage;
        } else if (knockoutInconveniencePage.isOnInconveniencePage() || knockoutInconveniencePage.isOnKnockOutPage()) {
            testStep("User landed on the KO/Inconvenience page, please check the DB for details. Quote Number => " + quoteNumber, true);
            new LandingPage(isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, quoteNumber);
            AdditionalInfoPolicyStartDateOneUI additionalInformationPage = new AdditionalInfoPolicyStartDateOneUI();
            if (additionalInformationPage.isOnAdditionalInfoPage()) {
                additionalInformationPage.confirmSignalEnrollment();
                additionalInformationPage.continueToPaymentPage();
                if (autoPolicyPaymentBasePage.isOnContinueToPaymentPage() || bwPaymentSummaryPage.isOnBwPaymentSummaryPage()) {
                    Reporter.pass(NAVIGATED_TO + "Payment page after retrieving quote from landing page");
                    return autoPolicyPaymentBasePage;
                } else {
                    throw new IllegalStateException(DID_NOT_REACH + autoPolicyPaymentBasePage.getClass().getSimpleName() + NEWLINE);
                }
            } else {
                throw new IllegalStateException(DID_NOT_REACH + autoPolicyPaymentBasePage.getClass().getSimpleName() + NEWLINE);
            }
        } else {
            throw new IllegalStateException(DID_NOT_REACH + autoPolicyPaymentBasePage.getClass().getSimpleName() + NEWLINE);
        }
    }

    public PaymentSelectionBasePage navigateToPaymentSelectionPage(ADPFApplicant applicant) throws Exception {
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = navigateToAdditionalInfoPageWithAdpfData(applicant);
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage();
        DriverMismatchPage driverMismatchPage = new DriverMismatchPage();
        if (driverMismatchPage.isOnDriverMismatchPage()) {
            driverMismatchPage.dontIncludeAnyMismatchedDriversInQuote();
            waitForSpinnerToBeGone();
        }
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            QuoteSummaryAutoPage quoteSummaryAutoPage = continueWithBristolWestPage.continueWithBwPopUp();
            BristolWestAdditionalDiscountsPage additionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
            if (additionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
                additionalDiscountsPage.clickContinue();
                waitForSpinnerToBeGone();
            }
            quoteSummaryAutoPage.clickOnStartCheckoutButton();
            waitForSpinnerToBeGone();
            new AdditionalInfoContinueToPaymentOneUI().clickContinueToPaymentButton();
        }
        new ContactInfoAutoPage().waitForRC2ScreenToFinish();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        if (autoPolicyPaymentBasePage.isOnContinueToPaymentPage()) {
            Reporter.pass(NAVIGATED_TO + "Payment page");
            return autoPolicyPaymentBasePage;
        } else if (new ConsolidatedPaymentPage().isOnConsolidatedPaymentPage()) {
            Reporter.pass(NAVIGATED_TO + "Consolidated Payment page");
            return autoPolicyPaymentBasePage;
        } else {
            throw new IllegalStateException(DID_NOT_REACH + autoPolicyPaymentBasePage.getClass().getSimpleName() + NEWLINE);
        }
    }

    public void processHeresWhatWeFoundOrVehicleDriverConsolidatedPage(AutoApplicant applicant) throws Exception {
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
        heresWhatWeFoundPage.isOnHeresWhatWeFoundPage();
        if (isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            if(vehiclesDriversInfoPage.getDisplayedVehicles().isEmpty()) {
                vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            } else {
                vehiclesDriversInfoPage.selectAndEditDefaultAdpfVehicles();
            }
            if (vehiclesDriversInfoPage.getFoundDriversCount() == 1) {
                vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
            } else {
                vehiclesDriversInfoPage.selectAndEditDefaultAdpfDrivers(Collections.emptyList());
            }
        } else {
            String fullName = applicant.getFirstName() + SPACE + applicant.getLastName();
            if (heresWhatWeFoundPage.getListOfCheckedVehicles().isEmpty()) {
                heresWhatWeFoundPage.addVehiclesWhenNoneAreFound(applicant);
            } else if (applicant.getStateCode().equals(CA)) {
                heresWhatWeFoundPage.updateVinsForVehicles(getRandomVinNumber(3));
                sleep(1);
            } else if (applicant.getTestScenario().contains("BW")) {
                heresWhatWeFoundPage.updateVinsForVehicles(getRandomVinNumber(3));
            }
            heresWhatWeFoundPage.addADPFApplicant(Optional.of(applicant), fullName, applicant.getGender(), applicant.getDateOfBirth());
            heresWhatWeFoundPage.clickOnDoneAddingDriversButton();
            int vehicleCountFromDataProvider = applicant.getVehicles().size();
            if (vehicleCountFromDataProvider == 1) {
                heresWhatWeFoundPage.uncheckVehiclesOnlyForOne();
            }
            List<WebElement> listOfCheckedVehicles = heresWhatWeFoundPage.getListOfCheckedVehicles();
            int numberOfElements = listOfCheckedVehicles.size();
            for (int i = 5; i < numberOfElements; i++) {
                setCheckboxTo(listOfCheckedVehicles.get(i), false);
            }
            heresWhatWeFoundPage.excludeDriversEqualOrLessThan15();
            if (heresWhatWeFoundPage.isOnHeresWhatWeFoundPage() && applicant.getTestScenario().contains(DIFFERENT_STATE_DL) || applicant.getTestScenario().contains(SUSPENDED_DL)) {
                heresWhatWeFoundPage.clickAddAnotherDriverButton();
                heresWhatWeFoundPage.enterAdditionalDriverData(applicant, applicant.getAdditionalDrivers().get(0));
                heresWhatWeFoundPage.clickOnSaveButton();
                heresWhatWeFoundPage.clickOnDoneAddingDriversButton();
            }
        }
    }

    public WhoShouldWeInsurePage navigateBackToWhoShouldWeInsurePage() throws Exception {
    	WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
    	KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
    	int maxPages = 8; // set to whatever limit is reasonable
    	while (maxPages>0 && !whoShouldWeInsurePage.quickIsOnWhoShouldWeInsurePage() && !koPage.isQuoteKnockedOut()) {
    		navigateBackToPreviousPage();
    		maxPages--;
    	}
    	if (whoShouldWeInsurePage.quickIsOnWhoShouldWeInsurePage()) {
    		Reporter.pass("Navigated back to Who should we insure page");
    		return whoShouldWeInsurePage;
    	} else {
    		throw new IllegalStateException("Unable to navigate back to Who should we insure page");
    	}
    }

}