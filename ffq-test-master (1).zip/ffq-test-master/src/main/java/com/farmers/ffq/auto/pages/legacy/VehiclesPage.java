package com.farmers.ffq.auto.pages.legacy;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.datatransferobjects.SqlVehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import javax.annotation.Nullable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class VehiclesPage extends AutoBasePage {

	private static final String VEHICLES_PAGE_HEADER = "WHICH VEHICLE(S) DO YOU WANT TO INSURE?";
	private static final String COMMUTE = "Commute";

	private static final String PURCHASE_ERROR_MESSAGE = "Please enter purchase date.";
	private static final String VIN_ERROR_MESSAGE = "Enter VIN or select Year, Make and Model.";
	private static final String YEAR_ERROR_MESSAGE = "Please enter year.";
	private static final String ONEWAY_MILES_ERROR_MESSAGE = "Please enter the miles you drive one-way.";

	private static final String YMMT_LABEL = "Select the year, make, and model of your vehicle or";
	private static final String CAR_NOT_FOUND_LABEL = "Can't find your car?";
	private static final String VIN_LABEL = "Please enter your Vehicle Identification Number (VIN) or";
	private static final String WHERES_VIN_LABEL = "Where's my VIN?";
	private static final String OWNERSHIP_LABEL = "This vehicle is:";
	private static final String FINANCED_LABEL = "Financed";
	private static final String LEASED_LABEL = "Leased";
	private static final String OWNED_LABEL = "Owned";
	private static final String PURCHASE_DATE_LABEL = "On what date did you purchase your vehicle?";
	private static final String PRIMARY_USE_LABEL = "What is this vehicle's primary use?";
	private static final String COMMUTE_LABEL = "Commuting to/from work or school";
	private static final String BUSINESS_LABEL = "Business";
	private static final String PLEASURE_LABEL = "Pleasure";
	private static final String RIDESHARING_LABEL = "Is this vehicle used for ridesharing?";
	private static final String RIDESHARING_ANDOR_DELIVERY_LABEL = "Is this vehicle used for ridesharing, on-demand food delivery, or both?";
	private static final String RIDESHARING_OR_DELIVERY_LABEL = "Is this vehicle used for ridesharing or delivery?";
	private static final String OVERNIGHT_PARKING_LABEL = "Do you park this vehicle overnight at your residential address at ";
	private static final String WHERE_DO_YOU_PARK_LABEL = "Where do you park this vehicle?";

	private static final String CANT_FIND_CAR_FAQ_TITLE = "Can't find your car?";
	private static final String CANT_FIND_CAR_FAQ_TEXT = "Enter your VIN number if your car is not in our system. If you want an insurance quote for a specialty car, motorcycle or recreational vehicle, please contact a Farmers agent. At this time, we do not provide online quotes for these types of vehicles.";
	private static final String CANT_FIND_CAR_FAQ_TEXT_EE = "Enter your VIN number if your car is not in our system. If you want an insurance quote for a specialty car, motorcycle or recreational vehicle, please call Farmers representative at 1-888-767-4030. At this time, we do not provide online quotes for these types of vehicles.";
	private static final String VIN_FAQ_TITLE ="Vehicle Identification Number (VIN)";
	private static final String VIN_FAQ_TEXT ="Your Vehicle Identification Number is a unique 17-digit number given to every vehicle in the United States. This number is listed on your registration card, and is also engraved on a narrow plate attached to your dashboard on the driver side. " +
			"VIN Number Locations " +
			"1. Dashboard on the driver side " +
			"2. Driver side door (where the door latches) " +
			"3. Vehicle registration card or title " +
			"4. Current insurance card for this vehicle " +
			"NOTE: If in doubt, VIN Number will not include the letters O (o), I (i), or Q (q). These are actually numerals 0, 1, and 9.";
	private static final String ALTERNATIVE_FUELS_FAQ_TITLE = "Alternative fuels";
	private static final String ALTERNATIVE_FUELS_FAQ_TEXT = "Eco-friendly vehicles that run on electric, electric/gasoline hybrid, ethanol, methanol, compressed natural gas or propane can qualify for a reduced rate.";
	private static final String ANTI_THEFT_DEVICE_FAQ_TITLE = "Anti-theft device";
	private static final String ANTI_THEFT_DEVICE_FAQ_TEXT = "Approved anti-theft devices may qualify you for discounts. Examples of these devices include manual or automatic alarm systems, active or passive devices that disable your vehicle, and/or your VIN number etched into your window glass.";
	private static final String OWNERSHIP_FAQ_TITLE = "Vehicle Ownership";
	private static final String OWNERSHIP_FAQ_TEXT = "If you borrowed money from a lender to pay for your vehicle and you're still making payments, select \"Financed\". " +
			"If you are leasing the car for a set period of time, select \"Leased\". " +
			"Select \"Owned\" if your vehicle loan is paid off, or if you purchased your car without a loan.";
	private static final String PRIMARY_USAGE_FAQ_TITLE = "Primary use of vehicle";
	private static final String PRIMARY_USAGE_FAQ_TEXT = "Select the option for which you drive the most often, it helps to know if this car will be used for commuting to/from school/work, for business use, or used for pleasure.";
	private static final String PRIMARY_USAGE_FAQ_TEXT_NC = PRIMARY_USAGE_FAQ_TEXT + " If it is used for farming, please select Business.";
	private static final String RIDESHARING_FAQ_TITLE = "Ride sharing";
	private static final String RIDESHARING_FAQ_TEXT = "Ride-sharing companies, such as Uber or Lyft, use personal vehicles to transport passengers for a payment.";
	private static final String RIDESHARING_FAQ_TITLE_VERSION2 = "Ridesharing";
	private static final String RIDESHARING_FAQ_TEXT_VERSION2 = "Ridesharing companies, such as Uber or Lyft, allow an individual to use their personal vehicle to transport passengers for a payment. " +
			"On-demand Food Delivery " +
			"On-demand food delivery is pre-arranged delivery of prepared food or grocery items through a digital network or similar connection such as Uber Eats, GrubHub, or Postmates.";
	private static final String RIDESHARING_FAQ_TITLE_NC = "Ridesharing (Limited Transportation Network Driver Coverage) ";
	private static final String RIDESHARING_FAQ_TEXT_NC = "Provides coverage for participation as a transportation network driver for the period of time from when the driver logs into a transportation network platform (like Uber or Lyft) and a passenger is not occupying the vehicle, up until the driver accepts a request through the transportation network platform to transport a passenger. " +
			"Delivery Coverage " +
			"Delivery coverage can be purchased for vehicles used to deliver food, goods, items or products. Examples include Uber Eats, GrubHub, or delivery for a local restaurant.";
	private static final String OVERNIGHT_PARKING_FAQ_TITLE = "Garage Address";
	private static final String OVERNIGHT_PARKING_FAQ_TEXT = "To provide an accurate quote, it helps to know where your car is parked overnight. Typically, this is the same as your home address or mailing address. However, if you park your car elsewhere, please provide that address.";

	private static final String LINK_XPATH = "/a";

	@FindBy(className = "ffq-main-title")
	private WebElement vehiclesPageHeader;

	@FindBy(xpath = "//a[@data-gtm='FFQ_Auto_Vehicle_addVeh_button']")
	private WebElement addVehicleLink;

	@FindBy(xpath = "//div[contains(@class,'auto__vehicles__footer')]/button[contains(@data-gtm, 'back')]")
	private WebElement backButton;

	@FindBy(xpath = "//div[contains(@class,'auto__vehicles__footer')]/button[contains(@data-gtm, 'next')]")
	private WebElement nextButton;

	@FindBy(xpath = "//button[@data-gtm='FFQ_Auto_Vehsummary_next_button' and contains(@class, 'right_button')]")
	private WebElement buttonNext;

	@FindBy(xpath = "//lib-card//div[@data-gtm='FFQ_Auto_Vehicle_selectVehicle_checkbox']//h3")
	private List<WebElement> listOfVehicles;

	@FindBy(xpath = "//lib-card//span[contains (@aria-label, 'Vehicle Identification Number : VIN')]")
	private List<WebElement> listOfVINs;

	// Add Vehicle dialog
	private static final String CLOSE_DIALOG_BUTTON_XPATH = "//div[contains(@class, 'close-icon')]";
	@FindBy (xpath = CLOSE_DIALOG_BUTTON_XPATH)
	private WebElement closeAddVehicleDialogButton;

	@FindBy (id = "infoDialog")
	private WebElement navigateAwayDialog;

	private static final String CONTINUE_CHANGING_XPATH = "//button/span[text()='No, continue']";
	@FindBy (xpath = CONTINUE_CHANGING_XPATH)
	private WebElement continueChangingButton;

	private static final String NAVIGATE_AWAY_XPATH = "//button/span[text()='Yes, navigate away']";
	@FindBy (xpath = NAVIGATE_AWAY_XPATH)
	private WebElement navigateAwayButton;

	// Check Vehicle
	private static final String CHECK_VEHICLE_XPATH = "//div[@data-gtm='FFQ_Auto_Vehicle_selectVehicle_checkbox']";
	@FindBy (xpath = CHECK_VEHICLE_XPATH)
	private WebElement checkAddVehicle;

	private static final String CHECK_VEHICLE_NAME_XPATH =
			"//div[@data-gtm='FFQ_Auto_Vehicle_selectVehicle_checkbox' and contains(.,'%s')]";

	private static final String EDIT_VEHICLE_NAME_XPATH =
			"//div[@data-gtm='FFQ_Auto_Vehicle_editVeh_button' and contains(@aria-label,'%s')]//a";

	@FindBy (className = "auto-module__add-vehicle-header-text")
	private static final String ADD_VEHICLE_DIALOG_HEADER_XPATH = "//div[contains(@class, 'auto-module__add-vehicle-header-text')]";

	@FindBy (xpath = ADD_VEHICLE_DIALOG_HEADER_XPATH)
	private WebElement addVehicleDialogHeader;

	@FindBy (xpath = "//button[@data-gtm='FFQ_Auto_Vehicle_Save_button']")
	private WebElement saveVehicleInformationLink;

	@FindBy (xpath = "//button[@data-gtm='FFQ_Auto_Vehicle_Add_button']")
	private WebElement addVehicleInformationLink;

	@FindBy (xpath = "//div[@id='auto-module__add-vehicle-forms']/form/p")
	private WebElement selectYMMTHeader;

	private static final String ADD_VEHICLE_BUTTON_XPATH = "//button[@data-gtm='FFQ_Auto_Vehicle_Add_button']";
	@FindBy (xpath = ADD_VEHICLE_BUTTON_XPATH)
	private WebElement addVehicleButton;

	private static final String SAVE_VEHICLE_BUTTON_XPATH = "//button[@data-gtm='FFQ_Auto_Vehicle_Save_button']";
	@FindBy (xpath = SAVE_VEHICLE_BUTTON_XPATH)
	private WebElement saveVehicleButton;

	private static final String CONTINUE_WITH_CHANGES_XPATH = "//span[contains(.,'No, continue')]";
	@FindBy (xpath = CONTINUE_WITH_CHANGES_XPATH)
	private WebElement continueWithChangesButton;

	@FindBy(id = "yearMake")
    private WebElement ymmtLabel;

	@FindBy (id = "vinId")
    private WebElement enterVINLink;

    private static final String VIN_LABEL_XPATH = "//span[contains(text(), 'enter your Vehicle')]";
    @FindBy (xpath = VIN_LABEL_XPATH)
    private WebElement enterVINLabel;

	@FindBy(xpath = "//input[@aria-label='Vehicle Identification Number']")
    private WebElement vinEntryField;

    private static final String FIND_CAR_LABEL_XPATH = "//div[contains(text(), 'find your car?')]";
    @FindBy (xpath = FIND_CAR_LABEL_XPATH)
    private WebElement carNotFoundLabel;

    @FindBy(xpath = FIND_CAR_LABEL_XPATH + "/a[contains(@class,'info-icon')]")
    private WebElement carNotFoundFAQButton;

	private static final String ENTER_YMM_LINK_XPATH = "//a[contains(@class,'auto-module__add-vehicle-text-link') and contains(text(), 'enter Year, Make')]";
	@FindBy (xpath = ENTER_YMM_LINK_XPATH)
    private WebElement enterYMMLink;

    private static final String WHERES_MY_VIN_LABEL_XPATH = "//div[contains(text(), 'my VIN?')]";
    @FindBy (xpath = WHERES_MY_VIN_LABEL_XPATH)
    private WebElement whereVINLabel;

    @FindBy(xpath = WHERES_MY_VIN_LABEL_XPATH + LINK_XPATH)
    private WebElement vinFAQButton;

    private static final String VIN_ERROR_MESSAGE_XPATH = "//lib-input-text/mat-form-field/div/div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error";
    @FindBy(xpath = VIN_ERROR_MESSAGE_XPATH)
    private WebElement vinErrorMessage;

	private static final String WAIT_FOR_YMMT_VALUES_CLASSNAME = "preloaderInputField";

    @FindBy(xpath = "//span/label/mat-label[text()='Vehicle Year']/../../../mat-select")
    private WebElement vehicleYearDropdown;

	@FindBy(xpath = "//div[contains(@class,'addVehicleBody')]/div/lib-select/mat-form-field/div/div[contains(@class,'mat-form-field-subscript-wrapper')]/div/mat-error")
	private WebElement ymmtErrorMessage;

    @FindBy(xpath = "//span/label/mat-label[text()='Vehicle Make']/../../../mat-select")
    private WebElement vehicleMakeDropdownOld;

    @FindBy(xpath = "//span/label/mat-label[text()='Vehicle Model']/../../../mat-select")
    private WebElement vehicleModelDropdownOld;

    @FindBy(xpath = "//span/label/mat-label[text()='Vehicle Make']/../../../input")
    private WebElement vehicleMakeDropdown;

    @FindBy(xpath = "//span/label/mat-label[text()='Vehicle Model']/../../../input")
    private WebElement vehicleModelDropdown;

    @FindBy(xpath = "//span/label/mat-label[text()='Vehicle type']/../../../mat-select")
    private WebElement vehicleTypeDropdown;

	private static final String ALTERNATIVE_FUELS_LABEL_XPATH = "//*[contains(text(), 'Alternative fuels')]";
	private static final String XPATH_TO_FAQ = "/../a";
    @FindBy(xpath = ALTERNATIVE_FUELS_LABEL_XPATH)
    private WebElement alternativeFuelLabel;

    @FindBy(xpath = ALTERNATIVE_FUELS_LABEL_XPATH + XPATH_TO_FAQ)
    private WebElement alternativeFuelFAQButton;

	@FindBy(xpath = "//input[@aria-label='Alternative fuels']")
    private WebElement alternativeFuelCheckbox;

	private static final String ANTI_THEFT_LABEL_XPATH = "//*[contains(text(), 'Anti-theft')]";
    @FindBy(xpath = ANTI_THEFT_LABEL_XPATH)
    private WebElement antiTheftLabel;

    @FindBy(xpath = ANTI_THEFT_LABEL_XPATH + XPATH_TO_FAQ)
    private WebElement antiTheftFAQButton;

	@FindBy(xpath = "//input[@aria-label='Anti-theft device']")
    private WebElement antiTheftCheckbox;

	private static final String OWNERSHIP_LABEL_XPATH = "//div/p[contains(text(), 'This vehicle is')]";
    @FindBy(xpath = OWNERSHIP_LABEL_XPATH)
    private WebElement ownershipLabel;

    @FindBy(xpath = OWNERSHIP_LABEL_XPATH + LINK_XPATH)
    private WebElement ownershipFAQButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Vehicle_ownership_financed_radio']")
    private WebElement financedRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Vehicle_ownership_leased_radio']")
    private WebElement leasedRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Vehicle_ownership_Owned_radio']")
    private WebElement ownedRadioButton;

	private static final String PURCHASE_LABEL_XPATH = "//div/p[contains(text(), 'purchase')]";
    @FindBy(xpath = PURCHASE_LABEL_XPATH)
    private WebElement purchaseDateLabel;

	private static final String PURCHASE_DATE_XPATH = "//lib-date-picker-monthyear-format/mat-form-field/div/div/div/input";
    @FindBy(xpath = PURCHASE_DATE_XPATH)
    private WebElement purchaseDateEntryField;

    @FindBy(xpath = "//lib-date-picker-monthyear-format/mat-form-field/div/div/div/mat-error")
	private WebElement purchaseDateErrorMessage;

	private static final String PRIMARY_USAGE_LABEL_XPATH = "//div/p[contains(text(), 'primary use')]";
    @FindBy(xpath = PRIMARY_USAGE_LABEL_XPATH)
    private WebElement primaryUsageLabel;

    @FindBy(xpath = PRIMARY_USAGE_LABEL_XPATH + LINK_XPATH)
    private WebElement primaryUsageFAQButton;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Commuting')]/../div/input")
    private WebElement commuteRadioButtonCircle;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Commuting')]")
    private WebElement commuteRadioButton;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Business')]")
    private WebElement businessRadioButton;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Pleasure')]")
    private WebElement pleasureRadioButton;

	@FindBy(xpath = "//div/p[contains(text(), 'primary use')]/../lib-radio-button/div/mat-error")
	private WebElement primaryUsageErrorMessage;

	private static final String VEHICLE_USAGE_ERROR_TEXT_ID = "error_opt_vehicleUsage";
	@FindBy(id = VEHICLE_USAGE_ERROR_TEXT_ID)
	private WebElement vehicleUsageErrorText;

	private static final String RIDESHARING_LABEL_XPATH = "//div/p[contains(text(), 'for ridesharing')]";
    @FindBy(xpath = RIDESHARING_LABEL_XPATH)
    private WebElement ridesharingLabel;

	@FindBy(xpath = RIDESHARING_LABEL_XPATH + LINK_XPATH)
    private WebElement ridesharingFAQButton;

	@FindBy(xpath = "//div/p[contains(text(), 'ridesharing')]/..//div[contains(text(), 'Yes')]")
    private WebElement usedForRideshareRadioButton;

	@FindBy(xpath = "//div/p[contains(text(), 'ridesharing')]/..//mat-radio-button[contains(@data-gtm, 'FFQ_Auto_Vehicle_rideshareYes_radio')]")
    private WebElement usedForRideshareRadioButtonGTMElement;

	@FindBy(xpath = "//div/p[contains(text(), 'ridesharing')]/..//div[contains(text(), 'No')]")
    private WebElement notUsedForRideshareRadioButton;

	@FindBy(xpath = "//div/p[contains(text(), 'ridesharing')]/..//mat-radio-button[contains(@data-gtm, 'FFQ_Auto_Vehicle_rideshareNo_radio')]")
    private WebElement notUsedForRideshareRadioButtonGTMElement;

	@FindBy(xpath = "//div/p[contains(text(), 'ridesharing')]/..//div[contains(text(), 'No')]/../div/input")
    private WebElement notUsedForRideshareNoRadioButtonCircle;

    @FindBy(xpath = "//div/p[contains(text(), 'for ridesharing')]/../lib-radio-button/div/mat-error")
	private WebElement ridesharingErrorMessage;

	@FindBy(xpath = "//div/p[contains(text(), 'overnight')]/../lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]/../div/input")
    private WebElement parkingOvernightAtResidenceRadioButtonCircle;

	@FindBy(xpath = "//div/p[contains(text(), 'overnight')]/../lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]")
    private WebElement parkingOvernightAtResidenceRadioButton;

	@FindBy(xpath = "//div/p[contains(text(), 'overnight')]/../lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]")
    private WebElement notParkingOvernightAtResidenceRadioButton;

	private static final String OVERNIGHT_PARKING_LABEL_XPATH = "//div/p[contains(text(), 'vehicle overnight')]";
	@FindBy(xpath = OVERNIGHT_PARKING_LABEL_XPATH)
    private WebElement overnightParkingLabel;

	@FindBy(xpath = OVERNIGHT_PARKING_LABEL_XPATH + LINK_XPATH)
    private WebElement overnightParkingFAQButton;

    @FindBy(xpath = "//div/p[contains(text(), 'vehicle overnight')]/../lib-radio-button/div/mat-error")
 	private WebElement overnightParkingErrorMessage;

	private static final String WHERE_DO_YOU_PARK_LABEL_XPATH = "//div/p[contains(text(), 'Where do')]";
	@FindBy(xpath = WHERE_DO_YOU_PARK_LABEL_XPATH)
    private WebElement whereDoYouParklLabel;

    @FindBy(xpath = "//span/label/mat-label[text()='Garaging address']/../../../input")
    private WebElement garagingAddressEntryField;

    @FindBy(xpath = "//input[@data-gtm='FFQ_Auto_Vehicle_garaptnumber_text']")
    private WebElement garagingApartmentEntryField;

    @FindBy(xpath = "//span/label/mat-label[text()='City']/../../../input")
    private WebElement garagingCityEntryField;

    @FindBy(xpath = "//span/label/mat-label[text()='Zip Code']/../../../input")
    private WebElement garagingZipcodeEntryField;

    private static final String TOWN_DROPDOWN_XPATH ="//mat-select[@data-gtm='FFQ_Auto_Vehicle_garagetown_dropdown']";
    @FindBy(xpath = TOWN_DROPDOWN_XPATH)
    private WebElement garagingTownSelectField;

	private static final String MILES_DRIVEN_ONE_WAY_XPATH = "//span/label/mat-label[text()='Miles you drive one-way']/../../../input";
	@FindBy(xpath = MILES_DRIVEN_ONE_WAY_XPATH)
    private WebElement milesDrivenOneWayEntryField;

    @FindBy(xpath = "//mat-form-field/div/div/div/mat-error[contains(text(),'Please enter the miles you drive one-way.')]")
    private WebElement milesDrivenOneWayErrorMessage;

    private static final String COMMUTE_DROPDOWN_XPATH = "//span/label/mat-label[text()='How often do you commute?']/../../../mat-select";
    @FindBy(xpath = COMMUTE_DROPDOWN_XPATH)
    private WebElement commuteDropdown;

    private static final String MILES_DRIVEN_PER_YEAR_XPATH = "//span/label/mat-label[text()='Miles you drive per year']/../../../input";
    @FindBy(xpath = MILES_DRIVEN_PER_YEAR_XPATH)
    private WebElement milesDrivenPerYearEntryField;

	private static final String SELECT_OPTION_XPATH = "//mat-option";

	@FindBy(xpath = "//mat-sidenav//div[starts-with(text(), ' Auto Quote ')]")
	private WebElement txtQuoteNumber;

    public VehiclesPage() throws Exception {
		super();
		waitForSpinnerToBeGone();
		checkForKnockout("VehiclesPage constructor", LOB_AUTO);
		if (isADATestingEnabled()) {
		    waitForAddVehicleDialog();
		    waitAndClickElement(carNotFoundFAQButton);
		    saveVehicleData();
		    performADATesting(getClass().getSimpleName()+"UsingYMM", MARKETING_IT, "Auto");
		    screenCapture(addVehicleDialogHeader, getClass().getSimpleName(), LOB_AUTO, false);
		    closeFAQDialog();
		    waitAndClickElement(enterVINLink);
		    waitAndClickElement(vinFAQButton);
		    saveVehicleData();
		    performADATesting(getClass().getSimpleName()+"UsingVIN", MARKETING_IT, "Auto");
		    screenCapture(addVehicleDialogHeader, getClass().getSimpleName(), LOB_AUTO, false);
		    closeFAQDialog();
		    closeAddVehicleDialog(true);
		}
	}

	public boolean validatePageTitle() {
		 return isExpectedTextDisplayed(vehiclesPageHeader, VEHICLES_PAGE_HEADER);
	}

	public boolean validateAddVehicleErrorMessages(String stateCode, FarmersSoftAssert fsa) throws Exception{
		waitForSpinnerToBeGone();
		waitForAddVehicleDialog();
		saveVehicleData();
		waitAndClickElement(addVehicleDialogHeader);
		saveVehicleData();
		waitElementBeVisible(ymmtErrorMessage);
		scrollToBottomOfPage();
		verifyElementExpectedContent(setErrorElementsList(stateCode), setExpectedErrorContentMap(stateCode), fsa);
		scrollToTopOfPage();
		waitAndClickElement(enterVINLink);
		saveVehicleData();
		return isExpectedTextDisplayed(vinErrorMessage, VIN_ERROR_MESSAGE);
	}

	public boolean validateAddVehicleFAQButtons(String stateCode, FarmersSoftAssert fsa) throws Exception {
		waitForSpinnerToBeGone();
		waitForAddVehicleDialog();
		waitElementBeVisible(carNotFoundFAQButton);
		waitAndClickElement(enterVINLink);
		waitElementBeVisibleClickable(vinFAQButton);
		validateFAQ(vinFAQButton, VIN_FAQ_TITLE, VIN_FAQ_TEXT, fsa);
		waitAndClickElement(enterYMMLink);
		waitElementBeVisibleClickable(carNotFoundFAQButton);
		int faqCount = 3; // Three FAQs always there
		String cantFindCarHelpText = isEasternExpansionState(stateCode)? CANT_FIND_CAR_FAQ_TEXT_EE: CANT_FIND_CAR_FAQ_TEXT;
		validateFAQ(carNotFoundFAQButton, CANT_FIND_CAR_FAQ_TITLE, cantFindCarHelpText, fsa);
		if (isAlternativeFuelState(stateCode)) {
			validateFAQ(alternativeFuelFAQButton, ALTERNATIVE_FUELS_FAQ_TITLE, ALTERNATIVE_FUELS_FAQ_TEXT, fsa);
			faqCount++;
		}
		if (isAntiTheftState(stateCode)) {
			validateFAQ(antiTheftFAQButton, ANTI_THEFT_DEVICE_FAQ_TITLE, ANTI_THEFT_DEVICE_FAQ_TEXT, fsa);
			faqCount++;
		}
		validateFAQ(ownershipFAQButton, OWNERSHIP_FAQ_TITLE, OWNERSHIP_FAQ_TEXT, fsa);
		String vehicleUsageFAQText = stateCode.equals(NC)? PRIMARY_USAGE_FAQ_TEXT_NC : PRIMARY_USAGE_FAQ_TEXT;
		validateFAQ(primaryUsageFAQButton, PRIMARY_USAGE_FAQ_TITLE, vehicleUsageFAQText, fsa);
		scrollToElement(buttonNext);
		if (isFlexState(stateCode)) {
			validateFAQ(ridesharingFAQButton, stateCode.equals(AL)? RIDESHARING_FAQ_TITLE : RIDESHARING_FAQ_TITLE_VERSION2, RIDESHARING_FAQ_TEXT_VERSION2, fsa);
			faqCount++;
		} else {
			String faqTitle = stateCode.equals(NC)? RIDESHARING_FAQ_TITLE_NC : RIDESHARING_FAQ_TITLE;
			String faqText = stateCode.equals(NC)? RIDESHARING_FAQ_TEXT_NC : RIDESHARING_FAQ_TEXT;
			validateFAQ(ridesharingFAQButton, faqTitle, faqText, fsa);
			faqCount++;
		}
		if (isAskOvernightParkingState(stateCode)) {
			validateFAQ(overnightParkingFAQButton, OVERNIGHT_PARKING_FAQ_TITLE, OVERNIGHT_PARKING_FAQ_TEXT, fsa);
			faqCount++;
		}
		List<WebElement> faqsInView = driver().findElements(By.xpath("//*[contains(@class, 'info-icon') and not(contains(@aria-label, 'Potential Savings'))]"));
		int numberOfFAQsInDialog = faqsInView.size();
		boolean correctNumber = numberOfFAQsInDialog == faqCount || numberOfFAQsInDialog/2 == faqCount;
		Assert.assertTrue(correctNumber, faqCount + " FAQs expected in this page equals " + numberOfFAQsInDialog + " FAQs found");
		return true;
	}

	public boolean enterYMMTDataForFirstVehicle(SqlVehicle firstVehicle) throws Exception {
		waitForSpinnerToBeGone();
		waitForAddVehicleDialog();
		return enterYMMTInformation(firstVehicle);
	}

	public boolean addAVehicle(SqlVehicle vehicleInfo, SqlApplicant applicant) throws Exception {
		boolean vehicleAdded = false;
		String stateCode = applicant.getStateCode();
		List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC26316", "TC26320", "TC26321", "TC26328"));
		writeTestcaseState("VehiclesPage.addAVehicle", stateCode, rallyTestcasesCovered, FAILED);
		waitForSpinnerToBeGone();
		waitForAddVehicleDialog();
		if (vehicleInfo.isUseVIN()) {
			waitAndClickElement(enterVINLink);
			List<String> rallyCasesCovered = new ArrayList<>(Arrays.asList("TC39078", "TC39079", "TC39080"));
			writeTestcaseState("VehiclesPage.enterVINInformation", stateCode, rallyCasesCovered, FAILED);
			vehicleAdded = enterVINInformation(vehicleInfo.getVehicleVIN());
			writeTestcaseState("VehiclesPage.enterVINInformation", stateCode, rallyCasesCovered, PASSED);
		} else {
			vehicleAdded = enterYMMTInformation(vehicleInfo);
		}
		if (vehicleAdded) {
			if (isAntiTheftState(stateCode)) {
				enterAntiTheftDevicePresent(vehicleInfo.isAntiTheftDevice());
			} else {
				Assert.assertFalse(isElementPresentByXPath(ANTI_THEFT_LABEL_XPATH), "Anti-theft checkbox present");
			}
			if (isAlternativeFuelState(stateCode)) {
				if (!vehicleInfo.isUseVIN()) {
					enterAlternativeFuelVehicle(vehicleInfo.isAlternativeFuels());
				}
			} else {
				Assert.assertFalse(isElementPresentByXPath(ALTERNATIVE_FUELS_LABEL_XPATH), "Alternative fuels checkbox present");
			}
			enterVehicleOwnership(vehicleInfo.getOwnership());
			enterVehiclePurchaseDate(isAskPurchaseDateState(stateCode), vehicleInfo);
			enterVehiclePrimaryUse(vehicleInfo.getVehicleUsage());
			if (vehicleInfo.getVehicleUsage().equals(COMMUTE)) {
				enterMilesDrivenOneWay(isAskOneWayMilesDrivenState(stateCode), vehicleInfo.getOneWayMiles());
				enterCommuteFrequency(isAskCommuteFrequencyState(stateCode), vehicleInfo.getCommute());
			}
			enterVehicleRidesharingStatus(vehicleInfo.isRideSharing());
			enterVehicleOvernightParkingLocation(applicant, vehicleInfo);
			enterMilesDrivenPerYear(isAskMilesDrivenPerYearState(stateCode), vehicleInfo.getAnnualMiles());
			saveVehicleData();
			if (isElementPresentByXPath(TOWN_DROPDOWN_XPATH)) {
				selectValueInDropdown(applicant.getCity().toUpperCase(Locale.US), garagingTownSelectField, notParkingOvernightAtResidenceRadioButton);
				saveVehicleData();
			}
			//check to see if three business cars are being used
			if (applicant.getTestScenario().contains("3 business vehicles") && isElementPresent(By.id(VEHICLE_USAGE_ERROR_TEXT_ID), 2)) {
				Assert.assertEquals(getTextFromElement(vehicleUsageErrorText), "Business vehicle use is only allowed on two vehicles per policy.", "Business vehicle limit exceeded check");
				scrollAndClickOnElement(pleasureRadioButton);
				saveVehicleData();
			}
			writeTestcaseState("VehiclesPage.addAVehicle", stateCode, rallyTestcasesCovered, PASSED);
		}
		return vehicleAdded && noErrorsPresentInPage() && !isElementPresent(By.xpath(SAVE_VEHICLE_BUTTON_XPATH), 2) && !isElementPresent(By.xpath(ADD_VEHICLE_BUTTON_XPATH), 2);
	}

	private void saveVehicleData() {
		boolean useAddVehicleButton = isElementPresentByXPath(ADD_VEHICLE_BUTTON_XPATH);
		if (useAddVehicleButton) {
			scrollAndClickOnElement(addVehicleButton);
		} else {
			scrollAndClickOnElement(saveVehicleButton);
		}
		waitForSpinnerToBeGone();
		if (isElementPresentByXPath(CONTINUE_WITH_CHANGES_XPATH )) {
			scrollAndClickOnElement(continueWithChangesButton);
			waitForSpinnerToBeGone();
			if (useAddVehicleButton) {
				scrollAndClickOnElement(addVehicleButton);
			} else {
				scrollAndClickOnElement(saveVehicleButton);
			}
			waitForSpinnerToBeGone();
		}
	}

	public DriversPage forwardToDriversPage() throws Exception {
		scrollToBottomOfPage();
		clickElement(buttonNext);
		waitForSpinnerToBeGone();
		return new DriversPage(false);
	}

	public void validateGTMTags(FarmersSoftAssert fsa) {
		if (isElementPresentByXPath(ADD_VEHICLE_DIALOG_HEADER_XPATH)) {
			verifyElementExpectedAttribute(getListWithPageElements(), getMapWithExpectedGTMTags(), "data-gtm", fsa);
		}
	}

	public void validateAddVehicleDialogLabels(String stateCode, FarmersSoftAssert fsa) throws Exception {
		waitForSpinnerToBeGone();
		waitForAddVehicleDialog();
		waitElementBeVisibleClickable(carNotFoundFAQButton);
		waitAndClickElement(enterVINLink);
		fsa.assertEquals(getTextFromElement(enterVINLabel), VIN_LABEL, VIN_LABEL);
		fsa.assertEquals(getTextFromElement(whereVINLabel), WHERES_VIN_LABEL, WHERES_VIN_LABEL);
		waitAndClickElement(enterYMMLink);
		fsa.assertEquals(getTextFromElement(ymmtLabel), YMMT_LABEL, YMMT_LABEL);
		fsa.assertEquals(getTextFromElement(carNotFoundLabel), CAR_NOT_FOUND_LABEL, CAR_NOT_FOUND_LABEL);
		if (isAlternativeFuelState(stateCode)) {
			fsa.assertEquals(getTextFromElement(alternativeFuelLabel), ALTERNATIVE_FUELS_FAQ_TITLE, ALTERNATIVE_FUELS_FAQ_TITLE);
		}
		if (isAntiTheftState(stateCode)) {
			fsa.assertEquals(getTextFromElement(antiTheftLabel), ANTI_THEFT_DEVICE_FAQ_TITLE, ANTI_THEFT_DEVICE_FAQ_TITLE);
		}
		fsa.assertEquals(getTextFromElement(ownershipLabel), OWNERSHIP_LABEL, OWNERSHIP_LABEL);
		fsa.assertEquals(getTextFromElement(financedRadioButton), FINANCED_LABEL, FINANCED_LABEL);
		fsa.assertEquals(getTextFromElement(leasedRadioButton), LEASED_LABEL, LEASED_LABEL);
		fsa.assertEquals(getTextFromElement(ownedRadioButton), OWNED_LABEL, OWNED_LABEL);
		if (isAskPurchaseDateState(stateCode)) {
			fsa.assertEquals(getTextFromElement(purchaseDateLabel), PURCHASE_DATE_LABEL, PURCHASE_DATE_LABEL);
		}
		fsa.assertEquals(getTextFromElement(primaryUsageLabel), PRIMARY_USE_LABEL, PRIMARY_USE_LABEL);
		scrollToElementBottom(buttonNext);
		fsa.assertEquals(getTextFromElement(commuteRadioButton), COMMUTE_LABEL, COMMUTE_LABEL);
		fsa.assertEquals(getTextFromElement(businessRadioButton), BUSINESS_LABEL, BUSINESS_LABEL);
		fsa.assertEquals(getTextFromElement(pleasureRadioButton), PLEASURE_LABEL, PLEASURE_LABEL);
		if (isFlexState(stateCode)) {
			fsa.assertEquals(getTextFromElement(ridesharingLabel), RIDESHARING_ANDOR_DELIVERY_LABEL, RIDESHARING_ANDOR_DELIVERY_LABEL);
		} else if (stateCode.equals(NC)){
			fsa.assertEquals(getTextFromElement(ridesharingLabel), RIDESHARING_OR_DELIVERY_LABEL, RIDESHARING_OR_DELIVERY_LABEL);
		} else {
			fsa.assertEquals(getTextFromElement(ridesharingLabel), RIDESHARING_LABEL, RIDESHARING_LABEL);
		}
		if (isAskOvernightParkingState(stateCode)) {
			fsa.assertTrue(getTextFromElement(overnightParkingLabel).contains(OVERNIGHT_PARKING_LABEL), OVERNIGHT_PARKING_LABEL);
			scrollAndClickOnElement(notParkingOvernightAtResidenceRadioButton);
			fsa.assertEquals(getTextFromElement(whereDoYouParklLabel), WHERE_DO_YOU_PARK_LABEL, WHERE_DO_YOU_PARK_LABEL);
		}
	}

	public void closeAddVehicleDialog(boolean discardChanges){
		if (isElementPresent(By.xpath(ADD_VEHICLE_DIALOG_HEADER_XPATH), 2)) {
			clickElement(closeAddVehicleDialogButton);
		}
		if (isElementPresent(By.xpath(NAVIGATE_AWAY_XPATH), 2)) {
			if (discardChanges) {
				clickElement(navigateAwayButton);
			} else {
				//This actually means stay and continue editing
				clickElement(continueChangingButton);
			}
		}
	}

	public boolean saveQuoteAndFinishLater(SqlApplicant applicant) throws Exception {
		logAutoQuoteNumber(applicant);
		return saveAutoQuoteAndFinishLater(applicant, VEHICLES_PAGE_AUTO, applicant.isSaveAndRetrieveVehiclesPage());
	}

	private List<WebElement> getListWithPageElements() {
		Log.info("Getting List with Vehicles Page elements");
		List<WebElement> vpElements = new ArrayList<>();
		vpElements.add(vehicleYearDropdown);
		vpElements.add(vehicleTypeDropdown);
		return vpElements;
	}

	private Map<WebElement, String> getMapWithExpectedGTMTags() {
		Log.info("Getting Map with expected Vehicles Page elements' GTM values");
		Map<WebElement,String> expectedElementGTMMap = new HashMap<>();
		expectedElementGTMMap.put(vehicleYearDropdown, "FFQ_Auto_Vehicle_year_dropdown");
		expectedElementGTMMap.put(vehicleTypeDropdown, "FFQ_Auto_Vehicle_vehicletype_dropdown");
		return expectedElementGTMMap;
	}

	private boolean enterVINInformation(String vehicleVIN) {
		if (isElementPresentByID(enterVINLink)) {
			clickElement(enterVINLink);
			waitElementBeVisibleClickable(vinEntryField);
		}
		sendKeysToElement(vinEntryField, vehicleVIN);
		waitForSpinnerToBeGone();
		return !isElementPresentByXPath(VIN_ERROR_MESSAGE_XPATH);
	}

	private boolean enterYMMTInformation(SqlVehicle vehicleInfo) throws Exception {
		if (isElementPresentByXPath(ENTER_YMM_LINK_XPATH)) {
			clickElement(enterYMMLink);
			waitElementBeVisibleClickable(vehicleYearDropdown);
		}
		waitForSpinnerToBeGone();
		boolean isAllGood = selectValueInDropdown(vehicleInfo.getVehicleYear(), vehicleYearDropdown, addVehicleDialogHeader);
		if (!isAllGood) {
			//api that returns YMMT data sometimes does not return data in time for automation, reopening page might help
			closeAddVehicleDialog(true);
			waitElementBeVisibleClickable(addVehicleLink);
			clickOnHiddenElement(addVehicleLink);
			waitElementBeVisibleClickable(vehicleYearDropdown);
			isAllGood = selectValueInDropdown(vehicleInfo.getVehicleYear(), vehicleYearDropdown, addVehicleDialogHeader);
		}
		if (isAllGood) {
			waitElementBeVisibleClickable(vehicleMakeDropdown);
			longWaitForElementToBeGoneByClass(WAIT_FOR_YMMT_VALUES_CLASSNAME);
			String vehicleMake = vehicleInfo.getVehicleMake();
			if (vehicleMake.equals("FORD TRUCK")) {
				vehicleMake = "FORD";
			}
			isAllGood = selectValueInDropdown(vehicleMake, vehicleMakeDropdown, addVehicleDialogHeader);
			if (isAllGood) {
				longWaitForElementToBeGoneByClass(WAIT_FOR_YMMT_VALUES_CLASSNAME);
				isAllGood = selectValueInDropdown(vehicleInfo.getVehicleModel(), vehicleModelDropdown, addVehicleDialogHeader);
				if (isAllGood) {
					String vehicleType = vehicleInfo.getVehicleType();
					longWaitForElementToBeGoneByClass(WAIT_FOR_YMMT_VALUES_CLASSNAME);
					isAllGood = selectValueInDropdown(vehicleType, vehicleTypeDropdown, addVehicleDialogHeader);
					if (!isAllGood) {
						logVehicleErrorMessage(vehicleTypeDropdown, vehicleType);
					}
				} else {
					logVehicleErrorMessage(vehicleModelDropdown, vehicleInfo.getVehicleModel());
				}
			}else {
				logVehicleErrorMessage(vehicleMakeDropdown, vehicleMake);
			}
		} else {
			logVehicleErrorMessage(vehicleYearDropdown, vehicleInfo.getVehicleYear());
		}
		return isAllGood;
	}

	private void logVehicleErrorMessage(WebElement dropdown, String expected) throws Exception {
		List<String> listOfAvailableValues = getDropdownOptions(dropdown, false);
		Log.error(NEWLINE + dropdown + " not set correctly, expected to find<" + expected + "> and dropdown contains :" + listOfAvailableValues);
	}

	private void enterVehicleOwnership(String ownership) throws Exception {
		scrollToElement(ownershipFAQButton);
		switch (ownership) {
		case FINANCED_LABEL:
			clickElement(financedRadioButton);
			break;
		case LEASED_LABEL:
			clickElement(financedRadioButton);
			break;
		case OWNED_LABEL:
			clickElement(ownedRadioButton);
			break;
		default :
			Log.error("Invalid ownership type: " + ownership);
			break;
		}
	}

	private void enterVehiclePrimaryUse(String vehicleUsage) {
		Assert.assertTrue(commuteRadioButtonCircle.isSelected(), "Commute radio button selected");
		switch (vehicleUsage) {
		case COMMUTE:
			scrollAndClickOnElement(commuteRadioButton);
			break;
		case BUSINESS_LABEL:
			scrollAndClickOnElement(businessRadioButton);
			break;
		case PLEASURE_LABEL:
			scrollAndClickOnElement(pleasureRadioButton);
			break;
		default :
			Log.error("Invalid usage type: " + vehicleUsage);
			break;
		}
	}

	private void enterVehicleRidesharingStatus(boolean usedForRidesharing) throws Exception {
		scrollToElement(ownershipFAQButton);
		if (usedForRidesharing) {
			clickElement(usedForRideshareRadioButton);
		} else {
			clickElement(notUsedForRideshareRadioButton);
		}
	}

	private void enterVehicleOvernightParkingLocation(SqlApplicant applicant, SqlVehicle vehicleInfo) {
		if (isAskOvernightParkingState(applicant.getStateCode())) {
			if (vehicleInfo.isParkInresidentAddress()) {
				scrollAndClickOnElement(parkingOvernightAtResidenceRadioButton);
			} else {
				scrollAndClickOnElement(notParkingOvernightAtResidenceRadioButton);
				scrollAndClickOnElement(garagingZipcodeEntryField);
				sendKeysToElement(garagingAddressEntryField, applicant.getGaragingAddress());
				sendKeysToElement(garagingCityEntryField, applicant.getCity());
				sendKeysToElement(garagingZipcodeEntryField, applicant.getZipCode());
			}
		}
	}

	private void enterMilesDrivenPerYear(boolean isAskMilesDrivenPerYearState, int annualMiles) {
		if (isAskMilesDrivenPerYearState) {
			sendKeysToElement(milesDrivenPerYearEntryField, annualMiles);
		}
	}

	private void enterMilesDrivenOneWay(boolean isAskOneWayMilesDrivenState, int oneWayMiles) {
		if (isAskOneWayMilesDrivenState) {
			sendKeysToElement(milesDrivenOneWayEntryField, oneWayMiles);
		}
	}

	private void enterVehiclePurchaseDate(boolean isAskPurchaseDateState, SqlVehicle vehicleInfo) {
		if (isAskPurchaseDateState) {
			sendKeysToElement(purchaseDateEntryField, vehicleInfo.getPurchaseDate());
		}
	}

	private void enterCommuteFrequency(boolean isAskCommuteFrequencyState, String commuteFrequency) throws Exception {
		if (isAskCommuteFrequencyState) {
			selectValueInDropdown(commuteFrequency, commuteDropdown, commuteRadioButton );
		}
	}

	private void enterAntiTheftDevicePresent(boolean hasAntiTheftDevice) {
		scrollElementToMiddle(antiTheftCheckbox);
		setCheckboxTo(antiTheftCheckbox, hasAntiTheftDevice);
	}

	private void enterAlternativeFuelVehicle(boolean isAlternativeFuelVehicle) {
		scrollElementToMiddle(alternativeFuelCheckbox);
		setCheckboxTo(alternativeFuelCheckbox, isAlternativeFuelVehicle);
	}

	private List<WebElement> setErrorElementsList(String stateCode){
		List<WebElement> errorMessageElements = new ArrayList<>();
		errorMessageElements.add(ymmtErrorMessage);
		if (isAskPurchaseDateState(stateCode)){
			clickElement(purchaseDateEntryField);
			saveVehicleData();
			errorMessageElements.add(purchaseDateErrorMessage);
		}
		if (isAskOneWayMilesDrivenState(stateCode) && isValueNotPrefilledState(stateCode)) {
			errorMessageElements.add(milesDrivenOneWayErrorMessage);
		}
		return errorMessageElements;
	}

	private Map<WebElement, String> setExpectedErrorContentMap(String stateCode) {
		Map<WebElement,String> errorMessagesMap = new HashMap<>();
		errorMessagesMap.put(ymmtErrorMessage, YEAR_ERROR_MESSAGE);
		if (isAskPurchaseDateState(stateCode)){
			clickElement(purchaseDateEntryField);
			saveVehicleData();
			errorMessagesMap.put(purchaseDateErrorMessage, PURCHASE_ERROR_MESSAGE);
		}
		if (isAskOneWayMilesDrivenState(stateCode) && isValueNotPrefilledState(stateCode)) {
			errorMessagesMap.put(milesDrivenOneWayErrorMessage, ONEWAY_MILES_ERROR_MESSAGE);
		}
		return errorMessagesMap;
	}

	private void waitForAddVehicleDialog() throws Exception {
		if (isElementPresentByXPath(ADD_VEHICLE_DIALOG_HEADER_XPATH)) {
			if (!isElementPresentByXPath("//mat-radio-button/label/div[contains(text(), 'Financed')]")) {
				closeAddVehicleDialog(true);
				scrollToElement(buttonNext);
				clickOnHiddenElement(addVehicleLink);
				waitElementBeVisible(financedRadioButton);
			}
		} else {
			waitForSpinnerToBeGone();
			scrollToElementBottom(buttonNext);
			clickOnHiddenElement(addVehicleLink);
			waitElementBeVisible(financedRadioButton);
		}
	}

	private boolean isAlternativeFuelState(String stateCode) {
		return isEasternExpansionState(stateCode);
	}

	private boolean isAntiTheftState(String stateCode) {
		List<String> antiTheftStates = new ArrayList<>(Arrays.asList(IL, KY, NM, PA));
		return antiTheftStates.contains(stateCode);
	}

	private boolean isAskOvernightParkingState(String stateCode) {
		List<String> askOvernightParkingStates = new ArrayList<>(Arrays.asList(FL, GA, OH, VA));
		return isFlexState(stateCode) || isEasternExpansionState(stateCode) || askOvernightParkingStates.contains(stateCode);
	}

	private boolean isAskPurchaseDateState(String stateCode) {
		List<String> askPurchaseDateStates = new ArrayList<>(Arrays.asList(CA));
		return askPurchaseDateStates.contains(stateCode);
	}

	private boolean isAskMilesDrivenPerYearState(String stateCode) {
		List<String> askMilesDrivenPerYearStates = new ArrayList<>(Arrays.asList(CA));
		return askMilesDrivenPerYearStates.contains(stateCode);
	}

	private boolean isAskCommuteFrequencyState(String stateCode) {
		List<String> askCommuteFrequencyStates = new ArrayList<>(Arrays.asList(CA));
		return askCommuteFrequencyStates.contains(stateCode);
	}

	private boolean isAskOneWayMilesDrivenState(String stateCode) {
		List<String> askOneWayMilesDrivenStates = new ArrayList<>(Arrays.asList(CA, NJ));
		return askOneWayMilesDrivenStates.contains(stateCode);
	}

	private boolean isValueNotPrefilledState(String stateCode) {
		List<String> valuePrefilledStates = new ArrayList<>(Arrays.asList(CA, FL, OH, OK, MO, NY, VA));
		return !valuePrefilledStates.contains(stateCode);
	}

	public void addAVehicle() throws Exception {
		boolean bOpen = false;
		try {
			waitElementBeVisibleClickable(closeAddVehicleDialogButton);
		} catch (NoSuchElementException e) {
			waitAndClickElement(addVehicleLink);
			bOpen = true;
		}
		waitForAddVehicleDialog();
		waitAndClickElement(vehicleYearDropdown);
		selectValue(null);
		waitAndClickElement(vehicleMakeDropdown);
		selectValue(null);
		waitAndClickElement(vehicleModelDropdown);
		selectValue(null);
		waitAndClickElement(vehicleTypeDropdown);
		selectValue(null);
		if (isElementDisplayed(By.xpath(PURCHASE_DATE_XPATH))) {
			sendKeysToElement(purchaseDateEntryField,
					LocalDate.now().plusMonths(-1).format(DateTimeFormatter.ofPattern("MM/yyyy")));
		}
		if (isElementDisplayed(By.xpath(MILES_DRIVEN_ONE_WAY_XPATH))) {
			sendKeysToElement(milesDrivenOneWayEntryField, "10");
		}
		if (isElementDisplayed(By.xpath(COMMUTE_DROPDOWN_XPATH))) {
			waitAndClickElement(commuteDropdown);
			selectValue("5 days a week");
		}
		if (bOpen) {
			waitAndClickElement(saveVehicleInformationLink);
		} else {
			waitAndClickElement(addVehicleInformationLink);
		}
		waitForSpinnerToBeGone();
	}

	public void addAVehicleADPF(@Nullable String primaryUse) throws Exception {
		waitForSpinnerToBeGone();
		waitForAddVehicleDialog();
		if (primaryUse != null) {
			// alter primaryUse to a different value
			if (commuteRadioButtonCircle.isSelected() && !primaryUse.equals("Commuting")) {
				enterVehiclePrimaryUse(primaryUse);
			} else {
				enterVehiclePrimaryUse("Commuting");
			}
		}
		if (isElementDisplayed(By.xpath(ADD_VEHICLE_BUTTON_XPATH))) {
			waitAndClickElement(addVehicleInformationLink);
			sleep(2);
			if (isElementDisplayed(By.xpath(ADD_VEHICLE_BUTTON_XPATH))) {
				waitAndClickElement(addVehicleInformationLink);
			}
		} else {
			waitAndClickElement(saveVehicleInformationLink);
			sleep(2);
			if (isElementDisplayed(By.xpath(SAVE_VEHICLE_BUTTON_XPATH))) {
				waitAndClickElement(saveVehicleInformationLink);
			}
		}
		waitForSpinnerToBeGone();
	}

	public String getQuoteNumber() {
		return getRedesignedQuoteNumber();
	}

	public void selectValue (@Nullable String value) throws Exception {
    	sleep(1);
    	String xPath = (value == null) ? SELECT_OPTION_XPATH : SELECT_OPTION_XPATH + "[.='" + value + "']";
		waitAndClickElement(driver().findElement(By.xpath(xPath)));
		sleep(1);
	}

	public void checkVehicleByName(String value) throws Exception {
		waitForSpinnerToBeGone();
		WebElement weVCard = driver().findElement(By.xpath(String.format(CHECK_VEHICLE_NAME_XPATH, value)));
		waitAndClickElement(weVCard);
	}

	public void editVehicleByName(String value) throws Exception {
		waitForSpinnerToBeGone();
		WebElement weEdit = driver().findElement(By.xpath(String.format(EDIT_VEHICLE_NAME_XPATH, value)));
		waitAndClickElement(weEdit);
	}

	public void logAutoQuoteNumber(SqlApplicant applicant) throws Exception {
		closeAddVehicleDialog(true);
		writeCreatedQuoteInformationToFile("Legacy Auto - " + getRedesignedQuoteNumber() + SPACE + applicant.logInformationString());
	}

	public boolean verifyVehiclePresent(SqlVehicle vehicleInfo) {
		waitForSpinnerToBeGone();
		if (vehicleInfo.isUseVIN()) {
			int vinCount = listOfVINs.size();
			for (int j=0; j<vinCount; j++) {
				WebElement vinListed = listOfVINs.get(j);
				if (getTextFromElement(vinListed).contains(vehicleInfo.getVehicleVIN().substring(14))) {
					return true;
				}
			}
		} else {
			int vehiclesCount = listOfVehicles.size();
			for (int index=0; index<vehiclesCount; index++) {
				String lookForVehicle = vehicleInfo.getVehicleYear() + SPACE + vehicleInfo.getVehicleMake() + SPACE + vehicleInfo.getVehicleModel();
				WebElement vehicleListed = listOfVehicles.get(index);
				if (getTextFromElement(vehicleListed).equals(lookForVehicle)) {
					return true;
				}
			}
		}
		return false;
	}
}
