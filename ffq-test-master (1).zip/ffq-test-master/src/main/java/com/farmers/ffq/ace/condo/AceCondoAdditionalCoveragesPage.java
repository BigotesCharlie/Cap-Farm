package com.farmers.ffq.ace.condo;

import com.farmers.ffq.ace.hrc.common.AceHRCAdditionalCoveragesBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.text.NumberFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCReviewQuoteBasePage.LIMITED_MOLD;
import static com.farmers.ffq.common.enums.CoveragesNameAceHome.Coverage.IDENTITY_FRAUD;
import static com.farmers.ffq.utils.CurrencyFormat.convertCurrencyStringToDouble;
import static com.farmers.ffq.utils.CurrencyFormat.convertDoubleToCurrencyString;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoAdditionalCoveragesPage extends AceHRCAdditionalCoveragesBasePage {

    private static final String PAGE_SUBTITLE = "Pick and choose optional coverages you want for your property. (optional)";
    private static final String RESIDENCE_GLASS = "Residence glass";
    private final List<String> ADDITIONAL_COVERAGES_TITLES = Arrays.asList(IDENTITY_SHIELD, PERSONAL_INJURY,
            SEWER_AND_DRAIN, LIMITED_MOLD, RESIDENCE_GLASS, INCREASED_LIMITS_FOR_VALUABLES_TITLE);
    private final List<String> INCREASED_VALUABLES_CHECKBOXES_LABELS = Arrays.asList("Jewelry ($1,000 per item still applies)", "Silverware",
            "Firearms", "Securities", "Off-premises portable electronic equipment");

    private static final String OPTIONAL_COVERAGES_XPATH = "//tr/td[text()='All other coverages']/following-sibling::td";
    @FindBy(xpath = QUOTE_PRESENTMENT_DESKTOP_XPATH + OPTIONAL_COVERAGES_XPATH)
    private WebElement quoteAllOtherCoveragesPriceOnCardDesktop;
    @FindBy(xpath = QUOTE_PRESENTMENT_MOBILE_XPATH + OPTIONAL_COVERAGES_XPATH)
    private WebElement quoteAllOtherCoveragesPriceOnCardMobile;

    @FindBy(xpath = "//div[@id='sewer']//label[contains(@class,'tui-input-text-2')][1]")
    private WebElement headerSewerDrain1;
    @FindBy(xpath = "//div[@id='sewer']//label[contains(@class,'tui-input-text-2')][2]")
    private WebElement headerSewerDrain2;
    @FindBy(xpath = "//mat-radio-group[@aria-label='coverage limit for Sewer and drain']//mat-radio-button")
    private List<WebElement> radioButtonsSewerDrain;
    @FindBy(xpath = "//div[@id='sewer']//label/following-sibling::div")
    private WebElement footerSewerDrain;
    @FindBy(xpath = "//div[@id='sewer']//label/following-sibling::div/label[1]")
    private WebElement footerSewerDrainLabel1;
    @FindBy(xpath = "//div[@id='sewer']//label/following-sibling::div/label[2]")
    private WebElement footerSewerDrainLabel2;
    @FindBy(xpath = "//mat-button-toggle-group[@aria-label='Coverage type']//button[.='Basic']")
    private WebElement matButtonSewerDrainBasic;
    @FindBy(xpath = "//div[@id='sewer']//label/following-sibling::div/div")
    private WebElement footerSewerDrainMD;
    @FindBy(xpath = "//mat-button-toggle-group[@aria-label='Coverage type']//button[.='Extended']")
    private WebElement matButtonSewerDrainExtended;
    @FindBy(xpath = "//mat-button-toggle-group[@aria-label='What level of coverage do you want?']//button[.='Full']")
    private WebElement matButtonSewerDrainFull;
    @FindBy(xpath = "//mat-button-toggle-group[@aria-label='What level of coverage do you want?']//button[.='Partial']")
    private WebElement matButtonSewerDrainPartial;
    @FindBy(xpath = "//div[@id='sewer']//mat-card//input")
    private WebElement inputSewerDrain;
    @FindBy(xpath = "//div[@id='sewer']//mat-button-toggle[.='remove']")
    private WebElement buttonSewerDrainMinus;
    @FindBy(xpath = "//div[@id='sewer']//mat-button-toggle[.='add']")
    private WebElement buttonSewerDrainPlus;
    @FindBy(xpath = "//div[@id='sewer']//mat-hint")
    private WebElement subTextInputSewerDrain;

    @FindBy(xpath = "//div[@id='increasedValuables']//label[contains(@class,'tui-input-text-2')]")
    private WebElement headerIncreasedValuables;
    @FindBy(xpath = "//div[@id='increasedValuables']//button[contains(@aria-label,'info icon')]")
    private WebElement headerIncreasedValuablesInfoIcon;
    @FindBy(xpath = "//div[@id='increasedValuables']//mat-checkbox")
    private List<WebElement> checkboxesIncreasedValuables;
    @FindBy(xpath = "//div[@id='increasedValuables']//div[contains(@class,'total-combined-tally-container')]")
    private WebElement footerIncreasedValuables;
    private final String INCREASED_VALUABLES_CHECKBOXES_FIELD_XPATH = "(//div[@id='increasedValuables']//mat-checkbox)";
    @FindBy(xpath = INCREASED_VALUABLES_CHECKBOXES_FIELD_XPATH + "[1]//input")
    private WebElement inputIncreasedCoverageJewelry;
    private final String INCREASED_VALUABLES_INCREASE_LIMIT_BUTTON_XPATH = "(//div[@id='increasedValuables']//button[contains(@class,'increase-button')])";
    @FindBy(xpath = INCREASED_VALUABLES_INCREASE_LIMIT_BUTTON_XPATH + "[1]")
    private WebElement increaseCoverageJewelry;
    private final String INCREASED_VALUABLES_DECREASE_LIMIT_BUTTON_XPATH = "(//div[@id='increasedValuables']//button[contains(@class,'decrease-button')])";
    @FindBy(xpath = INCREASED_VALUABLES_DECREASE_LIMIT_BUTTON_XPATH + "[1]")
    private WebElement decreaseCoverageJewelry;
    @FindBy(xpath = "//app-increase-valuables-info-dialog//div[contains(@class,'tui-field-label')]")
    private WebElement increasedValuablesInfoDialogSubtitle;
    @FindBy(xpath = "//app-increase-valuables-info-dialog//div/ul/li")
    private List<WebElement> listIncreasedValuablesInfoDialogItems;

    @FindBy(xpath = "//div[@id='Earthquake']//label")
    private WebElement headerEarthquake;
    @FindBy(xpath = "//div[@id='Earthquake']//mat-radio-button")
    private List<WebElement> radioButtonsEarthquake;
    @FindBy(xpath = "//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]")
    private List<WebElement> headersEarthquakeSection;
    @FindBy(xpath = "//div[@id='Earthquake']//label[contains(@class,'tui-input-text-2')]/following-sibling::div//li")
    private List<WebElement> listFoundationsEarthquakeSection;
    @FindBy(xpath = "//div[@id='Earthquake']//mat-button-toggle")
    private List<WebElement> toggleButtonsEarthquake;
    @FindBy(xpath = "//div[@id='Earthquake']//button[contains(@aria-label,'info icon')]")
    private WebElement earthquakeInfoIcon;
    @FindBy(xpath = "//app-earthquake-coverage-dialog//h4")
    protected WebElement earthquakeCoverageInfoDialogHeader;
    @FindBy(xpath = "//app-earthquake-coverage-dialog//div/span[contains(@class,'tui-subtitle-2')]")
    private List<WebElement> earthquakeInfoDialogSubheaders;
    @FindBy(xpath = "//app-earthquake-coverage-dialog//div[contains(@class,'tui-body')]")
    private List<WebElement> earthquakeInfoDialogParagraphs;

    @FindBy(xpath = "//app-additional-coverages-page//h2[@id='earthquake-coverage-heading']")
    private WebElement earthquakeCoverageHeading;
    @FindBy(xpath = "//app-additional-coverages-page//p[contains(@class,'earthquake_coverage_full_description')]")
    private WebElement earthquakeCoverageDesc;
    @FindBy(xpath = "//div[@class='earthquake-coverage-info']//div[contains(@class,'tui-info-box-header')]")
    private WebElement earthquakeCoverageInfo;
    @FindBy(xpath = "//div[@class='earthquake-coverage-info']//p[@class='tui-info-box-content']")
    private WebElement earthquakeCoverageInfoContent;
    private static final String EARTHQUAKE_INFO_CONTENT = "You can call us to learn more about purchasing CEA coverage at 888-327-6335. We'll also mail you a letter about your eligibility for this coverage.";
    private static final String EARTHQUAKE_TITLE = "Earthquake coverage";
    private static final String EARTHQUAKE_DESC = "The California Earthquake Authority (CEA) offers earthquake coverage.";

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceCondoAdditionalCoveragesPage() throws Exception {
    }

    public boolean isOnAdditionalCoveragesPageAceCondo() {
        if (isUseMobileViewEnabled()) {
            wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOf(buttonContinueMobile),
                    ExpectedConditions.visibilityOf(tryAgainButton)));
            return isElementVisible(buttonContinueMobile, 3);
        } else {
            wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOf(buttonContinueDesktop),
                    ExpectedConditions.visibilityOf(tryAgainButton)));
            return isElementVisible(buttonContinueDesktop, 3);
        }
    }

    public void validatePageTitleSubtitle(FarmersSoftAssert fsa) throws Exception {
    	waitForPageToBeReady();
        fsa.assertEquals(getTextFromElement(additionalCoveragesHeading), PAGE_TITLE, "Ace Condo Additional coverages page - Title.");
        fsa.assertTrue(isElementInViewport(additionalCoveragesHeading), "Ace Condo Additional coverages page - page title is in Viewport.");
        fsa.assertEquals(getTextFromElement(additionalCoveragesSubheading), PAGE_SUBTITLE, "Ace Condo Additional coverages page - Subtitle.");
    }

    public String getPackagePriceOnCard() throws Exception {
        String PRIMARY_PACKAGE_XPATH = String.format(PRIMARY_COVERAGE_PRICE_DESKTOP_XPATH, "Primary coverages");
        WebElement mainCoveragePriceWe = driver().findElement(By.xpath(PRIMARY_PACKAGE_XPATH));
        return getTextFromElement(mainCoveragePriceWe);
    }

    public String getPackagePriceOnCard(int numberOfPackages) throws Exception {
        String PRIMARY_PACKAGE_NAME = "Primary coverages";
        String OPTIONAL_PACKAGE_NAME = "All other coverages";
        String PRIMARY_PACKAGE_XPATH;
        if (isUseMobileViewEnabled()) {
            PRIMARY_PACKAGE_XPATH = (List.of(1, 3, 4, 6).contains(numberOfPackages)) ?
                    String.format(PRIMARY_COVERAGE_PRICE_MOBILE_XPATH, PRIMARY_PACKAGE_NAME) :
                    String.format(PRIMARY_COVERAGE_PRICE_MOBILE_XPATH, OPTIONAL_PACKAGE_NAME);
            if (isElementDisplayed(expandQuoteCard, 2)) {
                waitAndClickElement(expandQuoteCard);
            }
        } else {
            PRIMARY_PACKAGE_XPATH = (List.of(1, 3, 4, 6).contains(numberOfPackages)) ?
                    String.format(PRIMARY_COVERAGE_PRICE_DESKTOP_XPATH, PRIMARY_PACKAGE_NAME) :
                    String.format(PRIMARY_COVERAGE_PRICE_DESKTOP_XPATH, OPTIONAL_PACKAGE_NAME);
        }
        WebElement primaryPackagePriceWe = driver().findElement(By.xpath(PRIMARY_PACKAGE_XPATH));
        return getTextFromElement(primaryPackagePriceWe);
    }

    public String getAllOtherCoveragesPriceOnCard() {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard, 2)) {
                waitAndClickElement(expandQuoteCard);
            }
            return getTextFromElement(waitElementBeVisible(quoteAllOtherCoveragesPriceOnCardMobile));
        } else {
            return getTextFromElement(waitElementBeVisible(quoteAllOtherCoveragesPriceOnCardDesktop));
        }
    }

    public void verifyQuotePresentmentCard(FarmersSoftAssert fsa) throws Exception {
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);

        fsa.assertTrue(isPresentmentCardPriceHeader(), "Ace Condo Additional coverages page - Quote Presentment card - quote price header.");

        for (int i=0; i < 2; i++) {
            AppStore appStore = getSessionStorageAppStore();
            AppStore.Home.Quote quote = appStore.getHome().getQuote();
            String selectedPackageCode = quote.getSelectedPackageCode();
            String selectedPaymentMode = quote.getSelectedPaymentMode();
            double totalPremium = Double.parseDouble(appStore.getHome().getCoverageForPackage(selectedPackageCode, selectedPaymentMode).getTotalPremium());
            List<AppStore.Home.Discount> discounts = appStore.getHome().getDiscountsForPackage(selectedPackageCode, selectedPaymentMode);
            if (selectedPaymentMode.equals("PIF")) {
                fsa.assertEquals(currencyFormat.parse(getQuotePriceOnCard()).doubleValue(), totalPremium,
                        "Ace Condo Additional coverages page Condo - Quote Presentment card - Quote PIF price.");
                fsa.assertEquals(currencyFormat.parse(getPackagePriceOnCard()).doubleValue(), totalPremium,
                        "Ace Condo Additional coverages page Condo - Quote Presentment card - Package PIF price.");
                fsa.assertEquals(getAllOtherCoveragesPriceOnCard(), "$0", "Additional coverages - Quote Presentment card - All other coverages price.");
                fsa.assertEquals(getDiscountsOnCard(), String.format("%s discounts included", discounts.size()),
                        "Ace Condo Additional coverages page Condo - Quote Presentment card - number of discounts included.");
                if (isViewMonthlyPricingLink()) {
                    clickViewMonthlyPricing();
                } else {
                    break;
                }
            } else if (selectedPaymentMode.equals("EFT")) {
                Double monthlyPremium = Math.round((totalPremium / 12) * 100) / 100.00;
                fsa.assertEquals(currencyFormat.parse(getQuotePriceOnCard()).doubleValue(), monthlyPremium,
                        "Ace Condo Additional coverages page - Quote Presentment card - Quote monthly price.");
                fsa.assertEquals(currencyFormat.parse(getPackagePriceOnCard()).doubleValue(), monthlyPremium,
                        "Ace Condo Additional coverages page - Quote Presentment card - Package monthly price.");
                fsa.assertEquals(getAllOtherCoveragesPriceOnCard(), "$0", "Review Quote page - Quote Presentment card - All other coverages price");
                fsa.assertEquals(getDiscountsOnCard(), String.format("%s discounts included", discounts.size()),
                        "Ace Condo Additional coverages page - Quote Presentment card - number of discounts included");
                if (isViewPayInFullPricingLink()) {
                    clickViewPayInFullPricing();
                } else {
                    break;
                }
            }
            waitForPageToBeReady();
        }
    }

    public void validateAdditionalCoveragesTogglesText(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        LinkedHashMap<String, String> additionalCoveragesDescriptionMap = new LinkedHashMap<>();
        additionalCoveragesDescriptionMap.put(IDENTITY_SHIELD, "Helps you resolve identity fraud, provides compensation for time and loss up to the stated limits, " +
                "performs credit monitoring, provided assistance with notifying credit bureaus of the fraud, and assists in replacing important documents. Identity " +
                "shield also provides access to an advocate who will guide you through the identity recovery process.");
        if(!applicant.getStateCode().equals(KS)) {
            additionalCoveragesDescriptionMap.put(IDENTITY_FRAUD, "Helps with the costs of repairing credit integrity that was compromised by identity theft.");
        } else {
            additionalCoveragesDescriptionMap.put(IDENTITY_FRAUD, "Helps you resolve identity fraud, provides compensation for time and loss up to the stated limits, " +
                    "performs credit monitoring, provided assistance with notifying credit bureaus of the fraud, and assists in replacing important documents. " +
                    "Identity shield also provides access to an advocate who will guide you through the identity recovery process.");
        }
        additionalCoveragesDescriptionMap.put(PERSONAL_INJURY, "This coverage can pay for personal injury damages which you are legally obligated to pay as a result of a covered occurrence.");
        additionalCoveragesDescriptionMap.put(SEWER_AND_DRAIN, "This coverage can pay to repair or replace covered property resulting from a sudden and accidental water loss from a system " +
                "within the residence premises and is either a water - reverse flow or from below the surface of the ground.");
        additionalCoveragesDescriptionMap.put(RESIDENCE_GLASS, "Covers replacing broken window glass attached to the portion of the condominium that you own with no deductible.");
        additionalCoveragesDescriptionMap.put(INCREASED_LIMITS_FOR_VALUABLES_TITLE, "This is in addition to what's included in your policy for your jewelry ($1,000 per item / $2,500 total), " +
                "silverware ($2,500), firearms ($2,500), securities ($1,000), and off-premises portable electronic equipment($5,000).");
        additionalCoveragesDescriptionMap.put(SINKHOLE_LOSS, "Provides coverage for accidental, actual, and direct physical sinkhole loss.");
        additionalCoveragesDescriptionMap.put(LIMITED_MOLD, "This coverage can pay for expenses required to remediate any mold which results from the repair or replacement of a covered loss.");
        additionalCoveragesDescriptionMap.put(INCREASED_LIMITS_FOR_LIMITED_MOLD, "This coverage can pay for expenses required to remediate any mold which results from the repair or replacement of a covered loss.");
        additionalCoveragesDescriptionMap.put(EARTHQUAKE, "Provides coverage for direct physical loss or damage caused by earthquake subject to the coverage provided in " +
                "the endorsement and the earthquake deductible selected. The underlying property policies exclude loss caused by all earth movements, including earthquakes.");
        additionalCoveragesDescriptionMap.put(WATERCRAFT_LIABILITY_FAMILY_PROTECTION, "This coverage is for bodily injury to family and household members other than " +
                "the Named Insured, that results from an occurrence involving watercraft. (Unselecting this option will deduct $2.00 from your Package price. If you " +
                "choose to decline this coverage, you must sign and return the Declination of Family Protection Liability Coverage form.)");

        List<String> additionalCoverages = getAdditionalCoverageNames(applicant);
        for (String coverageTitle : additionalCoverages) {
            Log.info(">> Validating Additional coverage: " + coverageTitle);
            fsa.assertTrue(isElementDisplayed(By.xpath(String.format(TOGGLE_BUTTON_XPATH, coverageTitle))),
                    "Ace Condo Additional Coverage page - coverage toggle: " + coverageTitle + " is displayed.");
            fsa.assertEquals(getAdditionalCoverageText(coverageTitle), additionalCoveragesDescriptionMap.get(coverageTitle),
                    "Ace Condo Additional Coverage page - coverage description text: " + coverageTitle + " displayed.");

            String coveragePrice = getCoveragePriceForCoverageTitle(coverageTitle);
            if (coverageTitle.equals(INCREASED_LIMITS_FOR_VALUABLES_TITLE)) {   // && applicant.getStateCode().equals(KS)) {
                coveragePrice = EMPTY_STRING;
            }
            fsa.assertEquals(getAdditionalCoveragePrice(coverageTitle), coveragePrice,
                    "Ace Condo Additional Coverage page - coverage premium: " + coverageTitle + " is correctly displayed.");
        }
        if (applicant.getStateCode().equals(CA)) {
            validateEarthquakeSection(fsa);
        }
    }

    public void validateEarthquakeSection(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(earthquakeCoverageHeading), EARTHQUAKE_TITLE, "Earthquake coverage section title is displayed.");
        fsa.assertEquals(getTextFromElement(earthquakeCoverageDesc), EARTHQUAKE_DESC, "Earthquake coverage Description is displayed.");
        fsa.assertEquals(getTextFromElement(earthquakeCoverageInfo), EARTHQUAKE_TITLE, "Earthquake coverage section - info title is displayed.");
        fsa.assertEquals(getTextFromElement(earthquakeCoverageInfoContent), EARTHQUAKE_INFO_CONTENT, "Earthquake coverage section - Info content is displayed.");
    }

    public void validateAdditionalCoveragesTogglesPremium(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        final List<String> SEWER_DRAIN_CHECKBOXES_LABELS = Arrays.asList("$5,000", "$10,000", "$15,000", "$25,000", "$50,000");
        final List<String> SEWER_DRAIN_FOOTER_TEXT = Arrays.asList("Basic covers specific types of personal property (washing machines, " +
                "dryers, freezers and the food, refrigerators and the food, ranges, portable dishwashers, portable water softeners, " +
                "and dehumidifiers).", "Extended covers all property covered under Personal property (Coverage C).");
        final List<String> SEWER_DRAIN_FOOTER_TEXT_MD = Arrays.asList("Covers all property under Personal property (Coverage C), up to the Coverage C limit.",
                "Basic covers specific types of personal property (washing machines, dryers, freezers and the food, refrigerators and the food, ranges, " +
                "portable dishwashers, portable water softeners, and dehumidifiers).", "Extended covers all property covered under Personal property (Coverage C).");

        final List<String> INCREASED_LIMITS_FOR_VALUABLES_CHECKBOXES_VALUES = Arrays.asList("$1,000", "$1,000", "$1,000", "$1,000", "$5,000");
        final List<String> INCREASED_LIMITS_FOR_VALUABLES_FOOTER_VALUES = Arrays.asList("$1,000", "$2,000", "$3,000", "$4,000", "$9,000");

        final String INCREASED_LIMITS_FOR_VALUABLES_INFO_TITLE = INCREASED_LIMITS_FOR_VALUABLES_TITLE;
        final String INCREASED_LIMITS_FOR_VALUABLES_INFO_TEXT = "Each policy automatically includes some coverage for valuable items, but some people " +
                "need more coverage than what is automatically included. If you need more coverage, you can add additional coverage by type of valuable " +
                "item in increments of $1,000. There is a maximum combined coverage limit available depending on your Personal Property coverage limit.";
        final String INCREASED_LIMITS_FOR_VALUABLES_INFO_SUBTITLE = "The automatically included coverage limits are:";
        final List<String> INCREASED_LIMITS_FOR_VALUABLES_INFO_ITEMS = List.of("Jewelry is covered up $1,000 for any one article and up to $2,500 total " +
                "limit for loss by theft.", "Silverware, goldware, platinumware and pewterware, are covered up to $2,500 for loss by theft.",
                "Firearms are covered up to $2,500 for loss by theft.", "Securities, deeds, valuable papers, personal records, and stamps are covered up " +
                "to $1,000 for loss or damage.", "Portable electronic equipment, including computers, personal electronics, entertainment equipment, " +
                "communication equipment, and accessories necessary are covered up to $5,000 for repair or replacement due to a covered loss while the " +
                "property was away from your home.");
        final List<String> EARTHQUAKE_RADIO_TEXT = Arrays.asList("10%", "15%", "20%", "25%");
        final List<String> EARTHQUAKE_INFO_DIALOG_PARAGRAPHS = List.of(
                // Coverage
                "Coverage for direct physical loss or damage caused by earthquake subject to the Coverage A (Unit Owner's Building Property), Coverage C " +
                        "(Personal Property), and Coverage D (Loss of Use) limits.",
                // Deductible
                "This deductible applies to each earthquake event. This deductible will apply separately to loss under Coverage A (Unit Owner's Building " +
                        "Property) and Coverage C (Personal Property).");

        AppStore.Home home = getSessionStorageAppStore().getHome();
        String selectedPackageCode = home.getQuote().getSelectedPackageCode();
        String selectedPaymentMode = home.getQuote().getSelectedPaymentMode();
        String personalPropertyValue = home.getCoverageForPackage(selectedPackageCode, selectedPaymentMode).getCvgInfoForCvgDesc("Personal property").getCvgAmt();
        double dValuablesMaxCoverage = (convertCurrencyStringToDouble(personalPropertyValue) * .60d);
        dValuablesMaxCoverage = Math.min(dValuablesMaxCoverage, 75000d);
        final String INCREASED_LIMITS_FOR_VALUABLES_FOOTER_TEXT = "Total combined: %s *There is a max combined limit of "
                + CurrencyFormat.convertDoubleToCurrencyString(dValuablesMaxCoverage).replace(".00",EMPTY_STRING) + ".";

        String totalQuotePrice = getQuotePriceOnCard();
        Double dQuotePrice = convertCurrencyStringToDouble(totalQuotePrice);
        List<String> additionalCoverages = getAdditionalCoverageNames(applicant);
        fsa.assertEquals(toggleButtons.stream().map(this::getTextFromElement).sorted().collect(Collectors.toList()), additionalCoverages,
                "Additional coverages page - all expected toggles displayed.");
        for (String coverageTitle : additionalCoverages) {
            Log.info(">> Validating Additional coverage: " + coverageTitle);
            if (!coverageTitle.equals(WATERCRAFT_LIABILITY_FAMILY_PROTECTION)) {
                toggleAdditionalCoverage(coverageTitle, true);
            }
            String additionalCoveragePrice = getAdditionalCoveragePrice(coverageTitle);
            // validating toggle price is reflected in the quote presentment card
            if (!additionalCoveragePrice.isBlank()) {
                Double dAdditionalCoverage = convertCurrencyStringToDouble(additionalCoveragePrice);
                fsa.assertEquals(convertCurrencyStringToDouble(getQuotePriceOnCard().split("/")[0]),
                        Math.round((dQuotePrice + dAdditionalCoverage) * 100.0)/100.0, .02d, "Ace Condo Additional coverage page - toggle: "
                                + coverageTitle + " Total Quote price on Presentment card within delta=.02");
                fsa.assertEquals(convertCurrencyStringToDouble(getAllOtherCoveragesPriceOnCard().split("/")[0]),
                        dAdditionalCoverage, .02d, "Ace Condo Additional coverage page - toggle: "
                                + coverageTitle + " All other coverages price within delta=.02");
            }
            // validating toggles with dependent sections
            switch (coverageTitle) {
                case SEWER_AND_DRAIN:
                    if (!List.of(VA, MD).contains(applicant.getStateCode())) {
                        fsa.assertEquals(getTextFromElement(headerSewerDrain1), "Coverage limit", "Sewer and drain section header.");
                        fsa.assertEquals(getTextFromElement(headerSewerDrain2), "Coverage type", "Sewer and drain section type header.");

                        List<String> sewerDrainLabels = new ArrayList<>(SEWER_DRAIN_CHECKBOXES_LABELS);
                        fsa.assertEquals(radioButtonsSewerDrain.size(), sewerDrainLabels.size(), "Sewer and drain section number of " +
                                "radio-buttons (max value not to exceed Personal property).");
                        fsa.assertEquals(radioButtonsSewerDrain.size(), sewerDrainLabels.size(), "Sewer and drain section number of radio-buttons.");
                        int i = 0;
                        for (WebElement matRadio : radioButtonsSewerDrain) {
                            fsa.assertEquals(getTextFromElement(matRadio), SEWER_DRAIN_CHECKBOXES_LABELS.get(i),
                                    "Sewer and drain section radio button: " + (i + 1) + " text.");
                            if (i == 0) {
                                fsa.assertTrue(getAttributeData(matRadio, CLASS).contains(RADIO_BUTTON_CHECKED),
                                        "Sewer and drain first radio button is selected.");
                            }
                            i++;
                        }
                        fsa.assertEquals(getTextFromElement(footerSewerDrain), SEWER_DRAIN_FOOTER_TEXT.get(0), "Sewer and drain footer section text (Basic).");
                        waitAndClickElement(matButtonSewerDrainExtended);
                        fsa.assertEquals(getTextFromElement(footerSewerDrain), SEWER_DRAIN_FOOTER_TEXT.get(1), "Sewer and drain footer section text (Extended).");
                        fsa.assertTrue(isAdditionalCoveragePriceStrikeThru(SEWER_AND_DRAIN), "Additional coverages page - coverage premium price strike-thru.");
                        fsa.assertTrue(isQuotePriceStrikeThru(), "Additional coverages page - Quote price on card is strike-thru");
                    } else if (applicant.getStateCode().equals(MD)) {
                        fsa.assertEquals(getTextFromElement(headerSewerDrain1), "What level of coverage do you want?", "Sewer and drain section header (MD).");
                        fsa.assertEquals(getTextFromElement(footerSewerDrainLabel1), "Coverage Limit", "Sewer and drain footer section label (MD).");
                        fsa.assertEquals(getTextFromElement(footerSewerDrainLabel2), SEWER_DRAIN_FOOTER_TEXT_MD.get(0), "Sewer and drain footer section text (MD).");
                        waitAndClickElement(matButtonSewerDrainPartial);
                        List<String> sewerDrainLabels = new ArrayList<>(SEWER_DRAIN_CHECKBOXES_LABELS);
                        fsa.assertEquals(radioButtonsSewerDrain.size(), sewerDrainLabels.size(), "Sewer and drain section number of " +
                                "radio-buttons (max value not to exceed Personal property).");
                        fsa.assertEquals(radioButtonsSewerDrain.size(), sewerDrainLabels.size(), "Sewer and drain section number of radio-buttons.");
                        int i = 0;
                        for (WebElement matRadio : radioButtonsSewerDrain) {
                            fsa.assertEquals(getTextFromElement(matRadio), SEWER_DRAIN_CHECKBOXES_LABELS.get(i),
                                    "Sewer and drain section radio button: " + (i + 1) + " text.");
                            if (i == 0) {
                            	fsa.assertTrue(getAttributeData(matRadio, CLASS).contains(RADIO_BUTTON_CHECKED),
                                        "Sewer and drain first radio button is selected.");
                            }
                            i++;
                        }
                        fsa.assertEquals(getTextFromElement(footerSewerDrainMD), SEWER_DRAIN_FOOTER_TEXT_MD.get(1), "Sewer and drain footer section text (Basic).");
                        waitAndClickElement(matButtonSewerDrainExtended);
                        fsa.assertEquals(getTextFromElement(footerSewerDrainMD), SEWER_DRAIN_FOOTER_TEXT_MD.get(2), "Sewer and drain footer section text (Extended).");
                        fsa.assertTrue(isAdditionalCoveragePriceStrikeThru(SEWER_AND_DRAIN), "Additional coverages page - coverage premium price strike-thru.");
                        fsa.assertTrue(isQuotePriceStrikeThru(), "Additional coverages page - Quote price on card is strike-thru");
                    } else if (applicant.getStateCode().equals(VA)) {
                        fsa.assertEquals(getValueFromWebElement(inputSewerDrain), "$5,000", "Sewer and drain input field value.");
                        fsa.assertEquals(getTextFromElement(subTextInputSewerDrain), "$5,000 - " + personalPropertyValue, "Sewer and drain input field Sub-text.");
                        fsa.assertTrue(isElementVisible(buttonSewerDrainMinus, 2), "Sewer and drain minus button is displayed.");
                        fsa.assertTrue(isElementVisible(buttonSewerDrainPlus, 2), "Sewer and drain plus button is displayed.");
                        waitAndClickElement(buttonSewerDrainPlus);
                        fsa.assertEquals(getValueFromWebElement(inputSewerDrain), "$6,000", "Increased coverage for Sewer and drain form field.");
                        waitAndClickElement(buttonSewerDrainMinus);
                        fsa.assertEquals(getValueFromWebElement(inputSewerDrain), "$5,000", "Decreased coverage for Sewer and drain form field.");
                    }
                    break;
                case INCREASED_LIMITS_FOR_VALUABLES_TITLE:
                    fsa.assertEquals(getTextFromElement(headerIncreasedValuables), "Select which coverages to increase limits for*",
                            "Increased limits for certain valuables section header.");
                    fsa.assertEquals(getAttributeData(headerIncreasedValuablesInfoIcon, ARIA_LABEL), "info icon for Select which coverages to increase limits for*",
                            "Increased limits for certain valuables section header Info icon.");
                    // validating Info section side-sheet Content
                    scrollAndClickOnElement(headerIncreasedValuablesInfoIcon);
                    fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogHeader), INCREASED_LIMITS_FOR_VALUABLES_INFO_TITLE, "Increased limits for valuables info section title");
                    fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogMainContent), INCREASED_LIMITS_FOR_VALUABLES_INFO_TEXT,
                            "Increased limits for valuables info section text main content");
                    fsa.assertEquals(getTextFromElement(increasedValuablesInfoDialogSubtitle), INCREASED_LIMITS_FOR_VALUABLES_INFO_SUBTITLE,
                            "Increased limits for valuables info section sub-title");
                    int i = 0;
                    for (String infoPoint : INCREASED_LIMITS_FOR_VALUABLES_INFO_ITEMS) {
                        fsa.assertEquals(getTextFromElement(listIncreasedValuablesInfoDialogItems.get(i)), infoPoint,
                                "Increased limits for valuables info section items - item: " + i);
                        i++;
                    }
                    waitAndClickElement(increasedValuablesInfoDialogCloseButton);
                    //
                    List<String> valuablesLabels = new ArrayList<>(INCREASED_VALUABLES_CHECKBOXES_LABELS);
                    if (applicant.getStateCode().equals(VA)) {
                        valuablesLabels.removeAll(List.of("Silverware", "Securities", "Off-premises portable electronic equipment"));
                    } else if (applicant.getStateCode().equals((NC))) {
                        valuablesLabels.removeAll(List.of("Jewelry ($1,000 per item still applies)", "Off-premises portable electronic equipment"));
                    }
                    fsa.assertEquals(checkboxesIncreasedValuables.size(), valuablesLabels.size(), "Increased limits for certain valuables section number of checkboxes.");
                    fsa.assertEquals(getTextFromElement(footerIncreasedValuables), String.format(INCREASED_LIMITS_FOR_VALUABLES_FOOTER_TEXT, "$0"),
                            "Increased limits for certain valuables section footer text with no selected checkboxes.");
                    i = 0;
                    for (WebElement matCheckbox : checkboxesIncreasedValuables) {
                        WebElement weCheck = driver().findElement(By.xpath(INCREASED_VALUABLES_CHECKBOXES_FIELD_XPATH + "[" + (i + 1) + "]//input"));
                        clickOnHiddenElement(weCheck);
                        fsa.assertTrue(getAttributeData(waitElementBeVisible(matCheckbox), CLASS).contains(CHECKBOX_CHECKED),
                                "Increased limits for certain valuables section checkbox: " + (i + 1) + " is selected.");

                        WebElement weLabel = driver().findElement(By.xpath(INCREASED_VALUABLES_CHECKBOXES_FIELD_XPATH + "[" + (i + 1) + "]/following-sibling::div"));
                        fsa.assertEquals(getTextFromElement(weLabel), valuablesLabels.get(i),
                                "Increased limits for certain valuables section " + valuablesLabels.get(i) + " checkbox label.");

                        WebElement weField = driver().findElement(By.xpath(INCREASED_VALUABLES_CHECKBOXES_FIELD_XPATH + "[" + (i + 1) + "]/../following-sibling::div//input"));
                        fsa.assertEquals(getValueFromWebElement(weField), INCREASED_LIMITS_FOR_VALUABLES_CHECKBOXES_VALUES.get(i),
                                "Increased limits for certain valuables section " + valuablesLabels.get(i) + " form field value.");

                        fsa.assertEquals(getTextFromElement(footerIncreasedValuables), String.format(INCREASED_LIMITS_FOR_VALUABLES_FOOTER_TEXT,
                                        INCREASED_LIMITS_FOR_VALUABLES_FOOTER_VALUES.get(i)),
                                "Increased limits for certain valuables section footer text with checkbox: " + valuablesLabels.get(i) + " selected.");

                        if (getPageErrors().isEmpty()) {
                            // increase (+) coverage for the valuable
                            WebElement weIncrease = driver().findElement(By.xpath(INCREASED_VALUABLES_INCREASE_LIMIT_BUTTON_XPATH + "[" + (i + 1) + "]"));
                            waitAndClickElement(weIncrease);
                            fsa.assertEquals(getValueFromWebElement(waitElementBeVisible(weField)), convertDoubleToCurrencyString(convertCurrencyStringToDouble(INCREASED_LIMITS_FOR_VALUABLES_CHECKBOXES_VALUES.get(i))
                                            + convertCurrencyStringToDouble("$1,000")).replace(".00", ""),
                                    "Increased limits for certain valuables section checkbox: " + valuablesLabels.get(i) + " selected and value increased by 1K.");
                            // decrease (-) coverage for the valuable
                            WebElement weDecrease = driver().findElement(By.xpath(INCREASED_VALUABLES_DECREASE_LIMIT_BUTTON_XPATH + "[" + (i + 1) + "]"));
                            waitAndClickElement(weDecrease);
                            fsa.assertEquals(getValueFromWebElement(waitElementBeVisible(weField)), INCREASED_LIMITS_FOR_VALUABLES_CHECKBOXES_VALUES.get(i),
                                    "Increased limits for certain valuables section checkbox: " + valuablesLabels.get(i) + " selected and value decreased back by 1K.");
                        }
                        i++;
                    }
                    fsa.assertTrue(isQuotePriceStrikeThru(), "Additional coverages page - Quote price on card is strike-thru");
                    validateIncreasedCoverageLimits(applicant, CONDO, fsa);
                    break;
                case EARTHQUAKE:
                    List<String> sectionHeaders = List.of("Deductible", "Is the structure attached to the foundation?",
                            "Does the foundation include any of the following:");
                    fsa.assertEquals(headersEarthquakeSection.stream().map(this::getTextFromElement).collect(Collectors.toList()), sectionHeaders,
                            "Earthquake section headers.");
                    fsa.assertEquals(radioButtonsEarthquake.size(), 4, "Earthquake section number of radio-buttons.");
                    List<String> listFoundatioms = List.of("Elevated post/pier and beam (stilts)", "Stilts with sweep-away walls, or", "Deep pilings");
                    fsa.assertEquals(listFoundationsEarthquakeSection.stream().map(this::getTextFromElement).collect(Collectors.toList()), listFoundatioms,
                            "Earthquake section list foundations.");

                    List<String> sectionToggleButtons = List.of(YES, NO, YES, NO);
                    fsa.assertEquals(toggleButtonsEarthquake.stream().map(this::getTextFromElement).collect(Collectors.toList()), sectionToggleButtons,
                            "Earthquake section toggle buttons.");
                    i = 0;
                    for (WebElement matRadio : radioButtonsEarthquake) {
                        fsa.assertEquals(getTextFromElement(matRadio), EARTHQUAKE_RADIO_TEXT.get(i),
                                "Earthquake section radio button: " + (i + 1)+ " text.");
                        i++;
                    }
                    String infoIconText = "info icon for Deductible";
                    fsa.assertEquals(getAttributeData(earthquakeInfoIcon, ARIA_LABEL), infoIconText, "Earthquake section info icon.");

                    waitAndClickElement(earthquakeInfoIcon);
                    waitElementBeVisible(earthquakeCoverageInfoDialogHeader,3);
                    fsa.assertEquals(getTextFromElement(earthquakeCoverageInfoDialogHeader), "Earthquake coverage", "Earthquake info dialog side-sheet header.");
                    List<String> infoDialogSubheaders = List.of("Coverage", "Deductible");
                    fsa.assertEquals(earthquakeInfoDialogSubheaders.stream().map(this::getTextFromElement).collect(Collectors.toList()), infoDialogSubheaders,
                            "Earthquake info dialog sub-headers.");
                    fsa.assertEquals(earthquakeInfoDialogParagraphs.stream().map(this::getTextFromElement).collect(Collectors.toList()),
                            EARTHQUAKE_INFO_DIALOG_PARAGRAPHS, "Earthquake info dialog paragraphs text content.");
                    waitAndClickElement(closeSidesheetButton);
                    break;
                case WATERCRAFT_LIABILITY_FAMILY_PROTECTION:
                    String DIALOG_TITLE = "Watercraft liability - Family protection";
                    String DIALOG_CONTENT = "In your state, this coverage is automatically included in your quote. Unselecting this option " +
                            "will deduct $2.00 from your Package price. If you choose to decline this coverage, you must sign and return " +
                            "the Declination of Family Protection Liability Coverage form.";
                    fsa.assertTrue(isAdditionalCoverageToggleSelected(coverageTitle), "Additional coverage toggle (MN) has to be turned On by default.");

                    toggleAdditionalCoverage(coverageTitle, false);
                    fsa.assertEquals(getTextFromElement(watercraftCoverageDialogTitle), DIALOG_TITLE, "Additional coverage toggle (MN) confirmation dialog title");
                    fsa.assertEquals(getTextFromElement(watercraftCoverageDialogContent), DIALOG_CONTENT, "Additional coverage toggle (MN) confirmation dialog content");
                    waitAndClickElement(buttonOk);
                    tryRecalculateQuote();

                    toggleAdditionalCoverage(coverageTitle, false);
                    waitAndClickElement(buttonRemoveCoverage);
                    String paymentMode = getSessionStorageAppStore().getHome().getQuote().getSelectedPaymentMode();
                    String coveragePrice = paymentMode.equals("PIF") ? "$-2/year" : "$-0.17/month";
                    fsa.assertEquals(getAdditionalCoveragePrice(coverageTitle), coveragePrice,
                            "Ace Condo Additional Coverage page - coverage premium: " + coverageTitle + " is correctly displayed.");
                    break;
            }
            toggleAdditionalCoverage(coverageTitle, false);
            tryRecalculateQuote();
        }

    }

    private List<String> getAdditionalCoverageNames(ApplicantAceHome applicant) {
        List<String> additionalCoverages = new ArrayList<>(ADDITIONAL_COVERAGES_TITLES);
        switch (applicant.getStateCode()) {
            case AR:
                additionalCoverages.add(EARTHQUAKE);
                additionalCoverages.remove(LIMITED_MOLD);
                break;
            case CA:
                additionalCoverages.remove(RESIDENCE_GLASS);
                break;
            case GA:
                additionalCoverages.remove(LIMITED_MOLD);
                additionalCoverages.add(INCREASED_LIMITS_FOR_LIMITED_MOLD);
                break;
            case KS:
                additionalCoverages.remove(IDENTITY_SHIELD);
                additionalCoverages.add(IDENTITY_FRAUD);
                break;
            case KY:
            case LA:
            case MA:
            case MS:
                additionalCoverages.remove(IDENTITY_SHIELD);
                additionalCoverages.remove(LIMITED_MOLD);
                break;
            case NC:
                additionalCoverages.remove(SEWER_AND_DRAIN);
                additionalCoverages.remove(LIMITED_MOLD);
                additionalCoverages.remove(RESIDENCE_GLASS);
                additionalCoverages.remove(IDENTITY_SHIELD);
                additionalCoverages.add(IDENTITY_FRAUD);
                break;
            case MN:
                additionalCoverages.add(WATERCRAFT_LIABILITY_FAMILY_PROTECTION);
                break;
            case TN:
            case PA:
                additionalCoverages.add(SINKHOLE_LOSS);
                break;
            case VA:
                additionalCoverages.remove(RESIDENCE_GLASS);
                additionalCoverages.remove(LIMITED_MOLD);
                break;
            case MI:
            case WA:
                additionalCoverages.remove(LIMITED_MOLD);
                break;
        }
        return getSortedList(additionalCoverages);
    }


    public void validateSwitchingToAndFromReviewQuotePageCondo(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        List<String> togglesSelected = randomToggleSelection(applicant, fsa, CONDO);
        String totalQuotePriceAdditionalCoverages = getQuotePriceOnCard();
        String allOtherPriceAdditionalCoverages = getAllOtherCoveragesPriceOnCard();
        String packageNameAdditionalCoverages = getSelectedPackageName();
        String paymentModeAdditionalCoverages = getSelectedPaymentMode();

        selectStepper(REVIEW_QUOTE);
        AceCondoReviewQuotePage reviewQuotePage = new AceCondoNavigationHelper().goToAceCondoReviewQuotePage(applicant);

        String totalQuotePriceReviewQuote = reviewQuotePage.getQuotePriceOnCard();
        String allOtherPriceReviewQuote = reviewQuotePage.getAllOtherCoveragesPriceOnCard();
        String packageNameReviewQuote = reviewQuotePage.getSelectedPackageName();
        String paymentModeReviewQuote = reviewQuotePage.getSelectedPaymentMode();
        fsa.assertEquals(totalQuotePriceReviewQuote, totalQuotePriceAdditionalCoverages, "Review quote page - Total quote premium");
        fsa.assertEquals(allOtherPriceReviewQuote, allOtherPriceAdditionalCoverages, "Review quote page - All other coverages premium");
        fsa.assertEquals(packageNameReviewQuote, packageNameAdditionalCoverages, "Review quote page - Package name");
        fsa.assertEquals(paymentModeReviewQuote, paymentModeAdditionalCoverages, "Review quote page - Payment mode");
        reviewQuotePage.clickOnContinueButton();
        assert isOnAdditionalCoveragesPage();
        validatePageTitleSubtitle(fsa);

        String totalQuotePriceAdditionalCoverages2 = getQuotePriceOnCard();
        String allOtherPriceAdditionalCoverages2 = getAllOtherCoveragesPriceOnCard();
        String packageNameAdditionalCoverages2 = getSelectedPackageName();
        String paymentModeAdditionalCoverages2 = getSelectedPaymentMode();
        fsa.assertEquals(totalQuotePriceAdditionalCoverages2, totalQuotePriceAdditionalCoverages, "Additional coverages page - Total quote premium");
        fsa.assertEquals(allOtherPriceAdditionalCoverages2, allOtherPriceAdditionalCoverages, "Additional coverages page - All other coverages premium");
        fsa.assertEquals(packageNameAdditionalCoverages2, packageNameAdditionalCoverages, "Additional coverages page - Package name");
        fsa.assertEquals(paymentModeAdditionalCoverages2, paymentModeAdditionalCoverages, "Additional coverages page - Payment mode");
        fsa.assertEquals(getSelectedToggles(), getSortedList(togglesSelected), "Additional coverages page - Selected toggles");
    }

    public void validateADA(ApplicantAceHome applicant) throws Exception {
        performADATesting(this.getClass().getSimpleName(),MARKETING_IT,FFQ_ACE_CONDO);
        List<String> additionalCoverages = getAdditionalCoverageNames(applicant);
        for (String coverageTitle : additionalCoverages) {
            Log.info(">> Validating Additional coverage: " + coverageTitle);
            toggleAdditionalCoverage(coverageTitle, true);
            switch (coverageTitle) {
                case SEWER_AND_DRAIN:
                    performADATesting(this.getClass().getSimpleName()+"_SewerDrain",MARKETING_IT,FFQ_ACE_CONDO);
                    break;
                case LIMITED_MOLD:
                    performADATesting(this.getClass().getSimpleName()+"_LimitedMold",MARKETING_IT,FFQ_ACE_CONDO);
                    break;
                case INCREASED_LIMITS_FOR_VALUABLES_TITLE:
                    performADATesting(this.getClass().getSimpleName()+"_IncreasedCoverageForValuables",MARKETING_IT,FFQ_ACE_CONDO);
                    // check Info section side-sheet Content
                    waitAndClickElement(headerIncreasedValuablesInfoIcon);
                    performADATesting(this.getClass().getSimpleName()+"_IncreasedCoverageForValuables_InfoSideSheet",MARKETING_IT,FFQ_ACE_CONDO);
                    waitAndClickElement(increasedValuablesInfoDialogCloseButton);
                    //
                    int numberOfCheckboxes = checkboxesIncreasedValuables.size();
                    for (int i=0; i<numberOfCheckboxes; i++) {
                        WebElement weCheck = driver().findElement(By.xpath(INCREASED_VALUABLES_CHECKBOXES_FIELD_XPATH + "[" + (i + 1) + "]//input"));
                        waitAndClickElement(weCheck);
                    }
                    performADATesting(this.getClass().getSimpleName()+"_IncreasedCoverageForValuables_IncreasedLimits",MARKETING_IT,FFQ_ACE_CONDO);
                    break;
                case EARTHQUAKE:
                    performADATesting(this.getClass().getSimpleName()+"_Earthquake",MARKETING_IT,FFQ_ACE_CONDO);
                    break;
            }
            toggleAdditionalCoverage(coverageTitle, false);
        }
    }
}

