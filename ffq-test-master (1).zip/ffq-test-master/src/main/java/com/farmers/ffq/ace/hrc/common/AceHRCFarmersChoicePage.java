package com.farmers.ffq.ace.hrc.common;

import com.farmers.ffq.utils.FarmersSoftAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class AceHRCFarmersChoicePage extends AceHRCBasePage {

    @FindBy(xpath = "//div//nav[@data-topbar]//a[contains(@class,'logo')]")
    private WebElement pageTitle;
    private static final String PAGE_TITLE_TEXT = "Farmers Insurance Choice";

    @FindBy(xpath = "//div//nav[@data-topbar]//a[contains(@class,'partner-logo')]")
    private WebElement partnerLogo;

    private static final String XPATH_HERO = "//section[@id='hero']//h1";
    @FindBy(xpath = XPATH_HERO)
    private WebElement farmersHeroTitle;
    private static final String TITLE_HERO_TEXT = "MORE CHOICE, MORE SAVINGS";

    private static final String XPATH_PRODUCTS = "//section[@class='products']//h3";
    @FindBy(xpath = XPATH_PRODUCTS)
    private WebElement farmersProducts;
    private static final String PRODUCTS_SUBTITLE_TEXT = "Farmers Insurance Choice lets you compare and save on insurance";
    private static final String PRODUCTS_SUBTITLE_TEXT_URBN = "It's easy for URBN employees to compare and save on insurance with Farmers Insurance Choice.";

    private static final String XPATH_ZIP = "//section[@id='hero']//form[@id='quote-form']//input[@id='zipcode']";
    @FindBy(xpath = XPATH_ZIP)
    private WebElement inputZip;

    private static final String XPATH_START_QUOTE = "//section[@id='hero']//button[@id='start-quote']";
    @FindBy(xpath = XPATH_START_QUOTE)
    private WebElement buttonToStartQuote;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public AceHRCFarmersChoicePage() throws Exception {
        super();
        waitForSpinnerToBeGone();
        wait.until(ExpectedConditions.urlContains("/uat.farmersinsurancechoice.com/"));
    }

    public void verifyPageElements(String partnerText, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getAttributeData(pageTitle, "text").trim(), PAGE_TITLE_TEXT, "Farmers Insurance Choice page - Page Title");
        fsa.assertTrue(getAttributeData(partnerLogo, "style").contains(partnerText.toLowerCase()), "Farmers Insurance Choice page - Partner Logo");
        fsa.assertEquals(getTextFromElement(farmersHeroTitle), TITLE_HERO_TEXT, "Farmers Insurance Choice page - Hero section title");
        fsa.assertTrue(isElementDisplayed(By.xpath(XPATH_ZIP)), "Farmers Insurance Choice page - Input Zip Code field");
        fsa.assertTrue(isElementDisplayed(By.xpath(XPATH_START_QUOTE)), "Farmers Insurance Choice page - Button to start a quote");
        String subtitle = partnerText.contains("urbn") ? PRODUCTS_SUBTITLE_TEXT_URBN : PRODUCTS_SUBTITLE_TEXT;
        fsa.assertEquals(getTextFromElement(farmersProducts), subtitle, "Farmers Insurance Choice page - Farmers Insurance Subtitle is displayed");
    }
}
