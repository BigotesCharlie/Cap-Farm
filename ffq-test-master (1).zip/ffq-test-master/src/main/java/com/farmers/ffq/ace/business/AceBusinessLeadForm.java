package com.farmers.ffq.ace.business;

import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.ApplicantBusiness;
import com.farmers.ffq.datatransferobjects.ApplicantBusiness.contactMethods;
import com.farmers.ffq.datatransferobjects.ApplicantBusiness.contactTimes;
import com.farmers.ffq.datatransferobjects.ApplicantBusiness.insuranceStatusValues;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;

public class AceBusinessLeadForm extends BasePage {

	@FindBy (xpath = "//app-business-info//h1")
	private WebElement leadFormTitle;

	@FindBy (className = "section-header")
	private WebElement leadFormSubtitle;

	private static final String POLICY_TYPE_SECTION_XPATH = "//div[contains(@class, 'coverage-limit-section')]";
	@FindBy (xpath = POLICY_TYPE_SECTION_XPATH + "//div[@class='field-label-with-info']//label")
	private WebElement policyTypeSectionLabel;
	@FindBy (xpath = POLICY_TYPE_SECTION_XPATH + "//mat-checkbox//input")
	private List<WebElement> listOfPolicyTypeCheckboxes;
	@FindBy (xpath = "//div[contains(@class, 'other-policy-input')]//input")
	private WebElement otherPolicyTypeInputField;
	@FindBy (xpath = POLICY_TYPE_SECTION_XPATH + "//span[@class='mat-checkbox-label'] | " + POLICY_TYPE_SECTION_XPATH + "//label[@class='mdc-label']")
	private List<WebElement> listOfPolicyTypeCheckboxLabels;
	@FindBy (xpath = POLICY_TYPE_SECTION_XPATH + "//mat-icon")
	private WebElement policyTypeInfoIcon;
	@FindBy (xpath = "//mat-dialog-container//h1")
	private WebElement typesOfPoliciesHelpDialogTitle;
	@FindBy (className = "main-content")
	private WebElement typesOfPoliciesHelpDialogContent;


	private static final String BUSINESS_DESCRIPTION_FIELD_XPATH = "//div[contains(@class, 'business-description-field')]";
	@FindBy (xpath = BUSINESS_DESCRIPTION_FIELD_XPATH + "/label")
	private WebElement businessIndustryLabel;
	@FindBy (xpath = BUSINESS_DESCRIPTION_FIELD_XPATH + "//input")
	private WebElement businessIndustryInputField;

	private static final String BUSINESS_INFO_SECTION_XPATH = "//div[@class='business-info-section']";
	@FindBy (xpath = BUSINESS_INFO_SECTION_XPATH + "/label")
	private WebElement businessInfosectionLabel;
	@FindBy (xpath = "//mat-label[text()='Business name']/ancestor-or-self::div/input")
	private WebElement businessNameInputField;
	@FindBy (id = "auto-manual-street__input-section")
	private WebElement businessAddressInputField;
	@FindBy (xpath = "//input[@aria-label='city']")
	private WebElement cityInputField;
	@FindBy (xpath = "//input[@aria-label='zipCode']")
	private WebElement zipCodeInputField;
	@FindBy (xpath = "//div[@id='formField_state']//input")
	private WebElement stateInputField;
	@FindBy (xpath = "//mat-label[text()='Business Website URL']/ancestor-or-self::div/input")
	private WebElement businessWebsiteInpuField;

	private static final String BUSINESS_DESCRIPTION_SECTION_XPATH = "//div[@class='business-description-section']";
	@FindBy (xpath = BUSINESS_DESCRIPTION_SECTION_XPATH + "/label")
	private WebElement currentlyInsuredSectionLabel;
	@FindBy (xpath = BUSINESS_DESCRIPTION_SECTION_XPATH + "//mat-radio-button//label")
	private List<WebElement> listOfInsuranceDescriptionLabels;
	@FindBy (xpath = BUSINESS_DESCRIPTION_SECTION_XPATH + "//input")
	private List<WebElement> listOfInsuranceRadioButtons;
	@FindBy (xpath = "//label[contains(@class, 'business-additional-info')]")
	private WebElement additionalInfoLabel;
	@FindBy (xpath = "//mat-label[contains(text(), 'Details about')]/ancestor-or-self::div/input")
	private WebElement additionalInsuranceDetailsInputField;

	@FindBy (xpath = "//div[@class='personal-info-section']/label")
	private WebElement personalInformationLabel;
	@FindBy (xpath = "//mat-label[text()='First name']/ancestor-or-self::div/input")
	private WebElement firstNameInputField;
	@FindBy (xpath = "//mat-label[text()='Last name']/ancestor-or-self::div/input")
	private WebElement lastNameInputField;
	@FindBy (xpath = "//mat-label[contains(text(), 'Date of birth')]/ancestor-or-self::div/input")
	private WebElement dobInputField;
	@FindBy (xpath = "//input[@type='email']")
	private WebElement emailInputField;
	@FindBy (id = "contact-details-phoneNumber-input_Field")
	private WebElement phoneNumberInputField;
	@FindBy (xpath = "//input[@type='tel']")
	private WebElement extensionInputField;

	private static final String CONTACT_METHOD_SECTION_XPATH = "//div[@class='contact-preferences-section']";
	@FindBy(xpath = CONTACT_METHOD_SECTION_XPATH + "//label")
	private List<WebElement> listOfContactSectionLabels;
	@FindBy (xpath = CONTACT_METHOD_SECTION_XPATH + "/mat-radio-group//input")
	private List<WebElement> listOfContactMethodPreferenceRadioButtons;
	private static final String CONTACT_TIME_SECTION_XPATH = "//div[@class='time-preference-section']";
	@FindBy (xpath = CONTACT_TIME_SECTION_XPATH + "/mat-radio-group//input")
	private List<WebElement> listOfContactTimePreferenceRadioButtons;

	@FindBy (className = "disclaimer-section")
	private WebElement disclaimerSection;

	@FindBy (xpath = "//button[@type='submit']")
	private WebElement agreeAndSubmitButton;

	public AceBusinessLeadForm() throws Exception {
		super();
	}

	public boolean isOnBusinessLeadForm() {
		return isElementVisible(businessIndustryInputField, 3);
	}

	public void verifyPageContent(FarmersSoftAssert fsa, ApplicantBusiness businessApplicant) throws Exception {
		String separator = isSafariBrowser()? EMPTY_STRING : SPACE;
		List <String> listOfExpectedPolicyTypeSectionLabels = List.of("Businessowners policy (General Liability and Property)",
				"Commercial auto insurance",
				"Workers' compensation insurance",
				"Other");
		List <String> listOfExpectedBusinessDescriptionSectionLabels = List.of("I am in business and have business insurance",
				"I am in business, but don't have business insurance yet",
				"I am starting a business and interested in business insurance");
		List<String> listOfExpectedContactSectionLabels = List.of("How would you like to be contacted?",
				"Phone call",
				"Email",
				"No Preference",
				"What time of day works best for you?",
				"Morning",
				"Afternoon",
				"No Preference");
		String expectedHelpContent = "Businessowners Policy A Businessowners Policy (BOP) combines the major property and liability coverages into one insurance policy. Business property coverage can help when your business personal property or inventory is damaged by a covered event. In addition, Business liability insurance coverage can help you pay legal costs when someone — such as a customer or visitor — is hurt or suffers property damage and blames you and your business. If your company is found to be at fault, your business is legally responsible for the costs. " +
				"Commercial Auto Insurance" + separator + "However you use vehicles in your business, one thing is clear: You need commercial auto insurance. And Farmers\u00ae can help with numerous coverage options. Because Farmers agents are also small business owners, they understand the unique challenges of commercial driving in today's increasingly distracted world." + separator +
				"Workers' Compensation Insurance" + separator + "In a best-case scenario, you're able to manage recovery from an injury so employees can get back to work as quickly as possible. And Farmers has highly specialized workers' compensation services that can help. A workers' compensation policy can address medical care and lost income for your employees, death benefits for survivors, and your potential liability for covered claims. Farmers works with you to help reduce costs and improve recovery times — by making quick contact with an injured employee and using excellent medical providers for a specific injury or illness.";

		fsa.assertEquals(getTextFromElement(leadFormTitle), "Let's get started", "Lead form title");
		fsa.assertEquals(getTextFromElement(leadFormSubtitle), "Business coverage starts here - Tell us what you're looking for", "Lead form subtitle");
		fsa.assertEquals(getTextFromElement(policyTypeSectionLabel), "What type of policy are you looking for? Please select all that apply.", "Policy type section label");
		scrollAndClickOnElement(policyTypeInfoIcon);
		fsa.assertEquals(getTextFromElement(waitElementBeVisible(typesOfPoliciesHelpDialogTitle)), "Types of policies", "Policy types help dialog title");
		fsa.assertEquals(getTextFromElement(typesOfPoliciesHelpDialogContent), expectedHelpContent, "Policy types help dialog content");
		clickElement(closeIcon);
		waitElementBeInvisible(typesOfPoliciesHelpDialogTitle);
		fsa.assertEquals(getTextFromListOfWebElementNodes(listOfPolicyTypeCheckboxLabels), listOfExpectedPolicyTypeSectionLabels, "Type of policies label verification");
		fsa.assertEquals(getTextFromElement(businessIndustryLabel), "Describe what your business does and we'll help find the applicable industry.", "Industry type header");
		fsa.assertEquals(getTextFromElement(businessInfosectionLabel), "Now some information about your business", "Business information section header");
		fsa.assertEquals(getTextFromElement(currentlyInsuredSectionLabel), "Which of the following best describes your business?", "Insurance for business section label");
		fsa.assertEquals(getTextFromListOfWebElementsAndDescendents(listOfInsuranceDescriptionLabels), listOfExpectedBusinessDescriptionSectionLabels, "Insurance need section labels verification");
		fsa.assertEquals(getTextFromElement(additionalInfoLabel), "Is there anything else that you want us to know? (optional)", "Anything else label");
		fsa.assertEquals(getTextFromElement(personalInformationLabel), "Now some information about you", "Personal information label");
		fsa.assertEquals(getTextFromListOfWebElementsAndDescendents(listOfContactSectionLabels), listOfExpectedContactSectionLabels, "Contact information labels");
		fsa.assertEquals(getTextFromElement(agreeAndSubmitButton), "Agree and submit", "CTA label");
		new AceHRCBasePage().validatePageLinksText(fsa, businessApplicant.getBusinessId().equals(AWS_SCENARIOS)? AWS_SCENARIOS : DISABLED);
	}

	public void validatePageErrors(FarmersSoftAssert fsa, ApplicantBusiness businessApplicant) throws Exception {
		scrollAndClickOnElement(agreeAndSubmitButton);
		scrollToTopOfPage();
		List <String> listOfExpectedErrorLabels = List.of(
				"This is a required field.",
				"Please describe what your business does.",
				"Please provide your business name.",
				"Please provide your business address.",
				"Please enter your city.",
				"This is a required field.",
				"Please provide your first name.",
				"Please provide your last name.",
				"Please enter your email address.",
				"Please enter your phone number.",
				"One or more required fields is incomplete or incorrect. Please review.");
		List<WebElement> listOfErrorElements = driver().findElements(By.xpath("//mat-error[not(@hidden)] | //div[contains(@class, 'error-message')]"));
		List<String> listOfErrorsFoundOnPage = listOfErrorElements.stream().map(this::getTextFromElement).collect(Collectors.toList());
		fsa.assertEquals(listOfErrorsFoundOnPage, listOfExpectedErrorLabels, "Validate list of error messages" + listOfErrorsFoundOnPage);
		listOfErrorElements.addAll(List.of(policyTypeSectionLabel, businessIndustryLabel, businessInfosectionLabel, currentlyInsuredSectionLabel, personalInformationLabel));
		listOfErrorElements.forEach(errorMessage -> checkErrorColorForElement(errorMessage, fsa));
		selectPolicyType("Other with no value");
		WebElement missingOtherPolicyTypeErrorLabel = driver().findElement(By.xpath("//div[contains(@class, 'other-policy-input')]//mat-error"));
		fsa.assertEquals(getTextFromElement(missingOtherPolicyTypeErrorLabel), "Please specify type of policy.", "Missing other policy info error message");
		checkErrorColorForElement(policyTypeSectionLabel, fsa);
		checkErrorColorForElement(missingOtherPolicyTypeErrorLabel, fsa);
	}

	public void fillOutPageAndContinue(ApplicantBusiness businessApplicant) {
		selectPolicyType(businessApplicant.getListOfPolicyTypes());
		enterBusinessIndustry(businessApplicant.getIndustry());
		enterBusinessName(businessApplicant.getBusinessName());
		enterBusinessAddress(businessApplicant.getAddress1(), businessApplicant.getCity());
		//		enterCity(businessApplicant.getCity());
		//		enterZipCode(businessApplicant.getZipCode());
		enterWebsite(businessApplicant.getWebsite());
		selectCurrentInsuranceStatus(businessApplicant.getCurrentInsuranceStatus());
		enterAdditionalDetails(businessApplicant.getAdditionalDetails());
		enterFirstName(businessApplicant.getFirstName());
		enterLastName(businessApplicant.getLastName());
		enterDateOfBirth(calculateDateOfBirthFromAge(businessApplicant.getAge()));
		enterEmailAddress(businessApplicant.getEmail());
		enterPhoneNumber(businessApplicant.getPhoneNumber());
		enterPhoneNumberExtension(businessApplicant.getExtension());
		selectContactMethodPreference(businessApplicant.getContactMethodPreference());
		selectContactTimePreference(businessApplicant.getContactTimePreference());
		clickCTAButton();
		waitForSpinnerToBeGone();
	}

	private void selectPolicyType(List<String> listOfPolicyTypes) {
		if (!listOfPolicyTypes.isEmpty()) {
			listOfPolicyTypes.forEach(policyType -> selectPolicyType(policyType));
		}
	}

	private void selectPolicyType(String policyType) {
		switch (policyType) {
			case BUSINESSOWNER:
				setCheckboxTo(listOfPolicyTypeCheckboxes.get(0),true);
				break;
			case COMMERCIAL_AUTO:
				setCheckboxTo(listOfPolicyTypeCheckboxes.get(1), true);
				break;
			case WORKERS_COMPENSATION:
				setCheckboxTo(listOfPolicyTypeCheckboxes.get(2), true);
				break;
			case OTHER:
				setCheckboxTo(listOfPolicyTypeCheckboxes.get(3), true);
				enterValueInField("Property insurance", otherPolicyTypeInputField, "Entering Other policy type: ");
				break;
			default: // select other and provide no value
				setCheckboxTo(listOfPolicyTypeCheckboxes.get(3), true);
				break;
		}
	}

	private List<String> getListOfSelectedPolicyTypes() {
		List<String> listOfSelectedPolicyTypes = new ArrayList<>();
		if (listOfPolicyTypeCheckboxes.get(0).isSelected()) listOfSelectedPolicyTypes.add(BUSINESSOWNER);
		if (listOfPolicyTypeCheckboxes.get(1).isSelected()) listOfSelectedPolicyTypes.add(COMMERCIAL_AUTO);
		if (listOfPolicyTypeCheckboxes.get(2).isSelected()) listOfSelectedPolicyTypes.add(WORKERS_COMPENSATION);
		if (listOfPolicyTypeCheckboxes.get(3).isSelected()) listOfSelectedPolicyTypes.add(OTHER);
		return listOfSelectedPolicyTypes;
	}

	private void enterBusinessIndustry(String industry) {
		enterValueInField(industry, businessIndustryInputField, "Entering Business Industry: ");
		try {
			waitForElements(DROPDOWN_OPTIONS_XPATH);
			List<WebElement> listOfOptions = driver().findElements(By.xpath(DROPDOWN_OPTIONS_XPATH));
			if (!listOfOptions.isEmpty()) {
				clickElement(listOfOptions.get(FIRST_AVAILABLE_OPTION));
			} else {
				Log.info("Did not find options in " + businessIndustryInputField);
			}
		} catch (Exception e) {
			Log.error(e.getMessage());
		}
	}

	private String getBusinessIndustry() {
		return getElementValue(businessIndustryInputField, "Business Name: ");
	}

	private void enterBusinessName(String businessName) {
		enterValueInField(businessName, businessNameInputField, "Entering Business Name: ");
	}

	private String getBusinessName() {
		return getElementValue(businessNameInputField, "Business Name: ");
	}

	private void enterBusinessAddress(String businessAddress, String businessCity) {
		enterGoogleAddress(businessAddressInputField, businessAddress, EMPTY_STRING);
		//		enterValueInField(businessAddress, businessAddressInputField, "Entering business address: ");
	}

	private String getBusinessAddress() {
		return getElementValue(businessAddressInputField, "Business Address: ");
	}

	private void enterCity(String city) {
		enterValueInField(city, cityInputField, "Entering City: ");
	}

	private String getBusinessCity() {
		return getElementValue(cityInputField, "City: ");
	}

	private void enterZipCode(String zipCode) {
		enterValueInField(zipCode, zipCodeInputField, "Entering Zip code: ");
	}

	private String getBusinessZipCode() {
		return getElementValue(zipCodeInputField, "Zip code: ");
	}

	private String getBusinessStateCode() {
		return getElementValue(stateInputField, "State code: ");
	}

	private void enterWebsite(String website) {
		enterValueInField(website, businessWebsiteInpuField, "Entering Business website address: ");
	}

	private String getBusinessWebsiteAddress() {
		return getElementValue(businessWebsiteInpuField, "Business Website Address: ");
	}

	private void selectCurrentInsuranceStatus(insuranceStatusValues currentInsuranceStatus) {
		int radioButtonIndex = LAST_AVAILABLE_OPTION;
		switch (currentInsuranceStatus) {
			case HAVE:
				radioButtonIndex = 0;
				break;
			case DONT_HAVE:
				radioButtonIndex = 1;
				break;
			case INTERESTED:
				radioButtonIndex = 2;
				break;
			default:
				Log.error("Unexpected value for radio button selection");
				break;
		}
		if (radioButtonIndex != LAST_AVAILABLE_OPTION) {
			scrollAndClickOnElement(listOfInsuranceRadioButtons.get(radioButtonIndex));
		}
	}

    private insuranceStatusValues getCurrentInsuranceStatus() throws Exception {
        insuranceStatusValues currentInsuranceStatus = null;
        WebElement selectedInsuranceRadioButton = driver().findElement(By.xpath(BUSINESS_DESCRIPTION_SECTION_XPATH + "//mat-radio-group/mat-radio-button[contains(@class, '" + RADIO_BUTTON_CHECKED + "')]//label"));
        String selectionText = getTextFromElement(selectedInsuranceRadioButton);
        if (selectionText.contains(" and have ")) {
            currentInsuranceStatus = insuranceStatusValues.HAVE;
        } else if (selectionText.contains(" but don't have ")) {
            currentInsuranceStatus = insuranceStatusValues.DONT_HAVE;
        } else if (selectionText.contains(" interested ")) {
            currentInsuranceStatus = insuranceStatusValues.INTERESTED;
        }
        return currentInsuranceStatus;
    }

    private void enterAdditionalDetails(String additionalDetails) {
        enterValueInField(additionalDetails, additionalInsuranceDetailsInputField, "Entering additional details: ");
    }

    private String getAddtionalDetails() {
        return getElementValue(additionalInsuranceDetailsInputField, "Additional details: ");
    }

    private void enterFirstName(String name) {
        enterValueInField(name, firstNameInputField, "Entering First name: ");
    }

    private String getFirstName() {
        return getElementValue(firstNameInputField, "First Name: ");

    }
	private void enterLastName(String lastName) {
		enterValueInField(lastName, lastNameInputField, "Entering Last name: ");
	}

	private String getLastName() {
		return getElementValue(lastNameInputField, "Last Name: ");
	}

	private void enterDateOfBirth(String dateOfBirth) {
		enterValueInField(dateOfBirth, dobInputField, "Entering DOB: ");
	}

	private String getDateOfBirth() {
		return getElementValue(dobInputField, "Date of birth: ");
	}

	private void enterEmailAddress(String email) {
		enterValueInField(email, emailInputField, "Entering Email Address: ");
	}

	private String getEmailAddress() {
		return getElementValue(emailInputField, "Email address: ");
	}

	private void enterPhoneNumber(String number) {
		enterValueInField(number, phoneNumberInputField, "Entering Phone Number: ");
	}

	private String getPhoneNumber() {
		return getElementValue(phoneNumberInputField, "Phone number: ");
	}

	private void enterPhoneNumberExtension(String phoneNumberExtension) {
		enterValueInField(phoneNumberExtension, extensionInputField, "Entering Phone Number Extension: ");
	}

	private void selectContactMethodPreference(contactMethods contactMethodPreference) {
		int radioButtonIndex = LAST_AVAILABLE_OPTION;
		switch (contactMethodPreference) {
			case EMAIL:
				radioButtonIndex = 0;
				break;
			case PHONE:
				radioButtonIndex = 1;
				break;
			case NOPREFERENCE:
				radioButtonIndex = 2;
				break;
			default:
				Log.error("Unexpected value for radio button selection " + contactMethodPreference);
				break;
		}
		if (radioButtonIndex != LAST_AVAILABLE_OPTION) {
			scrollAndClickOnElement(listOfContactMethodPreferenceRadioButtons.get(radioButtonIndex));
		}
	}

	private contactMethods getContactMethodPreference() throws Exception {
		contactMethods preference = null;
		WebElement selectedContactMethod = driver().findElement(By.xpath(CONTACT_METHOD_SECTION_XPATH + "/mat-radio-group/mat-radio-button[contains(@class, 'mat-radio-checked')]//label"));
		String selectionText = getTextFromElement(selectedContactMethod);
		if (selectionText.contains("call")) {
			preference = contactMethods.PHONE;
		} else if (selectionText.contains("Email" )) {
			preference = contactMethods.EMAIL;
		} else if (selectionText.contains("Preference" )) {
			preference = contactMethods.NOPREFERENCE;
		}
		return preference;
	}

	private void selectContactTimePreference(contactTimes contactTimePreference) {
		int radioButtonIndex = LAST_AVAILABLE_OPTION;
		switch (contactTimePreference) {
			case MORNING:
				radioButtonIndex = 0;
				break;
			case AFTERNOON:
				radioButtonIndex = 1;
				break;
			case NOPREFERENCE:
				radioButtonIndex = 2;
				break;
			default:
				Log.error("Unexpected value for radio button selection " + contactTimePreference);
				break;
		}
		if (radioButtonIndex != LAST_AVAILABLE_OPTION) {
			scrollAndClickOnElement(listOfContactTimePreferenceRadioButtons.get(radioButtonIndex));
		}
	}

	private contactTimes getContactTimePreference() throws Exception {
		contactTimes preference = null;
		WebElement selectedContactMethod = driver().findElement(By.xpath(CONTACT_METHOD_SECTION_XPATH + "/mat-radio-group/mat-radio-button[contains(@class, 'mat-radio-checked')]//label"));
		String selectionText = getTextFromElement(selectedContactMethod);
		if (selectionText.contains("Morning")) {
			preference = contactTimes.MORNING;
		} else if (selectionText.contains("Afternoon" )) {
			preference = contactTimes.AFTERNOON;
		} else if (selectionText.contains("Preference" )) {
			preference = contactTimes.NOPREFERENCE;
		}
		return preference;
	}

	public void clickCTAButton()  {
		scrollAndClickOnElement(agreeAndSubmitButton);
	}

	private void checkErrorColorForElement(WebElement element, FarmersSoftAssert fsa) {
		String elementColor = element.getCssValue(COLOR);
		List<String> listOfValidColorStrings = List.of("rgba(197, 22, 45, 1)", "rgb(197, 22, 45)", "rgb(179, 0, 50)");
		fsa.assertTrue(listOfValidColorStrings.contains(elementColor), "["+ getTextFromElement(element) + "] message color is one of " + listOfValidColorStrings);
}

	public void capturePEWC() throws Exception {
		scrollToBottomOfPage();
		screenCapture(agreeAndSubmitButton, "AceBusiness_LeadForm", LARGE, false);
	}

}
