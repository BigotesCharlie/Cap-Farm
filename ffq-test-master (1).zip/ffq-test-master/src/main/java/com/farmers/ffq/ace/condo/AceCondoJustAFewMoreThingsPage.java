package com.farmers.ffq.ace.condo;

import com.farmers.ffq.ace.hrc.common.AceHRCJustAFewMoreThingsBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.farmers.ffq.utils.GlobalVariables.CA;

public class AceCondoJustAFewMoreThingsPage extends AceHRCJustAFewMoreThingsBasePage {
    @FindBy(xpath = "//mat-label[contains(text(),'HOA covers everything \u201cwalls-in\u201d')]")
    private WebElement hoaCoversEveyThingsWallsInCheckBox;

    @FindBy(xpath = "//p[contains(text(),' This is uncommon. Not sure if it applies?')]")
    private WebElement hoaCoversEveyThingsWallsInCheckBoxSubHeader;
    @FindBy(xpath = "//a[contains(@class,'hoaWallsInLink')]")
    private WebElement learnWhatWallsInMeanLink;
    @FindBy(xpath = "//h1[contains(text(), 'HOA covers')]")
    private WebElement hoaCoversWallsInHeaderSideSheet;

    @FindBy(xpath = "//p[contains(text(), 'Check with your HOA if you are unsure.')]")
    private WebElement hoaCoversWallsInDescriptionSideSheet;
    @FindBy(xpath = "//mat-icon[contains(text(),'close')]")
    private WebElement closeIconWhatWallsInSideSheet;

    public AceCondoJustAFewMoreThingsPage() throws Exception {
    }

    public void validateOtherQuestionsSectionCondoLob(ApplicantAceHome applicantAceHome, FarmersSoftAssert fsa) throws Exception {
        validateHOACoversEveryThingsWallsIn(fsa);
        validateBusinessOperatedOnPremises(fsa);
        validateDogsOnPremises(applicantAceHome.getDogsOnPremises(), applicantAceHome.getUpdatedDogsOnPremises(), fsa);
        validatePetWithBiteHistory(fsa);
        validateSelectTerritory(applicantAceHome, fsa);
    }

    public void validateHOACoversEveryThingsWallsIn(FarmersSoftAssert fsa) {
        clickOnHOACoversEveryThingWallsInCheckBox();

        final String HOA_COVERS_EVEY_THINGS_WALLS_IN_CHECKBOX_CONTENT = "HOA covers everything \"walls-in\"";
        fsa.assertEquals(getTextFromElement(hoaCoversEveyThingsWallsInCheckBox), HOA_COVERS_EVEY_THINGS_WALLS_IN_CHECKBOX_CONTENT, "HOA covers everything checkbox header check");

        final String HOA_COVERS_EVEY_THINGS_WALLS_IN_CHECKBOX_SUB_HEADER_CONTENT = "This is uncommon. Not sure if it applies? Learn what \"walls-in\" means.";
        fsa.assertEquals(getTextFromElement(hoaCoversEveyThingsWallsInCheckBoxSubHeader), HOA_COVERS_EVEY_THINGS_WALLS_IN_CHECKBOX_SUB_HEADER_CONTENT, "HOA covers everything checkbox sub header check");

        final String WHAT_WALLS_IN_MEAN_LINK_TEXT = "Learn what \"walls-in\" means.";
        fsa.assertEquals(getTextFromElement(learnWhatWallsInMeanLink), WHAT_WALLS_IN_MEAN_LINK_TEXT, "What walls-in mean link text check");

        clickWhatWallsInMeanLink();

        final String HOA_COVERS_WALLS_IN_HEADER_SIDE_SHEET = "HOA covers \"walls-in\"";
        fsa.assertEquals(getTextFromElement(hoaCoversWallsInHeaderSideSheet), HOA_COVERS_WALLS_IN_HEADER_SIDE_SHEET, "HOA covers walls in header text check in side sheet");

        final String HOA_COVERS_WALLS_IN_DESCRIPTION_SIDE_SHEET = "Association policy covers the cost to repair or rebuild the unit interior back to how it was originally built or purchased." +
                " The specifics are detailed in the condominium association master agreement." +
                " Unit owner is responsible to insure upgrades made to the unit interior which are not part of the association policy. Check with your HOA if you are unsure.";
        fsa.assertEquals(getTextFromElement(hoaCoversWallsInDescriptionSideSheet), HOA_COVERS_WALLS_IN_DESCRIPTION_SIDE_SHEET, "HOA covers walls in description text check in side sheet");

        clickCloseIconOnWhatWallsInMeanSideSheet();
    }

    public void clickWhatWallsInMeanLink() {
        waitAndClickElement(learnWhatWallsInMeanLink);
    }

    public void clickCloseIconOnWhatWallsInMeanSideSheet() {
        waitAndClickElement(closeIconWhatWallsInSideSheet);
    }

    public void clickOnHOACoversEveryThingWallsInCheckBox() {
        waitAndClickElement(hoaCoversEveyThingsWallsInCheckBox);
    }

    public void fillOutFMTPWithAllOtherQuestionsSelectedCondoLob(ApplicantAceHome applicantAceHome) throws Exception {
        if (applicantAceHome.isNewlyOwned()) {
            fillOutHomePurchaseDate(getFormattedYesterdayDate());
        }

        selectMortgageOnThisProperty(false);

        selectBusinessOperatedOnPremisesCheckBox(applicantAceHome.isBusinessOperatedOnPremises());
        selectDogsOnPremisesCheckbox(applicantAceHome.getDogsOnPremises());
        selectPetWithBiteHistoryCheckBox(applicantAceHome.isPetWithBiteHistory());
        clickContinueButton();
    }

    public void fillOutFMTPWithBusinessOperatedOnPremisesSelectedCondoLob(ApplicantAceHome applicantAceHome) throws Exception {
        selectMortgageOnThisProperty(false);
        selectBusinessOperatedOnPremisesCheckBox(applicantAceHome.isBusinessOperatedOnPremises());
        if (applicantAceHome.isNewlyOwned()) {
            fillOutHomePurchaseDate(getFormattedYesterdayDate());
        }
        clickContinueButton();
    }

    public void fillOutFMTPWithHOACoversWallsInSelectedCondoLob() throws Exception {
        selectMortgageOnThisProperty(false);
        clickOnHOACoversEveryThingWallsInCheckBox();
        clickContinueButton();
    }

    public void fillOutFMTPWithPetWithBiteHistorySelectedCondoLob(ApplicantAceHome applicantAceHome) throws Exception {
        if (applicantAceHome.isNewlyOwned()) {
            fillOutHomePurchaseDate(getFormattedYesterdayDate());
        }
        selectMortgageOnThisProperty(false);
        selectPetWithBiteHistoryCheckBox(applicantAceHome.isPetWithBiteHistory());
        clickContinueButton();
    }

    public void fillOutJustFewMoreThingsPageCondo(ApplicantAceHome applicant, boolean continueButton) throws Exception {
        if (applicant.isNewlyOwned() && !applicant.isInEscrow()) {
            fillOutHomePurchaseDate(getFormattedYesterdayDate());
        }
        selectMortgageOnThisProperty(false);
        fillOutTerritory(applicant);
        if (applicant.getStateCode().equals(CA)) {
            fillOutRNOGSectionNo();
            fillOutFlowOfWaterShutoffYes();
        }
        selectDogsOnPremisesCheckbox(applicant.getDogsOnPremises());
        if (continueButton) {
            clickContinueButton();
        }
    }
}
