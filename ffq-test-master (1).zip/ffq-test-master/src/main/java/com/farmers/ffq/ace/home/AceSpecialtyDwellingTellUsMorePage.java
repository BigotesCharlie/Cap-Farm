package com.farmers.ffq.ace.home;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.invisibilityOfElementLocated;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;

public class AceSpecialtyDwellingTellUsMorePage extends AceHRCBasePage {

	@FindBy (id = "dwelling-details-heading")
	private WebElement tellUsMorePageTitle;

	@FindBy (xpath = "//*[contains(@class, 'size-label')]")
	private WebElement yearBuiltLabel;

	@FindBy(xpath = "//input[@role='combobox']")
	private WebElement yearBuiltInputField;

	@FindBy (xpath = "//mat-form-field/preceding-sibling::h2[contains(text(), 'purchase')]")
	private WebElement purchaseDateLabel;

	@FindBy(xpath = "//input[@formcontrolname='purchaseDate']")
	private WebElement purchaseDateInputField;

	@FindBy (xpath = "//*[contains(@class, 'replacement-cost-label')]")
	private WebElement replacementCostLabel;

	@FindBy (xpath = "//mat-icon[contains(@aria-label, 'Replacement cost')]")
	private WebElement replacementCostHelpIcon;

	@FindBy (xpath = "//input[@formcontrolname='replacementCost']")
	private WebElement replacementCostInputField;

	@FindBy (xpath = "//mat-form-field/preceding-sibling::h2[contains(text(), 'type')]")
	private WebElement typeOfHomeLabel;

	@FindBy (xpath = "//mat-select[@formcontrolname='typeOfHome']")
	private WebElement typeOfHomeDropdown;

	@FindBy (id = "townhouse-row-house-label")
	private WebElement townhouseRowhouseLabel;

	@FindBy (xpath = "//mat-button-toggle-group[@formcontrolname='townhouseOrRowhouse']//span[contains(@class, 'label-content')][text()='Yes']/parent::button")
	private WebElement yesTownhouseButton;

	@FindBy (xpath = "//mat-button-toggle-group[@formcontrolname='townhouseOrRowhouse']//span[contains(@class, 'label-content')][text()='No']/parent::button")
	private WebElement noTownhouseButton;

	@FindBy (id = "units-label")
	private WebElement unitsLabel;
	private static final String UNIT_BUTTON_XPATH_STRING = "//mat-button-toggle-group[@formcontrolname='numUnitsForThisRentalProperty']//span[contains(@class, 'label-content')][normalize-space(text())='%s']/parent::button";

	@FindBy (id = "claims-label")
	private WebElement claimsLabel;
	private static final String CLAIMS_BUTTON_XPATH_STRING = "//mat-button-toggle-group[@formcontrolname='propertyClaimIn5Yrs']//span[contains(@class, 'label-content')][normalize-space(text())='%s']/parent::button";

	@FindBy (id = "cancellation-label")
	private WebElement cancellationLabel;

	@FindBy (xpath = "//mat-button-toggle-group[@formcontrolname='policyCancellationIn5Yrs']//span[contains(@class, 'label-content')][text()='Yes']/parent::button")
	private WebElement yesCancellationButton;

	@FindBy (xpath = "//mat-button-toggle-group[@formcontrolname='policyCancellationIn5Yrs']//span[contains(@class, 'label-content')][text()='No']/parent::button")
	private WebElement noCancellationButton;

	public AceSpecialtyDwellingTellUsMorePage() throws Exception {
		super();
	}

	public boolean isOnTellUsMorePage() {
		return isElementVisible(yearBuiltInputField, 10);
	}

	public void fillOutPageAndContinue(ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		enterValueInField(Integer.toString(specialtyDwellingApplicant.getYearBuilt()), yearBuiltInputField, "Enter Year built:");
		enterValueInField(DateTimeFormatter.ofPattern("MM/yyyy").format(LocalDate.of(specialtyDwellingApplicant.getYearBuilt(), 1, 1).plusYears(3)), purchaseDateInputField, "Enter purchase date");
		enterValueInField(specialtyDwellingApplicant.getReplacementCost(), replacementCostInputField, "Enter home's replacement cost:");
		selectValueInDropDown(typeOfHomeDropdown, specialtyDwellingApplicant.getTypeOfHome());
		// for now not changing rest of values, but they would be here
		scrollAndClickOnElement(buttonContinue);
		waitForSpinnerToBeGone();
	}

	public void verifyPageContent(FarmersSoftAssert fsa, ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		String testCategory = specialtyDwellingApplicant.getTestCategory();
		boolean isForemostQuote = testCategory.equals(FOREMOST);
		String activeStep = getActiveStep(testCategory);
		if (!isForemostQuote) {
			verifySpecialtyDwellingCommonHeader(fsa);
		}
		String REPLACEMENT_COST_HELP_CONTENT = "Please provide the estimated cost to replace your home with a new, equivalent model. " +
				"Include structures attached to the home, but don't include your personal belongings. " +
				"Do not use the appraisal value of the home since that reflects the price you can expect to receive if you sell your home—which would include the value of your land.";
		List<String> listOfHomeTypes = List.of("Adobe home","Dome home", "Earth home", "Log home", "Metal home", "Modular home", "Straw home", "Traditional site-built home", "Other");
		fsa.assertEquals(getTextFromElement(tellUsMorePageTitle), "Tell us more about your home", "Tell us more page - Page title.");
		fsa.assertEquals(getTextFromElement(yearBuiltLabel), "When was your home built?", "Tell us more - Year built label");
		fsa.assertEquals(getValueFromWebElement(yearBuiltInputField), EMPTY_STRING, "Tell us more page - Year built field is blank.");
		fsa.assertEquals(getTextFromElement(purchaseDateLabel), "When did you purchase this home?", "Tell us more - Purchase date label");
		fsa.assertEquals(getTextFromElement(replacementCostLabel), "What is the replacement cost of your home?", "Tell us more - Replacement cost label");
		validateHelpInfoContent(fsa, replacementCostHelpIcon, "Dwelling replacement cost", REPLACEMENT_COST_HELP_CONTENT);
		fsa.assertEquals(getValueFromWebElement(replacementCostInputField), EMPTY_STRING, "Tell us more page - replacement cost field is blank.");
		fsa.assertEquals(getTextFromElement(typeOfHomeLabel), "What type of home is it?", "Tell us more - Type of home label");
		fsa.assertEquals(getTextFromElement(typeOfHomeDropdown), "Traditional site-built home", "Tell us more page - Default type of home selected.");
		clickElement(typeOfHomeDropdown);
		List<WebElement> listOfDropdownOptionElements = driver().findElements(By.xpath(DROPDOWN_OPTIONS_XPATH + "[contains(@class, 'label')]"));
		List<String> listOfDropdownOptions = listOfDropdownOptionElements.stream().map(this::getTextFromElement).collect(Collectors.toList());
		fsa.assertEquals(listOfDropdownOptions, listOfHomeTypes, "Tell us more page - Type of home  dropdown content");
		clickElement(typeOfHomeDropdown);
		fsa.assertEquals(getTextFromElement(townhouseRowhouseLabel), "Is this a townhouse or a rowhouse?", "Tell us more - Townhouse/rowhouse label");
		fsa.assertTrue(isButtonSelected(noTownhouseButton), "Not a townhouse/rowhouse button selected by default");
		fsa.assertTrue(!isButtonSelected(yesTownhouseButton), "Is a townhouse/rowhouse button not selected by default");
		if (!isForemostQuote && List.of(RENT, SHORTRENT_DWELLING).contains(specialtyDwellingApplicant.getReasonWhyNotPrimaryResidence())) {
			fsa.assertEquals(getTextFromElement(unitsLabel), "How many units for this rental property?", "Tell us more - Unit count label");
			WebElement oneUnitButton = driver().findElement(By.xpath(String.format(UNIT_BUTTON_XPATH_STRING, "1")));
			fsa.assertTrue(isButtonSelected(oneUnitButton), "One rental unit button selected by default");
		}
		fsa.assertEquals(getTextFromElement(claimsLabel), "How many property claims have you filed in the last 5 years?", "Tell us more - Claims count label");
		WebElement noClaimsButton = driver().findElement(By.xpath(String.format(CLAIMS_BUTTON_XPATH_STRING, "None")));
		fsa.assertTrue(isButtonSelected(noClaimsButton), "No claims button selected by default");
		fsa.assertEquals(getTextFromElement(cancellationLabel), "Have you ever had a cancellation, declination, or non-renewal of insurance for any property policy in the last 5 years?", "Tell us more page - Cancellations label");
		fsa.assertTrue(isButtonSelected(noCancellationButton), "No cancellations button selected by default");
		fsa.assertEquals(getTextFromElement(buttonContinue), isForemostQuote? "Continue" : "Agree", "Tell us more page - CTA button text label");
		validatePageLinksText(fsa, activeStep);
		validatePageLinksNavigationTitles(fsa);
		validateDisclaimers(fsa, specialtyDwellingApplicant.getStateCode(), !isForemostQuote);
		validateAgentSectionContent(fsa, false, testCategory);
	}

	//Disclaimer section
    @FindBy(xpath = "//app-dwelling-details//div[contains(@class,'disclaimer__credit-report')]//p[1]")
    private WebElement creditReportDisclaimer;
    @FindBy(xpath = "//app-dwelling-details//div[contains(@class,'disclaimer__credit-report')]//p[2]")
    private WebElement consumerReportDisclaimer;
    @FindBy(xpath = "//app-dwelling-details//div[contains(@class,'disclaimer__color') and not(@hidden)]")
    private WebElement privacyPolicyDisclaimer;
    @FindBy(xpath = "//app-dwelling-details//div[contains(@class,'disclaimer__color')]//a")
    private WebElement privacyPolicyLink;

    private void validateDisclaimers(FarmersSoftAssert fsa, String stateCode, boolean isDisclaimerSectionExpected) {
    	if (isDisclaimerSectionExpected) {
    		String expectedCreditReportDisclaimer = "In connection with this application for insurance, the insurer may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. "+
    				"The insurer may use a third party in connection with the development of your insurance score.";
    		String householdCreditScoringDisclaimerString = "The insurer will obtain and use credit information on you or any other member(s) of your household as part of the insurance credit scoring process (N/A Tenant, Landlord/Rental, Vacation/Short-term Rental). " +
    				"The insurer may use a third-party in connection with the development of your insurance score.";
    		String riskInformationCreditReportDisclaimer = "In connection with this application for insurance, we may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. " +
    				"We may use a third party in connection with the development of your insurance score. " +
    				"We use credit risk information because there is statistical evidence showing a correlation between individuals' credit risk information and their insurance risk, or the likelihood that they will become involved in an occurrence or loss. " +
    				"We consider credit risk information to measure insurance risk. The credit risk information we consider includes the total number of accounts, use of open accounts, months since most recent delinquency, numbers of collections, and other information. " +
    				"A lack of credit risk information for a person will be considered as neutral insurance risk information as provided by our filing with the Director of the Department of Consumer and Business Services. If you have any questions about our consideration of credit risk information you may contact Foremost at: 866-302-4934.";
    		String expectedConsumerReportDisclaimer = "Farmers entities may use any consumer report information their affiliates might currently have for you for your quote request." + SPACE +
    				"Our Privacy Notice gives you the choice to opt out of allowing Farmers affiliates to share your consumer report information among Farmers entities." + SPACE +
    				"You can still opt out of future sharing.";
    		String expectedPrivacyPolicyDisclaimer = "By clicking \"Agree\", you acknowledge that you've read and agree to the Privacy Policy and the above consumer report information provisions." + SPACE +
    				"Otherwise contact a Farmers\u00ae representative to discuss options.";
    		//Variations
    		String CREDIT_REPORT_ALTERNATE = "In connection with this application for insurance, we will review your credit report or obtain or use a credit score, insurance score or other credit information as part of the underwriting process, except when you are applying for a tenant policy. ";
    		String SHALL_REVIEW_CREDIT_REPORT = "In connection with this application for insurance, the insurer shall review your credit report or obtain or use an insurance credit score based on the information contained in that credit report. ";
    		String THE_INSURER_MAY_USE_A_THIRD_PARTY = "The insurer may use a third"+ (stateCode.equals(TX)? "-" : SPACE) + "party in connection with the development of your insurance"+ (stateCode.equals(VA)? " credit " : SPACE) + "score" + (stateCode.equals(NV)? EMPTY_STRING : PERIOD);
    		String WE_MAY_USE_A_THIRD_PARTY = "We may use a third party in connection with the development of your insurance score. ";
    		String PLEASE_CONTACT_UNDERWRITING_FOR_DETAILS = "Please contact Underwriting at 1-866-302-4934 for details on qualifying circumstances and how to request an exception. ";
    		String PLEASE_HAVE_REPRESENTATIVE_CONTACT_UNDERWRITING_FOR_DETAILS = "Please have your insurance representative contact Underwriting for details on qualifying circumstances and how to request an exception. ";
    		String REQUEST_RECEIVED_WITHIN_60_DAYS = "Your request must be received within 60 days " + (stateCode.equals(IA)? "of":"from") + " the date of your application or renewal. ";
    		String EXTRAORDINARY_LIFE_CIRCUMSTANCE = "If you believe an extraordinary life circumstance has negatively impacted your credit information, you may request, in writing, that " + (List.of(DE, OK, NH, VT).contains(stateCode)? "the insurer":"we") + " provide reasonable exceptions to "+ (List.of(DE, OK, NH, VT).contains(stateCode)? "its":"our") + " underwriting and/or rating practices. ";
    		String DISPUTE_ADVERSE_ACTION = "In the event you dispute any adverse action the insurer takes based on credit information, you may request an appeal of the decision. Notify us in writing at Foremost Insurance Group, Attn: Manufactured Home Underwriting, P.O. Box 2047, Grand Rapids, MI 49501.";
    		String YOU_MAY_QUALIFY_FOR_AN_EXCEPTION = "You may qualify for an extraordinary life circumstance exception in the underwriting of your application or rating of your policy. ";
    		String EXTRAORDINARY_EVENTS = "An extraordinary life event may include, but is not limited to" + (stateCode.equals(NJ)? COLON : COMMA) + " catastrophic illness or injury; death of a spouse, child or parent; temporary loss of employment; divorce" + (stateCode.equals(NJ)? SEMI_COLON : COMMA) + " identity theft; or military deployment overseas.";

    		switch (stateCode) {
    			case IA: case MI:
    				expectedConsumerReportDisclaimer = EXTRAORDINARY_LIFE_CIRCUMSTANCE + REQUEST_RECEIVED_WITHIN_60_DAYS + PLEASE_CONTACT_UNDERWRITING_FOR_DETAILS + expectedConsumerReportDisclaimer;
    				break;
				case KS:
					expectedCreditReportDisclaimer = expectedCreditReportDisclaimer + SPACE + DISPUTE_ADVERSE_ACTION;
    				expectedConsumerReportDisclaimer = EXTRAORDINARY_LIFE_CIRCUMSTANCE + REQUEST_RECEIVED_WITHIN_60_DAYS + PLEASE_HAVE_REPRESENTATIVE_CONTACT_UNDERWRITING_FOR_DETAILS + expectedConsumerReportDisclaimer;
					break;
				case MD:
					expectedCreditReportDisclaimer = "Maryland law provides the company with a 45 day underwriting period beginning on the effective date of your coverage. " +
							"We may cancel your policy during this 45 day underwriting period if the policy does not meet our underwriting standards. " +
							"In addition, we may recalculate the premium from the effective date of the policy during the underwriting period.";
					break;
				case MN:
					expectedCreditReportDisclaimer = CREDIT_REPORT_ALTERNATE + WE_MAY_USE_A_THIRD_PARTY + YOU_MAY_QUALIFY_FOR_AN_EXCEPTION + EXTRAORDINARY_EVENTS;
					break;
				case ND:
					expectedConsumerReportDisclaimer = "The insurer may consider your claims history, or that of any member of your household, in determining whether to decline to write, cancel, nonrenew, or surcharge a policy and we may report any claims made to an insurance support organization. " + expectedConsumerReportDisclaimer;
					break;
				case NM:
					expectedCreditReportDisclaimer = "In connection with your application for insurance coverage, the insurer may review and use information contained in your credit report to help determine your premium or your eligibility for coverage. " +
							"The insurer may use a third party in connection with the development of your insurance score.";
					break;
    			case OK:
    				expectedConsumerReportDisclaimer = EXTRAORDINARY_LIFE_CIRCUMSTANCE + REQUEST_RECEIVED_WITHIN_60_DAYS + PLEASE_HAVE_REPRESENTATIVE_CONTACT_UNDERWRITING_FOR_DETAILS + expectedConsumerReportDisclaimer;
    				break;
				case OR:
					expectedCreditReportDisclaimer = riskInformationCreditReportDisclaimer;
					break;
				case TX:
					expectedCreditReportDisclaimer = householdCreditScoringDisclaimerString;
					break;
				case VA:
					expectedCreditReportDisclaimer = SHALL_REVIEW_CREDIT_REPORT + THE_INSURER_MAY_USE_A_THIRD_PARTY +
					" You may request that your credit information be updated and if you question the accuracy of the credit information, the insurer will, upon your request, reevaluate you based on corrected credit information from a consumer reporting agency";
					break;
				default:
					break;
			}
    		fsa.assertEquals(getTextFromElement(creditReportDisclaimer), expectedCreditReportDisclaimer, "Tell us more - Credit report disclaimer");
    		fsa.assertEquals(getTextFromElement(consumerReportDisclaimer), expectedConsumerReportDisclaimer, "Tell us more - Consumer report disclaimer");
    		fsa.assertEquals(getTextFromElement(privacyPolicyDisclaimer), expectedPrivacyPolicyDisclaimer, "Tell us more - Privacy Policy disclaimer ");
    		fsa.assertEquals(getTextFromElement(privacyPolicyLink), "Privacy Policy", "Tell us more - Privacy Policy link label");
    		fsa.assertEquals(getAttributeData(privacyPolicyLink, HREF), "https://www.farmers.com/privacy-center/", "Tell us more - Privacy Policy link contains expected url.");
    	} else {
    		scrollToBottomOfPage();
    		fsa.assertEquals(!isElementDisplayed(creditReportDisclaimer, 1), true, "creditReportDisclaimer is not displayed");
    		fsa.assertEquals(!isElementDisplayed(consumerReportDisclaimer, 1), true, "consumerReportDisclaimer is not displayed");
    		fsa.assertEquals(!isElementDisplayed(privacyPolicyDisclaimer, 1), true, "privacyPolicyDisclaimer is not displayed");
    		fsa.assertEquals(!isElementDisplayed(privacyPolicyLink,1), true, "privacyPolicyLink is not displayed");
    	}
    }

	@FindBy (xpath =  "//div[@class='heading-area']//h1")
	private WebElement helpDialogTitle;
	@FindBy (className = "main-content")
	private WebElement helpDialogContent;

	private void validateHelpInfoContent(FarmersSoftAssert fsa, WebElement helpIcon, String helpTitle, String helpContent) {
		scrollAndClickOnElement(helpIcon);
		waitElementBeVisible(helpDialogTitle, 3);
		fsa.assertEquals(getTextFromElement(helpDialogTitle), helpTitle, helpTitle + " - Help title verification");
		fsa.assertEquals(getTextFromElement(helpDialogContent), helpContent, helpTitle + " - Help content verification");
		waitAndClickElement(closeIconMB);
	}

	public void validatePageErrors(FarmersSoftAssert fsa, ApplicantAceHome specialtyDwellingApplicant) throws Exception {
		clickElement(yearBuiltInputField);
		clickElement(replacementCostInputField);
		scrollAndClickOnElement(buttonContinue);
		List<String> defaultListOfExpectedErrors = List.of("Please enter the year your house was built.", "Please enter the length of your home.", "Please enter the width of your home.", "Replacement cost is required.");
		waitForElements(ERROR_MESSAGE_XPATH);
		List<String> listOfErrorsFoundInPage = getPageErrors();
		fsa.assertEquals(listOfErrorsFoundInPage, defaultListOfExpectedErrors, "Default errors when missing data");
		enterValueInField("1500", yearBuiltInputField, "Enter Year built:");
		scrollAndClickOnElement(buttonContinue);
		String currentYearPlusOne = String.valueOf(getTodayDate().plusYears(1).getYear());
		fsa.assertTrue(getPageErrors().contains("Mobile home model year must be between 1901-" + currentYearPlusOne + PERIOD), "Year built too old error found.");
		clearErrorsInPage();
		fsa.assertTrue(getPageErrors().isEmpty(), "Page error(s) should not be found after refresh.");
		fsa.assertTrue(getPageAlerts().isEmpty(), "Page alert(s) should not be found after refresh.");
		enterValueInField("2500", yearBuiltInputField, "Enter Year built:");
		scrollAndClickOnElement(buttonContinue);
		fsa.assertTrue(getPageErrors().contains("Mobile home model year must be between 1901-" + currentYearPlusOne + PERIOD), "Home built in the future error found.");
		clearErrorsInPage();
		scrollAndClickOnElement(buttonContinue);
		waitForElements(ERROR_MESSAGE_XPATH);
		enterValueInField("1000", replacementCostInputField, "Entering not expensive enough of a home:");
		scrollAndClickOnElement(buttonContinue);
		fsa.assertTrue(getPageErrors().contains("Please call to discuss coverage options for homes less than $25,000 or greater than $300,000."), "Home not expensive enough to cover error found.");
		clearErrorsInPage();
		enterValueInField("400000", replacementCostInputField, "Entering too expensive a home:");
		scrollAndClickOnElement(buttonContinue);
		fsa.assertTrue(getPageErrors().contains("Please call to discuss coverage options for homes less than $25,000 or greater than $300,000."), "Home too expensive to replace error found.");
		clearErrorsInPage();
	}

	protected void clearErrorsInPage() throws Exception {
		driver().navigate().refresh();
		wait.until(invisibilityOfElementLocated(By.xpath("//mat-error")));
	}

	public void validateSnackbarMessages(FarmersSoftAssert fsa) {
		enterValueInField("1500", yearBuiltInputField, "Enter Year built:");
		enterValueInField(String.valueOf(LocalDate.now().minusYears(10).getYear()), yearBuiltInputField, "Home built less than 15 years ago");
		sleep(3);
		fsa.assertTrue(isSnackBarMessageDisplayed("We added a newer home discount"), "Tell us more page - Newer home discount added snackbar message found.");
		enterValueInField(String.valueOf(LocalDate.now().minusYears(20).getYear()), yearBuiltInputField, "Home built more than 15 years ago");
		sleep(3);
		fsa.assertTrue(isSnackBarMessageDisplayed("Newer home discount removed"), "Tell us more page - Newer home discount removed snackbar message found.");
	}
}
