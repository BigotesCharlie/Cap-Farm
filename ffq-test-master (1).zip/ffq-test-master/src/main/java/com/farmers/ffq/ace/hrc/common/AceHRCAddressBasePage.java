package com.farmers.ffq.ace.hrc.common;

import com.farmers.ffq.common.pages.FGIALandingPage;
import com.farmers.ffq.common.pages.ForemostLandingPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.invisibilityOfElementLocated;

public class AceHRCAddressBasePage extends AceHRCBasePage {

	@FindBy(xpath = "//app-personal-info//div[contains(@class,'personal-info_address_h1')]//h1")
    protected WebElement addressPageTitle;

    @FindBy(xpath = "//app-property-type//*[@id='propertyTypeLabelSrOnly']")
    protected WebElement propertyTypeTitleMediaAlpha;

    @FindBy(xpath = "//app-personal-info//div[@id='auto-personal-info_address-subheading']")
    protected WebElement addressSubheading;

    @FindBy(xpath = "//app-personal-info//div[contains(@class,'new-home')]/label")
    private WebElement newHomeSubheading;

    @FindBy(xpath = "//app-personal-info//div[contains(@class,'escrow')]/label")
    private WebElement inEscrowSubheading;

    @FindBy(xpath = "//app-personal-info//div[contains(@class,'primary-residence')]/h2")
    private WebElement primaryResidenceSubheading;

    @FindBy(xpath = "//app-personal-info//div[contains(@class,'HOATextValue-title')]/label")
    private WebElement hoaCoverageSubheading;

    @FindBy(xpath = "//app-personal-info//div[contains(@class,'hoa-cover_element')]/label")
    private WebElement hoaCoverageDetailsSubheading;

    @FindBy(xpath = "//app-personal-info//div[contains(@class,'property-losses')]/label")
    protected WebElement propertyLossesSubheading;

    private static final String ADDRESS_INPUT_FIELD_XPATH = "//app-personal-info//input[@id='auto-manual-street__input-section']";
    @FindBy(xpath = ADDRESS_INPUT_FIELD_XPATH)
    protected WebElement formFieldAddressInput;

    @FindBy(xpath = "//app-personal-info//mat-form-field[@id='auto-manual-address-street__input-field']//mat-icon[contains(text(),'close')]")
    private WebElement addressFieldCrossIcon;

    private static final String ADDRESS_INPUT_FIELD_MANUAL_XPATH = "//app-personal-info//input[@id='auto-manual-street__input-section']";
    @FindBy(xpath = ADDRESS_INPUT_FIELD_MANUAL_XPATH)
    protected WebElement formFieldAddressManualInput;

    @FindBy(xpath = "//app-personal-info//div[@id='formField_apartment']//input")
    protected WebElement formFieldUnitInput;

    @FindBy(xpath = "//app-personal-info//div[@id='formField_city']//input")
    protected WebElement formFieldCityInput;

    @FindBy(xpath = "//app-personal-info//div[@id='formField_zipCode']//input")
    protected WebElement formFieldZipCodeInput;

    @FindBy(xpath = "//app-edit-address//mat-icon[@role='button']")
    private WebElement closeModalPopupButton;

    @FindBy(xpath = "//div[@role='alert' and contains(@class,'home-buyer__congratulations-message')]")
    private WebElement homeBuyerDiscountMessage;

    private static final String NEW_HOME_BUTTON_XPATH = "//app-personal-info//div[@id='formField_isNewHome']";

    private static final String IN_ESCROW_XPATH = "//app-personal-info//div[@id='formField_isEscrow']";

    protected static final String PRIMARY_RESIDENCE_XPATH = "//div[@id='formField_isPrimaryResidence']";

    protected static final String NOT_PRIMARY_RESIDENCE_REASON_XPATH = "//div[@id='formField_notPrimaryResidenceReason']";

    private static final String HOA_COVERAGE_HELP_SECTION_XPATH = "//app-personal-info//div[contains(@class,'personal-help')]";
    @FindBy(xpath = HOA_COVERAGE_HELP_SECTION_XPATH + "/h3")
    private WebElement hoaCoverageHelpTitle;
    @FindBy(xpath = HOA_COVERAGE_HELP_SECTION_XPATH + "/p")
    private WebElement hoaCoverageHelpText;

    protected static final String NUMBER_OF_PROPERTY_LOSSES_XPATH = "//app-personal-info//div[@id='formField_noOfPropertyLosses']";

    @FindBy(xpath = "(//app-edit-address//input[@id='auto-edit-street__input-section'])[2]")
    private WebElement formFieldEditAddressInput;

    @FindBy(xpath = "//app-edit-address//input[@id='auto-edit-apartment__input-section']")
    private WebElement formFieldEditApartmentInput;

    @FindBy(xpath = "//app-edit-address//input[@aria-label='city']")
    private WebElement formFieldEditCityInput;

    @FindBy(xpath = "//app-edit-address//mat-select[@aria-label='State']")
    private WebElement formFieldEditStateSelect;

    @FindBy(xpath = "//app-edit-address//input[@aria-label='zipCode']")
    private WebElement formFieldEditZipCodeInput;

    @FindBy(xpath = "//app-edit-address//button[contains(text(),'Save')]")
    private WebElement saveButton;

    @FindBy(xpath = "//app-edit-address//mat-error")
    private WebElement formEditAddressErrors;

    private static final String CHANGE_ZIP_TITLE_XPATH = "//app-change-zip//h4";
    @FindBy(xpath = CHANGE_ZIP_TITLE_XPATH)
    private WebElement changeZipHeader;

    @FindBy(xpath = "//app-change-zip//button[contains(text(),'Yes')]")
    private WebElement buttonZipChangeYes;

    @FindBy(xpath = "//app-change-zip//a[contains(text(),'Go back')]")
    private WebElement buttonZipChangeGoBack;

    @FindBy(xpath = "//app-edit-address//input[@aria-label='Street number and name']")
    private WebElement editAddressStreet;

    @FindBy(xpath = "//app-edit-address//mat-select[@aria-label='State']")
    private WebElement editAddressStateCode;

    @FindBy(xpath = "//app-edit-address//input[@aria-label='zipCode']")
    private WebElement editAddressZipCode;

    @FindBy(linkText = "Go back")
    private WebElement goBackButton;

    private static final String EMAIL_ADDRESS_XPATH = "//app-personal-info//input[@name='emailAddress']";
    @FindBy(xpath = EMAIL_ADDRESS_XPATH)
    private WebElement formFieldEmailAddressInput;

    @FindBy(xpath = "//app-personal-info//input[@name='phoneNumber']")
    private WebElement formFieldPhoneNumberInput;

    @FindBy(xpath = "//app-personal-info//button[text()='Agree and submit']")
    private WebElement agreeAndSubmitButton;

    @FindBy(linkText = "enter your address manually")
    protected WebElement linkEnterYourAddressManually;

    @FindBy(linkText = "Check your eligibility")
    protected WebElement linkCheckYourEligibility;

    @FindBy(xpath = "//app-farmers-groupselect-sidesheet//input")
    protected WebElement inputEmployerGroup;

    private static final String EMPLOYER_GROUP_LIST_XPATH = "//div[contains(@class,'mat-autocomplete')]/mat-option";
    @FindBy(xpath = EMPLOYER_GROUP_LIST_XPATH)
    private WebElement employerOption;

    @FindBy(xpath = "//app-farmers-groupselect-sidesheet//button")
    protected WebElement continueWithGroupDiscountButton;

    @FindBy(xpath = "//div[@class='selected_employer_name']")
    protected WebElement groupEmployerName;

    private static final String NEW_HOME_TEXT = "Is this a home you're buying, or have owned for less than a year? Yes No";
    protected static final String PRIMARY_RESIDENCE_TEXT = "Is this your primary residence? Yes No";
    private static final String IN_ESCROW_TEXT = "Are you currently in escrow? Yes No";
    private static final String PROPERTY_LOSSES_SUBHEADING_TEXT = "How many property claims have you submitted to your insurance carrier in the last 3 years?";
    private static final String PROPERTY_LOSSES_SUBHEADING_TEXT_CA = "How many property claims have you filed in the last 3 years?";
    protected static final String RENT = "RENT";
    protected static final String PART_TIME = "PARTTIME";
    protected static final String SHORTRENT = "SHORTRENT";

    protected static final String OTHER = "OTHER";
    protected static final String SECONDARY = "SECONDARY";
    protected static final String SEASONAL = "SEASONAL";

    /**
     * Default Constructor
     */
    public AceHRCAddressBasePage() throws Exception {
    }

    public boolean isOnAddressPage(boolean longWait) throws Exception {
        int timeout = longWait ? Property.PAGELOADTIMEOUT : 5;
        return isElementDisplayed(formFieldAddressManualInput, timeout);
    }

    public boolean isOnBundlePropertyQuestionsPage() {
        return isElementVisible(propertyLossesSubheading, 5);
    }

    public boolean isNewHomeSelected() throws Exception {
    	return isButtonSelected(driver().findElement(By.xpath(NEW_HOME_BUTTON_XPATH + "//button[.='Yes']")));
    }

    public boolean isNotNewHomeSelected() throws Exception {
    	return isButtonSelected(driver().findElement(By.xpath(NEW_HOME_BUTTON_XPATH + "//button[.='No']")));
    }

    public void selectNewHome(boolean newHome) throws Exception {
        String buttonXpath = newHome ? "//button[.='Yes']" : "//button[.='No']";
        WebElement we = driver().findElement(By.xpath(NEW_HOME_BUTTON_XPATH + buttonXpath));
        waitAndClickElement(we);
    }

    public boolean isAWSFlow(String agentId) {
        return !agentId.isEmpty();
    }

    public boolean isInEscrowSelected() throws Exception {
    	return isButtonSelected(driver().findElement(By.xpath(IN_ESCROW_XPATH + "//button[.=' Yes ']")));
    }

    public boolean isNotInEscrowSelected() throws Exception {
    	return isButtonSelected(driver().findElement(By.xpath(IN_ESCROW_XPATH + "//button[.=' No ']")));
    }

    public void selectInEscrow(boolean inEscrow) throws Exception {
        String buttonXpath = inEscrow ? "//button[.=' Yes ']" : "//button[.=' No ']";
        WebElement we = driver().findElement(By.xpath(IN_ESCROW_XPATH + buttonXpath));
        waitAndClickElement(we);
    }

    public boolean isPrimaryResidenceSelected() throws Exception {
        return isButtonSelected(driver().findElement(By.xpath(PRIMARY_RESIDENCE_XPATH + "//button[.='Yes']")));
    }

    public boolean isNotPrimaryResidenceSelected() throws Exception {
        return isButtonSelected(driver().findElement(By.xpath(PRIMARY_RESIDENCE_XPATH + "/button[.='No']")));
    }

    public void selectPrimaryResidence(boolean primaryResidence) throws Exception {
        String buttonXpath = primaryResidence ? "//button[.='Yes']" : "//button[.='No']";
        WebElement we = driver().findElement(By.xpath(PRIMARY_RESIDENCE_XPATH + buttonXpath));
        waitAndClickElement(we);
    }

    public List<String> getListOfNotPrimaryResidenceReasons() throws Exception {
        return driver().findElements(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH + "//mat-radio-button"))
                .stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public List<String> getListOfNotPrimaryResidenceReasonsValues() throws Exception {
    	 List<WebElement> listOfNonPrimaryResidenceReasons =  driver().findElements(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH + "//mat-radio-button//input"));
    	 List<String> listOfValues = new ArrayList<>();
         for (WebElement reason : listOfNonPrimaryResidenceReasons) {
        	 String value = getAttributeData(reason, VALUE);
        	 if (!value.isBlank()) {
        		 listOfValues.add(value);
        	 }
         }
         return listOfValues;
    }

    public String getNotPrimaryResidenceReason() throws Exception {
        List<WebElement> weList = driver().findElements(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH + "//mat-radio-button"));
        String nonPrimaryReason = "";
        for (WebElement we : weList) {
            if (getAttributeData(we, CLASS).contains(RADIO_BUTTON_CHECKED)) {
                nonPrimaryReason = getValueFromWebElement(we.findElement(By.xpath(".//input")));
                break;
            }
        }
        Log.info("Address page - Not Primary Residence Reason: " + nonPrimaryReason);
        return nonPrimaryReason;
    }

    public void selectNotPrimaryResidenceReason(String reason) throws Exception {
        selectPrimaryResidence(false);
        if (!getNotPrimaryResidenceReason().equals(reason)) {
            WebElement we = driver().findElement(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH + String.format("//mat-radio-button//input[starts-with(@value,'%s')]", reason)));
            scrollAndClickOnElement(we);
        }
    }

    public String getNumberOfPropertyLossesSelected() throws Exception {
        List<WebElement> weList = driver().findElements(By.xpath(NUMBER_OF_PROPERTY_LOSSES_XPATH + "//button"));
        String numberOfPropertyLosses = "";
        for (WebElement we : weList) {
            if (isButtonSelected(we)) {
                numberOfPropertyLosses = getTextFromElement(we);
                break;
            }
        }
        Log.info("Address page - Number Of Property Losses: " + numberOfPropertyLosses);
        return numberOfPropertyLosses;
    }

    public void selectNumberOfPropertyLosses(String numberOfLosses) throws Exception {
        if (!numberOfLosses.isBlank() && !getNumberOfPropertyLossesSelected().equals(numberOfLosses)) {
            WebElement we = driver().findElement(By.xpath(NUMBER_OF_PROPERTY_LOSSES_XPATH + String.format("//button[.='%s']", numberOfLosses)));
            waitAndClickElement(we);
        }
    }

    public String getAddress() {
        return getElementValue(formFieldAddressManualInput, "Home Address").trim();
    }

    public String getAddressManualInput() {
        return getElementValue(formFieldAddressManualInput, "Home Address").trim();
    }

    public void enterAddress(ApplicantAceHome applicant) throws Exception {
        scrollToTopOfPage();
        enterGoogleAddressAceHome(formFieldAddressInput, formFieldCityInput, applicant);
        if (getValueFromWebElement(waitElementBeVisible(formFieldCityInput, 3)).isBlank()) {
            sendKeysToElement(formFieldCityInput, applicant.getCity());
        }
        if (!applicant.getUnit().isBlank()) {
            sendKeysToElement(formFieldUnitInput, applicant.getUnit());
        }
    }

    public void validateAddressPageCrossIcon(FarmersSoftAssert fsa) {
        waitAndClickElement(addressFieldCrossIcon);
        fsa.assertEquals(getAddress(), EMPTY_STRING, "Address input field is cleared.");
    }

    public void validateAddressPageFieldsNotSaved(FarmersSoftAssert fsa, String lobType) throws Exception {
        fsa.assertEquals(getAddress(), EMPTY_STRING, "Address Street input field is cleared.");
        fsa.assertEquals(getCity(), EMPTY_STRING, "Address City input field is cleared.");
        if(lobType.equals(HOME) || lobType.equals(CONDO)) {
            fsa.assertTrue(isNotNewHomeSelected(), "Address page - Not New Home button is selected.");
            fsa.assertTrue(isPrimaryResidenceSelected(), "Address page - Primary Residence button is selected.");
            fsa.assertEquals(getNumberOfPropertyLossesSelected(), NONE, "Address page - Property Losses 'None' is selected.");
        }
    }

    public void validateAddressPageFieldsSaved(ApplicantAceHome applicant, String lobType, FarmersSoftAssert sa) throws Exception {
        AppStore.Data.CustomerData.Address appStoreAddress = getSessionStorageAppStore().getData().getCustomerData().getAddress();
        sa.assertTrue(appStoreAddress.getStreet().toUpperCase().contains(applicant.getAddress().toUpperCase()), "Address Street from the appStore: " + appStoreAddress.getStreet()
                        + " matches to the applicant Address field: " + applicant.getAddress());
        sa.assertEquals(appStoreAddress.getCity().toUpperCase(), applicant.getCity().toUpperCase(), "Address City input field match to appStore.");
        if(!lobType.equals(RENTERS)) {
            sa.assertEquals(isNewHomeSelected(), applicant.isNewlyOwned(), "Newly owned option detail is not retained");
            sa.assertEquals(isInEscrowSelected(), applicant.isInEscrow(), "Escrow option selection details are not retained ");
            sa.assertTrue(isPrimaryResidenceSelected(), "Address page - Primary Residence is not retained.");
            sa.assertEquals(getNumberOfPropertyLossesSelected(), NONE, "Address page - Property Losses 'None' is not selected.");
        }
    }

    public String getCity() {
        return getElementValue(formFieldCityInput, "City").trim();
    }

    public String getZipCode() {
        return getElementValue(formFieldZipCodeInput, "ZIP Code").trim();
    }

    public void enterZipCode(String zipCode) {
        waitAndClickElement(formFieldZipCodeInput);
        sendKeysToElement(formFieldZipCodeInput, zipCode);
        sendKeysToElement(formFieldZipCodeInput, Keys.TAB);
    }


    public String getState() {
        String PREFIX = "Please enter your ";
        String SUFFIX = " address.";
        return getTextFromElement(addressSubheading).replace(PREFIX,EMPTY_STRING).replace(SUFFIX,EMPTY_STRING);
    }

    public void validatePageFormFields(FarmersSoftAssert fsa, ApplicantAceHome applicant, String propertyType) throws Exception {
        final String HOME_BUYER_DISCOUNT_ADDED_TEXT = "Congratulations! We added a home buyer discount.";
        final String HOME_BUYER_DISCOUNT_REMOVED_TEXT = "Home buyer discount has been removed.";
        final List<String> NOT_PRIMARY_RESIDENCE_REASONS = List.of("I rent it out", "I use it part time", "Other");
        final List<String> NOT_PRIMARY_RESIDENCE_REASONS_SUBTEXT = List.of("My home is or will be occupied by a renter (short or long term)",
                "This home is for seasonal or secondary use.", "Such as my home is vacant, or will be under renovation within 30 days.");
        final List<String> NOT_PRIMARY_RESIDENCE_REASONS_WITH_FOUR_OPTIONS = List.of("I rent it out", "I use it as a secondary home throughout the year",
                "I only use it seasonally", "Vacant", "Other");
        final List<String> NOT_PRIMARY_RESIDENCE_REASONS_SUBTEXT_WITH_FOUR_OPTIONS = List.of("This home is or will be occupied by a renter (short or long term).",
                "This home is not rented out.", "This home is not rented out.", "This home is vacant, or will be under renovation within 30 days.");
        fsa.assertEquals(getAttributeData(formFieldAddressManualInput, ARIA_LABEL), "Home Address (No Post Office Boxes)", "Address page - Address field text.");
        fsa.assertEquals(getTextFromElement(formFieldAddressManualInput), EMPTY_STRING, "Address page - Address field is blank.");
        fsa.assertEquals(getAttributeData(formFieldUnitInput, ARIA_LABEL), "Apartment ID", "Address page - Unit # field text.");
        fsa.assertEquals(getTextFromElement(formFieldUnitInput), EMPTY_STRING, "Address page - Unit # field is blank.");

        if (!propertyType.equals(CONDO)) {
            String newHomeExpectedText = isSafariBrowser()? "Is this a home you're buying, or have owned for less than a year?YesNo": NEW_HOME_TEXT;
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(NEW_HOME_BUTTON_XPATH))), newHomeExpectedText,
                    "Address page - New Home text.");
            fsa.assertTrue(isNotNewHomeSelected(), "Address page - Not New Home button is selected.");
            selectNewHome(true);
            if (isHomeFlexState(applicant.getStateCode())) {
                sleep(2);
                fsa.assertTrue(isSnackBarMessageDisplayed(HOME_BUYER_DISCOUNT_ADDED_TEXT), "Address page - Home buyer discount added, message found.");
                waitSnackBarMessageInvisible(10);
            }
            fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(IN_ESCROW_XPATH))), IN_ESCROW_TEXT,
                    "Address page - Currently In Escrow text.");
            fsa.assertTrue(isNotInEscrowSelected(), "Address page - Currently in Not Escrow button is selected.");
            selectNewHome(false);
            if (isHomeFlexState(applicant.getStateCode())) {
                fsa.assertTrue(isSnackBarMessageDisplayed(HOME_BUYER_DISCOUNT_REMOVED_TEXT), "Address page - Home buyer discount removed, message found.");
            }
        }
        fsa.assertFalse(isElementDisplayed(By.xpath(IN_ESCROW_XPATH)), "Address page - When Not New Home, In Escrow should not display.");
        String primaryResidenceExpectedText = isSafariBrowser()? "Is this your primary residence?YesNo": PRIMARY_RESIDENCE_TEXT;
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(PRIMARY_RESIDENCE_XPATH))), primaryResidenceExpectedText,
                "Address page - Primary Residence text.");
        fsa.assertTrue(isPrimaryResidenceSelected(), "Address page - Primary Residence button is selected.");
        selectPrimaryResidence(false);
        List<String> subtextNotPrimaryReasons = driver().findElements(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH +
                        "//span[contains(@class,'primary-residence-usage__subtext')]")).stream().map(this::getTextFromElement)
                        .filter(s -> !s.isBlank()).collect(Collectors.toList());
        if (isPrimaryResidenceHasFourOptions(applicant.getStateCode())) {
            fsa.assertEquals(getListOfNotPrimaryResidenceReasons(), NOT_PRIMARY_RESIDENCE_REASONS_WITH_FOUR_OPTIONS, "Address page - List of radio buttons for Non-primary reasons (seasonal).");
            fsa.assertEquals(subtextNotPrimaryReasons, NOT_PRIMARY_RESIDENCE_REASONS_SUBTEXT_WITH_FOUR_OPTIONS, "Address page - Not Primary Residence Reasons subtext (seasonal).");
        } else {
            fsa.assertEquals(getListOfNotPrimaryResidenceReasons(), NOT_PRIMARY_RESIDENCE_REASONS, "Address page - List of radio buttons for Non-primary reasons.");
            fsa.assertEquals(subtextNotPrimaryReasons, NOT_PRIMARY_RESIDENCE_REASONS_SUBTEXT, "Address page - Not Primary Residence Reasons subtext.");
        }
        fsa.assertEquals(getNotPrimaryResidenceReason(), "RENT", "Address page - Not Primary Residence Reasons match.");
        selectPrimaryResidence(true);
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH)));
        fsa.assertFalse(isElementDisplayed(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH)), "Address page - When Primary Residence, Nor Primary Reasons should not display.");
        validatePropertyClaimsSectionTitle(fsa, applicant.getStateCode(), propertyType);
        validatePropertyClaimsToggleLabels(fsa);
        fsa.assertEquals(getNumberOfPropertyLossesSelected(), NONE, "Address page - Property Losses 'None' is selected.");
    }

    protected void validatePropertyClaimsSectionTitle(FarmersSoftAssert fsa, String stateCode, String propertyType) throws Exception {
        WebElement propertyClaimsSectionTitle = driver().findElement(By.xpath("//div[@id='formField_noOfPropertyLosses']/label"));
        String propertyLosesQuestion;
        if (stateCode.equals(CA)) {
            if (propertyType.equals(CONDO)) {
                propertyLosesQuestion = PROPERTY_LOSSES_SUBHEADING_TEXT.replace("3 years?", "5 years?");
            } else {
                propertyLosesQuestion = PROPERTY_LOSSES_SUBHEADING_TEXT_CA;
            }
        } else {
            propertyLosesQuestion = PROPERTY_LOSSES_SUBHEADING_TEXT;
        }
        fsa.assertEquals(getTextFromElement(propertyClaimsSectionTitle), propertyLosesQuestion, "Address page - Property claims question text");
    }

    protected void validatePropertyClaimsToggleLabels(FarmersSoftAssert sa) throws Exception {
        List<WebElement> propertyToggleLabelTexts = driver().findElements(By.xpath("//app-personal-info//div[@id='formField_noOfPropertyLosses']//span[contains(@class,'mat-button-toggle-label-content')]"));
        List<String> actualListOfLabels = propertyToggleLabelTexts.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> expectedListOfLabels = Arrays.asList("None", "One", "Two or more");
        sa.assertEquals(actualListOfLabels, expectedListOfLabels, "Propery Loss Toggles Label validation");
    }

    public boolean isNoSpouseCreditInCondoRentersDisclaimersState (String stateCode) {
        return List.of(AL, AZ, AR, IL, MO, ND, PA, SD, TN, WI, WY).contains(stateCode);
    }

    public void validatePageTitlesFooters(FarmersSoftAssert fsa, ApplicantAceHome applicant, String propertyType) throws Exception {
        final String PAGE_TITLE_TEXT = "What's the address?";
        final String PAGE_TITLE_TEXT_RENTERS = "We invite you to get a quote";
        final String PAGE_TITLE_TEXT_MEDIA_ALPHA = "You're almost there";
        final String PAGE_SUBTITLE_TEXT = "Please enter your %s address.";
        final String NEW_HOME_SUBHEADING_TEXT = "Is this a home you're buying, or have owned for less than a year?";
        final String IN_ESCROW_SUBHEADING_TEXT = "Are you currently in escrow?";
        final String PRIMARY_RESIDENCE_SUBHEADING_TEXT = "Is this your primary residence?";

        fsa.assertTrue(isElementInViewport(addressPageTitle), "Address page - Page title is in Viewport");

        //titles and subtitles
        if (propertyType.equals(RENTERS)) {
            fsa.assertEquals(getTextFromElement(addressPageTitle), PAGE_TITLE_TEXT_RENTERS, "Address page - Page title (h1) - Renters.");
        } else {
            String pageTitleText = propertyType.equals(MEDIA_ALPHA) ? PAGE_TITLE_TEXT_MEDIA_ALPHA : PAGE_TITLE_TEXT;
            fsa.assertEquals(getTextFromElement(addressPageTitle), pageTitleText, "Address page - Page title (h1).");
            fsa.assertEquals(getTextFromElement(newHomeSubheading), NEW_HOME_SUBHEADING_TEXT, "Address page - New Home subheading text.");
            selectNewHome(true);
            fsa.assertEquals(getTextFromElement(inEscrowSubheading), IN_ESCROW_SUBHEADING_TEXT, "Address page - Are you currently in escrow subheading text.");
            selectNewHome(false);
            fsa.assertEquals(getTextFromElement(primaryResidenceSubheading), PRIMARY_RESIDENCE_SUBHEADING_TEXT, "Address page - Primary residence subheading text.");
            String propertyClaimsQuestion;
            if (applicant.getStateCode().equals(CA) || propertyType.equals(MEDIA_ALPHA)) {
                if (propertyType.equals(CONDO)) {
                    propertyClaimsQuestion = PROPERTY_LOSSES_SUBHEADING_TEXT.replace("3 years?", "5 years?");
                } else {
                    propertyClaimsQuestion = PROPERTY_LOSSES_SUBHEADING_TEXT_CA;
                }
            } else {
                propertyClaimsQuestion = PROPERTY_LOSSES_SUBHEADING_TEXT;
            }
            fsa.assertEquals(getTextFromElement(propertyLossesSubheading), propertyClaimsQuestion, "Address page - Property Claims question subheading text.");
        }
        fsa.assertEquals(getTextFromElement(addressSubheading), String.format(PAGE_SUBTITLE_TEXT, applicant.getState()),
                "Address page - Address subheading text.");
        verifyFooterContent(fsa, applicant, propertyType);
    }

    protected void verifyFooterContent(FarmersSoftAssert fsa, ApplicantAceHome applicant, String propertyType) throws Exception {
        String creditReportDisclaimer = "//app-personal-info//div[contains(@class,'disclaimer__credit-report')]//p[1]";
        String consumerReportDisclaimer = "//app-personal-info//div[contains(@class,'disclaimer__credit-report')]//p[2]";
        String privacyPolicyDisclaimer = "//app-personal-info//div[contains(@class,'disclaimer__color') and not(@hidden)]";
        String privacyPolicyLink = "//app-personal-info//div[contains(@class,'disclaimer__color')]//a";

        String FARMERS_MAY_REVIEW_YOUR_CREDIT_REPORT = "In connection with this application for insurance, Farmers may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report.";
        String FARMERS_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT = "In connection with this application for insurance, Farmers may review your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report.";
        String FARMERS_ANDOR_AFFILIATES_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT = "In connection with this application for insurance, Farmers and/or affiliates may review your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report.";

        String WE_MAY_USE_THIRD_PARTIES = "We may use third parties in connection with the development of your insurance scores based on data from traditional credit bureaus and the National Consumer Telecom & Utilities Exchange database.";
        String WE_MAY_USE_A_THIRD_PARTY = "We may use a third party in connection with the development of your insurance scores based on data from traditional credit bureaus and the National Consumer Telecom & Utilities Exchange database.";

        String EXTRAORDINARY_CIRCUMSTANCES = "If you believe an extraordinary life circumstance has negatively impacted your credit information, you may request, in writing, that we provide reasonable exceptions to our underwriting and/or rating practices.";
        String CONTACT_A_FARMERS_REPRESENTATIVE = "Please contact a Farmers\u00ae representative for details on qualifying circumstances and how to request an exception.";

        String CONSUMER_REPORT_ADDITIONAL_DISCLAIMER = "Any estimate provided will reflect rates in effect as of the date of that estimate and is subject to revision, including revision based on verification of information and inspection if needed." + SPACE +
                "Premium may vary based on additional information, coverages, and deductibles that you select, underwriting criteria, and any changes to assumptions." + SPACE +
                "Farmers reserves the right to accept, reject, or modify this quote after review of an application and other underwriting information." + SPACE +
                "Applications are subject to underwriting approval. Farmers online auto quotes are available for new auto customers.";

        String expectedCreditReportDisclaimer = FARMERS_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE + WE_MAY_USE_THIRD_PARTIES;;
        String expectedConsumerReportDisclaimer = "Farmers entities may use any consumer report information their affiliates might currently have for you for your quote request." + SPACE +
                "Our Privacy Notice gives you the choice to opt out of allowing Farmers affiliates to share your consumer report information among Farmers entities." + SPACE +
                "You can still opt out of future sharing.";
        String expectedPrivacyPolicyDisclaimer = "By clicking \"Agree\", you acknowledge that you've read and agree to the Privacy Policy and the above consumer report information provisions." + SPACE +
                "Otherwise contact a Farmers\u00ae representative to discuss options.";

        if (!propertyType.equals(FFQ_MOBILE_HOME)) {
            if (isNoSpouseCreditInCondoRentersDisclaimersState(applicant.getStateCode()) &&
                    (propertyType.equals(CONDO) || propertyType.equals(RENTERS))) {
                expectedCreditReportDisclaimer = FARMERS_MAY_REVIEW_YOUR_CREDIT_REPORT + SPACE + WE_MAY_USE_THIRD_PARTIES;
            } else {
                switch (applicant.getStateCode()) {
                    case CA:
                        expectedCreditReportDisclaimer = "In connection with this application for insurance, Farmers may obtain consumer reports or personal information from third parties. This information, as well as " +
                                "other personal information subsequently collected by the insurer or your agent, may in certain circumstances be disclosed to third parties without authorization, as permitted by law.";
                        if (propertyType.equals(RENTERS)) {
                            expectedConsumerReportDisclaimer = EMPTY_STRING;
                        } else if (propertyType.equals(HOME)) {
                            expectedConsumerReportDisclaimer = expectedConsumerReportDisclaimer + SPACE + CONSUMER_REPORT_ADDITIONAL_DISCLAIMER;
                        } else if (propertyType.equals(CONDO)) {
                            expectedConsumerReportDisclaimer = EMPTY_STRING;
                            expectedPrivacyPolicyDisclaimer = "By clicking \"Agree\", you acknowledge that you have read and agree to the Privacy Policy and agree to the use of consumer report information described above. " +
                                    "Otherwise, you can contact a Farmers\u00ae representative to discuss your options.";
                        }
                        break;
                    case CT:
                        expectedCreditReportDisclaimer = FARMERS_ANDOR_AFFILIATES_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                                "We may use third parties in connection with the development of your insurance scores based on data from traditional credit bureaus." + SPACE +
                                "If you believe an extraordinary life circumstance has negatively impacted your credit information, you may request, in writing, that we provide reasonable exceptions to our underwriting and/or rating practices for this quote or any policy issued." + SPACE +
                                CONTACT_A_FARMERS_REPRESENTATIVE;
                        break;
                    case IA:
                        expectedCreditReportDisclaimer = FARMERS_ANDOR_AFFILIATES_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                                WE_MAY_USE_THIRD_PARTIES + SPACE +
                                EXTRAORDINARY_CIRCUMSTANCES + SPACE +
                                CONTACT_A_FARMERS_REPRESENTATIVE;
                        break;
                    case IL:
                        if (!propertyType.equals(CONDO) && !propertyType.equals(RENTERS)) {
                            expectedConsumerReportDisclaimer = expectedConsumerReportDisclaimer + SPACE + CONSUMER_REPORT_ADDITIONAL_DISCLAIMER;
                        }
                        break;
                    case KS:
                        expectedCreditReportDisclaimer = FARMERS_ANDOR_AFFILIATES_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                                WE_MAY_USE_THIRD_PARTIES + SPACE +
                                "We provide an internal appeal process whereby you may ask us to review an adverse action based on your credit information." + SPACE +
                                "Also, if you believe an extraordinary life circumstance has negatively impacted your credit information, you may request, in writing, that we provide reasonable exceptions to our underwriting and/or rating practices." + SPACE +
                                CONTACT_A_FARMERS_REPRESENTATIVE;
                        break;
                    case KY:
                        expectedCreditReportDisclaimer = FARMERS_ANDOR_AFFILIATES_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                                WE_MAY_USE_THIRD_PARTIES + SPACE +
                                EXTRAORDINARY_CIRCUMSTANCES + SPACE +
                                CONTACT_A_FARMERS_REPRESENTATIVE;
                        break;
                    case MD:
                        expectedCreditReportDisclaimer = "Farmers Privacy Notice gives you the choice to opt out of allowing Farmers affiliates to share your consumer report information among Farmers entities." + SPACE +
                                "May Farmers entities use any consumer report information their affiliates might currently have for you for this specific transaction. You can still opt out of future sharing.";
                        break;
                    case MI:
                        expectedCreditReportDisclaimer = FARMERS_ANDOR_AFFILIATES_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                                WE_MAY_USE_THIRD_PARTIES + SPACE +
                                EXTRAORDINARY_CIRCUMSTANCES + SPACE +
                                CONTACT_A_FARMERS_REPRESENTATIVE;
                        break;
                    case MN:
                        expectedCreditReportDisclaimer = "The insurer may elect to cancel coverage at any time during the first 59 days following issuance of the coverage for any reason which is not specifically prohibited by statute.";
                        expectedConsumerReportDisclaimer = "Your state also requires us to tell you that we may obtain consumer reports or personal or privileged information from third parties." + SPACE +
                                "This information as well as other personal or privileged information subsequently collected by us or your agent may be used for underwriting or rating and in certain circumstances may be disclosed to third parties without authorization, as permitted by law." + SPACE +
                                "You have the right of access and correction with respect to all personal information collected." + SPACE +
                                "At your request, we will provide you with more detailed information regarding our collection, use and disclosure of personal information, and your rights to access and correct such information." + SPACE +
                                "By continuing, you authorize us and your agent to collect and disclose your personal and privileged information." + SPACE +
                                "This authorization will remain valid for as long as you are continually insured with us." + SPACE +
                                FARMERS_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                                WE_MAY_USE_THIRD_PARTIES + SPACE +
                                EXTRAORDINARY_CIRCUMSTANCES + SPACE +
                                "Please contact us for details on qualifying circumstances and how to request an exception." + SPACE +
                                expectedConsumerReportDisclaimer;
                        break;
                    case MT:
                        expectedConsumerReportDisclaimer = "Also, Farmers entities may use any consumer report information their affiliates might currently have for you for this transaction.";
                        expectedPrivacyPolicyDisclaimer = "By clicking \"Agree\", you acknowledge that you have read and agree to the Privacy Policy and agree to the use of consumer report information described above. Otherwise, you can contact a Farmers\u00ae representative to discuss your options.";
                        break;
                    case NC:
                        expectedCreditReportDisclaimer = FARMERS_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                                WE_MAY_USE_THIRD_PARTIES + SPACE +
                                "In addition to a $3 installment fee, we also may charge a $15 late fee, a $20 returned payment charge, or a $25 reinstatement fee." + SPACE +
                                "This policy is also subject to a policy fee of $5. By proceeding, you agree to pay any fees assessed.";
                        break;
                    case NM:
                        expectedCreditReportDisclaimer = "In connection with this application for insurance coverage, Farmers may review and use information contained in your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report to help determine your premium or your eligibility for coverage." + SPACE +
                                WE_MAY_USE_A_THIRD_PARTY;
                        break;
                    case OK:
                        expectedCreditReportDisclaimer = FARMERS_ANDOR_AFFILIATES_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                                WE_MAY_USE_THIRD_PARTIES + SPACE +
                                EXTRAORDINARY_CIRCUMSTANCES + SPACE +
                                CONTACT_A_FARMERS_REPRESENTATIVE;
                        break;
                    case OR:
                        expectedCreditReportDisclaimer = FARMERS_MAY_REVIEW_YOUR_AND_YOUR_SPOUSES_CREDIT_REPORT + SPACE +
                                WE_MAY_USE_THIRD_PARTIES + SPACE +
                                "You may request that we give you a written statement describing our use of credit history and insurance scores.";
                        break;
                    case VA:
                        expectedCreditReportDisclaimer = "In connection with this application for insurance, Farmers shall review your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report." + SPACE +
                                WE_MAY_USE_THIRD_PARTIES + SPACE +
                                "You may request that your credit information be updated and if you question the accuracy of the credit information, we will, upon your request, reevaluate you based on corrected credit information from a consumer reporting agency.";
                        break;
                    case TX:
                        expectedCreditReportDisclaimer =  "We will obtain and use credit information, from traditional credit bureaus and the National Consumer Telecom & Utilities Exchange database, on you [and your spouse] as a part of the insurance credit scoring process.";
                        break;
                }
            }
        }
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(creditReportDisclaimer))), expectedCreditReportDisclaimer, "Address page - Credit report disclaimer for " + applicant.getStateCode());
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(consumerReportDisclaimer))), expectedConsumerReportDisclaimer, "Address page - Consumer report disclaimer for " + applicant.getStateCode());
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(privacyPolicyDisclaimer))), expectedPrivacyPolicyDisclaimer, "Address page - Privacy Policy disclaimer for " + applicant.getStateCode());
        fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(privacyPolicyLink))), "Privacy Policy", "Address page - Privacy Policy link label");
        fsa.assertTrue(getAttributeData(driver().findElement(By.xpath(privacyPolicyLink)), HREF).contains("https://www.farmers.com/disclaimer/privacy-policy/"), "Address page - Privacy Policy link contains expected url.");
    }

    public void validatePageErrors(FarmersSoftAssert sa, ApplicantAceHome applicant) throws Exception {
        final String ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR = "Please enter street number and name.";
        final String ADDRESS_FIELD_ENTER_YOUR_CITY_ERROR = "Please enter your city.";
        final String PAGE_ALERT = "One or more required fields are incomplete or incorrect. Please review.";
        clickContinueButton();
        waitForSpinnerToBeGone();
        List<String> listOfErrorsFoundInPage = getPageErrors();
        sa.assertTrue(listOfErrorsFoundInPage.contains(ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR), ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR + ERROR_FOUND);
        sa.assertTrue(listOfErrorsFoundInPage.contains(ADDRESS_FIELD_ENTER_YOUR_CITY_ERROR), ADDRESS_FIELD_ENTER_YOUR_CITY_ERROR + ERROR_FOUND);
        sa.assertTrue(getPageAlerts().contains(PAGE_ALERT), "Expected page alert(s) found.");
        waitAndClickElement(formFieldAddressManualInput);
        sendKeysToElement(formFieldAddressManualInput,SPECIALCHARS);
        clickContinueButton();
        waitForSpinnerToBeGone();
        sa.assertTrue(getPageErrors().contains(ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR), ADDRESS_FIELD_ENTER_YOUR_ADDRESS_ERROR + ERROR_FOUND);
        sa.assertTrue(getPageAlerts().contains(PAGE_ALERT), "Expected page alert(s) found.");
        driver().navigate().refresh();
        enterGoogleAddressAceHome(formFieldAddressInput, formFieldCityInput, applicant);
        wait.until(invisibilityOfElementLocated(By.xpath("//mat-error")));
        sa.assertTrue(getPageErrors().isEmpty(), "Page error(s) should not be found.");
        sa.assertTrue(getPageAlerts().isEmpty(), "Page alert(s) should not be found.");
    }

    public void enterAvailableFields(ApplicantAceHome applicant) throws Exception {
        if (applicant.isNewlyOwned() != isNewHomeSelected()) {
            selectNewHome(applicant.isNewlyOwned());
        }
        if (applicant.isNewlyOwned() && (applicant.isInEscrow() != isInEscrowSelected())) {
            selectInEscrow(applicant.isInEscrow());
        }
        if (isNoPropertyClaimsQuestionOnAddressPage(applicant.getStateCode())) {
            if (isElementDisplayed(By.xpath(NUMBER_OF_PROPERTY_LOSSES_XPATH))) {
                selectNumberOfPropertyLosses(NONE);
            }
        } else {
            selectNumberOfPropertyLosses(NONE);
        }
        if (!applicant.isPrimaryResidence()) {
            selectNotPrimaryResidenceReason(applicant.getReasonWhyNotPrimaryResidence());
        }
    }

    public void fillOutAddressPage(ApplicantAceHome applicant) throws Exception {
        enterAddress(applicant);
        enterAvailableFields(applicant);
        clickContinueButton();
        waitForSpinnerToBeGone();
    }

    public void validateNonPrimaryResidence(FarmersSoftAssert sa, ApplicantAceHome applicant, String lobType) throws Exception {
        String stateCode = applicant.getStateCode();
        String randomSelectedReason = selectPrimaryResidenceAsNoWithRandomReason(stateCode);
        boolean isPropertyYearBuiltPage = false;
        AceHRCPropertyBasePage propertyPage = new AceHRCPropertyBasePage();
        if (propertyPage.isOnHRCPropertyBasePage(false)) {
            isPropertyYearBuiltPage = true;
            propertyPage.enterPropertyPageFields(applicant);
            clickContinueButton();
            waitForSpinnerToBeGone();
        }
        if (!isSeasonalSecondaryHomeState(stateCode)) {
            validateKnockout(sa, applicant, "nonOffering");
        } else {
            if (randomSelectedReason.equals(SEASONAL) || randomSelectedReason.equals(SECONDARY)) {
                if (isPropertyYearBuiltPage) {
                    AceHRCPropertyDetailsBasePage aceHRCPropertyDetailsBasePage = new AceHRCPropertyDetailsBasePage();
                    sa.assertTrue(aceHRCPropertyDetailsBasePage.isOnPropertyDetailsPage(), "Navigated to Property details page - " + lobType);
                }
            }else{
                ForemostLandingPage foremostLandingPage = new ForemostLandingPage();
                foremostLandingPage.validateContentOfContinueWithForeMostScreen(sa, HOME);
                foremostLandingPage.validateURLAfterClickingOnContinueWithForeMostButton(sa, randomSelectedReason, HOME);
            }
        }
    }

    public void validateTwoOrMorePropertyClaims(FarmersSoftAssert fsa, ApplicantAceHome applicant, String lobType) throws Exception {
        selectNumberOfPropertyLosses("Two or more");
        clickContinueButton();
        if (!lobType.equals(HOME)) {
            KnockoutInconveniencePage knockoutPage = new KnockoutInconveniencePage();
            if (applicant.getAgentId().isBlank()) {
                knockoutPage.verifyMonetizationKnockout(fsa);
            } else {
                knockoutPage.verifyUnableToCompleteOnlineKnockout(applicant, fsa);
            }
        } else { // F99042: FFQ Home KO Redirect To FGIA (No KO, but forwarding to FGIA instead)
            FGIALandingPage fgiaLandingPage = new FGIALandingPage();
            fgiaLandingPage.validateContentOfFGIAPopUp(fsa, HOME);
            if (fgiaLandingPage.isFgiaNoThanksButtonDisplayed()) {
                fgiaLandingPage.clickNoThanksButtonInFGIAPopUp();
                fgiaLandingPage.weAreNotAbleToCompleteQuotePageValidation(fsa, HOME);
            }
        }
    }

    private void validateKnockout(FarmersSoftAssert sa, ApplicantAceHome applicant, String koType) throws Exception {
        KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
        if (isElementVisible(koPage.getKnockoutTitle(),3)) {
            if (koType.equals("nonOffering")) {
                koPage.validateKnockOutForNotOffering(sa);
            } else {
                if (applicant.getAgentId().isBlank()) {
                    koPage.verifyMonetizationKnockout(sa);
                } else {
                    koPage.verifyUnableToCompleteOnlineKnockout(applicant, sa);
                }
            }
        } else {
            clickContinueButton();
            waitForSpinnerToBeGone();
            AceHRCPropertyBasePage propertyBasePage = new AceHRCPropertyBasePage();
            if (propertyBasePage.isOnHRCPropertyBasePage(false)) {
                waitElementBeVisible(buttonContinue,3);
                propertyBasePage.enterPropertyPageFields(applicant);
                propertyBasePage.clickContinueButton();
            }
            AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
            waitElementBeVisible(buttonContinue,3);
            qualityGradePage.clickContinueButton();
            koPage = new KnockoutInconveniencePage();
            koPage.validateKnockOutForNotOffering(sa);
        }
    }

    public void validateADA(String lobType) throws Exception {
        clickContinueButton(); // to expose address page errors
        performADATesting("AceHRCAddressPage", MARKETING_IT, lobType);
        if (isElementDisplayed(By.xpath(NEW_HOME_BUTTON_XPATH + "//button"))) {
            selectNewHome(true);
        }
        if (isElementDisplayed(By.xpath(PRIMARY_RESIDENCE_XPATH + "//button"))) {
            selectPrimaryResidence(false);
        }
        clickContinueButton();
        if (isElementDisplayed(By.xpath(NEW_HOME_BUTTON_XPATH + "//button"))) {
            performADATesting("AceHRCAddressPage_NewHome_NonPrimaryResidence", MARKETING_IT, lobType);
        } else {
            performADATesting("AceHRCAddressPage_EnterAddressManually", MARKETING_IT, lobType);
        }
        driver().navigate().refresh();
    }

    public void verifyAutoHRCBundlePageContent(String lobType, ApplicantAceHome applicantAceHome, FarmersSoftAssert fsa) throws Exception {
        String applicantStateCode = applicantAceHome.getStateCode();
    	String expectedPageTitleString = lobType.equalsIgnoreCase(RENTERS)? "One more question": "A few property questions";
    	fsa.assertEquals(getTextFromElement(addressPageTitle), expectedPageTitleString, "Bundle property questions page title validation");
    	fsa.assertTrue(!isElementVisible(formFieldAddressManualInput, 3), "Address input field not visible");
    	if (!lobType.equalsIgnoreCase(RENTERS)) {
    		String newHomeExpectedText = isSafariBrowser()? "Is this a home you're buying, or have owned for less than a year?YesNo": NEW_HOME_TEXT;
    		fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(NEW_HOME_BUTTON_XPATH))), newHomeExpectedText, "New Home label and button text validation");
    		fsa.assertTrue(isNotNewHomeSelected(), "Not a New Home button is selected.");
    		selectNewHome(true);
    		fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(IN_ESCROW_XPATH))), IN_ESCROW_TEXT, "Currently In Escrow text validation");
    		fsa.assertTrue(isNotInEscrowSelected(), "Currently in Not Escrow button is selected.");
    		selectNewHome(false);
    		fsa.assertTrue(!isElementDisplayed(By.xpath(IN_ESCROW_XPATH)), "When Not New Home, In Escrow should not display.");
    		String primaryReferenceExpectedText = isSafariBrowser()? "Is this your primary residence?YesNo": PRIMARY_RESIDENCE_TEXT;
    		fsa.assertEquals(getTextFromElement(driver().findElement(By.xpath(PRIMARY_RESIDENCE_XPATH))), primaryReferenceExpectedText, "Primary Residence text validation");
    		fsa.assertTrue(isPrimaryResidenceSelected(), "Primary Residence button is selected.");
    		selectPrimaryResidence(false);
    		List<String> subtextNotPrimaryReasons = driver().findElements(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH +
    				"//span[contains(@class,'primary-residence-usage__subtext')]")).stream().map(this::getTextFromElement).collect(Collectors.toList());
    		List<String> NOT_PRIMARY_RESIDENCE_REASONS = List.of("My home is or will be occupied by a renter (short or long term)",
    				"This home is for seasonal or secondary use.", "Such as my home is vacant, or will be under renovation within 30 days.");
    		List<String> NOT_PRIMARY_RESIDENCE_REASONS_WITH_FOUR_OPTIONS = List.of("This home is or will be occupied by a renter (short or long term).",
    				"This home is not rented out.", "This home is not rented out.", "This home is vacant, or will be under renovation within 30 days.");
    		fsa.assertEquals(subtextNotPrimaryReasons, isPrimaryResidenceHasFourOptions(applicantStateCode)? NOT_PRIMARY_RESIDENCE_REASONS_WITH_FOUR_OPTIONS : NOT_PRIMARY_RESIDENCE_REASONS,
    				"Not Primary Residence Reasons subtext.");
    		selectPrimaryResidence(true);
    		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH)));
    		fsa.assertTrue(!isElementDisplayed(By.xpath(NOT_PRIMARY_RESIDENCE_REASON_XPATH)), "When Primary Residence, Not Primary Reasons should not display.");
    	}
        String propertyLossesQuestion = applicantStateCode.equals(CA)? PROPERTY_LOSSES_SUBHEADING_TEXT_CA : PROPERTY_LOSSES_SUBHEADING_TEXT;
    	fsa.assertEquals(getTextFromElement(propertyLossesSubheading), propertyLossesQuestion, "Property losses section label validation");
    	List<WebElement> propertyToggleLabelTexts = driver().findElements(By.xpath("//app-personal-info//div[@id='formField_noOfPropertyLosses']//span[contains(@class,'mat-button-toggle-label-content')]"));
    	List<String> actualListOfLabels = propertyToggleLabelTexts.stream().map(this::getTextFromElement).collect(Collectors.toList());
    	List<String> expectedListOfLabels = Arrays.asList("None", "One", "Two or more");
    	fsa.assertEquals(actualListOfLabels, expectedListOfLabels, "Property losses button label validation");
    	fsa.assertEquals(getNumberOfPropertyLossesSelected(), NONE, "Property Losses 'None' is selected.");
        verifyFooterContent(fsa, applicantAceHome, lobType);
    }

    public String selectPrimaryResidenceAsNoWithRandomReason(String stateCode) throws Exception {
        List<String> values = getListOfNotPrimaryResidenceReasonsValues();
        Collections.shuffle(values);
        selectPrimaryResidence(false);
        String randomSelectedValue = values.get(FIRST_AVAILABLE_OPTION);
        selectNotPrimaryResidenceReason(randomSelectedValue);
        return randomSelectedValue;
    }

    public void selectNonPrimaryResidenceWithSecondarySeasonalReason() throws Exception {
        List<String> reasons = List.of(SECONDARY, SEASONAL);
        selectPrimaryResidence(false);
        Random random = new Random();
        String randomSelectedReason = reasons.get(random.nextInt(reasons.size()));
        selectNotPrimaryResidenceReason(randomSelectedReason);
    }

    public void consentToCreditReport() throws Exception {
    	if (getTextFromElement(addressPageTitle).equals("One more question") && !isElementDisplayed(propertyLossesSubheading, 3)) {
    		clickContinueButton();
    	}
    }

    public boolean isCheckYourEligibilityLinkDisplayed(FarmersSoftAssert fsa) {
        return isElementDisplayed(linkCheckYourEligibility, 5);
    }

    public void setEmployerGroup(String empGroup) throws Exception {
        waitAndClickElement(linkCheckYourEligibility);
        Log.info("Employer Group: " + empGroup);
        sendKeysOneByOne(inputEmployerGroup, empGroup);
        sleep(3);
        // Try up to 3 times to make employerOption visible and clickable
        int maxAttempts = 3;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                waitElementBeVisible(employerOption, 5);
                break; // Success, exit loop
            } catch (Exception e) {
                if (attempt == maxAttempts)
                    throw new Exception(" >> Employer options are not displaying >>"); // Rethrow after last attempt
                clearOutFieldUsingBackSpace(inputEmployerGroup);
                sendKeysOneByOne(inputEmployerGroup, empGroup);
            }
        }
        String empGroup1 = empGroup.substring(0,1).toUpperCase() + empGroup.substring(1).toLowerCase();
        WebElement selection = driver().findElement(By.xpath(EMPLOYER_GROUP_LIST_XPATH + "[starts-with(.,'" + empGroup + "') or " +
                "starts-with(.,'" + empGroup1 + "')]"));
        waitAndClickElement(selection);
        waitAndClickElement(continueWithGroupDiscountButton);
    }

    public String getSelectedEmployerName(){
        return getTextFromElement(waitElementBeVisible(groupEmployerName, 5)).trim();
    }

    public void clickZipChangeYes() {
        waitAndClickElement(buttonZipChangeYes);
    }

    public void clickZipChangeGoBack() {
        waitAndClickElement(buttonZipChangeGoBack);
    }
}
