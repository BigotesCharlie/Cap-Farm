package com.farmers.ffq.auto.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OneMomentPage extends AutoBasePage {

    @FindBy(xpath = "//p[contains(@class, 'auto-spinner__subheading')]")
    private WebElement pageContent;
    @FindBy(xpath = "//app-one-moment//h1")
    private WebElement pageTitle;

    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public OneMomentPage() throws Exception {
    }

    public boolean isOnOneMomentPage() {
        return isElementVisible(pageTitle, 5);
    }

    public String getOneMomentPageContent() {
	return getTextFromElement(pageContent);
    }

    public String getOneMomentPageTitle() {
        return getTextFromElement(pageTitle);
    }

    public void waitPageTitleAppear() {
        waitElementBeVisible(pageTitle);
    }

}
