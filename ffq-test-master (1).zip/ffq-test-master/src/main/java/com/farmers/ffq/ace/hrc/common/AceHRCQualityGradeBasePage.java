package com.farmers.ffq.ace.hrc.common;

import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Home.Field;
import com.farmers.ffq.datatransferobjects.AppStore.Home.HomeQualityGradeForm;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCQualityGradeBasePage extends AceHRCBasePage {
    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceHRCQualityGradeBasePage() throws Exception {
    }

    public boolean isOnQualityGradePage() {
        return isElementVisible(yourHomeQualityGradeHeader, Property.PAGELOADTIMEOUT);
    }

    public boolean isOnPropertyDetailsQualityGradePage(boolean longWait) {
        int timer = longWait ? Property.PAGELOADTIMEOUT : 5;
        return isElementVisible(propertyDetailsYourHomeQualityGradeHeader, timer);
    }

    public boolean isOnQualityGradeOrPropertyDetailsAndQualityCombined(boolean longWait) {
        int timer = longWait ? Property.PAGELOADTIMEOUT : 5;
        try {
            driverWait(timer).until(ExpectedConditions.or(
                    ExpectedConditions.visibilityOf(yourHomeQualityGradeHeader),
                    ExpectedConditions.visibilityOf(propertyDetailsYourHomeQualityGradeHeader)));
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    private static final String ECONOMY_QUALITY_GRADE = "Economy";
    private static final String STANDARD_QUALITY_GRADE = "Standard";
    private static final String ABOVE_AVERAGE_QUALITY_GRADE = "Above Average";
    private static final String CUSTOM_QUALITY_GRADE = "Custom";
    private static final String PREMIUM_QUALITY_GRADE = "Premium";

    private final List<String> EXPECTED_QUALITY_GRADE_RADIO_BUTTON_TEXT = Arrays.asList("Economy", "Standard", "Above Average", "Custom", "Premium");

    private static final String EXPECTED_GENERAL_SHAPE_AND_STYLE_HEADER = "General Shape & Style";
    private static final String EXPECTED_EXTERIOR_FEATURES_AND_FINISHES_HEADER = "Exterior Features & Finishes";
    private static final String EXPECTED_INTERIOR_FEATURES_AND_FINISHES_HEADER = "Interior Features & Finishes";
    private static final String EXPECTED_CABINETS_AND_COUNTERTOPS_HEADER = "Cabinets & Countertops";
    private static final String EMPTY_QUALITY_GRADE = "--";
    @FindBy(xpath = "//app-quality-grade//h1")
    private WebElement yourHomeQualityGradeHeader;
    @FindBy(xpath = "//app-quality-grade//h2")
    private WebElement yourHomeQualityGradeHeaderSection;
    @FindBy(xpath = "//app-property-details//h2[contains(@class,'home-details-section-title') and text()='Your home quality grade']")
    private WebElement propertyDetailsYourHomeQualityGradeHeader;
    @FindBy(xpath = "//app-quality-grade//div[contains(text(), 'Please review')]")
    private WebElement pleaseReviewQualityGradeSubText;
    @FindBy(xpath = "//h2[contains(@class,'street_address')]")
    private WebElement customerstreetAddressWebElement;
    @FindBy(xpath = "//span[contains(@class,'city_zipcode')]")
    private WebElement customerCityStateZipcodeWebElement;
    @FindBy(xpath = "//div[contains(@class,'customer-address')]")
    private WebElement customerAddressQualityGradeSection;
    @FindBy(xpath = "//app-quality-grade//div[contains(@class,'customer-address')]/div[1]")
    private WebElement qualityGradeAddressLine1;
    @FindBy(xpath = "//app-quality-grade//div[contains(@class,'customer-address')]/div[2]")
    private WebElement qualityGradeAddressLine2;

    @FindBy(xpath = "//div[contains(@class,'general-style')]//p")
    private WebElement generalShapeAndStyleHeader;

    @FindBy(css = "button.edit-button.tui-link-button")
    private List<WebElement> editButtons;

    final static String INITIAL_XPATH_GENERAL_SHAPE_STYLE = "//div[contains(@class,'general-style')]";
    @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//span[contains(@class,'quality-grade-desc')]")
    private WebElement generalShapeAndStyleQualityGrade;
    @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//button")
    private WebElement generalShapeAndStyleEditLinkButton;
    @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//following::div[1]//mat-radio-button//input")
    private List<WebElement> generalShapeAndStyleRadioButtons;

    @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//following::div[1]//mat-radio-button")
    private List<WebElement> generalShapeAndStyleMatRadioButtons;
    @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//following::div[1]//mat-radio-button[contains(@class,'radio-checked')]")
    private WebElement checkedGeneralShapeAndStyleRadioButton;
    @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//following::div[1]//div[contains(@class,'section-selector-images')]//img")
    private List<WebElement> generalShapeAndStyleHomeImages;
    @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//following::div[1]//div[contains(@class,'section-selector-content')]")
    private WebElement generalShapeAndStyleDescriptions;
    @FindBy(xpath = "//div[@id='section-selector-content-for-General']")
    private WebElement generalShapeAndStyleQualityGradeFeatures;
    @FindBy(xpath = INITIAL_XPATH_GENERAL_SHAPE_STYLE + "//span[contains(@class,'quality-grade-desc')]")
    private WebElement generalShapeAndStyleDescription;

    final static String INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES = "//div[contains(@class,'exterior-feature-style')]";
    @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//p")
    private WebElement exteriorFeaturesAndFinishesHeader;
    @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//span[contains(@class,'quality-grade-desc')]")
    private WebElement exteriorFeaturesAndFinishesQualityGrade;
    @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//button")
    private WebElement exteriorFeaturesAndFinishesEditLinkButton;
    @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//following::div[1]//mat-radio-button//input")
    private List<WebElement> exteriorFeaturesAndFinishesRadioButtons;
    @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//following::div[1]//mat-radio-button")
    private List<WebElement> exteriorFeaturesAndFinishesMatRadioButtons;
    @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//following::div[1]//div[contains(@class,'section-selector-images')]//img")
    private List<WebElement> exteriorFeaturesAndFinishesHomeImages;
    @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//following::div[1]//div[contains(@class,'section-selector-content')]")
    private List<WebElement> exteriorFeaturesAndFinishesDescriptions;
    @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//following::div[1]//mat-radio-button[contains(@class,'radio-checked')]")
    private WebElement checkedExteriorFeaturesAndFinishedRadioButton;
    @FindBy(xpath = "//div[@id='section-selector-content-for-Exterior']")
    private WebElement exteriorFeaturesAndFinishesQualityGradeFeatures;
    @FindBy(xpath = INITIAL_XPATH_EXTERIOR_FEATURES_FINISHES + "//span[contains(@class,'quality-grade-desc')]")
    private WebElement exteriorFeaturesAndFinishesDescription;

    final static String INITIAL_XPATH_INTERIOR_FEATURES_FINISHES = "//div[contains(@class,'interior-feature-style')]";
    @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//p")
    private WebElement interiorFeaturesAndFinishesHeader;
    @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//span[contains(@class,'quality-grade-desc')]")
    private WebElement interiorFeaturesAndFinishesQualityGrade;
    @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//button")
    private WebElement interiorFeaturesAndFinishesEditLinkButton;
    @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//following::div[1]//mat-radio-button//input")
    private List<WebElement> interiorFeaturesAndFinishesRadioButtons;
    @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//following::div[1]//mat-radio-button")
    private List<WebElement> interiorFeaturesAndFinishesMatRadioButtons;
    @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//following::div[1]//div[contains(@class,'section-selector-images')]//img")
    private List<WebElement> interiorFeaturesAndFinishesImages;
    @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//following::div[1]//div[contains(@class,'section-selector-content')]")
    private WebElement interiorFeaturesAndFinishesDescriptions;
    @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//following::div[1]//mat-radio-button[contains(@class,'radio-checked')]")
    private WebElement checkedInteriorFeaturesAndFinishedRadioButton;
    @FindBy(xpath = "//div[@id='section-selector-content-for-Interior']")
    private WebElement interiorFeaturesAndFinishesQualityGradeFeatures;
    @FindBy(xpath = INITIAL_XPATH_INTERIOR_FEATURES_FINISHES + "//span[contains(@class,'quality-grade-desc')]")
    private WebElement interiorFeaturesAndFinishesDescription;

    final static String INITIAL_XPATH_CABINETS_COUNTERTOPS = "//div[contains(@class,'cabinet-style')]";
    @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//p")
    private WebElement cabinetsAndCounterTopsHeader;
    @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//span[contains(@class,'quality-grade-desc')]")
    private WebElement cabinetsAndCounterTopsQualityGrade;
    @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//button")
    private WebElement cabinetsAndCounterTopsEditLinkButton;
    @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//following::div[1]//mat-radio-button//input")
    private List<WebElement> cabinetsAndCounterTopsRadioButtons;
    @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//following::div[1]//mat-radio-button")
    private List<WebElement> cabinetsAndCounterTopsMatRadioButtons;
    @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//following::div[1]//div[contains(@class,'section-selector-images')]//img")
    private List<WebElement> cabinetsAndCounterTopsHomeImages;
    @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//following::div[1]//div[contains(@class,'section-selector-content')]")
    private WebElement cabinetsAndCounterTopsDescriptions;
    @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//following::div[1]//mat-radio-button[contains(@class,'radio-checked')]")
    private WebElement checkedCabinetsAndCountertopsRadioButton;
    @FindBy(xpath = "//div[@id='section-selector-content-for-Cabinet']")
    private WebElement cabinetsAndCountertopsQualityGradeFeatures;
    @FindBy(xpath = INITIAL_XPATH_CABINETS_COUNTERTOPS + "//span[contains(@class,'quality-grade-desc')]")
    private WebElement cabinetsAndCountertopsDescription;

    @FindBy(xpath = "//div[contains(@class,'lightbulb-container')]//img[contains(@class,'lightbulb-icon')]")
    private WebElement lightBulbIcon;
    @FindBy(xpath = "//div[contains(@class,'disclaimer-header')]//div[contains(@class,'tui-subtitle')]")
    private WebElement whyIsThisImportantQuestion;
    @FindBy(xpath = "//div[contains(@class,'disclaimer-text')]")
    private WebElement disclaimerText;
    @FindBy(xpath = "//p[contains(@class,'error-highlight')]")
    private List<WebElement> errorsOnQualityGradePage;

    @FindBy(xpath = "//mat-dialog-container//button")
    private WebElement doubleCheckYourCoverageDialogContinueButton;

    private static final String QUALITY_GRADE_PAGE_TITLE = "Your home quality grade";

    public boolean isQualityGradePageAlone() {
        return isElementDisplayed(yourHomeQualityGradeHeader, 5) && getTextFromElement(yourHomeQualityGradeHeader).equals(QUALITY_GRADE_PAGE_TITLE);
    }

    public void dismissCheckYourCoverageDialog() {
    	if (isElementDisplayed(doubleCheckYourCoverageDialogContinueButton, 5)) {
    		clickElement(doubleCheckYourCoverageDialogContinueButton);
    		waitElementBeInvisible(doubleCheckYourCoverageDialogContinueButton);
    	}
    }

    public void clickOnGeneralShapeAndStyleEditButton() {
        scrollAndClickOnElement(generalShapeAndStyleEditLinkButton);
    }

    public void clickOnExteriorFeaturesAndFinishesEditButton() {
        scrollAndClickOnElement(exteriorFeaturesAndFinishesEditLinkButton);
    }

    public void clickOnInteriorFeaturesAndFinishesEditButton() {
        scrollAndClickOnElement(interiorFeaturesAndFinishesEditLinkButton);
    }

    public void clickOnCabinetsCounterTopsEditButton() {
        scrollAndClickOnElement(cabinetsAndCounterTopsEditLinkButton);
    }

    public void validateHeaderAndSubHeaderForQualityGradePage(FarmersSoftAssert fsa, String lobType) throws Exception {
        String expectedYourHomeQualityGradeHeader = "Your home quality grade";
        fsa.assertEquals(getTextFromElement(yourHomeQualityGradeHeader), expectedYourHomeQualityGradeHeader, "Your home quality grade header text matching - " + lobType);
        fsa.assertTrue(isElementInViewport(yourHomeQualityGradeHeader), "Quality grade page - page title is in Viewport");

        String expectedPleaseReviewQualityGradeText = "Please review. If you feel any of the quality grades listed are inaccurate, feel free to \"Edit\" and select the appropriate grade.";
        fsa.assertEquals(getTextFromElement(pleaseReviewQualityGradeSubText), expectedPleaseReviewQualityGradeText, "Please review your quality grade text matching - " + lobType);
    }

    public void validateHeaderForQualityGradeSection(FarmersSoftAssert fsa, String lobType) throws Exception {
        String expectedYourHomeQualityGradeHeader = "Your home quality grade";
        fsa.assertEquals(getTextFromElement(yourHomeQualityGradeHeaderSection), expectedYourHomeQualityGradeHeader, "Your home quality grade section header text matching - " + lobType);
        fsa.assertTrue(isElementInViewport(yourHomeQualityGradeHeaderSection), "Quality grade section - title is in Viewport");
    }

    public void validateAddressOnQualityGradePage(FarmersSoftAssert sa, String lobType) throws Exception {
        Field address = getSessionStorageAppStore().getHome().getAddressForm().getFields().get(0);
        String customerStreetAddress = address.getAddress();
        sa.assertEquals(getTextFromElement(customerstreetAddressWebElement).toUpperCase(), customerStreetAddress.toUpperCase(),
                "Customer street address matching in quality grade page address - " + lobType);
        String customerCity = address.getCity();
        String customerState = address.getState();
        String customerZip = address.getZipCode();
        sa.assertEquals(getTextFromElement(customerCityStateZipcodeWebElement).toUpperCase().contains(customerCity.toUpperCase()), true, "Customer city matching in quality grade page address - " + lobType);
        sa.assertEquals(getTextFromElement(customerCityStateZipcodeWebElement).toUpperCase().contains(customerState.toUpperCase()), true, "Customer state matching in quality grade page address - " + lobType);
        sa.assertEquals(getTextFromElement(customerCityStateZipcodeWebElement).contains(customerZip), true, "Customer zip matching in quality grade page address - " + lobType);
    }

    public String getQualityGradeAddress() {
        return getTextFromElement(qualityGradeAddressLine1).endsWith(COMMA) ?
                getTextFromElement(qualityGradeAddressLine1) + SPACE + getTextFromElement(qualityGradeAddressLine2) :
                getTextFromElement(qualityGradeAddressLine1) + COMMA + SPACE + getTextFromElement(qualityGradeAddressLine2);
    }

    public void validateAddressOnQualityGradeSection(FarmersSoftAssert sa, String lobType) throws Exception {
        String address = getSessionStorageAppStore().getData().getCustomerData().getAddress().getNew_address();
        if (!isQualityGradePageAlone()) {
            sa.assertEquals(getQualityGradeAddress().toUpperCase(), address.toUpperCase(),
                    "Customer street address matches in quality grade section to address from appStore - " + lobType);
        } else {
            sa.assertEquals(getTextFromElement(customerAddressQualityGradeSection).toUpperCase(), address.toUpperCase(),
                    "Customer street address matches in quality grade section to address from appStore - " + lobType);
        }
    }

    public void validateErrorOnQualityGradePage(FarmersSoftAssert sa, HomeQualityGradeForm homeQualityGradeForm, String lobType) throws Exception {
        sa.assertEquals(getTextFromElement(generalShapeAndStyleHeader), EXPECTED_GENERAL_SHAPE_AND_STYLE_HEADER + ":", "General shape and style header matching - " + lobType);
        int errorCount = 0;
        // if general shape and style quality grade is empty
        String expectedGeneralShapeAndStyleQualityGrade = getHomeQualityGradeByHeader(homeQualityGradeForm, EXPECTED_GENERAL_SHAPE_AND_STYLE_HEADER);
        if (expectedGeneralShapeAndStyleQualityGrade.equals(EMPTY_QUALITY_GRADE)) {
            errorCount++;
        }

        String expectedExteriorFeaturesAndFinishesQualityGrade = getHomeQualityGradeByHeader(homeQualityGradeForm, EXPECTED_EXTERIOR_FEATURES_AND_FINISHES_HEADER);
        if (expectedExteriorFeaturesAndFinishesQualityGrade.equals(EMPTY_QUALITY_GRADE)) {
            errorCount++;
        }

        String expectedInteriorFeaturesAndFinishesQualityGrade = getHomeQualityGradeByHeader(homeQualityGradeForm, EXPECTED_INTERIOR_FEATURES_AND_FINISHES_HEADER);
        if (expectedInteriorFeaturesAndFinishesQualityGrade.equals(EMPTY_QUALITY_GRADE)) {
            errorCount++;
        }

        String expectedCabinetsAndCounterTopsQualityGrade = getHomeQualityGradeByHeader(homeQualityGradeForm, EXPECTED_CABINETS_AND_COUNTERTOPS_HEADER);
        if (expectedCabinetsAndCounterTopsQualityGrade.equals(EMPTY_QUALITY_GRADE)) {
            errorCount++;
        }

        if (errorCount > 0) {
            clickContinueButton();
            sa.assertEquals(errorsOnQualityGradePage.size(), errorCount, "Check number of Errors in quality grade page - " + lobType);
        }
    }

    public void validateGeneralShapeAndStyleSection(FarmersSoftAssert fsa, AppStore.Home home, String lobType) throws Exception {
        fsa.assertEquals(getTextFromElement(generalShapeAndStyleHeader), EXPECTED_GENERAL_SHAPE_AND_STYLE_HEADER + ":", "General shape and style header matching - " + lobType);

        String expectedGeneralShapeAndStyleQualityGrade = getHomeQualityGradeByHeader(home.getHomeQualityGradeForm(), EXPECTED_GENERAL_SHAPE_AND_STYLE_HEADER);

        // if general shape and style quality grade is empty
        if (expectedGeneralShapeAndStyleQualityGrade.equals(EMPTY_QUALITY_GRADE)) {
            int numberOfRadios = Integer.parseInt(home.getPropertyForm().getFields().get(0).getSqFeet()) > 1500 ? 4 : 5;
            List<WebElement> uncheckedRadioButtons = uncheckedQualityGradeRadioButtons(generalShapeAndStyleMatRadioButtons);
            fsa.assertEquals(uncheckedRadioButtons.size(), numberOfRadios, "General shape and style - One of the radio button is checked - " + lobType);

            String selectedRadioButtonText = randomlySelectGeneralShapeAndStyleRadioButton();
            fsa.assertEquals(getTextFromElement(generalShapeAndStyleQualityGrade), selectedRadioButtonText, "General shape and style - required radio button selected - " + lobType);
            fsa.assertEquals(getTextFromElement(generalShapeAndStyleEditLinkButton), "Hide", "General shape and style edit link button text (Hide) matching - " + lobType);
        } else {
            expectedGeneralShapeAndStyleQualityGrade = getHomeQualityGradeByHeader(home.getHomeQualityGradeForm(), EXPECTED_GENERAL_SHAPE_AND_STYLE_HEADER);
            fsa.assertEquals(getTextFromElement(generalShapeAndStyleQualityGrade), expectedGeneralShapeAndStyleQualityGrade, "Expected general shape and style quality grade matching - " + lobType);

            fsa.assertEquals(getTextFromElement(generalShapeAndStyleEditLinkButton), "Edit", "General shape and style edit link button text (Edit) matching - " + lobType);
            clickOnGeneralShapeAndStyleEditButton();
            fsa.assertEquals(getTextFromElement(generalShapeAndStyleEditLinkButton), "Hide", "General shape and style edit link button text (Hide) matching - " + lobType);

            if (lobType.equals(HOME)) {
                waitElementBeVisible(generalShapeAndStyleHomeImages.get(0));
            }

            fsa.assertEquals(getTextFromElement(checkedGeneralShapeAndStyleRadioButton), expectedGeneralShapeAndStyleQualityGrade, "Expected general shape and style quality grade is selected in radio button - " + lobType);
        }

        List<String> foundGeneralShapeAndStyleQualityGrades = generalShapeAndStyleMatRadioButtons.stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(foundGeneralShapeAndStyleQualityGrades, getExpectedQualityGrades(), "General shape and style radio button text matching - " + lobType);
        int radioButtonCount = generalShapeAndStyleRadioButtons.size();

        for (int i = 0; i < radioButtonCount; i++) {
            clickOnHiddenElement(generalShapeAndStyleRadioButtons.get(i));
            if (lobType.equals(HOME)) {
                fsa.assertEquals(generalShapeAndStyleHomeImages.size(), 3,
                        "General shape and style images size check for " + getTextFromElement(generalShapeAndStyleMatRadioButtons.get(0)) + " - " + lobType);
            }
            String expectedEconomyQualityGradeFeaturesText = "Typical Economy Features: Minimal design details Square/rectangular foundation No interior spaces extending past the foundation, e.g. bay/bow window, (also known as cantilevers) Gently sloping roof";
            String expectedEconomyQualityGradeFeaturesText_SAFARI = "Typical Economy Features:Minimal design detailsSquare/rectangular foundationNo interior spaces extending past the foundation, e.g. bay/bow window, (also known as cantilevers)Gently sloping roof";
            String expectedStandardQualityGradeFeaturesText = "Typical Standard Features: Common design details for when home was built Square/rectangular or L-shaped foundation 1 or 2 interior spaces extending past the foundation, e.g. bay/bow window, (also known as cantilevers) Gently to moderately sloping roof";
            String expectedStandardQualityGradeFeaturesText_SAFARI = "Typical Standard Features:Common design details for when home was builtSquare/rectangular or L-shaped foundation1 or 2 interior spaces extending past the foundation, e.g. bay/bow window, (also known as cantilevers)Gently to moderately sloping roof";
            String expectedAboveAverageQualityGradeFeaturesText = "Typical Above Average Features: Enhanced design details L- or T-shaped foundation 2+ interior spaces extending past the foundation, e.g. bay/bow window, (also known as cantilevers) Steeply sloping roof";
            String expectedAboveAverageQualityGradeFeaturesText_SAFARI = "Typical Above Average Features:Enhanced design detailsL- or T-shaped foundation2+ interior spaces extending past the foundation, e.g. bay/bow window, (also known as cantilevers)Steeply sloping roof";
            String expectedCustomQualityGradeFeaturesText = "Typical Custom Features: Some detailed/custom design features and architecture Irregular/complex-shaped foundation with 8+ corners 2+ interior spaces extending past the foundation, e.g. bay/bow window, (also known as cantilevers) Multiple roof lines with steeper pitch/slope";
            String expectedCustomQualityGradeFeaturesText_SAFARI = "Typical Custom Features:Some detailed/custom design features and architectureIrregular/complex-shaped foundation with 8+ corners2+ interior spaces extending past the foundation, e.g. bay/bow window, (also known as cantilevers)Multiple roof lines with steeper pitch/slope";
            String expectedPremiumQualityGradeFeaturesText = "Typical Premium Features: Detailed/custom design features and architecture Irregular/complex-shaped foundation with 13+ corners Multiple interior spaces extending past the foundation, e.g. bay/bow window, (also known as cantilevers) Steeply sloping roof";
            String expectedPremiumQualityGradeFeaturesText_SAFARI = "Typical Premium Features:Detailed/custom design features and architectureIrregular/complex-shaped foundation with 13+ cornersMultiple interior spaces extending past the foundation, e.g. bay/bow window, (also known as cantilevers)Steeply sloping roof";

            String foundQualityGradeFeaturesText = getTextFromElement(generalShapeAndStyleQualityGradeFeatures);

            switch (getTextFromElement(generalShapeAndStyleMatRadioButtons.get(i))) {
                case ECONOMY_QUALITY_GRADE:
                    expectedEconomyQualityGradeFeaturesText = isSafariBrowser() ? expectedEconomyQualityGradeFeaturesText_SAFARI : expectedEconomyQualityGradeFeaturesText;
                    fsa.assertEquals(foundQualityGradeFeaturesText, expectedEconomyQualityGradeFeaturesText, "General shape and style - Economy quality grade features text - " + lobType);
                    break;

                case STANDARD_QUALITY_GRADE:
                    expectedStandardQualityGradeFeaturesText = isSafariBrowser() ? expectedStandardQualityGradeFeaturesText_SAFARI : expectedStandardQualityGradeFeaturesText;
                    fsa.assertEquals(foundQualityGradeFeaturesText, expectedStandardQualityGradeFeaturesText, "General shape and style - standard quality grade features text - " + lobType);
                    break;

                case ABOVE_AVERAGE_QUALITY_GRADE:
                    expectedAboveAverageQualityGradeFeaturesText = isSafariBrowser() ? expectedAboveAverageQualityGradeFeaturesText_SAFARI : expectedAboveAverageQualityGradeFeaturesText;
                    fsa.assertEquals(foundQualityGradeFeaturesText, expectedAboveAverageQualityGradeFeaturesText, "General shape and style - above average quality grade features text - " + lobType);
                    break;

                case CUSTOM_QUALITY_GRADE:
                    expectedCustomQualityGradeFeaturesText = isSafariBrowser() ? expectedCustomQualityGradeFeaturesText_SAFARI : expectedCustomQualityGradeFeaturesText;
                    fsa.assertEquals(foundQualityGradeFeaturesText, expectedCustomQualityGradeFeaturesText, "General shape and style - custom quality grade features text - " + lobType);
                    break;

                case PREMIUM_QUALITY_GRADE:
                    expectedPremiumQualityGradeFeaturesText = isSafariBrowser() ? expectedPremiumQualityGradeFeaturesText_SAFARI : expectedPremiumQualityGradeFeaturesText;
                    fsa.assertEquals(foundQualityGradeFeaturesText, expectedPremiumQualityGradeFeaturesText, "General shape and style - premium quality grade features text - " + lobType);
                    break;
            }
        }
        clickOnGeneralShapeAndStyleEditButton();
    }

    public void validateExteriorFeaturesAndFinishedSection(FarmersSoftAssert fsa, AppStore.Home home, String lobType) throws Exception {
        fsa.assertEquals(getTextFromElement(exteriorFeaturesAndFinishesHeader), EXPECTED_EXTERIOR_FEATURES_AND_FINISHES_HEADER + ":", "Exterior features and finishes header matching - " + lobType);

        String expectedExteriorFeaturesAndFinishesQualityGrade = getHomeQualityGradeByHeader(home.getHomeQualityGradeForm(), EXPECTED_EXTERIOR_FEATURES_AND_FINISHES_HEADER);

        // if exterior features and finishes quality grade is empty
        if (expectedExteriorFeaturesAndFinishesQualityGrade.equals(EMPTY_QUALITY_GRADE)) {
            int numberOfRadios = Integer.parseInt(home.getPropertyForm().getFields().get(0).getSqFeet()) > 1500 ? 4 : 5;
            clickOnExteriorFeaturesAndFinishesEditButton();
            List<WebElement> uncheckedRadioButtons = uncheckedQualityGradeRadioButtons(exteriorFeaturesAndFinishesMatRadioButtons);
            fsa.assertEquals(uncheckedRadioButtons.size(), numberOfRadios, "Exterior features and finishes - One of the radio button is checked - " + lobType);

            String selectedRadioButtonText = randomlySelectExteriorFeaturesAndFinishesRadioButton();
            fsa.assertEquals(getTextFromElement(exteriorFeaturesAndFinishesQualityGrade), selectedRadioButtonText, "General shape and style - required radio button selected - " + lobType);
            fsa.assertEquals(getTextFromElement(exteriorFeaturesAndFinishesEditLinkButton), "Hide", "Exterior features and finishes edit link button text (Hide) matching - " + lobType);
        } else {
            expectedExteriorFeaturesAndFinishesQualityGrade = getHomeQualityGradeByHeader(home.getHomeQualityGradeForm(), EXPECTED_EXTERIOR_FEATURES_AND_FINISHES_HEADER);
            fsa.assertEquals(getTextFromElement(exteriorFeaturesAndFinishesQualityGrade), expectedExteriorFeaturesAndFinishesQualityGrade, "Expected general shape and style quality grade matching - " + lobType);

            fsa.assertEquals(getTextFromElement(exteriorFeaturesAndFinishesEditLinkButton), "Edit", "Exterior features and finishes edit link button text (Edit) matching - " + lobType);
            clickOnExteriorFeaturesAndFinishesEditButton();
            fsa.assertEquals(getTextFromElement(exteriorFeaturesAndFinishesEditLinkButton), "Hide", "Exterior features and finishes edit link button text (Hide) matching - " + lobType);

            if (lobType.equals(HOME)) {
                waitElementBeVisible(exteriorFeaturesAndFinishesHomeImages.get(0));
            }
            fsa.assertEquals(getTextFromElement(checkedExteriorFeaturesAndFinishedRadioButton), expectedExteriorFeaturesAndFinishesQualityGrade, "Exterior features and finishes quality grade selected in radio button - " + lobType);
        }

        List<String> foundExteriorFeaturesAndFinishesQualityGrades = exteriorFeaturesAndFinishesMatRadioButtons.stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(foundExteriorFeaturesAndFinishesQualityGrades, getExpectedQualityGrades(), "Exterior features and finishes radio button text are not matching - " + lobType);
        int numberOfRadioButtons = exteriorFeaturesAndFinishesRadioButtons.size();
        for (int i = 0; i < numberOfRadioButtons; i++) {
            clickOnHiddenElement(exteriorFeaturesAndFinishesRadioButtons.get(i));
            if (lobType.equals(HOME)) {
                fsa.assertEquals(exteriorFeaturesAndFinishesHomeImages.size(), 3,
                		"Exterior features and finishes images size matching for " + getTextFromElement(exteriorFeaturesAndFinishesMatRadioButtons.get(i)) + " - " + lobType);
            }
            String expectedEconomyQualityGradeFeaturesText = "Typical Economy finishes/features: Economy roof material, such as 3-tab shingle Economy siding materials, such as vinyl, aluminum, metal, hardboard, or Masonite Minimal or no architectural details";
            String expectedEconomyQualityGradeFeaturesText_SAFARI = "Typical Economy finishes/features:Economy roof material, such as 3-tab shingleEconomy siding materials, such as vinyl, aluminum, metal, hardboard, or MasoniteMinimal or no architectural details";
            String expectedStandardQualityGradeFeaturesText = "Typical Standard finishes/features: Medium-grade roof material, such as 3-tab shingle or architectural shingle Medium-grade siding materials, such as vinyl, aluminum, metal, hardboard, Masonite, pine, cement fiber, or stucco Minimal or no architectural details";
            String expectedStandardQualityGradeFeaturesText_SAFARI = "Typical Standard finishes/features:Medium-grade roof material, such as 3-tab shingle or architectural shingleMedium-grade siding materials, such as vinyl, aluminum, metal, hardboard, Masonite, pine, cement fiber, or stuccoMinimal or no architectural details";
            String expectedAboveAverageQualityGradeFeaturesText = "Typical Above Average finishes/features: High-grade roof material, such as architectural shingle, tile, metal or concrete High-grade siding or masonry materials, such as vinyl, pine, cedar, stucco, cement fiber, brick veneer, or manufactured stone veneer Bay, round, or transom window(s), and/or double or French doors Wood or fiberglass columns, some decorative molding, or ornate handrails on porch";
            String expectedAboveAverageQualityGradeFeaturesText_SAFARI = "Typical Above Average finishes/features:High-grade roof material, such as architectural shingle, tile, metal or concreteHigh-grade siding or masonry materials, such as vinyl, pine, cedar, stucco, cement fiber, brick veneer, or manufactured stone veneerBay, round, or transom window(s), and/or double or French doorsWood or fiberglass columns, some decorative molding, or ornate handrails on porch";
            String expectedCustomQualityGradeFeaturesText = "Select \"Custom\" if the home has a combination of \"Above Average\" and \"Premium\" features. Typical Custom finishes/features: High-grade roof material, such as architectural shingle, tile, metal, or concrete High-grade siding or masonry materials, such as high-grade vinyl, pine, cedar, stucco, cement fiber, brick or manufactured stone Some unique windows (extra-large picture windows, hexagon-shaped windows, etc.), 8 high or arched top exterior door(s) Fiberglass or brick columns, ornate handrails on porch, and/or decorative crown molding/trim";
            String expectedCustomQualityGradeFeaturesText_SAFARI = "Select \"Custom\" if the home has a combination of \"Above Average\" and \"Premium\" features. Typical Custom finishes/features:High-grade roof material, such as architectural shingle, tile, metal, or concreteHigh-grade siding or masonry materials, such as high-grade vinyl, pine, cedar, stucco, cement fiber, brick or manufactured stoneSome unique windows (extra-large picture windows, hexagon-shaped windows, etc.), 8 high or arched top exterior door(s)Fiberglass or brick columns, ornate handrails on porch, and/or decorative crown molding/trim";
            String expectedPremiumQualityGradeFeaturesText = "Typical Premium finishes/features: High-grade roof material, such as architectural shingle, tile, metal or concrete High-grade siding, such as top-quality vinyl, pine, cedar, stucco, cement fiber, brick, manufactured stone, or natural stone Several unique windows (extra-large picture windows, hexagon shaped windows, etc.), some 8-foot high or arched-top exterior doors Decorative cornerstones/keystones; fiberglass, brick, or marble columns; ornate handrails on porch; and/or prominent decorative crown molding/trim";
            String expectedPremiumQualityGradeFeaturesText_SAFARI = "Typical Premium finishes/features:High-grade roof material, such as architectural shingle, tile, metal or concreteHigh-grade siding, such as top-quality vinyl, pine, cedar, stucco, cement fiber, brick, manufactured stone, or natural stoneSeveral unique windows (extra-large picture windows, hexagon shaped windows, etc.), some 8-foot high or arched-top exterior doorsDecorative cornerstones/keystones; fiberglass, brick, or marble columns; ornate handrails on porch; and/or prominent decorative crown molding/trim";

            String foundQualityGradeFeaturesText = getTextFromElement(exteriorFeaturesAndFinishesQualityGradeFeatures);

            switch (getTextFromElement(exteriorFeaturesAndFinishesRadioButtons.get(i))) {
                case ECONOMY_QUALITY_GRADE:
                    expectedEconomyQualityGradeFeaturesText = isSafariBrowser() ? expectedEconomyQualityGradeFeaturesText_SAFARI : expectedEconomyQualityGradeFeaturesText;
                    fsa.assertEquals(foundQualityGradeFeaturesText, expectedEconomyQualityGradeFeaturesText, "Exterior features and finishes - Economy quality grade features text matching - " + lobType);
                    break;

                case STANDARD_QUALITY_GRADE:
                    expectedStandardQualityGradeFeaturesText = isSafariBrowser() ? expectedStandardQualityGradeFeaturesText_SAFARI : expectedStandardQualityGradeFeaturesText;
                    fsa.assertEquals(foundQualityGradeFeaturesText, expectedStandardQualityGradeFeaturesText, "Exterior features and finishes - standard quality grade features text matching - " + lobType);
                    break;

                case ABOVE_AVERAGE_QUALITY_GRADE:
                    expectedAboveAverageQualityGradeFeaturesText = isSafariBrowser() ? expectedAboveAverageQualityGradeFeaturesText_SAFARI : expectedAboveAverageQualityGradeFeaturesText;
                    fsa.assertEquals(foundQualityGradeFeaturesText, expectedAboveAverageQualityGradeFeaturesText, "Exterior features and finishes - above average quality grade features text matching - " + lobType);
                    break;

                case CUSTOM_QUALITY_GRADE:
                    expectedCustomQualityGradeFeaturesText = isSafariBrowser() ? expectedCustomQualityGradeFeaturesText_SAFARI : expectedCustomQualityGradeFeaturesText;
                    fsa.assertEquals(foundQualityGradeFeaturesText, expectedCustomQualityGradeFeaturesText, "Exterior features and finishes - custom quality grade features text matching - " + lobType);
                    break;

                case PREMIUM_QUALITY_GRADE:
                    expectedPremiumQualityGradeFeaturesText = isSafariBrowser() ? expectedPremiumQualityGradeFeaturesText_SAFARI : expectedPremiumQualityGradeFeaturesText;
                    fsa.assertEquals(foundQualityGradeFeaturesText, expectedPremiumQualityGradeFeaturesText, "Exterior features and finishes - premium quality grade features text matching - " + lobType);
                    break;
            }
        }
        clickOnExteriorFeaturesAndFinishesEditButton();
    }

    public void validateInteriorFeaturesAndFinishedSection(FarmersSoftAssert sa, AppStore.Home home, String lobType) throws Exception {
        sa.assertEquals(getTextFromElement(interiorFeaturesAndFinishesHeader), EXPECTED_INTERIOR_FEATURES_AND_FINISHES_HEADER + ":", "Interior features and finishes header matching - " + lobType);

        String expectedInteriorFeaturesAndFinishesQualityGrade = getHomeQualityGradeByHeader(home.getHomeQualityGradeForm(), EXPECTED_INTERIOR_FEATURES_AND_FINISHES_HEADER);

        // if interior features and finishes quality grade is empty
        if (expectedInteriorFeaturesAndFinishesQualityGrade.equals(EMPTY_QUALITY_GRADE)) {
            int numberOfRadios = Integer.parseInt(home.getPropertyForm().getFields().get(0).getSqFeet()) > 1500 ? 4 : 5;
            clickOnInteriorFeaturesAndFinishesEditButton();
            List<WebElement> uncheckedRadioButtons = uncheckedQualityGradeRadioButtons(interiorFeaturesAndFinishesMatRadioButtons);
            sa.assertEquals(uncheckedRadioButtons.size(), numberOfRadios, "Interior features and finishes - One of the radio button is checked - " + lobType);

            String selectedRadioButtonText = randomlySelectInteriorFeaturesAndFinishesRadioButton();
            sa.assertEquals(getTextFromElement(interiorFeaturesAndFinishesQualityGrade), selectedRadioButtonText, "Interior features and finishes - required radio button selected - " + lobType);
            sa.assertEquals(getTextFromElement(interiorFeaturesAndFinishesEditLinkButton), "Hide", "Interior features and finishes edit link button text (Hide) matching - " + lobType);
        } else {

            expectedInteriorFeaturesAndFinishesQualityGrade = getHomeQualityGradeByHeader(home.getHomeQualityGradeForm(), EXPECTED_INTERIOR_FEATURES_AND_FINISHES_HEADER);
            sa.assertEquals(getTextFromElement(interiorFeaturesAndFinishesQualityGrade), expectedInteriorFeaturesAndFinishesQualityGrade, "Expected interior features and finishes quality grade matching - " + lobType);

            sa.assertEquals(getTextFromElement(interiorFeaturesAndFinishesEditLinkButton), "Edit", "Interior features and finishes edit link button text (Edit) matching - " + lobType);
            clickOnInteriorFeaturesAndFinishesEditButton();
            sa.assertEquals(getTextFromElement(interiorFeaturesAndFinishesEditLinkButton), "Hide", "Interior features and finishes edit link button text (Hide) matching - " + lobType);

            waitElementBeVisible(interiorFeaturesAndFinishesImages.get(0));

            sa.assertEquals(getTextFromElement(checkedInteriorFeaturesAndFinishedRadioButton), expectedInteriorFeaturesAndFinishesQualityGrade, "Interior features and finishes quality grade selected in radio button - " + lobType);
        }

        List<String> foundInteriorFeaturesAndFinishesQualityGrades = interiorFeaturesAndFinishesMatRadioButtons.stream().map(this::getTextFromElement).collect(Collectors.toList());
        sa.assertEquals(foundInteriorFeaturesAndFinishesQualityGrades, getExpectedQualityGrades(), "Interior features and finishes radio button text are not matching - " + lobType);
        int numberOfRadioButtons = interiorFeaturesAndFinishesRadioButtons.size();
        for (int i = 0; i < numberOfRadioButtons; i++) {
            clickOnHiddenElement(interiorFeaturesAndFinishesRadioButtons.get(i));
            sa.assertEquals(interiorFeaturesAndFinishesImages.size(), 3,
            		"Interior features and finishes images size matching for " + getTextFromElement(interiorFeaturesAndFinishesMatRadioButtons.get(i)) + " - " + lobType);

            String expectedEconomyQualityGradeFeaturesText = "Typical Economy finishes/features: Minimal molding 8-foot high ceilings Paint/inexpensive wallpaper Hollow-core, flat-panel doors Low-grade carpet/sheet vinyl flooring";
            String expectedEconomyQualityGradeFeaturesText_SAFARI = "Typical Economy finishes/features:Minimal molding 8-foot high ceilingsPaint/inexpensive wallpaperHollow-core, flat-panel doorsLow-grade carpet/sheet vinyl flooring";
            String expectedStandardQualityGradeFeaturesText = "Typical Standard finishes/features: Crown molding/chair railing in 1 or 2 rooms Vaulted ceilings in some areas Paint, medium-grade wallpaper, and/or some natural wood paneling Hollow-core, raised-panel/painted doors Medium-grade flooring, such as carpet with some sheet vinyl, ceramic tile, hardwood, or laminate";
            String expectedStandardQualityGradeFeaturesText_SAFARI = "Typical Standard finishes/features:Crown molding/chair railing in 1 or 2 rooms Vaulted ceilings in some areasPaint, medium-grade wallpaper, and/or some natural wood paneling Hollow-core, raised-panel/painted doorsMedium-grade flooring, such as carpet with some sheet vinyl, ceramic tile, hardwood, or laminate";
            String expectedAboveAverageQualityGradeFeaturesText = "Typical Above Average finishes/features: Crown molding/chair railing in several rooms Vaulted/tray ceilings in several areas, may have exposed structural/decorative wood beams in some areas Paint, high-grade wallpaper, and/or natural wood paneling Hollow-core, raised-panel/stained wood doors High-grade flooring, such as top-quality carpet, with some sheet vinyl, ceramic tile, hardwood, laminate, or marble/granite/travertine Built-in features, such as bookcases or a wet-bar";
            String expectedAboveAverageQualityGradeFeaturesText_SAFARI = "Typical Above Average finishes/features:Crown molding/chair railing in several roomsVaulted/tray ceilings in several areas, may have exposed structural/decorative wood beams in some areasPaint, high-grade wallpaper, and/or natural wood panelingHollow-core, raised-panel/stained wood doorsHigh-grade flooring, such as top-quality carpet, with some sheet vinyl, ceramic tile, hardwood, laminate, or marble/granite/travertineBuilt-in features, such as bookcases or a wet-bar";
            String expectedCustomQualityGradeFeaturesText = "Typical Custom finishes/features: Crown molding/chair railing in several rooms Vaulted/tray ceilings in several areas, may have exposed structural/decorative wood beams in some areas Paint, high-grade wallpaper or natural wood paneling, tile, and/or brick Hollow-core, raised-panel/stained wood, French or 8-foot high interior doors High-grade floor covering, such as top-quality carpet, sheet vinyl/ceramic tile, hardwood, laminate, or marble/granite/travertine Built-ins, such as bookcases or a wet-bar, an ornate staircase, ornate chandeliers, hanging lights, or recessed lights";
            String expectedCustomQualityGradeFeaturesText_SAFARI = "Typical Custom finishes/features:Crown molding/chair railing in several roomsVaulted/tray ceilings in several areas, may have exposed structural/decorative wood beams in some areasPaint, high-grade wallpaper or natural wood paneling, tile, and/or brickHollow-core, raised-panel/stained wood, French or 8-foot high interior doorsHigh-grade floor covering, such as top-quality carpet, sheet vinyl/ceramic tile, hardwood, laminate, or marble/granite/travertineBuilt-ins, such as bookcases or a wet-bar, an ornate staircase, ornate chandeliers, hanging lights, or recessed lights";
            String expectedPremiumQualityGradeFeaturesText = "Typical Premium finishes/features: Oversized crown molding/chair railing in several rooms Vaulted/tray ceilings in several areas, with 9- to 12-foot ceilings throughout; may have exposed structural/decorative wood beams Line 3 Paint, high-grade wallpaper, natural wood paneling, tile, brick, and/or marble, hand painted murals or wall designs Solid-core hardwood/ornate doors, French doors, 8-foot high doors, and/or arched-top doors High-grade floor covering, such as wool carpet with ceramic tile, top-quality hardwood, or marble/granite/travertine Columns and built-ins, such as bookcases or a wet-bar, curved/ornate staircase(s), ornate or crystal chandeliers, hanging lights, or recessed light";
            String expectedPremiumQualityGradeFeaturesText_SAFARI = "Typical Premium finishes/features:Oversized crown molding/chair railing in several roomsVaulted/tray ceilings in several areas, with 9- to 12-foot ceilings throughout; may have exposed structural/decorative wood beams Line 3 Paint, high-grade wallpaper, natural wood paneling, tile, brick, and/or marble, hand painted murals or wall designsSolid-core hardwood/ornate doors, French doors, 8-foot high doors, and/or arched-top doorsHigh-grade floor covering, such as wool carpet with ceramic tile, top-quality hardwood, or marble/granite/travertineColumns and built-ins, such as bookcases or a wet-bar, curved/ornate staircase(s), ornate or crystal chandeliers, hanging lights, or recessed light";

            String foundQualityGradeFeaturesText = getTextFromElement(interiorFeaturesAndFinishesQualityGradeFeatures);

            switch (getTextFromElement(interiorFeaturesAndFinishesRadioButtons.get(i))) {
                case ECONOMY_QUALITY_GRADE:
                    expectedEconomyQualityGradeFeaturesText = isSafariBrowser() ? expectedEconomyQualityGradeFeaturesText_SAFARI : expectedEconomyQualityGradeFeaturesText;
                    sa.assertEquals(foundQualityGradeFeaturesText, expectedEconomyQualityGradeFeaturesText, "Interior features and finishes - Economy quality grade features text matching - " + lobType);
                    break;

                case STANDARD_QUALITY_GRADE:
                    expectedStandardQualityGradeFeaturesText = isSafariBrowser() ? expectedStandardQualityGradeFeaturesText_SAFARI : expectedStandardQualityGradeFeaturesText;
                    sa.assertEquals(foundQualityGradeFeaturesText, expectedStandardQualityGradeFeaturesText, "Interior features and finishes - standard quality grade features text matching - " + lobType);
                    break;

                case ABOVE_AVERAGE_QUALITY_GRADE:
                    expectedAboveAverageQualityGradeFeaturesText = isSafariBrowser() ? expectedAboveAverageQualityGradeFeaturesText_SAFARI : expectedAboveAverageQualityGradeFeaturesText;
                    sa.assertEquals(foundQualityGradeFeaturesText, expectedAboveAverageQualityGradeFeaturesText, "Interior features and finishes - above average quality grade features text matching - " + lobType);
                    break;

                case CUSTOM_QUALITY_GRADE:
                    expectedCustomQualityGradeFeaturesText = isSafariBrowser() ? expectedCustomQualityGradeFeaturesText_SAFARI : expectedCustomQualityGradeFeaturesText;
                    sa.assertEquals(foundQualityGradeFeaturesText, expectedCustomQualityGradeFeaturesText, "Interior features and finishes - custom quality grade features text matching - " + lobType);
                    break;

                case PREMIUM_QUALITY_GRADE:
                    expectedPremiumQualityGradeFeaturesText = isSafariBrowser() ? expectedPremiumQualityGradeFeaturesText_SAFARI : expectedPremiumQualityGradeFeaturesText;
                    sa.assertEquals(foundQualityGradeFeaturesText, expectedPremiumQualityGradeFeaturesText, "Interior features and finishes - premium quality grade features text matching - " + lobType);
                    break;
            }
        }
        clickOnInteriorFeaturesAndFinishesEditButton();
    }

    public void validateCabinetsAndCounterTopsSection(FarmersSoftAssert sa, AppStore.Home home, String lobType) throws Exception {
        sa.assertEquals(getTextFromElement(cabinetsAndCounterTopsHeader), EXPECTED_CABINETS_AND_COUNTERTOPS_HEADER + ":", "Cabinets and countertops header matching - " + lobType);

        String expectedCabinetsAndCountertopsQualityGrade = getHomeQualityGradeByHeader(home.getHomeQualityGradeForm(), EXPECTED_CABINETS_AND_COUNTERTOPS_HEADER);

        // if cabinets and counter tops quality grade is empty
        if (expectedCabinetsAndCountertopsQualityGrade.equals(EMPTY_QUALITY_GRADE)) {
            int numberOfRadios = Integer.parseInt(home.getPropertyForm().getFields().get(0).getSqFeet()) > 1500 ? 4 : 5;
            clickOnCabinetsCounterTopsEditButton();
            List<WebElement> uncheckedRadioButtons = uncheckedQualityGradeRadioButtons(cabinetsAndCounterTopsMatRadioButtons);
            sa.assertEquals(uncheckedRadioButtons.size(), numberOfRadios, "Cabinets and counter tops - One of the radio button is checked - " + lobType);

            String selectedRadioButtonText = randomlySelectCabinetsAndCounterTopsRadioButton();
            sa.assertEquals(getTextFromElement(cabinetsAndCounterTopsQualityGrade), selectedRadioButtonText, "Cabinets and counter tops - required radio button selected - " + lobType);
            sa.assertEquals(getTextFromElement(cabinetsAndCounterTopsEditLinkButton), "Hide", "Cabinets and counter tops edit link button text (Hide) matching - " + lobType);
        } else {
            expectedCabinetsAndCountertopsQualityGrade = getHomeQualityGradeByHeader(home.getHomeQualityGradeForm(), EXPECTED_CABINETS_AND_COUNTERTOPS_HEADER);

            sa.assertEquals(getTextFromElement(cabinetsAndCounterTopsQualityGrade), expectedCabinetsAndCountertopsQualityGrade, "Expected cabinets and countertops quality grade matching - " + lobType);

            sa.assertEquals(getTextFromElement(cabinetsAndCounterTopsEditLinkButton), "Edit", "Cabinets and countertops edit link button text (Edit) matching - " + lobType);
            clickOnCabinetsCounterTopsEditButton();
            sa.assertEquals(getTextFromElement(cabinetsAndCounterTopsEditLinkButton), "Hide", "Cabinets and countertops edit link button text (Hide) matching - " + lobType);

            waitElementBeVisible(cabinetsAndCounterTopsHomeImages.get(0));

            sa.assertEquals(getTextFromElement(checkedCabinetsAndCountertopsRadioButton), expectedCabinetsAndCountertopsQualityGrade, "Cabinets and countertops quality grade selected in radio button - " + lobType);


        }

        List<String> foundCabinetsAndCountertopsQualityGrades = cabinetsAndCounterTopsMatRadioButtons.stream().map(this::getTextFromElement).collect(Collectors.toList());
        sa.assertEquals(foundCabinetsAndCountertopsQualityGrades, getExpectedQualityGrades(), "Cabinets and countertops radio button text are not matching - " + lobType);
        int numberOfRadioButtons = cabinetsAndCounterTopsRadioButtons.size();
        for (int i = 0; i < numberOfRadioButtons; i++) {
            clickOnHiddenElement(cabinetsAndCounterTopsRadioButtons.get(i));
            sa.assertEquals(cabinetsAndCounterTopsHomeImages.size(), 3,
            		"Cabinets and countertops images size matching for " + getTextFromElement(cabinetsAndCounterTopsMatRadioButtons.get(i)) + " - " + lobType);
            String expectedEconomyQualityGradeFeaturesText = "Typical Economy cabinet/countertop features: Pre-fabricated, modular box-style, particleboard cabinets Standard flat-panel cabinet doors Laminate countertops/li>";
            String expectedEconomyQualityGradeFeaturesText_SAFARI = "Typical Economy cabinet/countertop features:Pre-fabricated, modular box-style, particleboard cabinetsStandard flat-panel cabinet doorsLaminate countertops/li>";
            String expectedStandardQualityGradeFeaturesText = "Typical Standard cabinet/countertop features: Solid pine/other softwood material or pre-fabricated, modular box-style, particleboard cabinets with hardwood frames Hardwood cabinet door fronts with a flat, recessed panel Laminate countertops, may have hardwood edging, low-grade solid surface material, or natural marble/granite tile countertops";
            String expectedStandardQualityGradeFeaturesText_SAFARI = "Typical Standard cabinet/countertop features:Solid pine/other softwood material or pre-fabricated, modular box-style, particleboard cabinets with hardwood framesHardwood cabinet door fronts with a flat, recessed panelLaminate countertops, may have hardwood edging, low-grade solid surface material, or natural marble/granite tile countertops";
            String expectedAboveAverageQualityGradeFeaturesText = "Typical Above Average cabinet/countertop features: Solid pine/other softwood material or pre-fabricated, modular box-style, particleboard cabinets with hardwood frames Hardwood raised-panel cabinet door fronts, may have cathedral-style/glass panes High-grade laminate with hardwood edging, medium-grade solid surface material, or domestic solid natural marble/granite countertops";
            String expectedAboveAverageQualityGradeFeaturesText_SAFARI = "Typical Above Average cabinet/countertop features:Solid pine/other softwood material or pre-fabricated, modular box-style, particleboard cabinets with hardwood framesHardwood raised-panel cabinet door fronts, may have cathedral-style/glass panesHigh-grade laminate with hardwood edging, medium-grade solid surface material, or domestic solid natural marble/granite countertops";
            String expectedCustomQualityGradeFeaturesText = "Select \"Custom\" if the home has a combination of \"Above Average\" and \"Premium\" features. Typical Custom cabinet/countertop features: Solid hardwood or pre-fabricated, modular box-style cabinets Hardwood raised-panel cabinet door fronts, may have cathedral-style/leaded/beveled glass panesHigh-grade solid surface material, domestic solid natural granite/marble, quartz, or solid wood butcher block countertops Special features like slide out lower cabinet shelves, concealed hinges, soft or self-close hinges or drawer slides";
            String expectedCustomQualityGradeFeaturesText_SAFARI = "Select \"Custom\" if the home has a combination of \"Above Average\" and \"Premium\" features. Typical Custom cabinet/countertop features:Solid hardwood or pre-fabricated, modular box-style cabinetsHardwood raised-panel cabinet door fronts, may have cathedral-style/leaded/beveled glass panesHigh-grade solid surface material, domestic solid natural granite/marble, quartz, or solid wood butcher block countertopsSpecial features like slide out lower cabinet shelves, concealed hinges, soft or self-close hinges or drawer slides";
            String expectedPremiumQualityGradeFeaturesText = "Typical Premium cabinet/countertop features: Solid hardwood or pre-fabricated, modular box-style cabinets Hardwood raised-panel cabinet door fronts, may have cathedral-style or leaded/beveled glass panes Highest grade imported solid natural granite/marble or quartz, concrete countertops with decorative edging, or stainless steel countertops Built-in or commercial grade appliances Plywood box construction with unique design features, solid wood face frames and soft or self-close hinges, drawer slides, etc. Built-in spice racks, pantry doors or custom valances";
            String expectedPremiumQualityGradeFeaturesText_SAFARI = "Typical Premium cabinet/countertop features:Solid hardwood or pre-fabricated, modular box-style cabinetsHardwood raised-panel cabinet door fronts, may have cathedral-style or leaded/beveled glass panes Highest grade imported solid natural granite/marble or quartz, concrete countertops with decorative edging, or stainless steel countertopsBuilt-in or commercial grade appliances Plywood box construction with unique design features, solid wood face frames and soft or self-close hinges, drawer slides, etc.Built-in spice racks, pantry doors or custom valances";

            String foundQualityGradeFeaturesText = getTextFromElement(cabinetsAndCountertopsQualityGradeFeatures);

            switch (getTextFromElement(cabinetsAndCounterTopsRadioButtons.get(i))) {
                case ECONOMY_QUALITY_GRADE:
                    expectedEconomyQualityGradeFeaturesText = isSafariBrowser() ? expectedEconomyQualityGradeFeaturesText_SAFARI : expectedEconomyQualityGradeFeaturesText;
                    sa.assertEquals(foundQualityGradeFeaturesText, expectedEconomyQualityGradeFeaturesText, "Cabinets and countertops - Economy quality grade features text matching - " + lobType);
                    break;

                case STANDARD_QUALITY_GRADE:
                    expectedStandardQualityGradeFeaturesText = isSafariBrowser() ? expectedStandardQualityGradeFeaturesText_SAFARI : expectedStandardQualityGradeFeaturesText;
                    sa.assertEquals(foundQualityGradeFeaturesText, expectedStandardQualityGradeFeaturesText, "Cabinets and countertops - standard quality grade features text matching - " + lobType);
                    break;

                case ABOVE_AVERAGE_QUALITY_GRADE:
                    expectedAboveAverageQualityGradeFeaturesText = isSafariBrowser() ? expectedAboveAverageQualityGradeFeaturesText_SAFARI : expectedAboveAverageQualityGradeFeaturesText;
                    sa.assertEquals(foundQualityGradeFeaturesText, expectedAboveAverageQualityGradeFeaturesText, "Cabinets and countertops - above average quality grade features text matching - " + lobType);
                    break;

                case CUSTOM_QUALITY_GRADE:
                    expectedCustomQualityGradeFeaturesText = isSafariBrowser() ? expectedCustomQualityGradeFeaturesText_SAFARI : expectedCustomQualityGradeFeaturesText;
                    sa.assertEquals(foundQualityGradeFeaturesText, expectedCustomQualityGradeFeaturesText, "Cabinets and countertops - custom quality grade features text matching - " + lobType);
                    break;

                case PREMIUM_QUALITY_GRADE:
                    expectedPremiumQualityGradeFeaturesText = isSafariBrowser() ? expectedPremiumQualityGradeFeaturesText_SAFARI : expectedPremiumQualityGradeFeaturesText;
                    sa.assertEquals(foundQualityGradeFeaturesText, expectedPremiumQualityGradeFeaturesText, "Cabinets and countertops - premium quality grade features text matching - " + lobType);
                    break;
            }
        }
        clickOnCabinetsCounterTopsEditButton();
    }


    public void validateWhyIsThisImportantQuestionSectionValidation(FarmersSoftAssert sa, String lobType) {
        sa.assertTrue(isElementDisplayed(lightBulbIcon, 5), "Light bulb icon displayed - " + lobType);

        final String EXPECTED_WHY_IS_THIS_IMPORTANT_QUESTION_TEXT = "Why is this important?";
        sa.assertEquals(getTextFromElement(whyIsThisImportantQuestion), EXPECTED_WHY_IS_THIS_IMPORTANT_QUESTION_TEXT, "Why is this important question text matching - " + lobType);

        final String EXPECTED_WHY_IS_THIS_IMPORTANT_QUESTION_DESCRIPTION_TEXT = "The quality grade of the features and finishes of your home help estimate the cost to rebuild it in the event of a total loss.";
        sa.assertEquals(getTextFromElement(disclaimerText), EXPECTED_WHY_IS_THIS_IMPORTANT_QUESTION_DESCRIPTION_TEXT, "Why is this important question description text matching - " + lobType);
    }

    public List<String> getExpectedQualityGrades() throws Exception {
        List<String> qualityGrades = new ArrayList<>(EXPECTED_QUALITY_GRADE_RADIO_BUTTON_TEXT);
        int sqFeet = Integer.parseInt(getSessionStorageAppStore().getHome().getPropertyForm().getFields().get(0).getSqFeet());
        if (sqFeet > 1500) {
            qualityGrades.remove(ECONOMY_QUALITY_GRADE);
        }
        return qualityGrades;
    }

    public String getFeatureDescription(String feature) {
        String featureText = "";
        switch (feature) {
            case EXPECTED_GENERAL_SHAPE_AND_STYLE_HEADER:
                featureText = getTextFromElement(generalShapeAndStyleDescription);
                break;
            case EXPECTED_EXTERIOR_FEATURES_AND_FINISHES_HEADER:
                featureText = getTextFromElement(exteriorFeaturesAndFinishesDescription);
                break;
            case EXPECTED_INTERIOR_FEATURES_AND_FINISHES_HEADER:
                featureText = getTextFromElement(interiorFeaturesAndFinishesDescription);
                break;
            case EXPECTED_CABINETS_AND_COUNTERTOPS_HEADER:
                featureText = getTextFromElement(cabinetsAndCountertopsDescription);
                break;
            default:
                Log.error("Unexpected quality grade feature: " + feature);
        }
        return featureText;
    }

    public void verifyDisplayedFeatures(FarmersSoftAssert sa, ApplicantAceHome applicant) throws Exception {
        HomeQualityGradeForm qualityGradeForm = getSessionStorageAppStore().getHome().getHomeQualityGradeForm();
        if (!applicant.isKeep360Prefill()) {
            sa.assertEquals(getFeatureDescription(EXPECTED_GENERAL_SHAPE_AND_STYLE_HEADER), applicant.getGeneralShapeAndStyleQualityGrade(),
                    "Quality grade page - General Shape & Style match with applicant data.");
            sa.assertEquals(getFeatureDescription(EXPECTED_EXTERIOR_FEATURES_AND_FINISHES_HEADER), applicant.getExteriorShapeAndStyleQualityGrade(),
                    "Quality grade page - Exterior Features & Finishes match with applicant data.");
            sa.assertEquals(getFeatureDescription(EXPECTED_INTERIOR_FEATURES_AND_FINISHES_HEADER), applicant.getInteriorShapeAndStyleQualityGrade(),
                    "Quality grade page - Interior Features & Finishes match with applicant data.");
            sa.assertEquals(getFeatureDescription(EXPECTED_CABINETS_AND_COUNTERTOPS_HEADER), applicant.getCabinetsAndCounterTopsQualityGrade(),
                    "Quality grade page - Cabinets & Countertops match with applicant data.");
        } else {
            sa.assertEquals(getFeatureDescription(EXPECTED_GENERAL_SHAPE_AND_STYLE_HEADER), getHomeQualityGradeByHeader(qualityGradeForm,
                    EXPECTED_GENERAL_SHAPE_AND_STYLE_HEADER), "Quality grade page - General Shape & Style match with appStore.");
            sa.assertEquals(getFeatureDescription(EXPECTED_EXTERIOR_FEATURES_AND_FINISHES_HEADER), getHomeQualityGradeByHeader(qualityGradeForm,
                    EXPECTED_EXTERIOR_FEATURES_AND_FINISHES_HEADER), "Quality grade page - Exterior Features & Finishes match with appStore.");
            sa.assertEquals(getFeatureDescription(EXPECTED_INTERIOR_FEATURES_AND_FINISHES_HEADER), getHomeQualityGradeByHeader(qualityGradeForm,
                    EXPECTED_INTERIOR_FEATURES_AND_FINISHES_HEADER), "Quality grade page - Interior Features & Finishes match with appStore.");
            sa.assertEquals(getFeatureDescription(EXPECTED_CABINETS_AND_COUNTERTOPS_HEADER), getHomeQualityGradeByHeader(qualityGradeForm,
                    EXPECTED_CABINETS_AND_COUNTERTOPS_HEADER), "Quality grade page - Cabinets & Countertops match with appStore.");
        }
    }

    public String getHomeQualityGradeByHeader(AppStore.Home.HomeQualityGradeForm homeQualityGradeForm, String headerName) {
        return homeQualityGradeForm.getFields().get(0).getValues().stream().filter(i -> i.getDescription().equals(headerName)).collect(Collectors.toList()).get(0).getWebDesc();
    }

    public String randomlySelectGeneralShapeAndStyleRadioButton() throws Exception {
        Random random = new Random();
        int index = random.nextInt(generalShapeAndStyleRadioButtons.size());
        clickOnHiddenElement(generalShapeAndStyleRadioButtons.get(index));
        return getTextFromElement(generalShapeAndStyleMatRadioButtons.get(index));
    }

    public String randomlySelectExteriorFeaturesAndFinishesRadioButton() throws Exception {
        Random random = new Random();
        int index = random.nextInt(exteriorFeaturesAndFinishesRadioButtons.size());
        clickOnHiddenElement(exteriorFeaturesAndFinishesRadioButtons.get(index));
        return getTextFromElement(exteriorFeaturesAndFinishesMatRadioButtons.get(index));
    }

    public String randomlySelectInteriorFeaturesAndFinishesRadioButton() throws Exception {
        Random random = new Random();
        int index = random.nextInt(interiorFeaturesAndFinishesRadioButtons.size());
        clickOnHiddenElement(interiorFeaturesAndFinishesRadioButtons.get(index));
        return getTextFromElement(interiorFeaturesAndFinishesMatRadioButtons.get(index));
    }

    public String randomlySelectCabinetsAndCounterTopsRadioButton() throws Exception {
        Random random = new Random();
        int index = random.nextInt(cabinetsAndCounterTopsRadioButtons.size());
        clickOnHiddenElement(cabinetsAndCounterTopsRadioButtons.get(index));
        return getTextFromElement(cabinetsAndCounterTopsMatRadioButtons.get(index));
    }

    public List<WebElement> uncheckedQualityGradeRadioButtons(List<WebElement> radioButtonsWebElement) {
        return radioButtonsWebElement.stream().filter(i -> !(getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED))).collect(Collectors.toList());
    }

    public List<String> getRadioButtonDescriptionsFromWebElements(List<WebElement> radioButtonWebElements) {
        return radioButtonWebElements.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public void fillOutQualityGradePage(ApplicantAceHome applicant, HomeQualityGradeForm homeQualityGradeForm) throws Exception {
        final String NOT_SELECTED = "--";
        String expectedGeneralShapeAndStyleQualityGrade = getHomeQualityGradeByHeader(homeQualityGradeForm, EXPECTED_GENERAL_SHAPE_AND_STYLE_HEADER);
        String expectedExteriorFeaturesAndFinishesQualityGrade = getHomeQualityGradeByHeader(homeQualityGradeForm, EXPECTED_EXTERIOR_FEATURES_AND_FINISHES_HEADER);
        String expectedInteriorFeaturesAndFinishesQualityGrade = getHomeQualityGradeByHeader(homeQualityGradeForm, EXPECTED_INTERIOR_FEATURES_AND_FINISHES_HEADER);
        String expectedCounterAndCabinetsQualityGrade = getHomeQualityGradeByHeader(homeQualityGradeForm, EXPECTED_CABINETS_AND_COUNTERTOPS_HEADER);
        if (!applicant.isKeep360Prefill() ||
                expectedGeneralShapeAndStyleQualityGrade.equals(NOT_SELECTED) ||
                expectedExteriorFeaturesAndFinishesQualityGrade.equals(NOT_SELECTED) ||
                expectedInteriorFeaturesAndFinishesQualityGrade.equals(NOT_SELECTED) ||
                expectedCounterAndCabinetsQualityGrade.equals(NOT_SELECTED)) {
            if (!expectedGeneralShapeAndStyleQualityGrade.equals(applicant.getGeneralShapeAndStyleQualityGrade()) || expectedGeneralShapeAndStyleQualityGrade.equals(NOT_SELECTED)) {
                clickOnGeneralShapeAndStyleEditButton();
                int indexToSelectRadioButton = getRadioButtonDescriptionsFromWebElements(generalShapeAndStyleMatRadioButtons).indexOf(applicant.getGeneralShapeAndStyleQualityGrade());
                if (indexToSelectRadioButton < 0) {
                    indexToSelectRadioButton = 0;
                    applicant.setGeneralShapeAndStyleQualityGrade(getTextFromElement(generalShapeAndStyleMatRadioButtons.get(indexToSelectRadioButton)));
                }
                clickOnHiddenElement(generalShapeAndStyleRadioButtons.get(indexToSelectRadioButton));
            }
            if (!expectedExteriorFeaturesAndFinishesQualityGrade.equals(applicant.getExteriorShapeAndStyleQualityGrade()) || expectedExteriorFeaturesAndFinishesQualityGrade.equals(NOT_SELECTED)) {
                clickOnExteriorFeaturesAndFinishesEditButton();
                int indexToSelectRadioButton = getRadioButtonDescriptionsFromWebElements(exteriorFeaturesAndFinishesMatRadioButtons).indexOf(applicant.getExteriorShapeAndStyleQualityGrade());
                if (indexToSelectRadioButton < 0) {
                    indexToSelectRadioButton = 0;
                    applicant.setGeneralShapeAndStyleQualityGrade(getTextFromElement(exteriorFeaturesAndFinishesRadioButtons.get(indexToSelectRadioButton)));
                }
                clickOnHiddenElement(exteriorFeaturesAndFinishesRadioButtons.get(indexToSelectRadioButton));
            }
            if (!expectedInteriorFeaturesAndFinishesQualityGrade.equals(applicant.getInteriorShapeAndStyleQualityGrade()) || expectedInteriorFeaturesAndFinishesQualityGrade.equals(NOT_SELECTED)) {
                clickOnInteriorFeaturesAndFinishesEditButton();
                int indexToSelectRadioButton = getRadioButtonDescriptionsFromWebElements(interiorFeaturesAndFinishesMatRadioButtons).indexOf(applicant.getInteriorShapeAndStyleQualityGrade());
                if (indexToSelectRadioButton < 0) {
                    indexToSelectRadioButton = 0;
                    applicant.setGeneralShapeAndStyleQualityGrade(getTextFromElement(interiorFeaturesAndFinishesRadioButtons.get(indexToSelectRadioButton)));
                }
                clickOnHiddenElement(interiorFeaturesAndFinishesRadioButtons.get(indexToSelectRadioButton));
            }
            if (!expectedCounterAndCabinetsQualityGrade.equals(applicant.getCabinetsAndCounterTopsQualityGrade()) || expectedCounterAndCabinetsQualityGrade.equals(NOT_SELECTED)) {
                clickOnCabinetsCounterTopsEditButton();
                int indexToSelectRadioButton = getRadioButtonDescriptionsFromWebElements(cabinetsAndCounterTopsMatRadioButtons).indexOf(applicant.getCabinetsAndCounterTopsQualityGrade());
                if (indexToSelectRadioButton < 0) {
                    indexToSelectRadioButton = 0;
                    applicant.setGeneralShapeAndStyleQualityGrade(getTextFromElement(cabinetsAndCounterTopsRadioButtons.get(indexToSelectRadioButton)));
                }
                clickOnHiddenElement(cabinetsAndCounterTopsRadioButtons.get(indexToSelectRadioButton));
            }
        }
    }

    public void validateADA(String lobType) throws Exception {
        for (WebElement weEdit : editButtons) {
            waitAndClickElement(weEdit);
        }
        performADATesting(this.getClass().getSimpleName(), MARKETING_IT, lobType);
        driver().navigate().refresh();
    }

    public void updateExteriorValidateReviewQuoteAndPurchaseStepper(FarmersSoftAssert sa) throws Exception {
        clickOnExteriorFeaturesAndFinishesEditButton();
        List<WebElement> uncheckExteriorRadioButtons = uncheckedQualityGradeRadioButtons(exteriorFeaturesAndFinishesRadioButtons);
        for (WebElement unchecked : uncheckExteriorRadioButtons) {
            if (!unchecked.isSelected()) {
                clickOnHiddenElement(unchecked);
                break;
            }
        }
        boolean isStepperSelected = true;
        if (!isUseMobileViewEnabled()) {
            if(!getSelectedStepper(DESKTOP_BROWSER).equals(REVIEW_QUOTE) || !getSelectedStepper(DESKTOP_BROWSER).equals(PURCHASE))
            {
                isStepperSelected = false;
                log.info(REVIEW_QUOTE + " and " + PURCHASE + " Stepper are disabled.");
            }
        } else {
            if(!getSelectedStepper(MOBILE_BROWSER).equals(REVIEW_QUOTE) || !getSelectedStepper(MOBILE_BROWSER).equals(PURCHASE))
            {
                isStepperSelected = false;
                log.info(REVIEW_QUOTE + " and " + PURCHASE + " Stepper are disabled.");
            }
        }
        sa.assertTrue(!isStepperSelected, "Review quote stepper is displaying selected");
    }
}
