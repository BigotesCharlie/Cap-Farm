package com.farmers.ffq.home.pages;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.ApplicantHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import static com.farmers.ffq.home.pages.PropertyPage.saveApplicantFinishLater;
import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Choose Your Coverage Page - Home.
 *
 *
 */
public class ChooseYourCoveragePage extends BasePage {

	private static final String CONTAINS = " contains: ";
	private static final String PREMIUM_FOR = "Premium amount for ";
	private static final String PACKAGE_NOT_DISPLAYED = " package not displayed";
	private static final String PACKAGE_VERIFICATION = " package title verification";
	private static final String POPUP_CONTAINS = "Pop up contains text : ";

	//Package description static text
	private static final String STANDARD_PCK_DESCRIPTION = "Our most affordable home coverage package includes fundamental coverage levels that can be customized to provide additional protection for things that matter most to you.";
	private static final String ENHANCED_PCK_DESCRIPTION = "This package offers extended limits and pays the cost to replace your roof or contents without depreciation.";
	private static final String PREMIER_PCK_DESCRIPTION = "Our premier coverage provides the highest limits on personal property and has Extended Replacement Cost coverage for your home.";

	@FindBy(id = "homequote:packCompHeader9")
	private WebElement packagesSideBySideStaticText1;

	@FindBy(id = "homequote:packCompHeader22")
	private WebElement packagesSideBySideStaticText2;

	@FindBy(xpath = "//*[@id='ComparePaymentOptions']/div[1]/p[2]")
	private WebElement estimatedReconstructionCostText;

	@FindBy(id = "homequote:stdPckgPremium22")
	private WebElement stdPckgPremiumAmountText;

	@FindBy(id = "homequote:enhancedPckgPremium33")
	private WebElement enhancedPckgPremiumAmountText;

	@FindBy(id = "homequote:premierPckgPremium33")
	private WebElement premierPckgPremiumAmountText;

	@FindBy(id = "homequote:homeDiscountNames")
	private WebElement preQualifiedDiscountsText;

	@FindBy(xpath = "//*[@id='homequote:radioInfo:0:packagesMode']/tbody/tr/td/input")
	protected WebElement standardButton;

	@FindBy(xpath = "//*[@id='homequote:radioInfo:1:packagesMode']/tbody/tr/td/input")
	private WebElement enhancedButton;

	@FindBy(xpath = "//*[@id='homequote:radioInfo:2:packagesMode']/tbody/tr/td/input")
	private WebElement premierButton;

	@FindBy(xpath = "//*[@id='ComparePaymentOptions']/div[1]/p[2]")
	private WebElement estimatedReconstructionCostValue;

	@FindBy(id = "homequote:submit")
	private WebElement continueBtn;

	@FindBy(id = "renterSave")
	private WebElement saveAndFinishLaterBtn;

	@FindBy(xpath = "//*[@id='contButtonCA']/a")
	private WebElement visitFcomButton;

	@FindBy(css = ".ArrowS.arrowDown")
	private WebElement arrowDownStandrtPck;

	@FindBy(css = ".ArrowE.arrowDown")
	private WebElement arrowDownEnhancedPck;

	@FindBy(css = ".ArrowP.arrowDown")
	private WebElement arrowDownPremierPck;

	@FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[1]/td[1]/div/div[4]/div/span")
	private WebElement standardPackageDescriptionText;

	@FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[2]/td[1]/div/div[4]/div/span")
	private WebElement enhancedPackageDescriptionText;

	@FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[3]/td[1]/div/div[4]/div/span")
	private WebElement premierPackageDescriptionText;

	@FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[1]/td[1]/div/div[2]")
	private WebElement standardPackagePremiumAmount;

	@FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[2]/td[1]/div/div[2]")
	private WebElement enhancedPackagePremiumAmount;

	@FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[3]/td[1]/div/div[2]")
	private WebElement premierPackagePremiumAmount;

	@FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[1]/td[1]/div/div[3]/div[2]/span")
	private WebElement standardPckTitle;

	@FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[2]/td[1]/div/div[3]/div[2]/span")
	private WebElement enhancedPckTitle;

	@FindBy(xpath = "//*[@id='homequote:radioInfo']/tbody/tr[3]/td[1]/div/div[3]/div[2]/span")
	private WebElement premierPckTitle;

	@FindBy(id = "HomeUpdateBtn")
	private WebElement updateQuoteBtn;

	@FindBy(xpath = "//*[@id='homequote:progress:0:coverages']/span[2]")
	private WebElement yourInfoNavBarText;

	@FindBy(xpath = "//*[@id='homequote:progress:1:coverages']/span[2]")
	protected WebElement propertyNavBarText;

	@FindBy(xpath = "//*[@id='homequote:progress:2:coverages']/span[2]")
	private WebElement coverageNavBarText;

	@FindBy(xpath = "//*[@id='homequote:progress:3:coverages']/span[2]")
	private WebElement quoteNavBarText;

	@FindBy(id = "pbMenuPlaceHolder")
	private WebElement blueNavBar;

	@FindBy(id = "HeaderLogo")
	private WebElement headerLogo;

	@FindBy(xpath = "//*[@id='ComparePaymentOptions']/div[1]/p[1]")
	private WebElement reviewAndChooseSubHeaderText;

	@FindBy(xpath = "//*[@id='BoxArea']/div[@class='quote_disclaimer3']")
	private WebElement footerDisclaimerStaticText;

	@FindBy(xpath = "//*[@id='homequote:disclaimer_2']/p/i")
	private WebElement briefSummaryStaticText;

	@FindBy(xpath = "//*[@id='VeriSign']/img")
	private WebElement digiCertImageLogo;

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public ChooseYourCoveragePage() throws Exception {
		super();
	}

	private void verifyEstimatedReconstructionCostValueIsDisplayed(FarmersSoftAssert fsa) {
		fsa.assertTrue(estimatedReconstructionCostText.isDisplayed() && getTextFromElement(estimatedReconstructionCostText).contains("Estimated Reconstruction Cost")
				,"Estimated Reconstruction Cost text verification");
	}

	public QuotePageHome chooseYourCoveragePageValidationHome(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		waitElementBeVisible(saveAndFinishLaterBtn);
		verifyHomeHelpLinks(getListWithHomeLOBFooterLinks(), getListWithHomeLOBFooterURLDestinationsTitle());
		verifyNavBarTitle(fsa);
		verifyFooterDisclaimerText(fsa);
		verifyEstimatedReconstructionCostValueIsDisplayed(fsa);
		verifyPackageDescriptionAndPremiumAmount(STANDARD, fsa);
		verifyPackageDescriptionAndPremiumAmount(ENHANCED, fsa);
		verifyPackageDescriptionAndPremiumAmount(PREMIER, fsa);
		selectPackage(applicant.getYourPackage());
		clickElement(continueBtn);
		waitForLegacySpinnerToBeGone();
		checkAllURLsAndImages(findAllURLsAndImages());
		return new QuotePageHome(applicant);
	}

	protected void clickSaveFinishLaterButton() {
		Log.info("Clicking save finish later button");
		clickElement(saveAndFinishLaterBtn);
		clickVisitFarmerButton();
	}

	private void clickUpdateYourQuoteButton() {
		Log.info("Clicking update your quote  button");
		waitElementBeVisible(updateQuoteBtn);
		clickElement(updateQuoteBtn);
	}

	private void clickVisitFarmerButton() {
		Log.info("Clicking visit Farmers.com button");
		waitElementBeVisible(visitFcomButton);
		clickElement(visitFcomButton);
	}

	private void verifyPackageDescriptionAndPremiumAmount(String yourPackage, FarmersSoftAssert fsa) {
		Log.info("Asserting package description text and premium amount for " + yourPackage + " package");
		switch (yourPackage) {
		case STANDARD:
			waitElementBeVisible(standardPckTitle);
			fsa.assertEquals(getTextFromElement(standardPckTitle), "Basic coverage at a lower premium.", yourPackage + PACKAGE_VERIFICATION);
			clickElement(arrowDownStandrtPck);
			fsa.assertTrue(getTextFromElement(standardPackageDescriptionText).contains(STANDARD_PCK_DESCRIPTION), "standardPackageDescriptionText " + CONTAINS + STANDARD_PCK_DESCRIPTION);
			fsa.assertTrue(standardPackagePremiumAmount.isDisplayed(), PREMIUM_FOR + yourPackage + PACKAGE_NOT_DISPLAYED);
			break;
		case ENHANCED:
			waitElementBeVisible(enhancedPckTitle);
			fsa.assertEquals(getTextFromElement(enhancedPckTitle), "Great coverage at a great value.", yourPackage + PACKAGE_VERIFICATION);
			clickElement(arrowDownEnhancedPck);
			fsa.assertTrue(getTextFromElement(enhancedPackageDescriptionText).contains(ENHANCED_PCK_DESCRIPTION), "enhancedPackageDescriptionText " + CONTAINS + ENHANCED_PCK_DESCRIPTION);
			fsa.assertTrue(enhancedPackagePremiumAmount.isDisplayed(), PREMIUM_FOR + yourPackage + PACKAGE_NOT_DISPLAYED);
			break;
		case PREMIER:
			waitElementBeVisible(premierPckTitle);
			fsa.assertEquals(getTextFromElement(premierPckTitle), "Ultimate option for premium coverage.", yourPackage + PACKAGE_VERIFICATION);
			clickElement(arrowDownPremierPck);
			fsa.assertTrue(getTextFromElement(premierPackageDescriptionText).contains(PREMIER_PCK_DESCRIPTION), "premierPackageDescriptionText " + CONTAINS + PREMIER_PCK_DESCRIPTION);
			fsa.assertTrue(premierPackagePremiumAmount.isDisplayed(), PREMIUM_FOR + yourPackage + PACKAGE_NOT_DISPLAYED);
			break;
		default: throw new IllegalArgumentException("Wrong package name: " + yourPackage);
		}
	}

	private void verifyPopup(FarmersSoftAssert fsa) throws Exception {
		String pageSource = driver().getPageSource();
		fsa.assertTrue(pageSource.contains(THANK_YOU_FOR_RETRIEVING_YOUR_QUOTE), POPUP_CONTAINS + THANK_YOU_FOR_RETRIEVING_YOUR_QUOTE);
		fsa.assertTrue(pageSource.contains(YOUR_QUOTE_MAY_HAVE_CHANGED), POPUP_CONTAINS + YOUR_QUOTE_MAY_HAVE_CHANGED);
	}

	private void verifyNavBarTitle(FarmersSoftAssert fsa) {
		waitElementBeVisible(yourInfoNavBarText);
		fsa.assertEquals(getTextFromElement(yourInfoNavBarText), YOUR_INFO, "yourInfoNavBarText verification");
		fsa.assertEquals(getTextFromElement(propertyNavBarText), PROPERTY, "propertyNavBarText verification");
		fsa.assertEquals(getTextFromElement(coverageNavBarText), COVERAGE, "coverageNavBarText verification");
		fsa.assertEquals(getTextFromElement(quoteNavBarText), QUOTE, "quoteNavBarText verification");
		fsa.assertTrue(blueNavBar.isDisplayed(),"Blue navigation bar isn't displayed ");
		fsa.assertTrue(headerLogo.isDisplayed(),"Header logo isn't displayed ");
		fsa.assertEquals(getTextFromElement(reviewAndChooseSubHeaderText), "Please review and choose one of the packages for your 12 month policy coverage below.", "Sub header text verification");
	}

	private void verifyFooterDisclaimerText(FarmersSoftAssert fsa) {
		fsa.assertEquals(getTextFromElement(briefSummaryStaticText), BRIEF_SUMMARY_STATIC_TEXT, "Brief summary static text verification");
		fsa.assertEquals(getTextFromElement(footerDisclaimerStaticText), AMOUNT_DISCLAIMER_STATIC_TEXT, "Disclaimer static text verification");
	}

	/**
	 * Select Your Coverage.
	 *
	 * @param applicant
	 */
	public QuotePageHome enterChooseYourCoveragePage(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		waitForLegacySpinnerToBeGone();
		if (isLegacyQuoteKnockout()) {
			String pageContent = driver().getPageSource();
			String errorMessageEnd = " page reached\n";
			if (pageContent.contains(YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION)) {
				Assert.fail(YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION + errorMessageEnd);
			} else if (pageContent.contains(WE_APOLOGIZE_FOR_THE_INCONVENIENCE)) {
				Assert.fail(WE_APOLOGIZE_FOR_THE_INCONVENIENCE + errorMessageEnd);
			}        	
		}
		waitElementBeVisible(continueBtn);
		if (applicant.isSaveAndRetrieveCoveragePage() && findInCallStack(SAVE_AND_RETRIEVE_HOME_QUOTE)) {
			verifyPopup(fsa);
			clickUpdateYourQuoteButton();
			waitForRecalculationPopupToBeGone();
			waitElementBeVisible(continueBtn);
			fsa.assertEquals(applicant.getApplicantRetQuote().getQuoteNumber(), getLegacyQuoteNumber(), "Quote number vefrification");
		}
		if (applicant.isBackNavFlow()) {
			clickElement(standardButton);
		} else {
			selectPackage(applicant.getYourPackage());
		}
		clickElement(continueBtn);
		longWaitForElementToBeGoneByID("homequote:submit");
		return new QuotePageHome(applicant);
	}

	private void selectPackage(String yourPackage) {
		switch (yourPackage) {
		case STANDARD : 
			clickElement(standardButton);
			break;
		case ENHANCED :
			clickElement(enhancedButton);
			break;
		case PREMIER :
			clickElement(premierButton);
			break;
		default :
			throw new IllegalArgumentException("Wrong package name : " + yourPackage);
		}
	}

	public void saveHomeOnCoveragePageAndFinishLater(ApplicantHome applicant) {
		waitForLegacySpinnerToBeGone();
		saveApplicantFinishLater(applicant, CHOOSE_YOUR_COVERAGE_PAGE, getLegacyQuoteNumber());
		clickSaveFinishLaterButton();
	}

	public boolean onChooseYourCoveragePage() {
		waitForLegacySpinnerToBeGone();
		return isElementPresentByID(continueBtn);
	}
}

