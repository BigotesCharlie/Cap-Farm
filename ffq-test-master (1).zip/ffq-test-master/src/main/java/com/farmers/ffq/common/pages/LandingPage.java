package com.farmers.ffq.common.pages;

import com.farmers.ffq.ace.life.AceLifeNameAndDOBPage;
import com.farmers.ffq.ace.life.AceLifePersonalInfoPage;
import com.farmers.ffq.ace.life.AceLifeReviewQuotePage;
import com.farmers.ffq.auto.pages.legacy.DiscountsPage;
import com.farmers.ffq.auto.pages.legacy.DriversPage;
import com.farmers.ffq.auto.pages.legacy.QuotePageAuto;
import com.farmers.ffq.auto.pages.legacy.VehiclesPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.LeadTypeHQM;
import com.farmers.ffq.home.pages.ChooseYourCoveragePage;
import com.farmers.ffq.home.pages.PropertyPage;
import com.farmers.ffq.home.pages.QuotePageHome;
import com.farmers.ffq.home.pages.YourInfoPageHome;
import com.farmers.ffq.utils.AESHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.driver.Driver;
import com.farmers.framework.report.Log;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.SkipException;

import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;


/**
 * Farmers Fast Quote (FFQ) - FFQ Landing page - legacy version.
 */
public class LandingPage extends BasePage {

	@FindBy(className = "ffq-landing-disclaimer")
	private WebElement landingPageDisclaimer;

	@FindBy(xpath = "//button[contains(text(), 'START QUOTE')]")
	private WebElement startMyQuoteButton;

	@FindBy(id = "landing:DecideQuote:0")
	private WebElement getNewQuoteRadioButton;

	@FindBy(id = "landing:DecideQuote:1")
	private WebElement retrieveSavedQuoteRadioButton;

	@FindBy(id = "landing:quoteTypeLbl")
	private WebElement dropdownLOBLabel;

	@FindBy(id = "landing:quoteType")
	private WebElement dropdownLOB;

	@FindBy(id = "landing:zipCodeLbl")
	private WebElement zipCodeLabel;

	private static final String XPATH_TO_ZIP_CODE_FIELD = "//input[@aria-label='Zip code']";
	@FindBy(xpath = XPATH_TO_ZIP_CODE_FIELD)
	private WebElement zipCodeField;

	private static final String XPATH_TO_SUBMIT_BUTTON = "//button[@title='Start My Quote']";

    @FindAll({
            @FindBy(xpath = XPATH_TO_SUBMIT_BUTTON),
            @FindBy(css = "button[data-gtm='FFQ_Auto_Landing_Newquote_Startmyquote_button']")
    })
    private WebElement submitButton;

	@FindBy(id = "landing:lastNameLbl")
	private WebElement lastNameLabel;

	@FindBy(xpath = "//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Lastname_field']//input")
	private WebElement lastNameField;

	@FindBy(id = "landing:dateOfBirthLbl")
	private WebElement dateOfBirthLabel;

	@FindBy(xpath = "//lib-date-picker[@data-gtm='FFQ_Auto_Landing_Retrievequote_Dateofbirth_field']//input[string-length(@aria-label)>0]")
	private WebElement dateOfBirthField;

	@FindBy(id = "landing:emailquotenumberLbl")
	private WebElement quoteNumberLabel;

	@FindBy(xpath = "//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Quotenumber_field']//input")
	private WebElement quoteNumberField;

	@FindBy(id = "landing:zipcode2Lbl")
	private WebElement zipCodeForRetrieveLabel;

	@FindBy(xpath = "//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Zipcode_field']//input")
	private WebElement zipCodeForRetrieveField;

	private static final String UNABLE_TO_LOCATE_QUOTE_ID_STRING = "landingErrorInfoHeading";
	@FindBy(id = UNABLE_TO_LOCATE_QUOTE_ID_STRING)
	private WebElement unableToLocateQuoteDialog;

	private static final String XPATH_TO_RETRIEVE_BUTTON = "//button[@title='Retrieve Your Quote']";
    @FindAll({
            @FindBy(xpath = XPATH_TO_RETRIEVE_BUTTON),
            @FindBy(css = "button[data-gtm='FFQ_Auto_Landing_Retrievequote_button']")
    })
    private WebElement retrieveQuoteButton;

    private static final String XPATH_TO_REVIEW_QUOTE_BUTTON = "//button[@title='Review quote with quote number %s']";

	@FindBy(xpath = "//*[@id='DisclaimerLanding']/p/span")
	private WebElement footerStaticText;

	@FindBy(id = "quoteTypeError")
	private WebElement quoteTypeErrorMessage;

	@FindBy(xpath = "//div[@id='ffq-landing-zip-code']//mat-error")
	private WebElement zipCodeEntryErrorMessage;

	@FindBy(xpath = "//div[@class='ffq-landing-show-zip-err ng-star-inserted'] | //p[@id='zipCodeError']")
	private WebElement zipCodeErrorMessage;

	@FindBy(xpath = "//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Lastname_field']//mat-error")
	private WebElement lastNameErrorMessage;

	@FindBy(xpath = "//lib-date-picker[@data-gtm='FFQ_Auto_Landing_Retrievequote_Dateofbirth_field']//mat-error")
	private WebElement dateOfBirthErrorMessage;

	@FindBy(xpath = "//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Quotenumber_field']//mat-error")
	private WebElement emailQuoteNumberErrorMessage;

	@FindBy(xpath = "//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Zipcode_field']//mat-error")
	private WebElement zipCodeInRetrieveErrorMessage;

	@FindBy(xpath = "//div[h2[contains(text(),'We were unable to locate your quote')]]")
	private WebElement quoteRetrievalErrorMessage;

	@FindBy(xpath = "//div[h2[contains(text(),'We were unable to locate your quote')]]//button[text()='CLOSE']")
	private WebElement buttonCloseErrorDialog;

	@FindBy(id = "landing-quote")
	private WebElement getNewQuoteTab;

	@FindBy(id = "landing-retrieve")
	private WebElement retrieveSavedQuoteTab;

	@FindBy(xpath = "//div/p[@class='ffq-landing-showproduct-err ng-star-inserted']")
	private WebElement selectProductErrorMessage;

	@FindBy(xpath = "//*[@value='auto']")
	private WebElement autoLOBButton;

	@FindBy(xpath = "//*[@value='home']")
	private WebElement homeLOBButton;

	@FindBy(xpath = "//*[@value='life']")
	private WebElement lifeLOBButton;

	@FindBy(xpath = "//*[@value='business']")
	private WebElement businessLOBButton;

	@FindBy(xpath = "//*[@value='renter']")
	private WebElement rentersLOBButton;

	@FindBy(xpath = "//*[@value='mobilehome']")
	private WebElement mobileHomeLOBButton;

	@FindBy(xpath = "//*[@value='condo']")
	private WebElement condoLOBButton;

	@FindBy(xpath = "//*[@value='autoHome']")
	private WebElement autoHomeBundleButton;

	@FindBy(xpath = "//*[@value='autoRenters']")
	private WebElement autoRentersBundleButton;

	@FindBy(xpath = "//*[@value='autoCondo']")
	private WebElement autoCondoBundleButton;

	@FindBy(css = "#infoContent")
	private WebElement infoDialogContent;

	@FindBy(css = ".dialog__info-dialog-button-close")
	private WebElement infoDialogCloseButton;

	private static final String COLOR_ERROR_MSG = " error message color is one of " + RED_RGB + SPACE + RED_RGBA + SPACE + RED_RGB_AUTO_REDESIGN + SPACE + RED_RGBA_AUTO_REDESIGN + SPACE + DARK_RED_RGBA + " or " + DARK_RED_RGB;
	private static final String ZIP_CODE_MSG = "Zip code error message";
	private static final String ENTER_ZIP_CODE = "Please enter ZIP Code.";
	private static final String ENTER_5DIGIT_ZIP_CODE = "Please enter a 5-digit ZIP Code.";
	private static final String PRODUCT_REQUIRED = "Please select a product.";
	private static final String LAST_NAME_REQUIRED = "Please enter Last Name.";
	private static final String DOB_REQUIRED = "Please enter Date of Birth.";
	private static final String QUOTE_OR_EMAIL_REQUIRED = "Please enter Quote Number Or Email Address.";
	private static final String ERROR_FOUND_MSG = "Error message found is: ";
	private static final String NO_POLICIES_OFFERED = "We apologize for this inconvenience, Farmers does not currently offer policies in ";
	private static final String NO_BUNDLE_POLICIES_OFFERED = "We're sorry, we are not able to offer a bundle quote in your area at this time.";
	private static final String CANT_COMPLETE_QUOTE_ONILNE = "We're sorry, a quote cannot be completed online at this time. Please contact your local Farmers Agent for a quote.";
	private static final String ONLINE_QUOTING_UNAVAILABLE = "Farmers online quoting is currently unavailable in your state. Contact Your Farmers Agent or call 1-800-FARMERS.";
	private static final String CLICK_TO_RETURN = ". Click here to return to Farmers.com.";
	private static final String PAGE_DOESNT_EXIST = " page doesn't exist";
	private static final String RETRIEVE_QUOTE_HASHMAP_MISING_KEY = "Retrieve Quote Concurrent Hash Map doesn't contain key: ";
	private static final String LINE_OF_BUSINESS_DOESNT_EXIST = " line of business doesn't exist";
	private static final String UNCHECKED = "unchecked";

	private static final String AWS_ZIP = "?Lob=&Zip_Code=";
	private static final String AWS_STATE = "&platform=LG&Source_Indicator=AS&State_Code=";
	private static final String AWS_AGENTCODE = "&Agent_Code=";
	private static final String AWS_FORMATTING_STRING = "?Lob=%s&Source_Indicator=AP&State_Code=%s&AOR=%s&Zip_Code=%s";

	public LandingPage() throws Exception {
		intializeLandingPage(Property.getUri(), false, false);
	}

	public LandingPage(int justCreateALandingPageObject) throws Exception {
		//This empty constructor is to just get us a landing page object without any navigation or settings associated with other constructors.
	}

	public LandingPage(String url) throws Exception {
		intializeLandingPage(url, false, false);
	}

	public LandingPage(boolean useMobile) throws Exception {
		intializeLandingPage(Property.getUri(), useMobile, false);
	}

	public LandingPage(String url, boolean useMobile) throws Exception {
		intializeLandingPage(url, useMobile, false);
	}

	public LandingPage(boolean useMobile, boolean useFarmersDotCom) throws Exception {
		intializeLandingPage(Property.getUri(), useMobile, useFarmersDotCom);
	}

	public LandingPage(String zipCode, LeadTypeHQM leadType, String browserType) throws Exception {
		driverWait(1);
		String url = Property.getEnvironmentProperty("uri_hqm") + "&ZIP=" + zipCode;
		switch (leadType.getLeadType()) {
			case AS:
				if (leadType.getAgentId().isEmpty()) {
					url += "&SRC=FC000000001&Source_Indicator=FC&Data=nQsC4nLgvwtwxXVvMclU1cAEK5hjNkZynMKx1LEdlduyOUoIdGlS0xYjwrNV3YkGHz4SH3Q%2FzUDSgM81sUrMDA%3D%3D";
				} else {
					url += "&AOR=" + leadType.getAgentId() +
							"&SRC=AS000000001&Source_Indicator=AS&Data=%2BfDrl4rHuotPUXhs3tXXGMAEK5hjNkZynMKx1LEdldvDUgqXLcLVEx4BOCJeq27dHz4SH3Q%2FzUDSgM81sUrMDA%3D%3D";
				}
				break;
			case FC:
				url += "&SRC=FC000000001&Source_Indicator=FC&Data=nQsC4nLgvwtwxXVvMclU1cAEK5hjNkZynMKx1LEdlduyOUoIdGlS0xYjwrNV3YkGHz4SH3Q%2FzUDSgM81sUrMDA%3D%3D";
				break;
			case RQ:
				url = Property.getUri();
				break;
			case QQ:
			case QQNPS:
				if (leadType.getLeadType().equals(QQ)) {
					url += "&SRC=QQQARHQKFQ0000001&PpcSrc=QQ&Source_Indicator=QQ&Data=";
				} else {
					url += "&SRC=QQQARHQKFQ0000001&Source_Indicator=QQ&Data=";
				}
				ObjectMapper mapper = new ObjectMapper();
				String customerData = mapper.writeValueAsString(leadType);
				Log.info("Customer Data:"  + customerData);
				url += AESHelper.encryptWithOutIV(customerData);
				break;
			case AEM:
				url += "&SRC=" + leadType.getCampaignId() + "&Data=31MtZKRTa8w0iUjKiF71w%3D%3D";
				break;
			default:
				Log.error("Unknown leadType parameter: " + leadType);
		}
		setWindowDimensions(browserType.startsWith(MOBILE_BROWSER));
		Log.info("Navigating to " + url);
		driver().navigate().to(url);
		addAuthCookie();
	}

	public LandingPage(String zipCode, LeadTypeHQM leadType, String browserType, String lob) throws Exception {
		driverWait(1);
		String lobUrl = lob.equals(RENTERS) ? lob.substring(0, lob.length()-1) : lob;
		String url = Property.getUri() + "?LOB=" + lobUrl.toUpperCase() + "&ZIP=" + zipCode;
		if (Arrays.asList(AUTO, CONDO, RENTERS, LIFE).contains(lob)) {
			url += "&SRC=" + leadType.getLeadType() + "000000001" + "&Source_Indicator=" + leadType.getLeadType() + "&param=";
			if (!lob.equals(AUTO)) {
				String[] dob = leadType.getDob().split("/");
				leadType.setDob(dob[2] + "-" + dob[0] + "-" + dob[1]);
			}
			ObjectMapper mapper = new ObjectMapper();
			LeadTypeCSS leadTypeCSS = new LeadTypeCSS(leadType, lob.toLowerCase());
			String customerData = mapper.writeValueAsString(leadTypeCSS);
			Log.info("Customer Data:" + customerData);
			url += AESHelper.encryptWithOutIV(customerData);
		} else {
			Log.error("Unknown lob parameter: " + lob);
		}
		setWindowDimensions(browserType.startsWith(MOBILE_BROWSER));
		Log.info("Navigating to " + url);
		driver().navigate().to(url);
		addAuthCookie();
	}

	public LandingPage(Object object) throws Exception {
		String awsURL;
		String applicantType = object.getClass().getSimpleName();
		synchronized (this) {
			switch (applicantType) {
				case AUTO_APPLICANT:
					SqlApplicant autoApplicant = (SqlApplicant) object;
					String agentStateCode = autoApplicant.getStateCode().equals(CA)? autoApplicant.getRepresentative().getAddress() : autoApplicant.getStateCode();
					awsURL = Property.getUri() + AWS_ZIP + autoApplicant.getZipCode() + AWS_STATE + agentStateCode + AWS_AGENTCODE + autoApplicant.getRepresentative().getAor();
					break;
				case ACE_AUTO_APPLICANT:
					AutoApplicant aceAutoApplicant = (AutoApplicant) object;
					awsURL = String.format(Property.getUri() + AWS_FORMATTING_STRING, "A", aceAutoApplicant.getStateCode(), getAgentData(aceAutoApplicant.getStateCode(), new AutoDataProviders()).getAgentOfRecords(), aceAutoApplicant.getZipCode());
					break;
				case ACE_AUTO_ADPF_APPLICANT:
					ADPFApplicant adpfApplicant = (ADPFApplicant) object;
					awsURL = String.format(Property.getUri() + AWS_FORMATTING_STRING, "A", adpfApplicant.getStateCode(), getAgentData(adpfApplicant.getStateCode(), new AutoDataProviders()).getAgentOfRecords(), adpfApplicant.getZipCode());
					break;
				case ACE_BUNDLE_APPLICANT:
					AceBundleApplicant bundleApplicant = (AceBundleApplicant) object;
					AutoApplicant autoBundleApplicant = bundleApplicant.getAutoApplicant();
					awsURL = String.format(Property.getUri() + AWS_FORMATTING_STRING, autoBundleApplicant.getTestScenario(), autoBundleApplicant.getStateCode(), getAgentData(autoBundleApplicant.getStateCode(), new AutoDataProviders()).getAgentOfRecords(), autoBundleApplicant.getZipCode());
					break;
				case ACE_HOME_APPLICANT:
					//actually for the Mobile Home LOB since they share same object with H/R/C
					ApplicantAceHome aceMobilehomeApplicant = (ApplicantAceHome) object;
					switch (aceMobilehomeApplicant.getTestCategory()) {
						case FOREMOST:
							awsURL = String.format("https://" + new URL(Property.getUri()).getHost() + "/quote/?Source_Indicator=FRMS&Zip=%s&Lob=M&SRC=FRMS00\u2026", aceMobilehomeApplicant.getZipCode());
							break;
						case USAA:
							awsURL = String.format("https://" + new URL(Property.getUri()).getHost() + "/quote/home/personal-info?SourceID=USMAXYQQQQ&SRC=USMAXYQQQQ&Source_Indicator=US&Zip=%s&Lob=M&showView=address", aceMobilehomeApplicant.getZipCode());
							break;
						default:
							awsURL = String.format(Property.getUri() + AWS_FORMATTING_STRING, "M", aceMobilehomeApplicant.getStateCode(), getAgentData(aceMobilehomeApplicant.getStateCode(), new AutoDataProviders()).getAgentOfRecords(), aceMobilehomeApplicant.getZipCode());
							break;
					}
					break;
				case BUSINESS_APPLICANT:
					ApplicantBusiness businessApplicant = (ApplicantBusiness) object;
					awsURL = String.format(Property.getUri() + AWS_FORMATTING_STRING, "B", businessApplicant.getStateCode(), getAgentData(businessApplicant.getStateCode(), new AutoDataProviders()).getAgentOfRecords(), businessApplicant.getZipCode());
					break;
				case HOME_APPLICANT:
					ApplicantHome homeApplicant = (ApplicantHome) object;
					awsURL = String.format(Property.getUri() + AWS_FORMATTING_STRING, "H", homeApplicant.getStateCode(), homeApplicant.getSameStateZipCode(), homeApplicant.getZipCode());
					break;
				case HQM_APPLICANT:
					ApplicantHQM hqmApplicant = (ApplicantHQM) object;
					awsURL = Property.getUri() + AWS_ZIP + hqmApplicant.getZipCode() + AWS_STATE + hqmApplicant.getStateCode() + AWS_AGENTCODE + hqmApplicant.getAgentId();
					break;
				case LIFE_APPLICANT:
					ApplicantLife lifeApplicant = (ApplicantLife) object;
					awsURL = String.format(Property.getUri() + AWS_FORMATTING_STRING, "L", lifeApplicant.getStateCode(), getAgentData(lifeApplicant.getStateCode(), new AutoDataProviders()).getAgentOfRecords(), lifeApplicant.getZipCode());
					break;
				default:
					throw new IllegalArgumentException("Invalid object specified: " + object.getClass().getSimpleName());
			}
		}
		intializeLandingPage(awsURL, isUseMobileViewEnabled(), false);
	}

	private void intializeLandingPage(String url, boolean useMobile, boolean useFarmersDotCom) throws Exception {
        setWindowDimensions(useMobile);
		openLandingPage(url, useFarmersDotCom);
	}

	private void setWindowDimensions(boolean useMobile) throws Exception {
		if (useMobile) {
			driver(Driver.MOBILE);
		} else if ("true".equals(Property.getTestProperty("headless"))) {
			// Headless needs explicit dimensions to avoid defaulting to mobile version of the site
			driver().manage().window().setSize(new Dimension(1920, 1080));
		} else {
			driver().manage().window().maximize();
		}
	}

	private void openLandingPage(String url, boolean useFarmersDotCom) throws Exception {
		if (!isSafariBrowser()) {
			driver().manage().deleteAllCookies();
		}
		if (useFarmersDotCom) {
			url = Property.getEnvironmentProperty("farmers_com_url");
			if (url==null || url.isBlank()) {
				url = Property.getUri();
			}
		}
		Log.info("Navigating to: " + url);
		driver().navigate().to(url);
		addAuthCookie();
		acceptCookies();
	}

	private AgentFlowData getAgentData(String stateCode, AutoDataProviders autoDataProviders) throws Exception {
		List<AgentFlowData> listOfAgentFlowData = autoDataProviders.listOfAgentFlowData();
		List<AgentFlowData> agentDataList = listOfAgentFlowData.stream().filter(data -> data.getStateCode().equals(stateCode)).collect(Collectors.toList());
		if (agentDataList.isEmpty()) {
			throw new SkipException("Skipping this test as there is no data for " + stateCode + " in the 'agentFlow' data sheet");
		}
		AgentFlowData agentFlowData = agentDataList.get(0);
		return agentFlowData;
	}

	public void clickGetNewQuoteTab() {
		scrollToElement(waitElementBeVisible(landingPageDisclaimer));
		if (isElementPresent(By.xpath(XPATH_TO_RETRIEVE_BUTTON), 2)) {
			waitAndClickElement(getNewQuoteTab);
		}
	}

	public void clickRetrieveSavedQuoteTab() {
		waitAndClickElement(retrieveSavedQuoteTab);
	}

	private void clickRetrieveQuoteButton() {
		waitAndClickElement(retrieveQuoteButton);
	}

	private void clickRetrieveQuoteButtonAndContinue() {
		clickRetrieveQuoteButton();
		waitForSpinnerToBeGone();
		waitForLegacySpinnerToBeGone();
		if (!isElementPresentByID(unableToLocateQuoteDialog)) {
			longWaitForElementToBeGoneByXpath(XPATH_TO_RETRIEVE_BUTTON);
		}
	}

	public void validateUnableToRetrieveContent(FarmersSoftAssert softAssert, String expectedContent) {
		softAssert.assertTrue(isQuoteNotFoundPopUpPresent(), "Unable to locate quote dialog displayed");
		softAssert.assertTrue(isExpectedTextContainedInElement(infoDialogContent, expectedContent), expectedContent + " found in dialog");
	}

	public void selectLOB(String lob) {
		switch (lob) {
			case LOB_AUTO:
				waitAndClickElement(autoLOBButton);
				break;
			case LOB_BUSINESS:
				waitAndClickElement(businessLOBButton);
				break;
			case LOB_CONDO:
				waitAndClickElement(condoLOBButton);
				break;
			case LOB_HOME:
				waitAndClickElement(homeLOBButton);
				break;
			case LOB_LIFE:
				waitAndClickElement(lifeLOBButton);
				break;
			case LOB_MOBILE_HOME:
				waitAndClickElement(mobileHomeLOBButton);
				break;
			case LOB_RENTERS:
				waitAndClickElement(rentersLOBButton);
				break;
			case AUTO_HOME_BUNDLE:
				waitAndClickElement(autoHomeBundleButton);
				break;
			case AUTO_RENTERS_BUNDLE:
				waitAndClickElement(autoRentersBundleButton);
				break;
			case AUTO_CONDO_BUNDLE:
				waitAndClickElement(autoCondoBundleButton);
				break;
			default:
				throw new IllegalArgumentException(lob + LINE_OF_BUSINESS_DOESNT_EXIST);
		}
		scrollToTopOfPage();
	}

	public boolean isLOBButtonAvailable(String lob) {
		boolean usingDefaultLandingPage = isElementPresent(By.xpath(XPATH_TO_ZIP_CODE_FIELD), 2);
		WebElement buttonToCheck;
		switch (lob) {
			case LOB_AUTO:
				buttonToCheck = usingDefaultLandingPage? autoLOBButton : buttonAuto;
				break;
			case LOB_BUSINESS:
				buttonToCheck = usingDefaultLandingPage? businessLOBButton : buttonBusiness;
				break;
			case LOB_HOME:
				buttonToCheck = usingDefaultLandingPage? homeLOBButton : buttonHome;
				break;
			case LOB_LIFE:
				buttonToCheck = usingDefaultLandingPage? lifeLOBButton : buttonLife;
				break;
			case LOB_MOBILE_HOME:
				buttonToCheck = usingDefaultLandingPage? mobileHomeLOBButton : buttonMobileHome;
				break;
			case LOB_RENTERS:
				buttonToCheck = usingDefaultLandingPage? rentersLOBButton : buttonRenters;
				break;
			case AUTO_HOME_BUNDLE:
				buttonToCheck = usingDefaultLandingPage? autoHomeBundleButton : buttonAuto;
				break;
			case AUTO_RENTERS_BUNDLE:
				buttonToCheck = usingDefaultLandingPage? autoRentersBundleButton : buttonAuto;
				break;
			default:
				throw new IllegalArgumentException(lob + LINE_OF_BUSINESS_DOESNT_EXIST);
		}
		return (isElementDisplayed(buttonToCheck, 3));
	}

	public void enterZip(String zip) {
		sendKeysToElement(zipCodeField, zip);
		Log.info("Zip code entered: " + zip);
	}

	public void clickSubmit() {
		scrollAndClickOnElement(submitButton);
		if (isSafariBrowser()) {
			sleep(3);
		}
	}

	public void enterLandingPageDataAndContinue(String lob, String zip) throws Exception {
		enterLandingPageData(lob, zip);
		waitForSpinnerToBeGone();
		waitForLegacySpinnerToBeGone();
		waitForPageToBeDismissed();
	}

	private void waitForPageToBeDismissed() {
		if (!isElementVisible(infoDialogCloseButton, 3)) {
			if (isElementPresent(By.xpath(XPATH_TO_SUBMIT_BUTTON), 3)) {
				clickSubmit();
				longWaitForElementToBeGoneByXpath(XPATH_TO_SUBMIT_BUTTON);
			}
		}
	}

	public void enterLandingPageDataAndRemainInPage(String lob, String zip) throws Exception {
		enterLandingPageData(lob, zip);
	}

	public void enterLandingPageData(String lob, String zip) throws Exception {
		boolean usingDefaultLandingPage = isElementPresent(By.xpath(XPATH_TO_ZIP_CODE_FIELD), 2);
		if (usingDefaultLandingPage) {
			enterZip(zip);
			selectLOB(lob);
			clickSubmit();
		} else {
			enterZipOnFarmersDotCom(zip);
			selectFarmersDotComLOB(lob);
			clickGetMyQuoteButton();
		}
	}

	public void landingPageValidation(FarmersSoftAssert fsa) throws Exception {
		verifyStaticFooterText(fsa);
		verifyLOBButtons(fsa);
		checkAllURLsAndImages(findAllURLsAndImages());
	}

	private void verifyLOBButtons(FarmersSoftAssert fsa) {
		Log.info("Verifying LOB selection buttons");
		fsa.assertTrue(autoLOBButton.isDisplayed(), "Automobile insurance button displayed");
		fsa.assertTrue(homeLOBButton.isDisplayed(), "Home insurance button displayed");
		fsa.assertTrue(mobileHomeLOBButton.isDisplayed(), "Mobile Home insurance button displayed");
		fsa.assertTrue(businessLOBButton.isDisplayed(), "Business insurance button displayed");
		fsa.assertTrue(rentersLOBButton.isDisplayed(), "Renters insurance button displayed");
		fsa.assertTrue(lifeLOBButton.isDisplayed(), "Life insurance button displayed");
		fsa.assertTrue(autoHomeBundleButton.isDisplayed(), "Auto & Home insurance button displayed");
		fsa.assertTrue(autoRentersBundleButton.isDisplayed(), "Auto & Renters insurance button displayed");
	}

	private void verifyStaticFooterText(FarmersSoftAssert fsa) {
		String disclaimerText = getTextFromElement(landingPageDisclaimer);
		Log.info("Verifying Footer static text " + disclaimerText);
		fsa.assertEquals(disclaimerText, "A preliminary rate (\"quote\") is for insurance coverage you select. Certain assumptions may have been made that will influence the quote you receive. " +
				"A quote is not an offer for insurance, an offer of an insurance contract, nor is it an insurance contract, binder or an application to purchase insurance. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract. " +
				"Rates quoted reflect the rates in effect as of the date of this quote and are subject to revision. Your actual premium may vary based upon additional information you provide or we obtain, the coverages and deductibles that you select, any additional underwriting criteria, " +
				"and removal of any assumptions. Farmers reserves the right to accept, reject, or modify this quote after review of the application and other underwriting information. All applications are subject to underwriting approval. " +
				"Farmers online quotes are for new customers only. Existing customers are requested to contact their local agent to make changes to their policy. Quoted rates do not include fees permitted by state law.", "Footer static text verification");
	}

	private void verifyErrorMessagesRedAndVisibleForGetAQuoteElements(FarmersSoftAssert fsa) {
		fsa.assertEquals(getTextFromElement(selectProductErrorMessage), PRODUCT_REQUIRED, "selectProductErrorMessage verification");
		fsa.assertTrue(checkErrorColorForElement(selectProductErrorMessage), PRODUCT_REQUIRED + COLOR_ERROR_MSG);
		fsa.assertEquals(getTextFromElement(zipCodeEntryErrorMessage), ENTER_ZIP_CODE, "No zip code entered verification");
		fsa.assertTrue(checkErrorColorForElement(zipCodeEntryErrorMessage), ENTER_ZIP_CODE + COLOR_ERROR_MSG);
		enterZip("799");
		clickSubmit();
		fsa.assertEquals(getTextFromElement(zipCodeEntryErrorMessage), ENTER_5DIGIT_ZIP_CODE, "Partial zip code entered verification");
		fsa.assertTrue(checkErrorColorForElement(zipCodeEntryErrorMessage), ENTER_5DIGIT_ZIP_CODE + COLOR_ERROR_MSG);
	}

	private void verifyErrorMessagesRedAndVisibleForRetrieveQuoteElements(FarmersSoftAssert fsa) {
		waitElementBeVisible(zipCodeInRetrieveErrorMessage);
		fsa.assertEquals(getTextFromElement(lastNameErrorMessage), LAST_NAME_REQUIRED, "Retrieve Quote lastNameErrorMessage verification");
		fsa.assertTrue(checkErrorColorForElement(lastNameErrorMessage), "Last Name" + COLOR_ERROR_MSG);
		fsa.assertEquals(getTextFromElement(dateOfBirthErrorMessage), DOB_REQUIRED, "Retrieve Quote dateOfBirthErrorMessage verification");
		fsa.assertTrue(checkErrorColorForElement(dateOfBirthErrorMessage), "Date of Birth" + COLOR_ERROR_MSG);
		fsa.assertEquals(getTextFromElement(emailQuoteNumberErrorMessage), QUOTE_OR_EMAIL_REQUIRED, "Retrieve Quote emailQuoteNumberErrorMessage verification");
		fsa.assertTrue(checkErrorColorForElement(emailQuoteNumberErrorMessage), "Quote/Email" + COLOR_ERROR_MSG);
		fsa.assertEquals(getTextFromElement(zipCodeInRetrieveErrorMessage), ENTER_ZIP_CODE, "Retrieve Quote zipCodeInRetrieveErrorMessage verification");
		fsa.assertTrue(checkErrorColorForElement(zipCodeInRetrieveErrorMessage), ZIP_CODE_MSG + COLOR_ERROR_MSG);
	}

	private boolean checkErrorColorForElement(WebElement element) {
		String elementColor = element.getCssValue(COLOR);
		boolean result = Arrays.asList(RED_RGB, RED_RGBA, DARK_RED_RGBA, DARK_RED_RGB, RED_RGB_AUTO_REDESIGN, RED_RGBA_AUTO_REDESIGN).contains(elementColor);
		if (!result) {
			Log.warn(elementColor + "not in expected list of colors");
		}
		return result;
	}

	public boolean isNotOfferedInStateErrorMessageRedAndVisible(String state) {
		return checkZIPErrorMessage(NO_POLICIES_OFFERED + state + CLICK_TO_RETURN);
	}

	public boolean cantBeCompletedOnlineErrorMessageRedAndVisible() {
		return checkZIPErrorMessage(CANT_COMPLETE_QUOTE_ONILNE);
	}

	public boolean bundleIsNotOfferedErrorMessageRedAndVisible() {
		return checkZIPErrorMessage(NO_BUNDLE_POLICIES_OFFERED);
	}

	public boolean isNoOnlineQuotingErrorMessageRedAndVisible() {
		return checkZIPErrorMessage(ONLINE_QUOTING_UNAVAILABLE);
	}

	public boolean invalidZipCodeErrorMessageRedAndVisible() {
		return checkZIPErrorMessage("Please enter a valid Zip Code.");
	}

	private boolean checkZIPErrorMessage(String errorMessage) {
		waitElementBeVisible(zipCodeErrorMessage);
		String zipErrorMessage = getTextFromElement(zipCodeErrorMessage);
		boolean result = checkErrorColorForElement(zipCodeErrorMessage) && zipErrorMessage.contains(errorMessage);
		if (!zipErrorMessage.contains(errorMessage)) {
			Log.warn(ERROR_FOUND_MSG + "<" + zipErrorMessage + "> EXPECTED <" + errorMessage + ">");
		}
		return result;
	}

	public void landingPageErrorValidation(FarmersSoftAssert fsa) {
		clickSubmit();
		verifyErrorMessagesRedAndVisibleForGetAQuoteElements(fsa);
		clickRetrieveSavedQuoteTab();
		clickRetrieveQuoteButton();
		verifyErrorMessagesRedAndVisibleForRetrieveQuoteElements(fsa);
		clickGetNewQuoteTab();
	}

	private void enterDateOfBirth(int age) {
		Log.info("Entering Date of Birth calculated from age: " +  age);
		enterDateOfBirth(calculateDateOfBirthFromAge(age));
	}

	public void enterDateOfBirth(String dob) {
		Log.info("Entering Date of Birth: " + dob);
		sendKeysToElement(dateOfBirthField, dob);
	}

	private void enterZipCodeRetrieve(String zip) {
		sendKeysToElement(zipCodeForRetrieveField, zip);
	}

	private void enterQuoteNumber(String quote) {
		sendKeysToElement(quoteNumberField, quote);
	}

	private void enterLastName(String lastName) {
		sendKeysToElement(lastNameField, lastName);
	}

	public <T extends BasePage> T enterRetrieveQuote(Object object, String quoteNumber) throws Exception {
		clickRetrieveSavedQuoteTab();
		waitForRetreiveQuotePageLoad();
		synchronized (this) {
			switch (object.getClass().getSimpleName()) {
				case AUTO_APPLICANT:
					return enterRetrieveSavedQuoteForAuto((SqlApplicant) object);
				case HOME_APPLICANT:
					return enterRetrieveSavedQuoteForHome((ApplicantHome) object);
				case LIFE_APPLICANT:
					return enterRetrieveSavedQuoteForLife((ApplicantLife) object, quoteNumber);
				default:
					throw new IllegalArgumentException("Invalid object specified: " + object.getClass().getSimpleName());
			}
		}
	}

	public void retrieveQuoteFromLandingPage(AutoApplicant applicant, String emailOrQuoteNumber) throws Exception {
		Log.info("Retrieving quote data: Zipcode: " + applicant.getZipCode() + ", Last name: " + applicant.getLastName() + ". Birth date: " + applicant.getDateOfBirth() + ", Email or Quote Number: " + emailOrQuoteNumber);
		enterQuoteInformationAndRetrieve(applicant.getLastName(), applicant.getDateOfBirth(), emailOrQuoteNumber, applicant.getZipCode());
		waitForSpinnerToBeGone();
	}

	public void retrieveQuoteFromLandingPage(ADPFApplicant adfpApplicant, String emailOrQuoteNumber) throws Exception {
		Log.info("Retrieval data: Zipcode: " + adfpApplicant.getZipCode() + ", Last name: " + adfpApplicant.getLastName() + ". Birth date: " + adfpApplicant.getDateOfBirth() + ", Email or Quote Number: " + emailOrQuoteNumber);
		enterQuoteInformationAndRetrieve(adfpApplicant.getLastName(), adfpApplicant.getDateOfBirth(), emailOrQuoteNumber, adfpApplicant.getZipCode());
		waitForSpinnerToBeGone();
	}

	public void retrieveQuoteFromLandingPage(String lastName, String dateOfBirth, String emailOrQuoteNumber, String zipCode) throws Exception {
		Log.info("Retrieval data: Zipcode: " + zipCode + ", Last name: " + lastName + ". Birth date: " + dateOfBirth + ", Email or Quote Number: " + emailOrQuoteNumber);
		enterQuoteInformationAndRetrieve(lastName, dateOfBirth, emailOrQuoteNumber, zipCode);
		waitForSpinnerToBeGone();
	}

	private void enterQuoteInformationAndRetrieve(String lastName, String dateOfBirth, String emailOrQuoteNumber, String zipcode ) throws Exception {
		boolean usingDefaultLandingPage = isElementPresent(By.xpath(XPATH_TO_ZIP_CODE_FIELD), 2);
		if (usingDefaultLandingPage) {
			if (isElementVisible(retrieveSavedQuoteTab,3)) {
				waitAndClickElement(retrieveSavedQuoteTab);
			}
		} else {
			scrollAndClickOnElement(retrieveSavedQuoteLink);
		}
		waitForRetreiveQuotePageLoad();
		sendKeysToElement(lastNameField, lastName);
		sendKeysToElement(dateOfBirthField, dateOfBirth);
		sendKeysToElement(quoteNumberField, emailOrQuoteNumber);
		sendKeysToElement(zipCodeForRetrieveField, zipcode);
		clickElement(retrieveQuoteButton);
		waitElementBeInvisible(retrieveQuoteButton);
		waitForSpinnerToBeGone();
		List<WebElement> listOfReviewQuoteButtons = driver().findElements(By.xpath(String.format(XPATH_TO_REVIEW_QUOTE_BUTTON, emailOrQuoteNumber)));
		if (!listOfReviewQuoteButtons.isEmpty()) {
			clickElement(listOfReviewQuoteButtons.get(FIRST_AVAILABLE_OPTION));
			waitElementBeInvisible(listOfReviewQuoteButtons.get(FIRST_AVAILABLE_OPTION));
			waitForSpinnerToBeGone();
		}
	}

	public void retrieveQuoteWithLink(AutoApplicant applicant, String quoteNumber) throws Exception {
		driver().get(String.format(Property.getUri() + "/?retrieve=true&quoteNumber=%s", quoteNumber));
		waitElementBeVisible(lastNameField).sendKeys(applicant.getLastName());
		waitElementBeVisible(dateOfBirthField).sendKeys(applicant.getDateOfBirth());
		waitElementBeVisible(zipCodeForRetrieveField).sendKeys(applicant.getZipCode());
		waitAndClickElement(retrieveQuoteButton);
	}

	@SuppressWarnings(UNCHECKED)
	private <T extends BasePage> T enterRetrieveSavedQuoteForAuto(SqlApplicant applicant) throws Exception {
		String quoteKey = applicant.getLastName() + applicant.getZipCode();
		if (returningQuoteConcurrentHashMap.containsKey(quoteKey)) {
			ApplicantRetQuote applicantRetQuote = returningQuoteConcurrentHashMap.get(quoteKey);
			enterLastName(applicantRetQuote.getLastName());
			if (applicant.getDateOfBirth() != null) {
				enterDateOfBirth(applicant.getDateOfBirth());
			} else {
				enterDateOfBirth(applicantRetQuote.getAge());
			}
			enterQuoteNumber(applicantRetQuote.getQuoteNumber());
			enterZipCodeRetrieve(applicantRetQuote.getZipCode());
			applicant.setApplicantRetQuote(applicantRetQuote);
			returningQuoteConcurrentHashMap.remove(quoteKey, applicantRetQuote);
			clickRetrieveQuoteButtonAndContinue();
			switch (applicantRetQuote.getPageLeftOn()) {
				case VEHICLES_PAGE_AUTO:
					return (T) new VehiclesPage();
				case DRIVERS_PAGE_AUTO:
					return (T) new DriversPage();
				case DISCOUNTS_PAGE_AUTO:
					return (T) new DiscountsPage();
				case QUOTE_PAGE_AUTO :
					return (T) new QuotePageAuto();
				default:
					throw new IllegalArgumentException(applicantRetQuote.getPageLeftOn() + PAGE_DOESNT_EXIST);
			}
		} else {
			throw new IllegalArgumentException(RETRIEVE_QUOTE_HASHMAP_MISING_KEY + quoteKey);
		}
	}

	@SuppressWarnings(UNCHECKED)
	private <T extends BasePage> T enterRetrieveSavedQuoteForHome(ApplicantHome applicantHome) throws Exception {
		String quoteKey = applicantHome.getLastName() + applicantHome.getZipCode();
		if (returningQuoteConcurrentHashMap.containsKey(quoteKey)) {
			ApplicantRetQuote applicantRetQuote = returningQuoteConcurrentHashMap.get(quoteKey);
			enterLastName(applicantRetQuote.getLastName());
			enterDateOfBirth(applicantRetQuote.getAge());
			enterQuoteNumber(applicantRetQuote.getQuoteNumber());
			enterZipCodeRetrieve(applicantRetQuote.getZipCode());
			applicantHome.setApplicantRetQuote(applicantRetQuote);
			returningQuoteConcurrentHashMap.remove(quoteKey, applicantRetQuote);
			clickRetrieveQuoteButtonAndContinue();
			if (applicantHome.getState().equals(WISCONSIN)) {
				return (T) new PropertyPage();
			} else {
				switch (applicantRetQuote.getPageLeftOn()) {
					case YOUR_INFO_PAGE_HOME:
						return (T) new YourInfoPageHome();
					case PROPERTY_PAGE_HOME:
						return (T) new PropertyPage();
					case CHOOSE_YOUR_COVERAGE_PAGE:
						return (T) new ChooseYourCoveragePage();
					case QUOTE_PAGE_HOME:
						return (T) new QuotePageHome(applicantHome);
					default:
						throw new IllegalArgumentException(applicantRetQuote.getPageLeftOn() + PAGE_DOESNT_EXIST);
				}
			}
		} else {
			throw new IllegalArgumentException(RETRIEVE_QUOTE_HASHMAP_MISING_KEY + quoteKey);
		}
	}

	public void enterRetrieveSavedQuoteForHQM(ApplicantHQM applicant, String quoteNumber) {
		enterLastName(applicant.lastName);
		enterDateOfBirth(applicant.dateOfBirth);
		enterQuoteNumber(quoteNumber);
		enterZipCodeRetrieve(applicant.zipCode);
		clickRetrieveQuoteButton();
	}

	@SuppressWarnings(UNCHECKED)
	private <T extends BasePage> T enterRetrieveSavedQuoteForLife(ApplicantLife applicant, String quoteNumber) throws Exception {
		String quoteKey = applicant.getLastName() + applicant.getZipCode() + quoteNumber;
		if (returningQuoteConcurrentHashMap.containsKey(quoteKey)) {
			ApplicantRetQuote applicantRetQuote = returningQuoteConcurrentHashMap.get(quoteKey);
			enterLastName(applicantRetQuote.getLastName());
			enterDateOfBirth(applicantRetQuote.getAge());
			enterQuoteNumber(applicantRetQuote.getQuoteNumber());
			enterZipCodeRetrieve(applicantRetQuote.getZipCode());
			applicant.setApplicantRetQuote(applicantRetQuote);
			clickRetrieveQuoteButtonAndContinue();
			if (isElementPresentByID(unableToLocateQuoteDialog)) {
				returningQuoteConcurrentHashMap.remove(quoteKey, applicantRetQuote);
				return (T) this;
			}
			// sometimes we get back to the landing page, so try it again
			if (isElementPresentByXPath(XPATH_TO_SUBMIT_BUTTON)) {
				Log.warn("Back on Landing page, trying to retrieve one more time");
				clickRetrieveSavedQuoteTab();
				enterLastName(applicantRetQuote.getLastName());
				enterDateOfBirth(applicantRetQuote.getAge());
				enterQuoteNumber(applicantRetQuote.getQuoteNumber());
				enterZipCodeRetrieve(applicantRetQuote.getZipCode());
				clickRetrieveQuoteButtonAndContinue();
			}
			if (isElementPresentByXPath(XPATH_TO_SUBMIT_BUTTON)) {
				Assert.fail("Retrieve quote keeps returning to Landing page");
			}
			returningQuoteConcurrentHashMap.remove(quoteKey, applicantRetQuote);
			switch (applicantRetQuote.getPageLeftOn()) {
				case ACE_LIFE_NAME_DOB_PAGE:
					return (T) new AceLifeNameAndDOBPage();
				case ACE_LIFE_PERSONAL_INFO_PAGE:
					return (T) new AceLifePersonalInfoPage();
				case ACE_LIFE_REVIEW_QUOTE_PAGE:
					return (T) new AceLifeReviewQuotePage();
				default:
					throw new IllegalArgumentException(applicantRetQuote.getPageLeftOn()+ PAGE_DOESNT_EXIST);
			}
		} else {
			throw new IllegalArgumentException(RETRIEVE_QUOTE_HASHMAP_MISING_KEY + quoteKey);
		}
	}

	public boolean isQuoteRetrievalErrorMessage() {
		boolean bErrorMessage = true;
		try {
			waitElementBeVisible(quoteRetrievalErrorMessage);
			clickElement(buttonCloseErrorDialog);
		} catch (TimeoutException e) {
			bErrorMessage = false;
		}
		return bErrorMessage;
	}

	private void waitForRetreiveQuotePageLoad() {
		waitElementBeVisible(lastNameField);
		waitElementBeVisible(dateOfBirthField);
		waitElementBeVisible(quoteNumberField);
		waitElementBeVisible(zipCodeForRetrieveField);
		waitElementBeVisibleClickable(retrieveQuoteButton);
	}

	private static void addAuthCookie() throws Exception {
		Cookie c = new Cookie("synthetic_agent", "VrrZcox7bk8ZVi0Ua1BECnbiIZRgYttw.appD", "farmers.com", null, null);
		driver().manage().addCookie(c);
	}

	public String getInfoDialogContent() {
		return getTextFromElement(waitElementBeVisible(infoDialogContent));
	}

	public boolean isQuoteNotFoundPopUpPresent() {
		return isElementVisible(unableToLocateQuoteDialog,3);
	}

	// farmers.com members and methods
	@FindBy(xpath ="//div//button[@data-id='Auto']")
	private WebElement buttonAuto;

	@FindBy(xpath ="//div//button[@data-id='Home']")
	private WebElement buttonHome;

	@FindBy(xpath ="//div//button[@data-id='Renter']")
	private WebElement buttonRenters;

	@FindBy(xpath ="//div//button[@data-id='mobilehome']")
	private WebElement buttonMobileHome;

	@FindBy(xpath ="//div//button[@data-id='Life']")
	private WebElement buttonLife;

	@FindBy(xpath ="//div//button[@data-id='Business']")
	private WebElement buttonBusiness;

	@FindBy(xpath ="//form//input[@name='Zip_Code']")
	private WebElement zipCodeInput;

	@FindBy(xpath ="//form//button[contains(@class,'button-cta--mobile') and contains(.,'Get my quote')]")
	private WebElement buttonGetMyQuoteMobile;

    @FindAll({
            @FindBy(xpath ="//form//button[contains(@class,'button-cta--desktop') and contains(.,'Get my quote')]"),
            @FindBy(xpath ="//form//button[contains(@class,'button-cta--desktop') and contains(.,'Get a quote')]")
    })
	private WebElement buttonGetMyQuoteDesktop;

	@FindBy(xpath ="//a[@data-gtm='Farmers_GroupLandingPage_ProductGrid_MobileTextDataLink_Body']")
	private WebElement retrieveSavedQuoteLink;

	public void selectFarmersDotComLOB(String lob) throws Exception {
		switch (lob) {
			case LOB_AUTO:
				scrollAndClickOnElement(buttonAuto);
				break;
			case LOB_BUSINESS:
				scrollAndClickOnElement(buttonBusiness);
				break;
			case LOB_HOME:
				scrollAndClickOnElement(buttonHome);
				break;
			case LOB_LIFE:
				scrollAndClickOnElement(buttonLife);
				break;
			case LOB_MOBILE_HOME:
				scrollAndClickOnElement(buttonMobileHome);
				break;
			case LOB_RENTERS:
				scrollAndClickOnElement(buttonRenters);
				break;
			case AUTO_HOME_BUNDLE:
				scrollAndClickOnElement(buttonAuto);
				scrollAndClickOnElement(buttonHome);
				break;
			case AUTO_RENTERS_BUNDLE:
				scrollAndClickOnElement(buttonAuto);
				scrollAndClickOnElement(buttonRenters);
				break;
			default:
				throw new IllegalArgumentException(lob + LINE_OF_BUSINESS_DOESNT_EXIST);
		}
	}

	public void enterZipOnFarmersDotCom(String zipCode) {
		scrollToElement(zipCodeInput);
		sendKeysToElement(zipCodeInput, zipCode);
		Log.info("Zip code entered: " + zipCode);
	}

	public void clickGetMyQuoteButton() {
		if (isUseMobileViewEnabled()) {
			scrollAndClickOnElement(buttonGetMyQuoteMobile);
		} else {
			scrollAndClickOnElement(buttonGetMyQuoteDesktop);
		}
	}

}
