package com.farmers.ffq.hqm.pages;

import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.PrefillResponseHQM;
import com.farmers.ffq.datatransferobjects.hqm.StaticContentHQM;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import javax.annotation.Nullable;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Home Quote Modernization (HQM) - Property Details Page.
 */

public class PropertyDetailsPage extends HqmBasePage {

    private static final String FOUND_PAGE_ERRORS = "Found page errors: ";
	private static final String LOWERCASE_BASEMENT = "basement";
	private static final String SELECT = "Select";
	private static final String NO_GARAGE = "No Garage";
	private static final String DETACHED = "Detached";
	private static final String EXTERIOR_HEAT_PUMP_TEXT = "Exterior heat pump driving interior heating/cooling units. No air ducts, each unit treats one room/area.";
	private static final String SOLID_STONE = "Solid Stone";
	private static final String SOLID_LOG_MEDIUM_9_12 = "Solid Log - Medium (9 - 12)";
	private static final String BRICK_SOLID_CUSTOM = "Brick - Solid - Custom";
	private static final String BRICK_SOLID = "Brick - Solid";
	private static final String SPLIT_LEVEL = "Split Level";
	private static final String SHALLOW_BASEMENT = "Shallow Basement";
	private static final String BASEMENT = "Basement";
	private static final String FOUR_STORIES = "4 Stories";
	private static final String PROPERTY_DETAILS_PAGE_TITLE = "JUST A FEW MORE\nTHINGS ABOUT\nYOUR HOME";
    private final List<String> numberOfStories = new LinkedList<>(Arrays.asList("1 Story", "1 1/2 Stories (Attic)",
            "2 Stories", "2 1/2 Stories (Attic)", "3 Stories", "3 1/2 Stories (Attic)", FOUR_STORIES,
            "Bi-Level (Raised Ranch)", SPLIT_LEVEL));

    private List<String> foundationTypes = new LinkedList<>(Arrays.asList("Concrete Slab", BASEMENT,
            SHALLOW_BASEMENT, "Crawlspace", "Pier & Grade Beam", "Elevated Post/Pier & Beam (Stilts)",
            "Stilts with Sweep Away Walls", "Deep Pilings"));

    private List<String> foundationTypeDescriptions = new LinkedList<>(
            Arrays.asList("Concrete slab on existing ground, with a deeper \"stem\" wall down to the frost line " +
                            "around its perimeter.",
            "Lowest enclosed story, all or partly below grade, with concrete floor and ceilings at least 6 feet.",
            "Lowest enclosed story, partly below grade. Exterior walls sit atop low foundation walls.",
            "An unfinished accessible area below the first floor of a structure, enclosed by the foundation walls with a dirt floor.",
            "Concrete beams supported by concrete footings cast into a steep or unstable slope.",
            "Structure sits on level beams atop a grid of posts, elevating the base of the building above the ground.",
            "Structure sits atop posts elevating the building above ground. Breakaway walls allow storage beneath.",
            "Long vertical posts of steel or concrete driven or cast deep into the ground below the building."));

    private final List<String> exteriorWallFinish = new LinkedList<>(Arrays.asList("Cement Fiber (Shingle)",
            SOLID_LOG_MEDIUM_9_12, "None - Included in Ext. Wall Construction", BRICK_SOLID,
            BRICK_SOLID_CUSTOM, "Brick Veneer", "Brick Veneer - Custom", "Cypress - Reclaimed",
            "Metal - Copper Shingle", "Siding - Alum. Or Metal", "Siding - Board and Batten",
            "Siding - Cedar (Clapboard)", "Siding - Cedar (Tongue & Groove)", "Siding - Cement Fiber (Clapboard)",
            "Siding - Hardboard/Masonite", "Siding - Pine (Tongue & Groove)", "Siding - Plywood (Vertical Groove)",
            "Siding - Redwood (Clapboard)", "Siding - Redwood (Tongue & Groove)", "Siding - Steel", "Siding - Vinyl",
            "Siding - Vinyl Shingles", "Siding - Log", SOLID_STONE, "Stone Veneer (Manufactured)",
            "Stone Veneer (Natural)", "Stucco - Synthetic (EIFS)", "Stucco - Traditional Hard Coat",
            "Wood Shingle/Shake", "Wood Shingle/Shake (Scalloped)", "Cut Limestone Veneer"));

    private final List<String> roofCovers = Arrays.asList("Composition - 3 Tab Shingle", "Composition - Architectural Shingle",
            "Tile - Concrete", "Tile - Clay", "Built-up (hot mopped) w/Gravel", "Metal - Tile/Shake",
            "Wood Shingles or Shakes", "Built-up (hot mopped) w/o Gravel", "Composition - Impact Resist. Shingle",
            "Composition - Roll Roofing", "Synthetic Composite Roofing", "Tile - Cement Fiber", "Tile - Glazed",
            "Metal - Standing Seam", "Metal - Copper Shingle", "Metal - Standing Seam Copper", "Metal - Corrugated Galvanized",
            "Slate", "Membrane - EPDM or PVC", "Sprayed Polyurethane Foam (SPF)");

    private final List<String> heatingSystems = Arrays.asList("Forced Air Heating System", "Elec. Base/Wall Heat (no. of units)",
            "Boiler/Hot Water Heating System", "Radiant Ceiling Heating System", "Radiant Floor Heating System",
            "Heat Pump - Heat/Cool System", "Duct-Free Heat/Cool Split System - 1 Zone",
            "Duct-Free Heat/Cool Split System - 2 Zone", "Duct-Free Heat/Cool Split System - 3 Zone",
            "Duct-Free Heat/Cool Split System - 4 Zone", "Geothermal - Heat/Cool System", "Wood Burning Furnace - Forced Air",
            "Wood Burning Furnace - Radiant Flr.");

    private final List<String> heatingSystemDescriptions = Arrays.asList(
            "Furnace with ducts and/or fan to move warm air throughout the home.",
            "Electric baseboard or wall heaters, with individual thermostats for each.",
            "Uses coal, oil, or other heat source to heat water or steam circulated through radiators.",
            "Heating elements embedded in the ceiling to give off heat to warm the structure.",
            "Hot water or electric heating elements installed in the floor to warm the structure.",
            "Central heat pump system that distributes heats or cools through central ductwork like a furnace.",
            EXTERIOR_HEAT_PUMP_TEXT,
            EXTERIOR_HEAT_PUMP_TEXT,
            EXTERIOR_HEAT_PUMP_TEXT,
            EXTERIOR_HEAT_PUMP_TEXT,
            "System which heats or cools by pumping heat from or to the earth.",
            "Exterior wood-burning furnace provides hot water  to an interior heating system with hot air ducts.",
            "Exterior wood-burning furnace provides hot water to pipes installed in the building floors, heating the floor."
            );

    private final List<String> fireplaces = Arrays.asList(SELECT, "Zero Clearance Fireplace", "Masonry Fireplace",
            "Masonry Fireplace - Custom", "Freestanding Wood/Gas Burning Stove", "Fireplace Insert", "Beehive Fireplace",
            "Chimney Only", NONE);

    private final List<String> garageCarports = Arrays.asList("1 Car", "2 Car", "3 Car", "4+ Cars");

    private final List<String> garageStyles = new LinkedList<>(Arrays.asList("Attached / Built-In", BASEMENT, "Carport", DETACHED, NO_GARAGE));

    private static final String ERROR1 = "Please enter number of stories";
    private static final String ERROR2 = "Please enter finished percentage of lowest level between 1-100";
    private static final String ERROR3 = "Please enter fireplace(s)";
    private static final String ERROR4 = "Please enter garage style";
    private static final String ERROR5 = "Please enter garage/carport";
    private static final String ERROR6 = "Please enter underground oil tank on premise";
    private static final String ERROR7 = "Please enter is there a pool or hot tub located on the premises?";
    private static final String ERROR8 = "Please enter how many units are attached to your residence?";

    @FindBy(xpath = "//mat-select[contains(@id,'numberOfStories')]")
    private WebElement selectNumberOfStories;

    private static final String SELECT_OPTIONS_XPATH = "//div[contains(@id,'matselect-panel')]//mat-option[.='%s']";
    private static final String SELECT_OPTION_XPATH = "//div[contains(@id,'matselect-panel')]//mat-option";
    @FindBy(xpath = SELECT_OPTION_XPATH)
    private WebElement dropdownOptionElement;

    private static final String SELECT_OPTIONS_STARTS_XPATH = "//div[contains(@class,'mat-select-panel')]//mat-option[starts-with(.,'%s')]";

    @FindBy(xpath = "//mat-select[@formcontrolname='foundationType']")
    private WebElement selectFoundationType;

    @FindBy(xpath = "//mat-select[@formcontrolname='heatingSystem']")
    private WebElement selectHeatingSystem;

    private static final String LIST_OPTIONS_XPATH = "//div[contains(@class,'mat-select-panel-wrap')]//mat-option";
    private final By selectListOptions = By.xpath(LIST_OPTIONS_XPATH);
    @FindBy(xpath = LIST_OPTIONS_XPATH)
    private WebElement selectListOptionsWe;

    private static final String FINISHED_PERCENT_XPATH = "//ui-farmers-input[starts-with(@fieldlabel,'Finished Percentage of Lowest Level')]";
    @FindBy(xpath = FINISHED_PERCENT_XPATH)
    private WebElement inputFinishedPercent;

    private static final String READY_FINISHED_PERCENT_XPATH = "//ui-farmers-input[starts-with(@fieldlabel,'Finished Percentage of Lowest Level')]//input";
    @FindBy(xpath = READY_FINISHED_PERCENT_XPATH)
    private WebElement readyInputFinishedPercent;

    private static final String ERROR_FINISHED_PERCENT_XPATH = "//ui-farmers-input[starts-with(@fieldlabel,'Finished Percentage of Lowest Level')]//mat-error";
    private final By errorFinishedPercentBy = By.xpath(ERROR_FINISHED_PERCENT_XPATH);
    @FindBy(xpath = ERROR_FINISHED_PERCENT_XPATH)
    private WebElement errorInputFinishedPercent;

    @FindBy(xpath = "//mat-select[@formcontrolname='exteriorWallFinish']")
    private WebElement selectExteriorWallFinish;

    private static final String SELECT_LIST_ITEMS_XPATH = "//mat-dialog-container//mat-list-item[.='%s']";
    private static final String SELECT_LIST_ITEMS_ANY_XPATH = "//mat-dialog-container//mat-list-item";
    @FindBy(xpath = SELECT_LIST_ITEMS_ANY_XPATH)
    private WebElement selectListElementAny;

    @FindBy(xpath = "//mat-select[@formcontrolname='roofCover']")
    private WebElement selectRoofCover;

    @FindBy(xpath = "//mat-select[@id='solarPanelQuestion_matselect']")
    private WebElement selectSolarPanels;

    @FindBy(xpath = "//mat-select[@id='trampolineQuestion_matselect']")
    private WebElement selectTrampoline;

    @FindBy(xpath = "//mat-select[@id='onlyPoolQuestion_matselect']")
    private WebElement selectPoolOnPremises;

    private static final String CARD_ITEM_DESCRIPTION_XPATH = "//mat-card/mat-card-content/span";
    @FindBy(xpath = CARD_ITEM_DESCRIPTION_XPATH)
    private WebElement cardItemDescription;

    private static final String SELECT_RADIOS_BYTEXT_XPATH = "//mat-dialog-container//mat-radio-button[contains(.,'%s')]";
    private static final String LIST_RADIOS_XPATH = "//mat-dialog-container//mat-radio-button//p";
    private static final By selectListRadios = By.xpath(LIST_RADIOS_XPATH);
    @FindBy(xpath = LIST_RADIOS_XPATH)
    private WebElement selectListRadiosWe;

    private static final String DONE_BUTTON_XPATH = "//mat-dialog-container//button[@aria-label='Done']";
    @FindBy(xpath = DONE_BUTTON_XPATH)
    private WebElement doneDialogButton;

    @FindBy(xpath = "//mat-select[@id='firePlaces_matselect']")
    private WebElement selectFireplaces;

    private static final String GARAGE_CARPORT_XPATH = "//mat-select[@id='garage_matselect']";
    @FindBy(xpath = GARAGE_CARPORT_XPATH)
    private WebElement selectGarageCarport;

    private static final String GARAGE_STYLE_XPATH = "//mat-select[@id='garageStyle_matselect']";
    final By garageStyleBy = By.xpath(GARAGE_STYLE_XPATH);
    @FindBy(xpath = GARAGE_STYLE_XPATH)
    private WebElement selectGarageStyle;

    private static final String OIL_TANK_ONPREMISES_XPATH = "//mat-select[contains(@id,'oilTank')]";
    final By oilTankOnPremisesBy = By.xpath(OIL_TANK_ONPREMISES_XPATH);
    @FindBy(xpath = OIL_TANK_ONPREMISES_XPATH)
    private WebElement undergroundOilTank;

    private static final String POOL_HOT_TUB_ONPREMISES_XPATH = "//mat-select[contains(@id,'poolQuestion')]";
    final By poolHotTubOnPremisesBy = By.xpath(POOL_HOT_TUB_ONPREMISES_XPATH);
    @FindBy(xpath = POOL_HOT_TUB_ONPREMISES_XPATH)
    private WebElement poolHotTubOnPremises;

    private static final String UNITS_ATTACHED_XPATH = "//mat-select[contains(@id,'unitsQuestion')]";
    final By unitsAttachedBy = By.xpath(UNITS_ATTACHED_XPATH);
    @FindBy(xpath = UNITS_ATTACHED_XPATH)
    private WebElement unitsAttached;

    @FindBy(xpath = "//farmers-home-quote-tooltip-modal//h4")
    private WebElement helpDialogTitle;

    @FindBy(xpath = "//farmers-home-quote-tooltip-modal//div[@class='mat-dialog-content']")
    private WebElement helpDialogContent;

    @FindBy(xpath = "//span[starts-with(@aria-label,'Number of stories')]//mat-icon")
    private WebElement helpNumberOfStories;

    @FindBy(xpath = "//span[starts-with(@aria-label,'Foundation type')]//mat-icon")
    private WebElement helpFoundationType;

    @FindBy(xpath = "//span[starts-with(@aria-label,'Finished Percentage of Lowest Level')]//mat-icon")
    private WebElement helpFinishedPercent;

    @FindBy(xpath = "//span[starts-with(@aria-label,'Exterior wall finish')]//mat-icon")
    private WebElement helpExteriorWallFinish;

    @FindBy(xpath = "//span[starts-with(@aria-label,'Roof Cover')]//mat-icon")
    private WebElement helpRoofCover;

    @FindBy(xpath = "//span[starts-with(@aria-label,'Floor covering')]//mat-icon")
    private WebElement helpFloorCovering;

    @FindBy(xpath = "//span[starts-with(@aria-label,'Heating system')]//mat-icon")
    private WebElement helpHeatingSystem;

    @FindBy(xpath = "//span[starts-with(@aria-label,'Fireplace(s)')]//mat-icon")
    private WebElement helpFireplaces;

    @FindBy(xpath = "//span[starts-with(@aria-label,'Garage/Carport')]//mat-icon")
    private WebElement helpGarageCarport;

    @FindBy(xpath = "//span[starts-with(@aria-label,'Garage Style')]//mat-icon")
    private WebElement helpGarageStyle;

    @FindBy(xpath = "//span[starts-with(@aria-label,'Underground Oil Tank')]//mat-icon")
    private WebElement helpUndergroundOilTank;

    @FindBy(xpath = "//span[starts-with(@aria-label,'How many units are attached')]//mat-icon")
    private WebElement helpNumberUfUnitsAttached;

    @FindBy(xpath = "//mat-dialog-actions//button[.='CLOSE']")
    private WebElement buttonCloseDialog;

    @FindBy(xpath = "//farmers-home-quote-property-details//farmers-home-quote-discount-journey//img[@id='clock-img']/../p")
    private WebElement discountSubTitleLock;

    private static final String DISCOUNT_LOCK_TEXT = "For your convenience, we used your address to pre-fill some information.";

    @FindBy(xpath = "//farmers-home-quote-property-details//farmers-home-quote-discount-journey//img[@id='lock-img']/../p")
    private WebElement discountSubTitlePiggy;

    private static final String DISCOUNT_PIGGY_TEXT = "otential savings/discounts. Let's find some more.";

    @FindBy(xpath ="//farmers-home-quote-property-details//div[@class='discount-journey-card']//mat-icon[text()='info']")
    private WebElement discountHelpButtonPiggy;

    @FindBy(xpath = "//farmers-home-quote-discount-journey-dialog//h4")
    private WebElement discountHelpDialogTitle;

    private static final String DISCOUNT_HELP_DIALOG_TITLE = "Potential savings/discounts ($)";

    private static final String CONTENT_XPATH = "//farmers-home-quote-discount-journey-dialog//li";
    @FindBy(xpath = CONTENT_XPATH)
    private WebElement discountHelpDialogContent;

    private static final String NUMBER_OF_STORIES_HELP_TITLE = "Number of stories";
    private static final String NUMBER_OF_STORIES_HELP_CONTENT = "Number of finished living levels in your home.";

    private static final String FOUNDATION_TYPE_HELP_TITLE = "Foundation type";
    private static final String FOUNDATION_TYPE_HELP_CONTENT = "The type of foundation your house predominately has \u2014 " +
            "whether a basement, crawlspace or concrete slab.";

    private static final String FINISHED_PERCENT_HELP_TITLE = "Finished Percentage Of Lowest Level";
    private static final String FINISHED_PERCENT_HELP_CONTENT = "Finished includes all living space (closets and stairwells) " +
            "that is heated and/or cooled. It has finished ceilings, and has floor covering.";

    private static final String EXTERIOR_WALL_FINISH_HELP_TITLE = "Exterior Wall finish";
    private static final String EXTERIOR_WALL_FINISH_HELP_CONTENT = "The material that predominately covers your exterior walls " +
            "\u2014 like wood siding, brick or stucco.";

    private static final String ROOF_COVER_HELP_TITLE = "Roof cover";
    private static final String ROOF_COVER_HELP_CONTENT = "The type of material predominately installed on your roof \u2014 " +
            "like shingles, metal or membrane.";

    private static final String HEATING_SYSTEM_HELP_TITLE = "Heating system";
    private static final String HEATING_SYSTEM_HELP_CONTENT = "The type of Heating System at your House - Forced Air " +
            "Heating system/Boiler Hot water Heating system/Radiant ceiling /Floor Heating system/ Duct Free Heating system etc";

    private static final String FIREPLACES_HELP_TITLE = "Fireplace(s)";
    private static final String FIREPLACES_HELP_CONTENT = "The type of fireplaces in your home that you believe has the highest " +
            "replacement cost \u2014 like masonry, freestanding stoves or fireplace inserts.";

    private static final String GARAGE_CARPORT_HELP_TITLE = "Garage/Carport";
    private static final String GARAGE_CARPORT_HELP_CONTENT = "The type of vehicle shelter at your house that you believe that has " +
            "the highest replacement cost \u2014 like an attached garage, basement garage or carport.";

    private static final String GARAGE_STYLE_HELP_TITLE = "Garage Style";
    private static final String GARAGE_STYLE_HELP_CONTENT = "Select the garage/carport style of your house. Attached garages " +
            "share a wall(s) with the home, built-in garages have living space above, and basement garages share the " +
            "lowest level of the home with living space above.";

    private static final String UNDERGROUND_OIL_TANK_HELP = "Underground Oil Tank On Premise";
    private static final String UNDERGROUND_OIL_TANK_CONTENT = "Please let us know if your property has an Underground Oil Tank " +
            "used currently or previously as a heating source for the dwelling.";

    private static final String NUMBER_OF_UNITS_ATTACHED_HELP = "Units Within Your Building";
    private static final String NUMBER_OF_UNITS_ATTACHED_CONTENT = "A unit is part of a structure designed as a complete living " +
            "quarters and does not share access with other residents of the structure or building.";

    @FindBy(xpath = "//farmers-home-quote-property-details//h1[@id='header-text']")
    private WebElement textPageTitle;

    @FindBy(xpath = "//farmers-home-quote-property-details//span[contains(@class,'tui-subtitle-text-1')]")
    private WebElement textPageSubTitle;

    @FindBy(xpath = "//farmers-home-quote-property-details//ui-farmers-card//p[contains(@class,'sub-title-one')]")
    private WebElement textPageCardSubtitle;

    private static final String SUBTITLE_TEXT = "If you want a more comprehensive estimate, please contact a Farmers\u00ae " +
            "Agent to add additional details about your home.";

    private static final String SUBTITLE_TEXT_KY = "If you want a more comprehensive estimate, please contact a Farmers\u00ae " +
            "Representative to add additional details about your home.";

    private static final String CARD_SUBTITLE_TEXT = "We were able to retrieve this information about your home. If these details " +
            "look up to date you can skip to the next step.";

    private final List<String> listNoYes = Arrays.asList(NO, YES);

    private final List<String> numberOfUnitsAttachedList = Arrays.asList("1-2", "3-4", "5+");

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public PropertyDetailsPage() throws Exception {
        super();
        waitElementBeVisible(selectNumberOfStories);
        if (getTextFromElement(selectNumberOfStories).isBlank()) {
            driver().navigate().refresh();
            waitElementBeVisible(selectNumberOfStories);
            if (getTextFromElement(selectNumberOfStories).isBlank()) {
                clickBack();
                clickBack();
                clickButtonNext();
                clickButtonNext();
                waitElementBeVisible(selectNumberOfStories);
            }
        }
    }

    public void setRequiredFields(ApplicantHQM applicant, FarmersSoftAssert fsa, @Nullable PrefillResponseHQM propertyData) throws Exception {
        sleep(1);
        if (!applicant.keep360Prefill) {
            Log.info("Going to modify pre-selected 360 values.");
            selectNumberOfStories(applicant.numberOfStories);
            selectFoundationType(applicant.foundationType);
            selectExteriorWallFinish(applicant.exteriorWallFinish);
            selectRoofCover(applicant.roofCover);
            selectHeatingSystem(applicant.heatingSystem);
            selectFireplaces(applicant.fireplaces);
            selectGarageStyle(applicant.garageStyle);
            if (applicant.stateCode.equals(NC)) {
                selectPoolHotTubOnPremises(applicant.poolOnPremises);
                selectUnitsAttached(applicant.unitsAttached);
            }
            if (!StringUtils.isEmpty(applicant.garageStyle) &&
                    !applicant.garageStyle.equals(NO_GARAGE) &&
                    !applicant.garageStyle.equals(DETACHED)) {
                selectGarageCarport(applicant.garageCarport);
            }
            if (applicant.stateCode.equals(NC)) {
                if (isElementPresentByID(poolHotTubOnPremises)) {
                    if (!getPoolHotTubOnPremises().equals(applicant.poolOnPremises)) {
                        selectPoolHotTubOnPremises(applicant.poolOnPremises);
                    }
                }
                if (isElementPresentByID(unitsAttached)) {
                    if (!getUnitsAttached().equals(applicant.unitsAttached)) {
                        selectUnitsAttached(applicant.unitsAttached);
                    }
                }
            }
            if (isFlexState(applicant.stateCode)) {
                selectSolarPanelsOnPremises(applicant.solarPanels);
                selectTrampolineOnPremises(applicant.trampoline);
                selectPoolOnPremises(applicant.poolOnPremises);
            }
        } else {
            if (getSelectedGarageStyle().isEmpty()) {
                if ((propertyData != null) && (propertyData.getGarageStyle() != null)) {
                    selectGarageStyle(propertyData.getGarageStyle());
                } else {
                    selectGarageStyle(applicant.garageStyle);
                }
                if (!StringUtils.isEmpty(applicant.garageStyle) &&
                        !applicant.garageStyle.equals(NO_GARAGE) &&
                        !applicant.garageStyle.equals(DETACHED)) {
                    selectGarageCarport(applicant.garageCarport);
                }
            }
            getSelectedGarageCarport(); // to mitigate the case when Garage Style drop-down is not populated until refresh
            if (isFlexState(applicant.stateCode) && (getSolarPanelsOnPremises() != null)) {
                if (getSolarPanelsOnPremises().isEmpty()) {
                    selectSolarPanelsOnPremises(applicant.solarPanels);
                }
                if (getTrampolineOnPremises().isEmpty()) {
                    selectTrampolineOnPremises(applicant.trampoline);
                }
                if (getPoolOnPremises().isEmpty()) {
                    selectPoolOnPremises(applicant.poolOnPremises);
                }
            }
        }
        if (this.getSelectedFoundationType().toLowerCase().contains(LOWERCASE_BASEMENT)) {
            String finishedPercent;
            if ((propertyData != null) && (propertyData.getFinishedPercentOfLowestLevel() != null)) {
                finishedPercent = propertyData.getFinishedPercentOfLowestLevel().equals("0") ?
                        applicant.finishedPercentOfLowestLevel : propertyData.getFinishedPercentOfLowestLevel();
            } else {
                finishedPercent = applicant.finishedPercentOfLowestLevel;
            }
            String displayedPercent = this.getFinishedPercentReadyInput();
            if (!displayedPercent.equals(finishedPercent)) {
                setFinishedPercent(finishedPercent);
                sendKeysToElement(readyInputFinishedPercent, Keys.TAB);
            } else if (displayedPercent.isBlank()) {
                setFinishedPercent("100");
            }
        }
        if ((applicant.foundationType != null) && (propertyData != null)){ // avoid fields verification, if the values are not set
            verifyPageFieldSelections(applicant, fsa, propertyData);
        }
    }

    public void selectNumberOfStories(String numberOfStories) throws Exception {
        String numOfStories = getSelectedNumberOfStories();
        Log.info("Number of stories selected: " + numOfStories + ";  Selecting now: " + numberOfStories);
        if (StringUtils.isEmpty(numberOfStories) || numberOfStories.equals(numOfStories)) {
            return;
        }
        switch (numberOfStories) {
            case "1":
                numberOfStories = "1 Story";
                break;
            case "1 1/2":
                numberOfStories = "1 1/2 Stories (Attic)";
                break;
            case "2":
                numberOfStories = "2 Stories";
                break;
            case "2 1/2":
                numberOfStories = "2 1/2 Stories (Attic)";
                break;
            case "3":
                numberOfStories = "3 Stories";
                break;
            case "3 1/2":
                numberOfStories = "3 1/2 Stories (Attic)";
                break;
            case "4":
                numberOfStories = FOUR_STORIES;
                break;
            case "Bi-Level":
                numberOfStories = "Bi-Level (Raised Ranch)";
                break;
            case SPLIT_LEVEL:
                numberOfStories = SPLIT_LEVEL;
                break;
        }
        waitAndClickElement(selectNumberOfStories);
        WebElement optionWe = driver().findElement(By.xpath(String.format(SELECT_OPTIONS_XPATH, numberOfStories)));
        waitAndClickElement(optionWe);
    }

    public String getSelectedNumberOfStories() throws Exception {
        waitElementBeVisible(selectNumberOfStories);
        if (getTextFromElement(selectNumberOfStories).isBlank()) {
            driver().navigate().refresh();
            waitElementBeVisible(selectNumberOfStories);
        }
        return getTextFromElement(selectNumberOfStories);
    }

    public List<String> getAvailableNumberOfStories() throws Exception {
        waitAndClickElement(selectNumberOfStories);
        Thread.sleep(500);
        List<String> listAvailableNumberOfStories = driver().findElements(selectListOptions).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        listAvailableNumberOfStories.remove(SELECT);
        listAvailableNumberOfStories.remove("");
        sendKeysToElement(selectNumberOfStories,Keys.ESCAPE);
        System.out.println(">> Available Number of stories: " + listAvailableNumberOfStories);
        return listAvailableNumberOfStories;
    }

    public List<String> getAvailableRoofCovers() throws Exception {
        waitAndClickElement(selectRoofCover);
        Thread.sleep(500);
        waitElementBeVisible(driver().findElement(By.xpath(SELECT_LIST_ITEMS_ANY_XPATH)));
        List<String> listAvailableRoofCovers = driver().findElements(By.xpath(SELECT_LIST_ITEMS_ANY_XPATH)).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        waitAndClickElement(doneDialogButton);
        System.out.println(">> Available Roof Covers: " + listAvailableRoofCovers);
        return listAvailableRoofCovers;
    }

    public void verifyAvailableHeatingSystems() throws Exception {
        waitAndClickElement(selectHeatingSystem);
        Thread.sleep(500);
        List<String> listAvailableHeatingSystems = driver().findElements(selectListRadios).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        List<String> listHeatingSystemDescriptions = driver().findElements(By.xpath(CARD_ITEM_DESCRIPTION_XPATH)).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        waitAndClickElement(doneDialogButton);
        System.out.println(">> Available Heating Systems: " + listAvailableHeatingSystems);
        Assert.assertEquals(listAvailableHeatingSystems, heatingSystems, "Property Details page - Available Heating Systems");
        Assert.assertEquals(listHeatingSystemDescriptions, heatingSystemDescriptions, "Property Details page - Heating Systems Descriptions");
    }

    public List<String> getAvailableFireplaces() throws Exception {
        waitAndClickElement(selectFireplaces);
        Thread.sleep(500);
        List<String> listAvailableFireplaces = driver().findElements(selectListOptions).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        sendKeysToElement(selectFireplaces,Keys.ESCAPE);
        System.out.println(">> Available Fireplace(s): " + listAvailableFireplaces);
        return listAvailableFireplaces;
    }

    public List<String> getAvailableGarageCarports() throws Exception {
        waitAndClickElement(selectGarageCarport);
        Thread.sleep(500);
        List<String> listGarageCarports = driver().findElements(selectListOptions).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        listGarageCarports.remove(SELECT);
        listGarageCarports.remove("");
        selectGarageCarport.sendKeys(Keys.ESCAPE);
        System.out.println(">> Available Garage/Carports: " + listGarageCarports);
        return listGarageCarports;
    }

    public List<String> getAvailableGarageStyles() throws Exception {
        waitAndClickElement(selectGarageStyle);
        Thread.sleep(500);
        List<String> listGarageStyles = driver().findElements(selectListOptions).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        listGarageStyles.remove(SELECT);
        listGarageStyles.remove("");
        selectGarageStyle.sendKeys(Keys.ESCAPE);
        System.out.println(">> Available Garage Styles: " + listGarageStyles);
        return listGarageStyles;
    }

    public void selectFoundationType(String foundationType) throws Exception {
        String foundation = getSelectedFoundationType();
        Log.info("Foundation type selected: " + foundation + ";  Selecting now: " + foundationType);
        if (StringUtils.isEmpty(foundationType) || foundationType.equals(foundation)) {
            return;
        }
        waitAndClickElement(selectFoundationType);
        WebElement optionWe = driver().findElement(By.xpath(String.format(SELECT_RADIOS_BYTEXT_XPATH, foundationType)));
        scrollAndClickOnElement(optionWe);
        waitAndClickElement(doneDialogButton);
    }

    public String getSelectedFoundationType() {
        return getTextFromElement(selectFoundationType);
    }

    public void setFinishedPercent(String finishedPercent) throws Exception {
        if (StringUtils.isEmpty(finishedPercent) || finishedPercent.equals(getFinishedPercent())) {
            return;
        }
        waitAndClickElement(inputFinishedPercent);
        sendKeysToElement(readyInputFinishedPercent, finishedPercent);
    }

    public String getFinishedPercent() throws Exception {
        if (isElementDisplayed(By.xpath(FINISHED_PERCENT_XPATH))) {
            waitElementBeVisible(inputFinishedPercent);
            return getTextFromElement(inputFinishedPercent);
        } else {
            return null;
        }
    }

    public String getFinishedPercentReadyInput() {
        return getAttributeData(readyInputFinishedPercent, VALUE).trim();
    }

    public String getFinishedPercentError() throws Exception {
        String errorText = null;
        sleep(1);
        if (isElementDisplayed(errorFinishedPercentBy)) {
            errorText = getTextFromElement(errorInputFinishedPercent);
        }
        return errorText;
    }

    public void selectExteriorWallFinish(String exteriorWallFinish) throws Exception {
        if (StringUtils.isEmpty(exteriorWallFinish) || exteriorWallFinish.equals(getSelectedExteriorWallFinish())) {
            return;
        }
        waitAndClickElement(selectExteriorWallFinish);
        WebElement optionWe = driver().findElement(By.xpath(String.format(SELECT_LIST_ITEMS_XPATH, exteriorWallFinish)));
        waitAndClickElement(optionWe);
    }

    public String getSelectedExteriorWallFinish() {
        return getTextFromElement(selectExteriorWallFinish);
    }

    public void selectRoofCover(String roofCover) throws Exception {
        if (StringUtils.isEmpty(roofCover) || roofCover.equals(getSelectedRoofCover())) {
            return;
        }
        waitAndClickElement(selectRoofCover);
        WebElement optionWe = driver().findElement(By.xpath(String.format(SELECT_LIST_ITEMS_XPATH, roofCover)));
        waitAndClickElement(optionWe);
    }

    public String getSelectedRoofCover() {
        return getTextFromElement(selectRoofCover);
    }

    public void selectHeatingSystem(String heatingSystem) throws Exception {
        if (StringUtils.isEmpty(heatingSystem) || heatingSystem.equals(getSelectedHeatingSystem())) {
            return;
        }
        waitAndClickElement(selectHeatingSystem);
        WebElement optionWe = driver().findElement(By.xpath(String.format(SELECT_RADIOS_BYTEXT_XPATH, heatingSystem)));
        scrollAndClickOnElement(optionWe);
        waitAndClickElement(doneDialogButton);
    }

    public String getSelectedHeatingSystem() {
        return getTextFromElement(selectHeatingSystem);
    }

    public void selectFireplaces(String fireplaces) throws Exception {
        if (StringUtils.isEmpty(fireplaces) || fireplaces.equals(getSelectedFireplaces())) {
            return;
        }
        waitAndClickElement(selectFireplaces);
        WebElement optionWe = driver().findElement(By.xpath(String.format(SELECT_OPTIONS_XPATH, fireplaces)));
        waitAndClickElement(optionWe);
    }

    public String getSelectedFireplaces() {
        return getTextFromElement(selectFireplaces);
    }

    public void selectGarageCarport(String garageCarport) throws Exception {
        if (StringUtils.isEmpty(garageCarport) || getSelectedGarageCarport().startsWith(garageCarport)) {
            return;
        }
        waitAndClickElement(selectGarageCarport);
        driverWait(Property.PAGELOADTIMEOUT).until(ExpectedConditions.visibilityOf(dropdownOptionElement));
        garageCarport = garageCarport.startsWith("4+ Cars (781") ? "4+ Cars (781" : garageCarport; // there's &nbsp; in this xpath
        WebElement optionWe = driver().findElement(By.xpath(String.format(SELECT_OPTIONS_STARTS_XPATH, garageCarport)));
        waitAndClickElement(optionWe);
    }

    public String getSelectedGarageCarport() throws Exception {
        String garageCarport = null;
        if (isElementDisplayed(By.xpath(GARAGE_CARPORT_XPATH))) {
            scrollToElement(selectGarageCarport);
            garageCarport = getTextFromElement(selectGarageCarport);
        }
        return garageCarport;
    }

    public void selectGarageStyle(String garageStyle) throws Exception {
        waitAndClickElement(selectGarageStyle);
        driverWait(Property.PAGELOADTIMEOUT).until(ExpectedConditions.visibilityOf(dropdownOptionElement));
        WebElement optionWe = driver().findElement(By.xpath(String.format(SELECT_OPTIONS_XPATH, garageStyle)));
        waitAndClickElement(optionWe);
    }

    public String getSelectedGarageStyle() throws Exception {
        List<WebElement> garageStyleWe = driver().findElements(garageStyleBy);
        if (!garageStyleWe.isEmpty()) {
            waitElementBeVisible(selectGarageStyle);
            if (getTextFromElement(selectGarageStyle).isBlank()) {
                Log.warn("Property Details page - Garage Style field was not pre-populated.");
                driver().navigate().refresh();
                driverWait(Property.PAGELOADTIMEOUT).until(ExpectedConditions.visibilityOf(selectGarageStyle));
            }
            return getTextFromElement(selectGarageStyle);
        } else {
            return null;
        }
    }

    public String getMatSelect(WebElement selectWe) {
        if (isElementPresentByID(selectWe)) {
            return getTextFromElement(selectWe);
        } else {
            return null;
        }
    }

    public void selectMatSelect (WebElement selectWe, String value) throws Exception {
        scrollToElement(selectWe);
        waitAndClickElement(selectWe);
        Thread.sleep(500);
        List<WebElement> listOptionsWe = driver().findElements(By.xpath(SELECT_OPTION_XPATH));
        for (WebElement we: listOptionsWe) {
            if (getTextFromElement(we).equals(value)) {
                waitAndClickElement(we);
                break;
            }
        }
        driverWait(5).until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(SELECT_OPTION_XPATH)));
    }

    public List<String> getAvailableMatSelectOptions(WebElement selectWe) throws Exception {
        scrollAndClickOnElement(selectWe);
        Thread.sleep(500);
        List<String> listOptions = driver().findElements(selectListOptions).stream()
                .map(this::getTextFromElement).filter(op -> !op.equals(SELECT)).collect(Collectors.toList());
        selectWe.sendKeys(Keys.ESCAPE);
        System.out.println(">> matSelect Available Options: " + listOptions);
        return listOptions;
    }

    public String getOilTankOnPremises() {
        return getMatSelect(undergroundOilTank);
    }

    public void selectOilTankOnPremises(String oilTank) throws Exception {
        selectMatSelect(undergroundOilTank, oilTank);
    }

    public List<String> getAvailableOilTank() throws Exception {
        return getAvailableMatSelectOptions(undergroundOilTank);
    }

    public String getPoolHotTubOnPremises() throws Exception {
        return getMatSelect(poolHotTubOnPremises);
    }

    public void selectPoolHotTubOnPremises(String poolOnPrem) throws Exception {
        selectMatSelect(poolHotTubOnPremises, poolOnPrem);
    }

    public List<String> getAvailablePoolHotTub() throws Exception {
        return getAvailableMatSelectOptions(poolHotTubOnPremises);
    }

    public String getUnitsAttached() {
        return getMatSelect(unitsAttached);
    }

    public void selectUnitsAttached(String unitsAttachedVal) throws Exception {
        selectMatSelect(unitsAttached, unitsAttachedVal);
    }

    public List<String> getAvailableNumberOfUnitsAttached() throws Exception {
        return getAvailableMatSelectOptions(unitsAttached);
    }

    public String getPoolOnPremises() {
        return getMatSelect(selectPoolOnPremises);
    }

    public void selectPoolOnPremises(String poolOnPrem) throws Exception {
        selectMatSelect(selectPoolOnPremises, poolOnPrem);
    }

    public List<String> getAvailablePoolOnPrem() throws Exception {
        return getAvailableMatSelectOptions(selectPoolOnPremises);
    }

    public String getTrampolineOnPremises() {
        return getMatSelect(selectTrampoline);
    }

    public void selectTrampolineOnPremises(String trampoline) throws Exception {
        selectMatSelect(selectTrampoline, trampoline);
    }

    public List<String> getAvailableTrampolineOnPrem() throws Exception {
        return getAvailableMatSelectOptions(selectTrampoline);
    }

    public String getSolarPanelsOnPremises() {
        return getMatSelect(selectSolarPanels);
    }

    public void selectSolarPanelsOnPremises(String solarPanelsOnPrem) throws Exception {
        selectMatSelect(selectSolarPanels, solarPanelsOnPrem);
    }

    public List<String> getAvailableSolarPanelsOnPrem() throws Exception {
        return getAvailableMatSelectOptions(selectSolarPanels);
    }

    public void verifyPageFieldSelections(ApplicantHQM applicant, FarmersSoftAssert fsa, @Nullable PrefillResponseHQM propertyData) throws Exception {
        if (applicant.keep360Prefill && (propertyData != null)) {
            fsa.assertEquals(getSelectedNumberOfStories(), propertyData.getNumberOfStories(), "Property Details page - Verify Number of stories");
            fsa.assertEquals(getSelectedFoundationType(), propertyData.getFoundationType(), "Property Details page - Verify Foundation type");
            if (propertyData.getFoundationType().toLowerCase().contains(LOWERCASE_BASEMENT)) {
                String finishedPercent = getFinishedPercentReadyInput();
                if ((Integer.parseInt(propertyData.getFinishedPercentOfLowestLevel()) > 0) &&
                        (Integer.parseInt(propertyData.getFinishedPercentOfLowestLevel()) <= 100)) {
                    fsa.assertEquals(finishedPercent, propertyData.getFinishedPercentOfLowestLevel(),
                            "Property Details page - Verify Finished Percentage of Lowest Level vs. Postgres");
                } else if (applicant.finishedPercentOfLowestLevel.isBlank()) {
                    fsa.assertEquals(finishedPercent, "100", "Property Details page - Verify Finished Percentage of Lowest Level");
                }
            }
            fsa.assertEquals(getSelectedExteriorWallFinish(), propertyData.getExteriorWallFinish(), "Property Details page - Verify exterior wall finish");
            fsa.assertEquals(getSelectedRoofCover(), propertyData.getRoofCover(), "Property Details page - Verify Roof Cover");
            fsa.assertEquals(getSelectedHeatingSystem(), propertyData.getHeatingSystem(), "Property Details page - Verify Heating system");
            fsa.assertEquals(getSelectedFireplaces(), propertyData.getFireplaces(), "Property Details page - Verify Fireplace(s)");
            fsa.assertEquals(getSelectedGarageCarport(), propertyData.getGarageCarport(), "Property Details page - Verify Garage/Carport");
            fsa.assertEquals(getSelectedGarageStyle(), propertyData.getGarageStyle(), "Property Details page - Verify Garage Style");
            if (Arrays.asList(MA,LA).contains(applicant.stateCode)) {
                fsa.assertEquals(getOilTankOnPremises(), propertyData.getOilTankOnPremises(), "Property Details page - Underground Oil Tank On Premise vs. Postgres");
            }
            if (applicant.stateCode.equals(NC)) {
                fsa.assertEquals(getPoolHotTubOnPremises(), propertyData.getPoolHotTubOnPremises(), "Property Details page - Pool or Hot Tub On Premises vs. Postgres");
                fsa.assertEquals(getUnitsAttached(), propertyData.getUnitsAttached(), "Property Details page - Units attached to you residence vs. Postgres");
            }
            if (isFlexState(applicant.stateCode) && (getSolarPanelsOnPremises() != null)) {
                String solarPanels = propertyData.getSolarPanelsOnPremises();
                solarPanels = (solarPanels == null || solarPanels.equals("")) ? applicant.solarPanels : solarPanels;
                fsa.assertEquals(getSolarPanelsOnPremises(), solarPanels, "Property Details page - Solar Panels On Premises vs. Postgres");

                String trampoline = propertyData.getTrampolineOnPremises();
                trampoline = (trampoline == null || trampoline.equals("")) ? applicant.trampoline : trampoline;
                fsa.assertEquals(getTrampolineOnPremises(), trampoline, "Property Details page - Trampoline On Premises vs. Postgres");

                String pool = propertyData.getPoolOnPremises();
                pool = (pool == null || pool.equals("")) ? applicant.poolOnPremises : pool;
                fsa.assertEquals(getPoolOnPremises(), pool, "Property Details page - Pool On Premises vs. Postgres");
            }
        } else {
            fsa.assertEquals(getSelectedNumberOfStories(), applicant.numberOfStories, "Property Details page - Verify Number of stories");
            fsa.assertEquals(getSelectedFoundationType(), applicant.foundationType, "Property Details page - Verify Foundation type");
            if (applicant.foundationType.toLowerCase().contains(LOWERCASE_BASEMENT)) {
                String finishedPercent = getFinishedPercentReadyInput();
                if ((Integer.parseInt(applicant.finishedPercentOfLowestLevel) > 0) &&
                        (Integer.parseInt(applicant.finishedPercentOfLowestLevel) <= 100)) {
                    fsa.assertEquals(finishedPercent, applicant.finishedPercentOfLowestLevel,
                            "Property Details page - Verify Finished Percentage of Lowest Level");
                } else {
                    fsa.assertEquals(finishedPercent, "100", "Property Details page - Verify Finished Percentage of Lowest Level");
                }
            }
            fsa.assertEquals(getSelectedExteriorWallFinish(), applicant.exteriorWallFinish, "Property Details page - Verify exterior wall finish");
            fsa.assertEquals(getSelectedRoofCover(), applicant.roofCover, "Property Details page - Verify Roof Cover");
            fsa.assertEquals(getSelectedHeatingSystem(), applicant.heatingSystem, "Property Details page - Verify Heating system");
            fsa.assertEquals(getSelectedFireplaces(), applicant.fireplaces, "Property Details page - Verify Fireplace(s)");
            fsa.assertEquals(getSelectedGarageCarport(), applicant.garageCarport, "Property Details page - Verify Garage/Carport");
            fsa.assertEquals(((getSelectedGarageStyle() == null) ? "" : getSelectedGarageStyle()),
                    applicant.garageStyle, "Property Details page - Verify Garage Style");
            if (Arrays.asList(MA,LA).contains(applicant.stateCode)) {
                fsa.assertEquals(getOilTankOnPremises(), applicant.oilTankOnPremise, "Property Details page - Underground Oil Tank On Premise vs. Postgres");
            }
            if (applicant.stateCode.equals(NC)) {
                fsa.assertEquals(getPoolHotTubOnPremises(), applicant.poolOnPremises, "Property Details page - Pool or Hot Tub On Premises");
                fsa.assertEquals(getUnitsAttached(), applicant.unitsAttached, "Property Details page - Units attached to you residence");
            }
            if (isFlexState(applicant.stateCode) && (getSolarPanelsOnPremises() != null)) {
                fsa.assertEquals(getSolarPanelsOnPremises(), applicant.solarPanels, "Property Details page - Solar Panels On Premises");
                fsa.assertEquals(getTrampolineOnPremises(), applicant.trampoline, "Property Details page - Trampoline On Premises");
                fsa.assertEquals(getPoolOnPremises(), applicant.poolOnPremises, "Property Details page - Pool On Premises");
            }
        }
    }

    public void verifyExteriorWallFinish(ApplicantHQM applicant) throws Exception {
        waitAndClickElement(selectExteriorWallFinish);
        waitElementBeVisibleClickable(selectListElementAny);
        List<String> listExteriorWallFinishes = driver().findElements(By.xpath(SELECT_LIST_ITEMS_ANY_XPATH)).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        System.out.println(">> Actual Exterior Wall Finishes: " + listExteriorWallFinishes);
        listExteriorWallFinishes.remove("");
        listExteriorWallFinishes.sort(Comparator.naturalOrder());
        switch (applicant.exteriorWallConstruction) {
            case "FRW":
                exteriorWallFinish.remove("None - Included in Ext. Wall Construction");
                exteriorWallFinish.remove(BRICK_SOLID);
                exteriorWallFinish.remove(SOLID_LOG_MEDIUM_9_12);
                exteriorWallFinish.remove(BRICK_SOLID_CUSTOM);
                exteriorWallFinish.remove(SOLID_STONE);
                break;
            case "BL":
            case "CONC":
            case "SBR":
                exteriorWallFinish.remove(BRICK_SOLID);
                exteriorWallFinish.remove(SOLID_LOG_MEDIUM_9_12);
                exteriorWallFinish.remove(BRICK_SOLID_CUSTOM);
                exteriorWallFinish.remove(SOLID_STONE);
                break;
            case "N":
                exteriorWallFinish.clear();
                exteriorWallFinish.add(BRICK_SOLID);
                exteriorWallFinish.add(SOLID_LOG_MEDIUM_9_12);
                exteriorWallFinish.add(BRICK_SOLID_CUSTOM);
                exteriorWallFinish.add(SOLID_STONE);
                break;
        }
        exteriorWallFinish.sort(Comparator.naturalOrder());
        Assert.assertEquals(listExteriorWallFinishes,
                exteriorWallFinish, "List of available Exterior Wall Finishes");
        waitAndClickElement(doneDialogButton);
    }

    public void verifyFoundationTypes(ApplicantHQM applicant) throws Exception {
        String displayedPercent = null;
        if (getSelectedFoundationType().contains(BASEMENT)) {
            displayedPercent = getFinishedPercentReadyInput();
        }
        waitAndClickElement(selectFoundationType);
        Thread.sleep(500);
        waitElementBeVisibleClickable(selectListRadiosWe);
        List<String> listFoundationTypes = driver().findElements(selectListRadios).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        List<String> listFoundationTypeDescriptions = driver().findElements(By.xpath(CARD_ITEM_DESCRIPTION_XPATH)).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        waitAndClickElement(doneDialogButton);
        if (applicant.numberOfStories.equals(FOUR_STORIES)) {
            foundationTypes = foundationTypes.subList(0, 4);
            foundationTypeDescriptions = foundationTypeDescriptions.subList(0,4);
        }
        System.out.println(">>  Actual: " + listFoundationTypes);
        Assert.assertEquals(listFoundationTypes, foundationTypes, "List of available Foundation Types");
        Assert.assertEquals(listFoundationTypeDescriptions, foundationTypeDescriptions, "List of Foundation Types Descriptions.");
        // restore finished percent value, because it gets cleared after accessing foundation drop-down
        if (getSelectedFoundationType().contains(BASEMENT)) {
            Thread.sleep(500);
            String finishedPercent2 = getFinishedPercentReadyInput();
            if (finishedPercent2.isEmpty() || finishedPercent2.startsWith("Finished Percentage of Lowest Level")) {
                if ((Integer.parseInt(0 + displayedPercent) < 1) ||
                        (Integer.parseInt(0 + displayedPercent) > 100)) {
                    setFinishedPercent("100");
                } else {
                    setFinishedPercent(displayedPercent);
                }
                sendKeysToElement(readyInputFinishedPercent, Keys.TAB);
            }
        }
    }

    public void validateHelpDialogs(FarmersSoftAssert fsa, @Nullable StaticContentHQM staticContent) throws Exception {
        waitAndClickElement(helpNumberOfStories);
        sleep(1);  // waitElementBeVisible(helpDialogTitle);
        fsa.assertEquals(getTextFromElement(helpDialogTitle), NUMBER_OF_STORIES_HELP_TITLE, "Number of stories Help Title validated.");
        fsa.assertEquals(getTextFromElement(helpDialogContent), NUMBER_OF_STORIES_HELP_CONTENT, "Number of stories Help Content validated.");
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getPropertyDetailsHelpStories(), NUMBER_OF_STORIES_HELP_CONTENT, "Number of stories Help Content validated (AEM).");
        }
        waitAndClickElement(buttonCloseDialog);
        //
        waitAndClickElement(helpFoundationType);
        sleep(1);  // waitElementBeVisible(helpDialogTitle);
        fsa.assertEquals(getTextFromElement(helpDialogTitle), FOUNDATION_TYPE_HELP_TITLE, "Foundation Type Help Title validated.");
        fsa.assertEquals(getTextFromElement(helpDialogContent), FOUNDATION_TYPE_HELP_CONTENT, "Foundation Type Help Content validated.");
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getPropertyDetailsHelpFoundationType(), FOUNDATION_TYPE_HELP_CONTENT,
                    "Foundation Type Help Content validated (AEM).");
        }
        waitAndClickElement(buttonCloseDialog);
        //
        if (checkIfElementIsDisplayed(inputFinishedPercent, 3)) {
            waitAndClickElement(helpFinishedPercent);
            Thread.sleep(500);  // waitElementBeVisible(helpDialogTitle);
            fsa.assertEquals(getTextFromElement(helpDialogTitle), FINISHED_PERCENT_HELP_TITLE, "Finished Percentage Of Lowest Level Help Title validated.");
            fsa.assertEquals(getTextFromElement(helpDialogContent), FINISHED_PERCENT_HELP_CONTENT, "Finished Percentage Of Lowest Level Help Content validated.");
            if (staticContent != null) {
                fsa.assertEquals(staticContent.getPropertyDetailsHelpFinishedLevel(), FINISHED_PERCENT_HELP_CONTENT,
                        "Finished Percentage Of Lowest Level Help Content validated (AEM).");
            }
            waitAndClickElement(buttonCloseDialog);
        }
        //
        waitAndClickElement(helpExteriorWallFinish);
        sleep(1);  // waitElementBeVisible(helpDialogTitle);
        fsa.assertEquals(getTextFromElement(helpDialogTitle), EXTERIOR_WALL_FINISH_HELP_TITLE, "Exterior Wall Finish Help Title validated.");
        fsa.assertEquals(getTextFromElement(helpDialogContent), EXTERIOR_WALL_FINISH_HELP_CONTENT, "Exterior Wall Finish Help Content validated.");
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getPropertyDetailsHelpExteriorWall(), EXTERIOR_WALL_FINISH_HELP_CONTENT,
                    "Exterior Wall Finish Help Content validated (AEM).");
        }
        waitAndClickElement(buttonCloseDialog);
        //
        waitAndClickElement(helpRoofCover);
        sleep(1);  // waitElementBeVisible(helpDialogTitle);
        fsa.assertEquals(getTextFromElement(helpDialogTitle), ROOF_COVER_HELP_TITLE, "Roof Cover Help Title validated.");
        fsa.assertEquals(getTextFromElement(helpDialogContent), ROOF_COVER_HELP_CONTENT, "Roof Cover Help Content validated.");
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getPropertyDetailsHelpRoof(), ROOF_COVER_HELP_CONTENT,
                    "Roof Cover Help Content validated (AEM).");
        }
        waitAndClickElement(buttonCloseDialog);
        //
        waitAndClickElement(helpHeatingSystem);
        sleep(1);  // waitElementBeVisible(helpDialogTitle);
        fsa.assertEquals(getTextFromElement(helpDialogTitle), HEATING_SYSTEM_HELP_TITLE, "Heating System Help Title validated.");
        fsa.assertEquals(getTextFromElement(helpDialogContent), HEATING_SYSTEM_HELP_CONTENT, "Heating System Help Content validated.");
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getPropertyDetailsHelpHeating(), HEATING_SYSTEM_HELP_CONTENT,
                    "Heating System Help Content validated (AEM).");
        }
        waitAndClickElement(buttonCloseDialog);
        //
        waitAndClickElement(helpFireplaces);
        sleep(1);  // waitElementBeVisible(helpDialogTitle);
        fsa.assertEquals(getTextFromElement(helpDialogTitle), FIREPLACES_HELP_TITLE, "Fireplace(s) Help Title validated.");
        fsa.assertEquals(getTextFromElement(helpDialogContent), FIREPLACES_HELP_CONTENT, "Fireplace(s) Help Content validated.");
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getPropertyDetailsHelpFireplace(), FIREPLACES_HELP_CONTENT,
                    "Fireplace(s) Content validated (AEM).");
        }
        waitAndClickElement(buttonCloseDialog);
        //
        if (checkIfElementIsDisplayed(selectGarageCarport, 2)) {
            waitAndClickElement(helpGarageCarport);
            sleep(1);  // waitElementBeVisible(helpDialogTitle);
            fsa.assertEquals(getTextFromElement(helpDialogTitle), GARAGE_CARPORT_HELP_TITLE, "Garage/Carport Title validated.");
            fsa.assertEquals(getTextFromElement(helpDialogContent), GARAGE_CARPORT_HELP_CONTENT, "Garage/Carport Content validated.");
            if (staticContent != null) {
                fsa.assertEquals(staticContent.getPropertyDetailsHelpGarage(), GARAGE_CARPORT_HELP_CONTENT,
                        "Garage/Carport Content validated (AEM).");
            }
            waitAndClickElement(buttonCloseDialog);
        }
        //
        waitAndClickElement(helpGarageStyle);
        sleep(1);  // waitElementBeVisible(helpDialogTitle);
        fsa.assertEquals(getTextFromElement(helpDialogTitle), GARAGE_STYLE_HELP_TITLE, "Garage Style Title validated.");
        fsa.assertEquals(getTextFromElement(helpDialogContent), GARAGE_STYLE_HELP_CONTENT, "Garage Style Content validated.");
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getPropertyDetailsHelpGarageStyle(), GARAGE_STYLE_HELP_CONTENT,
                    "Garage Style Content validated (AEM).");
        }
        waitAndClickElement(buttonCloseDialog);
        //
        if (isElementDisplayed(oilTankOnPremisesBy)) {
            waitAndClickElement(helpUndergroundOilTank);
            sleep(1);  // waitElementBeVisible(helpDialogTitle);
            fsa.assertEquals(getTextFromElement(helpDialogTitle), UNDERGROUND_OIL_TANK_HELP, "Underground Oil Tank Help Title validated.");
            fsa.assertEquals(getTextFromElement(helpDialogContent), UNDERGROUND_OIL_TANK_CONTENT, "Underground Oil Tank Help Content validated.");
            if (staticContent != null) {
                fsa.assertEquals(staticContent.getPropertyDetailsHelpUndergroundOilTank(), UNDERGROUND_OIL_TANK_CONTENT,
                        "Number Of Units Attched Content validated (AEM).");
            }
            waitAndClickElement(buttonCloseDialog);
        }
        //
        if (isElementDisplayed(unitsAttachedBy)) {
            waitAndClickElement(helpNumberUfUnitsAttached);
            sleep(1);  // waitElementBeVisible(helpDialogTitle);
            fsa.assertEquals(getTextFromElement(helpDialogTitle), NUMBER_OF_UNITS_ATTACHED_HELP, "Number of Units Attached Title validated.");
            fsa.assertEquals(getTextFromElement(helpDialogContent), NUMBER_OF_UNITS_ATTACHED_CONTENT, "Number of Units Attached Content validated.");
            if (staticContent != null) {
                fsa.assertEquals(staticContent.getPropertyDetailsHelpNumberOfUnitsAttached(), NUMBER_OF_UNITS_ATTACHED_CONTENT,
                        "Number Of Units Attched Content validated (AEM).");
            }
             waitAndClickElement(buttonCloseDialog);
        }
    }

    public void validatePageFieldContents(ApplicantHQM applicant, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getAvailableNumberOfStories(), numberOfStories, "Content of Number Of Stories drop-down");
        verifyFoundationTypes(applicant);
        verifyExteriorWallFinish(applicant);
        fsa.assertEquals(getAvailableRoofCovers(), roofCovers, "Available Roof Covers");
        verifyAvailableHeatingSystems();
        fsa.assertEquals(getAvailableFireplaces(), fireplaces, "Available Fireplace(s)");
        String foundationType = getSelectedFoundationType();
        if (foundationType.equals(BASEMENT) || foundationType.equals(SHALLOW_BASEMENT)) {
            fsa.assertTrue(isElementDisplayed(By.xpath(FINISHED_PERCENT_XPATH)), "Finished Percentage of Lowest Level is available");
        } else {
            fsa.assertFalse(isElementDisplayed(By.xpath(FINISHED_PERCENT_XPATH)), "Finished Percentage of Lowest Level is unavailable");
            garageStyles.remove(BASEMENT);
        }
        if (getSelectedGarageStyle().equals(DETACHED) || getSelectedGarageStyle().equals(NO_GARAGE)) {
            fsa.assertFalse(isElementDisplayed(By.xpath(GARAGE_CARPORT_XPATH)), "Garage/Carport field is unavailable when Garage Style is Detached or No Garage.");
        } else {
            fsa.assertEquals(getAvailableGarageCarports(), garageCarports, "Available Garage/Carports");
        }
        if (Arrays.asList(LA, MA).contains(applicant.stateCode)) {
            fsa.assertEquals(getAvailableOilTank(), listNoYes, "Available Underground Oil Tank on Premises");
        }
        if (applicant.stateCode.equals(NC)) {
            fsa.assertEquals(getAvailablePoolHotTub(), listNoYes, "Available Pool or Hot Tub on Premises");
            if (isElementDisplayed(unitsAttachedBy)) {
                fsa.assertEquals(getAvailableNumberOfUnitsAttached(), numberOfUnitsAttachedList, "Available Number of Units Attached");
            }
        }
        if (isFlexState(applicant.stateCode) && isElementPresentByID(selectSolarPanels)) {
            fsa.assertEquals(getAvailableSolarPanelsOnPrem(), listNoYes, "Available Solar Panels on Premises");
            fsa.assertEquals(getAvailableTrampolineOnPrem(), listNoYes, "Available Trampoline on Premises");
            fsa.assertEquals(getAvailablePoolOnPrem(), listNoYes, "Available Pool on Premises");
        }
        waitForPageToBeReady();
    }

    public void validatePageErrors() throws Exception {
        List<String> errorsList1 = new ArrayList<>();
        this.selectNumberOfStories(SELECT);
        List<String> pageErrors = this.getPageErrors();
        Log.info(FOUND_PAGE_ERRORS + pageErrors);
        errorsList1.add(ERROR1);
        Assert.assertEquals(pageErrors, errorsList1, "Property Details page - Number of stories error.");
        Assert.assertTrue(this.isButtonNextDisabled(), "Next button is disabled");

        if (getSelectedFoundationType().equals(BASEMENT) || getSelectedFoundationType().equals(SHALLOW_BASEMENT)) {
            waitAndClickElement(selectFoundationType);
            waitAndClickElement(doneDialogButton);
        } else {
            this.selectFoundationType(BASEMENT);
        }
        setFinishedPercent(ZERO);
        pageErrors = this.getPageErrors();
        Log.info(FOUND_PAGE_ERRORS + pageErrors);
        errorsList1.add(ERROR2);
        Assert.assertEquals(pageErrors, errorsList1, "Property Details page - And Finished Percent errors 2.");
        Assert.assertTrue(this.isButtonNextDisabled(), "Next button is disabled");

        this.selectFireplaces(SELECT);
        pageErrors = this.getPageErrors();
        Log.info(FOUND_PAGE_ERRORS + pageErrors);
        errorsList1.add(ERROR3);
        Assert.assertEquals(pageErrors, errorsList1, "Property Details page - And Fireplaces errors 3.");
        Assert.assertTrue(this.isButtonNextDisabled(), "Next button is disabled");

        this.selectGarageStyle(SELECT);
        this.selectGarageCarport(SELECT);
        pageErrors = this.getPageErrors();
        Log.info(FOUND_PAGE_ERRORS + pageErrors);
        errorsList1.add(ERROR4);
        errorsList1.add(ERROR5);
        Assert.assertEquals(pageErrors, errorsList1, "Property Details page - And Garage Style + Garage/Carport errors 4, 5.");
        Assert.assertTrue(this.isButtonNextDisabled(), "Next button is disabled");

        this.selectGarageCarport("1 Car");
        this.selectGarageStyle(SELECT);
        pageErrors = this.getPageErrors();
        errorsList1.remove(ERROR5);
        Assert.assertEquals(pageErrors, errorsList1, "Property Details page - Removed Garage/Carport page error.");
        Assert.assertTrue(this.isButtonNextDisabled(), "Next button is disabled");

        if (isElementDisplayed(oilTankOnPremisesBy)) {
            selectOilTankOnPremises(SELECT);
            pageErrors = this.getPageErrors();
            errorsList1.add(ERROR6);
            Assert.assertEquals(pageErrors, errorsList1, "Property Details page - And Underground Oil Tank on Premises page errors.");
            Assert.assertTrue(this.isButtonNextDisabled(), "Next button is disabled");
        }

        if (isElementDisplayed(poolHotTubOnPremisesBy)) {
            selectPoolHotTubOnPremises("Select");
            pageErrors = this.getPageErrors();
            errorsList1.add(ERROR7);
            Assert.assertEquals(pageErrors, errorsList1, "Property Details page - And Pool or Hot Tub on Premises page errors.");
            Assert.assertTrue(this.isButtonNextDisabled(), "Next button is disabled");
        }

        if (isElementDisplayed(unitsAttachedBy)) {
            selectUnitsAttached(SELECT);
            pageErrors = this.getPageErrors();
            errorsList1.add(ERROR8);
            Assert.assertEquals(pageErrors, errorsList1, "Property Details page - And Number Of Units Attached page errors.");
            Assert.assertTrue(this.isButtonNextDisabled(), "Next button is disabled");
        }

        driver().navigate().refresh();
        waitForPageToBeReady();
    }

    public void validatePageTitles(ApplicantHQM applicant, FarmersSoftAssert fsa, @Nullable StaticContentHQM staticContent) {
        fsa.assertEquals(getTextFromElement(textPageTitle), PROPERTY_DETAILS_PAGE_TITLE, "Property Details page - page H1 Title.");
        String subtitle = isEasternExpansionState(applicant.stateCode) ? SUBTITLE_TEXT_KY : SUBTITLE_TEXT;
        fsa.assertEquals(getTextFromElement(textPageSubTitle), subtitle, "Property Details page - page Sub-Title.");
        fsa.assertEquals(getTextFromElement(textPageCardSubtitle), CARD_SUBTITLE_TEXT, "Property Details page - page Card Sub-Heading.");
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getPropertyDetailsTitle(), PROPERTY_DETAILS_PAGE_TITLE, "Property Details page - page Title (AEM).");
            fsa.assertEquals(staticContent.getPropertyDetailsCaption(), subtitle, "Property Details page - page Sub-Title (AEM).");
            fsa.assertEquals(staticContent.getPropertyDetailsSubHeading(), CARD_SUBTITLE_TEXT, "Property Details page - page Card Sub-Heading (AEM).");
        }
    }

    public void validateSubtitlesDiscountJourney(List<String> discounts, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(discountSubTitleLock), DISCOUNT_LOCK_TEXT,
                "Property Details page - Discount Journey Subtitle Clock image.");
        int discountCount = discounts.size();
        ArrayList<String> discountsAvailable = new ArrayList<>(discounts);
        String textDiscount = discountCount > 0? discountCount + " p" : "P";
        fsa.assertEquals(getTextFromElement(discountSubTitlePiggy), textDiscount + DISCOUNT_PIGGY_TEXT,
                "Property Details page - Discount Journey Subtitle Lock image.");
        if (discountCount > 0) {
            waitAndClickElement(discountHelpButtonPiggy);
            waitElementBeVisible(discountHelpDialogTitle);
            fsa.assertEquals(getTextFromElement(discountHelpDialogTitle), DISCOUNT_HELP_DIALOG_TITLE.replace("($)", "(" + discountCount + ")"),
                    "Property Details page - Discount Journey Help Dialog Title.");
            List<String> listDiscounts = driver().findElements(By.xpath(CONTENT_XPATH)).stream()
                    .map(this::getTextFromElement).sorted(Comparator.naturalOrder()).collect(Collectors.toList());
            discountsAvailable.sort(Comparator.naturalOrder());
            fsa.assertEquals(listDiscounts, discountsAvailable, "Property Details page - Discount Journey Help Dialog Content.");
            waitAndClickElement(buttonCloseDialog);
        }
    }

    public void verifyPageFieldsNotReadonly(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getAttributeData(selectNumberOfStories, READONLY), EMPTY_STRING, "Property Details page - Number of stories is not read-only");
        fsa.assertEquals(getAttributeData(selectFoundationType, READONLY), EMPTY_STRING, "Property Details page - Foundation type is not read-only");
        if (isElementDisplayed(By.xpath(FINISHED_PERCENT_XPATH))) {
            fsa.assertEquals(getAttributeData(inputFinishedPercent, READONLY), EMPTY_STRING, "Property Details page - Finished Percentage is not read-only");
        }
        fsa.assertEquals(getAttributeData(selectExteriorWallFinish, READONLY), EMPTY_STRING, "Property Details page - Exterior wall finish is not read-only");
        fsa.assertEquals(getAttributeData(selectRoofCover, READONLY), EMPTY_STRING, "Property Details page - Roof Cover isread-only");
        fsa.assertEquals(getAttributeData(selectHeatingSystem, READONLY), EMPTY_STRING, "Property Details page - Heating system is not read-only");
        fsa.assertEquals(getAttributeData(selectFireplaces, READONLY), EMPTY_STRING, "Property Details page - Fireplace(s) is not read-only");
        fsa.assertEquals(getAttributeData(selectGarageStyle, READONLY), EMPTY_STRING, "Property Details page - Garage Style is not read-only");
        if (isElementDisplayed(By.xpath(GARAGE_CARPORT_XPATH))) {
            fsa.assertEquals(getAttributeData(selectGarageCarport, READONLY), EMPTY_STRING, "Property Details page - Garage/Carport style is not read-only");
        }
        if (isElementDisplayed(oilTankOnPremisesBy)) {
            fsa.assertEquals(getAttributeData(undergroundOilTank, READONLY), EMPTY_STRING, "Property Details page - Underground Oil Tank is not read-only");
        }
        if (isElementDisplayed(poolHotTubOnPremisesBy)) {
            fsa.assertEquals(getAttributeData(poolHotTubOnPremises, READONLY), EMPTY_STRING, "Property Details page - Pool On Premises is not read-only");
        }
        if (isElementDisplayed(unitsAttachedBy)) {
            fsa.assertEquals(getAttributeData(unitsAttached, READONLY), EMPTY_STRING, "Property Details page - Units Attached is not read-only");
        }
    }

    public boolean isNextButtonEnabled(String stateCode) throws Exception {
        if (isFlexState(stateCode)) {
            return !getSolarPanelsOnPremises().isEmpty() && !getTrampolineOnPremises().isEmpty() && !getPoolOnPremises().isEmpty()
                    && (getFinishedPercentError() == null);
        } else {
            return getFinishedPercentError() == null;
        }
    }
}
