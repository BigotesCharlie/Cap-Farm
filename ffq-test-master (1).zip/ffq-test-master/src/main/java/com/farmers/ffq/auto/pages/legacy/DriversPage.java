package com.farmers.ffq.auto.pages.legacy;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.datatransferobjects.SqlIncident;
import com.farmers.ffq.datatransferobjects.SqlVehicle;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import javax.annotation.Nullable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.invisibilityOf;

public class DriversPage extends AutoBasePage {
	private static final String DRIVERS_PAGE_HEADER = "Who's driving?";
	private static final String CANCEL_DIALOG_CONTENT = "You have made changes to this page. Do you want to discard your changes?";
	private static final String MARITAL_STATUS_DROPDOWN_ERROR_MESSAGE = "Please enter your marital status.";
	private static final String MARITAL_STATUS_RADIO_BUTTONS_ERROR_MESSAGE = "Please choose your marital status.";
	private static final String CHOOSE_YES_OR_NO_ERROR_MESSAGE = "Please choose yes or no.";
	private static final String AGE_FIRST_LICENSED_ERROR_MESSAGE = "Age first licensed is required.";
	private static final String ACCIDENTS_OR_VIOLATIONS_ERROR_MESSAGE = "Please choose yes or no, if you had any accidents or violations.";
	private static final String FINANCIAL_FILING_ERROR_MESSAGE = "Please choose options for the financial filing.";
	private static final String PIP_ERROR_MESSAGE = "Please enter driver principal PIP.";
	private static final String INCIDENT_TYPE_ERROR_MESSAGE = "Please choose the incident type.";
	private static final String INCIDENT_DESCRIPTION_ERROR_MESSAGE = "Please enter the incident description.";
	private static final String INCIDENT_DATE_ERROR_MESSAGE = "Please enter the date, the violation or incident occurred.";
	private static final String FIRSTNAME_ERROR_MESSAGE = "Please enter your first name.";
	private static final String LASTNAME_LICENSED_ERROR_MESSAGE = "Please enter your last name.";
	private static final String DOB_ERROR_MESSAGE = "Please enter your date of birth.";
	private static final String RELATIONSHIP_ERROR_MESSAGE = "Please enter Relation to applicant.";
	private static final String GENDER_ERROR_MESSAGE = "Please choose your gender.";
	private static final String ADDITIONAL_DRIVER_AGE_ERROR_MESSAGE = "Please enter valid age.";
	private static final String AGE_FIRST_LICENSED_FAQ_TITLE = "Driver's License Age";
	private static final String AGE_FIRST_LICENSED_FAQ_TEXT = "How old were you when you first received your Driver's License?";
	private static final String AGE_FIRST_LICENSED_FAQ_TEXT_CA = "At what age was this driver first licensed to drive, whether in the United States or in a foreign country? " +
			"If there has been a gap in licensing, please provide the age this driver first held a license to drive. This includes only a full driver's license, not a learner's permit.";
	private static final String AGE_ADDITIONAL_FIRST_LICENSED_FAQ_TEXT = "How old was the driver when they first received their Driver's License?";
	private static final String MARITAL_STATUS_FAQ_TEXT = "Select \"Married\" for any legally recognized relationship, including marriage, civil union, or domestic partnership, regardless of gender.";
	private static final String DRIVERS_LICENSE_FAQ_TITLE = "Drivers License";
	private static final String DRIVERS_LICENSE_FAQ_TEXT = "We need this to collect from department of motor vehicle reports.";
	private static final String ACTIVE_MILITARY_DUTY_FAQ_TITLE = "Active Military Duty";
	private static final String ACTIVE_MILITARY_DUTY_FAQ_TEXT = "Farmers offers a discount to drivers who are active military personnel based in Louisiana.";
	private static final String FINANCIAL_RESPONSIBILITY_FAQ_TITLE = "Financial Responsibility Filing";
	private static final String FINANCIAL_RESPONSIBILITY_FAQ_TEXT = "When required by the state, financial filings (also known as SR-22 or FR-44) are filed by insurance companies on behalf of the insured. The filing allows insurance companies to notify the state if you are maintaining coverage and financially responsible for accidents.";
	private static final String FINANCIAL_RESPONSIBILITY_EXPANDED_FAQ_TEXT = FINANCIAL_RESPONSIBILITY_FAQ_TEXT + " If you need a financial responsibility filing in a different state, we are unable to process this online, but your Farmers representative will be happy to help.";
	private static final String LICENSED_BY_US_STATE_FAQ_TEXT = "Answer \"yes\" if this driver currently holds a valid license issued by a U.S. state, U.S. territory, or Canadian province.";
	private static final String PERSONAL_INJURY_FAQ_TEXT = "Personal Injury refers to bodily injuries incurred by each insured person injured in a motor vehicle accident.";
	private static final String SAFETY_COURSE_FAQ_TITLE = "Safety Course";
	private static final String SAFETY_COURSE_FAQ_TEXT = "Farmers offers a discount to drivers who complete an approved driving safety or defensive driving course.";
	private static final String COMMUTER_FAQ_TEXT = "This question applies to any driver on the policy who commutes to another state.";
	private static final String PRINCIPAL_PIP_FAQ_TITLE = "PIP Insurance Policy";
	private static final String PRINCIPAL_PIP_FAQ_TEXT = "Personal Injury Protection (PIP) is medical coverage for injuries you (and others) suffer in an auto accident, regardless of fault. It also covers reimbursement for certain expenses incurred when you are hurt, such as lost wages or hiring someone to take care of your home or family.";
	private static final String EMAIL_ERROR_MESSAGE = "Please enter your email address.";
	private static final String PHONE_NUMBER_ERROR_MESSAGE = "Please enter your phone number.";
	private static final String MAILING_ADDRESS_ERROR_MESSAGE = "Please enter your mailing address.";
	private static final String MAILING_CITY_ERROR_MESSAGE = "Please enter your city.";
	private static final String MAILING_STATE_ERROR_MESSAGE = "Please enter your state.";
	private static final String MAILING_ZIPCODE_ERROR_MESSAGE = "Please enter your ZIP code.";
	private static final String VEHICLE_ASSIGNMENT_HEADER = "Assign cars to drivers";
	private static final String VEHICLE_ASSIGNMENT_DESCRIPTION = "Select the vehicle each driver drives. If you have more drivers in your household, some drivers may not be assigned to any vehicles.";
	private static final String VEHICLE_ASSIGNMENT_DESCRIPTION_NY = "Select each driver's vehicles.";
	private static final String VEHICLE_ASSIGNMENT_ERROR_MESSAGE = "Each vehicle must have at least one driver";
	private static final String VEHICLE_ASSIGNMENT_ERROR_MESSAGE_NY = "Each driver should be assigned to at least one vehicle.";
	private static final String INDIVIDUAL_VEHICLE_ASSIGNMENT_ERROR_MESSAGE = " should be assigned to at least one vehicle.";
	private static final String CURRENT_INSURER_FAQ_TITLE = "Current Auto Insurance Company";
	private static final String CURRENT_INSURER_FAQ_TEXT = "If you have a current auto insurance policy with a company, please select the name of the company. Select \"Other\" if the company is not listed.";
	private static final String INNOCENT_NOPRIOR_TEXT = " If you have been deployed overseas select \"Innocent-No Prior\".";
	private static final String NOPRIOR_MILITARY_TEXT = " If you have been deployed overseas select \"No Prior-Military\".";
	private static final String CURRENT_INSURER_MN_FAQ_TEXT = CURRENT_INSURER_FAQ_TEXT + INNOCENT_NOPRIOR_TEXT;
	private static final String PRIOR_INSURER_FAQ_TITLE = "Who was your prior auto insurance company?";
	private static final String PRIOR_INSURER_FAQ_TEXT = "If you have a prior auto insurance policy with a company, please select the name of the company. Select \"Other\" if the company is not listed.";
	private static final String PRIOR_INSURER_AND_DEPLOYED_FAQ_TEXT = PRIOR_INSURER_FAQ_TEXT + NOPRIOR_MILITARY_TEXT;
	private static final String PRIOR_INSURER_MN_FAQ_TEXT = PRIOR_INSURER_FAQ_TEXT + INNOCENT_NOPRIOR_TEXT;
	private static final String COVERAGE_LENGTH_FAQ_TITLE = "Auto Insurance Coverage";
	private static final String COVERAGE_LENGTH_FAQ_TEXT = "Let us know how long you were insured with your prior auto insurance company without any breaks or lapses in coverage";
	private static final String BODILY_INJURY_LIMITS_FAQ_TITLE = "Bodily Injury Limits";
	private static final String BODILY_INJURY_LIMITS_FAQ_TEXT = "Under your current auto insurance policy, what are the \"Bodily Injury Limits\"? ";
	private static final String BODILY_INJURY_LIMITS_DECLARATION_FAQ_TEXT =	"This information is listed on your policy's Declaration Page, typically shown like this: $50,000/$100,000. This represents the highest amount per person/per accident your insurance company would pay if you are at fault in an accident that causes injury to another person.";
	private static final String BODILY_INJURY_LIMITS_INCREASE_FAQ_TEXT = BODILY_INJURY_LIMITS_DECLARATION_FAQ_TEXT + " If you have increased your Bodily Injury Limits at any time over the last 12 months, please select those lower limits. Otherwise select your current limits.";
	private static final String POLICY_EXPIRATION_DATE_FAQ_TITLE = "Policy Expiration";
	private static final String WHEN_DOES_YOUR_POLICY_EXPIRE = "When does your current policy expire?";
	private static final String POLICY_EXPIRATION_DATE_TEXT = "Your policy expiration date is the day when your policy ends. After that date, your current insurance policy will no longer cover you in the event of an accident.";

	private static final String DRIVER_TO_INSURE_XPATH_BEGIN = "//div[@data-gtm='FFQ_Auto_Driver_selectDriver_checkbox' and contains(@aria-label, '";
	private static final String DRIVER_TO_INSURE_XPATH_END = "')]";

	private static final String BW_DRIVER_TO_ASSIGN_XPATH_BEGIN = "//div[contains(text(), '";
	private static final String BW_DRIVER_TO_ASSIGN_XPATH_END = "')]//mat-select";

	private static final String LT_6MONTHS = "< 6 Months";
	private static final String SIX_TO_ELEVEN_MONTHS = "6 - 11 Months";
	private static final String TWELVE_TO_TWENTYTHREE_MONTHS = "12 - 23 Months";
	private static final String TWENTYFOUR_TO_THIRTYFIVE_MONTHS = "24 - 35 Months";
	private static final String THIRTYSIX_TO_FORTYSEVEN_MONTHS = "36 - 47 Months";
	private static final String FORTYEIGHT_TO_FIFTYNINE_MONTHS = "48 - 59 Months";
	private static final String SIXTYPLUS_MONTHS = "60+ Months";
	private static final String NO_BI_PIP_PD_ONLY = "No BI- PIP/PD only";
	private static final String PIP_PD_ONLY = "PIP PD Only";

	@FindBy(className = "ffq-main-title")
	private WebElement driversPageHeader;

	@FindBy(className = "auto__driver__add-new-disabled")
	private WebElement disabledAddDriverLink;

	@FindBy(xpath = "//*[@data-gtm='FFQ_Auto_Driver_addspouse_button']")
	private WebElement addSpouseDriverLink;

	@FindBy(xpath = "//*[@data-gtm='FFQ_Auto_Driver_addadriver_button']")
	private WebElement addAdditionalDriverLink;

	@FindBy(xpath = "//*[@data-gtm='FFQ_Auto_Driver_selectSpouse_checkbox']")
	private WebElement checkSelectSpouseDriver;

	@FindBy(xpath = "//*[@data-gtm='FFQ_Auto_Driver_notmarried_button']")
	private WebElement driverNotMarriedLink;

	@FindBy(xpath = "//span[contains(@class,'max-driver-info-text')]")
	private WebElement maximumNumberOfDriversMessage;

	@FindBy(xpath = "//button[@data-gtm='FFQ_Auto_Driversummary_back_button']")
	private WebElement backButton;

	@FindBy(xpath = "//button[@data-gtm='FFQ_Auto_Driversummary_next_button']")
	private WebElement nextButton;

	private static final String NEXT_BUTTON_XPATH = "//button[contains(.,'NEXT')]";
	@FindBy(xpath = NEXT_BUTTON_XPATH)
	private WebElement buttonNext;

	// Add Driver Details dialog
	private static final String CLOSE_DIALOG_XPATH = "//div[contains(@class, 'close-icon')]";
	@FindBy (xpath = CLOSE_DIALOG_XPATH)
	private WebElement closeAddDriverDetailsDialog;

	@FindBy (className = "auto-module__add-driver-header-text")
	private WebElement addDriverDetailsDialogHeader;

	@FindBy (xpath = "//button[contains(@class, 'auto-module__add-driver-save-button')]")
	private WebElement saveDriverDetailsLink;

	@FindBy (id = "infoDialog")
	private WebElement closeDetailsConfirmationDialogContent;

	@FindBy (xpath = "//mat-dialog-actions/button/span[text()='No, continue'] | //mat-dialog-actions/button/span[text()='NO, CONTINUE']")
	private WebElement closeConfirmationDialogContinueButton;

	@FindBy (xpath = "//mat-dialog-actions/button/span[text()='Yes, navigate away'] | //mat-dialog-actions/button/span[text()='YES, NAVIGATE AWAY']")
	private WebElement closeConfirmationDialogCloseButton;

	@FindBy(xpath = "//div[contains(text(), 'Are you married')]/a")
	private WebElement maritalStatusFAQLink;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_MaritalStatus_yes_radio']/label/div")
	private WebElement marriedRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_MaritalStatus_no_radio']/label/div")
	private WebElement notMarriedRadioButton;

	@FindBy(xpath = "//div[contains(text(), 'Is this driver married')]/a")
	private WebElement additionalDriverMaritalStatusFAQLink;

	@FindBy(xpath = "//div[contains(text(), 'Is this driver married')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]")
	private WebElement additionalDriverMarriedRadioButton;

	@FindBy(xpath = "//div[contains(text(), 'Is this driver married')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]")
	private WebElement additionalDriverNotMarriedRadioButton;

	@FindBy(xpath = "//span/label/mat-label[text()='Marital status']/../../../mat-select")
	private WebElement maritalStatusDropdown;

	@FindBy(xpath = "//div[@class='auto-module__add-driver-input-text']/lib-select/mat-form-field/div/div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
	private WebElement maritalStatusDropdownErrorMessage;

	@FindBy(xpath = "//div[@class='auto-module__add-driver-input-text']/lib-radio-button/div[@id='opt_maritalStatus']/mat-error")
	private WebElement maritalStatusRadioButtonsErrorMessage;

	private static final String OCCUPATION_ENTRY_FIELD_XPATH = "//mat-label[text()='Occupation']/../../../input";
	@FindBy(xpath = OCCUPATION_ENTRY_FIELD_XPATH)
	private WebElement occupationEntryField;

	private static final String OCCUPATION_XPATH = "//mat-option[contains(@data-gtm, 'FFQ_Auto_Driver_Occupation')]";
	@FindBy(xpath = OCCUPATION_XPATH)
	private WebElement occupationOption;

	@FindBy(xpath = "//div[contains(text(), 'active military duty stationed')]/a")
	private WebElement activeMilitaryDutyStationedInStateFAQLink;

	@FindBy(xpath = "//mat-radio-button[contains(@data-gtm,'FFQ_Auto_driver_activemilitary_yes_radio')]//input")
	private WebElement activeMilitaryDutyStationedInStateRadioButton;

	@FindBy(xpath = "//mat-radio-button[contains(@data-gtm,'FFQ_Auto_driver_activemilitary_No_radio')]//input")
	private WebElement notActiveMilitaryDutyStationedInStateRadioButton;

	private static final String CURRENTLY_INSURED_XPATH = "//mat-radio-button[@data-gtm='FFQ_Auto_Drivers_CurrentlyInsured_yes_radio']//input";
	@FindBy(xpath = CURRENTLY_INSURED_XPATH)
	private WebElement currentlyInsuredRadioButton;

	@FindBy(xpath = "//a[contains(@aria-label, 'Current Auto Insurance Company')]")
	private WebElement currentlyInsuredFAQLink;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'insurance expired')]")
	private WebElement insuranceExpiredRadioButton;

	@FindBy(xpath = "//a[contains(@aria-label, 'Prior auto insurance company')]")
	private WebElement priorInsuranceFAQLink;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'never had insurance')]")
	private WebElement neverInsuredRadioButton;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'deployed or overseas')]")
	private WebElement deployedRadioButton;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'not required')]")
	private WebElement notRequiredRadioButton;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'not own a vehicle')]")
	private WebElement notOwnAVehicleRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_6Mconticoverage_yes_radio']/label/div[contains(text(), 'Yes')]")
	private WebElement had6MonthCoverageInPastRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_militarydepreason_yes_radio']/label/div[contains(text(), 'Yes')]")
	private WebElement deploymentReasonForNoInsuranceRadioButton;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Other')]")
	private WebElement otherRadioButton;

	@FindBy(xpath = "//div[contains(text(), 'Are you currently')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-error")
	private WebElement currentlyInsuredStatusErrorMessage;

	@FindBy(xpath = "//div/span/label/mat-label[contains(text(), 'Current')]/../../../input")
	private WebElement currentAutoInsuranceCompanyEntryField;

	@FindBy(xpath = "//div/span/label/mat-label[contains(text(), 'Prior auto insurance')]/../../../input")
	private WebElement priorAutoInsuranceCompanyEntryField;

	@FindBy(xpath = "//mat-option[contains(@data-gtm, 'FFQ_Auto_Driver_company')]")
	private WebElement insuranceCompanyOption;

	@FindBy(xpath = "//a[contains(@aria-label, 'Insurance Coverage')]")
	private WebElement continuousCoverageLengthFAQLink;

	@FindBy(xpath = "//span/label/mat-label[contains(text(), 'Length of continuous')]/../../../mat-select")
	private WebElement continuousCoverageLengthDropDown;

	private static final String SIX_MONTHS_COVERAGE_YES_XPATH = "//mat-radio-button[contains(@data-gtm,'FFQ_Auto_Driver_6Mconticoverage_yes_radio')]//input";
	@FindBy(xpath = SIX_MONTHS_COVERAGE_YES_XPATH)
	private WebElement yesSixMonthsRadioButton;

	private static final String SIX_MONTHS_COVERAGE_NO_XPATH = "//mat-radio-button[contains(@data-gtm,'FFQ_Auto_Driver_6Mconticoverage_no_radio')]//input";
	@FindBy(xpath = SIX_MONTHS_COVERAGE_NO_XPATH)
	private WebElement noSixMonthsRadioButton;

	@FindBy(xpath = "//*[contains(text(), 'bodily injury limits')]/a")
	private WebElement bodilyInjuryLimitsFAQLink;

	@FindBy(xpath = "//span/label/mat-label[contains(text(), 'Bodily injury')]/../../../mat-select")
	private WebElement bodilyInjuryLimitsDropDown;

	@FindBy(xpath = "//a[contains(@aria-label, 'Policy Expiration')]")
	private WebElement policyExpirationDateFAQLink;

	@FindBy(xpath = "//span/label/mat-label[text()='Policy expiration date']/../../../input")
	private WebElement policyExpirationDateEntryField;

	private static final String POLICY_EXPIRATION_DATE_ERROR_MESSAGE_XPATH = "//div/div/mat-error[contains(text(),' Please enter policy expiration date.')]";
	@FindBy(xpath = POLICY_EXPIRATION_DATE_ERROR_MESSAGE_XPATH)
	private WebElement policyExpirationDateErrorMessage;

	@FindBy(xpath = "//div[contains(text(), 'Is your spouse licensed to drive')]")
	private WebElement spouseLicensedToDriveInUSLabel;

	private static final String SPOUSE_LICENSED_IN_USA_DROPDOWN_XPATH = "//span/label/mat-label[text()='Licensed to drive in the U.S.A']/../../../mat-select";
	@FindBy(xpath = SPOUSE_LICENSED_IN_USA_DROPDOWN_XPATH)
	private WebElement spouseLicensedinUSADropdown;

	private static final String SPOUSE_LICENSED_TO_DRIVE_XPATH = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_licensedtodrive_yes']/label//input";
	@FindBy(xpath = SPOUSE_LICENSED_TO_DRIVE_XPATH)
	private WebElement spouseLicensedToDriveRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_licensedtodrive_no']//input")
	private WebElement spouseNotLicensedToDriveRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_licensedtodrive_yesbutaway']//input")
	private WebElement spouseLivesAwayRadioButton;

	@FindBy(xpath = "//*[contains(text(), 'Age you first')]/a")
	private WebElement ageFirstLicensedFAQLink;

	@FindBy(xpath = "//*[contains(text(), 'driver first received')]/a")
	private WebElement ageAdditionalDriverFirstLicensedFAQLink;

	@FindBy(xpath = "//input[@data-gtm='FFQ_Auto_Driver_Licenseage_text']")
	private WebElement ageFirstLicensedEntryField;

	@FindBy(xpath = "//lib-input-text[@id='inputForAge']/mat-form-field/div/div[contains(@class,'mat-form-field-subscript-wrapper')]/div/mat-error")
	private WebElement ageFirstLicensedErrorMessage;

	@FindBy(xpath = "//mat-checkbox/label/span/span[contains(text(), 'foreign country')]")
	private WebElement licenseIssuedInForeignCountryCheckbox;

	@FindBy(xpath = "//div[contains(text(), 'license issued by a')]/a")
	private WebElement licenseIssuedByUSStateFAQLink;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_LicenseCountryUS_Yes_radio']//input")
	private WebElement licensedByUSStateRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_LicenseCountryUS_No_radio']//input")
	private WebElement notLicensedByUSStateRadioButton;

	@FindBy(xpath = "//a[@data-gtm='FFQ_Auto_AddDriverDetails_DriverLicense_Ihelp_icon']")
	private WebElement driversLicenseFAQLink;

	@FindBy(xpath = "//input[@data-gtm='FFQ_Auto_AddDriverDetails_DriverLicense_text']")
	private WebElement driversLicenseEntryField;

	@FindBy(xpath = "//mat-select[@aria-label='License issue state']")
	private WebElement driversLicenseIssueStateDropdown;

	@FindBy(xpath = "//mat-radio-button[contains(@data-gtm,'FFQ_Auto_driverspouse_activemilitary_yes_radio')]//input")
	private WebElement spouseActiveMilitaryDutyStationedInStateRadioButton;

	@FindBy(xpath = "//mat-radio-button[contains(@data-gtm,'FFQ_Auto_driverspouse_activemilitary_No_radio')]//input")
	private WebElement spouseNotActiveMilitaryDutyStationedInStateRadioButton;

	@FindBy(xpath = "//div[contains(text(), 'accidents or violations')]")
	private WebElement accidentsInLastYearsHeader;

	@FindBy(xpath = "//div[contains(text(), 'accidents or violations')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]")
	private WebElement accidentsInLastYearsRadioButton;

	@FindBy(xpath = "//div[contains(text(), 'accidents or violations')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]")
	private WebElement noAccidentsInLastYearsRadioButton;

	@FindBy(xpath = "//div[contains(text(), 'accidents or violations')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-error")
	private WebElement accidentsOrViolationsErrorMessage;

	@FindBy(xpath = "//span/mat-panel-title[contains(text(), 'Incident 1')]")
	private WebElement incident1SectionHeader;

	@FindBy(xpath = "//mat-expansion-panel-header[@id='mat-expansion-panel-header-1']/span/mat-panel-description/a")
	private WebElement removeIncident1Link;

	@FindBy(xpath = "//span/mat-panel-title[contains(text(), 'Incident 2')]")
	private WebElement incident2SectionHeader;

	@FindBy(xpath = "//mat-expansion-panel-header[@id='mat-expansion-panel-header-2']/span/mat-panel-description/a")
	private WebElement removeIncident2Link;

	@FindBy(xpath = "//mat-dialog-actions/button[contains(text(), 'NO')]")
	private WebElement doNotRemoveIncidentButton;

	@FindBy(xpath = "//mat-dialog-actions/button[contains(text(), 'REMOVE IT')]")
	private WebElement confirmRemoveIncidentButton;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Accident')]")
	private WebElement accidentRadioButton;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Citation')]")
	private WebElement citationRadioButton;

	@FindBy(xpath = "//div[@id='opt_incidentType']//mat-error")
	private WebElement incidentTypeErrorMessage;

	@FindBy(xpath = "//span/label/mat-label[text()='Description']/../../../mat-select")
	private WebElement incidentDescriptionDropdown;

	@FindBy(xpath = "//label/mat-label[text()='Description']/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
	private WebElement incidentDescriptionErrorMessage;

	@FindBy(xpath = "//span/label/mat-label[contains(text(),'Date the violation or accident')]/../../../input")
	private WebElement incidentDateEntryField;

	@FindBy(xpath = "//span/label/mat-label[contains(text(),'Date the violation or accident')]/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
	private WebElement incidentDateErrorMessage;

	@FindBy(xpath = "//app-incident/mat-expansion-panel/div/div/div/div/lib-radio-button/div/mat-radio-group/mat-radio-button/label/div[contains(text(), 'Yes')]")
	private WebElement injuriesRadioButton;

	@FindBy(xpath = "//app-incident/mat-expansion-panel/div/div/div/div/lib-radio-button/div/mat-radio-group/mat-radio-button/label/div[contains(text(), 'No')]")
	private WebElement noInjuriesRadioButton;

	@FindBy (xpath = "//div[@class='auto-module__add-driver-incidents__add-new-incident-box']/a")
	private WebElement addAnotherIncidentButton;

	@FindBy (xpath = "//div[@class='auto-module__add-driver-text' and contains(text(), 'GPA of 3')]")
	private WebElement fullTimeStudentSectionLabel;

	@FindBy (xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_GPA_Yes_radio']//input")
	private WebElement fullTimeStudentWithGPARadioButton;

	private static final String NOT_FULLTIME_STUDENT_XPATH = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_GPA_No_radio']//input";
	@FindBy (xpath = NOT_FULLTIME_STUDENT_XPATH)
	private WebElement notFullTimeStudentWithGPARadioButton;

	@FindBy (xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Away_Yes_radio']//input")
	private WebElement attendingDistantSchoolRadioButton;

	@FindBy (xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Away_No_radio']//input")
	private WebElement notAttendingDistantSchoolRadioButton;

	@FindBy(xpath = "//div[contains(text(), 'financial')]/a")
	private WebElement financialResponsibilityFAQLink;

	private static final String NO_FINANCIAL_FILING_XPATH = "//div[contains(text(), 'financial')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]";
	@FindBy(xpath = NO_FINANCIAL_FILING_XPATH)
	private WebElement noFinancialFilingRadioButton;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'SR-22')]")
	private WebElement sr22RadioButton;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'FR-22')]")
	private WebElement fr22RadioButton;

	@FindBy(xpath = "//div[contains(text(), 'financial')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-error")
	private WebElement financialFilingErrorMessage;

	@FindBy(xpath = "//div[contains(text(), 'one personal injury')]/a")
	private WebElement personalInjuryFAQLink;

	@FindBy(xpath = "//div[contains(text(), 'one personal injury')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]")
	private WebElement personalInjuryRadioButton;

	@FindBy(xpath = "//div[contains(text(), 'one personal injury')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]")
	private WebElement noPersonalInjuryRadioButton;

	@FindBy(xpath = "//div[contains(text(), 'Principal PIP')]/a")
	private WebElement principalPIPFAQLink;

	@FindBy(xpath = "//span/label/mat-label[text()='Principal PIP']/../../../mat-select")
	private WebElement principalPIPDropdown;

	@FindBy(xpath = "//span/label/mat-label[contains(text(),'Principal PIP')]/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
	private WebElement principalPIPErrorMessage;

	@FindBy(xpath = "//div[contains(text(), 'safety course')]/a")
	private WebElement safetyCourseFAQLink;

	private static final String SAFETY_COURSE_COMPLETED_XPATH = "//div[contains(text(), 'safety course')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'Yes')]";
	@FindBy(xpath = SAFETY_COURSE_COMPLETED_XPATH)
	private WebElement safetyCourseCompletedRadioButton;

	@FindBy(xpath = "//div[contains(text(), 'safety course')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-radio-group//mat-radio-button/label/div[contains(text(), 'No')]")
	private WebElement noSafetyCourseCompletedRadioButton;

	@FindBy(xpath = "//div[contains(text(), 'safety course')]/../div[@class='auto-module__add-driver-input-text']/lib-radio-button/div/mat-error")
	private WebElement safetyCourseCompletedErrorMessage;

	@FindBy(xpath = "//span/label/mat-label[text()='Safety course completion date']/../../../input")
	private WebElement safetyCourseCompletedateEntryField;

	@FindBy(xpath = "//div[contains(text(), 'commuters to')]/a")
	private WebElement commutersFAQLink;

	private static final String COMMUTERS_TO_OTHER_STATE_RADIO_BUTTON_XPATH = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Commutestate_Yes_radio']//input";
	@FindBy(xpath = COMMUTERS_TO_OTHER_STATE_RADIO_BUTTON_XPATH)
	private WebElement commutersToOtherStateRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Commutestate_No_radio']//input")
	private WebElement noCommutersToOtherStateRadioButton;

	@FindBy(id = "error_opt_commutQues")
	private WebElement commutersErrorMessage;

	// Additional Driver page (Duplicates come from regular driver details page
	@FindBy (className = "auto-module__add-driver-header-text")
	private WebElement addAdditionalDriverDetailsDialogHeader;

	@FindBy (xpath = "//div[@class='auto-module__add-driver-header-save']/a")
	private WebElement saveAdditionalDriverDetailsLink;

	@FindBy(xpath = "//span/label/mat-label[text()='First name']/../../../input")
	private WebElement firstNameADEntryField;

	@FindBy(xpath = "//div[@class='auto-module__add-driver-input-text']/lib-input-text/mat-form-field/div/div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
	private WebElement firstNameADErrorMessage;

	@FindBy(xpath = "//span/label/mat-label[text()='Last name']/../../../input")
	private WebElement lastNameADEntryField;

	@FindBy(xpath = "//label/mat-label[text()='Last name']/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
	private WebElement lastNameADErrorMessage;

	@FindBy(xpath = "//span/label/mat-label[text()='Date of birth']/../../../input")
	private WebElement dobADEntryField;

	private static final String DOB_ADDITIONAL_DRIVER_ERROR_MESSAGE_XPATH = "//span/label/mat-label[text()='Date of birth']/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error";
	@FindBy(xpath = DOB_ADDITIONAL_DRIVER_ERROR_MESSAGE_XPATH)
	private WebElement dobADErrorMessage;

	@FindBy(xpath = "//span/label/mat-label[text()='Relationship to applicant']/../../../mat-select")
	private WebElement relationshipToApplicantDropdown;

	@FindBy(xpath = "//label/mat-label[text()='Relationship to applicant']/../../../../../div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
	private WebElement relationshipToApplicantErrorMessage;

	@FindBy(xpath = "//div[contains(text(),'ender:')]")
	private WebElement genderSectionLabel;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Male')]")
	private WebElement maleRadioButton;

	@FindBy(xpath = "//mat-radio-button[contains(@data-gtm,'gender_male_radio')]//input[@value='M']")
	private WebElement maleRadioButtonInternal;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Female')]")
	private WebElement femaleRadioButton;

	@FindBy(xpath = "//mat-radio-button[contains(@data-gtm,'gender_female_radio')]//input[@value='F']")
	private WebElement femaleRadioButtonInternal;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Binary')]")
	private WebElement genderNotSpecifiedRadioButton;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Nonbinary')]")
	private WebElement nonbinaryRadioButton;

	@FindBy(xpath = "//mat-radio-button/label/div[contains(text(), 'Intersex')]")
	private WebElement intersexRadioButton;

	@FindBy(xpath = "//mat-error[@id='error_opt_gender']")
	private WebElement genderErrorMessage;

	// Additional details
	@FindBy(xpath = "//span/label/mat-label[text()='Email address']/../../../input")
	private WebElement emailEntryField;

	@FindBy(xpath = "//span/label/mat-label[text()='Email address']/../../../../../div/div/mat-error")
	private WebElement emailEntryFieldErrorMessage;

	@FindBy(xpath = "//span/label/mat-label[text()='Phone number']/../../../input")
	private WebElement phoneNumberEntryField;

	private static final String PHONE_NUMBER_ENTRY_FIELD_ERROR_MESSAGE_XPATH = "//span/label/mat-label[text()='Phone number']/../../../../../div/div/mat-error";
	@FindBy(xpath = PHONE_NUMBER_ENTRY_FIELD_ERROR_MESSAGE_XPATH)
	private WebElement phoneNumberEntryFieldErrorMessage;

	@FindBy(xpath = "//span[contains(text(), 'address is different')]")
	private WebElement differentMailingAddressCheckbox;

	@FindBy(xpath = "//span/label/mat-label[text()='Mailing address']/../../../input")
	private WebElement mailingAddressEntryField;

	@FindBy(xpath = "//span/label/mat-label[text()='Mailing address']/../../../../../div/div/mat-error")
	private WebElement mailingAddressErrorMessage;

	@FindBy(xpath = "//span/label/mat-label[text()='City']/../../../input")
	private WebElement mailingCityEntryField;

	@FindBy(xpath = "//span/label/mat-label[text()='City']/../../../../../div/div/mat-error")
	private WebElement mailingCityErrorMessage;

	@FindBy(xpath = "//span/label/mat-label[text()='State']/../../../mat-select")
	private WebElement mailingStateDropdown;

	@FindBy(xpath = "//span/label/mat-label[text()='State']/../../../../../div/div/mat-error")
	private WebElement mailingStateErrorMessage;

	@FindBy(xpath = "//span/label/mat-label[text()='ZIP Code']/../../../input")
	private WebElement mailingZipEntryField;

	@FindBy(xpath = "//span/label/mat-label[text()='ZIP Code']/../../../../../div/div/mat-error")
	private WebElement mailingZipErrorMessage;

	@FindBy(xpath = "//button[@id='addDet_backbt']")
	private WebElement additionalDetailsBackButton;

	@FindBy(xpath = "//button[@id='addDet_nextbtn']")
	private WebElement additionalDetailsNextButton;

	@FindBy(className = "p_addnl_disclaimer_text")
	private WebElement additionalDetailsDisclaimer;

	@FindBy(className = "disclaimer_consent")
	private WebElement consentSelectionDisclaimerTextElement;

	@FindBy(className = "auto-module_PEWC")
	private WebElement pewcDisclaimerTextElement;

	@FindBy(className = "ffq-main-title")
	private WebElement rideshareTitle;

	@FindBy(xpath = "//div[contains(@class, 'auto__rideshare')]/p")
	private WebElement rideshareDescription;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Rideshare_Yes_radio']/label/div/input")
	private WebElement vehiclesUsedForRideshareRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Rideshare_Yes_radio']//input")
	private WebElement vehiclesUsedForRideshareGTMElement;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Rideshare_No_radio']/label/div/input")
	private WebElement vehiclesNotUsedForRideshareRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_Rideshare_No_radio']//input")
	private WebElement vehiclesNotUsedForRideshareGTMElement;

	@FindBy(xpath = "//div[contains(@class, 'auto-module__driver_assignment_message-header')]")
	private WebElement vehicleToDriversAssignmentDescription;

	@FindBy(className = "auto-module__driver_assignment_error_message")
	private WebElement vehicleToDriversAssignmentErrorMessage;

	private static final String WHO_DRIVES_VEHICLE_MOST_RADIOBUTTON_XPATH = "//mat-radio-button[@data-gtm='FFQ_Auto_AssignVehiclesDrivers_DriverForVehicle_radio']//input";
	@FindBy (xpath = WHO_DRIVES_VEHICLE_MOST_RADIOBUTTON_XPATH)
	private WebElement driverWhoUsesVehicleMostRadioButton;

	@FindBy (xpath = "//button[@data-gtm='FFQ_Auto_AssignVehiclesDrivers_Discounts_button']")
	private WebElement agreeDriverUsesMostAndNextButton;

	@FindBy(xpath = "//mat-dialog-actions/button[contains(text(), 'Delete')]")
	private WebElement confirmDeleteIncident;

	private static final String XPATH_TO_DRIVER = "//div[@class='ffq-lib__driver_assignment-card ng-star-inserted'][";
	private static final String XPATH_TO_VEHICLE = "]/div/lib-check-box/section/div[";
	private static final String XPATH_FOR_CHECKBOX = "]/mat-checkbox/label";
	private static final String XPATH_TO_INCIDENT_NUMBER = "//span/mat-panel-title/span[contains(text(), 'Incident ";
	private static final String XPATH_TO_REMOVE_INCIDENT_NUMBER = "//mat-panel-description/a[@id='removeIcon";
	private static final String FINISH_REMOVE_XPATH = "']";
	private static final String XPATH_TO_TYPE_GROUP = "')]/../../../../div/div/div/div/lib-radio-button/div/mat-radio-group";
	private static final String ACCIDENT_BUTTON	= "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_IncidentAcc_radio']//input";
	private static final String CITATION_BUTTON = "//mat-radio-button[@data-gtm='FFQ_Auto_Driver_IncidentCitn_radio']//input";
	private static final String XPATH_TO_DESCRIPTION_DROPDOWN = "')]/../../../../div/div/div/div[@class='auto-module__add-driver-input-select']/lib-select/mat-form-field/div/div/div/mat-select";
	private static final String XPATH_TO_INJURIES_GROUP = "')]/../../../../div/div/div/div/lib-radio-button/div/mat-radio-group//mat-radio-button/label";
	private static final String INJURIES_BUTTON	= "/div[contains(text(), 'Yes')]";
	private static final String NO_INJURIES_BUTTON = "/div[contains(text(), 'No')]";
	private static final String XPATH_TO_INCIDENT_DATE_FIELD = "')]/../../../../div/div/div/div[3]/lib-date-picker/mat-form-field/div/div/div/input";

	@FindBy(xpath = "//div[contains(@class, 'auto__driver__footer')]/button[1]")
	private WebElement vehicleToDriversAssignmentBackButton;

	@FindBy(xpath = "//button[@data-gtm='FFQ_Auto_VDassign_next_button' and contains(@class, 'right_button')]")
	private WebElement vehicleToDriversAssignmentNextButton;

	private static final String MARRIED_RADIO_BUTTON_XPATH = "//div[@id='opt_maritalStatus']//input[@value='M']";
	@FindBy(xpath = MARRIED_RADIO_BUTTON_XPATH)
	private WebElement radioMarriedYes;

	@FindBy(xpath = "//div[@id='opt_maritalStatus']//input[@value='S']")
	private WebElement radioMarriedNo;

	private static final String SELECT_OPTION = "//mat-option";
	private static final String YES_BUT_LIVES_AWAY = "Yes, but lives away from home";

	public DriversPage() throws Exception {
	    initDriversPage(true);
	}

	public DriversPage(boolean waitForPage) throws Exception {
	    initDriversPage(waitForPage);
	}

	private void initDriversPage(boolean waitForPage) throws KnockoutException {
		checkForKnockout("DriversPage constructor", LOB_AUTO);
		if (waitForPage) {
		    waitForPage();
		}
	}

	public boolean addPNIDriverInformation(SqlApplicant applicant) throws Exception {
		waitForSpinnerToBeGone();
		selectDriverToInsure(applicant, true);
		if (isADATestingEnabled()) {
		    clickRadioButton(currentlyInsuredRadioButton);
		    clickRadioButton(accidentsInLastYearsRadioButton);
		    WebElement accidentTypeRadioButton = driver().findElement(By.xpath("//mat-radio-button[@data-gtm='FFQ_Auto_Driver_IncidentAcc_radio']//input"));
		    scrollAndClickOnElement(accidentTypeRadioButton);
		    scrollAndClickOnElement(maritalStatusFAQLink);
		    scrollAndClickOnElement(saveDriverDetailsLink);
		    performADATesting(getClass().getSimpleName()+"UsingCurrentlyInsured", MARKETING_IT, "Auto");
		    screenCapture(saveDriverDetailsLink, getClass().getSimpleName()+"UsingCurrentlyInsured", LOB_AUTO, false);
		    closeFAQDialog();
		    clickRadioButton(insuranceExpiredRadioButton);
		    scrollAndClickOnElement(saveDriverDetailsLink);
		    performADATesting(getClass().getSimpleName()+"UsingExpiredInsurance", MARKETING_IT, "Auto");
		    screenCapture(saveDriverDetailsLink, getClass().getSimpleName()+"UsingExpiredInsurance", LOB_AUTO, false);
		    clickRadioButton(neverInsuredRadioButton);
		    scrollAndClickOnElement(saveDriverDetailsLink);
		    performADATesting(getClass().getSimpleName()+"UsingNeverInsured", MARKETING_IT, "Auto");
		    screenCapture(saveDriverDetailsLink, getClass().getSimpleName()+"UsingNeverInsured", LOB_AUTO, false);
		}
		List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC27343", "TC27348"));
		String applicantStateCode = applicant.getStateCode();
		writeTestcaseState("DriversPage.addPNIDriverInformation", applicantStateCode, rallyTestcasesCovered, FAILED);
		enterGender(applicant.getGender());
		if (isEasternExpansionState(applicantStateCode)) {
			selectValueInDropdown(applicant.getMaritalStatus(), maritalStatusDropdown, addDriverDetailsDialogHeader);
		} else {
			enterMaritalStatus(applicant.getMaritalStatus());
			enterOccupation(applicant.getOccupation());
		}
		if (applicantStateCode.equals(LA)) {
			clickRadioButton(notActiveMilitaryDutyStationedInStateRadioButton);
		}
		enterCurrentlyInsured(applicant);
		//NY minimum age limit is 17, not 16 like other states. Adjust the data accordingly
		if (applicantStateCode.equals(NY) && (applicant.getFirstAgeUnitedStatesDriverLicense() < 17)) {
			applicant.setFirstAgeUnitedStatesDriverLicense(17);
		}
		enterAgeFirstLicensed(applicant);
		enterPNIAccidentsOrViolations(applicant.getIncidents(), applicant.isHaveAccidentOrViolations(), isReportInjuriesState(applicantStateCode), applicantStateCode.equals(NC));
		enterFullTimeStudent(applicant.getAge(), applicant.isFullTimeStudentWithHighGPA());
		enterFinancialFiling(applicantStateCode, applicant.getFinancialFiling());
		enterPersonalInjuryLoss(applicantStateCode, applicant.isHavePersonalInjuryLoss());
		enterPrincipalPIP(applicant);
		enterSafetyCourse(applicantStateCode, applicant.getAge(), applicant.isCompletedDriversSafetyCourse());
		enterCommute(applicant);
		waitForSpinnerToBeGone();
		scrollAndClickOnElement(saveDriverDetailsLink);
		waitForSpinnerToBeGone();
		boolean successfullyAddedDriver = noErrorsPresentInPage();
		if (successfullyAddedDriver && isElementPresentByXPath(CLOSE_DIALOG_XPATH)) {
			clickElement(saveDriverDetailsLink);
			waitForSpinnerToBeGone();
			//last try
			if (isElementPresentByXPath(CLOSE_DIALOG_XPATH)) {
				clickElement(saveDriverDetailsLink);
			    waitForSpinnerToBeGone();
			}
			successfullyAddedDriver = !isElementPresentByXPath(CLOSE_DIALOG_XPATH);
		}
		if (!successfullyAddedDriver) {
			Assert.fail("Add PNI Driver failed for quote " + getRedesignedQuoteNumber());
		}
		writeTestcaseState("DriversPage.addPNIDriverInformation", applicantStateCode, rallyTestcasesCovered, PASSED);
		return successfullyAddedDriver;
	}

	public void validatePNIPageErrorMessages(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception{
		waitForSpinnerToBeGone();
		selectDriverToInsure(applicant, true);
		waitAndClickElement(saveDriverDetailsLink);
		String applicantStateCode = applicant.getStateCode();
		verifyElementExpectedContent(setPNIErrorElementsList(applicantStateCode), setPNIExpectedErrorContentMap(applicantStateCode), fsa);
		verifyMessagesDependentOnInteractions(applicantStateCode, fsa);
		validateListOfMaritalStatus(applicantStateCode, fsa);
		validateCloseConfirmationDialog(fsa);
	}

	public void validateAdditionalDriverErrorMessages(SqlAdditionalDriver additionalDriver, String stateCode, FarmersSoftAssert fsa) throws Exception {
		waitForSpinnerToBeGone();
		boolean isSpouse = additionalDriver.getRelationshipToApplicant().equals(SPOUSE);
		if (isSpouse) {
			waitAndClickElement(addSpouseDriverLink);
		} else {
			waitAndClickElement(addAdditionalDriverLink);
		}
		waitAndClickElement(saveDriverDetailsLink);
		waitForSpinnerToBeGone();
		verifyElementExpectedContent(setAdditionalDriverErrorElementsList(isSpouse, stateCode), setAdditionalDriverExpectedErrorContentMap(isSpouse, stateCode), fsa);
		verifyMessagesDependentOnInteractions(stateCode, fsa);
		validateListOfMaritalStatus(stateCode, fsa);
		validateCloseConfirmationDialog(fsa);
	}

	public boolean addAdditionalDriver(SqlAdditionalDriver driver, List<SqlIncident> incidents, String stateCode, int additionalDriverID) throws Exception {
		waitForSpinnerToBeGone();
		scrollToElementBottom(nextButton);
		if (isADATestingEnabled() && additionalDriverID==1) {
		    scrollAndClickOnElement(additionalDriverMaritalStatusFAQLink);
		    scrollAndClickOnElement(saveDriverDetailsLink);
		    performADATesting(getClass().getSimpleName()+"AdditionalDriver", MARKETING_IT, "Auto");
		    screenCapture(saveDriverDetailsLink, getClass().getSimpleName()+"AdditionalDriver", LOB_AUTO, false);
		    closeFAQDialog();
		}
		String relationship = driver.getRelationshipToApplicant();
		WebElement additionalDriverToAddLink = relationship.equals(SPOUSE) || driver.getMaritalStatus().equals(SPOUSE)?
				addSpouseDriverLink : addAdditionalDriverLink;
		waitAndClickElement(additionalDriverToAddLink);
		waitAndClickElement(firstNameADEntryField);
		enterFirstName(driver.getFirstName());
		enterLastName(driver.getLastName());
		enterDateOfBirth(driver.getDateOfBirth());
		enterGender(driver.getGender());
		//NY minimum age limit is 17, not 16 like other states. Adjust the data accordingly
		if (stateCode.equals(NY) && (driver.getFirstAgeUnitedStatesDriverLicense() < 17)) {
			driver.setFirstAgeUnitedStatesDriverLicense(17);
		}
		if (relationship.equals(SPOUSE)) {
			if (driver.getLicenseToDriveInUSA().equals(YES_BUT_LIVES_AWAY) && stateCode.equals(NC)) {
				driver.setLicenseToDriveInUSA(YES);
			}
			enterSpouseLicensedinUSA(stateCode, driver.getLicenseToDriveInUSA(), false);
			if (isSpouseOccupationQuestionState(stateCode)) {
				enterOccupation(driver.getOccupation());
			}
			if (driver.getLicenseToDriveInUSA().equals(YES) ||
					driver.getLicenseToDriveInUSA().equals(YES_BUT_LIVES_AWAY) && !isEasternExpansionState(stateCode)) {
				enterAgeFirstLicensed(stateCode, driver.getAge() <= MAX_YOUNG_AGE, driver.getFirstAgeUnitedStatesDriverLicense(), driver.getFirstAgeForeignDriverLicense(), driver.getDriversLicense(), driver.getLicenseIssueStateName());
			}
			if (isAdditionalDriverFullTimeStudentState(stateCode)) {
				scrollToElementWithOffset(saveDriverDetailsLink, 20);
				enterFullTimeStudent(driver.getAge(), driver.isFullTimeStudentWithHighGPA());
			}
		} else {
			if (isRelationshipToApplicantQuestionState(stateCode)) {
				if (stateCode.equals(MI)) {
					switch (relationship) {
					case RELATIVE:
						relationship = "Non Resident";
						break;
					case PARENT:
						relationship = "Non-Resident Relative";
						break;
					case DAUGHTER: case SON: default:
						relationship = "Resident Relative";
						break;
					}
				}
				enterRelationshipToApplicant(relationship);
			}
			scrollToElement(accidentsInLastYearsRadioButton);
			if (driver.getMaritalStatus().equals(SPOUSE)) {
				enterSpouseLicensedinUSA(stateCode, driver.getLicenseToDriveInUSA(), true);
			} else {
				if (isEasternExpansionState(stateCode)) {
					selectValueInDropdown(driver.getMaritalStatus(), maritalStatusDropdown, addDriverDetailsDialogHeader);
				} else {
					enterAdditionalDriverMaritalStatus(driver.getMaritalStatus());
				}
			}
			enterAgeFirstLicensed(stateCode, driver.getAge() < MAX_YOUNG_AGE, driver.getFirstAgeUnitedStatesDriverLicense(), driver.getFirstAgeForeignDriverLicense(), driver.getDriversLicense(), driver.getLicenseIssueStateName());
			scrollToElementWithOffset(accidentsInLastYearsRadioButton, 20);
			if (isElementVisible(fullTimeStudentWithGPARadioButton, 3)) {
				enterFullTimeStudent(driver.getAge(), driver.isFullTimeStudentWithHighGPA());
				if (isElementVisible(attendingDistantSchoolRadioButton, 3)) {
					scrollToElementWithOffset(accidentsInLastYearsRadioButton, 20);
					enterStudentAtDistantSchool(driver.getAge(), driver.isAttendsDistantSchool());
				}
			}
			if (!isEasternExpansionState(stateCode)) {
				enterOccupation(driver.getOccupation());
			}
		}
		if (!driver.getLicenseToDriveInUSA().equals(NO)) {
			enterAccidentsOrViolations(incidents, additionalDriverID, driver.isAnyIncident(), isReportInjuriesState(stateCode), stateCode.equals(NC));
			if (driver.isAnyIncident()) {
				enterPersonalInjuryLoss(stateCode, incidents.get(additionalDriverID).isAnyInjuries());
			}
			enterSafetyCourse(stateCode, driver.getAge(), driver.isCompletedDriversSafetyCourse());
			enterFinancialFiling(stateCode, driver.getFinancialFiling());
		}
		waitForSpinnerToBeGone();
		scrollAndClickOnElement(saveDriverDetailsLink);
		waitForSpinnerToBeGone();
		boolean successfullyAddedDriver = noErrorsPresentInPage();
		if (successfullyAddedDriver) {
			if (isElementPresentByXPath(CLOSE_DIALOG_XPATH)) {
				scrollAndClickOnElement(saveDriverDetailsLink);
				waitForSpinnerToBeGone();
				successfullyAddedDriver = !isElementPresentByXPath(CLOSE_DIALOG_XPATH);
			}
		} else {
			Assert.fail("Add Additional Driver failed");
		}
		return successfullyAddedDriver;
	}

	public void enterAdditionalDetails(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		forwardToAdditionalInfo();
		waitForSpinnerToBeGone();
		if (isADATestingEnabled()) {
		    scrollAndClickOnElement(differentMailingAddressCheckbox);
		    scrollAndClickOnElement(additionalDetailsNextButton);
		    performADATesting("ContactInformationPage", MARKETING_IT, "Auto");
		    screenCapture(saveDriverDetailsLink, "ContactInformationPage", LOB_AUTO, false);
		    scrollAndClickOnElement(differentMailingAddressCheckbox);
		} else {
		    screenCapture(additionalDetailsNextButton, "Auto_AdditionalDetailsPage", EMPTY_STRING, false);
		}
		scrollToBottomOfPage();
		clickElement(additionalDetailsNextButton);
		fsa.assertEquals(getTextFromElement(emailEntryFieldErrorMessage), EMAIL_ERROR_MESSAGE, "emailEntryFieldErrorMessage error");
		fsa.assertEquals(getTextFromElement(phoneNumberEntryFieldErrorMessage), PHONE_NUMBER_ERROR_MESSAGE, "phoneNumberEntryFieldErrorMessage error");
		String applicantStateCode = applicant.getStateCode();
		if (isPETEnvironment()) {
			fsa.assertEquals(getTextFromElement(pewcDisclaimerTextElement), "By clicking \"Agree and submit\", you agree to these ESIGN terms and conditions and to receive marketing calls and text messages as detailed below. " +
					"We sometimes call and/or text consumers to provide helpful information about products and services. " +
					"By clicking \"Agree and submit\", you consent to receive marketing calls and text messages on behalf of Farmers\u00ae, Foremost\u00ae, Bristol West\u00ae, and Farmers Life\u00ae insurance associated entities and their representatives using an automated telephone dialing system, AI-generated voice, and by artificial or pre-recorded voice, even if your number(s) is/are listed on a national, state, or business do-not-call registry. " +
					"Consent is not a condition of purchase. You can go to Farmers.com for alternative contact information. Message and data rates may apply.", "pewcDisclaimerTextElement");
		} else {
			fsa.assertEquals(getTextFromElement(pewcDisclaimerTextElement), "By clicking \"Agree and submit\", you agree to these ESIGN terms and conditions and to receive marketing calls and texts as detailed below. " +
					"We call and/or text consumers with information about products and services. " +
					"By clicking \"Agree and submit\", you consent to receive marketing calls and texts on behalf of Farmers\u00ae, Foremost\u00ae, Bristol West\u00ae, and Farmers Life\u00ae associated entities and their representatives using an automated telephone dialing system, AI-generated and artificial or pre-recorded voice, even for numbers listed on national, state, or business do-not-call registries. " +
					"Consent is not a condition of purchase. Go to Farmers.com for alternative contact options. Message and data rates may apply.", "pewcDisclaimerTextElement");
		}
		enterValueInField(applicant.getEmail(),  emailEntryField, "Enter applicant email");
		enterValueInField(applicant.getPhoneNumber(), phoneNumberEntryField, "Enter applicant phone number");
		if (isDifferentMailingAddressState(applicantStateCode)) {
			clickElement(differentMailingAddressCheckbox);
			clickElement(mailingAddressEntryField);
			clickElement(additionalDetailsNextButton);
			fsa.assertEquals(getTextFromElement(mailingAddressErrorMessage), MAILING_ADDRESS_ERROR_MESSAGE, "mailingAddressErrorMessage error");
			fsa.assertEquals(getTextFromElement(mailingCityErrorMessage), MAILING_CITY_ERROR_MESSAGE, "mailingCityErrorMessage error");
			fsa.assertEquals(getTextFromElement(mailingStateErrorMessage), MAILING_STATE_ERROR_MESSAGE, "mailingStateErrorMessage error");
			fsa.assertEquals(getTextFromElement(mailingZipErrorMessage), MAILING_ZIPCODE_ERROR_MESSAGE, "mailingZipErrorMessage error");
			if (applicant.isMailingAddressDifferent()) {
				enterValueInField(applicant.getResidentAddress1(), mailingAddressEntryField, "Enter mailing address");
				enterValueInField(applicant.getCity(), mailingCityEntryField, "Enter mailing city");
				selectValueInDropdown(applicant.getStateName(), mailingStateDropdown, emailEntryField);
				enterValueInField(applicant.getZipCode(),mailingZipEntryField, "Enter mailing zip code");
			} else {
				clickElement(differentMailingAddressCheckbox);
			}
		}
		String quoteNumber = getRedesignedQuoteNumber();
		clickAdditionalDetailsNextButton();
		if (isBrightlinedQuote()) {
			continueToBristolWest(true);
			waitForSpinnerToBeGone();
			isBristolWest = true;
		}
		checkForKnockout("DriversPage.enterAdditionalDetails", quoteNumber);
	}

	public void clickAdditionalDetailsNextButton() {
		waitForSpinnerToBeGone();
		scrollToBottomOfPage();
		scrollAndClickOnElement(additionalDetailsNextButton);
		waitForSpinnerToBeGone();
	}

	public String getEmailAddress() {
		return getElementValue(emailEntryField, "Email address");
	}

	public boolean isEmailAddressDisabled() {
		return !getAttributeData(emailEntryField, DISABLED).equals(EMPTY_STRING);
	}

	public String getPhoneNumber() {
		return getElementValue(phoneNumberEntryField, "Phone number");
	}

	public boolean isPhoneNumberDisabled() {
		return !getAttributeData(phoneNumberEntryField, DISABLED).equals(EMPTY_STRING);
	}

	public DiscountsPage enterVehicleAssignmentData(SqlApplicant applicant, boolean doDeepValidation, FarmersSoftAssert fsa) throws Exception {
		String applicantStateCode = applicant.getStateCode();
		if (isVehicleAssignmentState(applicantStateCode)) {
			int driverCount = getDriverCount(applicant);
			int vehicleCount = applicant.getVehicles().size();
			if  (!(driverCount==1 && vehicleCount==1)){
				waitElementBeVisible(vehicleToDriversAssignmentDescription);
				if (isADATestingEnabled()) {
				    scrollAndClickOnElement(vehicleToDriversAssignmentNextButton);
				    performADATesting("VehicleAssignmentPage", MARKETING_IT, "Auto");
				    screenCapture(saveDriverDetailsLink, "VehicleAssignmentPage", LOB_AUTO, false);
				}
				if (doDeepValidation && !isBristolWestQuote()) {
					validateVehicleAssignmentPage(applicant, fsa);
				}
				if (isBristolWestQuote() && applicantStateCode.equals(NY)) {
					WebElement vehicleAssignmentSelectionDropdown = driver().findElement(By.xpath(BW_DRIVER_TO_ASSIGN_XPATH_BEGIN + applicant.getFirstName() + SPACE + applicant.getLastName() + BW_DRIVER_TO_ASSIGN_XPATH_END));
					selectFromDropDownByPosition(vehicleAssignmentSelectionDropdown, FIRST_AVAILABLE_OPTION, vehicleToDriversAssignmentDescription );
					if (!applicant.getAdditionalDrivers().isEmpty()) {
						for (int additionalDriverNum=0; additionalDriverNum<applicant.getAdditionalDrivers().size(); additionalDriverNum++) {
							vehicleAssignmentSelectionDropdown = driver().findElement(By.xpath(BW_DRIVER_TO_ASSIGN_XPATH_BEGIN +
									applicant.getAdditionalDrivers().get(additionalDriverNum).getFirstName() + SPACE + applicant.getAdditionalDrivers().get(additionalDriverNum).getLastName() + BW_DRIVER_TO_ASSIGN_XPATH_END));
							selectFromDropDownByPosition(vehicleAssignmentSelectionDropdown, additionalDriverNum+1, vehicleToDriversAssignmentDescription );
						}
					}
				} else {
					List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC33471", "TC33473", "TC33499"));
					writeTestcaseState("DriversPage.driversToVehicleAssignmentTests", applicantStateCode, rallyTestcasesCovered, FAILED);
					for (int index = 1; index<=driverCount && index<=vehicleCount; index++) {
						WebElement vehicleAssignmentSelection = driver().findElement(By.xpath(XPATH_TO_DRIVER + index + XPATH_TO_VEHICLE + index + XPATH_FOR_CHECKBOX));
						clickElement(vehicleAssignmentSelection);
					}
					String testMethod = "DriversPage.vehicleToDriversAssignmentTests";
					if (vehicleCount > driverCount) {
						List<String> rallyCasesCovered = new ArrayList<>(Arrays.asList("TC35104", "TC53105", "TC35106", "TC35130", "TC35131", "TC35132"));
						writeTestcaseState(testMethod, applicantStateCode, rallyCasesCovered, FAILED);
						for (int index = vehicleCount; index > driverCount; index--) {
							WebElement vehicleAssignmentSelection = driver().findElement(By.xpath(XPATH_TO_DRIVER + "1" + XPATH_TO_VEHICLE + index + XPATH_FOR_CHECKBOX));
							clickElement(vehicleAssignmentSelection);
						}
						writeTestcaseState(testMethod, applicantStateCode, rallyCasesCovered, PASSED);
					} else if (!applicantStateCode.equals(CA) && driverCount > vehicleCount) {
						List<String> rallyCasesCovered = new ArrayList<>(Arrays.asList("TC35097", "TC35098"));
						writeTestcaseState(testMethod, applicantStateCode, rallyCasesCovered, FAILED);
						for (int index = driverCount; index > vehicleCount; index--) {
							WebElement vehicleAssignmentSelection = driver().findElement(By.xpath(XPATH_TO_DRIVER + index + XPATH_TO_VEHICLE + "1" + XPATH_FOR_CHECKBOX));
							clickElement(vehicleAssignmentSelection);
						}
						writeTestcaseState(testMethod, applicantStateCode, rallyCasesCovered, PASSED);
					}
					writeTestcaseState("DriversPage.driversToVehicleAssignmentTests", applicantStateCode, rallyTestcasesCovered, PASSED);
				}
				clickElement(vehicleToDriversAssignmentNextButton);
			}
		} else {
			if (isElementPresent(By.xpath(WHO_DRIVES_VEHICLE_MOST_RADIOBUTTON_XPATH), 2)) {
				clickRadioButton(driverWhoUsesVehicleMostRadioButton);
				clickElement(agreeDriverUsesMostAndNextButton);
			}
		}
		return new DiscountsPage();
	}

	public void validatePNIFAQs(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		waitForSpinnerToBeGone();
		selectDriverToInsure(applicant, true);
		validateDriversFAQs(applicant.getStateCode(), true, applicant.getAge(), fsa);
		clickElement(closeAddDriverDetailsDialog);
		if (isElementPresentByID(closeDetailsConfirmationDialogContent)) {
			waitElementBeVisible(closeDetailsConfirmationDialogContent);
			clickElement(closeConfirmationDialogCloseButton);
		}
		waitForPage();
	}

	public void validateAdditionalDriversFAQs(SqlAdditionalDriver additionalDriver, String stateCode, FarmersSoftAssert fsa) throws Exception {
		waitForSpinnerToBeGone();
		boolean isSpouse = additionalDriver.getRelationshipToApplicant().equals(SPOUSE);
		if (isSpouse) {
			waitAndClickElement(addSpouseDriverLink);
		} else {
			waitAndClickElement(addAdditionalDriverLink);
		}
		validateDriversFAQs(stateCode, false, additionalDriver.getAge(), fsa);
		clickElement(closeAddDriverDetailsDialog);
	}

	public void validateDriversPageContent(FarmersSoftAssert fsa) {
		fsa.assertEquals(getTextFromElement(driversPageHeader), DRIVERS_PAGE_HEADER, "driversPageHeader text verification");
	}

	public void validateGTMTags(FarmersSoftAssert fsa) {
		if (isElementPresentByClass(addDriverDetailsDialogHeader)) {
			clickElement(closeAddDriverDetailsDialog);
		}
		scrollToElement(backButton);
		verifyElementExpectedAttribute(getListWithPageElements(), getMapWithExpectedGTMTags(), "data-gtm", fsa);
	}

	public boolean saveQuoteAndFinishLater(SqlApplicant applicant) {
		return saveAutoQuoteAndFinishLater(applicant, DRIVERS_PAGE_AUTO, applicant.isSaveAndRetrieveDriversPage());
	}

	public void forwardToAdditionalInfo() {
		waitForSpinnerToBeGone();
		scrollAndClickOnElement(nextButton);
	}

	public void selectDriverToInsure(boolean firstDriver) {
		if (firstDriver) {
			waitElementBeVisible(closeAddDriverDetailsDialog);
		} else {
			waitElementBeVisibleClickable(checkSelectSpouseDriver);
			waitAndClickElement(checkSelectSpouseDriver);
		}
	}

	public Boolean isMarried() {
		if (isElementPresentByXPath(MARRIED_RADIO_BUTTON_XPATH)) {
			return radioMarriedYes.isSelected();
		} else {
			return getTextFromElement(maritalStatusDropdown).equalsIgnoreCase(MARRIED);
		}
	}

	public String getOccupation() {
		String occupation = null;
		if (isElementPresentByXPath(OCCUPATION_ENTRY_FIELD_XPATH)) {
			occupation = getElementValue(occupationEntryField, "Occupation");
		}
		return occupation;
	}

	public void fillDriverInfo(ApplicantHQM applicantHqm, boolean firstDriver) throws Exception {
		if (firstDriver) {
			enterGender(applicantHqm.gender);
			this.setMaritalStatus(applicantHqm);
		} else {
			enterGender(applicantHqm.spouseGender);
		}
		if (applicantHqm.stateCode.equals(LA)) {
			clickElement(notActiveMilitaryDutyStationedInStateRadioButton);
		}
		if (isElementDisplayed(By.xpath(CURRENTLY_INSURED_XPATH))) {
			this.setCurrentlyInsured();
			this.enterInsuranceCompanyInfo(currentAutoInsuranceCompanyEntryField, "AAA");
			this.selectHowLongHadInsurance("12");
			if (isElementDisplayed(By.xpath(SIX_MONTHS_COVERAGE_YES_XPATH))) {
				this.setSixMonthsCoverage(true);
			}
			this.selectBodilyInjuryLimits("$50,000/$100,000");
			sendKeysToElement(policyExpirationDateEntryField,
					LocalDate.now().plusDays(30).format(DateTimeFormatter.ofPattern(MM_DD_YYYY)));
		}
		if (isElementDisplayed(By.xpath(SPOUSE_LICENSED_IN_USA_DROPDOWN_XPATH)) ||
				isElementDisplayed(By.xpath(SPOUSE_LICENSED_TO_DRIVE_XPATH))) {
			enterSpouseLicensedinUSA(applicantHqm.stateCode, YES, false);
		}
		this.enterAgeFirstLicensed(applicantHqm.stateCode, false, 18, 0, "B4943227", "California");
		this.scrollOffsetClickOnElement(noAccidentsInLastYearsRadioButton);
		if (isElementPresentByXPath(COMMUTERS_TO_OTHER_STATE_RADIO_BUTTON_XPATH)) {
			scrollAndClickOnElement(noCommutersToOtherStateRadioButton);
		}
		if (isElementDisplayed(By.xpath(NOT_FULLTIME_STUDENT_XPATH))) {
			this.scrollOffsetClickOnElement(notFullTimeStudentWithGPARadioButton);
		}
		if (isElementDisplayed(By.xpath(NO_FINANCIAL_FILING_XPATH))) {
			this.scrollOffsetClickOnElement(noFinancialFilingRadioButton);
		}
		if (isElementDisplayed(By.xpath(SAFETY_COURSE_COMPLETED_XPATH))) {
			this.scrollOffsetClickOnElement(safetyCourseCompletedRadioButton);
		}
		waitAndClickElement(saveDriverDetailsLink);
		wait.until(invisibilityOf(addAdditionalDriverDetailsDialogHeader));
	}

	public void setSpouseName(String firstName, String lastName, String dob) {
		waitElementBeVisible(addAdditionalDriverDetailsDialogHeader);
		for (int i=3; i > 0; i--) {
			enterFirstName(firstName);
			enterLastName(lastName);
			enterDateOfBirth(dob);
			if (getFirstName().equals(firstName) && getLastName().equals(lastName) && getDob().equals(dob)) {
				break;
			}
		}
	}

	public void setEmailPhone(String email, String phone) {
		enterValueInField(email, emailEntryField, "email");
		enterValueInField(phone, phoneNumberEntryField, "phone");
	}

	public void setMaritalStatus(ApplicantHQM applicantHqm) throws Exception {
		try {
			if (isEasternExpansionState(applicantHqm.stateCode)) {
				if (applicantHqm.maritalStatus.equalsIgnoreCase(MARRIED)) {
					selectValueInDropdown(MARRIED, maritalStatusDropdown, addDriverDetailsDialogHeader);
				} else {
					selectValueInDropdown(SINGLE, maritalStatusDropdown, addDriverDetailsDialogHeader);
				}
			} else {
				waitElementBeVisible(marriedRadioButton);
				enterMaritalStatus(applicantHqm.maritalStatus);
				enterOccupation(applicantHqm.occupation);
			}
		} catch (ElementNotInteractableException e) {
			Log.info("Drivers page - Married field and/or Occupation field is disabled.");
		}
	}

	public void assignCarsToDrivers() throws Exception {
		String assignXpath = "//mat-checkbox[contains(@data-gtm,'FFQ_Auto_VDassign')]";
		if (isElementPresent(By.xpath(assignXpath), 5)) {
			List<WebElement> checkboxes = driver().findElements(By.xpath(assignXpath));
			for (WebElement chkWe : checkboxes) {
				waitAndClickElement(chkWe);
			}
			scrollToBottomOfPage();
			clickElement(vehicleToDriversAssignmentNextButton);
		}
	}

	public void cancelAddDriver() {
		waitForSpinnerToBeGone();
		waitAndClickElement(closeAddDriverDetailsDialog);
	}

	private void enterSpouseLicensedinUSA(String stateCode, String licensedToDriveInUSA, boolean spouseOfRelative) throws Exception {
		String notLicensed = "No, not licensed";
		if (isEasternExpansionState(stateCode)) {
			if (licensedToDriveInUSA.equals(NO)) {
				licensedToDriveInUSA = notLicensed;
			}
			scrollElementToMiddle(spouseLicensedinUSADropdown);
			selectValueInDropdown(licensedToDriveInUSA, spouseLicensedinUSADropdown, spouseLicensedToDriveInUSLabel);
			clickElement(spouseLicensedToDriveInUSLabel);
			if (stateCode.equals(LA) && !licensedToDriveInUSA.equals(notLicensed) && !spouseOfRelative) {
				clickRadioButton(spouseNotActiveMilitaryDutyStationedInStateRadioButton);
			}
		} else {
			scrollElementToMiddle(spouseLicensedToDriveRadioButton);
			switch (licensedToDriveInUSA) {
			case NO :
				clickRadioButton(spouseNotLicensedToDriveRadioButton);
				break;
			case YES :
				clickRadioButton(spouseLicensedToDriveRadioButton);
				break;
			case YES_BUT_LIVES_AWAY :
				clickRadioButton(spouseLivesAwayRadioButton);
				break;
			default :
				Log.error("Unknown licensed to drive status: " + licensedToDriveInUSA);
				break;
			}
		}
	}

	private void enterAgeFirstLicensed(SqlApplicant applicant) throws Exception {
		enterAgeFirstLicensed(applicant.getStateCode(), applicant.getAge() <= MAX_YOUNG_AGE, applicant.getFirstAgeUnitedStatesDriverLicense(), applicant.getFirstAgeForeignDriverLicense(), applicant.getDriversLicense(), applicant.getLicenseIssueStateName());
	}


	private void enterAgeFirstLicensed(String stateCode, boolean isYoungDriver, int firstAgeUnitedStatesDriverLicense, int firstAgeForeignDriverLicense, String driversLicense, String licenseIssueStateName) throws Exception {
		if (isEasternExpansionState(stateCode)) {
			if (firstAgeForeignDriverLicense > 0) {
				enterValueInField(String.valueOf(firstAgeForeignDriverLicense), ageFirstLicensedEntryField, "ageFirstLicensedEntryField");
				if (stateCode.equals(MA)) {
					setCheckboxTo(licenseIssuedInForeignCountryCheckbox, true);
				}
			} else {
				enterValueInField(String.valueOf(firstAgeUnitedStatesDriverLicense), ageFirstLicensedEntryField, "ageFirstLicensedEntryField");
				if (stateCode.equals(MA)) {
					enterDriverLicense(driversLicense);
					selectDriverLicenseIssueState(licenseIssueStateName);
				}
			}
		} else {
			if (firstAgeForeignDriverLicense > 0) {
				clickRadioButton(notLicensedByUSStateRadioButton);
			}
			if (!stateCode.equals(MT)) {
				// This doesn't seem to apply anymore
//				enterValueInField(String.valueOf(firstAgeUnitedStatesDriverLicense), ageFirstLicensedEntryField, "ageFirstLicensedEntryField");
			}
		}
	}

	private void enterDriverLicense(String driversLicense) {
		enterValueInField(driversLicense, driversLicenseEntryField, "driversLicense");
	}

	private void selectDriverLicenseIssueState(String licenseIssueStateName) throws Exception {
		selectValueInDropdown(licenseIssueStateName, driversLicenseIssueStateDropdown, addDriverDetailsDialogHeader);
	}

	private void enterPNIAccidentsOrViolations(List<SqlIncident> incidentList, boolean haveAccidentOrViolations, boolean reportInjuriesState, boolean adjustDescriptionState) throws Exception {
		enterAccidentsOrViolations(incidentList, 0, haveAccidentOrViolations, reportInjuriesState, adjustDescriptionState);
	}

	private void enterAccidentsOrViolations(List<SqlIncident> incidentList, int driverID, boolean anyIncidents, boolean reportInjuriesState, boolean adjustDescriptionState) throws Exception {
		if (anyIncidents) {
			List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC26813", "TC26816", "TC26817"));
			writeTestcaseState("DriversPage.enterAccidentsOrViolations", ALL_STATES, rallyTestcasesCovered, FAILED);
			clickRadioButton(accidentsInLastYearsRadioButton);
			int numberOfIncidents = incidentList.size();
			int incidentNumber = 1;
			for (int incidentIndex = 0; incidentIndex < numberOfIncidents; incidentIndex++) {
				SqlIncident incident = incidentList.get(incidentIndex);
				if (incident.getAdditionalDriverId() == driverID) {
					enterIncidentData(incident, reportInjuriesState, incidentNumber++, adjustDescriptionState);
				}
			}
			writeTestcaseState("DriversPage.enterAccidentsOrViolations", ALL_STATES, rallyTestcasesCovered, PASSED);
		} else {
			clickRadioButton(noAccidentsInLastYearsRadioButton);
		}
	}

	private void enterIncidentData(SqlIncident incident, boolean reportInjuriesState, int incidentNumber, boolean adjustDescriptionState) throws Exception {
		if (incident.getIncidentType().equals("Remove")) {
			List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC26759", "TC26770", "TC26771", "TC26818", "TC26819", "TC26820",
					"TC26823", "TC26825", "TC26827"));
			writeTestcaseState("DriversPage.deleteIncident", ALL_STATES, rallyTestcasesCovered, FAILED);
			WebElement removeIncidentIcon = driver().findElement(By.xpath(XPATH_TO_REMOVE_INCIDENT_NUMBER + incident.getDescription() + FINISH_REMOVE_XPATH));
			scrollOffsetClickOnElement(removeIncidentIcon);
			waitAndClickElement(confirmDeleteIncident);
			writeTestcaseState("DriversPage.deleteIncident", ALL_STATES, rallyTestcasesCovered, PASSED);
		} else {
			if (incident.getIncidentType().equals("Edit")) {
				incidentNumber--;
			} else if (incidentNumber != 1) {
				clickElement(addAnotherIncidentButton);
			}
			boolean incidentIsAccident = incident.getIncidentType().equals(ACCIDENT);
			String xpathToIncidentHeader = XPATH_TO_INCIDENT_NUMBER + incidentNumber;
			WebElement incidentTypeRadioButton = incidentIsAccident ? driver().findElement(By.xpath(xpathToIncidentHeader + XPATH_TO_TYPE_GROUP + ACCIDENT_BUTTON)):
				driver().findElement(By.xpath(xpathToIncidentHeader + XPATH_TO_TYPE_GROUP + CITATION_BUTTON));
			//multiple calls because of Selenium interaction issues
			clickRadioButton(incidentTypeRadioButton);
			WebElement dateEntryField = driver().findElement(By.xpath(xpathToIncidentHeader + XPATH_TO_INCIDENT_DATE_FIELD));
			enterValueInField(incident.getDateOccured(), dateEntryField, "dateEntryField");
			WebElement descriptionDropdown = driver().findElement(By.xpath(xpathToIncidentHeader + XPATH_TO_DESCRIPTION_DROPDOWN));
			String incidentDescription = adjustDescriptionState? adjustIncidentDescription(incident.getDescription()) : incident.getDescription();
			if (incidentDescription.equals("Accident was not driver")) {
				incidentDescription = "Accident was not driver's fault";
			}
			selectValueInDropdown(incidentDescription, descriptionDropdown, incidentTypeRadioButton);
			if (incidentIsAccident && reportInjuriesState) {
				String xpathToInjuriesSelection = xpathToIncidentHeader + XPATH_TO_INJURIES_GROUP;
				if (incident.isAnyInjuries()) {
					xpathToInjuriesSelection =  xpathToInjuriesSelection.concat(INJURIES_BUTTON);
				} else {
					xpathToInjuriesSelection =  xpathToInjuriesSelection.concat(NO_INJURIES_BUTTON);
				}
				WebElement injuriesSelectionRadioButton = driver().findElement(By.xpath(xpathToInjuriesSelection));
				clickRadioButton(injuriesSelectionRadioButton);
			}
		}
	}

	private void enterFullTimeStudent(int age, boolean fullTimeStudentWithHighGPA) {
		if(age < MAX_YOUNG_AGE) {
			scrollElementToMiddle(fullTimeStudentWithGPARadioButton);
			if(fullTimeStudentWithHighGPA) {
				Log.info("A full-time student with GPA of 3.0 or higher");
				clickRadioButton(fullTimeStudentWithGPARadioButton);
			} else {
				Log.info("Not a full-time student with GPA of 3.0 or higher");
				clickRadioButton(notFullTimeStudentWithGPARadioButton);
			}
		}
	}

	private void enterStudentAtDistantSchool(int age, boolean attendsDistantSchool) {
		if(age < MAX_YOUNG_AGE) {
			scrollElementToMiddle(attendingDistantSchoolRadioButton);
			if(attendsDistantSchool) {
				Log.info("Attending a distant school");
				clickRadioButton(attendingDistantSchoolRadioButton);
			} else {
				Log.info("Not attending a distant school");
				clickRadioButton(notAttendingDistantSchoolRadioButton);
			}
		}
	}

	private void enterFinancialFiling(String stateCode, String financialFiling) {
		String method = "DriversPage.enterFinancialFiling";
		if (isFinancialFilingState(stateCode)) {
			List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC27028"));
			writeTestcaseState(method, stateCode, rallyTestcasesCovered, FAILED);
			waitElementBeVisibleClickable(noFinancialFilingRadioButton);
			switch (financialFiling) {
			case "No":
				clickRadioButton(noFinancialFilingRadioButton);
				break;
			case SR_22:
				clickRadioButton(sr22RadioButton);
				break;
			case "FR-22":
				clickRadioButton(fr22RadioButton);
				break;
			default:
				throw new IllegalArgumentException("Invalid financial filing: " + financialFiling);
			}
			writeTestcaseState(method, stateCode, rallyTestcasesCovered, PASSED);
		} else {
			List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC27027"));
			writeTestcaseState(method, stateCode, rallyTestcasesCovered, FAILED);
			Assert.assertFalse(isElementPresentByXPath(NO_FINANCIAL_FILING_XPATH), "Financial filing question found");
			writeTestcaseState(method, stateCode, rallyTestcasesCovered, PASSED);
		}
	}

	private void enterPersonalInjuryLoss(String stateCode, boolean hasPersonalInjuryLoss) {
		if (isPersonalInjuryLossState(stateCode)) {
			if (hasPersonalInjuryLoss) {
				clickRadioButton(personalInjuryRadioButton);
			} else {
				clickRadioButton(noPersonalInjuryRadioButton);
			}
		}
	}

	private void enterPrincipalPIP(SqlApplicant applicant) throws Exception {
		if (isPrincipalPIPState(applicant.getStateCode())) {
			selectValueInDropdown(applicant.getPrincipalPIP(), principalPIPDropdown, addDriverDetailsDialogHeader);
		}
	}

	private void enterSafetyCourse(String stateCode, int age, boolean completedSafetyCourse) {
		if (stateCode.equals(CT) && isBristolWestQuote()) {
			age-=5;
		}
		if (isSafetyCourseState(stateCode) || (isSafetyCourseStateForOlderDrivers(stateCode) && age >= MIN_OLD_AGE)) {
			if (completedSafetyCourse) {
				clickRadioButton(safetyCourseCompletedRadioButton);
				if (stateCode.equals(PA)) {
					enterValueInField(LocalDate.now().minusYears(1).format(DateTimeFormatter.ofPattern(MM_DD_YYYY)), safetyCourseCompletedateEntryField, "safetyCourseCompletedateEntryField");
				}
			} else {
				clickRadioButton(noSafetyCourseCompletedRadioButton);
			}
		}
	}

	private void enterCommute(SqlApplicant applicant) {
		if (isCommuterState(applicant.getStateCode())) {
			// For now hard coded to say no, would need to add data column and appropriate logic
			clickRadioButton(noCommutersToOtherStateRadioButton);
		}
	}

	private void enterFirstName(String firstName) {
		enterValueInField(firstName, firstNameADEntryField, "First name");
	}

	private String getFirstName() {
		return getElementValue(firstNameADEntryField, "First name");
	}

	private void enterLastName(String lastName) {
		enterValueInField(lastName, lastNameADEntryField, "Last name");
	}

	private String getLastName() {
		return getElementValue(lastNameADEntryField, "Last name");
	}

	private void enterDateOfBirth(String dob) {
		enterValueInField(dob, dobADEntryField, "Date of birth");
	}

	private String getDob() {
		return getElementValue(dobADEntryField, "Date of birth");
	}

	private void enterRelationshipToApplicant(String relationship) throws Exception {
		selectValueInDropdown(relationship, relationshipToApplicantDropdown, addAdditionalDriverDetailsDialogHeader);
	}

	private void enterGender(String gender) {
		waitElementBeVisibleClickable(maleRadioButton);
		if (gender.equals(MALE)) {
			clickRadioButton(maleRadioButtonInternal);
		} else if (gender.equals(FEMALE)) {
			clickRadioButton(femaleRadioButtonInternal);
		} else if (gender.equals(NOT_SPECIFIED) && isElementVisible(genderNotSpecifiedRadioButton, 3)) {
			clickRadioButton(genderNotSpecifiedRadioButton);
		} else if (gender.equals(NOT_SPECIFIED) && isElementVisible(nonbinaryRadioButton, 3)) {
			clickRadioButton(nonbinaryRadioButton);
		} else if (gender.equals(INTERSEX) && isElementVisible(intersexRadioButton, 3)) {
			clickRadioButton(intersexRadioButton);
		} else {
			throw new IllegalArgumentException("Button disabled or invalid gender specified: " + gender);
		}
	}

	private boolean verifyMessagesDependentOnInteractions(String stateCode, FarmersSoftAssert fsa) throws Exception {
		scrollToElementWithOffset(accidentsInLastYearsRadioButton, 20);
		clickRadioButton(accidentsInLastYearsRadioButton);
		saveDriverDetailsLink.click();
		fsa.assertEquals(getTextFromElement(incidentTypeErrorMessage), INCIDENT_TYPE_ERROR_MESSAGE, "incidentTypeErrorMessage error") ;
		fsa.assertEquals(getTextFromElement(incidentDateErrorMessage), INCIDENT_DATE_ERROR_MESSAGE, "incidentDateErrorMessage error") ;
		scrollOffsetClickOnElement(accidentRadioButton);
		waitElementBeVisibleClickable(incidentDescriptionDropdown);
		scrollAndClickOnElement(saveDriverDetailsLink);
		fsa.assertEquals(getTextFromElement(incidentDescriptionErrorMessage), INCIDENT_DESCRIPTION_ERROR_MESSAGE, "incidentDescriptionErrorMessage error");
		if (isPrincipalPIPState(stateCode) && isElementPresentByXPath(CURRENTLY_INSURED_XPATH)) {
			clickRadioButton(currentlyInsuredRadioButton);
			saveDriverDetailsLink.click();
			fsa.assertEquals(getTextFromElement(principalPIPErrorMessage), PIP_ERROR_MESSAGE, "principalPIPErrorMessage error");
		}
		return true;
	}

	private List<WebElement> setPNIErrorElementsList(String stateCode) {
		List<WebElement> errorMessageElements = new ArrayList<>();
		if (isEasternExpansionState(stateCode)) {
			errorMessageElements.add(maritalStatusDropdownErrorMessage);
		} else {
			errorMessageElements.add(maritalStatusRadioButtonsErrorMessage);
		}
		if (isEasternExpansionState(stateCode)) {
			errorMessageElements.add(ageFirstLicensedErrorMessage);
		}
		errorMessageElements.add(accidentsOrViolationsErrorMessage);
		if (isCurrentInsuredStatusState(stateCode)) {
			errorMessageElements.add(currentlyInsuredStatusErrorMessage);
		}
		if (isFinancialFilingState(stateCode)) {
			errorMessageElements.add(financialFilingErrorMessage);
		}
		if (isSafetyCourseState(stateCode)) {
			errorMessageElements.add(safetyCourseCompletedErrorMessage);
		}
		if (isCommuterState(stateCode)) {
			errorMessageElements.add(commutersErrorMessage);
		}
		return errorMessageElements;
	}

	private Map<WebElement, String> setPNIExpectedErrorContentMap(String stateCode) {
		Map<WebElement,String> errorMessagesMap = new HashMap<>();
		if (isEasternExpansionState(stateCode)) {
			errorMessagesMap.put(maritalStatusDropdownErrorMessage, MARITAL_STATUS_DROPDOWN_ERROR_MESSAGE);
		} else {
			errorMessagesMap.put(maritalStatusRadioButtonsErrorMessage, MARITAL_STATUS_RADIO_BUTTONS_ERROR_MESSAGE);
		}
		if (isEasternExpansionState(stateCode)) {
			errorMessagesMap.put(ageFirstLicensedErrorMessage, AGE_FIRST_LICENSED_ERROR_MESSAGE);
		}
		errorMessagesMap.put(accidentsOrViolationsErrorMessage, ACCIDENTS_OR_VIOLATIONS_ERROR_MESSAGE);
		if (isCurrentInsuredStatusState(stateCode)) {
			errorMessagesMap.put(currentlyInsuredStatusErrorMessage, CHOOSE_YES_OR_NO_ERROR_MESSAGE);
		}
		if (isFinancialFilingState(stateCode)) {
			errorMessagesMap.put(financialFilingErrorMessage, FINANCIAL_FILING_ERROR_MESSAGE);
		}
		if (isSafetyCourseState(stateCode)) {
			errorMessagesMap.put(safetyCourseCompletedErrorMessage, CHOOSE_YES_OR_NO_ERROR_MESSAGE);
		}
		if (isCommuterState(stateCode)) {
			errorMessagesMap.put(commutersErrorMessage, CHOOSE_YES_OR_NO_ERROR_MESSAGE);
		}
		return errorMessagesMap;
	}

	private List<WebElement> setAdditionalDriverErrorElementsList(boolean isSpouse, String stateCode) {
		List<WebElement> errorMessageElements = new ArrayList<>();
		errorMessageElements.add(firstNameADErrorMessage);
		errorMessageElements.add(lastNameADErrorMessage);
		errorMessageElements.add(dobADErrorMessage);
		if (!isSpouse && isRelationshipToApplicantQuestionState(stateCode)) {
			errorMessageElements.add(relationshipToApplicantErrorMessage);
			if (isEasternExpansionState(stateCode)) {
				errorMessageElements.add(maritalStatusDropdownErrorMessage);
			} else {
				errorMessageElements.add(maritalStatusRadioButtonsErrorMessage);
			}
		}
		errorMessageElements.add(genderErrorMessage);
		if (isEasternExpansionState(stateCode) || stateCode.equals(CA)) {
			errorMessageElements.add(ageFirstLicensedErrorMessage);
		}
		errorMessageElements.add(accidentsOrViolationsErrorMessage);
		return errorMessageElements;
	}

	private Map<WebElement, String> setAdditionalDriverExpectedErrorContentMap(boolean isSpouse, String stateCode) {
		Map<WebElement,String> errorMessagesMap = new HashMap<>();
		errorMessagesMap.put(firstNameADErrorMessage, FIRSTNAME_ERROR_MESSAGE);
		errorMessagesMap.put(lastNameADErrorMessage, LASTNAME_LICENSED_ERROR_MESSAGE);
		errorMessagesMap.put(dobADErrorMessage, DOB_ERROR_MESSAGE);
		if (!isSpouse && isRelationshipToApplicantQuestionState(stateCode)) {
			errorMessagesMap.put(relationshipToApplicantErrorMessage, RELATIONSHIP_ERROR_MESSAGE);
			if (isEasternExpansionState(stateCode)) {
				errorMessagesMap.put(maritalStatusDropdownErrorMessage, MARITAL_STATUS_DROPDOWN_ERROR_MESSAGE);
			} else {
				errorMessagesMap.put(maritalStatusRadioButtonsErrorMessage, MARITAL_STATUS_RADIO_BUTTONS_ERROR_MESSAGE);
			}
		}
		errorMessagesMap.put(genderErrorMessage, GENDER_ERROR_MESSAGE);
		if (isEasternExpansionState(stateCode) || stateCode.equals(CA)) {
			String ageFistLicensedErrorText = isDifferentAgeMessageState(stateCode)? ADDITIONAL_DRIVER_AGE_ERROR_MESSAGE : AGE_FIRST_LICENSED_ERROR_MESSAGE;
			errorMessagesMap.put(ageFirstLicensedErrorMessage, ageFistLicensedErrorText);
		}
		errorMessagesMap.put(accidentsOrViolationsErrorMessage, ACCIDENTS_OR_VIOLATIONS_ERROR_MESSAGE);
		return errorMessagesMap;
	}

	private boolean isDifferentAgeMessageState(String stateCode) {
		List<String> aditionalDriverFistLicensedErrorTextStates = new ArrayList<>(Arrays.asList(CA, KY, MA, MD, MN, NC, NM, PA));
		return aditionalDriverFistLicensedErrorTextStates.contains(stateCode);
	}

	private void validateDriversFAQs(String stateCode, boolean isPNI, int age, FarmersSoftAssert fsa) throws Exception {
		int faqCount = 0;
		if (isPNI) {
			if (isEasternExpansionState(stateCode)) {
				validateFAQ(ageFirstLicensedFAQLink, AGE_FIRST_LICENSED_FAQ_TITLE, AGE_FIRST_LICENSED_FAQ_TEXT, fsa);
				faqCount++;
				if (stateCode.equals(LA)) {
					validateFAQ(activeMilitaryDutyStationedInStateFAQLink, ACTIVE_MILITARY_DUTY_FAQ_TITLE, ACTIVE_MILITARY_DUTY_FAQ_TEXT, fsa);
					faqCount++;
				}
				if (stateCode.equals(MA)) {
					validateFAQ(driversLicenseFAQLink, DRIVERS_LICENSE_FAQ_TITLE, DRIVERS_LICENSE_FAQ_TEXT, fsa);
					faqCount++;
				}
			} else {
				validateFAQNoTitle(licenseIssuedByUSStateFAQLink, LICENSED_BY_US_STATE_FAQ_TEXT);
				faqCount++;
				if (stateCode.equals(CA)) {
					validateFAQ(ageFirstLicensedFAQLink, AGE_FIRST_LICENSED_FAQ_TITLE, AGE_FIRST_LICENSED_FAQ_TEXT_CA, fsa);
					faqCount++;
				}
				validateFAQNoTitle(maritalStatusFAQLink, MARITAL_STATUS_FAQ_TEXT);
				faqCount++;
			}
			if (isFinancialFilingState(stateCode)) {
				String ffrFAQText = isShortFRTextState(stateCode)? FINANCIAL_RESPONSIBILITY_FAQ_TEXT : FINANCIAL_RESPONSIBILITY_EXPANDED_FAQ_TEXT;
				validateFAQ(financialResponsibilityFAQLink, FINANCIAL_RESPONSIBILITY_FAQ_TITLE, ffrFAQText, fsa);
				faqCount++;
			}
			if (isPersonalInjuryLossState(stateCode)) {
				validateFAQNoTitle(personalInjuryFAQLink, PERSONAL_INJURY_FAQ_TEXT);
				faqCount++;
			}
			if (isSafetyCourseState(stateCode) || (isSafetyCourseStateForOlderDrivers(stateCode) && age >= MIN_OLD_AGE)) {
				validateFAQ(safetyCourseFAQLink, SAFETY_COURSE_FAQ_TITLE, SAFETY_COURSE_FAQ_TEXT, fsa);
				faqCount++;
			}
			if (isCommuterState(stateCode)) {
				validateFAQNoTitle(commutersFAQLink, COMMUTER_FAQ_TEXT);
				faqCount++;
			}
			if (isPrincipalPIPState(stateCode)) {
				validateFAQ(principalPIPFAQLink, PRINCIPAL_PIP_FAQ_TITLE, PRINCIPAL_PIP_FAQ_TEXT, fsa);
				faqCount++;
			}
			if (isCurrentInsuredStatusState(stateCode)) {
				clickRadioButton(currentlyInsuredRadioButton);
				String currentlyInsuredFAQText = stateCode.equals(MN)? CURRENT_INSURER_MN_FAQ_TEXT: CURRENT_INSURER_FAQ_TEXT;
				validateFAQ(currentlyInsuredFAQLink, CURRENT_INSURER_FAQ_TITLE, currentlyInsuredFAQText, fsa);
				verifyAllAvailableValuesForMapOfDropdowns(getMapWithDriversPageDropdownsAndExpectedValues(stateCode), policyExpirationDateEntryField, fsa);
				clickRadioButton(insuranceExpiredRadioButton);
				String priorInsuredFAQText = isPriorInsuredAndDeployedState(stateCode)? PRIOR_INSURER_AND_DEPLOYED_FAQ_TEXT: PRIOR_INSURER_FAQ_TEXT;
				if (stateCode.equals(MN) ) {
					priorInsuredFAQText = PRIOR_INSURER_MN_FAQ_TEXT;
				}
				validateFAQ(priorInsuranceFAQLink, PRIOR_INSURER_FAQ_TITLE, priorInsuredFAQText, fsa);
				faqCount++;
				validateFAQ(continuousCoverageLengthFAQLink, COVERAGE_LENGTH_FAQ_TITLE, COVERAGE_LENGTH_FAQ_TEXT, fsa);
				faqCount++;
				String bodilyInjuriesHelpText = isFlexState(stateCode) || stateCode.equals(VA)? BODILY_INJURY_LIMITS_INCREASE_FAQ_TEXT : BODILY_INJURY_LIMITS_FAQ_TEXT + BODILY_INJURY_LIMITS_DECLARATION_FAQ_TEXT;
				validateFAQ(bodilyInjuryLimitsFAQLink, BODILY_INJURY_LIMITS_FAQ_TITLE, bodilyInjuriesHelpText, fsa);
				faqCount++;
				String separator = isSafariBrowser()? EMPTY_STRING : SPACE;
				validateFAQ(policyExpirationDateFAQLink, POLICY_EXPIRATION_DATE_FAQ_TITLE, WHEN_DOES_YOUR_POLICY_EXPIRE + separator + POLICY_EXPIRATION_DATE_TEXT, fsa);
				faqCount++;
			}
		} else {
			if (isEasternExpansionState(stateCode)) {
				validateFAQ(ageAdditionalDriverFirstLicensedFAQLink, AGE_FIRST_LICENSED_FAQ_TITLE, AGE_ADDITIONAL_FIRST_LICENSED_FAQ_TEXT, fsa);
				faqCount++;
			} else {
				validateFAQNoTitle(licenseIssuedByUSStateFAQLink, LICENSED_BY_US_STATE_FAQ_TEXT);
				faqCount++;
				if (stateCode.equals(CA)) {
					validateFAQ(ageAdditionalDriverFirstLicensedFAQLink, AGE_FIRST_LICENSED_FAQ_TITLE, AGE_FIRST_LICENSED_FAQ_TEXT_CA, fsa);
					faqCount++;
				}
				validateFAQNoTitle(additionalDriverMaritalStatusFAQLink, MARITAL_STATUS_FAQ_TEXT);
				faqCount++;
			}
			if (isFinancialFilingAdditionalDriverState(stateCode)) {
				String ffrFAQText = isShortFRTextState(stateCode)? FINANCIAL_RESPONSIBILITY_FAQ_TEXT : FINANCIAL_RESPONSIBILITY_EXPANDED_FAQ_TEXT;
				validateFAQ(financialResponsibilityFAQLink, FINANCIAL_RESPONSIBILITY_FAQ_TITLE, ffrFAQText, fsa);
				faqCount++;
			}
			if (isPersonalInjuryLossState(stateCode)) {
				validateFAQNoTitle(personalInjuryFAQLink, PERSONAL_INJURY_FAQ_TEXT);
				faqCount++;
			}
		}
		if (isElementPresentByClass(faqDialogCloseButton)) {
			clickElement(faqDialogCloseButton);
		}
		List<WebElement> faqsInView = driver().findElements(By.xpath("//*[contains(@class, 'info-icon') and not(contains(@aria-label, 'Potential Savings'))]"));
		String driver = isPNI? "PNI ": "additional driver";
		fsa.assertEquals(faqsInView.size(), faqCount, "FAQs for " + driver);
	}

	private LinkedHashMap<WebElement, List<String>> getMapWithDriversPageDropdownsAndExpectedValues(String applicantStateCode) {
		LinkedHashMap<WebElement, List<String>> dropdownsAndAvaliableValues = new LinkedHashMap<>();
		dropdownsAndAvaliableValues.put(continuousCoverageLengthDropDown, new ArrayList<>(Arrays.asList(LT_6MONTHS, SIX_TO_ELEVEN_MONTHS, TWELVE_TO_TWENTYTHREE_MONTHS, TWENTYFOUR_TO_THIRTYFIVE_MONTHS, THIRTYSIX_TO_FORTYSEVEN_MONTHS, FORTYEIGHT_TO_FIFTYNINE_MONTHS, SIXTYPLUS_MONTHS)));
		dropdownsAndAvaliableValues.put(bodilyInjuryLimitsDropDown, bodiliInjuryLimitsListOfValues(applicantStateCode));
		return dropdownsAndAvaliableValues;
	}

	private List<String> bodiliInjuryLimitsListOfValues(String stateCode) {
		switch(stateCode) {
		case AR : case GA : case NE : case TN :
			return new ArrayList<>(Arrays.asList(NO_BI_PIP_PD_ONLY, _10K_AND_20K, _15K_AND_30K, _20K_AND_40K, _25K_AND_50K, _25K_AND_65K, _30K_AND_60K, _30K_AND_65K, _35K_AND_70K, _35K_AND_80K,
					_50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _300K_AND_300K, _500K_AND_500K, _500K_AND_1M, _1M_AND_1M,
					_35K, _45K, _50K, _60K, _75K, _85K, _100K, _200K, _300K, _500K, _1M));
		case FL :
			return new ArrayList<>(Arrays.asList(PIP_PD_ONLY, _10K_AND_20K, _15K_AND_30K, _20K_AND_40K, _25K_AND_50K, _30K_AND_60K, _35K_AND_70K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _300K_AND_300K));
		case AZ :
			return new ArrayList<>(Arrays.asList(_15K_AND_30K, _20K_AND_40K, _25K_AND_50K, _30K_AND_60K, _35K_AND_70K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K, _1M_AND_1M,
					_50K, _75K, _100K, _200K, _300K, _500K, _1M));
		case PA :
			return new ArrayList<>(Arrays.asList(_15K_AND_30K, _20K_AND_40K, _25K_AND_50K, _25K_AND_65K, _30K_AND_60K, _30K_AND_65K, _35K_AND_70K, _35K_AND_80K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _150K_AND_300K, _250K_AND_500K, _300K_AND_300K, _500K_AND_500K, _500K_AND_1M, _1M_AND_1M,
					_35K, _45K, _50K, _60K, _75K, _85K, _100K, _200K, _300K, _500K, _1M));
		case IA :
			return new ArrayList<>(Arrays.asList(_20K_AND_40K, _25K_AND_50K, _30K_AND_60K, _35K_AND_70K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K,
					_500K));
		case MA :
			return new ArrayList<>(Arrays.asList(_20K_AND_40K, _25K_AND_50K, _30K_AND_60K, _35K_AND_80K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K, _500K_AND_1M,
					_45K, _75K, _100K, _200K, _500K));
		case UT :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _25K_AND_65K, _30K_AND_60K, _30K_AND_65K, _35K_AND_70K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K,
					_500K));
		case AL : case CO : case ND : case SD : case WY :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _25K_AND_65K, _30K_AND_60K, _30K_AND_65K, _35K_AND_70K, _35K_AND_80K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _150K_AND_300K, _250K_AND_500K, _300K_AND_300K, _500K_AND_500K, _500K_AND_1M, _1M_AND_1M,
					_35K, _45K, _50K, _60K, _75K, _85K, _100K, _200K, _300K, _500K, _1M));
		case WI :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _30K_AND_60K, _35K_AND_70K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _150K_AND_300K, _250K_AND_500K, _500K_AND_500K,
					_500K));
		case ID : case IN : case MT : case NM : case NV : case OH : case WA :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _30K_AND_60K, _35K_AND_70K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K,
					_500K));
		case KY :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _30K_AND_60K, _35K_AND_70K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K, _500K_AND_1M,
					_60K, _75K, _200K, _500K, _1M));
		case LA :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _30K_AND_60K, _35K_AND_70K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K, _500K_AND_1M,
					_75K, _100K, _200K, _500K));
		case MS :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _30K_AND_60K, _35K_AND_70K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K, _500K_AND_1M,
					_75K, _200K, _500K, _1M));
		case IL : case KS : case MO : case OK : case OR :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _30K_AND_60K, _35K_AND_70K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K, _500K_AND_1M,
					_500K, _1M));
		case NY :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K,
					_75K, _100K, _200K, _300K, _500K));
		case CT :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K,
					_50K, _75K, _100K, _200K, _300K, _500K));
		case NJ :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K, _500K_AND_1M));
		case VA :
			return new ArrayList<>(Arrays.asList(_30K_AND_60K, _30K_AND_65K, _35K_AND_70K, _35K_AND_80K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _150K_AND_300K, _250K_AND_500K, _300K_AND_300K, _500K_AND_500K, _500K_AND_1M, _1M_AND_1M,
					_35K, _45K, _50K, _60K, _75K, _85K, _100K, _200K, _300K, _500K, _1M));
		case MN :
			return new ArrayList<>(Arrays.asList(_30K_AND_60K, _35K_AND_70K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K,
					_500K));
		case NC :
			return new ArrayList<>(Arrays.asList(_30K_AND_60K, _35K_AND_70K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K, _500K_AND_1M, _1M_AND_1M,
					_85K, _100K, _200K, _300K, _500K, _1M));
		case TX :
			return new ArrayList<>(Arrays.asList(_30K_AND_60K, _35K_AND_70K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _300K_AND_300K, _500K_AND_500K, _500K_AND_1M,
					_50K, _75K, _200K, _300K, _500K));
		case MD :
			return new ArrayList<>(Arrays.asList(_30K_AND_60K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case MI :
			return new ArrayList<>(Arrays.asList(_50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _300K_AND_300K, _500K_AND_500K, _500K_AND_1M, _1M_AND_1M,
					_75K, _100K, _200K, _300K, _500K, _1M));
		default :
			return new ArrayList<>(Arrays.asList("bodiliInjuryLimitsListOfValues content not defined for: " + stateCode));
		}
	}

	private List<WebElement> getListWithPageElements() {
		Log.info("Getting List with Drivers Page elements");
		List<WebElement> dpElements = new ArrayList<>();
		dpElements.add(backButton);
		return dpElements;
	}

	private Map<WebElement, String> getMapWithExpectedGTMTags() {
		Log.info("Getting Map with expected Drivers Page elements GTM values");
		Map<WebElement,String> expectedElementGTMMap = new HashMap<>();
		expectedElementGTMMap.put(backButton, "FFQ_Auto_Driversummary_back_button");
		return expectedElementGTMMap;
	}

	// Business rules
	private boolean isCivilUnionState(String stateCode) {
		List<String> civilUnionStates = new ArrayList<>(Arrays.asList(CO, IL));
		return civilUnionStates.contains(stateCode);
	}

	private boolean isCivilUnionPartnerState(String stateCode) {
		List<String> civilUnionPartnerStates = new ArrayList<>(Arrays.asList(NJ));
		return civilUnionPartnerStates.contains(stateCode);
	}

	private boolean isCommuterState(String stateCode) {
		return Arrays.asList(MD, NJ).contains(stateCode);
	}

	private boolean isCurrentInsuredStatusState(String stateCode) {
		List<String> noCurrentInsuredQuestionStates = new ArrayList<>(Arrays.asList(CA));
		return !noCurrentInsuredQuestionStates.contains(stateCode);
	}

	private boolean isFinancialFilingState(String stateCode) {
		List<String> noFFQuestionStates = new ArrayList<>(Arrays.asList(CA, GA, KY, MA, MD, MN, NM, NC, NJ, NY, PA));
		return !noFFQuestionStates.contains(stateCode);
	}

	private boolean isFinancialFilingAdditionalDriverState(String stateCode) {
		List<String> noFFQuestionAdditionalDriverStates = new ArrayList<>(Arrays.asList(LA, MS));
		return !noFFQuestionAdditionalDriverStates.contains(stateCode) && isFinancialFilingState(stateCode);
	}

	private boolean isPersonalInjuryLossState(String stateCode) {
		List<String> pilQuestionStates = new ArrayList<>(Arrays.asList(FL));
		return pilQuestionStates.contains(stateCode);
	}

	private boolean isRelationshipToApplicantQuestionState(String stateCode) {
		List<String> relationshipToApplicantQuestionStates = new ArrayList<>(Arrays.asList(CA, CT, MI, MT, NJ, NY));
		return relationshipToApplicantQuestionStates.contains(stateCode) || (isFlexState(stateCode) && !stateCode.equals(AL));
	}

	private boolean isReportInjuriesState(String stateCode) {
		List<String> reportInjuriesStates = new ArrayList<>(Arrays.asList(CA));
		return reportInjuriesStates.contains(stateCode);
	}

	private boolean isPrincipalPIPState(String stateCode) {
		List<String> pipQuestionStates = new ArrayList<>(Arrays.asList(NJ));
		return pipQuestionStates.contains(stateCode);
	}

	private boolean isPriorInsuredAndDeployedState(String stateCode) {
		List<String> priorInsuredAndDeployedStates = new ArrayList<>(Arrays.asList(AL, AR, CT, ID, IN, GA, KS, CO, MD, MI, MO, MT, ND, NE, NJ, NM, NV, NY,
				OR, SD, TN, VA, WI, WY));
		return priorInsuredAndDeployedStates.contains(stateCode);
	}

	private boolean isSafetyCourseState(String stateCode) {
		List<String> safetyCourseQuestionStates = new ArrayList<>(Arrays.asList(GA, IN, KS, MT, ND, NJ, NY, OK));
		return safetyCourseQuestionStates.contains(stateCode);
	}

	private boolean isSafetyCourseStateForOlderDrivers(String stateCode) {
		List<String> noSafetyCourseStateForOlderDriversStates = new ArrayList<>(Arrays.asList(LA, MA, MO, NC, NE, SD, TX, WI));
		return !noSafetyCourseStateForOlderDriversStates.contains(stateCode);
	}

	private boolean isShortFRTextState(String stateCode) {
		List<String> shortFRTextStates = new ArrayList<>(Arrays.asList(CT, GA, MD, MN, NJ, NM, NY, OK, PA));
		return shortFRTextStates.contains(stateCode);
	}

	private boolean isSpouseOccupationQuestionState(String stateCode) {
		List<String> noSpouseOccupationQuestionStates = new ArrayList<>(Arrays.asList(AR, CA, GA, IN, MD, NJ, TX, WY));
		return !(noSpouseOccupationQuestionStates.contains(stateCode) || isEasternExpansionState(stateCode));
	}

	// Other business rules
	private boolean isDifferentMailingAddressState(String stateCode) {
		List<String> mailingAddressDifferentCheckboxStates = new ArrayList<>(Arrays.asList(IN, KS, NV, OR, TN));
		return mailingAddressDifferentCheckboxStates.contains(stateCode);
	}

	private boolean isVehicleAssignmentState(String stateCode) {
		List<String> vehicleAssignmentStates = new ArrayList<>(Arrays.asList(CA, NY, VA));
		return vehicleAssignmentStates.contains(stateCode);
	}

	// End of business Rules

	private void setCurrentlyInsured() {
		clickRadioButton(currentlyInsuredRadioButton);
	}

	private void selectMatOption (@Nullable String value) throws Exception {
		if (value == null) {
			driver().findElement(By.xpath(SELECT_OPTION)).click();
		} else {
			driver().findElement(By.xpath(SELECT_OPTION + "[contains(.,'" + value + "')]")).click();
		}
	}

	private void selectHowLongHadInsurance (@Nullable String value) throws Exception {
		scrollToElement(currentAutoInsuranceCompanyEntryField);
		waitAndClickElement(continuousCoverageLengthDropDown);
		selectMatOption(value);
	}

	private void setSixMonthsCoverage(boolean yesCoverage) {
		if (yesCoverage) {
			clickRadioButton(yesSixMonthsRadioButton);
		} else {
			clickRadioButton(noSixMonthsRadioButton);
		}
	}

	private void selectBodilyInjuryLimits (@Nullable String value) throws Exception {
		waitElementBeVisible(bodilyInjuryLimitsDropDown);
		scrollOffsetClickOnElement(bodilyInjuryLimitsDropDown);
		selectMatOption(value);
	}

	private void clickRadioButton(WebElement radioButton) {
		//click button and retry twice if not selected
		scrollToElement(radioButton);
		if (radioButton.isEnabled()) {
			for (int retry = 0; retry<3 && !radioButton.isSelected(); retry++) {
				scrollAndClickOnElement(radioButton);
			}
		} else {
			Log.warn(radioButton + " disabled.");
		}
	}

	private String adjustIncidentDescription(String originalDescription) {
		switch (originalDescription) {
		case "Assault with motor vehicle" :
			return "Aggressive Driving";
		case "Drinking in vehicle" :
			return "DUI/DWI";
		case "Violation of license restriction" :
			return "Driving during Revocation or Suspension of License or Registration";
		case "Driving in wrong lane or side" :
			return "Highway Racing";
		case "Failing to control car" :
			return "Failure to Display License or Registration";
		case "Improper operation of vehicle" :
			return "Following too closely";
		case "Being inattentive while driving" :
			return "Hit-and-run";
		case "Changing lane in an unsafe manner" :
			return "Illegal Passing";
		case "Driving recklessly" :
			return "Improper Lights/Equipment";
		case "Driving while on medication" :
			return "Speeding";
		case "Driving under the influence" :
			return "Other Major Conviction";
		case "Driving with a suspended license" :
			return "Other Minor Conviction";
		case "Failing to stop after accident" :
			return "Passing a stopped school bus";
		case "Failing to yield right of way" :
			return "Reckless Driving";
		case "Accident was not driver" :
		case "Hit other car or object" :
			return "At-fault accident resulting in Bodily Injury";
		case "Accident caused damage less than $800" :
		case "Car rolled over" :
		default :
			return "At-fault accident resulting in Property Damage";
		}
	}

	private void selectDriverToInsure(SqlApplicant applicant, boolean retrySelectDriverToInsure) throws Exception {
		if (!isElementPresentByClass(addDriverDetailsDialogHeader)) {
			if (applicant.getLastName().equals("FFQTEST")) {
				applicant.setLastName(PRODUCTION_APPLICANT_LAST_NAME);
			}
			WebElement driverToInsure = driver().findElement(By.xpath(DRIVER_TO_INSURE_XPATH_BEGIN + applicant.getFirstName() + SPACE + applicant.getLastName().substring(0, 1) + DRIVER_TO_INSURE_XPATH_END));
			clickElement(driverToInsure);
		} else if (retrySelectDriverToInsure) {
			selectDriverToInsure(applicant, false);
		}
	}

	private boolean isAdditionalDriverFullTimeStudentState(String stateCode) {
		List<String> aditionalDriverFullTimeStudentStates = new ArrayList<>(Arrays.asList(CA, MI));
		return aditionalDriverFullTimeStudentStates.contains(stateCode);
	}

	private int getDriverCount(SqlApplicant applicant) {
		int additionalDrivers = applicant.getAdditionalDrivers().size() > MAX_NUMBER_OF_ADDITIONALDRIVERS ? MAX_NUMBER_OF_ADDITIONALDRIVERS : applicant.getAdditionalDrivers().size();
		int totalDriversForPolicy = 1;
		for (int driverIndex = 0; driverIndex <= additionalDrivers-1; driverIndex++) {
			if (!applicant.getAdditionalDrivers().get(driverIndex).getLicenseToDriveInUSA().equals(NO)) {
				totalDriversForPolicy++;
			}
		}
		return totalDriversForPolicy;
	}

	private void validateVehicleAssignmentPage(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		String applicantStateCode = applicant.getStateCode();
		List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC34700", "TC34701", "TC34702", "TC34705", "TC34706", "TC34766", "TC34767", "TC34775",
				"TC34776", "TC34900", "TC34901", "TC34902", "TC35125", "TC35126", "TC35127"));
		writeTestcaseState("DriversPage.validateVehicleAssignmentPage", applicantStateCode, rallyTestcasesCovered, FAILED);
		fsa.assertEquals(getTextFromElement(driversPageHeader), VEHICLE_ASSIGNMENT_HEADER, "Vehicle assignment page header");
		String descriptionText = applicantStateCode.equals(NY) ? VEHICLE_ASSIGNMENT_DESCRIPTION_NY : VEHICLE_ASSIGNMENT_DESCRIPTION;
		fsa.assertEquals(getTextFromElement(vehicleToDriversAssignmentDescription), descriptionText, "vehicleToDriversAssignmentDescription");
		List<WebElement> listOfDriversAndVehicles = driver().findElements(By.xpath("//div[@class='ffq-lib__driver_assignment-card ng-star-inserted']"));
		int driverCount = applicant.getAdditionalDrivers().size() > MAX_NUMBER_OF_ADDITIONALDRIVERS ? MAX_NUMBER_OF_ADDITIONALDRIVERS + 1 :
			applicant.getAdditionalDrivers().size() + 1;
		if (!listOfDriversAndVehicles.isEmpty()) {
			int driversFound = listOfDriversAndVehicles.size();
			fsa.assertEquals(driverCount, driversFound, "Number of listed drivers");
			for (int driverNum=0; driverNum<driverCount; driverNum++) {
				scrollElementToMiddle(listOfDriversAndVehicles.get(driverNum));
				String driverVehicleList = getTextFromElement(listOfDriversAndVehicles.get(driverNum));
				String driverExpectedEntry = driverNum == 0? applicant.getFirstName() + SPACE + applicant.getLastName():
					applicant.getAdditionalDrivers().get(driverNum-1).getFirstName() + SPACE + applicant.getAdditionalDrivers().get(driverNum-1).getLastName();
				fsa.assertTrue(driverVehicleList.contains(driverExpectedEntry), "[" + driverExpectedEntry + "] found in [" + driverVehicleList + "]");
				for (SqlVehicle vehicle : applicant.getVehicles()) {
					String vehicleExpectedEntry = vehicle.getVehicleYear() + SPACE + vehicle.getVehicleMake() + SPACE + vehicle.getVehicleModel();
					if (!vehicle.getVehicleMake().contains("QUATTRO")) {
						fsa.assertTrue(driverVehicleList.contains(vehicleExpectedEntry), "[" + vehicleExpectedEntry + "] found in [" + driverVehicleList + "]");
					}
				}
			}
		}
		clickElement(vehicleToDriversAssignmentNextButton);
		String errorMessage = applicantStateCode.equals(VA)? VEHICLE_ASSIGNMENT_ERROR_MESSAGE : VEHICLE_ASSIGNMENT_ERROR_MESSAGE_NY;
		if (driverCount == 1 && errorMessage.equals(VEHICLE_ASSIGNMENT_ERROR_MESSAGE_NY) ) {
			errorMessage = applicant.getFirstName() + SPACE + applicant.getLastName() + INDIVIDUAL_VEHICLE_ASSIGNMENT_ERROR_MESSAGE;
		}
		fsa.assertEquals(getTextFromElement(vehicleToDriversAssignmentErrorMessage), errorMessage, "vehicleToDriversAssignmentErrorMessage error");
		writeTestcaseState("DriversPage.validateVehicleAssignmentPage", applicantStateCode, rallyTestcasesCovered, PASSED);
	}

	private void waitForPage() {
		waitForSpinnerToBeGone();
		waitElementBeVisible(driversPageHeader);
	}

	private void enterMaritalStatus(String maritalStatus){
		waitElementBeVisible(marriedRadioButton);
		if (maritalStatus.equals(MARRIED)) {
			clickRadioButton(marriedRadioButton);
		} else if (notMarriedRadioButton.isEnabled()){
			clickRadioButton(notMarriedRadioButton);
		}
	}

	private void enterAdditionalDriverMaritalStatus(String maritalStatus){
		if (maritalStatus.equals(MARRIED)) {
			clickRadioButton(additionalDriverMarriedRadioButton);
		} else {
			clickRadioButton(additionalDriverNotMarriedRadioButton);
		}
	}

	private void validateListOfMaritalStatus(String stateCode, FarmersSoftAssert fsa) throws Exception {
		if (isEasternExpansionState(stateCode)) {
			List<String> statusesListed = getDropdownOptions(maritalStatusDropdown, false);
			verifyAllStatuses(statusesListed, stateCode, fsa);
			clickElement(addDriverDetailsDialogHeader);
		}
	}

	private void validateCloseConfirmationDialog(FarmersSoftAssert fsa) {
		clickElement(closeAddDriverDetailsDialog);
		waitElementBeVisible(closeDetailsConfirmationDialogContent);
		fsa.assertEquals(getTextFromElement(closeDetailsConfirmationDialogContent), CANCEL_DIALOG_CONTENT, "closeDetailsConfirmationDialogContent");
		fsa.assertEquals(closeConfirmationDialogContinueButton.isDisplayed(), true, "closeConfirmationDialogContinueButton");
		fsa.assertEquals(closeConfirmationDialogCloseButton.isDisplayed(), true, "closeConfirmationDialogCloseButton");
		clickElement(closeConfirmationDialogContinueButton);
		fsa.assertEquals(addDriverDetailsDialogHeader.isDisplayed(), true, "addDriverDetailsDialogHeader");
		clickElement(closeAddDriverDetailsDialog);
		waitElementBeVisible(closeDetailsConfirmationDialogContent);
		clickElement(closeConfirmationDialogCloseButton);
		fsa.assertEquals(driversPageHeader.isEnabled(), true, "driversPageHeader");
	}

	private void verifyAllStatuses(List<String> statusesListed, String stateCode, FarmersSoftAssert fsa) {
		int maritalStatusCount = 4;
		fsa.assertEquals(statusesListed.contains(SINGLE), true, SINGLE + SPACE + MARITAL_STATUS);
		fsa.assertEquals(statusesListed.contains(MARRIED), true, MARRIED + SPACE + MARITAL_STATUS);
		fsa.assertEquals(statusesListed.contains(SEPARATED), true, SEPARATED + SPACE + MARITAL_STATUS);
		fsa.assertEquals(statusesListed.contains(WIDOWED), true, WIDOWED + SPACE + MARITAL_STATUS);
		if (isCivilUnionState(stateCode)) {
			fsa.assertEquals(statusesListed.contains(CIVIL_UNION), true, CIVIL_UNION + SPACE + MARITAL_STATUS);
			maritalStatusCount++;
		}
		if (isCivilUnionPartnerState(stateCode)) {
			fsa.assertEquals(statusesListed.contains(CIVIL_UNION_PARTNER), true, CIVIL_UNION_PARTNER + SPACE + MARITAL_STATUS);
			maritalStatusCount++;
		}
		fsa.assertEquals(statusesListed.size(), maritalStatusCount, MARITAL_STATUS + SPACE + statusesListed);
	}

	private void enterOccupation(String occupation) {
		if (occupationEntryField.isEnabled()) {
			enterValueInField(occupation, occupationEntryField, "Occupation");
			if (isElementPresentByXPath(OCCUPATION_XPATH)) {
				occupationOption.click();
			}
		}
	}

	private void enterCurrentlyInsured(SqlApplicant applicant) throws Exception {
		String applicantStateCode = applicant.getStateCode();
		if (isCurrentInsuredStatusState(applicantStateCode)) {
			switch (applicant.getCurrentlyInsuredStatus()) {
			case "Insured":
				clickRadioButton(currentlyInsuredRadioButton);
				waitElementBeVisibleClickable(currentAutoInsuranceCompanyEntryField);
				enterInsuranceCompanyInfo(currentAutoInsuranceCompanyEntryField, applicant.getCurrentInsuranceCompany().toUpperCase(Locale.US));
				Assert.assertTrue(selectValueInDropdown(applicant.getContinuosInsurancePeriod(), continuousCoverageLengthDropDown, addDriverDetailsDialogHeader));
				if (applicant.getContinuosInsurancePeriod().equals(LT_6MONTHS) ||
						applicant.getContinuosInsurancePeriod().equals(SIX_TO_ELEVEN_MONTHS)) {
					clickRadioButton(had6MonthCoverageInPastRadioButton);
				}
				if (!selectValueInDropdown(applicant.getCurrentBodilyInjuryLimit(), bodilyInjuryLimitsDropDown, policyExpirationDateEntryField)) {
					List<String> listOfAvailableValues = getDropdownOptions(bodilyInjuryLimitsDropDown, false);
					Log.warn("Available values are: " + listOfAvailableValues);
					selectFromDropDownByPosition(bodilyInjuryLimitsDropDown, SECOND_AVAILABLE_OPTION, addDriverDetailsDialogHeader);
				}
				scrollElementToMiddle(policyExpirationDateEntryField);
				enterValueInField(applicant.getCurrentInsuranceExpirationDate(), policyExpirationDateEntryField, "Current insurance expiration date");
				break;
			case EXPIRED:
				clickRadioButton(insuranceExpiredRadioButton);
				waitElementBeVisibleClickable(priorAutoInsuranceCompanyEntryField);
				enterInsuranceCompanyInfo(priorAutoInsuranceCompanyEntryField, applicant.getCurrentInsuranceCompany().toUpperCase(Locale.US));
				if (!selectValueInDropdown(applicant.getContinuosInsurancePeriod(), continuousCoverageLengthDropDown, addDriverDetailsDialogHeader)) {
					selectFromDropDownByPosition(continuousCoverageLengthDropDown, LAST_AVAILABLE_OPTION, bodilyInjuryLimitsDropDown);
				}
				if (!selectValueInDropdown(applicant.getCurrentBodilyInjuryLimit(), bodilyInjuryLimitsDropDown, policyExpirationDateEntryField)) {
					selectFromDropDownByPosition(bodilyInjuryLimitsDropDown, SECOND_AVAILABLE_OPTION, addDriverDetailsDialogHeader);
				}
				enterValueInField(applicant.getCurrentInsuranceExpirationDate(), policyExpirationDateEntryField, "Current insurance expiration date");
				if (applicant.getContinuosInsurancePeriod().equals(LT_6MONTHS)) {
					if (!applicantStateCode.equals(NY)) {
						clickRadioButton(had6MonthCoverageInPastRadioButton);
					}
					if (applicantStateCode.equals(FL)) {
						clickRadioButton(deploymentReasonForNoInsuranceRadioButton);
					}
				}
				break;
			case "Never had insurance":
				clickRadioButton(neverInsuredRadioButton);
				if (!applicant.getStateCode().equals(WA)) {
					//overloading this field to contain the reason why
					enterNotInsuredReason(applicant.getCurrentInsuranceCompany());
				}
				break;
			default:
				throw new IllegalArgumentException("Invalid insurance status: " + applicant.getCurrentlyInsuredStatus());
			}

		}
	}

	private void enterInsuranceCompanyInfo(WebElement insuranceCompanyEntryField, String insuranceCompany) {
		sendKeysToElement(insuranceCompanyEntryField, insuranceCompany);
		insuranceCompanyOption.click();
	}

	private void enterNotInsuredReason(String reasonForNoInsurance) {
		switch (reasonForNoInsurance) {
		case DEPLOYED :
			clickRadioButton(deployedRadioButton);
			break;
		case NOT_REQUIRED :
			clickRadioButton(notRequiredRadioButton);
			break;
		case "No vehicle" :
			clickRadioButton(notOwnAVehicleRadioButton);
			break;
		case OTHER :
			clickRadioButton(otherRadioButton);
			break;
		default :
			Log.error("Unknown no prior insurance reason: " + reasonForNoInsurance);
			break;
		}
	}

}
