package com.farmers.ffq.ace.mobilehome;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.invisibilityOfElementLocated;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;

public class AceMobileHomeTellUsMorePage extends AceHRCBasePage {

	@FindBy (xpath = "//div[@class='mobile-home-details-container']//h1")
	private WebElement tellUsMorePageTitle;

	@FindBy (xpath = "//*[contains(@class, 'address-street')]")
	private WebElement mobileHomeAddressElement;

	@FindBy (xpath = "//*[contains(@class, 'address-city-state')]")
	private WebElement mobileHomeCityStateZipElement;

	@FindBy(xpath = "//input[@role='combobox']")
	private WebElement yearBuiltInputField;

	@FindBy (xpath = "//*[contains(@class, 'size-label')]")
	private WebElement sizeOfHomeLabel;

	@FindBy (xpath = "//mat-icon[contains(@aria-label, 'Home size')]")
	private WebElement sizeOfHomeHelpIcon;

	private static final String WIDTH_BUTTON_LABEL_XPATH = "//mat-button-toggle-group//span[contains(@class, 'label-content')]";
	@FindBy (xpath = WIDTH_BUTTON_LABEL_XPATH)
	private List<WebElement> listOfLabelsFromWidthButtons;

	private static final String WIDTH_BUTTON_XPATH = WIDTH_BUTTON_LABEL_XPATH + "[normalize-space(text())='%s']/parent::button";

	@FindBy (xpath = "//*[contains(@class, 'replacement-cost-label')]")
	private WebElement replacementCostLabel;

	@FindBy (xpath = "//mat-icon[contains(@aria-label, 'Replacement cost')]")
	private WebElement replacementCostHelpIcon;

	@FindBy (xpath = "//input[@formcontrolname='replacementCost']")
	private WebElement replacementCostInputField;

	@FindBy (xpath = "//h2[contains(@class, 'mb-3')]")
	private WebElement primaryHeatSourceLabel;

	@FindBy (xpath = "//mat-select[@formcontrolname='primaryHeatSource']")
	private WebElement primaryHeatSourceDropdown;

	@FindBy (id = "secondary-heat-source-input")
	private WebElement secondaryHeatSourceCheckbox;

	@FindBy (xpath = "//label[@for='secondary-heat-source-input']")
	private WebElement secondaryHeatSourceLabel;

	@FindBy (xpath = "//div[contains(@class, 'secondary-heat-source-group')]/p")
	private WebElement secondaryHeatSourceSubtextElement;

	public AceMobileHomeTellUsMorePage() throws Exception {
		super();
	}

	public boolean isOnTellUsMorePage() {
		return isElementVisible(yearBuiltInputField, 5);
	}

	public void fillOutPageAndContinue(ApplicantAceHome mobilehomeApplicant) throws Exception {
		enterValueInField(Integer.toString(mobilehomeApplicant.getYearBuilt()), yearBuiltInputField, "Enter Year built:");
		WebElement homeWidthButton = driver().findElement(By.xpath(String.format(WIDTH_BUTTON_XPATH, mobilehomeApplicant.getHomeWidth())));
		scrollAndClickOnElement(homeWidthButton);
		enterValueInField(mobilehomeApplicant.getReplacementCost(), replacementCostInputField, "Enter home's value:");
		selectValueInDropDown(primaryHeatSourceDropdown, mobilehomeApplicant.getPrimaryHeatingSource());
		setCheckboxTo(secondaryHeatSourceCheckbox, mobilehomeApplicant.getSecondaryHeatingSource().equalsIgnoreCase(TRUE));
		scrollAndClickOnElement(buttonContinue);
		waitForSpinnerToBeGone();
	}

	public void verifyPageContent(FarmersSoftAssert fsa, ApplicantAceHome mobilehomeApplicant) throws Exception {
		String testCategory = mobilehomeApplicant.getTestCategory();
		boolean isForemostQuote = testCategory.equals(FOREMOST);
		boolean isForemostAffiliateQuote = testCategory.equals(USAA);
		boolean isAWSQuote = testCategory.equals(AWS_SCENARIOS);
		String activeStep = getActiveStep(testCategory);
		String separator = isSafariBrowser() ? EMPTY_STRING : SPACE;
		String MOBILE_HOME_SIZE_HELP_CONTENT = "Use this table as a guide to confirm your home's dimensions. (These are average dimensions based on current industry data.) " +
				"Width-type" + separator + "Single" + separator + "Double" + separator + "Triple" + separator +
				"Bedrooms" + separator + "1-2" + separator + "2-4" + separator + "3-6" + separator +
				"Bathrooms" + separator + "1-2" + separator + "2+" + separator + "2-4" + separator +
				"Width (feet)" + separator + "14-18" + separator + "24-32" + separator + "40-60+" + separator +
				"Length (feet)" + separator + "40-80" + separator + "40-80" + separator + "40-80" + separator +
				"Square footage" + separator + "500-1,200" + separator + "1,000-2,400" + separator + "2,000-3,500+";
		String MOBILE_HOME_REPLACEMENT_COST_HELP_CONTENT = "Please provide the estimated cost to replace your mobile home with a new, equivalent model. Include structures attached to the home, but don't include your personal belongings. " +
				"Do not use the appraisal value of the home since that reflects the price you can expect to receive if you sell your home—which would include the value of your land.";
		String MOBILE_HOME_REPLACEMENT_COST_ALTERNATE_HELP_CONTENT = "Please provide the estimated cost to replace your mobile home with a new, equivalent model. Include structures attached to the home, but don't include other structures not attached to the home, or your personal belongings. " +
				"Do not use the appraisal value nor the purchase price you can expect to receive if you sell your home—which would include the value of your land and/or the lot location value.";
		List<String> listOfPrimaryHeatSources = List.of("Baseboard (electric or hot water)", "Central hot water", "Furnace (central, forced-air, or wall)", "Heat pump",
				"Space heater (permanent or portable)", "Wood stove (excluding wood/oil stove)", "Other primary heat source type(s)", "No primary heat source");
		if (!isForemostQuote) {
			verifyMobileHomeCommonHeader(fsa, isForemostAffiliateQuote);
		}
		fsa.assertEquals(getTextFromElement(tellUsMorePageTitle), "Tell us more about your home", "Tell us more page - Page title.");
		fsa.assertEquals(getTextFromElement(mobileHomeAddressElement).toUpperCase(), mobilehomeApplicant.getAddress().toUpperCase(), "Tell us more page - Address.");
		fsa.assertEquals(getTextFromElement(mobileHomeCityStateZipElement).toUpperCase(), mobilehomeApplicant.getCity().toUpperCase() + COMMA + SPACE + mobilehomeApplicant.getStateCode() + SPACE + mobilehomeApplicant.getZipCode(), "Tell us more page - City, State and Zip code.");
		fsa.assertEquals(getValueFromWebElement(yearBuiltInputField), EMPTY_STRING, "Tell us more page - Year built field is blank.");
		fsa.assertEquals(getTextFromElement(sizeOfHomeLabel), "What width is your home?", "Tell us more - Home width label");
		validateHelpInfoContent(fsa, sizeOfHomeHelpIcon, "Mobile home size", MOBILE_HOME_SIZE_HELP_CONTENT, false);
		fsa.assertEquals(getTextFromElement(replacementCostLabel), "What is the replacement cost of your home?", "Tell us more - Replacement cost label");
		fsa.assertEquals(getValueFromWebElement(replacementCostInputField), EMPTY_STRING, "Tell us more page - replacement cost field is blank.");
		if (isForemostAffiliateQuote) {
			validateHelpInfoContent(fsa, replacementCostHelpIcon, "Mobile home replacement cost", MOBILE_HOME_REPLACEMENT_COST_ALTERNATE_HELP_CONTENT, true);
		} else {
			validateHelpInfoContent(fsa, replacementCostHelpIcon, "Mobile home replacement cost", MOBILE_HOME_REPLACEMENT_COST_HELP_CONTENT, false);
		}
		fsa.assertEquals(getTextFromElement(primaryHeatSourceDropdown), "Furnace (central, forced-air, or wall)", "Tell us more page - Default Primary Heat source.");
		fsa.assertEquals(getTextFromElement(primaryHeatSourceLabel), "Please select your primary heat source.", "Tell us more - Primary heat source label");
		clickElement(primaryHeatSourceDropdown);
		List<WebElement> listOfDropdownOptionElements = driver().findElements(By.xpath(DROPDOWN_OPTIONS_XPATH));
		List<String> listOfDropdownOptions = listOfDropdownOptionElements.stream().map(this::getTextFromElement).collect(Collectors.toList());
		fsa.assertEquals(getSortedList(listOfDropdownOptions), getSortedList(listOfPrimaryHeatSources), "Tell us more page - Primary heat source dropdown content");
		clickElement(primaryHeatSourceDropdown);
		fsa.assertEquals(getTextFromElement(secondaryHeatSourceLabel), "I have a secondary heat source.", "Tell us more - Secondary heat source label");
		fsa.assertTrue(!secondaryHeatSourceCheckbox.isSelected(), "Tell us more page - Secondary Heat source checkbox is not selected.");
		fsa.assertEquals(getTextFromElement(secondaryHeatSourceSubtextElement), "Fireplace, wood stove, or any other supplemental heating system", "Tell us more - Secondary heat source subtext");
		fsa.assertEquals(getTextFromElement(buttonContinue), "Continue", "Tell us more page - CTA button text label");
		validatePageLinksText(fsa, activeStep);
		if (!isForemostAffiliateQuote) {
			validatePageLinksNavigationTitles(fsa);
		}
		validateAgentSectionContent(fsa, isAWSQuote, testCategory);
	}

	@FindBy (xpath =  "//div[@class='heading-area']//h1")
	private WebElement helpDialogTitle;
	@FindBy (className = "main-content")
	private WebElement helpDialogContent;

	private void validateHelpInfoContent(FarmersSoftAssert fsa, WebElement helpIcon, String helpTitle, String helpContent, boolean failureExpected) {
		scrollAndClickOnElement(helpIcon);
		waitElementBeVisible(helpDialogTitle, 3);
		fsa.assertEquals(getTextFromElement(helpDialogTitle), helpTitle, helpTitle + " - Help title verification");
		if (failureExpected) {
			fsa.assertNotEquals(getTextFromElement(helpDialogContent), helpContent, helpTitle + " - Help content verification - DE326975");
		} else {
			fsa.assertEquals(getTextFromElement(helpDialogContent), helpContent, helpTitle + " - Help content verification");
		}
		waitAndClickElement(closeIconMB);
	}

	public void validatePageErrors(FarmersSoftAssert fsa, ApplicantAceHome mobilehomeApplicant) throws Exception {
		WebElement homeWidthButton = driver().findElement(By.xpath(String.format(WIDTH_BUTTON_XPATH, SINGLE)));
		scrollAndClickOnElement(homeWidthButton);
		clickElement(yearBuiltInputField);
		clickElement(replacementCostInputField);
		scrollAndClickOnElement(buttonContinue);
		List<String> defaultListOfExpectedErrors = List.of("Please enter the year your house was built.", "Replacement cost is required.");
		waitForElements(ERROR_MESSAGE_XPATH);
		List<String> listOfErrorsFoundInPage = getPageErrors();
		fsa.assertEquals(listOfErrorsFoundInPage, defaultListOfExpectedErrors, "Default errors when missing data");
		enterValueInField("1500", yearBuiltInputField, "Enter Year built:");
		scrollAndClickOnElement(buttonContinue);
		String currentYearPlusOne = String.valueOf(getTodayDate().plusYears(1).getYear());
		fsa.assertTrue(getPageErrors().contains("Mobile home model year must be between 1901-" + currentYearPlusOne + PERIOD), "Year built too old error found.");
		clearErrorsInPage();
		fsa.assertTrue(getPageErrors().isEmpty(), "Page error(s) should not be found after refresh.");
		fsa.assertTrue(getPageAlerts().isEmpty(), "Page alert(s) should not be found after refresh.");
		enterValueInField("2500", yearBuiltInputField, "Enter Year built:");
		scrollAndClickOnElement(buttonContinue);
		fsa.assertTrue(getPageErrors().contains("Mobile home model year must be between 1901-" + currentYearPlusOne + PERIOD), "Home built in the future error found.");
		clearErrorsInPage();
		enterValueInField("1000", replacementCostInputField, "Entering not expensive enough of a home:");
		scrollAndClickOnElement(buttonContinue);
		fsa.assertTrue(getPageErrors().contains("Please call to discuss coverage options for homes less than $50,000 or greater than $300,000."), "Home not expensive enough to cover error found.");
		clearErrorsInPage();
		enterValueInField("400000", replacementCostInputField, "Entering too expensive a home:");
		scrollAndClickOnElement(buttonContinue);
		fsa.assertTrue(getPageErrors().contains("Please call to discuss coverage options for homes less than $50,000 or greater than $300,000."), "Home too expensive to replace error found.");
		clearErrorsInPage();
	}

	protected void clearErrorsInPage() throws Exception {
		driver().navigate().refresh();
		wait.until(invisibilityOfElementLocated(By.xpath("//mat-error")));
	}

	public void validateSnackbarMessages(FarmersSoftAssert fsa) {
		enterValueInField("1500", yearBuiltInputField, "Enter Year built:");
		enterValueInField(String.valueOf(LocalDate.now().minusYears(10).getYear()), yearBuiltInputField, "Home built less than 15 years ago");
		sleep(3);
		fsa.assertTrue(isSnackBarMessageDisplayed("We added a newer home discount"), "Tell us more page - Newer home discount added snackbar message found.");
		enterValueInField(String.valueOf(LocalDate.now().minusYears(20).getYear()), yearBuiltInputField, "Home built more than 15 years ago");
		sleep(3);
		fsa.assertTrue(isSnackBarMessageDisplayed("Newer home discount removed"), "Tell us more page - Newer home discount removed snackbar message found.");
	}
}
