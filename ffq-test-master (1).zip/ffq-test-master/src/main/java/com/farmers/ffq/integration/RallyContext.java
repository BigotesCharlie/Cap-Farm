package com.farmers.ffq.integration;

/**
 * Thread-local context that carries extra metadata from a running test
 * to the {@link RallyListener} without requiring test methods to pass
 * arguments explicitly.
 *
 * <p>Usage inside a test method:
 * <pre>
 *   // store the quote number so it appears in the Rally result note
 *   RallyContext.setQuoteNumber(appStore.getData().getQuoteNumber());
 *
 *   // optionally override the auto-captured screenshot
 *   RallyContext.setScreenshotBytes(myCustomScreenshotBytes);
 * </pre>
 *
 * <p>The context is cleared automatically at the start of every test by
 * {@link RallyListener#onTestStart}.
 */
public final class RallyContext {

    private static final ThreadLocal<String> quoteNumber     = new ThreadLocal<>();
    private static final ThreadLocal<byte[]> screenshotBytes  = new ThreadLocal<>();
    private static final ThreadLocal<String> htmlReportPath   = new ThreadLocal<>();
    private static final ThreadLocal<String> pageSourceHtml   = new ThreadLocal<>();

    private RallyContext() {}

    /** Stores the quote number for the currently running test. */
    public static void setQuoteNumber(String qn) {
        quoteNumber.set(qn);
    }

    /** Returns the quote number stored by the current test, or {@code null}. */
    public static String getQuoteNumber() {
        return quoteNumber.get();
    }

    /**
     * Manually stores screenshot bytes.
     * If not set, {@link RallyListener} will attempt to capture the screenshot
     * automatically via the WebDriver.
     */
    public static void setScreenshotBytes(byte[] bytes) {
        screenshotBytes.set(bytes);
    }

    /** Returns screenshot bytes stored by the current test, or {@code null}. */
    public static byte[] getScreenshotBytes() {
        return screenshotBytes.get();
    }

    /**
     * Manually sets the path to an HTML page-source capture to attach to the
     * Rally result.  If not set, {@link RallyListener} will automatically search
     * {@code build/source/} for a file whose name ends with the test method name.
     */
    public static void setHtmlReportPath(String path) {
        htmlReportPath.set(path);
    }

    /** Returns the HTML report path stored by the current test, or {@code null}. */
    public static String getHtmlReportPath() {
        return htmlReportPath.get();
    }

    /**
     * Stores the raw page-source HTML (with {@code <base>} tag already injected)
     * captured immediately after the test method body completes.
     */
    public static void setPageSourceHtml(String html) {
        pageSourceHtml.set(html);
    }

    /** Returns the page-source HTML stored for the current test, or {@code null}. */
    public static String getPageSourceHtml() {
        return pageSourceHtml.get();
    }


    /** Clears all thread-local state. Called by {@link RallyListener#onTestStart}. */
    public static void clear() {
        quoteNumber.remove();
        screenshotBytes.remove();
        htmlReportPath.remove();
        pageSourceHtml.remove();
    }
}
