package com.farmers.ffq.utils;

import com.farmers.ffq.auto.pages.AutoBasePage;


import com.farmers.ffq.datatransferobjects.AutoApplicant;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import javax.annotation.Nullable;

public class MailinatorHelper extends AutoBasePage {

    @FindBy(css = "#menu-item-7937")
    private WebElement logInButton;

    @FindBy(id = "many_login_email")
    private WebElement emailIdLoginInputField;

    @FindBy(id = "many_login_password")
    private WebElement passwordInputField;

    @FindBy(css = "a[class='btn btn-default submit']")
    private WebElement logInSubmit;

    @FindBy(css = "input[id='inbox_field']")
    private WebElement emailUserNameInputField;

    @FindBy(xpath = "//div[@class='wrapper-title d-flex align-items-center']//div[2]")
    private WebElement emailSubject;

    @FindBy(css = "img[title='Farmers Insurance']")
    private WebElement farmersInsuranceLink;

    @FindBy(css = "span[style='font-size: 28px']>b")
    private WebElement premiumAmount;

    @FindBy(partialLinkText = "Finish my quote")
    private WebElement finishMyQuote;

    @FindBy(partialLinkText = "Finalize my coverage")
    private WebElement finalizeMyCoverage;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public MailinatorHelper() throws Exception {
    }

    private final String MAILINATOR_URL = "https://www.mailinator.com/";

    private void logIntoMailinator() throws Exception {
        driver().navigate().refresh();
        driver().get(MAILINATOR_URL);
        String emailId = "ali.ak@farmersinsurance.com";
        String password = "Farmers123!";
        waitAndClickElement(logInButton);
        sendKeysToElement(waitElementBeVisible(emailIdLoginInputField), emailId);
        sendKeysToElement(waitElementBeVisible(passwordInputField), password);
        waitAndClickElement(logInSubmit);
    }

    private void openEmail(String emailUserName) throws Exception{

        logIntoMailinator();
        sendKeysToElement(waitElementBeVisible(emailUserNameInputField), emailUserName);
        sleep(1);
        WebElement lastRecievedEmail = waitElementBeVisible(driver().findElement(By.xpath(String.format("//tr[contains(@id,'row_%s')][1]", emailUserName))));

        waitAndClickElement(lastRecievedEmail);

    }

    public boolean validateEmailContent(AutoApplicant applicant, String emailUserName, String expectedSubject, String expectedEmailContentHeader, String quoteNumber, @Nullable String expectedPremiumAmount) throws Exception {

        boolean validated = true;
        // wait for the email to drop in the inbox
        sleep(5);
        openEmail(emailUserName.split("@")[0]);

        //validate subject of the email
        validated &= validateEmailSubject(applicant, expectedSubject);

        // validate email body
        validated &= validateEmailBody(applicant, expectedEmailContentHeader, quoteNumber);

        if(expectedPremiumAmount != null) {
            String actualPremiumAmount = getPremiumAmount();
            System.out.println("Actual Premium Amount => " + actualPremiumAmount);
            System.out.println("Expected Premium Amount => " + expectedPremiumAmount);
            validated &= actualPremiumAmount.contains(expectedPremiumAmount);
        }

        return validated;

    }

    private boolean validateEmailBody(AutoApplicant applicant, String expectedEmailContentHeader, String quoteNumber) throws Exception {
        boolean validated = true;
        driver().switchTo().frame("html_msg_body");
        //validate the title of the email body
        validated &= getTextFromElement(waitElementBeVisible(driver().findElement(By.xpath(String.format("//p[contains(.,'%s')]", expectedEmailContentHeader))))).contains(applicant.getFirstName());
        // validate quote number correctly displayed
        validated &= waitElementBeVisible(driver().findElement(By.xpath(String.format("//b[contains(.,'%s')]", quoteNumber)))).isDisplayed();
        return validated;
    }

    private boolean validateEmailSubject(AutoApplicant applicant, String expectedSubject) {
        boolean validated = true;
        String expectedSubjectText = applicant.getFirstName() + expectedSubject;
        // validate subjectLine
        validated &= testExpectedTextContentForElement(waitElementBeVisible(emailSubject), expectedSubjectText);
        return validated;
    }

    public String getPremiumAmount() throws Exception {
       return getTextFromElement(driver().findElement(By.cssSelector("span[style='font-size: 28px']>b")));
    }

    public void clickOnFinishMyQuote() {
       waitAndClickElement(finishMyQuote);
    }

    public void clickOnFinalizeMyQuote() {
       waitAndClickElement(finalizeMyCoverage);
    }

}
