package com.farmers.ffq.auto.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PartnerPremiumDetailsPage extends AutoBasePage {

	@FindBy(xpath = "//app-partner-premium-details//h1")
    private WebElement partnerDetailsPageTitle;

    public PartnerPremiumDetailsPage() throws Exception {
    }

    public boolean isOnPartnerPremiumDetailsPage() {
        return isElementVisible(partnerDetailsPageTitle, 10);
    }

}
