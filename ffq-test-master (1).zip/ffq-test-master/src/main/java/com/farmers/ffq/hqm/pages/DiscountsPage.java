package com.farmers.ffq.hqm.pages;

import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.QuoteRateHQM;
import com.farmers.ffq.datatransferobjects.hqm.StaticContentHQM;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import javax.annotation.Nullable;
import java.time.LocalDate;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOf;

/**
 * Farmers Fast Quote (FFQ) - Quote Property Page - Home Quote Modernization (HQM).
 */

public class DiscountsPage extends HqmBasePage {
    private static final String HOME_PROTECTION_AND_LOSS_PREVENTION = "home protection and loss prevention";
	private static final String PREFERRED_PAYMENT_PLAN = "preferred payment plan";
	private static final String DISCOUNTS_PAGE_BUTTON_NEXT_DISABLED = "Discounts page - button Next is disabled now.";
	private static final String NO_I_DONT = "no, i don't";
	private static final String PROFESSIONALLY_DASH_MONITORED = "professionally-monitored";
	private static final String WHOLE_HOUSE_WATER_DETECTION_AND_SHUTOFF = "whole house water detection and shutoff";
	private static final String FORTIFIED_HOME_IS_SELECTED_CORRECTLY = "Fortified Home is selected correctly.";
	private static final String WATER_LEAK_PROTECTION_IS_SELECTED_CORRECTLY = "Water Leak Protection is selected correctly.";
	private static final String FIRE_PROTECTION_IS_SELECTED_CORRECTLY = "Fire Protection is selected correctly.";
	private static final String THEFT_PROTECTION_IS_SELECTED_CORRECTLY = "Theft Protection is selected correctly.";
	private static final String PROFESSIONALLY_MONITORED = "professionally monitored";
	private static final String HOME_BUYER = "home buyer";
	private static final String HOME_CEA = "home cea";
	private static final String CENTRAL_BURGLAR_ALARM = "central burglar alarm";
	private static final String CENTRAL_FIRE_ALARM = "central fire alarm";
	private static final String NEW_HOME = "new home";
	private static final String PREFERRED_PAYMENT = "preferred payment";
	private static final String PAPERLESS = "paperless";
	private static final String GOOD_PAYER = "good payer";
	private static final String AFFINITY_OCCUPATION = "affinity(occupation)";
	private static final String FARMERS_LIFE_CUSTOMER = "farmers life customer";
	private static final String FARMERS_AUTO_CUSTOMER = "farmers auto customer";
    private static final String DISCOUNTS_PAGE_TITLE = "DO ANY OF THESE\nPOTENTIAL\nDISCOUNTS APPLY?";
    private static final String DISCOUNTS_PAGE_TITLE2 = "Preapplied discounts";

    // Safety features checkboxes

    private static final String SAFETY_FEATURES_CHECKBOXES_XPATH = "//div[@id='safetyFeaturesCheckbox']//mat-checkbox//input";

    private static final String CENTRAL_FIRE_XPATH = "//ui-farmers-checkbox[contains(@data-gtm,'CentralFireAlarm')]//mat-checkbox//input";
    @FindBy(xpath = CENTRAL_FIRE_XPATH)
    private WebElement checkCentralFire;

    private static final String CENTRAL_BURGLAR_XPATH = "//ui-farmers-checkbox[contains(@data-gtm,'CentralBurglarAlarm')]//mat-checkbox//input";
    @FindBy(xpath = CENTRAL_BURGLAR_XPATH)
    private WebElement checkBurglar;

    private static final String CEA_XPATH = "//ui-farmers-checkbox[contains(@data-gtm,'CeaInsurance')]//mat-checkbox//input";
    @FindBy(xpath = CEA_XPATH)
    private WebElement checkCEA;

    private static final String ADT_XPATH = "//ui-farmers-checkbox[contains(@data-gtm,'ConnectedHome')]//mat-checkbox//input";
    @FindBy(xpath = ADT_XPATH)
    private WebElement checkADT;

    private static final String THEFT_ALARM_XPATH = "//mat-checkbox[starts-with(@id,'professionallyMonitoredTheftAlarm')]//input";
    @FindBy(xpath = THEFT_ALARM_XPATH)
    private WebElement checkTheftAlarm;

    private static final String FIRE_ALARM_XPATH = "//mat-checkbox[starts-with(@id,'professionallyMonitoredFireAlarm')]//input";
    @FindBy(xpath = FIRE_ALARM_XPATH)
    private WebElement checkFireAlarm;

    private static final String WATER_SENSOR_XPATH = "//mat-checkbox[starts-with(@id,'waterSensor')]//input";
    @FindBy(xpath = WATER_SENSOR_XPATH)
    private WebElement checkWaterSensor;

    private static final String FORTIFIED_HOME_XPATH = "//mat-checkbox[starts-with(@id,'fortifiedHome')]//input";
    @FindBy(xpath = FORTIFIED_HOME_XPATH)
    private WebElement checkFortifiedHome;

    private static final String NEWLY_OWNED_HOME_XPATH = "//mat-checkbox//input[@id='HBDD-input']";
    @FindBy(xpath = NEWLY_OWNED_HOME_XPATH)
    private WebElement checkNewlyOwnedHome;

    private static final String SAFETY_FEATURES_SELECT_XPATH = "//div[@id='safetyFeaturesCheckbox']//mat-select";

    @FindBy(xpath = "//mat-select[contains(@id,'theftProtectionSelected')]")
    private WebElement selectTheftProtection;

    @FindBy(xpath = "//mat-select[contains(@id,'fireProtectionSelected')]")
    private WebElement selectFireProtection;

    @FindBy(xpath = "//mat-select[contains(@id,'waterProtectionSelected')]")
    private WebElement selectWaterProtection;

    private static final String FORTIFIED_XPATH = "//mat-select[contains(@id,'fortifiedHomeSelectedValue') or " +
            "contains(@id,'windStormMitigationSelectedValue')]";
    @FindBy(xpath = FORTIFIED_XPATH)
    private WebElement selectFortifiedHome;

    @FindBy(xpath = "//mat-select[contains(@id,'centralAlarmSelected')]")
    private WebElement selectCentralAlarm;

    @FindBy(xpath = "//mat-select[contains(@id,'directAlarmSelected')]")
    private WebElement selectDirectAlarm;

    @FindBy(xpath = "//mat-select[contains(@id,'localAlarmSelected')]")
    private WebElement selectLocalAlarm;

    @FindBy(xpath = "//mat-select[contains(@id,'automaticSmokeDetector')]")
    private WebElement selectAutoSmokeDetectors;

    @FindBy(xpath = "//mat-select[contains(@id,'automaticSprinkler')]")
    private WebElement selectAutoSprinklerSystem;

    private static final String AUTO_POLICY_XPATH = "//mat-checkbox//input[@id='autoSelected-input']";
    @FindBy(xpath = AUTO_POLICY_XPATH)
    private WebElement checkAutoPolicy;

    private static final String SELECT_LIST_OPTIONS_XPATH = "//div[contains(@class,'mat-select-panel-wrap')]//mat-option";
    private final By selectListOptionsBy = By.xpath(SELECT_LIST_OPTIONS_XPATH);

    private static final String SELECT_OPTIONS_XPATH = "//div[contains(@class,'mat-select-panel')]//mat-option[.='%s']";

    @FindBy(xpath = "//ui-farmers-datepicker[@fieldlabel='Policy start date']//input[@matinput]")
    private WebElement inputPolicyStartDate;

    @FindBy(xpath = "//ui-farmers-datepicker[@fieldlabel='Policy start date']//mat-label")
    private WebElement labelPolicyStartDate;

    // Farmers insurance products checkboxes

    private static final String INSURANCE_PRODUCTS_CHECKBOXES_XPATH = "//div[@id='farmersInsuranceCheckbox']//mat-checkbox//input";

    private static final String LIFE_INSURANCE_XPATH = "//ui-farmers-checkbox[contains(@data-gtm,'LifeInsurance')]//mat-checkbox//input";
    @FindBy(xpath = LIFE_INSURANCE_XPATH)
    private WebElement checkLifeInsurance;

    private static final String AUTO_INSURANCE_XPATH = "//ui-farmers-checkbox[contains(@data-gtm,'AutoInsurance')]//mat-checkbox//input";
    @FindBy(xpath = AUTO_INSURANCE_XPATH)
    private WebElement checkAutoInsurance;

    private static final String COMMERCIAL_XPATH = "//ui-farmers-checkbox[contains(@data-gtm,'CommercialInsurance')]//mat-checkbox//input";
    @FindBy(xpath = COMMERCIAL_XPATH)
    private WebElement checkCommercial;

    private static final String BOAT_WATER_CRAFT_XPATH = "//ui-farmers-checkbox[contains(@data-gtm,'rec')]//mat-checkbox//input";
    @FindBy(xpath = BOAT_WATER_CRAFT_XPATH)
    private WebElement checkBoatAndWatercraft;

    private static final String OFF_ROAD_XPATH = "//ui-farmers-checkbox[contains(@data-gtm,'offroadInsurance')]//mat-checkbox//input";
    @FindBy(xpath = OFF_ROAD_XPATH)
    private WebElement checkOffRoad;

    private static final String MOTOR_HOME_XPATH = "//ui-farmers-checkbox[contains(@data-gtm,'MotorHome')]//mat-checkbox//input";
    @FindBy(xpath = MOTOR_HOME_XPATH)
    private WebElement checkMotorHome;

    private static final String UMBRELLA_INSURANCE_XPATH = "//ui-farmers-checkbox[contains(@data-gtm,'UmbrellaInsurance')]//mat-checkbox//input";
    @FindBy(xpath = UMBRELLA_INSURANCE_XPATH)
    private WebElement checkUmbrellaInsurance;

    @FindBy(xpath = "//mat-icon[text()='info ']")
    private WebElement iconHelp;

    @FindBy(xpath = "//div//p[contains(@class,'quote-step-caption')]/span[text()='Preferred Payment']")
    private WebElement textPreferredPayment;

    @FindBy(xpath = "//div//p[contains(@class,'quote-step-caption')]/span[text()='Paperless']")
    private WebElement textPaperless;

    @FindBy(xpath = "//div//p[contains(@class,'quote-step-caption')]/span[text()='Good Payer']")
    private WebElement textGoodPayer;

    @FindBy(xpath = "//div//p[contains(@class,'quote-step-caption')]/span[text()='Recreational boat/watercraft insurance']")
    private WebElement textRecreationalBoat;

    private static final String PAGE_TITLE_XPATH = "//farmers-home-quote-discounts//h1[@aria-label='DO ANY OF THESE POTENTIAL DISCOUNTS APPLY?']";
    @FindBy(xpath = PAGE_TITLE_XPATH)
    private WebElement textPageTitle1;

    @FindBy(xpath = "//farmers-home-quote-knockouts//h1")
    private WebElement knockOutsPageTitle;

    @FindBy(xpath = "//farmers-home-quote-discounts//h2[@aria-label='Preapplied discounts']")
    private WebElement textPageTitle2;

    private static final String XPATH_PAGE_SUBTITLE_TEXT1 = "//farmers-home-quote-discounts//div[contains(@class,'sub-title-one') or " +
            "contains(@class,'tui-subtitle-text-1')]";

    private static final String XPATH_PAGE_SUBTITLE_TEXT2 = "//farmers-home-quote-discounts//span[contains(@class,'sub-title-one') or " +
            "contains(@class,'tui-subtitle-text-1')]";

    private final List<String> subtitlesDiscountsPage = Arrays.asList("Please choose the safety features that you have in your home.",
            "Do you have any of these Farmers insurance products?\ninfo", "Based on the information you provided, discounts " +
                    "you may qualify for have been applied to the premium shown in this quote.", "You may be asked to provide information " +
                    "to verify eligibility. Other discounts may be available through a Farmers agent.");

    private static final String SUBTITLE_KY = "When would you like your new policy to start?";

    private static final String SUBTITLE_CA = "Do you have any of these Farmers insurance products?\ninfo";

    private final By textPreappliedDiscounts = By.xpath("//farmers-home-quote-discounts//mat-card//p[contains(@class,'quote-step-caption')]/span[not(@aria-hidden)]");

    private final List<String> preappliedDiscounts = Arrays.asList(AFFINITY_OCCUPATION, GOOD_PAYER, PAPERLESS, PREFERRED_PAYMENT, NEW_HOME);

    @FindBy(xpath = "//farmers-home-quote-discounts//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__potential')]/../p")
    private WebElement discountSubTitlePiggy;

    private static final String DISCOUNT_PIGGY_TEXT = "otential savings/discounts. Let's find some more.";

    @FindBy(xpath ="//farmers-home-quote-discounts//div[@class='discount-journey-card']//mat-icon[text()='info']")
    private WebElement discountHelpButtonPiggy;

    @FindBy(xpath = "//farmers-home-quote-discount-journey-dialog//h4")
    private WebElement discountHelpDialogTitle;

    private static final String DISCOUNT_HELP_DIALOG_TITLE = "Potential savings/discounts ($)";

    private static final String DISCOUNT_HELP_DIALOG_CONTENT_XPATH = "//farmers-home-quote-discount-journey-dialog//li";
    @FindBy(xpath = DISCOUNT_HELP_DIALOG_CONTENT_XPATH)
    private WebElement discountHelpDialogContent;

    @FindBy(xpath = "//farmers-home-quote-discounts//mat-card//div[@id='safetyFeaturesCheckbox']//div[@class='djm-discount-check']/../p")
    private WebElement safetyFeaturesCheck;

    private static final String SAFETY_FEATURES_CHECK_TEXT = "Nice! You may be eligible for our Home Safety discount.";

    private static final String SAFETY_FEATURES_CHECK_TEXT2 = "Great! You may be eligible for one or more Home Safety discounts.";

    @FindBy(xpath = "//farmers-home-quote-discounts//mat-card//div[@id='farmersInsuranceCheckbox']/../..//div[@class='djm-discount-check']/../p")
    private WebElement discountsCheck;

    private static final String DISCOUNT_CHECK_TEXT = "Great! You may be eligible for our Multi-line discount.";

    @FindBy(xpath = "//farmers-home-quote-tooltip-modal//h4")
    private WebElement helpDialogTitle;

    @FindBy(xpath = "//mat-dialog-actions//button[text()=('CLOSE' or 'close')]")
    private WebElement buttonCloseDialog;

    @FindBy(xpath = "//mat-dialog-container//div[@data-test-id='DIALOG_CONTENT' or @mat-dialog-content]")
    private WebElement helpDialogContent;

    @FindBy(xpath = "//farmers-home-quote-discounts//span[contains(@class,'sub-title-one')]//mat-icon[contains(@class,'mid-blue')]")
    private WebElement helpSubtitle;

    @FindBy(xpath = "//farmers-home-quote-discounts//span[starts-with(@aria-label,'California Earthquake Authority')]//mat-icon")
    private WebElement helpCEA;

    @FindBy(xpath = "//farmers-home-quote-discounts//div[contains(@class,'prequalified-discounts-block')]//mat-icon[contains(@class,'mid-blue')]")
    private WebElement helpPreappliedTitle;

    @FindBy(xpath = "//ui-farmers-checkbox[@id='professionallyMonitoredTheftAlarm']//mat-icon")
    private WebElement helpTheftAlarm;

    @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'TheftProtection')]//mat-icon")
    private WebElement helpTheftAlarmSelect;

    @FindBy(xpath = "//ui-farmers-checkbox[@id='professionallyMonitoredFireAlarm']//mat-icon")
    private WebElement helpFireAlarm;

    @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'FireProtection')]//mat-icon")
    private WebElement helpFireAlarmSelect;

    @FindBy(xpath = "//ui-farmers-checkbox[@id='waterSensor']//mat-icon")
    private WebElement helpWaterSensor;

    @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'WaterLeakProtection')]//mat-icon")
    private WebElement helpWaterSensorSelect;

    @FindBy(xpath = "//ui-farmers-checkbox[@id='fortifiedHome']//mat-icon")
    private WebElement helpFortifiedHome;

    @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'FORTIFIEDHome')]//mat-icon")
    private WebElement helpFortifiedHomeSelect;

    @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'WindStormMitigation')]//mat-icon")
    private WebElement helpWindstormMitigationSelect;

    @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'CentralAlarm')]//mat-icon")
    private WebElement helpCentralAlarmSelect;

    @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'DirectAlarm')]//mat-icon")
    private WebElement helpDirectAlarmSelect;

    @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'LocalAlarm')]//mat-icon")
    private WebElement helpLocalAlarmSelect;

    @FindBy(xpath = "//ui-farmers-select[contains(@data-gtm,'AutomaticSprinklerSystem')]//mat-icon")
    private WebElement helpAutomaticSprinklerSelect;

    private static final String DISCOUNTS_HELP_TEXT = "Discounts are applied after verification that you satisfy all requirements. " +
            "Discounts may vary and are not available in all states.";
    private static final String DISCOUNTS_HELP_TEXT2 = "Discounts are applied after verification that you satisfy all requirements. " +
            "Discounts may vary and are not available in all states. If available,the Preferred payment discount only applies " +
            "for specific payment plans. This discount is not available if you choose a monthly payment plan,except for the " +
            "monthly mortgagee pay plan.";
    private static final String THEFT_SELECT_HELP_TITLE = "Theft Protection";
    private static final String THEFT_SELECT_HELP_TEXT = "A discount is provided if the dwelling has a theft protection device installed " +
            "that is un-monitored, self-monitored or monitored by a professional servicing company.";
    private static final String FIRE_SELECT_HELP_TITLE = "Fire Protection";
    private static final String FIRE_SELECT_HELP_TEXT = "A discount is provided if the dwelling has a fire alarm device installed " +
            "that is un-monitored, self-monitored or monitored by a professional servicing company.";

    private static final String WATER_SENSOR_SELECT_HELP_TITLE = "Water Leak Protection";
    private static final String WATER_SENSOR_SELECT_HELP_TEXT = "A discount is provided if the dwelling has a water leak protection device " +
            "system that monitors the plumbing systems within a dwelling and has single point water detection, whole home " +
            "water detection or whole home water detection with shutoff. Note that proof of installation must be provided " +
            "for the applicable discount to be applied.";

    private static final String FORTIFIED_HOME_SELECT_HELP_TITLE = "FORTIFIED Home \u2122";
    private static final String FORTIFIED_HOME_SELECT_HELP_TEXT = "A Fortified Home is a dwelling that is constructed with added " +
            "protection to resist natural disasters and extreme weather events such as high wind, wildfire, flood, hail, " +
            "and earthquake. The home is constructed with added protection to windows and doors, improved connections " +
            "between the roof, walls and foundation, and a roof design that is thicker, stronger, and designed to stay drier. " +
            "Fortified Home has 3 designation levels: Roof (Bronze), Silver, Gold.";
    private static final String WINDSTORM_MITIGATION_SELECT_HELP_TITLE = "Windstorm Mitigation";
    private static final String WINDSTORM_MITIGATION_SELECT_HELP_TEXT = "A discount is provided if the dwelling is constructed with " +
            "added protection to resist natural disasters and extreme weather events such as high wind, wildfire, flood, hail, " +
            "and earthquake. The discount has 5 levels of qualification. Note that proof of certification must be provided for " +
            "the applicable discount to be applied.";
    private static final String CENTRAL_ALARM_SELECT_HELP_TITLE = "Central Alarm";
    private static final String CENTRAL_ALARM_SELECT_HELP_TEXT = "Alerts a third-party monitoring company that may send someone " +
            "to investigate or contacts the police/fire department.";
    private static final String DIRECT_ALARM_SELECT_HELP_TITLE = "Direct Alarm";
    private static final String DIRECT_ALARM_SELECT_HELP_TEXT = "Alerts the police or fire department directly.";
    private static final String LOCAL_ALARM_SELECT_HELP_TITLE = "Local Alarm";
    private static final String LOCAL_ALARM_SELECT_HELP_TEXT = "Alarm sounds on premises only.";
    private static final String POLICY_START_DATE_ERROR = "Policy start date can not be greater than 60 days from today's date";
    private static final String POLICY_START_DATE_ERROR2 = "Date can not be less than today's date";
    private static final String POLICY_START_DATE_ERROR3 = "Entered policy start date is not a valid entry";

    private final List<String> listTheftProtections = Arrays.asList(NONE, "Unmonitored", "Self-Monitored", "Professionally Monitored");
    private final List<String> listFireProtections = Arrays.asList(NONE, "Unmonitored", "Self-Monitored", "Professionally Monitored");
    private final List<String> listFortifiedHome = Arrays.asList(NONE, "FORTIFIED Roof", "Silver", "Gold");
    private final List<String> listWindstormMitigation = Arrays.asList(NONE, "2006 International Residential Code", "FORTIFIED Roof",
            "FORTIFIED Silver", "FORTIFIED Gold", "FORTIFIED for Safer Living");
    private final List<String> listWaterSensors = Arrays.asList(NONE, "Single Point Water Detection", "Whole House Water Detection",
            "Whole House Water Detection and Shutoff");

    private List<String> listTheftProtectionFlex = Arrays.asList("No, I don't have this feature", "Yes, it is unmonitored",
            "Yes, it is self-monitored", "Yes, it is professionally-monitored");
    private final List<String> listFireProtectionFlex = Arrays.asList("No, I don't have this feature", "Yes, it is unmonitored",
            "Yes, it is self-monitored", "Yes, it is professionally-monitored");
    private List<String> listWaterProtectionFlex = Arrays.asList("No, I don't have this feature", "Yes, single point detection",
            "Yes, whole house detection", "Yes, whole house detection and shutoff");
    private final List<String> listFortifiedHomeFlex = Arrays.asList("No, I don't have this feature", "Yes, FORTIFIED Roof",
            "Yes, FORTIFIED Silver", "Yes, FORTIFIED Gold");

    private final List<String> listCentralAlarm = Arrays.asList(NONE, "Burglar", "Fire", "Both");
    private final List<String> listDirectAlarm = Arrays.asList(NONE, "Fire Station", "Police Station", "Both");
    private final List<String> listLocalAlarm = Arrays.asList(NONE, "Burglar", "Fire", "Both");
    private final List<String> listNoYes = Arrays.asList(NO, YES);
    private final List<String> listAutoSprinklers = Arrays.asList(NONE, "Full", "Partial");

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public DiscountsPage() throws Exception {
        super();
//        wait.until(ExpectedConditions.or(visibilityOf(textPageTitle1), visibilityOf(knockOutsPageTitle)));
        wait.until(ExpectedConditions.or(visibilityOf(textPageTitle2), visibilityOf(knockOutsPageTitle)));
    }

    public void setRequiredFields(ApplicantHQM applicant) throws Exception {
        List<String> preAppliedDiscounts = this.getDiscountsLowerCase();
        if (isEasternExpansionState(applicant.stateCode)) {
            if (!applicant.stateCode.equals(NC)) {
                selectTheftProtection(Boolean.toString(applicant.theftAlarm));
                selectFireProtection(Boolean.toString(applicant.fireAlarm));
                selectWaterProtection(Boolean.toString(applicant.waterShutoff));
                if (isEasternExpansionState(applicant.stateCode) && applicant.fortifiedHome) {
                    selectFortifiedHome(Boolean.toString(true));
                }
            } else {
                selectCentralAlarm(applicant.centralAlarm);
                selectDirectAlarm(applicant.directAlarm);
                selectLocalAlarm(applicant.localAlarm);
                selectAutomaticSmokeDetectors(applicant.autoSmokeDetectors);
                selectAutomaticSprinklerSystem(applicant.autoSprinklerSystem);
                selectWaterProtection(Boolean.toString(applicant.waterShutoff));
            }
        } else if (isFlexState(applicant.stateCode)) {
            checkNewlyOwnedHome(applicant.newlyOwned);
            scrollToElement(textPageTitle2);
            selectTheftProtection(Boolean.toString(applicant.theftAlarm));
            selectFireProtection(Boolean.toString(applicant.fireAlarm));
            selectWaterProtection(Boolean.toString(applicant.waterShutoff));
            selectFortifiedHome(Boolean.toString(applicant.fortifiedHome));
            checkAutoPolicy(applicant.autoInsurance);
            return;
        } else {
            checkCentralFireAlarm(applicant.centralFireAlarm);
            checkCentralBurglarAlarm(applicant.centralBurglarAlarm);
            checkCommercialInsurance(applicant.commercial);
            checkUmbrellaInsurance(applicant.umbrellaInsurance);
        }
        if (!preAppliedDiscounts.contains(FARMERS_AUTO_CUSTOMER)) {
            checkAutoInsurance(applicant.autoInsurance);
        }
        if (!preAppliedDiscounts.contains(FARMERS_LIFE_CUSTOMER) && !Arrays.asList(KY, CT, MS, MA, LA, NC).contains(applicant.stateCode)) {
            checkLifeInsurance(applicant.lifeInsurance);
        }
        if (!applicant.stateCode.equals(CA)) {
            checkBoatAndWatercraft(applicant.boatWaterCraft);
            if (!Arrays.asList(NV, MO, CO, IN, KS, MD).contains(applicant.stateCode)) {
                checkOffRoad(applicant.offRoad);
                checkMotorHome(applicant.motorHome);
            }
        } else {
            checkCEA(applicant.ceaCoverage);
        }
        if (isAdtSecurityState(applicant.stateCode)) {
            checkADT(applicant.adtSecurity);
        }
    }

    public void getFieldValues(ApplicantHQM applicant) throws Exception {
        if (isEasternExpansionState(applicant.stateCode)) {
            if (!applicant.stateCode.equals(NC)) {
                Log.info("Theft Protection value selected: " + this.getSelectedTheftProtection());
                Log.info("Fire Protection value selected: " + this.getSelectedFireProtection());
                Log.info("Water Leak Protection value selected: " + this.getSelectedWaterProtection());
                Log.info("FORTIFIED Home value selected: " + this.getSelectedFortifiedHome());
            } else {
                Log.info("Selected Central Alarm: " + this.getSelectedCentralAlarm());
                Log.info("Selected Direct Alarm: " + this.getSelectedDirectAlarm());
                Log.info("Selected Local Alarm: " + this.getSelectedLocalAlarm());
                Log.info("Selected Automatic Smoke Detectors: " + this.getSelectedAutomaticSmokeDetectors());
                Log.info("Selected Automatic Sprinkler System: " + this.getSelectedAutomaticSprinklerSystem());
                Log.info("Selected Water Leak Protection: " + this.getSelectedWaterProtection());
            }
        } else if (isFlexState(applicant.stateCode)) {
            Log.info("Newly Owned Home: " + this.isCheckedNewlyOwnedHome());
            Log.info("Theft Protection value selected: " + this.getSelectedTheftProtection());
            Log.info("Fire Protection value selected: " + this.getSelectedFireProtection());
            Log.info("Water Leak Protection value selected: " + this.getSelectedWaterProtection());
            Log.info("FORTIFIED Home value selected: " + this.getSelectedFortifiedHome());
            Log.info("Have Farmers Auto Policy: " + this.isCheckedAutoPolicy());
            return;
        } else {
            Log.info("Central Fire Alarm: " + this.isCheckedCentralFireAlarm());
            Log.info("Central Burglar Alarm: " + this.isCheckedCentralBurglarAlarm());
            Log.info("Commercial Insurance: " + this.isCheckedCommercial());
            Log.info("Umbrella Insurance: " + this.isCheckedUmbrellaInsurance());
        }
        if (!applicant.stateCode.equals(CA)) {
            Log.info("Boat and Watercraft: " + this.isCheckedBoatAndWatercraft());
            if (!Arrays.asList(NV, MO, CO, IN, KS, MD).contains(applicant.stateCode)) {
                Log.info("Off-road Vehicle insurance: " + this.isCheckedOffRoad());
                Log.info("Motorhome, Travel Trailer or 5th Wheel insurance: " + this.isCheckedMotorHome());
            }
        } else {
            Log.info("CEA Insurance: " + this.isCheckedCEA());
        }
        if (isAdtSecurityState(applicant.stateCode)) {
            Log.info("Active Security Monitoring with ADT™: " + this.isCheckedADT());
        }
    }

    private boolean isCheckedElement(String checkboxXpath) throws Exception {
        WebElement webElInput = driver().findElement(By.xpath(checkboxXpath)); // +"//input"));
        return webElInput.isSelected();
    }

    private void checkElement(String checkboxXpath, boolean check) throws Exception {
        WebElement webEl = driver().findElement(By.xpath(checkboxXpath + "/.."));
        if ((check && !isCheckedElement(checkboxXpath)) || (!check && isCheckedElement(checkboxXpath))) {
            waitAndClickElement(webEl);
        }
    }

    public void checkCentralFireAlarm(boolean check) throws Exception {
        checkElement(CENTRAL_FIRE_XPATH, check);
    }

    public boolean isCheckedCentralFireAlarm() throws Exception {
        return isCheckedElement(CENTRAL_FIRE_XPATH);
    }

    public void checkCentralBurglarAlarm(boolean check) throws Exception {
        checkElement(CENTRAL_BURGLAR_XPATH, check);
    }

    public boolean isCheckedCentralBurglarAlarm() throws Exception {
        return isCheckedElement(CENTRAL_BURGLAR_XPATH);
    }

    public void checkNewlyOwnedHome(boolean check) throws Exception {
        checkElement(NEWLY_OWNED_HOME_XPATH, check);
    }

    public boolean isCheckedNewlyOwnedHome() throws Exception {
        return isCheckedElement(NEWLY_OWNED_HOME_XPATH);
    }

    public void checkCEA(boolean check) throws Exception {
        checkElement(CEA_XPATH, check);
    }

    public boolean isCheckedCEA() throws Exception {
        return isCheckedElement(CEA_XPATH);
    }

    public void checkADT(boolean check) throws Exception {
        checkElement(ADT_XPATH, check);
    }

    public boolean isCheckedADT() throws Exception {
        return isCheckedElement(ADT_XPATH);
    }

    public void checkTheftAlarm(boolean check) throws Exception {
        checkElement(THEFT_ALARM_XPATH, check);
    }

    public boolean isCheckedTheftAlarm() throws Exception {
        return isCheckedElement(THEFT_ALARM_XPATH);
    }

    public void checkFireAlarm(boolean check) throws Exception {
        checkElement(FIRE_ALARM_XPATH, check);
    }

    public boolean isCheckedFireAlarm() throws Exception {
        return isCheckedElement(FIRE_ALARM_XPATH);
    }

    public void checkWaterSensor(boolean check) throws Exception {
        checkElement(WATER_SENSOR_XPATH, check);
    }

    public boolean isCheckedWaterSensor() throws Exception {
        return isCheckedElement(WATER_SENSOR_XPATH);
    }

    public void checkFortifiedHome(boolean check) throws Exception {
        checkElement(FORTIFIED_HOME_XPATH, check);
    }

    public boolean isCheckedFortifiedHome() throws Exception {
        return isCheckedElement(FORTIFIED_HOME_XPATH);
    }

    public void checkLifeInsurance(boolean check) throws Exception {
        checkElement(LIFE_INSURANCE_XPATH, check);
    }

    public boolean isCheckedLifeInsurance() throws Exception {
        return isCheckedElement(LIFE_INSURANCE_XPATH);
    }

    public void checkAutoInsurance(boolean check) throws Exception {
        checkElement(AUTO_INSURANCE_XPATH, check);
    }

    public boolean isCheckedAutoInsurance() throws Exception {
        return isCheckedElement(AUTO_INSURANCE_XPATH);
    }

    public void checkCommercialInsurance(boolean check) throws Exception {
        checkElement(COMMERCIAL_XPATH, check);
    }

    public boolean isCheckedCommercial() throws Exception {
        return isCheckedElement(COMMERCIAL_XPATH);
    }

    public void checkBoatAndWatercraft(boolean check) throws Exception {
        checkElement(BOAT_WATER_CRAFT_XPATH, check);
    }

    public boolean isCheckedBoatAndWatercraft() throws Exception {
        return isCheckedElement(BOAT_WATER_CRAFT_XPATH);
    }

    public void checkOffRoad(boolean check) throws Exception {
        checkElement(OFF_ROAD_XPATH, check);
    }

    public boolean isCheckedOffRoad() throws Exception {
        return isCheckedElement(OFF_ROAD_XPATH);
    }

    public void checkMotorHome(boolean check) throws Exception {
        checkElement(MOTOR_HOME_XPATH, check);
    }

    public boolean isCheckedMotorHome() throws Exception {
        return isCheckedElement(MOTOR_HOME_XPATH);
    }

    public void checkAutoPolicy(boolean check) throws Exception {
        checkElement(AUTO_POLICY_XPATH, check);
    }

    public boolean isCheckedAutoPolicy() throws Exception {
        return isCheckedElement(AUTO_POLICY_XPATH);
    }

    public void checkUmbrellaInsurance(boolean check) throws Exception {
        checkElement(UMBRELLA_INSURANCE_XPATH, check);
    }

    public boolean isCheckedUmbrellaInsurance() throws Exception {
        return isCheckedElement(UMBRELLA_INSURANCE_XPATH);
    }

    public void validatePageFieldContents(ApplicantHQM applicant, boolean bNew, FarmersSoftAssert fsa, @Nullable List<String> discounts) throws Exception {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(MM_DD_YYYY);
        if (bNew) {
            boolean centralFire = false;
            boolean centralBurglar = false;
            boolean ceaCoverage = false;
            boolean adtSecurity = false;
            boolean theftAlarm = false;
            boolean fireAlarm = false;
            boolean waterSensor = false;
            boolean newlyOwned = false;
            boolean fortifiedHome = false;
            boolean autoInsurance = false;
            boolean lifeInsurance = false;
            boolean centralAlarm = false;
            boolean directAlarm = false;
            boolean localAlarm = false;
            boolean autoSmokeDetectors = false;
            boolean autoSprinklerSystem = false;
            if ((!Objects.requireNonNull(discounts).isEmpty())) {
                centralFire = discounts.contains(CENTRAL_FIRE_ALARM);
                centralBurglar = discounts.contains(CENTRAL_BURGLAR_ALARM);
                ceaCoverage = discounts.contains(HOME_CEA);
                adtSecurity = discounts.contains("active security monitoring with adt™");
                autoInsurance = discounts.contains(FARMERS_AUTO_CUSTOMER);
                lifeInsurance = discounts.contains(FARMERS_LIFE_CUSTOMER);
                newlyOwned = discounts.contains(HOME_BUYER);
            } else {   // work-around in case Postgres connection does not work
                if (isEasternExpansionState(applicant.stateCode)) {
                    if (!applicant.stateCode.equals(NC)) {
                        theftAlarm = this.isCheckedTheftAlarm();
                        fireAlarm = this.isCheckedFireAlarm();
                        waterSensor = this.isCheckedWaterSensor();
                        fortifiedHome = this.isCheckedFortifiedHome();
                    } else {
                        centralAlarm = !this.getSelectedCentralAlarm().equals(NONE);
                        directAlarm = !this.getSelectedDirectAlarm().equals(NONE);
                        localAlarm = !this.getSelectedLocalAlarm().equals(NONE);
                        autoSmokeDetectors = this.getSelectedAutomaticSmokeDetectors().equals(YES);
                        autoSprinklerSystem = !this.getSelectedAutomaticSprinklerSystem().equals(NONE);
                        waterSensor = !this.getSelectedWaterProtection().equals(NONE);
                    }
                } else {
                    centralFire = this.isCheckedCentralFireAlarm();
                    centralBurglar = this.isCheckedCentralBurglarAlarm();
                    if (applicant.stateCode.equals(CA)) {
                        ceaCoverage = this.isCheckedCEA();
                    }
                    if (isAdtSecurityState(applicant.stateCode)) {
                        adtSecurity = this.isCheckedADT();
                    }
                }
            }
            if (isEasternExpansionState(applicant.stateCode)) {
                if (!applicant.stateCode.equals(NC)) {
                    fsa.assertEquals(this.getSelectedTheftProtection().toLowerCase(),
                            (theftAlarm ? PROFESSIONALLY_MONITORED : "none"), THEFT_PROTECTION_IS_SELECTED_CORRECTLY);
                    fsa.assertEquals(this.getSelectedFireProtection().toLowerCase(),
                            (fireAlarm ? PROFESSIONALLY_MONITORED : "none"), FIRE_PROTECTION_IS_SELECTED_CORRECTLY);
                    fsa.assertEquals(this.getSelectedWaterProtection().toLowerCase(),
                            (waterSensor ? WHOLE_HOUSE_WATER_DETECTION_AND_SHUTOFF : "none"), WATER_LEAK_PROTECTION_IS_SELECTED_CORRECTLY);
                    if (applicant.fortifiedHome) {
                        fsa.assertEquals(this.getSelectedFortifiedHome().toLowerCase(),
                                (fireAlarm ? "gold" : "none"), FORTIFIED_HOME_IS_SELECTED_CORRECTLY);
                    }
                    fsa.assertEquals(getAvailableValues(selectTheftProtection), listTheftProtections, "Theft Protection contains expected values.");
                    fsa.assertEquals(getAvailableValues(selectFireProtection), listFireProtections, "Fire Protection contains expected values.");
                    if (!applicant.stateCode.equals(MS)) {
                        fsa.assertEquals(getAvailableValues(selectFortifiedHome), listFortifiedHome, "Fortified Home contains expected values.");
                    } else {
                        fsa.assertEquals(getAvailableValues(selectFortifiedHome), listWindstormMitigation, "Windstorm Mitigation contains expected values.");
                    }
                } else {
                    fsa.assertEquals(this.getSelectedCentralAlarm(),
                            (centralAlarm ? applicant.centralAlarm : NONE), "Central Alarm is selected correctly.");
                    fsa.assertEquals(this.getSelectedDirectAlarm(),
                            (directAlarm ? applicant.directAlarm : NONE), "Direct Alarm is selected correctly.");
                    fsa.assertEquals(this.getSelectedLocalAlarm(),
                            (localAlarm ? applicant.localAlarm : NONE), "Local Alarm is selected correctly.");
                    fsa.assertEquals(this.getSelectedAutomaticSmokeDetectors(),
                            (autoSmokeDetectors ? applicant.autoSmokeDetectors : NO), "Automatic Smoke Detectors is selected correctly.");
                    fsa.assertEquals(this.getSelectedAutomaticSprinklerSystem(),
                            (autoSprinklerSystem ? applicant.autoSprinklerSystem : NONE), "Automatic Sprinkler System is selected correctly.");
                    fsa.assertEquals(this.getSelectedWaterProtection().toLowerCase(),
                            (waterSensor ? WHOLE_HOUSE_WATER_DETECTION_AND_SHUTOFF : "none"), WATER_LEAK_PROTECTION_IS_SELECTED_CORRECTLY);
                    fsa.assertEquals(getAvailableValues(selectCentralAlarm), listCentralAlarm, "Central Alarm contains expected values.");
                    fsa.assertEquals(getAvailableValues(selectDirectAlarm), listDirectAlarm, "Direct Alarm contains expected values.");
                    fsa.assertEquals(getAvailableValues(selectLocalAlarm), listLocalAlarm, "Local Alarm contains expected values.");
                    fsa.assertEquals(getAvailableValues(selectAutoSmokeDetectors), listNoYes, "Auto Smoke Detectors contains expected values.");
                    fsa.assertEquals(getAvailableValues(selectAutoSprinklerSystem), listAutoSprinklers, "Auto Sprinkler Systems contains expected values.");
                }
                fsa.assertEquals(getAvailableValues(selectWaterProtection), listWaterSensors, "Water Protection contains expected values.");
                // check the Policy start date value
                fsa.assertEquals(this.getPolicyStartDate(), dtf.format(LocalDate.now().plusDays(1)), "Validate Policy Start Date (today+1).");
            } else if (isFlexState(applicant.stateCode)) {
                fsa.assertEquals(this.isCheckedNewlyOwnedHome(), newlyOwned, "Home Buyer is selected correctly.");
                if (!discounts.contains("farmers auto customer")) {
                    fsa.assertEquals(this.isCheckedAutoPolicy(), autoInsurance, "Auto Policy is selected correctly.");
                } else {
                    fsa.assertFalse(isElementDisplayed(By.xpath(AUTO_POLICY_XPATH)), "Auto Policy checkbox is not displayed correctly.");
                }
                fsa.assertTrue(this.getSelectedTheftProtection().toLowerCase().contains(theftAlarm ? "professionally-monitored" :
                        "no, i don't"), "Theft Protection is selected correctly.");
                fsa.assertTrue(this.getSelectedFireProtection().toLowerCase().contains(fireAlarm ? "professionally-monitored" : "no, i don't"),
                        "Fire Protection is selected correctly.");
                fsa.assertTrue(this.getSelectedWaterProtection().toLowerCase().contains(waterSensor ? "whole house water detection and shutoff" : "no, i don't"),
                        "Water Leak Protection is selected correctly.");
                fsa.assertTrue(this.getSelectedFortifiedHome().toLowerCase().contains(fireAlarm ? "fortified gold" : "no, i don't"),
                        "Fortified Home is selected correctly.");
                fsa.assertEquals(getAvailableValues(selectTheftProtection), listTheftProtectionFlex, "Theft Protection contains expected values.");
                fsa.assertEquals(getAvailableValues(selectFireProtection), listFireProtectionFlex, "Fire Protection contains expected values.");
                fsa.assertEquals(getAvailableValues(selectWaterProtection), listWaterProtectionFlex, "Water Protection contains expected values.");
                fsa.assertEquals(getAvailableValues(selectFortifiedHome), listFortifiedHomeFlex, "Fortified Home contains expected values.");
            } else {
                fsa.assertEquals(this.isCheckedCentralFireAlarm(), centralFire, "Central Fire checkbox is checked?");
                fsa.assertEquals(this.isCheckedCentralBurglarAlarm(), centralBurglar, "Central burglar checkbox is checked?");
                if (isAdtSecurityState(applicant.stateCode)) {
                    fsa.assertEquals(this.isCheckedADT(), adtSecurity, "Active Security Monitoring with ADT™ checkbox is checked?");
                }
                if (discounts.contains(FARMERS_AUTO_CUSTOMER)) {
                    fsa.assertFalse(isElementDisplayed(By.xpath(AUTO_INSURANCE_XPATH)),
                            "Discounts page - Auto Insurance checkbox should not be displayed.");
                }
                if (discounts.contains(FARMERS_LIFE_CUSTOMER)) {
                    fsa.assertFalse(isElementDisplayed(By.xpath(LIFE_INSURANCE_XPATH)),
                            "Discounts page - Life Insurance checkbox should not be displayed.");
                }
                fsa.assertFalse(this.isCheckedCommercial(), "Commercial insurance checkbox is checked?");
                if (applicant.stateCode.equals(CA)) {
                    fsa.assertEquals(this.isCheckedCEA(), ceaCoverage, "CEA Insurance checkbox is checked?");
                } else {
                    fsa.assertFalse(this.isCheckedBoatAndWatercraft(), "Recreational boat/watercraft insurance checkbox is unchecked.");
                    fsa.assertFalse(this.isCheckedOffRoad(), "Off-road Vehicle insurance checkbox is unchecked.");
                    fsa.assertFalse(this.isCheckedMotorHome(), "MotorHome, Travel Trailer or 5th Wheel insurance checkbox is unchecked.");
                }
            }
        } else {
            if (isEasternExpansionState(applicant.stateCode)) {
                if (!applicant.stateCode.equals(NC)) {
                    fsa.assertEquals(this.getSelectedTheftProtection().toLowerCase(),
                            (applicant.theftAlarm ? PROFESSIONALLY_MONITORED : "none"), THEFT_PROTECTION_IS_SELECTED_CORRECTLY);
                    fsa.assertEquals(this.getSelectedFireProtection().toLowerCase(),
                            (applicant.fireAlarm ? PROFESSIONALLY_MONITORED : "none"), FIRE_PROTECTION_IS_SELECTED_CORRECTLY);
                    fsa.assertEquals(this.getSelectedWaterProtection().toLowerCase(),
                            (applicant.waterShutoff ? WHOLE_HOUSE_WATER_DETECTION_AND_SHUTOFF : "none"), WATER_LEAK_PROTECTION_IS_SELECTED_CORRECTLY);
                    if (applicant.stateCode.contains(MS)) {
                        fsa.assertEquals(this.getSelectedFortifiedHome().toLowerCase(), (applicant.fortifiedHome ? "fortified for safer living" : "none"),
                                "Windstorm Mitigation is selected correctly.");
                    } else {
                        fsa.assertEquals(this.getSelectedFortifiedHome().toLowerCase(), (applicant.fortifiedHome ? "gold" : "none"),
                                FORTIFIED_HOME_IS_SELECTED_CORRECTLY);
                    }
                } else {
                    fsa.assertEquals(this.getSelectedCentralAlarm(),
                            (applicant.centralAlarm.isEmpty() ? NONE : applicant.centralAlarm), "Central Alarm is selected correctly.");
                    fsa.assertEquals(this.getSelectedDirectAlarm(),
                            (applicant.directAlarm.isEmpty() ? NONE : applicant.directAlarm), "Direct Alarm is selected correctly.");
                    fsa.assertEquals(this.getSelectedLocalAlarm(),
                            (applicant.localAlarm.isEmpty() ? NONE : applicant.localAlarm), "Local Alarm is selected correctly.");
                    fsa.assertEquals(this.getSelectedAutomaticSmokeDetectors(),
                            (applicant.autoSmokeDetectors.isEmpty() ? NO : applicant.autoSmokeDetectors), "Automatic Smoke Detectors is selected correctly.");
                    fsa.assertEquals(this.getSelectedAutomaticSprinklerSystem(),
                            (applicant.autoSprinklerSystem.isEmpty() ? NONE : applicant.autoSprinklerSystem), "Automatic Sprinkler System is selected correctly.");
                    fsa.assertEquals(this.getSelectedWaterProtection().toLowerCase(),
                            (applicant.waterShutoff ? WHOLE_HOUSE_WATER_DETECTION_AND_SHUTOFF : "none"), WATER_LEAK_PROTECTION_IS_SELECTED_CORRECTLY);
                }
                // check the Policy start date value
                fsa.assertEquals(this.getPolicyStartDate(), dtf.format(LocalDate.now().plusDays(1)), "Validate Policy Start Date (today+1).");
            } else if (isFlexState(applicant.stateCode)) {
                fsa.assertEquals(this.isCheckedNewlyOwnedHome(), applicant.newlyOwned, "Home Buyer is selected correctly.");
                fsa.assertEquals(this.isCheckedAutoPolicy(), applicant.autoInsurance, "Auto Policy is selected correctly.");
                fsa.assertTrue(this.getSelectedTheftProtection().toLowerCase().contains(applicant.theftAlarm ? PROFESSIONALLY_DASH_MONITORED : NO_I_DONT),
                        THEFT_PROTECTION_IS_SELECTED_CORRECTLY);
                fsa.assertTrue(this.getSelectedFireProtection().toLowerCase().contains(applicant.fireAlarm ? PROFESSIONALLY_DASH_MONITORED : NO_I_DONT),
                        FIRE_PROTECTION_IS_SELECTED_CORRECTLY);
                fsa.assertTrue(this.getSelectedWaterProtection().toLowerCase().contains(applicant.waterShutoff ? "whole house detection and shutoff" : NO_I_DONT),
                        WATER_LEAK_PROTECTION_IS_SELECTED_CORRECTLY);
                fsa.assertTrue(this.getSelectedFortifiedHome().toLowerCase().contains(applicant.fortifiedHome ? "fortified gold" : NO_I_DONT),
                        FORTIFIED_HOME_IS_SELECTED_CORRECTLY);
            } else {
                fsa.assertEquals(this.isCheckedCentralFireAlarm(), applicant.centralFireAlarm, "Central fire alarm checkbox validation");
                fsa.assertEquals(this.isCheckedCentralBurglarAlarm(), applicant.centralBurglarAlarm, "Central burglar alarm checkbox validation");
                fsa.assertEquals(this.isCheckedCommercial(), applicant.commercial, "Commercial insurance checkbox is checked?");
                if (!applicant.stateCode.equals(CT)) {
                    fsa.assertEquals(this.isCheckedLifeInsurance(), applicant.lifeInsurance, "Life Insurance checkbox validation");
                }
                fsa.assertEquals(this.isCheckedAutoInsurance(), applicant.autoInsurance, "Auto Insurance checkbox validation");
                if (applicant.stateCode.equals(CA)) {
                    fsa.assertEquals(this.isCheckedCEA(), applicant.ceaCoverage, "CEA Insurance checkbox validation");
                } else if (!isFlexState(applicant.stateCode)){
                    fsa.assertEquals(this.isCheckedBoatAndWatercraft(), applicant.boatWaterCraft, "Recreational boat/watercraft insurance checkbox is checked?");
                    fsa.assertEquals(this.isCheckedOffRoad(), applicant.offRoad, "Off-road Vehicle insurance checkbox is checked?");
                    fsa.assertEquals(this.isCheckedMotorHome(), applicant.motorHome, "Motorhome, Travel Trailer or 5th Wheel insurance checkbox is checked?");
                }
                if (isAdtSecurityState(applicant.stateCode)) {
                    fsa.assertEquals(this.isCheckedADT(), applicant.adtSecurity, "Active Security Monitoring with ADT™ checkbox validation");
                }
            }
        }
    }

    public void validatePageErrors(ApplicantHQM applicant, FarmersSoftAssert fsa) throws Exception {
        if (isEasternExpansionState(applicant.stateCode)) {
            String invalidPSD2 = "20/20/2020";

            String policyStartDate = getPolicyStartDate();
            fsa.assertEquals(policyStartDate, LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern(MM_DD_YYYY)),
                    "Discounts page - Policy start date is today+1.");

            setPolicyStartDate(LocalDate.now().plusDays(61).format(DateTimeFormatter.ofPattern(MM_DD_YYYY)));
            sendKeysToElement(inputPolicyStartDate, Keys.TAB);
            List<String> pageErrors = this.getPageErrors();
            Log.info(FOUND_PAGE_ERRORS + pageErrors);
            List<String> expectedErrors1 = new ArrayList<>(Collections.singletonList(POLICY_START_DATE_ERROR));
            fsa.assertEquals(pageErrors, expectedErrors1, "Discounts page - Found Policy Start Date > 60 days expected error.");
            fsa.assertTrue(isButtonNextDisabled(), DISCOUNTS_PAGE_BUTTON_NEXT_DISABLED);

            setPolicyStartDate(LocalDate.now().minusDays(1).format(DateTimeFormatter.ofPattern(MM_DD_YYYY)));
            sendKeysToElement(inputPolicyStartDate, Keys.TAB);
            pageErrors = this.getPageErrors();
            Log.info(FOUND_PAGE_ERRORS + pageErrors);
            List<String> expectedErrors2 = new ArrayList<>(Collections.singletonList(POLICY_START_DATE_ERROR2));
            fsa.assertEquals(pageErrors, expectedErrors2, "Discounts page - Found Policy Start Date cannot me less than todays date expected error.");
            fsa.assertTrue(isButtonNextDisabled(), DISCOUNTS_PAGE_BUTTON_NEXT_DISABLED);

            setPolicyStartDate(invalidPSD2);
            sendKeysToElement(inputPolicyStartDate, Keys.TAB);
            pageErrors = this.getPageErrors();
            Log.info(FOUND_PAGE_ERRORS + pageErrors);
            List<String> expectedErrors3 = new ArrayList<>(Collections.singletonList(POLICY_START_DATE_ERROR3));
            fsa.assertEquals(pageErrors, expectedErrors3, "Discounts page - Found Policy Start Date invalid date expected error.");
            fsa.assertTrue(isButtonNextDisabled(), DISCOUNTS_PAGE_BUTTON_NEXT_DISABLED);

            setPolicyStartDate(policyStartDate);
            sendKeysToElement(inputPolicyStartDate, Keys.TAB);
            fsa.assertFalse(isButtonNextDisabled(), "Discounts page - button Next is NOT disabled now.");
        }
    }

    public List<String> getDiscounts() throws Exception {
        List<String> listPageDiscounts = driver().findElements(textPreappliedDiscounts)
                .stream().map(this::getTextFromElement).collect(Collectors.toList());
        Log.info("Found Discount page Preapplied discounts:" + listPageDiscounts);
        return listPageDiscounts;
    }

    public List<String> getDiscountsLowerCase() throws Exception {
        List<String> listPageDiscounts = driver().findElements(textPreappliedDiscounts)
                .stream().map(this::getTextFromElement).map(String::toLowerCase).collect(Collectors.toList());
        Log.info("Found Discount page Preapplied discounts (converted to lower case):" + listPageDiscounts);
        return listPageDiscounts;
    }

    public void validatePreappliedDiscountsBeforeRate(ApplicantHQM applicant, List<String> discounts, FarmersSoftAssert fsa) throws Exception {
        List<String> listPageDiscounts = this.getDiscountsLowerCase();
        Log.info("Found Discounts page Preapplied discounts:" + listPageDiscounts);
        List<String> preDiscounts = new ArrayList<>();
        if (!discounts.isEmpty()) {
            preDiscounts.addAll(discounts);
            if (isFlexState(applicant.stateCode)) {
                preDiscounts.set(preDiscounts.indexOf(PREFERRED_PAYMENT), PREFERRED_PAYMENT_PLAN);
            }
        } else {   // work-around in case Postgres connection does not work
            preDiscounts.addAll(preappliedDiscounts);
            if (applicant.occupation.isEmpty() || applicant.occupation.equalsIgnoreCase("other")
                    || isEasternExpansionState(applicant.stateCode) || applicant.stateCode.equals(MN)) {
                preDiscounts.remove(AFFINITY_OCCUPATION);
            }
            Year currentYear = Year.now();
            if ((currentYear.minusYears(applicant.yearBuilt).getValue() > 13) ||
                    (applicant.stateCode.equals(MN))) {
                preDiscounts.remove(NEW_HOME);
            }
            if (isEasternExpansionState(applicant.stateCode)) {
                if (!applicant.stateCode.equals(NC)) {
                    if (!this.getSelectedFireProtection().equals(NONE)) {
                        preDiscounts.add("professionally-monitored fire alarm");
                    }
                    if (!this.getSelectedTheftProtection().equals(NONE)) {
                        preDiscounts.add("professionally-monitored theft alarm");
                    }
                    if (!this.getSelectedWaterProtection().equals(NONE)) {
                        preDiscounts.add("water sensor / shutoff valve");
                    }
                    if (!this.getSelectedFortifiedHome().equals(NONE)) {
                        preDiscounts.add("fortified Home");
                    }
                } else {
                    if (this.getSelectedAutomaticSmokeDetectors().equals(YES) ||
                            !this.getSelectedCentralAlarm().equals(NONE) ||
                            !this.getSelectedDirectAlarm().equals(NONE) ||
                            !this.getSelectedLocalAlarm().equals(NONE)) {
                        preDiscounts.add("protective device");
                    }
                }
                preDiscounts.remove(PAPERLESS);
            } else if (isFlexState(applicant.stateCode)) {
                if (this.isCheckedNewlyOwnedHome()) {
                    preDiscounts.add(HOME_BUYER);
                }
                if (this.isCheckedAutoPolicy()) {
                    preDiscounts.add("auto policy");
                }
                preDiscounts.remove(GOOD_PAYER);
                if (!applicant.stateCode.equals(CA)) {
                    preDiscounts.remove(PREFERRED_PAYMENT_PLAN);
                }
            } else {
                if (this.isCheckedCentralFireAlarm()) {
                    preDiscounts.add(CENTRAL_FIRE_ALARM);
                }
                if (this.isCheckedCentralBurglarAlarm()) {
                    preDiscounts.add(CENTRAL_BURGLAR_ALARM);
                }
                if (applicant.stateCode.equals(CA)) {
                    if (this.isCheckedCEA()) {
                        preDiscounts.add(HOME_CEA);
                    }
                    preDiscounts.remove(GOOD_PAYER);
                    preDiscounts.remove(PAPERLESS);
                } else {
                    if (isAdtSecurityState(applicant.stateCode) && applicant.adtSecurity) {
                    	discounts.add(HOME_PROTECTION_AND_LOSS_PREVENTION);
                    }
                }
            }
        }
        listPageDiscounts = listPageDiscounts.stream().map(String::toLowerCase)
                .sorted(Comparator.naturalOrder()).collect(Collectors.toList());
        preDiscounts = preDiscounts.stream().map(String::toLowerCase)
                .sorted(Comparator.naturalOrder()).collect(Collectors.toList());
        fsa.assertEquals(listPageDiscounts, preDiscounts, "Validate Discounts page - Preapplied discounts before rate.");
        this.validateAutoLifeCustomer(listPageDiscounts, applicant.stateCode, fsa);

    }

    private void validateAutoLifeCustomer(List<String> pageDiscounts, String stateCode, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(!isElementDisplayed(By.xpath(AUTO_INSURANCE_XPATH)), pageDiscounts.contains(FARMERS_AUTO_CUSTOMER),
                "Discount page - No Auto Insurance checkbox displayed for Farmers Auto customer");
        if (!Arrays.asList(CT, KY, MS, MA, LA, NC).contains(stateCode) && !isFlexState(stateCode)) {
            fsa.assertEquals(!isElementDisplayed(By.xpath(LIFE_INSURANCE_XPATH)), pageDiscounts.contains(FARMERS_LIFE_CUSTOMER),
                    "Discount page - No Life Insurance checkbox displayed for Farmers Life customer");
        }
    }

    public void validatePreappliedDiscountsAfterRate(ApplicantHQM applicant, QuoteRateHQM quoteRate) throws Exception {
        List<String> listPageDiscounts = this.getDiscountsLowerCase();
        Log.info("Found on Discounts page Preapplied discounts after rate:" + listPageDiscounts);
        List<String> discounts = new ArrayList<>(preappliedDiscounts);
        Year currentYear = Year.now();
        if ((currentYear.minusYears(applicant.yearBuilt).getValue() > 13) ||
                (applicant.stateCode.equals(MN)) || isFlexState(applicant.stateCode)){
            discounts.remove(NEW_HOME);
        }
        if (quoteRate == null) {
            if (applicant.occupation.equalsIgnoreCase("other") || applicant.occupation.isEmpty()
                    || isEasternExpansionState(applicant.stateCode) || applicant.stateCode.equals(MN)) {
                discounts.remove(AFFINITY_OCCUPATION);
            }
        } else {
            if (!quoteRate.getAppliedDiscounts().contains(AFFINITY_OCCUPATION)) {
                discounts.remove(AFFINITY_OCCUPATION);
            }
            if (applicant.stateCode.equals(AZ) && quoteRate.getAppliedDiscounts().contains("retirement community")) {
                discounts.add("retirement community");
            }
        }
        if (isEasternExpansionState(applicant.stateCode)) {
            if (applicant.waterShutoff) {
                discounts.add("water protection");
            }
            if (!applicant.stateCode.equals(NC)) {
                if (applicant.fireAlarm) {
                    discounts.add("fire protection");
                }
                if (applicant.theftAlarm) {
                    discounts.add("theft protection");
                }
                if (applicant.fortifiedHome) {
                    if (Arrays.asList(KY, MA, LA).contains(applicant.stateCode)) {
                        discounts.add("fortified home");
                    } else if (applicant.stateCode.equals(MS)) {
                        discounts.add("windstorm mitigation");
                    }
                }
            } else {
                if (this.getSelectedAutomaticSmokeDetectors().equals(YES) ||
                        !this.getSelectedCentralAlarm().equals(NONE) ||
                        !this.getSelectedDirectAlarm().equals(NONE) ||
                        !this.getSelectedLocalAlarm().equals(NONE)) {
                    discounts.add("protective device");
                }
            }
        } else if (isFlexState(applicant.stateCode)) {
            if (!applicant.stateCode.equals(CA)) {
                discounts.add("welcome");
            }
            if (applicant.newlyOwned) {
                discounts.add(HOME_BUYER);
            }
            if (applicant.theftAlarm) {
                discounts.add("theft protection");
            }
            if (applicant.fireAlarm) {
                discounts.add("fire protection");
            }
            if (applicant.waterShutoff) {
                discounts.add("water protection");
            }
            if (applicant.fortifiedHome) {
                discounts.add("fortified home");
            }
        } else {
            if (applicant.centralFireAlarm) {
                discounts.add(CENTRAL_FIRE_ALARM);
            }
            if (applicant.centralBurglarAlarm) {
                discounts.add(CENTRAL_BURGLAR_ALARM);
            }
            if (applicant.commercial) {
                discounts.add("farmers commercial customer");
            }
            if (applicant.umbrellaInsurance) {
                discounts.add("farmers umbrella customer");
            }
        }
        if (applicant.lifeInsurance) {
            discounts.add(FARMERS_LIFE_CUSTOMER);
        }
        if (applicant.autoInsurance) {
            discounts.add(FARMERS_AUTO_CUSTOMER);
        }
        if (applicant.stateCode.equals(CA)) {
            if (applicant.ceaCoverage) {
                discounts.add(HOME_CEA);
            }
            if (applicant.adtSecurity) {
                discounts.add(HOME_PROTECTION_AND_LOSS_PREVENTION);
            }
            discounts.remove(PAPERLESS);
            discounts.set(discounts.indexOf(PREFERRED_PAYMENT), PREFERRED_PAYMENT_PLAN);
        } else if (isFlexState(applicant.stateCode)) {
            discounts.set(discounts.indexOf(PREFERRED_PAYMENT), PREFERRED_PAYMENT_PLAN);
        } else {
            if (isAdtSecurityState(applicant.stateCode) && applicant.adtSecurity) {
            	discounts.add(HOME_PROTECTION_AND_LOSS_PREVENTION);
            }
            if (applicant.boatWaterCraft) {
                discounts.add("recreational boat/watercraft insurance");
            }
            if (applicant.offRoad) {
                discounts.add("off-road vehicle insurance");
            }
            if (applicant.motorHome) {
                discounts.add("motorhome, travel trailer or 5th wheel insurance");
            }
        }
        if (isEasternExpansionState(applicant.stateCode) || isFlexState(applicant.stateCode)) {
            discounts.remove(PAPERLESS);
        }
        if (!applicant.stateCode.equals(OK)) {  //DE46700 - Specific rules in OK state for Claim Free discount
            discounts.add("claim free");
        }
        if (isEarlyShoppingFactorState(applicant.stateCode) && !StringUtils.isBlank(applicant.earlyShoppingFactor)) {
            discounts.add("early shopping");
        }
        listPageDiscounts = listPageDiscounts.stream().map(String::toLowerCase)
                .sorted(Comparator.naturalOrder()).collect(Collectors.toList());
        discounts = discounts.stream().map(String::toLowerCase)
                .sorted(Comparator.naturalOrder()).collect(Collectors.toList());
        Log.info("Pre-applied discounts Displayed: " + listPageDiscounts);
        Log.info("Pre-applied discounts Expected: " + discounts);
        Assert.assertEquals(listPageDiscounts, discounts, "Validate Discounts page - Preapplied discounts after rate.");
    }

    public void validatePageTitles(boolean bDiscounts, FarmersSoftAssert fsa, @Nullable StaticContentHQM staticContent) {
        fsa.assertEquals(getTextFromElement(textPageTitle1), DISCOUNTS_PAGE_TITLE, "Discounts page - page Title h1");
        if (bDiscounts) {
            fsa.assertEquals(getTextFromElement(textPageTitle2), DISCOUNTS_PAGE_TITLE2, "Discounts page - page Title h2");
        }
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getDiscountsTitle(), DISCOUNTS_PAGE_TITLE, "Discounts page - page Title h1 (AEM).");
        }
    }

    public void validatePageSubtitles(ApplicantHQM applicant, boolean bDiscounts, @Nullable StaticContentHQM staticContent) throws Exception {
        List<String> listPageSubtitles = driver().findElements(By.xpath(XPATH_PAGE_SUBTITLE_TEXT1 + " | " + XPATH_PAGE_SUBTITLE_TEXT2))
                .stream().map(this::getTextFromElement).filter(el -> !el.isEmpty()).collect(Collectors.toList());
        Log.info("Found Discounts page subtitles:" + listPageSubtitles);
        List<String> pageSubtitles = new ArrayList<>(subtitlesDiscountsPage);
        if (!bDiscounts) {
            pageSubtitles.remove(2);
        }
        if (applicant.stateCode.equals(CA)) {
            pageSubtitles.remove(1);
            pageSubtitles.add(1, SUBTITLE_CA);
        }
        if (isEasternExpansionState(applicant.stateCode)) {
            if (!isElementDisplayed(By.xpath(THEFT_ALARM_XPATH))) {
                pageSubtitles.add(2, SUBTITLE_KY);
            }
            pageSubtitles.remove("You may be asked to provide information to verify eligibility. Other discounts may be " +
                    "available through a Farmers agent.");
            pageSubtitles.add("You may be asked to provide information to verify eligibility. Other discounts may be " +
                    "available through a Farmers representative.");
        }
        if (isFlexState(applicant.stateCode)) {
            pageSubtitles.add(0, "Are you buying a new home or have owned your home for less than a year?\ninfo");
        }
        Assert.assertEquals(listPageSubtitles, pageSubtitles, "Validate Discounts page subtitles.");
        if (staticContent != null) {
            String caption = isFlexState(applicant.stateCode) ? pageSubtitles.get(1) : pageSubtitles.get(0);
            Assert.assertEquals(staticContent.getDiscountsCaption(), caption, "Validate Discounts page subtitles (AEM).");
        }
    }

    public void validateHelpDialogs(ApplicantHQM applicant, boolean bDiscounts, FarmersSoftAssert fsa, @Nullable StaticContentHQM staticContent) throws Exception {
        if (isEasternExpansionState(applicant.stateCode)) {
            if (!applicant.stateCode.equals(NC)) {
                checkHelpDialog(helpTheftAlarmSelect, THEFT_SELECT_HELP_TITLE, THEFT_SELECT_HELP_TEXT, fsa);
                checkHelpDialog(helpFireAlarmSelect, FIRE_SELECT_HELP_TITLE, FIRE_SELECT_HELP_TEXT, fsa);
                if (applicant.stateCode.equals(MS)) {
                    checkHelpDialog(helpWindstormMitigationSelect, WINDSTORM_MITIGATION_SELECT_HELP_TITLE, WINDSTORM_MITIGATION_SELECT_HELP_TEXT, fsa);
                } else {
                    checkHelpDialog(helpFortifiedHomeSelect, FORTIFIED_HOME_SELECT_HELP_TITLE, FORTIFIED_HOME_SELECT_HELP_TEXT, fsa);
                }
            } else {
                checkHelpDialog(helpCentralAlarmSelect, CENTRAL_ALARM_SELECT_HELP_TITLE, CENTRAL_ALARM_SELECT_HELP_TEXT, fsa);
                checkHelpDialog(helpDirectAlarmSelect, DIRECT_ALARM_SELECT_HELP_TITLE, DIRECT_ALARM_SELECT_HELP_TEXT, fsa);
                checkHelpDialog(helpLocalAlarmSelect, LOCAL_ALARM_SELECT_HELP_TITLE, LOCAL_ALARM_SELECT_HELP_TEXT, fsa);
            }
            checkHelpDialog(helpWaterSensorSelect, WATER_SENSOR_SELECT_HELP_TITLE, WATER_SENSOR_SELECT_HELP_TEXT, fsa);
        }
        //
        waitAndClickElement(helpSubtitle);
        Thread.sleep(500);  // waitElementBeVisibleClickable is unreliable
        Assert.assertEquals(getTextFromElement(helpDialogContent), DISCOUNTS_HELP_TEXT, "Subtitle Help Dialog Content validated.");
        if (staticContent != null) {
            Assert.assertEquals(staticContent.getDiscountsInfoContentFIP(), DISCOUNTS_HELP_TEXT, "Subtitle Help Dialog Content validated (AEM).");
        }
        waitAndClickElement(buttonCloseDialog);
        //
        if (bDiscounts) {
            waitAndClickElement(helpPreappliedTitle);
            sleep(1);
            waitElementBeVisibleClickable(buttonCloseDialog);
            if (staticContent != null) {
                Assert.assertEquals(staticContent.getDiscountsInfoContentPD(), DISCOUNTS_HELP_TEXT2, "Preapplied discounts Help Dialog Content validated (AEM).");
            }
            waitAndClickElement(buttonCloseDialog);
        }
    }

    public void validateSubtitlesDiscountJourney(@Nullable List<String> discounts, String stateCode, FarmersSoftAssert fsa) throws Exception {
        List<String> discountsAvailable;
        if (discounts == null) {
            discountsAvailable = this.getDiscounts();
        } else {
            discountsAvailable = new ArrayList<>(discounts);
        }
        int discountCount = discountsAvailable.size();
        String textDiscount = discountCount > 0? discountCount + " p" : "P";
        fsa.assertEquals(getTextFromElement(discountSubTitlePiggy), textDiscount + DISCOUNT_PIGGY_TEXT,
                "Discounts page - Discount Journey Subtitle Lock image.");
        if (discountCount > 0) {
            waitAndClickElement(discountHelpButtonPiggy);
            waitElementBeVisible(discountHelpDialogTitle);
            fsa.assertEquals(getTextFromElement(discountHelpDialogTitle), DISCOUNT_HELP_DIALOG_TITLE.replace("($)", "(" + discountCount + ")"),
                    "Discounts page - Discount Journey Help Dialog Title.");
            List<String> listDiscounts = driver().findElements(By.xpath(DISCOUNT_HELP_DIALOG_CONTENT_XPATH)).stream()
                    .map(this::getTextFromElement).sorted(Comparator.naturalOrder()).collect(Collectors.toList());
            discountsAvailable.sort(Comparator.naturalOrder());
            fsa.assertEquals(listDiscounts, discountsAvailable, "Discounts page - Discount Journey Help Dialog Content.");
            waitAndClickElement(buttonCloseDialog);
        }

        // Verification of Safety features checkmark and text and Other Insurance checkmark and text
        List<Boolean> safetyFeatures;
        if (isEasternExpansionState(stateCode)) {
            List<WebElement> listSafetyFeatures = driver().findElements(By.xpath(SAFETY_FEATURES_SELECT_XPATH));
            safetyFeatures = listSafetyFeatures.stream().map(this::getTextFromElement).map(va -> (!va.equals(NONE) && !va.equals(NO)))
                    .filter(pa -> pa).collect(Collectors.toList());
        } else {
            List<WebElement> listSafetyFeatures = driver().findElements(By.xpath(SAFETY_FEATURES_CHECKBOXES_XPATH));
            safetyFeatures = listSafetyFeatures.stream().map(WebElement::isSelected).filter(pa -> pa).collect(Collectors.toList());
        }
        if (safetyFeatures.size() == 1) {
            fsa.assertEquals(getTextFromElement(safetyFeaturesCheck), SAFETY_FEATURES_CHECK_TEXT,
                    "Discounts page - Discount Journey, Safety Features Check1.");
        } else if (safetyFeatures.size() > 1) {
            fsa.assertEquals(getTextFromElement(safetyFeaturesCheck), SAFETY_FEATURES_CHECK_TEXT2,
                    "Discounts page - Discount Journey, Safety Features Check2.");
        }
        List<WebElement> listInsuranceProducts = driver().findElements(By.xpath(INSURANCE_PRODUCTS_CHECKBOXES_XPATH));
        List<Boolean> insuranceProducts = listInsuranceProducts.stream().map(WebElement::isSelected)
                .filter(pa -> pa).collect(Collectors.toList());
        if (!insuranceProducts.isEmpty() && !stateCode.equals(CA)) {
            fsa.assertEquals(getTextFromElement(discountsCheck), DISCOUNT_CHECK_TEXT,
                    "Discounts page - Discount Journey, Insurance Products Check1.");
        }
    }

    private void checkHelpDialog(WebElement helpIcon, String helpTitle, String helpContent, FarmersSoftAssert fsa) throws InterruptedException {
        waitAndClickElement(helpIcon);
        Thread.sleep(500);  // waitElementBeVisible is unreliable
        fsa.assertEquals(getTextFromElement(helpDialogTitle), helpTitle, helpTitle + " - Help Dialog Title validated.");
        waitElementBeVisible(helpDialogContent);
        fsa.assertEquals(getTextFromElement(helpDialogContent), helpContent,  helpTitle + " - Help Dialog Content validated.");
        waitAndClickElement(buttonCloseDialog);
    }

    public void verifyPageFieldsNotReadonly() throws Exception {
        List<WebElement> checkboxList = driver().findElements(
                By.xpath("//input[contains(@class,'mat-checkbox-input') and (@disabled or @readonly)]"));
        Assert.assertTrue(checkboxList.isEmpty(), "Discounts page - No disabled or read-only checkboxes");
        List<WebElement> listBoxList = driver().findElements(By.xpath("//mat-select[@disabled or @readonly]"));
        Assert.assertTrue(listBoxList.isEmpty(), "Discounts page - No disabled or read-only listBoxes");
    }

    public void selectSafetyFeature(WebElement featureWE, String featureName, String featureType) throws Exception {
        String protection = getTextFromElement(featureWE);
        Log.info(featureName + " type selected: " + protection + ";  Selecting now: " + featureType);
        if (StringUtils.isEmpty(featureType) || protection.equals(featureType)) {
            return;
        }
        waitAndClickElement(featureWE);
        Thread.sleep(500);
        WebElement optionWe = driver().findElement(By.xpath(String.format(SELECT_OPTIONS_XPATH, featureType)));
        waitAndClickElement(optionWe);
    }

    public void selectSafetyFeatureFirst(WebElement featureWE, String featureName) throws Exception {
    	String featureString = getTextFromElement(featureWE);
        if (featureString.equals(NONE) || featureString.startsWith("No, I don't")) {
            Log.info("Feature: " + featureName + " First Option: " + featureString + " was already selected.");
            return;
        }
        waitAndClickElement(featureWE);
        Thread.sleep(500);
        List<WebElement> listOptionsWe = driver().findElements(selectListOptionsBy);
        waitAndClickElement(listOptionsWe.get(0));
        Log.info("Feature " + featureName + " Selected First: " + featureString);
    }

    public void selectSafetyFeatureLast(WebElement featureWE, String featureName) throws Exception {
        waitAndClickElement(featureWE);
        Thread.sleep(500);
        List<WebElement> listOptionsWe = driver().findElements(selectListOptionsBy);
        waitAndClickElement(listOptionsWe.get(listOptionsWe.size()-1));
        Log.info("Feature " + featureName + " Selected Last: " + getTextFromElement(featureWE));
    }

    public void selectSafetyFeatureValue(WebElement featureWE, String featureName, String featureValue) throws Exception {
        waitAndClickElement(featureWE);
        Thread.sleep(500);
        List<WebElement> listOptionsWe = driver().findElements(selectListOptionsBy);
        for (WebElement weOption: listOptionsWe) {
            if (getTextFromElement(weOption).equals(featureValue)) {
                waitAndClickElement(weOption);
                break;
            }
        }
        Log.info("Feature " + featureName + " Selected Value: " + getTextFromElement(featureWE));
    }

    public void selectTheftProtection(String theftProtectionType) throws Exception {
        if (theftProtectionType.equalsIgnoreCase(LOWERCASE_TRUE)) {
            selectSafetyFeatureLast(selectTheftProtection, THEFT_SELECT_HELP_TITLE);
        } else {
            selectSafetyFeatureFirst(selectTheftProtection, THEFT_SELECT_HELP_TITLE);
        }
    }

    public String getSelectedTheftProtection() {
        return getTextFromElement(selectTheftProtection);
    }

    public void selectFireProtection(String fireProtectionType) throws Exception {
        if (fireProtectionType.equalsIgnoreCase(LOWERCASE_TRUE)) {
            selectSafetyFeatureLast(selectFireProtection, FIRE_SELECT_HELP_TITLE);
        } else {
            selectSafetyFeatureFirst(selectFireProtection, FIRE_SELECT_HELP_TITLE);
        }
    }

    public String getSelectedFireProtection() {
        return getTextFromElement(selectFireProtection);
    }

    public String getSelectedWaterProtection() {
        return getTextFromElement(selectWaterProtection);
    }

    public void selectWaterProtection(String waterProtectionType) throws Exception {
        if (waterProtectionType.equalsIgnoreCase(LOWERCASE_TRUE)) {
            selectSafetyFeatureLast(selectWaterProtection, "Water Protection");
        } else {
            selectSafetyFeatureFirst(selectWaterProtection, "Water Protection");
        }
    }

    public String getSelectedCentralAlarm() {
        return getTextFromElement(selectCentralAlarm);
    }

    public void selectCentralAlarm(String centralAlarm) throws Exception {
        selectSafetyFeature (selectCentralAlarm, CENTRAL_ALARM_SELECT_HELP_TITLE, centralAlarm);
    }

    public String getSelectedDirectAlarm() {
        return getTextFromElement(selectDirectAlarm);
    }

    public void selectDirectAlarm(String directAlarm) throws Exception {
        selectSafetyFeature (selectDirectAlarm, DIRECT_ALARM_SELECT_HELP_TITLE, directAlarm);
    }

    public String getSelectedLocalAlarm() {
        return getTextFromElement(selectLocalAlarm);
    }

    public void selectLocalAlarm(String localAlarm) throws Exception {
        selectSafetyFeature (selectLocalAlarm, LOCAL_ALARM_SELECT_HELP_TITLE, localAlarm);
    }

    public String getSelectedAutomaticSmokeDetectors() {
        return getTextFromElement(selectAutoSmokeDetectors);
    }

    public void selectAutomaticSmokeDetectors(String autoSmokeDetectors) throws Exception {
        selectSafetyFeature (selectAutoSmokeDetectors, "Automatic Smoke Detectors", autoSmokeDetectors);
    }

    public String getSelectedAutomaticSprinklerSystem() {
        return getTextFromElement(selectAutoSprinklerSystem);
    }

    public void selectAutomaticSprinklerSystem(String autoSprinklerSystem) throws Exception {
        selectSafetyFeature (selectAutoSprinklerSystem, "Automatic Sprinkler System", autoSprinklerSystem);
    }

    public void selectFortifiedHome(String fortifiedHomeType) throws Exception {
        if (fortifiedHomeType.equalsIgnoreCase(LOWERCASE_TRUE)) {
            selectSafetyFeatureLast(selectFortifiedHome, "FORTIFIED Home");
        } else {
            selectSafetyFeatureFirst(selectFortifiedHome, "FORTIFIED Home");
        }
    }

    public String getSelectedFortifiedHome() {
        return getTextFromElement(selectFortifiedHome);
    }

    public List<String> getAvailableValues(WebElement selectOption) throws Exception {
        waitAndClickElement(selectOption);
        Thread.sleep(500);
        List<String> listOptions = driver().findElements(selectListOptionsBy).stream()
                .map(this::getTextFromElement).filter(s -> !s.isBlank()).collect(Collectors.toList());
        selectOption.sendKeys(Keys.ESCAPE);
        System.out.println(">> Available Options: " + listOptions);
        return listOptions;
    }

    public void setPolicyStartDate(String policyStartDate) {
        waitAndClickElement(inputPolicyStartDate);
        sendKeysToElement(inputPolicyStartDate, policyStartDate);
    }

    public String getPolicyStartDate() {
        return getAttributeData(inputPolicyStartDate, VALUE);
    }

    public String getPolicyStartDateLabel() {
        return getTextFromElement(labelPolicyStartDate);
    }
}