package com.farmers.ffq.auto.pages;

import com.farmers.ffq.utils.FarmersSoftAssert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AutoRentersBundleOfferingPage extends AutoBasePage {

    @FindBy(xpath = "//app-auto-renters-bundle-offering//h1")
    private WebElement autoRentersBundleOfferingPageTitle;
    @FindBy(css = "div[class='title-description']")
    private WebElement autoRentersBundleOfferingPageDescription;

    // Auto Renters Bundle Card Elements
    @FindBy(xpath = "//mat-card[contains(.,'Add renters')]//img[contains(@class,'rebrand-card-bundle-icon')]")
    private WebElement autoRentersBundleCarAndCouchIcon;
    @FindBy(xpath = "//mat-card[contains(.,'Add renters')]//p[contains(@class,'tui-input-text tui-input-text-mobile')]")
    private WebElement autoRentersBundleCardDescription;
    @FindBy(xpath = "//mat-card[contains(.,'Add renters')]//p[contains(@class,'tui-h3 semi-bold')]")
    private WebElement autoRentersBundleCard6MonthTermText;
    @FindBy(xpath = "//mat-card[contains(.,'Add renters')]//div[contains(@class,'pricing')]")
    private WebElement autoRentersBundleCardPremium;
    @FindBy(xpath = "//mat-card[contains(.,'Add renters')]//p[contains(@class,'comparison-text tui-input-text')]")
    private WebElement autoRentersBundleCardComparisonText;
    @FindBy(xpath = "//button[contains(.,'Add renters discount')]")
    private WebElement addRentersDiscountButton;

    // Continue With Auto Only Card Elements
    @FindBy(xpath = "//img[contains(@class,'rebrand-card-icon')]")
    private WebElement onlyAutoCardCarIcon;
    @FindBy(xpath = "//mat-card[contains(.,'Continue with auto')]//p[@class='tui-input-text']")
    private WebElement justAutoText;
    @FindBy(xpath = "//mat-card[contains(.,'Continue with auto')]//div[@class='pricing']")
    private WebElement autoMonolinePremiumAmount;
    @FindBy(xpath = "//mat-card[contains(.,'Continue with auto')]//p[@class='estimated-text']")
    private WebElement estimatedText;
    @FindBy(xpath = "//button[contains(.,'Continue with auto')]")
    private WebElement continueWithAutoOnlyButton;


    // Continue With Discount Popup Modal elements
    @FindBy(id = "rentersDiscountDialog")
    private WebElement rentersDiscountDialog;
    @FindBy(xpath = "//mat-dialog-container[@id='rentersDiscountDialog']//h1")
    private WebElement rentersDiscountDialogHeader;
    @FindBy(xpath = "//mat-dialog-container[@id='rentersDiscountDialog']//mat-dialog-content")
    private WebElement rentersDiscountDialogContent;
    @FindBy(xpath = "//mat-dialog-container[@id='rentersDiscountDialog']//button")
    private WebElement yesContinueButton;
    @FindBy(xpath = "//mat-dialog-container[@id='rentersDiscountDialog']//a")
    private WebElement noRemoveDiscountLink;


    // Dont want renters discount popup modal elements
    @FindBy(id = "autoDiscountDialog")
    private WebElement noRentersDiscountDialog;
    @FindBy(xpath = "//mat-dialog-container[@id='autoDiscountDialog']//h1")
    private WebElement noRentersDiscountDialogHeader;
    @FindBy(xpath = "//mat-dialog-container[@id='autoDiscountDialog']//mat-dialog-content")
    private WebElement noRentersDiscountDialogContent;
    @FindBy(xpath = "//mat-dialog-container[@id='autoDiscountDialog']//button")
    private WebElement letsAddDiscountButton;
    @FindBy(xpath = "//mat-dialog-container[@id='autoDiscountDialog']//a")
    private WebElement continueWithoutDiscountButton;


    /**
     * Constructor.
     *
     * @throws Exception
     */
    public AutoRentersBundleOfferingPage() throws Exception {
    }

    public boolean isOnAutoRentersBundleOfferingPage() throws Exception {
        return isElementVisible(autoRentersBundleOfferingPageTitle, 25);
    }

    public boolean quickIsOnAutoRentersBundleOfferingPage() throws Exception {
        return isElementVisible(autoRentersBundleOfferingPageTitle, 5);
    }

    public void clickAddRentersDiscount() throws Exception {
        clickElement(addRentersDiscountButton);
        if (isElementVisible(yesContinueButton, 1)) {
            clickElement(yesContinueButton);
            waitForSpinnerToBeGone();
        }
    }

    /**
     * Click the "No, remove discount" link in the renters discount dialog to continue without renters discount. This method should only be called after the renters discount dialog is displayed.
     * This will take the user to monoline quote page
     *
     * @throws Exception
     */
    public void clickNoRemoveDiscountLink() throws Exception {
        clickElement(noRemoveDiscountLink);
    }

    public void clickContinueWithAutoOnly() throws Exception {
        clickElement(continueWithAutoOnlyButton);
        if (isElementVisible(continueWithoutDiscountButton, 1)) {
            clickContinueWithoutDiscountButton();
        }
    }

    public void clickContinueWithoutDiscountButton() throws Exception {
        clickElement(continueWithoutDiscountButton);
    }

    public void processRentersBundleOfferingPage(boolean addRentersBundle) throws Exception {
        if (addRentersBundle) {
            clickAddRentersDiscount();
        } else {
            clickContinueWithAutoOnly();
        }
    }

    public void validatePageContent(FarmersSoftAssert fsa) throws Exception {
        // Validate page title and subtitle
        fsa.assertEquals(getTextFromElement(autoRentersBundleOfferingPageTitle), "Want a renters discount?", "Auto Renters Bundle Offering page title mismatch");
        fsa.assertEquals(getTextFromElement(autoRentersBundleOfferingPageDescription), "When you bundle auto and renters insurance with Farmers®, the discount could make your renters insurance really affordable! Check pricing below.", "Auto Renters Bundle Offering page description mismatch");

        // validate the content of the auto renters bundle card
        fsa.assertTrue(isElementVisible(autoRentersBundleCarAndCouchIcon, 1), "Car and couch icon is visible in auto renters bundle card");
        fsa.assertEquals(getTextFromElement(autoRentersBundleCardDescription), "Get auto and renters for almost the same price as auto alone.", "Auto renters bundle card description mismatch");
        fsa.assertEquals(getTextFromElement(autoRentersBundleCard6MonthTermText), "6-month Auto & Renters", "Auto renters bundle card 6 month term text mismatch");
        fsa.assertTrue(getTextFromElement(autoRentersBundleCardPremium).startsWith("$"), "Auto renters bundle card premium should start with $");
        fsa.assertTrue(isElementVisible(autoRentersBundleCardPremium, 1), "Premium amount is visible in auto renters bundle card");
        fsa.assertTrue(isElementVisible(autoRentersBundleCardComparisonText, 1), "Comparison text is visible in auto renters bundle card");
        fsa.assertEquals(getTextFromElement(addRentersDiscountButton), "Add renters discount", "Add renters discount button text mismatch");


        // validate the pop up content when user click add renters discount button
        clickElement(addRentersDiscountButton);
        fsa.assertTrue(isElementVisible(rentersDiscountDialog, 5), "Renters discount dialog should be visible after clicking add renters discount button");
        fsa.assertEquals(getTextFromElement(rentersDiscountDialogHeader), "Continue with renters discount?", "Renters discount dialog header text mismatch");
        fsa.assertEquals(getTextFromElement(rentersDiscountDialogContent), isSafariBrowser() ? "You can save when bundling with Farmers.Please note: You'll need to purchase both an auto policy and renters policy to get the bundle discount." : "You can save when bundling with Farmers. Please note: You'll need to purchase both an auto policy and renters policy to get the bundle discount.", "Renters discount dialog content text mismatch");
        fsa.assertEquals(getTextFromElement(yesContinueButton), "Yes, continue", "Yes continue button text mismatch in renters discount dialog");
        fsa.assertEquals(getTextFromElement(noRemoveDiscountLink), "No, remove discount", "No remove discount link text mismatch in renters discount dialog");

        // fresh the driver
        driver().navigate().refresh();

        // validate the content of the auto monoline card
        fsa.assertTrue(isElementVisible(onlyAutoCardCarIcon, 1), "Car icon is visible in auto only card");
        fsa.assertEquals(getTextFromElement(justAutoText), "Just auto", "Just auto text mismatch in auto only card");
        fsa.assertEquals(getTextFromElement(estimatedText), "Estimated", "Estimated text mismatch in auto only card");
        fsa.assertTrue(isElementVisible(autoMonolinePremiumAmount, 1), "Premium amount is visible in auto only card");
        fsa.assertEquals(getTextFromElement(continueWithAutoOnlyButton), "Continue with auto", "Continue with auto only button text mismatch");


        // validate continue with auto only pop up
        clickElement(continueWithAutoOnlyButton);
        fsa.assertTrue(isElementVisible(noRentersDiscountDialog, 5), "No renters discount dialog should be visible after clicking continue with auto only button");
        fsa.assertEquals(getTextFromElement(noRentersDiscountDialogHeader), "Sure you don't want a renters discount?", "No renters discount dialog header text mismatch");
        fsa.assertEquals(getTextFromElement(noRentersDiscountDialogContent), isSafariBrowser() ? "You can save when bundling with Farmers.Please note: You'll need to purchase both an auto policy and renters policy to get the bundle discount." : "You can save when bundling with Farmers. Please note: You'll need to purchase both an auto policy and renters policy to get the bundle discount.", "No renters discount dialog content text mismatch");
        fsa.assertEquals(getTextFromElement(letsAddDiscountButton), "Let's add the discount", "Let's add the discount button text mismatch in no renters discount dialog");
        fsa.assertEquals(getTextFromElement(continueWithoutDiscountButton), "Continue without discount", "Continue without discount button text mismatch in no renters discount dialog");

    }
}
