package com.farmers.ffq.ace.condo;

import com.farmers.ffq.ace.hrc.common.AceHRCAdditionalInfoBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceCondoAdditionalInfoPage extends AceHRCAdditionalInfoBasePage {

    private static final String TEMPORARY_RENTAL_CHECKBOX_XPATH = "//div[@id='tempRental']//mat-checkbox";
    @FindBy(xpath = TEMPORARY_RENTAL_CHECKBOX_XPATH)
    private WebElement temporaryRentalMatCheckBox;
    @FindBy(xpath = TEMPORARY_RENTAL_CHECKBOX_XPATH + "//input")
    private WebElement temporaryRentalCheckBoxInput;
    @FindBy(xpath = TEMPORARY_RENTAL_CHECKBOX_XPATH + "//label")
    private WebElement temporaryRentalLabel;

    private static final String CENTRAL_FIRE_CHECKBOX_XPATH = "//div[@id='centralFireDiscount']//mat-checkbox";
    @FindBy(xpath = CENTRAL_FIRE_CHECKBOX_XPATH)
    private WebElement centralFireAlarmMatCheckBox;
    @FindBy(xpath = CENTRAL_FIRE_CHECKBOX_XPATH + "//input")
    private WebElement centralFireAlarmCheckBoxInput;
    @FindBy(xpath = CENTRAL_FIRE_CHECKBOX_XPATH + "//label")
    private WebElement centralFireAlarmLabel;

    private static final String CENTRAL_BURGLAR_CHECKBOX_XPATH = "//div[@id='centralBurglarDiscount']//mat-checkbox";
    @FindBy(xpath = CENTRAL_BURGLAR_CHECKBOX_XPATH)
    private WebElement centralBurglarAlarmMatCheckBox;
    @FindBy(xpath = CENTRAL_BURGLAR_CHECKBOX_XPATH + "//input")
    private WebElement centralBurglarAlarmCheckBoxInput;
    @FindBy(xpath = CENTRAL_BURGLAR_CHECKBOX_XPATH + "//label")
    private WebElement centralBurglarAlarmLabel;

    private static final String LOCAL_BURGLAR_CHECKBOX_XPATH = "//div[@id='localBurglarDiscount']//mat-checkbox";
    @FindBy(xpath = LOCAL_BURGLAR_CHECKBOX_XPATH)
    private WebElement localBurglarAlarmMatCheckBox;
    @FindBy(xpath = LOCAL_BURGLAR_CHECKBOX_XPATH + "//input")
    private WebElement localBurglarAlarmCheckBoxInput;
    @FindBy(xpath = LOCAL_BURGLAR_CHECKBOX_XPATH + "//label")
    private WebElement localBurglarAlarmLabel;

    private static final String LOCAL_FIRE_CHECKBOX_XPATH = "//div[@id='localFireDiscount']//mat-checkbox";
    @FindBy(xpath = LOCAL_FIRE_CHECKBOX_XPATH)
    private WebElement localFireAlarmMatCheckBox;
    @FindBy(xpath = LOCAL_FIRE_CHECKBOX_XPATH + "//input")
    private WebElement localFireAlarmCheckBoxInput;
    @FindBy(xpath = LOCAL_FIRE_CHECKBOX_XPATH + "//label")
    private WebElement localFireAlarmLabel;


    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public AceCondoAdditionalInfoPage() throws Exception {
    }

    public void validateContentOfCentralFireAlarmSection(FarmersSoftAssert fsa) throws Exception {
    	testCheckboxToggle(CENTRAL_FIRE_CHECKBOX_XPATH, centralFireAlarmMatCheckBox, centralFireAlarmLabel, "Central fire alarm", "Safety counts -- we added a fire alarm discount!", fsa);
    }
    
    public void validateContentOfCentralBurglarAlarmSection(FarmersSoftAssert fsa) throws Exception {
    	testCheckboxToggle(CENTRAL_BURGLAR_CHECKBOX_XPATH, centralBurglarAlarmMatCheckBox, centralBurglarAlarmLabel, "Central burglar alarm", "Safety counts! We added a burglar alarm discount.", fsa);
    }

    public void validateContentOfLocalFireAlarmSection(FarmersSoftAssert fsa) throws Exception {
        testCheckboxToggle(LOCAL_FIRE_CHECKBOX_XPATH, localFireAlarmMatCheckBox, localFireAlarmLabel, "Local Fire Alarm", "Safety counts! We added a local fire discount.", fsa);
    }

    public void validateContentOfLocalBurglarAlarmSection(FarmersSoftAssert fsa) throws Exception {
        testCheckboxToggle(LOCAL_BURGLAR_CHECKBOX_XPATH, localBurglarAlarmMatCheckBox, localBurglarAlarmLabel, "Local Burglar Alarm", "Safety counts! We added a local burglar discount.", fsa);
    }
    
    private void testCheckboxToggle(String checkboxXpath, WebElement checkbox, WebElement checkboxLabel, String identifier, String snackboxAddedText, FarmersSoftAssert fsa) throws Exception {
        scrollToElement(checkbox);
        fsa.assertTrue(checkbox.isDisplayed(), identifier + " checkbox displayed");
        fsa.assertEquals(getTextFromElement(checkboxLabel), identifier, identifier + " checkbox label verification");

        checkUncheckMatCheckbox(checkboxXpath, true);
        fsa.assertTrue(getAttributeData(checkbox, CLASS).contains(CHECKBOX_CHECKED), identifier + " checkbox is checked on initial load.");
        sleep(1);
        fsa.assertEquals(getTextFromElement(snackBar), snackboxAddedText, identifier + " discount added message displayed.");

        checkUncheckMatCheckbox(checkboxXpath, false);
        fsa.assertTrue(!getAttributeData(checkbox, CLASS).contains(CHECKBOX_CHECKED), identifier + " checkbox not checked.");
        sleep(2);
        fsa.assertEquals(getTextFromElement(snackBar), identifier + " discount has been removed.", identifier + " discount removed message displayed.");
    }

    public void fillOutAdditionalInfoPageCondo(ApplicantAceHome applicantAceHome, boolean continueButton) throws Exception {
        String stateCode = applicantAceHome.getStateCode();
        if (!isNoHomeShareState(stateCode)) {
            fillOutTemporaryRentalInfo(applicantAceHome.isTemporaryRentals());
        }
        if (List.of(KY, LA, MA, MS).contains(stateCode)) {
            if (applicantAceHome.getStateCode().equals(KY)) {
                if (applicantAceHome.getFireAlarm().equals(YES) || !applicantAceHome.getSprinklerSystem().isBlank()) {
                   fillOutFireSystemsInfo(applicantAceHome.getFireAlarm(), stateCode);
                   fillOutSprinklerSystemsInfo(applicantAceHome.getSprinklerSystem());
               }
            } else {
                fillOutFireAlarmInfo(applicantAceHome.getFireAlarm());
            }
            fillOutBurglarAlarmInfo(applicantAceHome.getBurglarAlarm());
            fillOutWaterLeakProtectionInfo(applicantAceHome.getWaterLeakProtection());
        } else {
            if (stateCode.equals(NC)) {
                fillOutFireSystemsInfo(applicantAceHome.getFireAlarm(), stateCode);
                fillOutSprinklerSystemsInfo(applicantAceHome.getSprinklerSystem());

                fillOutWaterLeakProtectionInfo(applicantAceHome.getWaterLeakProtection());
                fillOutLocalFireAlarmInfo(applicantAceHome.isLocalFireAlarm());
                fillOutLocalBurglarAlarmInfo(applicantAceHome.isLocalBurglarAlarm());
            }
            fillOutCentralFireAlarmInfo(applicantAceHome.isCentralFireAlarm());
            fillOutCentralBurglarAlarmInfo(applicantAceHome.isCentralBurglarAlarm());
        }
        if(continueButton) {
            clickContinueButton();
        }
    }

    public boolean isLocalFireAlarmCheckboxChecked() {
        return getAttributeData(localFireAlarmMatCheckBox, CLASS).contains(CHECKBOX_CHECKED);
    }
    
    public void validateDataNotSavedCondo( ApplicantAceHome applicantAceHome, FarmersSoftAssert fsa) {
        waitForPageToBeReady();
        if (!isNoHomeShareState(applicantAceHome.getStateCode())) {
            fsa.assertTrue(!isTemporaryRentalsCheckboxChecked(), "Temporary Rental check box is not selected");
        }
        if (List.of(KY, LA, MA, MS).contains(applicantAceHome.getStateCode())) {
            if (applicantAceHome.getStateCode().equals(KY)) {
                if (applicantAceHome.getFireAlarm().equals(YES) || !applicantAceHome.getSprinklerSystem().isBlank()) {
                    fsa.assertTrue(!isFireProtectionSystemCheckboxChecked(), "Fire protection check box is not selected");
                }
            } else {
                fsa.assertTrue(!isFireAlarmCheckboxChecked(), "Fire Alarm check box check box is not selected");
            }
            fsa.assertTrue(!isBurglarAlarmCheckboxChecked(), "Burglar alarm check box is not selected");
            fsa.assertTrue(!isWaterProtectionCheckboxChecked(), "Water Leak Protection check box is not selected");

        } else {
            if (applicantAceHome.getStateCode().equals(NC)) {

                fsa.assertTrue(!isFireProtectionSystemCheckboxChecked(), "Fire Protection check box is not selected");
                fsa.assertTrue(!isWaterProtectionCheckboxChecked(), "Water Leak Protection check box is not selected");
                fsa.assertTrue(!isLocalFireAlarmCheckboxChecked(), "Local Fire Alarm check box is not selected");
                fsa.assertTrue(!isBurglarAlarmCheckboxChecked(), "Burglar Fire Alarm check box is not selected");
            }
            fsa.assertTrue(!isCentralFireAlarmCheckboxChecked(), "Central Fire Alarm check box is not selected");
            fsa.assertTrue(!isCentralBurglarAlarmCheckboxChecked(), "Central Burglar Alarm check box is not selected");
        }

    }

    public void fillOutCentralFireAlarmInfo(boolean isCentralFireAlarm) throws Exception {
        if (isCentralFireAlarm){
            checkUncheckMatCheckbox(CENTRAL_FIRE_CHECKBOX_XPATH, true);
        }
    }

    public void fillOutCentralBurglarAlarmInfo(boolean isCentralBurglarAlarm) throws Exception {
        if (isCentralBurglarAlarm){
            checkUncheckMatCheckbox(CENTRAL_BURGLAR_CHECKBOX_XPATH, true);
        }
    }

    public void fillOutLocalFireAlarmInfo(boolean isLocalFireAlarm) throws Exception {
        if (isLocalFireAlarm){
            checkUncheckMatCheckbox(LOCAL_FIRE_CHECKBOX_XPATH, true);
        }
    }

    public void fillOutLocalBurglarAlarmInfo(boolean isLocalBurglarAlarm) throws Exception {
        if (isLocalBurglarAlarm){
            checkUncheckMatCheckbox(LOCAL_BURGLAR_CHECKBOX_XPATH, true);
        }
    }

    public void fillOutBurglarAlarmInfo(String burglarAlarmValue) throws Exception {
        if (!burglarAlarmValue.equals(EMPTY_STRING)) {
            scrollToElement(burglarAlarmMatCheckbox);
            checkUncheckMatCheckbox(BURGLAR_ALARM_CHECKBOX_XPATH, true);
            waitElementBeVisibleClickable(burglarAlarmRadioButton);
            if (burglarAlarmValue.trim().equals(expectedUnMonitoredLabel)) {
                scrollAndClickOnHiddenElement(burglarAlarmRadioButtonsInput.get(0));
            } else if (burglarAlarmValue.trim().equals(expectedSelfMonitoredLabel)) {
                scrollAndClickOnHiddenElement(burglarAlarmRadioButtonsInput.get(1));
            } else if (burglarAlarmValue.trim().equals(expectedProfessionallyMonitoredLabel)) {
                scrollAndClickOnHiddenElement(burglarAlarmRadioButtonsInput.get(2));
            }
        }
    }

    public void validateAdditionalInfoSelections(ApplicantAceHome applicant, FarmersSoftAssert fsa) {
        if (List.of(KY, LA, MA, MS).contains(applicant.getStateCode())) {
            if (applicant.getStateCode().equals(KY)) {
                if (applicant.getFireAlarm().equals(YES) || !applicant.getSprinklerSystem().isBlank()) {
                    fsa.assertEquals(getAttributeData(fireProtectionSystemsCheckbox, CLASS).contains(CHECKBOX_CHECKED),
                            applicant.getFireAlarm(), "Additional Info page - fire protection checkbox.");
                }
            } else {
                fsa.assertTrue(getAttributeData(fireAlarmMatCheckbox, CLASS).contains(CHECKBOX_CHECKED), "Additional Info page - fire alarm checkbox.");
                String foundFireAlarmSelectedOption = getTextFromElement(fireAlarmMatRadioButtons.stream().filter(i -> getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED)).collect(Collectors.toList()).get(0));
                fsa.assertTrue(foundFireAlarmSelectedOption.equals(applicant.getFireAlarm()), "Additional Info page - fire alarm checkbox.");

            }
            fsa.assertEquals(getAttributeData(burglarAlarmMatCheckbox, CLASS).contains(CHECKBOX_CHECKED),
                    !applicant.getBurglarAlarm().isBlank(), "Additional Info page - burglar alarm checkbox.");
            fsa.assertEquals(getAttributeData(waterProtectionMatCheckbox, CLASS).contains(CHECKBOX_CHECKED),
                    !applicant.getWaterLeakProtection().isBlank(), "Additional Info page - water protection checkbox.");
        } else {
            if (applicant.getStateCode().equals(NC)) {
                if (applicant.getFireAlarm().equals(YES) || !applicant.getSprinklerSystem().isBlank()) {
                    fsa.assertEquals(getAttributeData(fireProtectionSystemsCheckbox, CLASS).contains(CHECKBOX_CHECKED),
                            applicant.getFireAlarm(), "Additional Info page - fire protection checkbox.");
                }

                fsa.assertEquals(getAttributeData(waterProtectionMatCheckbox, CLASS).contains(CHECKBOX_CHECKED),
                        !applicant.getWaterLeakProtection().isBlank(), "Additional Info page - water protection checkbox.");

                fsa.assertEquals(getAttributeData(localFireAlarmMatCheckBox, CLASS).contains(CHECKBOX_CHECKED),
                        applicant.isLocalFireAlarm(), "Additional Info page - local fire alarm checkbox.");

                fsa.assertEquals(getAttributeData(localBurglarAlarmMatCheckBox, CLASS).contains(CHECKBOX_CHECKED),
                        applicant.isLocalBurglarAlarm(), "Additional Info page - local burglar alarm checkbox.");
            }
            fsa.assertEquals(getAttributeData(centralFireAlarmMatCheckBox, CLASS).contains(CHECKBOX_CHECKED),
                    applicant.isCentralFireAlarm(), "Additional Info page - Central fire alarm checkbox.");
            fsa.assertEquals(getAttributeData(centralBurglarAlarmMatCheckBox, CLASS).contains(CHECKBOX_CHECKED),
                    applicant.isCentralBurglarAlarm(), "Additional Info page - Central burglar alarm checkbox.");
        }
    }

    public void validateNoCentralAlarmSections(FarmersSoftAssert fsa) {
        fsa.assertTrue(!isElementVisible(centralBurglarAlarmMatCheckBox, 2), "Central Burglar Alarm not displayed");
        fsa.assertTrue(!isElementVisible(centralFireAlarmMatCheckBox, 2), "Central Fire Alarm not displayed");
    }
}
