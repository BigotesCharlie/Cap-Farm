package com.farmers.ffq.auto.pages;

import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import lombok.Getter;
import lombok.SneakyThrows;
import net.datafaker.Faker;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.RandomUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.farmers.ffq.auto.pages.ContactInfoAutoPage.EXPECTED_EMAIL_ADDRESS_FIELD_LABEL;
import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter
public class AutoEnterAddressPage extends AutoBasePage {


    private static final String FARMERS_GROUP_SELECT_SIDESHEET_NOT_DISPLAYED = "Farmers GroupSelect sidesheet not displayed";
    private static final String EMPLOYEE_GROUP = "bank of belleville";
    static final String ADDRESS_PAGE_ERROR_MESSAGE = "One or more required fields are incomplete or incorrect. Please review.";
    private static final String CHANGE_ZIPCODE_POPUP_CSS = "#changeZipHeading";
    private static final String CHANGE_ZIP_CODE_CONTENT = "Your home address has a different ZIP Code than what was entered before. Do you want to change it to ";
    private static final String CHANGE_ZIP_CODE_HEADING = "Confirm ZIP Code";
    private static final String EDIT_ADDRESS_HEADING = "//h4[@id='editAddressHeading']";

    @FindBy(xpath = "//div[contains(@class,'personal-info_address_h1')]")
    private WebElement addressPageTitle;

    @FindBy(id = "auto-personal-info_address-subheading")
    private WebElement addressPageSubtitle;

    private static final String ACTIVE_ADDRESS_PAGE_FIELDS_XPATH = "//div[contains(@class, 'address__input') and not(@hidden)]";
    @FindBy(xpath = "//span[@class='manual-addr-heading']//a")
    private WebElement enterAddressManuallyLink;

    @FindBy(xpath = "//div[@id='formField_street']//input")
    private WebElement manualStreetInputField;

    @FindBy(xpath = "//div[@id='formField_city']//input")
    private WebElement manualCityInputField;

    @FindBy(xpath = "//div[@id='formField_zipCode']//input")
    private WebElement manualZipCodeInputField;

    @FindBy(xpath = "//div[@id='formField_apartment']//input")
    private WebElement manualApartmentInputField;

    private static final String TOWN_DROPDOWN_XPATH = "//mat-form-field[contains(@id,'town__input-field')]//mat-select";
    @FindBy(xpath = TOWN_DROPDOWN_XPATH)
    private WebElement townDropDown;

    @FindBy(xpath = "//mat-option[contains(@class,'town__input')]")
    private List<WebElement> townDropDownOptions;

    @FindBy(xpath = "//mat-form-field[@id='auto-manual-address-street__input-field']//mat-error")
    private WebElement addressFieldErrorMessage;

    private final String TOWN_SELECTION_ERROR_MESSAGE_XPATH = "//div[contains(@class,'address__town_select')]//mat-error";
    @FindBy(xpath = TOWN_SELECTION_ERROR_MESSAGE_XPATH)
    private WebElement townSelectionMatError;

    @FindBy(xpath = "//input[@id='auto-manual-street__input-section']")
    private WebElement addressInputField;
    @FindBy(css = "input[id='auto-manual-street__input-section']")
    private WebElement streetInputField;
    @FindBy(xpath = "//mat-form-field[@id='auto-manual-address-street__input-field']//mat-error")
    private WebElement streetInputFieldErrorMessage;
    @FindBy(xpath = "//div[contains(@class,'actions-change')]//button")
    private WebElement changeButton;
    @FindBy(id = "changeZipContent")
    private WebElement changeZipCodeContent;

    @FindBy(xpath = "//div[contains(@class,'change-zip__actions-cancel-button')]")
    private WebElement changeZipCodeGoBack;

    @FindBy(id = "changeZipHeading")
    private WebElement changeZipCodeHeading;
    @FindBy(css = CHANGE_ZIPCODE_POPUP_CSS)
    private WebElement changeZipCodePopUp;
    @FindBy(xpath = "//span/mat-icon[@alt='Congratulations'] | // div[text()=' Congratulations — You get the Homeowner discount']")
    private WebElement congratulationsMessage;
    @FindBy(xpath = EDIT_ADDRESS_HEADING)
    private WebElement editAddressHeading;
    @FindBy(id = "auto-edit-street__input-section")
    private WebElement editAddressStreetInputField;
    @FindBy(css = "button[class='tui-btn tui-btn-primary auto-edit-address-submit__button']")
    private WebElement editAddressSubmitButton;
    @FindBy(xpath = "//p[contains(text(),'One or more required fields is incomplete or incorrect. Please review.')]")
    private WebElement generalErrorMessage;
    @FindBy(xpath = "//input[contains(@id,'spouse_chkbox-input')]")
    private WebElement isHomeOwner;

    @FindBy(xpath = "//div[@id='auto-personal-info_address-subheading']")
    private WebElement yourAddressSubheading;

    @FindBy(id = "manualAddrHeading")
    private WebElement manualAddressEntryPopUpHeader;

    @FindBy(id = "manualAddrContent")
    private WebElement manualAddressEntryPopUpContent;

    @FindBy(xpath = "//button[contains(@class,'manual-addr__action-buttons')]")
    private WebElement enterManuallyButton;

    @FindBy(xpath = "//div[contains(@class,'manual-addr__actions-cancel-button')]")
    private WebElement enterManuallyCancelButton;

    @FindBy(xpath = "//div[@id='formField_street']//label")
    private WebElement addressInputFieldLabel;

    @FindBy(xpath = "//div[@id='formField_apartment']//label")
    private WebElement unitInputFieldLabel;

    @FindBy(xpath = "//div[@id='formField_city']//label")
    private WebElement cityInputFieldLabel;

    @FindBy(xpath = "//div[@id='formField_zipCode']//input")
    private WebElement zipCodeInputField;

    @FindBy(xpath = "//div[@id='formField_zipCode']//label")
    private WebElement zipCodeInputFieldLabel;

    @FindBy(xpath = "//div[@id='formField_zipCode']//mat-error")
    private WebElement zipCodeInputFieldErrorMessage;

    @FindBy(xpath = "//div[@id='formField_street']//div[@class='manual-address-error-text ng-star-inserted']")
    private WebElement manulaAddressFieldErrorMessage;

    @FindBy(xpath = "//mat-form-field[@id='manual-address-city__input-field']//mat-error")
    private WebElement cityErrorMessage;

    @FindBy(xpath = "//input[@formcontrolname='email' or @formcontrolname='emailAddress' and @aria-required='true']")
    private WebElement emailIdInput;

    @FindBy(xpath = "//input[(@formcontrolname='phoneNumber' or @formcontrolname='phone_number') and (@aria-required='true')]")
    private WebElement phoneNumberInput;

    @FindBy(xpath = "//input[@formcontrolname='email' or @formcontrolname='emailAddress' and @aria-required='true']/..//label")
    private WebElement emailIdInputLabel;

    @FindBy(xpath = "//input[(@formcontrolname='phoneNumber' or @formcontrolname='phone_number') and (@aria-required='true')]/..//label")
    private WebElement phoneNumberInputLabel;

    @FindBy(xpath = "//mat-error[contains(text(), 'email address')]")
    private WebElement emailAddressError;

    @FindBy(xpath = "//mat-error[contains(text(), 'phone number')]")
    private WebElement phoneNumberError;

    @FindBy(xpath="//span[contains(@class, 'warning-text')]")
    private WebElement warningPhoneNumberMsg;

    @FindBy(xpath = "//mat-error[contains(text(), 'Email address')]")
    private WebElement invalidEmailAddressError;

    @FindBy(xpath = "//mat-error[contains(text(), 'not a valid')]")
    private WebElement invalidPhoneNumberError;

    @FindAll({
            @FindBy(xpath = "//div[contains(@class,'personal-info-cards-footer')]//button"),
            @FindBy(xpath = "//div[contains(@class,'personal-info__disclaimer')] /following-sibling::div //button[@data-tui-tracking-id='personal-info__continue-button-cta' and contains(@class,'address-form__agree-cta') and normalize-space()='Agree and submit']")
    })
    private WebElement agreeAndSubmitButton;

    @FindBy(xpath = "//div[@class='address-form__continue-button']//span")
    private WebElement agreeAndSubmitButtonDesc;

    @FindBy(className = "manual-addr_field-label-text")
    private WebElement goBackToEnterAddressLink;

    @FindBy(xpath = "//button[contains(@class, 'manual-addr__action-buttons')]")
    private WebElement enterAddressManuallyButton;

    @FindBy(xpath = "//div[contains(@class, 'disclaimer__credit-report')]")
    private WebElement addressPageCreditDisclaimer;

    @FindBy(xpath = "//div[contains(@class, 'disclaimer__color') and contains(@class, 'inserted')]")
    private WebElement addressPageConsentDisclaimer;

    @FindBy(id = "showMoreButton")
    private WebElement showMoreButton;

    @FindBy(id = "showLessButton")
    private WebElement showLessButton;

    @FindBy(xpath = "//div[contains(@class, 'employer_div_icon')]/mat-icon")
    private WebElement employeeAffinitySectionIcon;

    @FindBy(xpath = "//span[contains(@class, 'info-box-header')]")
    private WebElement employeeAffinitySectionHeader;

    @FindBy(xpath = "//p[contains(@class, 'employer-description')]")
    private WebElement employeeAffinitySectionDescription;

    private final static String CHECK_YOUR_ELIGIBILITY_XPATH = "//a[@class='employer-description-link']";
    @FindBy(xpath = CHECK_YOUR_ELIGIBILITY_XPATH)
    private WebElement checkYourFGSEligibilityLink;

    @FindBy(className = "selected_employer_name")
    private WebElement selectedEmployerName;

    @FindBy(xpath = "//a[contains(@class, 'remove_selected_employer')]")
    private WebElement removeEmployerGroupLink;

    @FindBy(id = "fgs_sidesheet_heading")
    private WebElement fgsSidesheetHeader;

    @FindBy(className = "fgs-sidesheet-text-employer-header")
    private WebElement fgsSidesheetDescription;

    @FindBy(id = "mat-input-fwsField")
    private WebElement fgsSidesheetEmployerGroupInputField;

    @FindBy(xpath = "//div[contains(@class, 'employer-card-message')]")
    private WebElement fgsSidesheetMessage;

    @FindBy(xpath = "//div[@class='fgs-sidesheet_content']//button")
    private WebElement fgsSidesheetContinueButton;

    @FindBy(className = "fgs_employer-card-success_title")
    private WebElement fgsSidesheetBenefitsTitle;

    @FindBy(className = "fgs_employer-card-success_desc")
    private WebElement fgsSidesheetBenefitsDescription;

    @FindBy(className = "fgs_employer-card-success_skip_btn")
    private WebElement fgsSidesheetSkipDiscountLink;

    @FindBy(className = "fgs_employer-card-success_disclaimer")
    private WebElement fgsSidesheetSkipDisclaimer;

    @FindBy(xpath = "//*[contains(@class, 'disclaimer__credit-report')]")
    private WebElement creditCheckDisclaimerTextElement;

    @FindBy(xpath = "//*[starts-with(@class, 'disclaimer__color')]")
    private WebElement privacyPolicyDisclaimerTextElement;

    @FindBy(xpath = "//p[contains(@class,'personal-info__multiple-fields-missing')]")
    private WebElement pageErrorMessage;

    @FindBy(xpath = "//a[contains(@href, 'electronic')]/ancestor::div[1][contains(@class, 'tui-stacking')]")
    WebElement esignAndContactDisclaimerSection;

    @FindBy (xpath = "//mat-button-toggle-group[contains(@aria-label, 'auto insurance with another insurance company')]//button[contains(., 'Yes')]")
    WebElement iHaveAutoInsuranceWithAnotherCompanyButton;

    @FindBy (xpath = "//mat-button-toggle-group[contains(@aria-label, 'auto insurance with another insurance company')]//button[contains(., 'No')]")
    WebElement iDontHaveAutoInsuranceWithAnotherCompanyButton;

    private static final String SELECT_ALL_PRODUCTS_XPATH = "//div[@class='insurance-products__select-all']//input";
    @FindBy (xpath = SELECT_ALL_PRODUCTS_XPATH)
    WebElement selectAllInsuranceProductsCheckbox;
    @FindBy (xpath = "//img[contains(@src, 'rebrand_home')]/preceding-sibling::mat-checkbox//input")
    WebElement homeInsuranceCheckbox;
    @FindBy (xpath = "//img[contains(@src, 'rebrand_renter')]/preceding-sibling::mat-checkbox//input")
    WebElement rentersInsuranceCheckbox;
    @FindBy (xpath = "//img[contains(@src, 'home-icon')]/preceding-sibling::mat-checkbox//input")
    WebElement mobilehomeInsuranceCheckbox;
    @FindBy (xpath = "//img[contains(@src, 'motorcycle')]/preceding-sibling::mat-checkbox//input")
    WebElement motorcycleInsuranceCheckbox;
    @FindBy (xpath = "//img[contains(@src, 'mobilehome')]/preceding-sibling::mat-checkbox//input")
    WebElement recVehicleInsuranceCheckbox;
    @FindBy (xpath = "//img[contains(@src, 'rebrand-umbrella')]/preceding-sibling::mat-checkbox//input")
    WebElement umbrellaInsuranceCheckbox;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public AutoEnterAddressPage() throws Exception {
    }

    public void checkHomeOwner(AutoApplicant applicant) throws Exception {
        if (isHomeowner(applicant)) {
            clickHomeOwnerCheckBox();
        }
    }

    public void clickHomeOwnerCheckBox() throws Exception {
        jsClickElement(isHomeOwner);
    }

    public void checkHomeOwnerDiscountIfNotChecked() throws Exception {
        if (!isHomeOwnerChecked()) {
            jsClickElement(isHomeOwner);
        }
    }

    public void enterAddress(String fullAddress, boolean selectFromDropDown, boolean clickCTA) throws Exception {
        waitAndClickElement(addressInputField);
        if (!getTextFromElement(addressInputField).isEmpty()) {
            addressInputField.clear();
            sendKeysToElement(addressInputField, Keys.ESCAPE);
        }
        int maxLength = (fullAddress.length() < 42) ? fullAddress.length() : 41;
        sendKeysToElement(addressInputField, fullAddress.substring(0, maxLength));
        sendKeysToElement(addressInputField, Keys.RETURN);
        if (selectFromDropDown) {
            if (!waitElementPresent(By.xpath("//span[@class='pac-item-query']"), 10)) {
                sleep(2);
            }
            sendKeysToElement(addressInputField, Keys.ARROW_DOWN);
            sendKeysToElement(addressInputField, Keys.ENTER);
        }

        if (isElementPresent(By.cssSelector(CHANGE_ZIPCODE_POPUP_CSS), 2)) {
            waitAndClickElement(changeButton);
            waitForSpinnerToBeGone();
            if (isElementPresent(By.cssSelector(CHANGE_ZIPCODE_POPUP_CSS), 2)) {
                waitAndClickElement(changeButton);
                waitForSpinnerToBeGone();
            }
        }

        if (clickCTA) {
            clickAddressPageCtaButton();
        }

    }

    // temporary workaround for bundle
    public boolean addressFieldsAreActive() {
		return isElementPresent(By.xpath(ACTIVE_ADDRESS_PAGE_FIELDS_XPATH), 3);
	}

    public void enterAddress(String address, String city, boolean setTown) throws Exception {
    	//AB testing moved address and email someplace else...
    	if (addressFieldsAreActive()) {
    		if (isElementVisible(enterAddressManuallyLink, 3)) {
    			clickElement(enterAddressManuallyLink);
    		}
    		if (!enterGoogleAddress(addressInputField, address, city)) {
    			waitAndClickElement(addressInputField);
    			addressInputField.clear();
    			enterValueInField(address, addressInputField, "Address");
    			enterValueInField(city, manualCityInputField, "City");
    			if (isElementPresent(By.cssSelector(CHANGE_ZIPCODE_POPUP_CSS), 2)) {
    				approveZipCodeChange();
    			}
    			if (isElementPresent(By.cssSelector(CHANGE_ZIPCODE_POPUP_CSS), 2)) {
    				approveZipCodeChange();
    			}
    		}
    		if (setTown) {
    			selectTown();
    		}
    	}
        clickAddressPageCtaButton();
        dismissMovingIntoBundleDialog();
    }

    public void dismissMovingIntoBundleDialog() throws Exception {
        if (isElementPresent(By.xpath("//mat-dialog-container//button"), 5)) {
			clickElement(driver().findElement(By.xpath("//mat-dialog-container//button")));
			waitForSpinnerToBeGone();
		}
	}

    public void approveZipChangeIfPresent() throws Exception {
        if (isElementPresent(By.cssSelector(CHANGE_ZIPCODE_POPUP_CSS), 2)) {
            approveZipCodeChange();
        }
    }

    public void enterAddress(String fullAddress) throws Exception {
        enterAddress(fullAddress, true, true);
    }

    public void enterAddress(List<String> fullAddresses, AutoApplicant applicant) throws Exception {
        String state = applicant.getStateCode();

        // Filter the addresses based on the zip code
        Optional<String> matchingAddress = fullAddresses.stream()
                .filter(address -> address.contains(state))
                .findFirst();

        if (matchingAddress.isPresent()) {
            enterAddress(matchingAddress.get(), false, true);
        } else {
            Log.error("There is no such matching address");
        }
    }

    public void fillOutAddressPage(AutoApplicant applicant) throws Exception {
        fillOutEmailAndPhoneIfPresent(applicant.getEmail(), applicant.getPhoneNumber());
        fillOutInsuredAutoElsewhereIfPresent(applicant);
        if (applicant.getTestScenario().contains(BW_CLICK_TO_BUY_FULL_FLOW)) {
            String landingZipCode = getSessionStorageAppStore().getData().getLandingZipCode();
            if(getStateCodeFromAppStore().equals(VA)) {
                clearOutFieldUsingBackSpace(streetInputField);
                fillOutAddressUsingGooglePrefillORManual(applicant);
            }
            applicant.setZipCode(landingZipCode);
            Log.info("Zipcode for Click to Buy Full Flow: " + landingZipCode);
            clickAddressPageCtaButton();
            if (!driver().findElements(By.xpath("//mat-error")).isEmpty()) {
                fillOutEmailAndPhoneIfPresent(RandomStringUtils.randomAlphabetic(10) + "@farmers.testinator.com", "4847585421");
            }
            Log.info("Quote number for this flow: " + getSessionStorageAppStore().getData().getQuoteNumber());
            return;
        }
        clickHomeOwnerCheckbox(isHomeowner(applicant));
        if (isContactInfoDetailsAsked()) {
            processConsentSelection("Farmers");
        }
        String fullAddress = applicant.getResidentAddress() + SPACE + applicant.getCity() + SPACE + applicant.getZipCode();
        selectTown(applicant);
        if (isElementVisible(streetInputField, 1)) {
            fillOutAddressUsingGooglePrefillORManual(applicant);
            clickAddressPageCtaButton();
        } else if(isRA61Environment()) {
            fillOutTheAddressPageManuallyAndContinue(applicant);
        } else {
            enterAddress(fullAddress);
            if (isElementVisible(generalErrorMessage, 1)) {
                Log.info("Address enter via google prefill was not successful, thus using manual entry");
                fillOutTheAddressPageManuallyAndContinue(applicant);
            }
        }
    }

    public void fillOutAddressUsingGooglePrefillORManual(AutoApplicant applicant) throws Exception {
        sendKeysToElement(streetInputField, applicant.getResidentAddress());
        sleep(1);
        List<WebElement> smartySuggesstions = driver().findElements(By.xpath("//mat-option"));
        if (!smartySuggesstions.isEmpty()) {
            sendKeysToElement(streetInputField, Keys.DOWN);
            sendKeysToElement(streetInputField, Keys.ENTER);
            if (isElementPresent(By.cssSelector(CHANGE_ZIPCODE_POPUP_CSS), 1)) {
                approveZipCodeChange();
            }
            if (getAttributeData(manualCityInputField, CLASS).contains("invalid")) {
                sendKeysToElement(manualCityInputField, applicant.getCity());
            }
        } else {
            clearOutFieldUsingBackSpace(streetInputField);
            clearOutFieldUsingBackSpace(manualCityInputField);
            if (isElementPresent(By.cssSelector(CHANGE_ZIPCODE_POPUP_CSS), 1)) {
                approveZipCodeChange();
            }
            sendKeysToElement(streetInputField, applicant.getResidentAddress());
            sendKeysToElement(manualCityInputField, applicant.getCity());
        }
    }

    public void fillOutAddressPage(ADPFApplicant applicant) throws Exception {
        isOnEnterAddressPage();
        String fullAddress = applicant.getAddress() + SPACE + applicant.getCity() + SPACE + applicant.getZipCode();
        Faker faker = new Faker();
        String phoneNumber = faker.phoneNumber().phoneNumber().replace("[^\\d.]", "");
        String emailId = applicant.getFirstName().strip() + UNDERSCORE + applicant.getLastName().strip() + "@farmers.testinator.com";
        emailId = emailId.replace(SPACE, EMPTY_STRING);
        fillOutEmailAndPhoneIfPresent(emailId, phoneNumber);
        clickHomeOwnerCheckbox(RandomUtils.nextBoolean());
        if (applicant.getStateCode().equals(MA)) {
        	selectTown();
        }
        if (isElementVisible(streetInputField, 1)) {
            sleep(1);
            sendKeysToElement(streetInputField, applicant.getAddress());
            waitForElements("//mat-option");
            List<WebElement> googleSuggestions = driver().findElements(By.xpath("//mat-option"));
            if (!googleSuggestions.isEmpty()) {
                sendKeysToElement(streetInputField, Keys.DOWN);
                sendKeysToElement(streetInputField, Keys.ENTER);
                sleep(1);
                if (getAttributeData(manualCityInputField, CLASS).contains("invalid")) {
                    sendKeysToElement(manualCityInputField, applicant.getCity());
                }
            } else {
                sendKeysToElement(streetInputField, applicant.getAddress());
                sendKeysToElement(manualCityInputField, applicant.getCity());
            }
            clickAddressPageCtaButton();
        } else {
            enterAddress(fullAddress);
            if (isElementVisible(generalErrorMessage, 3)) {
                Log.info("Address entry via google prefill was not success, trying manual entry");
                fillOutTheAddressPageManuallyAndContinue(applicant);
            }
        }

    }

    public void fillOutEmailAndPhoneIfPresent(String emailId, String phoneNumber) {
        if (isElementVisible(emailIdInput, 2)) {
            scrollElementToMiddle(emailIdInput);
            sendKeysToElement(emailIdInput, emailId);
            Log.info("EmailId Entered: " + emailId);
            sendKeysToElement(phoneNumberInput, phoneNumber);
            Log.info("phoneNumber Entered: " + phoneNumber);
        }
    }

    public void fillOutInsuredAutoElsewhereIfPresent(AutoApplicant applicant) throws Exception {
        if (isElementVisible(iHaveAutoInsuranceWithAnotherCompanyButton, 2)) {
        	if (applicant.getCurrentlyInsuredStatus().equals("Insured")) {
        		scrollAndClickOnElement(iHaveAutoInsuranceWithAnotherCompanyButton);
        	} else {
        		scrollAndClickOnElement(iDontHaveAutoInsuranceWithAnotherCompanyButton);
        	}
    		waitForElements(SELECT_ALL_PRODUCTS_XPATH);
            List<SqlDiscount> discounts = applicant.getDiscounts();
            if (!discounts.isEmpty()) {
            	SqlDiscount bundleObject = discounts.get(FIRST_AVAILABLE_OPTION);
            	setCheckboxTo(homeInsuranceCheckbox, bundleObject.isHomeInsurance());
            	setCheckboxTo(rentersInsuranceCheckbox, bundleObject.isRentersInsurance());
            	setCheckboxTo(mobilehomeInsuranceCheckbox, bundleObject.isLifeInsurance()); //overload this unused in auto
            	setCheckboxTo(motorcycleInsuranceCheckbox, bundleObject.isMotorcycleInsurance());
            	setCheckboxTo(recVehicleInsuranceCheckbox, bundleObject.isMotorHome());
            	setCheckboxTo(umbrellaInsuranceCheckbox, bundleObject.isUmbrellaInsurance());
            }
        }
    }

    public void validatePrefillValues(AutoApplicant applicant) throws Exception {
        if (isElementVisible(streetInputField, 1)) {
            scrollElementToMiddle(streetInputField);
            testStepAssert(getElementValue(streetInputField, "Street input field"), applicant.getResidentAddress(), "Resident address prefilled");
            testStepAssert(getElementValue(manualCityInputField, "City input field"), applicant.getCity(), "City prefilled");
            testStepAssert(getElementValue(manualZipCodeInputField, "ZipCode input field"), applicant.getZipCode(), "ZipCode prefilled");
        }

        if (isElementVisible(emailIdInput, 2) && !getAttributeData(emailIdInput, CLASS).contains("invalid")) { // if element is not present it means this section is provided in some other places due to A/B testing
            scrollElementToMiddle(emailIdInput);
            testStepAssert(getElementValue(emailIdInput, EXPECTED_EMAIL_ADDRESS_FIELD_LABEL), applicant.getEmail(), "Email input is matching");
            if (!getAttributeData(phoneNumberInput, CLASS).contains("invalid")) {
                testStepAssert(getElementValue(phoneNumberInput, "Phone number").replaceAll("[^0-9]", EMPTY_STRING), applicant.getPhoneNumber().replaceAll("[^0-9]", EMPTY_STRING).substring(0, 10), "Phone number is matching");
            }
        }
    }

    public void clickAddressPageCtaButton() throws Exception {
        clickAgreeSubmitButton();
        dismissMovingIntoBundleDialog();
        // lineTypeIntelligenceServiceInitiated is no longer invoked; the warning-text retry is not needed.
        waitForSpinnerToBeGone();
    }

    private void clickHomeOwnerCheckbox(boolean isHomeOwner) {
        if (isHomeOwner) {
            clickElement(this.isHomeOwner);
            Log.info("Homeowner checkbox is clicked");
        }
    }

    public void enterHomeAddress(AutoApplicant applicant, String address) throws Exception {
        enterHomeAddress(applicant, address, true);
    }

    public void enterHomeAddress(AutoApplicant applicant, String address, boolean clickOnContinueButton) throws Exception {
        String partialAddress = !address.isEmpty() ? address : applicant.getResidentAddress();
        if (isHomeowner(applicant)) {
            waitAndClickElement(isHomeOwner);
            Log.info("Homeowner checkbox is clicked");
        }

        boolean successfullyEnteredAddress = enterGoogleAddressAce(addressInputField, partialAddress, applicant.getStateName(), applicant.getCity());
        sleep(1);
        if (isElementDisplayed(By.xpath(EDIT_ADDRESS_HEADING))) {
            renderAddressSidePanel(applicant);
            if (clickOnContinueButton) {
               clickAddressPageCtaButton();
            }
            return;
        }

        boolean isErrorMessagePresent = isElementPresent(By.xpath("//mat-error[@name='mat-error']"));
        if (!successfullyEnteredAddress || isErrorMessagePresent) {
            // try again
            successfullyEnteredAddress = enterGoogleAddressAce(addressInputField, partialAddress, applicant.getStateName(), applicant.getCity());
            isErrorMessagePresent = isElementPresent(By.xpath("//mat-error[@name='mat-error']"));
        }
        if (!successfullyEnteredAddress || isErrorMessagePresent) {
            // Log it as warning and continue with the manual entry
            Log.warn("Unable to enter address: " + partialAddress + SPACE + applicant.getCity());
        }
        sleep(2);
        if (isElementPresent(By.cssSelector(CHANGE_ZIPCODE_POPUP_CSS))) {
            approveZipCodeChange();
            sleep(2);
        }

        if (isElementVisible(enterManuallyCancelButton, 5)) {
            waitAndClickElement(enterManuallyCancelButton);
            fillOutTheAddressPageManuallyAndContinue(applicant);
            return;
        }

        if (isElementPresent(By.xpath("//mat-error[contains(.,'Invalid address')]"), 5)) {
            fillOutTheAddressPageManuallyAndContinue(applicant);
            return;
        }

        selectTown(applicant);

        if (clickOnContinueButton) {
            clickAddressPageCtaButton();
        }
        //enterAddress(fullAddress);
    }

    @SneakyThrows
    public void fillOutTheAddressPageManuallyAndContinue(AutoApplicant applicant) {
        if (isElementVisible(enterAddressManuallyLink, 10)) {
            waitAndClickElement(enterAddressManuallyLink);
            if (isElementVisible(manualAddressEntryPopUpHeader, 1)) {
                clickYesEnterManuallyButton();
            }
            fillOutTheAddressDetails(applicant);
            checkHomeOwner(applicant);
            selectTown(applicant);
            clickAddressPageCtaButton();
        } else {
            enterHomeAddress(applicant, EMPTY_STRING);
        }
    }

    @SneakyThrows
    public void fillOutTheAddressPageManuallyAndContinue(ADPFApplicant applicant) {
        if (isElementVisible(enterAddressManuallyLink, 10)) {
            waitAndClickElement(enterAddressManuallyLink);
            if (isElementPresent(By.cssSelector(CHANGE_ZIPCODE_POPUP_CSS), 8)) {
                clickYesEnterManuallyButton();
            }
            fillOutTheAddressDetails(applicant);
            if (applicant.getStateCode().equals(MA)) {
            	selectTown();
            }
            clickAddressPageCtaButton();
        } else {
            enterAddress(applicant.getAddress() + applicant.getZipCode() + applicant.getCity());
        }
    }

    private void selectTown(AutoApplicant applicant) throws Exception {
        // if state is not MA no town field
        if (applicant.getStateCode().equals(MA) && isElementPresent(By.xpath(TOWN_DROPDOWN_XPATH))) {
            waitAndClickElement(townDropDown);
            //randomly select one of the town
            waitAndClickElement(townDropDownOptions.get(0));
        }
    }

    public void selectTown() throws Exception {
        // if state is not MA no town field
        if (isElementPresent(By.xpath(TOWN_DROPDOWN_XPATH))) {
            waitAndClickElement(townDropDown);
            //randomly select one of the town
            waitAndClickElement(townDropDownOptions.get(0));
        }
    }

    private void fillOutTheAddressDetails(AutoApplicant applicant) {
        sendKeysToElement(waitElementBeVisible(manualStreetInputField), applicant.getResidentAddress());
        sendKeysToElement(waitElementBeVisible(manualCityInputField), applicant.getCity());
        if (!StringUtils.isEmpty(applicant.getApartmentNumber())) {
            sendKeysToElement(waitElementBeVisible(manualApartmentInputField), applicant.getApartmentNumber());
        }
    }

    private void fillOutTheAddressDetails(ADPFApplicant applicant) {
        sendKeysToElement(waitElementBeVisible(manualStreetInputField), applicant.getAddress());
        sendKeysToElement(waitElementBeVisible(manualCityInputField), applicant.getCity());
    }

    public String getFormFieldWebElementValue(String fieldName) throws Exception {
        return getElementValue(driver().findElement(By.cssSelector(String.format("input[aria-label*='%s']", fieldName))), fieldName);
    }

    public String getAddressSubheading() {
        return getTextFromElement(yourAddressSubheading).replace("Your address", EMPTY_STRING);
    }

    @SneakyThrows
    public void isAddressInputDataSaved(AutoApplicant applicant, FarmersSoftAssert fsa) {
        String addressFieldValue = getInputFieldValue(addressInputField).toLowerCase();
        String containedText = applicant.getResidentAddress().toUpperCase();
        fsa.assertTrue(addressFieldValue.toLowerCase().contains(containedText.toLowerCase()), "Containing text: " + addressFieldValue + "Text to be contained: " + containedText);
    }

    @SneakyThrows
    public boolean isAddressInputFieldEmpty() {
        return getInputFieldValue(addressInputField).isEmpty();
    }

    public boolean isBlankAddressFieldErrorMessageDisplayed() {
        return isErrorMessageDisplayedAndRedInColor("Please enter street number and name.");
    }

    public boolean isCongratulationsMessageDisplayed() {
        return isElementVisible(congratulationsMessage, 5);
    }

    public boolean isHomeOwnerChecked() {
        return isHomeOwner.isSelected();
    }

    public boolean isInvalidAddressErrorMessageDisplayed() {
        return isErrorMessageDisplayedAndRedInColor(isRA11Environment() ? "Please enter street number and name." : "Invalid address");
    }

    public boolean isOnEnterAddressPage() {
        return isElementVisible(addressPageTitle, 3);
    }

    public boolean isSelectAddressFromTheDropListErrorMessageDisplayed() {
        return isErrorMessageDisplayedAndRedInColor("Please select an address from the list.");

    }

    public void processCantFindAddressDialog(boolean enterManually) {
        waitElementBeVisible(manualAddressEntryPopUpHeader);
        if (enterManually) {
            waitAndClickElement(enterAddressManuallyButton);
        } else {
            waitAndClickElement(goBackToEnterAddressLink);
        }
    }

    @SneakyThrows
    public void navigateBackToPreviousPage() {
        driver().navigate().back();
        waitUntilAngular5Ready();
    }

    @SneakyThrows
    public void refreshPage() {
        driver().navigate().refresh();
        waitUntilAngular5Ready();
    }

    public void waitForAutoEnterAddressPageToRender() {
        waitElementBeVisible(addressPageTitle);
    }

    public void approveZipCodeChange() {
        testStepAssert(getTextFromElement(changeZipCodeHeading), CHANGE_ZIP_CODE_HEADING, "Change zipCode header validated", true);
        testStepAssert(getTextFromElement(changeZipCodeContent).contains(CHANGE_ZIP_CODE_CONTENT), "Address change pop up content validation");
        waitAndClickElement(changeButton);
        waitForSpinnerToBeGone();
    }

    private boolean isErrorMessageDisplayedAndRedInColor(String errorMessageText) {
        sleep(1);
        boolean isErrorTextDisplayed = isExpectedTextDisplayed(waitElementBeVisible(addressFieldErrorMessage), errorMessageText);
        String messageColor = addressFieldErrorMessage.getCssValue("color");
        Log.info("Error message color: " + messageColor);
        return isErrorTextDisplayed && (messageColor.equals("rgba(197, 22, 45, 1)") || messageColor.equals("rgb(197, 22, 45)") || messageColor.equals("rgba(179, 0, 50, 1)") || messageColor.equals("rgb(179, 0, 50)"));
    }

    private void renderAddressSidePanel(AutoApplicant applicant) throws Exception {
        sleep(1);
        if (!isElementDisplayed(By.xpath(EDIT_ADDRESS_HEADING))) {
            return;
        }
        sendKeysToElement(waitElementBeVisible(editAddressStreetInputField), applicant.getResidentAddress());
        waitAndClickElement(editAddressSubmitButton);
    }

    public String getAddressPageTitle() {
        return getTextFromElement(addressPageTitle);
    }

    public String getAddressPageSubtitle() {
        return getTextFromElement(addressPageSubtitle);
    }

    public String getAddressPageCreditDisclaimer() {
        return getTextFromElement(addressPageCreditDisclaimer);
    }

    public String getAddressPageConsentDisclaimer() {
        return getTextFromElement(addressPageConsentDisclaimer);
    }

    public void clickOnShowMore() throws Exception {
        if (isElementPresent(By.xpath("//a[@id='showMoreButton']"))) {
            waitAndClickElement(showMoreButton);
        }

    }

    public boolean isShowLessButtonDisplayed() {
        return showLessButton.isDisplayed();
    }

    public void sendKeysToAddressInputField(String address) {
        sendKeysToElement(addressInputField, address);
    }

    public void validateManualEntryPopUp(FarmersSoftAssert fsa) throws Exception {
        sendKeysToAddressInputField(RandomStringUtils.randomAlphabetic(10));
        addressInputField.sendKeys(Keys.TAB);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(manualAddressEntryPopUpHeader)), "We can't find your address");
        fsa.assertEquals(getTextFromElement(manualAddressEntryPopUpContent), "Do you want to enter your address manually?");
        fsa.assertEquals(getTextFromElement(enterManuallyButton), "Yes, enter manually");
        fsa.assertEquals(getTextFromElement(enterManuallyCancelButton), "Go back");
    }

    public void validateAddressPageForF87669(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {

        String stateName = applicant.getStateName();
        String expectedTitle = String.format("Hi, %s", applicant.getFirstName());
        String expectedSubTitle = String.format("Please enter your %s address.", stateName);
        fsa.assertEquals(getTextFromElement(addressPageTitle), expectedTitle, "Address page title validation");
        fsa.assertEquals(getTextFromElement(addressPageSubtitle), expectedSubTitle, "Address page sub title validation");

        // Validate if the option to add address manually is removed (i.e.) 'Enter address manually' link should not be present on the address section.
        fsa.assertFalse(isElementDisplayed(enterAddressManuallyLink,1), "Manual entry link should not be visible");

        // validate label values
        validateLabelsForInputFieldsF87669(fsa);

        // validate zip code prefilled with the one provided on the landing page
        fsa.assertEquals(getValueFromWebElement(zipCodeInputField), applicant.getZipCode(), "Zip code is not correctly prefilled");

        // validate the google prefill selection is done properly
        validateGooglePrefillSelectionFunctionalityF87669(fsa, applicant);

        // validate error messages
        validateErrorMessagesF87669(fsa);

        //Validate if the browser prefill functionality continues to work as expected (i.e.) the address saved on the browser should prefill without issues.
        validateBrowserPrefillFunctionalityF87669(fsa, applicant);

    }

    private  void validateLabelsForInputFieldsF87669(FarmersSoftAssert fsa) {
        // validate input field field labels
        fsa.assertEquals(getTextFromElement(addressInputFieldLabel), "Home Address (No PO Boxes)", "Street input field label validation");
        fsa.assertEquals(getTextFromElement(cityInputFieldLabel), "City", "City input field label validation");
        fsa.assertEquals(getTextFromElement(zipCodeInputFieldLabel), "ZIP Code", "ZipCode input field label validation");
        fsa.assertEquals(getTextFromElement(unitInputFieldLabel), "Unit #");
        fsa.assertEquals(getTextFromElement(emailIdInputLabel), "Email address", "Email id input field label validation");
        fsa.assertEquals(getTextFromElement(phoneNumberInputLabel), "Mobile phone", "Mobile phone input field label validation");
    }

    private  void validateGooglePrefillSelectionFunctionalityF87669(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        // Validate whether the google prefill suggestions are listed as and when the user starts typing address on the Home address input field.
        // Validate when user selects any of the address from the prefill suggestions, then the same should be prefilled successfully on the input field boxes
        sendKeysToElement(streetInputField, applicant.getResidentAddress() + SPACE + applicant.getCity() + COMMA + SPACE + applicant.getStateCode());

        sleep(1);
        List<WebElement> suggestions = driver().findElements(By.xpath("//div[@class='pac-item']"));

        if(!suggestions.isEmpty()) {
            WebElement firstSuggestion = suggestions.get(0);
            String firstSuggestionText = getTextFromElement(firstSuggestion);
            firstSuggestionText = firstSuggestionText.replace("California", "CA");
            fsa.assertEquals(firstSuggestionText.replaceAll("\\D", EMPTY_STRING),  applicant.getResidentAddress().replaceAll("\\D", EMPTY_STRING),  "Google first suggestion is not matching with the user input");

            // when user accepts google suggestion, we should fill out the input fields
            sendKeysToElement(streetInputField, Keys.DOWN);
            sendKeysToElement(streetInputField, Keys.ENTER);
            sleep(1);
            fsa.assertEquals(getValueFromWebElement(streetInputField).replaceAll("\\D", EMPTY_STRING), applicant.getResidentAddress().replaceAll("\\D", EMPTY_STRING), "Validate street google prefill");
            fsa.assertEquals(getValueFromWebElement(manualCityInputField).replaceAll(SPACE, EMPTY_STRING), applicant.getCity().replaceAll(SPACE, EMPTY_STRING), "Validate city google prefill");
            fsa.assertEquals(getValueFromWebElement(zipCodeInputField), applicant.getZipCode(), "Validate zip code google prefill");
        }
  }


    private void validateErrorMessagesF87669(FarmersSoftAssert fsa) throws Exception {
    	clearOutFieldUsingBackSpace(streetInputField);
    	clearOutFieldUsingBackSpace(manualCityInputField);
    	clearOutFieldUsingBackSpace(zipCodeInputField);

    	clickAddressPageCtaButton();
    	fsa.assertEquals(getTextFromElement(streetInputFieldErrorMessage), "Please enter street number and name.", "Street input field error message for no input");
    	fsa.assertEquals(getTextFromElement(cityErrorMessage), "Please enter your city.", "City input error message for no input");
    	fsa.assertEquals(getTextFromElement(zipCodeInputFieldErrorMessage), "Please enter your ZIP code.", "zip code error message for no input");
    }

    private void validateBrowserPrefillFunctionalityF87669(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        driver().navigate().refresh();
        isOnEnterAddressPage();
        fillOutAddressPage(applicant);
        sleep(10);
        InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
        if(interstitialBundlePage.isOnInterstitialBundlePage()) {
            interstitialBundlePage.continueWithAutoMonoLine();
        }
        testStepAssert(new WhoShouldWeInsurePage().isOnWhoShouldWeInsurePage(), "User is on who should page");
        driver().navigate().back();
        if(interstitialBundlePage.isOnInterstitialBundlePage()){
            selectStepper(ENTER_INFO);
        }
        sleep(3);
        NameAndDobPage nameAndDobPage = new NameAndDobPage();

        if(new NameAndDobPage().isOnNameAndDobPage()) {
           nameAndDobPage.clickContinueButton();
            testStepAssert(isOnEnterAddressPage(), "User should land on the Address page navigating back from Who Should we insure page");
            fsa.assertEquals(getValueFromWebElement(streetInputField).replaceAll("\\D", EMPTY_STRING), applicant.getResidentAddress().replaceAll("\\D", EMPTY_STRING), "Prefilled street address validation");
            fsa.assertEquals(getValueFromWebElement(manualCityInputField).toLowerCase().replaceAll(SPACE, EMPTY_STRING), applicant.getCity().replaceAll(SPACE, EMPTY_STRING).toLowerCase(), "Prefilled city  validation");
            fsa.assertEquals(getValueFromWebElement(zipCodeInputField).toLowerCase(), applicant.getZipCode(), "Zip code prefilled");
            fsa.assertEquals(getValueFromWebElement(emailIdInput), applicant.getEmail(), "Email id prefilled");
            fsa.assertEquals(getValueFromWebElement(phoneNumberInput).replaceAll("\\D", EMPTY_STRING), applicant.getPhoneNumber().replaceAll("\\D", EMPTY_STRING), "Phone number prefilled");
        }
    }

    public void validateManualEntrySection(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        waitAndClickElement(enterAddressManuallyLink);
        WebElement activeElement = driver().switchTo().activeElement();
        fsa.assertEquals(activeElement, manualStreetInputField, "Cursor should be in the street input field");
        driver().switchTo().defaultContent();

        // validate input field field labels
        fsa.assertEquals(getTextFromElement(addressInputFieldLabel), "Street number and name");
        fsa.assertEquals(getTextFromElement(cityInputFieldLabel), "City");
        fsa.assertEquals(getTextFromElement(zipCodeInputFieldLabel), "ZIP Code");
        fsa.assertEquals(getTextFromElement(unitInputFieldLabel), "Unit #");

        // validate error messages
        clickAddressPageCtaButton();
        fsa.assertEquals(getTextFromElement(manulaAddressFieldErrorMessage), "Please enter street number and name");
        fsa.assertEquals(getTextFromElement(cityErrorMessage), "Please enter your city.");

        // confirm zipCode pop up
        driver().navigate().refresh();
        waitAndClickElement(enterAddressManuallyLink);
        waitAndClickElement(zipCodeInputField);
        sendKeysOneByOne(zipCodeInputField, "12345");
        clickElement(manualCityInputField);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(changeZipCodeHeading)), "Confirm ZIP Code");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(changeZipCodeContent)), "Your home address has a different ZIP Code than what was entered before. Do you want to change it to 12345?");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(changeZipCodeGoBack)), "Go back");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(changeButton)), "Yes");
        waitAndClickElement(changeZipCodeGoBack);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(snackBar)), "Your ZIP Code was reset.", "Zipcode reset snackbar message when user click go back button from change zip code pop up");
        sendKeysToElement(waitElementBeVisible(zipCodeInputField), "12345" + Keys.ENTER);
        waitAndClickElement(changeButton);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(snackBar)), "ZIP Code updated!", "Zipcode updated snackbar message when user click change button from change zip code pop up");

    }

    public void validateTownSection(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        List<AppStore.Auto.Dropdowns.Quote.DropDownResponseBean.DropDownValue> zipTownList = this.getSessionStorageAppStore().getData().getZipTownList();
        List<String> townNames = zipTownList.stream().map(each -> each.getWebDesc()).collect(Collectors.toList());

        Log.info("Town(s) associated for given zipcode '" + applicant.getZipCode() + "' : " + townNames);

        if (zipTownList.size() > 1) {
            testStep("Validate town dropdown is displayed with zipcode associated with more than one town names");
            fsa.assertTrue(townDropDown.isDisplayed(), "Drop down for town is displayed");
            enterGoogleAddressAce(addressInputField, applicant.getResidentAddress(), applicant.getStateName(), applicant.getCity());
            clickAddressPageCtaButton();
            waitElementBeVisible(townSelectionMatError);
            fsa.assertEquals(getTextFromElement(townSelectionMatError), "Please enter your town.", "Town drop down error message");
            testStep("Validate town field should display error message if user select anything from the dropdown options");

            for (AppStore.Auto.Dropdowns.Quote.DropDownResponseBean.DropDownValue dropDownValue : zipTownList) {
                waitAndClickElement(townDropDown);
                WebElement currentTown = townDropDownOptions.stream().filter(each -> getTextFromElement(each).equals(dropDownValue.getWebDesc())).collect(Collectors.toList()).stream().findFirst().get();
                waitAndClickElement(currentTown);
                fsa.assertFalse(isElementPresentByXPath(TOWN_SELECTION_ERROR_MESSAGE_XPATH), "Error message should not be visible when user selects valid town from drop down");
            }
            testStep("Validate user is able to select any drop down option");

        } else {
            testStep("Validate if the drop down for town is Not displayed if there is only one town option");
            fsa.assertFalse(isElementPresentByXPath(TOWN_DROPDOWN_XPATH), "Dropdown for town is displayed");
        }

    }

    public void validateADA_AutoEnterAddressPage() throws Exception {
        if (!isADATestingEnabled()) return;
        isOnEnterAddressPage();
        clickOnShowMore();
        clickContinueButton();
        // page ada validation default form with errors exposed
        performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);

        if (isElementPresent(By.xpath(CHECK_YOUR_ELIGIBILITY_XPATH), 4)) {
            waitAndClickElement(checkYourFGSEligibilityLink);
            // Farmers Group select frame ada if exists
            waitForPageToBeReady();
            performADATesting(this.getClass().getSimpleName() + "_FarmersGroupSelectFrame", MARKETING_IT, ACE_AUTO);
            waitAndClickElement(closeIconMB);
        }
        //refresh page
        driver().navigate().refresh();
    }

    public String verifyEmployerAffinitySection() {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(isElementDisplayed(employeeAffinitySectionIcon, 2), "Employee/Group affinity section icon displayed");
        fsa.assertEquals(getTextFromElement(employeeAffinitySectionHeader), "Employer/group affinity", "Employee/Group affinity section title is correct");
        fsa.assertEquals(getTextFromElement(employeeAffinitySectionDescription), "Qualified employees, affinity group members, and members of credit unions may qualify for discounts through Farmers GroupSelect\u00ae.",
                "Employee/Group affinity section description is correct");
        fsa.assertTrue(isElementDisplayed(checkYourFGSEligibilityLink, 2), "Check your eligibility link displayed");
        fsa.assertEquals(getTextFromElement(checkYourFGSEligibilityLink), "Check your eligibility", "Check your eligibility link text is correct");
        fsa.assertAll();
        return TEST_PASSED;
    }

    public String verifyFGSSideSheet() throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        scrollAndClickOnHiddenElement(checkYourFGSEligibilityLink);
        fsa.assertTrue(isElementDisplayed(waitElementBeVisible(fgsSidesheetHeader), 5), "Farmers GroupSelect sidesheet displayed");
        fsa.assertEquals(getTextFromElement(fgsSidesheetHeader), "Farmers GroupSelect\u00ae", "Farmers GroupSelect sidesheet title is incorrect");
        fsa.assertEquals(getTextFromElement(fgsSidesheetDescription), "Save money based on where you work, or the groups you belong to.", "Farmers GroupSelect sidesheet description is correct");
        sendKeysToElement(fgsSidesheetEmployerGroupInputField, "NON EXISTING");
        sendKeysToElement(fgsSidesheetEmployerGroupInputField, Keys.ENTER);
        fsa.assertTrue(isElementDisplayed(fgsSidesheetMessage, 5), "Farmers GroupSelect sidesheet message displayed");
        fsa.assertEquals(getTextFromElement(fgsSidesheetMessage), "Members of this group are not eligible for our affinity discounts. Try another employer or group, or continue your quote and we'll look for other discounts for you.",
                "Farmers GroupSelect non eligible message is correct");
        sendKeysToElement(fgsSidesheetEmployerGroupInputField, EMPLOYEE_GROUP);
        wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath(DROPDOWN_OPTIONS_XPATH), 1));
        sendKeysToElement(fgsSidesheetEmployerGroupInputField, Keys.ARROW_DOWN);
        sendKeysToElement(fgsSidesheetEmployerGroupInputField, Keys.ENTER);
        fsa.assertTrue(isElementDisplayed(fgsSidesheetMessage, 5), "Farmers GroupSelect sidesheet message displayed");
        fsa.assertEquals(getTextFromElement(fgsSidesheetMessage), "Good news! Discounts are available for members of this group. We'll ask you to verify your eligibility in a bit.", "Farmers GroupSelect discount available message is correct");
        fsa.assertTrue(isElementDisplayed(fgsSidesheetBenefitsTitle, 3), "Farmers GroupSelect benefits section displayed");
        fsa.assertEquals(getTextFromElement(fgsSidesheetBenefitsTitle), "Farmers GroupSelect benefits", "Farmers GroupSelect benefits title is correct");
        fsa.assertEquals(getTextFromElement(fgsSidesheetBenefitsDescription), "Others have saved 23%* on average by switching their auto insurance "
                + "By bundling policies, you could save even more "
                + "Get special employee or association member discounts", "Farmers GroupSelect benefits section is correct");
        fsa.assertAll();
        return TEST_PASSED;
    }

    public String validateSkipFGSDiscount() throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        scrollAndClickOnHiddenElement(checkYourFGSEligibilityLink);
        if (isElementDisplayed(fgsSidesheetHeader, 5)) {
            sendKeysToElement(fgsSidesheetEmployerGroupInputField, EMPLOYEE_GROUP);
            wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath(DROPDOWN_OPTIONS_XPATH), 1));
            sendKeysToElement(fgsSidesheetEmployerGroupInputField, Keys.ARROW_DOWN);
            sendKeysToElement(fgsSidesheetEmployerGroupInputField, Keys.ENTER);
            fsa.assertTrue(isElementDisplayed(fgsSidesheetSkipDiscountLink, 5), "Farmers GroupSelect sidesheet skip discount link displayed");
            clickElement(fgsSidesheetSkipDiscountLink);
            fsa.assertTrue(isElementDisplayed(checkYourFGSEligibilityLink, 3), "Check your eligibility link displayed");
            fsa.assertFalse(isElementDisplayed(removeEmployerGroupLink, 3), "Remove employer/group link not displayed");
        } else {
            fsa.fail(FARMERS_GROUP_SELECT_SIDESHEET_NOT_DISPLAYED);
        }
        fsa.assertAll();
        return TEST_PASSED;
    }

    public String validateRemoveEmployerGroupFunction() {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        scrollAndClickOnElement(checkYourFGSEligibilityLink);
        if (isElementDisplayed(fgsSidesheetHeader, 5)) {
            sendKeysToElement(fgsSidesheetEmployerGroupInputField, EMPLOYEE_GROUP);
            sendKeysToElement(fgsSidesheetEmployerGroupInputField, Keys.ENTER);
            wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath(DROPDOWN_OPTIONS_XPATH), 1));
            sendKeysToElement(fgsSidesheetEmployerGroupInputField, Keys.ARROW_DOWN);
            sendKeysToElement(fgsSidesheetEmployerGroupInputField, Keys.ENTER);
            fsa.assertTrue(isElementDisplayed(fgsSidesheetContinueButton, 5), "Farmers GroupSelect sidesheet continue button displayed");
            clickElement(fgsSidesheetContinueButton);
            fsa.assertFalse(isElementDisplayed(checkYourFGSEligibilityLink, 3), "Check your eligibility link not displayed");
            fsa.assertTrue(isElementDisplayed(removeEmployerGroupLink, 3), "Remove employer/group link displayed");
            fsa.assertEquals(getTextFromElement(selectedEmployerName).toLowerCase(), EMPLOYEE_GROUP, EMPLOYEE_GROUP + " displayed as employer group");
            clickElement(removeEmployerGroupLink);
            fsa.assertTrue(isElementDisplayed(checkYourFGSEligibilityLink, 3), "Check your eligibility link displayed after employer group removed");
            fsa.assertFalse(isElementDisplayed(removeEmployerGroupLink, 3), "Remove employer/group link not displayed after employer group removed");
        } else {
            fsa.fail(FARMERS_GROUP_SELECT_SIDESHEET_NOT_DISPLAYED);
        }
        fsa.assertAll();
        return TEST_PASSED;
    }

    public String continueWithFGSDiscount(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        scrollAndClickOnElement(checkYourFGSEligibilityLink);
        if (isElementDisplayed(fgsSidesheetHeader, 5)) {
            sendKeysToElement(fgsSidesheetEmployerGroupInputField, EMPLOYEE_GROUP);
            wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath(DROPDOWN_OPTIONS_XPATH), 1));
            sendKeysToElement(fgsSidesheetEmployerGroupInputField, Keys.ARROW_DOWN);
            sendKeysToElement(fgsSidesheetEmployerGroupInputField, Keys.ENTER);
            waitAndClickElement(fgsSidesheetContinueButton);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(selectedEmployerName)), EMPLOYEE_GROUP, EMPLOYEE_GROUP + " displayed as employer group");
            fillOutEmailAndPhoneIfPresent(applicant.getEmail(), applicant.getPhoneNumber());
            enterAddress(applicant.getResidentAddress() + SPACE + applicant.getCity() + SPACE + applicant.getStateCode() + SPACE + applicant.getZipCode());
            waitForSpinnerToBeGone();
            FarmersGroupSelectPage fgsPage = new FarmersGroupSelectPage();
            if (fgsPage.quoteWithFarmersInsuranceOnline()) {
                waitForSpinnerToBeGone();
                fsa.assertTrue(isOnEnterAddressPage(), "Returned to Address page");
                fsa.assertFalse(isElementDisplayed(employeeAffinitySectionIcon, 2), "Employee/Group affinity section icon is not displayed");
                fsa.assertFalse(isElementDisplayed(employeeAffinitySectionHeader, 2), "Employee/Group affinity section title is not displayed");
                fsa.assertFalse(isElementDisplayed(employeeAffinitySectionDescription, 2), "Employee/Group affinity section description is not displayed");
                fsa.assertFalse(isElementDisplayed(checkYourFGSEligibilityLink, 2), "Check your eligibility link not displayed");
                fsa.assertFalse(isElementDisplayed(removeEmployerGroupLink, 2), "Remove employer/group link not displayed after employer group removed");
            } else {
                fsa.fail("Did not reach \"Farmers GroupSelect\" page");
            }
        } else {
            fsa.fail(FARMERS_GROUP_SELECT_SIDESHEET_NOT_DISPLAYED);
        }
        fsa.assertAll();
        clickAddressPageCtaButton();
        waitForSpinnerToBeGone();
        return TEST_PASSED;
    }

    public String getDisplayedAddressForCrossSell() throws Exception {
        WebElement address1 = driver().findElement(By.xpath("//div[@id='auto-personal-info_address-subheading']//div[2]"));
        WebElement address2 = driver().findElement(By.xpath("//div[@id='auto-personal-info_address-subheading']//div[3]"));
        return getTextFromElement(address1) + SPACE + getTextFromElement(address2);
    }

    public void clickContinueButton() throws Exception {
        clickAddressPageCtaButton();
    }

    private void clickAgreeSubmitButton() {
        scrollToElementAndClickIt(agreeAndSubmitButton);
    }

    private void scrollToElementAndClickIt(WebElement element) {
		scrollToElement(element);
		clickElement(element);
		waitForSpinnerToBeGone();
	}

    public void verifyDisclaimers(String applicantStateCode, FarmersSoftAssert fsa) {
    	fsa.assertTrue(isExpectedTextContainedInElement(esignAndContactDisclaimerSection, EXPECTED_ESIGN_DISCLAIMER), "Correct ESIGN disclaimer content");
    	String expectedCTADisclaimer = isBDQFlowEnabled() ? EXPECTED_CTA_DISCLAIMER.replace("Farmers.com", "Bristolwest.com") : EXPECTED_CTA_DISCLAIMER;
        fsa.assertTrue(isExpectedTextContainedInElement(esignAndContactDisclaimerSection, expectedCTADisclaimer), "Correct Call/Text consent disclaimer content");
    }

    public void verifyBundleDisclaimerSection(FarmersSoftAssert fsa) {
    	String foundEsignAndContactDisclaimerText = getTextFromElement(esignAndContactDisclaimerSection);
     	fsa.assertTrue(isTextContainedInOtherText(foundEsignAndContactDisclaimerText, "By clicking \"Agree and submit\", you agree to these ESIGN terms and conditions and to receive marketing calls and texts as detailed below."), "Correct ESIGN disclaimer content");
    	fsa.assertTrue(isTextContainedInOtherText(foundEsignAndContactDisclaimerText, "We call and/or text consumers with information about products and services. " +
    			"By clicking \"Agree and submit\", you consent to receive marketing calls and texts on behalf of Farmers\u00ae, Foremost\u00ae, Bristol West\u00ae, and Farmers Life\u00ae associated entities and their representatives using an automated telephone dialing system, AI-generated and artificial or pre-recorded voice, even for numbers listed on national, state, or business do-not-call registries. " +
    			"Consent is not a condition of purchase. Go to Farmers.com for alternative contact options. Message and data rates may apply."), "Correct Call/Text consent disclaimer content");
    }

    public void captureBundlePEWC() throws Exception {
        screenCapture(esignAndContactDisclaimerSection, "AceBundle_PersonalInfoPage", MEDIUM, true);
    }

    public boolean isContactInfoDetailsAsked() {
        return isElementVisible(emailIdInput, 2);
    }

    public void validateCTAText(FarmersSoftAssert fsa) {
        if (isContactInfoDetailsAsked()) {
            fsa.assertEquals(getTextFromElement(agreeAndSubmitButton), "Agree and submit", "CTA button text is valid");
            //Brand selection discontinued
            //fsa.assertEquals(getTextFromElement(agreeAndSubmitButtonDesc), DONT_FORGET_TO_MAKE_YOUR_SELECTIONS, "Agree and submit button desc is valid");
        } else {
            fsa.assertEquals(getTextFromElement(agreeAndSubmitButton), "Continue");
        }
    }

    public void validateBrandSelectionRule(AutoApplicant applicant) throws Exception {
        if (!isContactInfoDetailsAsked()) {
            testStep("User is not being asked the consent at this stage");
            return;
        }
        //validate the error message is thrown if customer does not select checkbox and user is not able to move on unless they select
        enterHomeAddress(applicant, applicant.getResidentAddress(), false);
        fillOutEmailAndPhoneIfPresent(applicant.getEmail(), applicant.getPhoneNumber());
        clickAddressPageCtaButton();
        testStepAssert(getTextFromElement(brandSelectionErrorMessage), EXPECTED_BRAND_SELECTION_ERROR_MESSAGE, "Error message validated for not selecting brand");
    }

    public void validateandUpdateQuote_call(FarmersSoftAssert fsa) throws Exception {
        //validating the captchaID
        ApiHelper apiHelper = new ApiHelper();

        CaptchaRequestBean validateCaptchaBeanReq = apiHelper.getValidateandUpdateQuoteRequest(getSessionStorageAppStore().getData().getQuoteNumber());
        CaptchaRequestBean.ValidateCaptchaRequestBean captchaID = validateCaptchaBeanReq.getValidateCaptchaRequestBean();
        String caID = String.valueOf(captchaID.getCaId());
        fsa.assertTrue(caID != null, "CaptchaID is null");

        //validating the status
        CaptchaResponseBean validateCaptchaBeanRes = apiHelper.getValidateandUpdateQuoteResponse(getSessionStorageAppStore().getData().getQuoteNumber());
        CaptchaResponseBean.ValidateCaptchaResponseBean responseStatus = validateCaptchaBeanRes.getValidateCaptchaResponseBean();
        String status = responseStatus.getStatus();
        fsa.assertTrue(status.equalsIgnoreCase("success"), "ValidateAndUpdateQuote call got failed");

    }

    public void clickYesEnterManuallyButton() {
        waitAndClickElement(enterManuallyButton);
    }

    public void validateInvalidAddressInput(FarmersSoftAssert fsa) throws Exception {
        sendKeysToAddressInputField(RandomStringUtils.randomNumeric(15));
        if (isRA11Environment()) {
            sendKeysToAddressInputField((Keys.TAB).toString());
        } else {
            clickAddressPageCtaButton();
        }
        if (isSafariBrowser()) {
            clickAddressPageCtaButton();
        }
        fsa.assertTrue(isInvalidAddressErrorMessageDisplayed(), "Invalid Address message displayed");
    }

    public void validateSourceID(AutoApplicant applicant, String employeeGroup, FarmersSoftAssert fsa) throws Exception {
        new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        testStep("Navigate to Address Page");
        boolean egImpl = getSessionStorageAppStore().getData().getProjectCodeData().getAuto().isEgImpl();
        Log.info("EgIPM project code set to " + egImpl);
        if (egImpl) {
            validateAffinitySectionIsNotDisplayed(fsa);
        } else {
            testStep("Verify Employer/Group Affinity Section " + verifyEmployerAffinitySection());
            String originalURL = driver().getCurrentUrl();
            String SRC_Value = new URL(originalURL).getQuery().split("&")[2].split("=")[1];
            enterHomeAddress(applicant, applicant.getResidentAddress(), false);
            fillOutEmailAndPhoneIfPresent(applicant.getEmail(), applicant.getPhoneNumber());
            testStepAssertTrue(isElementDisplayed(checkYourFGSEligibilityLink, 3), "Check your eligibility link not displayed");
            waitAndClickElement(checkYourFGSEligibilityLink);
            if (isElementDisplayed(fgsSidesheetHeader, 5)) {
                sendKeysToElement(fgsSidesheetEmployerGroupInputField, employeeGroup);
                wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath(DROPDOWN_OPTIONS_XPATH), 1));
                sendKeysToElement(fgsSidesheetEmployerGroupInputField, Keys.ARROW_DOWN);
                sendKeysToElement(fgsSidesheetEmployerGroupInputField, Keys.ENTER);
                fsa.assertTrue(isElementDisplayed(fgsSidesheetContinueButton, 5), "Farmers GroupSelect sidesheet continue button displayed");
                clickElement(fgsSidesheetContinueButton);
                clickAddressPageCtaButton();
                sleep(3);
                fsa.assertTrue(driver().getCurrentUrl().contains(SRC_Value), "validating Source ID in FGS Page");
            }
        }
    }

    public void validateBDQSpecificRules(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        validateValidateAndFooterForBDQ(fsa, applicant, this);
        fsa.assertTrue(isOnBristolWest(), "User should be on the BW flow-Logo present");
        validateAffinitySectionIsNotDisplayed(fsa);
        if (isElementVisible(privacyPolicyDisclaimerTextElement, 1)) {
            fsa.assertTrue(isExpectedTextContainedInElement(privacyPolicyDisclaimerTextElement, "Bristol West\u00ae") && !getTextFromElement(privacyPolicyDisclaimerTextElement).contains("Farmers.com") && !getTextFromElement(privacyPolicyDisclaimerTextElement).contains("Farmers"), "User should get in the disclaimer Bristolwest not Farmers on " + this.getClass().getSimpleName());
        }
        validateZipChangeErrorMessage(fsa);
        fsa.assertFalse(isDiscountSectionDisplayed(), "Discount section should not be available on " + this.getClass().getSimpleName());
    }

    public void validateAffinitySectionIsNotDisplayed(FarmersSoftAssert fsa) {
        fsa.assertTrue(!isElementVisible(employeeAffinitySectionIcon, 1), "Address page: Employer section - Icon - should not be visible");
        fsa.assertTrue(!isElementVisible(employeeAffinitySectionHeader, 1), "Address page: Employer section - Header - should not be visible");
        fsa.assertTrue(!isElementVisible(employeeAffinitySectionDescription, 1), "Address page: Employer section - Description- should not be visible");
        fsa.assertTrue(!isElementVisible(checkYourFGSEligibilityLink, 1), "Address page: Employer section - Check your eligibility link- should not be visible");
    }

    private void validateZipChangeErrorMessage(FarmersSoftAssert fsa) {
        //waitAndClickElement(enterAddressManuallyLink);
        // sendKeysToElement(manualZipCodeInputField, );
        //TODO: US928916: BDQ Ace - Change of Address

    }

    public void validateRequiredErrorFieldsInputErrorMessages(FarmersSoftAssert fsa) throws Exception {
        clickAddressPageCtaButton();
        final String PLEASE_ENTER_YOUR = "Please enter your ";
        isBlankAddressFieldErrorMessageDisplayed();
        if (isContactInfoDetailsAsked()) {
            fsa.assertEquals(getTextFromElement(emailAddressError), PLEASE_ENTER_YOUR + "email address");
            fsa.assertEquals(getTextFromElement(phoneNumberError), PLEASE_ENTER_YOUR + "phone number");
            clickAddressPageCtaButton();
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageErrorMessage)), ADDRESS_PAGE_ERROR_MESSAGE);
            fsa.assertEquals(getTextFromElement(pageErrorMessage), ADDRESS_PAGE_ERROR_MESSAGE);

        }
    }

    public void validateInvalidContactDetailsErrorMessages(FarmersSoftAssert fsa) throws Exception {
        driver().navigate().refresh();
        final String IS_NOT_VALID_ENTRY = "is not a valid entry";
        if (isContactInfoDetailsAsked()) {
            //invalid email format
            waitAndClickElement(emailIdInput);
            sendKeysToElement(emailIdInput, "invalidEmail@");
            emailIdInput.sendKeys(Keys.TAB);
            final String EXPECTED_INVALID_EMAIL_ADDRESS_ERROR = "Email address entered is invalid";
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(invalidEmailAddressError)), EXPECTED_INVALID_EMAIL_ADDRESS_ERROR);

            //invalid domain --validate email call should fail
            waitAndClickElement(emailIdInput);
            sendKeysToElement(emailIdInput, "invalidemail_123@yopmael.com");
            waitAndClickElement(phoneNumberInput);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(invalidEmailAddressError)), EXPECTED_INVALID_EMAIL_ADDRESS_ERROR);

            //invalid phone number
            String invalidPhone = "(123) 456-6796";
            sendKeysToElement(phoneNumberInput, invalidPhone);
            phoneNumberInput.sendKeys(Keys.TAB);
            fsa.assertEquals(getTextFromElement(invalidPhoneNumberError), String.format("%s %s", invalidPhone, IS_NOT_VALID_ENTRY));

            //Business disabled this feature for now, so commenting out the below code
            //landline phone number
//            String landline="(315) 456-7890";
//            if (isSafariBrowser()) {
//                phoneNumberInput.sendKeys(Keys.COMMAND, "a", Keys.BACK_SPACE);
//            } else {
//                phoneNumberInput.sendKeys(Keys.CONTROL, "a", Keys.BACK_SPACE);
//            }
//
//            sendKeysToElement(phoneNumberInput, landline);
//            fsa.assertEquals(getTextFromElement(waitElementBeVisible(warningPhoneNumberMsg)),"This phone number is a landline phone. Please double-check that you entered the correct information.","Mismatch Warning message for landline phone number");

        }
    }


    //TODO : belo validation is for validEamil for "validateEmail" API
    public void validateBrightVerifyStatus() throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        BrightVerifyServiceResponse validateBrightVerifyResponse = new ApiHelper().getAutoBrightVerifyResponse(getSessionStorageAppStore().getData().getQuoteNumber());
        String status = validateBrightVerifyResponse.getValidateEmailResponseBean().getStatus();
        fsa.assertTrue(status.equalsIgnoreCase("valid") || status.equalsIgnoreCase("accept_all"), "BrightVerify call to check valid MAIL-ID");
        fsa.assertAll();

    }

    public void verifyLineTypeIntelligenceServicedIsCalled(FarmersSoftAssert fsa) throws Exception {
        sleep(2);
        LineTypeIntelligenceRequest lineTypeIntelligenceServiceInitiated = new ApiHelper().getLineTypeIntelligenceServiceInitiated(getSessionStorageAppStore().getData().getQuoteNumber());
        // validate the call is not empty and the status is success
        fsa.assertTrue(lineTypeIntelligenceServiceInitiated != null, "LineTypeIntelligenceService call is not empty");
    }

    public void changeZipcode(String newZipcode) {
    	if (isSafariBrowser()) {
    		scrollElementToMiddle(zipCodeInputField);
    		sendKeysToElementAlternate(zipCodeInputField, newZipcode);
            sendKeysToElement(zipCodeInputField, Keys.RETURN);
    	} else {
    		enterValueInField(newZipcode, zipCodeInputField, "Changing zipcode to " + newZipcode);
    	    sendKeysToElement(zipCodeInputField, Keys.RETURN);
        }
    }

    public void validateZipcodeChange(String state, boolean isSameState, FarmersSoftAssert fsa) {
    	scrollToTopOfPage();
    	if (isSameState) {
    		fsa.assertTrue(!isElementVisible(zipCodeInputFieldErrorMessage, 2), "Zip code change is valid");
    	} else {
    		fsa.assertEquals(getTextFromElement(zipCodeInputFieldErrorMessage), "Please enter a valid ZIP for " + state.toUpperCase() + " or start a new quote", "Zip code error message when changing state");
    	}
    }

    public void capturePEWC() throws Exception {
        screenCapture(esignAndContactDisclaimerSection, "AceAuto_AddressPage", MEDIUM, false);
    }

    public void fillOutCityIfInvalid(String city) {
        if (getAttributeData(manualCityInputField, CLASS).contains("ng-invalid")) {
            sendKeysToElement(manualCityInputField, city);
        }
    }
}
