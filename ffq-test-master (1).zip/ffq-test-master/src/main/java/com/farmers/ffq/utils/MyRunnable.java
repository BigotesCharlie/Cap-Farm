package com.farmers.ffq.utils;

import static com.farmers.ffq.common.pages.BasePage.sendGetRequest;

import org.openqa.selenium.WebElement;

public class MyRunnable implements Runnable {

    private final WebElement hrefElement;

    public MyRunnable(WebElement element) {
        this.hrefElement = element;
    }

    @Override
    public void run() {
        sendGetRequest(hrefElement);
    }
}
