package com.farmers.ffq.auto.pages.legacy;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.datatransferobjects.SqlDiscount;
import com.farmers.ffq.datatransferobjects.SqlVehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.NumberFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;
public class QuotePageAuto extends AutoBasePage{

	private static final String NON_CURRENCY_CHARS = "[^0-9.]";
	private static final String UNINSURED_STACKING_OPTION_DROPDOWN_NOT_PRESENT = "uninsured stacking option dropdown not present";
	private static final String UNDERINSURED_STACKING_OPTION_DROPDOWN_PRESENT = "underinsured stacking option dropdown present";
	private static final String UNINSURED_STACKING_OPTION_DROPDOWN_PRESENT = "uninsured stacking option dropdown present";
	private static final String UNDERINSURED_STACKING_OPTION_DROPDOWN_NOT_PRESENT = "underinsured stacking option dropdown not present";
	private static final String DISCLOSURE2_ERROR = "quotePageDisclosure2 error";
	private static final String RENTERS_DISCLOSURE_ERROR = "quotePageRentersDisclosure error";
	private static final String DISCLOSURE3_ERROR = "quotePageDisclosure3 error";
	private static final String DISCLOSURE1_ERROR = "quotePageDisclosure1 error";
	private static final String SKIP = "SKIP";
	private static final String QUOTE_PAGE_HEADER = "Here is your quote";
	private static final String QUOTE_PAGE_HEADER_ALTERNATE = "Here are your quotes";
	private static final String BASIC_PACKAGE = "Basic";
	private static final String ENHANCED_PACKAGE = "Enhanced";
	private static final String FULL_PACKAGE = "Full";
	private static final String CUSTOM_PACKAGE = "Custom";
	private static final String RECALCULATE = "RECALCULATE";
	private static final String RENTERS_SUMMARY_HEADER = "Renters Insurance  for ";

	private static final String QUOTE_PAGE_DISCLOSURE_LONG_PART0 = "This is a preliminary rate (\"quote\") for the insurance you selected. ";
	private static final String QUOTE_PAGE_DISCLOSURE_LONG_PART1 = "This quote is not a policy of insurance or application, offer to insure or binder. "
			+ "Certain assumptions may have been made and this quote reflects rates in effect the day of the quote and are subject to change. "
			+ "Premium may vary based on additional information, coverages and deductibles that you select, underwriting criteria, and any changes to assumptions. ";
	private static final String QUOTE_PAGE_DISCLOSURE_LONG_PART2 = "Farmers reserves the right to accept, reject, or modify this quote after review of an application and other underwriting information. "
			+ "Applications are subject to underwriting approval. ";
	private static final String QUOTE_PAGE_BRISTOL_WEST_DISCLOSURE = QUOTE_PAGE_DISCLOSURE_LONG_PART0 + QUOTE_PAGE_DISCLOSURE_LONG_PART1 + "BristolWest reserves the right to accept, reject, or modify this quote after review of an application and other underwriting information. "
			+ "Applications are subject to underwriting approval. BristolWest online auto quotes are available for new auto customers.";
	private static final String QUOTE_PAGE_DISCLOSURE_PART3 = "Farmers online auto quotes are available for new customers.";
	private static final String QUOTE_PAGE_DISCLOSURE_LONG_PART3 = "Farmers online auto quotes are available for new auto customers.";
	private static final String QUOTE_PAGE_DISCLOSURE_SHORT_PART3 = "Farmers online quotes are available for new customers.";
	private static final String QUOTE_PAGE_DISCLOSURE_ONE = "Based on paying premium automatically from a bank account. Service fees and fees permitted by state law are not shown. Amounts and service fees differ based on pay plan and automatic payment selection.";
	private static final String QUOTE_PAGE_DISCLOSURE_ONE_CA = "Installment plan options may be available. Service fees and fees permitted by state law are not shown. Amounts and service fees differ based on pay plan and automatic payment selection.";
	private static final String QUOTE_PAGE_DISCLOSURE_THREE = QUOTE_PAGE_DISCLOSURE_LONG_PART0 + QUOTE_PAGE_DISCLOSURE_LONG_PART1 + "In order to purchase a policy, information about your spouse may be necessary. "
			+ QUOTE_PAGE_DISCLOSURE_LONG_PART2 + QUOTE_PAGE_DISCLOSURE_PART3;
	private static final String QUOTE_PAGE_DISCLOSURE_THREE_ALTERNATE = QUOTE_PAGE_DISCLOSURE_LONG_PART0 + QUOTE_PAGE_DISCLOSURE_LONG_PART1 + QUOTE_PAGE_DISCLOSURE_LONG_PART2 + QUOTE_PAGE_DISCLOSURE_LONG_PART3;
	private static final String QUOTE_PAGE_DISCLOSURE_THREE_FLEX = QUOTE_PAGE_DISCLOSURE_LONG_PART0 + QUOTE_PAGE_DISCLOSURE_LONG_PART1 + QUOTE_PAGE_DISCLOSURE_LONG_PART2 + QUOTE_PAGE_DISCLOSURE_SHORT_PART3;
	private static final String QUOTE_PAGE_RENTERS_DISCLOSURE = "** This quote is for renters insurance in your zip code based on minimum coverage limits which may vary by state (hypothetical example: $20,000 in personal property, $100,000 in liability), and certain other assumptions about you. "
			+ "A quote is not an offer of, or application for, insurance, nor is it an insurance contract. The quote reflects the rates in effect as of the date of this quote and is subject to revision. Your actual premium may vary based upon additional information you provide or we obtain, the coverages and deductibles that you select, and additional underwriting criteria. "
			+ "Farmers online quotes are for new customers only. Existing customers are requested to contact their local agent to make changes to their policy. Quoted rates do not include fees permitted by state law.";

	// Liabilities
	private static final String ACCIDENTAL_DEATH = "Accidental Death Benefit";
	private static final String ACCIDENTAL_DEATH_BENEFITS = "Accidental Death Benefits";
	private static final String BODILY_INJURY = "Bodily Injury";
	private static final String COMPULSORY_BODILY_INJURY = "Compulsory Bodily Injury";
	private static final String COMPULSORY_BODILY_INJURY_MA = "Compulsory Bodily Injury (Part 1)";
	private static final String OPTIONAL_BODILY_INJURY = "Optional Bodily Injury";
	private static final String OPTIONAL_BODILY_INJURY_MA = "Optional Bodily Injury (Part 5)";
	private static final String ESSENTIAL_SERVICES = "Essential Services";
	private static final String EXTENDED_MEDICAL_PAYMENTS = "Extended Medical Payments";
	private static final String EXTRA_PIP_PACKAGE = "Extra PIP Package";
	private static final String FUNERAL_EXPENSE_BENEFITS ="Funeral Expense Benefits";
	private static final String GUEST_PIP = "Guest PIP";
	private static final String INCOME_CONTINUATION = "Income Continuation";
	private static final String LAWSUIT_OPTION = "Lawsuit Option";
	private static final String MEDICAL_AND_HOSPITAL_BENEFITS = "Medical and Hospital Benefits";
	private static final String MEDICAL_COVERAGE = "Medical Coverage";
	private static final String OPTIONAL_PIP = "Optional PIP";
	private static final String OPTIONAL_PERSONAL_INJURY_PROTECTION_NO_FAULT_COVERAGE = "Optional Personal Injury Protection/No Fault Coverage";
	private static final String PERMISSIVE_USER_LIMIT = "Permissive User Limit of Liability";
	private static final String PERSONAL_INJURY_DEDUCTIBLE_PROTECTION_EXCLUSION = "Personal Injury Protection - Exclusion of Work Loss";
	private static final String PERSONAL_INJURY_PROTECTION = "Personal Injury Protection";
	private static final String PERSONAL_INJURY_PROTECTION_MA = "Personal Injury Protection (Part 2)";
	private static final String PERSONAL_INJURY_PROTECTION_DEDUCTIBLE = "Personal Injury Protection - Deductible";
	private static final String PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO = "Personal Injury Protection - Deductible Applies To";
	private static final String PERSONAL_INJURY_PROTECTION_NO_FAULT_COVERAGE = "Personal Injury Protection/No Fault Coverage";
	private static final String PRINCIPAL_PIP = "Principal PIP";
	private static final String PRINCIPAL_PIP_MEDICAL_EXP_ONLY = "Principal PIP - Med Exp Only";
	private static final String PROPERTY_DAMAGE_LIABILITY = "Property Damage Liability";
	private static final String RENTAL_REIMBURSEMENT = "Rental Reimbursement";
	private static final String TORT = "Tort";
	private static final String UNDER_INSURED_MOTORIST = "Under Insured Motorist";
	private static final String UNDER_INSURED_MOTORIST_BODILY_INJURY = "Under Insured Motorist Bodily Injury";
	private static final String UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING = "Underinsured Motorist Bodily Injury - Stacking Option";
	private static final String UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE = "Under Insured Motorist Property Damage";
	private static final String UNDERINSURED_MOTORIST = "Underinsured Motorist";
	private static final String UNDERINSURED_MOTORIST_BI = "Underinsured Motorist BI";
	private static final String UNDERINSURED_MOTORIST_BODILY_INJURY = "Underinsured Motorist Bodily Injury";
	private static final String UNDER_CAP_INSURED_MOTORIST_BODILY_INJURY = "UnderInsured Motorist Bodily Injury";
	private static final String UNDERINSURED_MOTORIST_BODILY_INJURY_MA = "Underinsured Motorist Bodily Injury (Part 12)";
	private static final String UNDERINSURED_MOTORIST_PROPERTY_DAMAGE = "Underinsured Motorist Property Damage";
	private static final String UNINSURED_MOTORIST = "Uninsured Motorist";
	private static final String UNINSURED_MOTORIST_BI = "Uninsured Motorist BI";
	private static final String UNINSURED_MOTORIST_BI_OPTIONS = "Uninsured Motorist BI Options";
	private static final String UNINSURED_MOTORIST_BI_LOWERCASE_OPTIONS = "Uninsured Motorist BI options";
	private static final String UNINSURED_MOTORIST_BODILY_INJURY = "Uninsured Motorist Bodily Injury";
	private static final String UNINSURED_MOTORIST_DASH_BODILY_INJURY = "Uninsured Motorist - Bodily Injury";
	private static final String UNINSURED_MOTORIST_BODILY_INJURY_MA = "Uninsured Motorist Bodily Injury (Part 3)";
	private static final String UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION = "Uninsured Motorist Bodily Injury - Stacking Option";
	private static final String UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING = "Uninsured Motorist Bodily Injury - Without Stacking";
	private static final String UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI = "Uninsured Motorist/Underinsured Motorist BI";
	private static final String UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY = "Uninsured Motorist/Underinsured Motorist Bodily Injury";
	private static final String UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI = "Uninsured Motorist / Under Insured Motorist BI";
	private static final String UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION = "Uninsured Motorist / Under Insured Motorist BI Conversion";
	private static final String UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY = "Uninsured Motorist/Under Insured Motorist Bodily Injury";
	private static final String UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE = "Uninsured Motorist/Underinsured Motorist Property Damage";
	private static final String UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PD = "Uninsured Motorist/Underinsured Motorist PD";
	private static final String UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE = "Uninsured Motorist/Under Insured Motorist Property Damage";

	private static final String ACCIDENTAL_DEATH_BENEFITS_HELP_TEXT = "A death benefit will be paid if bodily injury from an accident causes the death of an insured.";
	private static final String ACCIDENTAL_DEATH_HELP_TEXT ="Accidental Death coverage ensures that your family is paid the selected amount of money if a death occurs as a direct result of an accident.";
	private static final String BODILY_INJURY_HELP_TEXT = "If you are legally obligated to pay damages due to bodily injury to others, and the injury occurred due to a covered loss, this coverage will pay damages. If you are sued because of a covered automobile loss, the cost of your legal defense is also covered. The limits chosen are the maximum the company will pay for any single occurrence, per policy (not per vehicle). The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String COMPULSORY_BODILY_INJURY_HELP_TEXT = "If you are legally obligated to pay damages due to bodily injury to others, and the injury occurred due to a covered accident, this coverage will pay damages. If you are sued because of a covered automobile accident, the cost of your legal defense is also covered. The limit is the maximum the company will pay for any single occurrence, per policy (not per auto). "
			+ "Compulsory Bodily Injury is mandatory in the state of MA. Compulsory Bodily Injury coverage does not pay for injuries to the driver or passengers in your auto. Compulsory Bodily Injury only covers accidents that occur in MA. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String OPTIONAL_BODILY_INJURY_HELP_TEXT = "Additional coverage for bodily injury to others, providing bodily injury coverage for passengers in your auto, and covering you if the accident occurs outside Massachusetts. The limit is the maximum the company will pay for any single occurrence, per policy (not per auto). The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String ESSENTIAL_SERVICES_HELP_TEXT = "Pays for necessary services that you (an insured) normally do yourself, such as cleaning your house, mowing your lawn, shoveling snow or doing laundry, if you are injured in an auto accident.";
	private static final String FUNERAL_EXPENSE_BENEFITS_HELP_TEXT = "Funeral or burial expenses incurred will be paid if bodily injury causes the death of an insured.";
	private static final String GUEST_PIP_HELP_TEXT= "Selecting Guest PIP will waive PIP Coverage for the named insured, all listed drivers on the policy and any members of the insured's family who are 16 years of age or older and reside in the insured's household. In a new customer quote in Express, you must select either Personal Injury Protection (PIP), or Guest PIP";
	private static final String INCOME_CONTINUATION_HELP_TEXT = "Coverage for lost wages if you cannot work due to accident-related injuries.";
	private static final String LAWSUIT_OPTION_HELP_TEXT = "No Limit coverage gives you the right to sue the person who caused an auto accident for pain and suffering for any injury.";
	private static final String MEDICAL_AND_HOSPITAL_BENEFITS_HELP_TEXT = "Provide benefits for bodily injury to each person injured in a no-fault motor vehicle accident. Benefits typically include reasonable medical and hospital expenses, loss of income, essential services, accidental death, and funeral services.";
	private static final String MEDICAL_COVERAGE_HELP_TEXT = "Medical coverage pays reasonable expenses incurred by the insured or passengers within three years from the date of accident for necessary medical services and funeral expenses. Medical payment coverage is afforded regardless of fault. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String MEDICAL_COVERAGE_HELP_TEXT_MA = "Medical coverage pays reasonable expenses incurred by the insured or passengers within two years from the date of accident for necessary medical services and funeral expenses. Medical payment coverage is afforded regardless of fault. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String OPTIONAL_PIP_HELP_TEXT = "Provides additional PIP/No Fault limits for medical coverage for injuries you or your passengers suffer in an auto accident, as well as reimbursement for certain expenses you incur when you are hurt, such as lost wages and hiring someone to take care of your home or family. For more information about this coverage, please contact our customer care center at 1-888-767-4030.";
	private static final String PERMISSIVE_USER_LIMIT_HELP_TEXT = "This coverage allows you to select full or limited liability coverage for permissive users of your insured car(s). Full Permissive User Coverage provides the liability limits you have selected for permissive users of your insured car(s). Limited Permissive User Coverage reduces vehicle liability limits to $15,000 bodily injury liability coverage per person, $30,000 bodily injury liability coverage per accident and $5,000 property damage coverage per accident for permissive users of your insured car(s). " +
			"Limited Permissive User Coverage is not available when bundling your auto policy with Umbrella insurance. " +
			"A permissive driver is someone who might operate your insured car on an incidental basis, who is not you, a family member or someone listed on your policy to operate your insured car.";
	private static final String PERSONAL_INJURY_DEDUCTIBLE_PROTECTION_EXCLUSION_HELP_TEXT = "Excludes coverage for lost wages caused by a covered accident.";
	private static final String PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO_HELP_TEXT = "The \"Personal Injury Protection Deductible Applies to\" line on your policy indicates who that deductible applies to, either just the named insured or the named insured and dependents as well.";
	private static final String PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_HELP_TEXT = "The Personal Injury Protection (PIP) deductible is that portion of the PIP loss that is not paid by insurance. It is subtracted from the amount the insurer would be obligated to pay.";
	private static final String PERSONAL_INJURY_PROTECTION_HELP_TEXT = "Personal Injury Protection (PIP) provides no fault benefits for bodily injury to each insured person injured in an accident. Benefits typically include reasonable medical and hospital expenses, loss of income, essential services, accidental death, and funeral services. Coverage varies by state and is subject to conditions and limitations. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String PERSONAL_INJURY_PROTECTION_HELP_TEXT_MA = "Personal Injury Protection (PIP) provides no fault benefits for bodily injury to each insured person injured in an accident. Benefits include reasonable medical expenses, lost wages, and replacement services. Coverage varies by state and is subject to conditions and limitations. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String PERSONAL_INJURY_PROTECTION_ALTERNATE_HELP_TEXT = "Personal Injury Protection, also known as No-Fault Coverage, provides medical coverage for injuries you or your passengers suffer in an auto accident, as well as reimbursement for certain expenses you incur when you are hurt, such as lost wages and hiring someone to take care of your home or family. This coverage is provided regardless of fault. " +
			"Personal Injury Protection/No-Fault Coverage: " +
			"Your coverage selection will default to \"Accept No Fault PIP.\" If you choose to reject PIP/No Fault coverage, Kentucky law requires you to complete the Kentucky No Fault Rejection form. To obtain this form, you must call Farmers at 888-767-4030 to reject the coverage, and we will send you a Kentucky No Fault Rejection Form. You must then submit a completed and signed Kentucky No Fault Rejection Form to the Kentucky Department of Insurance. " +
			"Your premium may be higher due to your rejection of No Fault coverage, as others will have the same right to sue you for their injuries.If you reject PIP/No Fault coverage, we are required to add Guest PIP/No Fault coverage to provide no fault coverage to passengers in your insured vehicle(s). Guest PIP/No Fault provides no coverage for you and your household residents. " +
			"For more information about this coverage, please contact our customer care center at 1-888-767-4030.";
	private static final String PRINCIPAL_PIP_HELP_TEXT = "Provides medical coverage for injuries you or your passengers suffer in an auto accident, as well as reimbursement for certain expenses you incur when you are hurt, such as lost wages and hiring someone to take care of your home or family.";
	private static final String PRINCIPAL_PIP_MEDICAL_HELP_TEXT = "Provides medical coverage for injuries you or your passengers suffer in an auto accident.";
	private static final String PROPERTY_DAMAGE_LIABILITY_HELP_TEXT = "If you are found legally responsible for accidental property damage to someone else's property, Property Damage Liability pays for damages caused by you or the driver of your car. This coverage pays for the repairs to the property, up to the limit of coverage chosen by you. If you are sued because of the accident, this coverage also covers the cost of your legal defense. The limits chosen are per policy (not per vehicle). The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String PROPERTY_DAMAGE_LIABILITY_HELP_TEXT_MA = "If you are found legally responsible for accidental property damage to someone else's property, Property Damage Liability pays for damages caused by you or the driver of your auto. This coverage pays for the repairs to the property, up to the limit of coverage chosen by you. If you are sued because of the accident, this coverage also covers the cost of your legal defense. The limits chosen are per policy (not per auto). The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String RENTAL_REIMBURSEMENT_HELP_TEXT = "This coverage reimburses the insured for the lesser of actual daily rental charges or the purchased limit option for a maximum of 30 days for each qualified disablement on a covered vehicle. A qualified disablement means a loss covered by the Comprehensive or Collision sections of the policy. Rental Reimbursement may be purchased for any vehicle covered by Comprehensive and Collision coverages. The limit options shown in Express are per day amounts.";
	private static final String RENTAL_REIMBURSEMENT_HELP_TEXT_NC = "This coverage reimburses the insured for the lesser of actual daily transportation expenses or the purchased limit option for a maximum of 30 days for each qualified disablement on a covered auto. A qualified disablement means a loss covered by the Comprehensive sections of the policy. The limit options shown are based on the daily limit and total limits.";
	private static final String TORT_HELP_TEXT = "This coverage limits your right to seek financial compensation for injuries caused by other drivers.";
	private static final String UNDERINSURED_MOTORIST_BODILY_INJURY_HELP_TEXT = "This policy option covers injuries to you or your passengers in an accident if the other party is at fault and doesn't have insurance or has an insufficient amount of insurance.";
	private static final String UNDERINSURED_MOTORIST_HELP_TEXT = "This policy option covers injuries to the insured or their passengers if the other party is at fault and has an insufficient amount of insurance. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_HELP_TEXT = "This policy option covers the property of the insured if the other party is at fault and doesn't have insurance or has an insufficient amount of insurance.";
	private static final String UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_HELP_TEXT = "The insured has the option of increasing the limits for UIM coverage from the selected vehicle limit, to an amount equal the sum of all UIM limits from each vehicle on the policy. Rejecting the stacking option will cause the premium to be lower.";
	private static final String UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_HELP_TEXT = "This policy option covers injuries to the insured or their passengers if the other party is at fault and has either no or insufficient amount of insurance. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String UNINSURED_MOTORIST_HELP_TEXT = "This coverage pays you the amount you are legally entitled to from damages for bodily injury, up to the limit of liability, when you are hit by an uninsured driver or an unidentified (e.g. hit-and-run) driver. Uninsured Motorist limits cannot be higher than Bodily Injury limits. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String UNINSURED_MOTORIST_BI_HELP_TEXT = "This coverage pays you the amount you are legally entitled to from damages for bodily injury, up to the limit of liability, when you are hit by an uninsured driver or an unidentified (e.g. hit-and-run) driver. Uninsured Motorist Bodily Injury limits cannot be higher than Bodily Injury limits. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String UNINSURED_LA_MOTORIST_BI_HELP_TEXT = "The full option covers monetary damages like medical costs, funeral expenses and lost wages. It also covers non-monetary damages like pain and suffering and mental anguish. The economic option only covers monetary damages.";
	private static final String UNINSURED_MOTORIST_BODILY_INJURY_STACKING_HELP_TEXT = "The insured has the option of increasing the limits for UM coverage from the selected vehicle limit, to an amount equal the sum of all UM limits from each vehicle on the policy. Rejecting the stacking option will cause the premium to be lower..";
	private static final String UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_HELP_TEXT = "This policy option covers injuries to you or your passengers in an accident if the other party is at fault and has an insufficient amount of insurance.";
	private static final String UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_HELP_TEXT = "An uninsured or underinsured motorist property damage policy can help pay for repairs to your vehicle if it is damaged when it is struck by an uninsured driver, a hit-and-run driver, or an insured driver whose property damage liability limit is not enough to cover the full amount of property damage losses incurred.";
	private static final String UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_HELP_TEXT = "An uninsured or underinsured motorist property damage policy can help pay for repairs to your vehicle if it is damaged when it is struck by an uninsured driver or an insured driver whose property damage liability limit is not enough to cover the full amount of property damage losses incurred. The coverage is a subject to $100 deductible per insured.";

	//Coverages
	private static final String COLLISION = "Collision";
	private static final String COLLISION_MA = "Collision (Part 7)";
	private static final String COLLISION_PLUS_LOSS_OF_USE = "Collision Plus/Loss of Use";
	private static final String COLLISION_PLUS_LOSS_OF_USE_K5 = "Collision Plus/Loss of Use K5";
	private static final String COMPREHENSIVE = "Comprehensive";
	private static final String COMPREHENSIVE_MA = "Comprehensive (Part 9)";
	private static final String DEATH_BENEFIT = "Death Benefit";
	private static final String EXTRA_PIP_PACKAGE_FOR_FAMILY = "Extra PIP Package for Primary Insured, Spouse & Resident Relatives";
	private static final String FUNERAL_EXPENSES = "Funeral Expenses";
	private static final String GLASS_DEDUCTIBLE_BUYBACK = "Glass Deductible Buyback";
	private static final String GLASS_100_COVERAGE = "$100 Glass Coverage";
	private static final String GLASS_100_DEDUCTIBLE = "$100 Glass Deductible";
	private static final String HEALTH_INSURER_PRIMARY = "Health Insurer Primary for PIP";
	private static final String INCOME_DISABILITY = "Income Disability";
	private static final String INCOME_LOSS = "Income Loss";
	private static final String LIMITED_COLLISION = "Limited Collision";
	private static final String LIMITED_COLLISION_MA = "Limited Collision (Part 8)";
	private static final String LOSS_OF_USE = "Loss of Use";
	private static final String MEDICAL = "Medical";
	private static final String MEDICAL_EXPENSE_COVERAGE = "Medical Expense Coverage";
	private static final String MEDICAL_PAYMENTS = "Medical Payments";
	private static final String MEDICAL_PAYMENTS_MA = "Medical Payments (Part 6)";
	private static final String PROPERTY_DAMAGE = "Property Damage";
	private static final String PROPERTY_DAMAGE_MA = "Property Damage (Part 4)";
	private static final String RENTAL = "Rental";
	private static final String RIDESHARE = "Rideshare";
	private static final String RIDESHARE_AND_FOOD_DELIVERY = "Rideshare and Food Delivery";
	private static final String ROADSIDE_ASSISTANCE = "Roadside Assistance";
	private static final String SAFETY_GLASS_WAIVER_OF_DEDUCTIBLE = "Safety Glass - Waiver Of Deductible";
	private static final String SAFETY_GLASS_WAIVER_OF_DEDUCTIBLE_SHORT_DASH_LOWERCASE_OF = "Safety Glass - Waiver of Deductible";
	private static final String SUBSTITUTE_TRANSPORTATION = "Substitute Transportation";
	private static final String SUBSTITUTE_TRANSPORTATION_MA = "Substitute Transportation (Part 10)";
	private static final String TOWING_AMP_ROAD_SERVICE = "Towing & Road Service";
	private static final String TOWING_AND_LABOR = "Towing and Labor";
	private static final String TOWING_AND_LABOR_MA = "Towing and Labor (Part 11)";
	private static final String TOWING_AND_LABOR_COSTS = "Towing and Labor Costs";
	private static final String TOWING_AND_ROAD_SERVICE = "Towing and Road Service";
	private static final String UNINSURED_MOTORIST_PD = "Uninsured Motorist PD";
	private static final String UNINSURED_MOTORIST_PD_WITHOUT_COLLISION = "Uninsured Motorist PD without collision";
	private static final String UNINSURED_MOTORIST_PD_WITHOUT_UPPERCASE_COLLISION = "Uninsured Motorist PD without Collision";
	private static final String UNINSURED_MOTORIST_PROPERTY_DAMAGE = "Uninsured Motorist Property Damage";
	private static final String UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITHOUT_COLLISION = "Uninsured Motorist Property Damage without Collision";
	private static final String UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITH_COLLISION = "Uninsured Motorist Property Damage with Collision";
	private static final String VEHICLE_REPLACEMENT_PLUS = "Vehicle Replacement Plus";
	private static final String WAIVER_OF_WORK_LOSS = "Waiver of Work Loss";

	private static final String COLLISION_HELP_TEXT = "Collision provides coverage for physical damage to the car caused by collision with another vehicle or object. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String COLLISION_HELP_TEXT_MA = "Collision provides coverage for physical damage to the auto caused by collision with another vehicle or object regardless of fault. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String COLLISION_PLUS_LOSS_OF_K5_USE_HELP_TEXT = "Coll.plus/Loss of use K5 coverage reimburses for expenses incurred from a Collision or Comprehensive loss. If a loss occurs more than 50 miles from home, this coverage also pays for expenses related to returning or retrieving the repaired car. In the case of a car theft, this coverage pays an additional daily amount in excess of the amount provided in a standard policy. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String COLLISION_PLUS_LOSS_OF_USE_HELP_TEXT = "Collision Plus/Loss of Use coverage reimburses for expenses incurred from a Collision or Comprehensive loss. If a loss occurs more than 50 miles from home, this coverage also pays for expenses related to returning or retrieving the repaired car. In the case of a car theft, this coverage pays an additional daily amount in excess of the amount provided in a standard policy. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String COMPREHENSIVE_HELP_TEXT = "Comprehensive covers losses from things other than an accident like vandalism, riots, floods, hail, fire, animal collisions and theft.";
	private static final String DEATH_BENEFIT_HELP_TEXT = "A death benefit will be paid if bodily injury from an accident causes the death of an insured.";
	private static final String EXTENDED_MEDICAL_PAYMENTS_HELP_TEXT = "Provides medical coverage for injuries you or your passengers suffer in an auto accident as the result of occupying a non-owned auto.";
	private static final String EXTRA_PIP_PACKAGE_HELP_TEXT = "If you have selected Principal PIP coverage, this package provides higher limits on Income Continuation, Essential Services, Death Benefit and Funeral Expense coverages.";
	private static final String EXTRA_PIP_PACKAGE_FOR_FAMILY_HELP_TEXT = "If you have selected Principal PIP coverage, this package provides higher limits on Income Continuation, Essential Services, Death Benefit and Funeral Expense coverages.";
	private static final String FUNERAL_EXPENSES_HELP_TEXT = "Funeral or burial expenses incurred will be paid if bodily injury causes the death of an insured.";
	private static final String GLASS_DEDUCTIBLE_BUYBACK_HELP_TEXT = "This coverage allows you to reduce the Comprehensive deductible to $100 when the loss is restricted to glass. (This option is not available if the deductible is already $100). The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String HEALTH_INSURER_PRIMARY_HELP_TEXT = "Provides medical coverage for injuries you (and others) suffer in an auto accident. PIP pays if you or other persons covered under your policy are injured in an auto accident. You can select either the Auto Insurance policy or your Health Insurance policy to be the primary source of coverage. You can receive a reduction in premium by using your own health insurance as a primary source of coverage in the case of injury related to an auto accident. Before selecting this option, you should find out if your health insurance will cover auto accident injuries and how much coverage is provided. MEDICARE and MEDICAID cannot be used for the Health Insurance Primary option (Most consumers do not choose their own health insurer).";
	private static final String INCOME_DISABILITY_HELP_TEXT = "When income is interrupted or terminated because of illness, sickness, or accident, Income Disability coverage pays up to 70% of the insured person's income. Coverages vary by state and are subject to conditions and limitations. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String INCOME_LOSS_HELP_TEXT = "If you are injured, this coverage pays up to 80% of your lost income, including payments for reasonable expenses incurred to hire someone to do your job (if you are self-employed) or to hire someone to help you work. The coverage only pays if it reduces loss of gross income, subject to the limits available.";
	private static final String LIMITED_COLLISION_HELP_TEXT = "Limited Collision provides coverage for physical damage to the auto caused by collision with another vehicle or object if you are not at fault. If you are more than 50% at fault, or the owner of the other auto cannot be identified, you will not receive payment. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String LOSS_OF_USE_HELP_TEXT = "With this option, Farmers will provide a flat sum for cabs, public transit or a rental while your car has a qualified disablement that's covered by your policy's comprehensive or collision coverage.";
	private static final String MEDICAL_EXPENSE_COVERAGE_HELP_TEXT = "Medical expense coverage pays reasonable expenses incurred by the insured or passengers within three years from the date of accident for necessary medical services and funeral expenses. Medical expense coverage is afforded regardless of fault. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String RENTAL_COVERAGE_HELP_TEXT = "This coverage provides reimbursement for your daily rental charges, including tax, up to the per day limit shown on your Declarations Page for a maximum of 30 days that result from a covered loss. You must utilize the appropriate coverage on your policy for Rental Coverage to apply. Rental Coverage starts the day the car is taken to a garage to begin repairs. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String RENTAL_COVERAGE_ALTERNATE_HELP_TEXT = "For losses covered by Comprehensive or Collision coverage, Rental Reimbursement will repay the daily rental charges up to the purchased limit option for a maximum of 30 days.";
	private static final String ROADSIDE_ASSISTANCE_HELP_TEXT = "If your insured car becomes disabled and you need help, we provide two tiers of Roadside Assistance coverage, Standard Roadside Assistance and Enhanced Roadside and Ride Assistance. Both options include the reasonable and necessary towing and labor costs related to a disablement. Our Enhanced Roadside and Ride Assistance provides for additional disablements per policy period, up to 100 mi of towing, mobile battery testing and installation (less the cost of the battery) and up to $25 in alternative transportation from a disablement. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String RIDESHARE_HELP_TEXT = "Farmers offers specific ridesharing coverage in select states. This policy enables you to select the coverage that fits your needs, including: " +
			"Comprehensive and collision coverages that help pay for damages to your car "+
			"Uninsured motorist coverage, in case you are hit by a driver who isn't insured or is underinsured " +
			"Medical payment and personal injury protection (if required).";
	private static final String RIDESHARE_AND_FOOD_DELIVERY_HELP_TEXT = "This coverage is available if you earn up to $25,000 while working part-time doing rideshare or on-demand food delivery. While ridesharing, coverage is provided from the time when you're available to receive requests to the time you're engaged in a prearranged ride. Once the prearranged ride has begun, it extends limited coverage. " +
			"During on-demand food delivery we will extend the coverages shown on your Declarations Page from the time you're available to receive on-demand food delivery requests to the time you're engaged in a prearranged delivery. Once the delivery has begun, limited coverage and a minimum deductible will apply. " +
			"In the event of a covered loss while doing rideshare or on-demand food delivery, limited property damage coverage for your business personal property and limited loss of business income may be available. " +
			"The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String SAFETY_GLASS_WAIVER_OF_DEDUCTIBLE_HELP_TEXT = "Glass deductible buyback option allows you to reduce the Comprehensive deductible to $100 in the case of a glass only loss (not available if deductible is already $100). The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String SAFETY_GLASS_WAIVER_OF_DEDUCTIBLE_AZ_HELP_TEXT = "This coverage/endorsement allows you to cover the glass equipment losses. It may be purchased for any vehicle covered by Comprehensive coverage. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String SAFETY_GLASS_WAIVER_OF_DEDUCTIBLE_IL_HELP_TEXT = "This coverage allows you to reduce your Comprehensive deductible to $100 for a loss to your insured vehicle's glass. (This option is not available if your deductible is already $100). The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String SUBSTITUTE_TRANSPORTATION_HELP_TEXT = "This coverage reimburses the insured for the lesser of actual daily rental charges or the purchased limit option for a maximum of 30 days for each qualified disablement on a covered auto. A qualified disablement means a loss covered by the Comprehensive or Collision sections of the policy. The limit options shown are per day amounts.";
	private static final String TOWING_AND_LABOR_HELP_TEXT = "This coverage reimburses the insured for the cost of towing a disabled vehicle and is only available with collision coverage. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String TOWING_AND_ROAD_SERVICE_HELP_TEXT = "Covers reasonable and necessary towing and labor costs incurred because of disablement of an insured car.";
	private static final String UNINSURED_MOTORIST_PROPERTY_DAMAGE_HELP_TEXT = "This policy option covers the property of the insured if the party at fault is uninsured or under-insured. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String UNINSURED_MOTORIST_PD_WITHOUT_COLLISION_HELP_TEXT = "If the other party is at fault and does not have a sufficient amount of insurance, this policy option covers the property of the insured. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITHOUT_COLLISION_HELP_TEXT = "Uninsured motorist property damage coverage is an optional auto insurance coverage. It is not available if collision coverage is selected. This coverage provides protection for physical damages sustained in an accident caused by a driver who is not insured.";
	private static final String VEHICLE_REPLACEMENT_PLUS_HELP_TEXT = "Coverage includes Replacement Provisions for both New and Newer Cars and Loan or Lease Gap Coverage (if applicable). New Car Replacement applies to vehicles that are two model years old or newer with up to 24,000 miles. Newer Car Replacement provides replacement with a vehicle one model year newer with 20,000 less miles for vehicles that are more than two model years old or have more than 24,000 miles. For financed vehicles, Loan or Lease Gap Coverage will cover the difference between a total loss settlement and the remaining debt to the lienholder or lessor, less any applicable deductible. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
	private static final String WAIVER_OF_WORK_LOSS_HELP_TEXT = "Waiving Work Loss coverage removes weekly income replacement coverage for the drivers named on your policy." + NEWLINE + NEWLINE +
			"Select \"Yes\" if you want to waive this coverage. Select \"No\" if you want to keep this coverage." + NEWLINE + NEWLINE +
			"This is available for drivers age 60-65 who are retired and receiving pensions, or drivers age 65+ who receive no wages. If you have only one vehicle in your household, all named drivers must qualify. If you have multiple vehicles, at least one driver must qualify." + NEWLINE + NEWLINE +
			"If you waive Work Loss coverage for the named drivers on your policy, the Work Loss deductible for other people must be $0.";

	//Liabilities help text yet to be discovered
	private static final String UNDER_INSURED_MOTORIST_BODILY_INJURY_HELP_TEXT = "UNDER_INSURED_MOTORIST_BODILY_INJURY_HELP_TEXT";
	private static final String UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_HELP_TEXT = "UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_HELP_TEXT";
	private static final String UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_HELP_TEXT = "UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_HELP_TEXT";
	private static final String UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING_HELP_TEXT = "UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING_HELP_TEXT";

	//Discounts
	private static final String AUTO_AMP_BUSINESS = "Auto & Business";
	private static final String AUTO_AMP_HOME = "Auto & Home";
	private static final String AUTO_AMP_LIFE = "Auto & Life";
	private static final String AUTO_AMP_RENT = "Auto & Rent";
	private static final String AUTO_AMP_UMBRELLA = "Auto & Umbrella";
	private static final String ACCIDENT_FREE_DISCOUNT = "Five Year Accident Free";
	private static final String AUTOPAY_DISCOUNT = "Auto Pay";
	private static final String BUSINESS_GROUP_DISCOUNT = "Business/Professional Group";
	private static final String BUSINESS_GROUP_DISCOUNT_ERROR_MSG = "Business/Professional Group discount found for the occupation: ";
	private static final String DISTANT_STUDENT_DISCOUNT = "Distant Student";
	private static final String EFT_DISCOUNT = "Electronic Funds Transfer";
	private static final String GOOD_PAYER_DISCOUNT = "Good Payer";
	private static final String GOOD_STUDENT_DISCOUNT = "Good Student";
	private static final String HOMEOWNER = "Homeowner";
	private static final String MULTI_CAR_DISCOUNT = "Multi-Car Discount Across Company";
	private static final String MULTIPLE_CAR_DISCOUNT = "Multiple Car";
	private static final String PAPERLESS_DISCOUNT = "Paperless";
	private static final String SENIOR_DISCOUNT = "Senior Defensive Driver";
	private static final String MATURE_DRIVER_DISCOUNT = "Mature Driver";
	private static final String DRIVER_IMPROVEMENT_DISCOUNT = "Driver Improvement";
	private static final String SHARED_FAMILY_CAR_DISCOUNT = "Shared Family";
	private static final String SIGNAL_DISCOUNT = "Signal";
	private static final String WELCOME_DISCOUNT = "Welcome";
	private static final String EXPECTED_TO_BE = " discount";
	private static final int SHARED_DRIVER_AGE = 20;

	//Dependency validation error messages
	private static final String COLOR_ERROR_MSG = " color ";
	private static final String GLASS_COVERAGE_REQUIRES_COMP = "You must have Comprehensive coverage with a deductible of more than $100 to select $100 Glass Coverage.";
	private static final String MEDICAL_COVERAGE_AND_PIP_ERRORMSG = "Medical Coverage and Personal Injury Protection cannot be selected simultaneously.";
	private static final String RENTAL_REQUIRES_COMP_AND_COLL = "Comprehensive and Collision coverages are required to select Rental coverage.";
	private static final String UMPD_AND_PD_ERRORMSG = "The Uninsured Motorist Property Damage limit selected cannot exceed the Property Damage limit.";
	private static final String UMPD_AND_PD_ERRORMSG_OH = "Uninsured Motorist Property Damage cannot be selected with Collision coverage.";
	private static final String UNDERINSURED_MOTORIST_LIMIT_ERRORMSG = "Underinsured Motorist limit selected cannot exceed the Bodily Injury limit.";
	private static final String UNDERINSURED_MOTORIST_LIMIT_EQUAL_TO_UNINSURED_MOTORIST_LIMIT_ERRORMSG = "Uninsured Motorist Bodily Injury limit should be equal to Underinsured Motorist Bodily Injury limit.";
	private static final String UNDERINSURED_MOTORIST_BI_SELECTED_ERRORMSG = "Underinsured Motorist Bodily Injury selected cannot exceed the Bodily Injury limit.";
	private static final String UNDERINSURED_MOTORIST_BI_LIMIT_SELECTED_ERRORMSG = "Underinsured Motorist Bodily Injury limit selected cannot exceed the Bodily Injury limit.";
	private static final String UNDER_INSURED_MOTORIST_BI_LIMIT_ERRORMSG = "Under Insured Motorist BI selected cannot exceed the Bodily Injury limit.";
	private static final String UNINSURED_MOTORIST_BI_LIMIT_ERRORMSG = "Uninsured Motorist Bodily Injury selected cannot exceed the Bodily Injury limit.";
	private static final String UNINSURED_MOTORIST_LIMIT_ERRORMSG = "The Uninsured Motorist limit selected cannot exceed the Bodily Injury limit.";
	private static final String UUIMBI_CONVERSION_ERRORMSG = "Uninsured/Underinsured Motorist Bodily Injury cannot be selected with Uninsured/Underinsured Motorist Bodily Injury Conversion.";
	private static final String VEHICLE_REPLACEMENT_REQUIRES_COMP_AND_COLL = "Comprehensive and Collision coverages are required to select Vehicle Replacement Plus coverage.";
	private static final String UNDERINSURED_MOTORIST_REQUIRES_UNINSURED_MOTORIST = "Underinsured Motorist Bodily Injury coverage cannot be selected without Uninsured Motorist Bodily Injury coverage.";
	private static final String UNDERINSURED_MOTORIST_CANT_EXCEED_UNINSURED_MOTORIST = "Underinsured Motorist Bodily Injury selected cannot exceed the Uninsured Motorist Bodily Injury limit.";

	// Coverage strings
	private static final String UNDEFINED = " content not defined for: ";
	private static final String NO_COVERAGE = "No Coverage";
	private static final String COVERAGE = "Coverage";
	private static final String NON_STACKING = "Non-stacking";
	private static final String STACKING = "Stacking";
	private static final String FULL = "Full";
	private static final String LIMITED = "Limited";
	private static final String STANDARD_ROADSIDE = "Standard Roadside Assistance";
	private static final String ENHANCED_RAODSIDE = "Enhanced Roadside and Ride Assistance";
	private final List<String> coverageNoCoverage = new ArrayList<>(Arrays.asList(NO_COVERAGE, COVERAGE));

	private static final String _30_DAILY = "$30 per day";
	private static final String _40_DAILY = "$40 per day";
	private static final String _50_DAILY = "$50 per day";
	private static final String _60_DAILY = "$60 per day";
	private static final String _100_DAILY = "$100 per day";

	private static final String _15_DAY_450_TOTAL = "$15 per day / $450 total";
	private static final String _30_DAY_900_TOTAL = "$30 per day / $900 total";
	private static final String _50_DAY_1500_TOTAL = "$50 per day / $1,500 total";
	private static final String _100_DAY_3000_TOTAL = "$100 per day / $3,000 total";

	private static final String _300_WITH_0 = "$300 with $0 Glass Deductible";
	private static final String _500_WITH_0 = "$500 with $0 Glass Deductible";
	private static final String _750_WITH_0 = "$750 with $0 Glass Deductible";
	private static final String _1000_WITH_0 = "$1,000 with $0 Glass Deductible";
	private static final String _1500_WITH_0 = "$1,500 with $0 Glass Deductible";
	private static final String _2500_WITH_0 = "$2,500 with $0 Glass Deductible";
	private static final String _300_WITH_100 = "$300 with $100 Glass Deductible";
	private static final String _500_WITH_100 = "$500 with $100 Glass Deductible";
	private static final String _750_WITH_100 = "$750 with $100 Glass Deductible";
	private static final String _1000_WITH_100 = "$1,000 with $100 Glass Deductible";
	private static final String _1500_WITH_100 = "$1,500 with $100 Glass Deductible";
	private static final String _2500_WITH_100 = "$2,500 with $100 Glass Deductible";

	@FindBy(id = "auto-module_header-title")
	private WebElement quotePageHeader;

	@FindBy(className = "quote-module_title-description-text")
	private WebElement quotePageDescription;

	@FindBy(id = "auto-quote_header-title")
	private WebElement packageHeader;

	@FindBy(className = "auto-quote-description-text")
	private WebElement packageDescription;

	private static final String VIEW_ALL_PACKAGES_XPATH= "//a[@id='auto-renters-package-link' and contains(@aria-label, 'View All Packages')]";
	@FindBy(xpath = VIEW_ALL_PACKAGES_XPATH)
	private WebElement viewAllPackagesLink;

	private static final String ACTION_BUTTON_XPATH= "//button[@id='auto-quote_quoteBtn' and @aria-label]";
	@FindBy(xpath = ACTION_BUTTON_XPATH)
	private WebElement buyNowButton;

	@FindBy(id = "auto-quote-renters_quoteBtn")
	private WebElement quoteRentersButton;

	private static final String QUOTE_RENTERS_PROGRESS_POPUP_CLASSNAME = "quote-renters-progress-popup";
	@FindBy(className = QUOTE_RENTERS_PROGRESS_POPUP_CLASSNAME)
	private WebElement quoteRentersProgressPopup;

	private static final String CALCULATING_SAVINGS_TEXT_XPATH = "//div[contains(@class, 'calculating-savings-text')]";

	@FindBy(id = "summaryquoteSmall")
	private WebElement rentersQuoteSummaryHeader;

	@FindBy(id = "auto-quote_coverageInfoPckAmtSpan")
	private WebElement quoteAmountField;

	@FindBy(className = "auto-quote-red-line")
	private WebElement quoteAmountFieldStruckthrough;

	@FindBy(id = "auto-quote_coverageInfoPCkDura")
	private WebElement quotePeriodField;

	@FindBy(id = "auto-quote-policyFee")
	private WebElement membershipFee;

	@FindBy(className = "auto__quote-your-discounts-header")
	private WebElement discountsListHeader;

	@FindBy(className = "auto__quote-your-discounts-text")
	private List<WebElement> listOfDiscounts;

	@FindBy(xpath = "//div[@id='auto-module__quote-card-text-disclaimer']/label")
	private WebElement disclosureLabel;

	@FindBy(xpath = "//p[contains(@id, 'service-fee-disclaimer1')]")
	private WebElement quotePageDisclosure1;

	@FindBy(id = "service-fee-disclaimer2")
	private WebElement quotePageRentersDisclosure;

	@FindBy(xpath = "//div[@class='disclaimer_txt']//p[contains(text(), 'BristolWest')]")
	private WebElement quotePageDisclosure2;

	@FindBy(xpath = "//p[contains(@id,'FFQAuto_Quote_legalDisclosure3')]")
	private WebElement quotePageDisclosure3;

	@FindBy(xpath = "//div[@class='ffq-quote-liability-coverages-containter']/lib-coverage-panel/mat-accordion/mat-expansion-panel/mat-expansion-panel-header/span/mat-panel-title/div/div[@class='ffq-coverage-panel-coverage-heading']")
	private WebElement liabilityCoverageHeader;

	@FindBy(xpath = "//div[@class='ffq-quote-liability-coverages-containter']/lib-coverage-panel/mat-accordion/mat-expansion-panel")
	private WebElement liabilityCoverageHeaderButton;

	@FindBy(xpath = "//form/lib-coverage-panel/mat-accordion/mat-expansion-panel")
	private WebElement vehicleCoveragesHeaderButton;

	@FindBy(id = "minLogo")
	private WebElement minimizeChatbotDialog;

	private static final String COVERAGE_PACKAGE_XPATH = "//div[@id='auto-quote_package-title' and text()='";
	private static final String BASIC_COVERAGE_PACKAGE = "Basic coverage package']";
	private static final String ENHANCED_COVERAGE_PACKAGE = "Enhanced coverage package']";
	private static final String FULL_COVERAGE_PACKAGE = "Full coverage package']";
	private static final String CUSTOM_COVERAGE_PACKAGE = "Custom coverage package']";

	@FindBy(xpath = COVERAGE_PACKAGE_XPATH + BASIC_COVERAGE_PACKAGE)
	private WebElement basicCoveragePackage;

	@FindBy(xpath = COVERAGE_PACKAGE_XPATH + ENHANCED_COVERAGE_PACKAGE)
	private WebElement enhancedCoveragePackage;

	@FindBy(xpath = COVERAGE_PACKAGE_XPATH + FULL_COVERAGE_PACKAGE)
	private WebElement fullCoveragePackage;

	@FindBy(xpath = COVERAGE_PACKAGE_XPATH + CUSTOM_COVERAGE_PACKAGE)
	private WebElement customCoveragePackage;

	@FindBy(xpath = "//button[@aria-label='Cancel']")
	private WebElement cancelButton;

	@FindBy(xpath = "//button[@aria-label='Confirm']")
	private WebElement confirmButton;

	//factoring out common xpath to elements
	private static final String FROM_FAQ_TO_BASE = "/../../../../";
	private static final String XPATH_TO_LABEL = FROM_FAQ_TO_BASE + "/div[contains(@class, 'ffq-coverage-panel-coverage-item-label')]";
	private static final String XPATH_TO_LABEL_ALTERNATE = "/../../..//div[contains(@class, 'ffq-coverage-panel-coverage-item-label')]";
	private static final String XPATH_TO_DROPDOWN = FROM_FAQ_TO_BASE + "/div[contains(@class, 'ffq-coverage-items-dropdown')]/lib-select/mat-form-field/div/div/div/mat-select";
	private static final String XPATH_TO_DROPDOWN_ALTERNATE = "/../../..//div[contains(@class, 'ffq-coverage-items-dropdown')]/lib-select/mat-form-field/div/div/div/mat-select";
	private static final String XPATH_TO_SUBTOTAL = FROM_FAQ_TO_BASE + "div[@class='coverage-name-amnt-wrapper']/div[contains(@class, 'sub')]";
	private static final String XPATH_TO_ERROR_LABEL = FROM_FAQ_TO_BASE + "/div[contains(@class, 'coverage-error-label')]";
	private static final String XPATH_TO_SUBTOTAL_AMOUNT = XPATH_TO_SUBTOTAL + "/span";
	private static final String XPATH_TO_REFRESH_ICON = XPATH_TO_SUBTOTAL + "/a";
	private static final String XPATH_TO_ERROR_MSG = FROM_FAQ_TO_BASE + "/div[contains(@class, 'coverage-error-msg')]";
	private static final String XPATH_TO_COVERAGE_LIABILITY_AMOUNT = "//div[@class='coverage-name-amnt-wrapper']/div[contains(@class, 'sub')]/span";
	private static final String APP_VEHICLE_COVERAGE_FORM_XPATH = "//app-vehicle-coverage//form[";
	private static final String VEHICLE_NAME_XPATH = "]//mat-expansion-panel-header//div[@class='ffq-coverage-panel-coverage-heading']";

	private static final String ACCIDENTAL_DEATH_FAQ_XPATH = "//a[starts-with(@aria-label,'Accidental Death Benefit info icon')]";
	@FindBy(xpath = ACCIDENTAL_DEATH_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement accidentalDeathLiabilityLabel;
	@FindBy(xpath = ACCIDENTAL_DEATH_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement accidentalDeathLiabilityDropdown;
	@FindBy(xpath = ACCIDENTAL_DEATH_FAQ_XPATH)
	private WebElement accidentalDeathLiabilityFAQ;
	@FindBy(xpath = ACCIDENTAL_DEATH_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement accidentalDeathLiabilityAmount;
	@FindBy(xpath = ACCIDENTAL_DEATH_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement accidentalDeathLiabilityRefreshIcon;

	private static final String ADB_FAQ_XPATH = "//a[starts-with(@aria-label,'Accidental Death Benefits info icon')]";
	@FindBy(xpath = ADB_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement accidentalDeathBenefitsLiabilityLabel;
	@FindBy(xpath = ADB_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement accidentalDeathBenefitsLiabilityDropdown;
	@FindBy(xpath = ADB_FAQ_XPATH)
	private WebElement accidentalDeathBenefitsLiabilityFAQ;
	@FindBy(xpath = ADB_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement accidentalDeathBenefitsLiabilityAmount;
	@FindBy(xpath = ADB_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement accidentalDeathBenefitsLiabilityRefreshIcon;

	private static final String BODILY_INJURY_FAQ_XPATH = "//a[starts-with(@aria-label,'Bodily Injury info icon')]";
	@FindBy(xpath = BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement bodilyInjuryLiabilityLabel;
	@FindBy(xpath = BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement bodilyInjuryLiabilityDropdown;
	@FindBy(xpath = BODILY_INJURY_FAQ_XPATH)
	private WebElement bodilyInjuryLiabilityFAQ;
	@FindBy(xpath = BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement bodilyInjuryLiabilityAmount;
	@FindBy(xpath = BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement bodilyInjuryLiabilityRefreshIcon;
	@FindBy(xpath = BODILY_INJURY_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement bodilyInjuryLiabilityErrorLabel;
	@FindBy(xpath = BODILY_INJURY_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement bodilyInjuryLiabilityErrorMessage;


	private static final String ESSENTIAL_SERVICES_FAQ_XPATH = "//a[starts-with(@aria-label,'Essential Services info icon')]";
	@FindBy(xpath = ESSENTIAL_SERVICES_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement essentialServicesLiabilityLabel;
	@FindBy(xpath = ESSENTIAL_SERVICES_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement essentialServicesLiabilityDropdown;
	@FindBy(xpath = ESSENTIAL_SERVICES_FAQ_XPATH)
	private WebElement essentialServicesLiabilityFAQ;
	@FindBy(xpath = ESSENTIAL_SERVICES_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement essentialServicesLiabilityAmount;
	@FindBy(xpath = ESSENTIAL_SERVICES_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement essentialServicesLiabilityRefreshIcon;

	private static final String EXTENDED_MEDICAL_PAYMENTS_FAQ_XPATH = "//a[starts-with(@aria-label,'Extended Medical Payments info icon')]";
	@FindBy(xpath = EXTENDED_MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement extendedMedicalPaymentsLiabilityLabel;
	@FindBy(xpath = EXTENDED_MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement extendedMedicalPaymentsLiabilityDropdown;
	@FindBy(xpath = EXTENDED_MEDICAL_PAYMENTS_FAQ_XPATH)
	private WebElement extendedMedicalPaymentsLiabilityFAQ;
	@FindBy(xpath = EXTENDED_MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement extendedMedicalPaymentsLiabilityAmount;
	@FindBy(xpath = EXTENDED_MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement extendedMedicalPaymentsLiabilityRefreshIcon;

	private static final String EXTRA_PIP_PACKAGE_FAQ_XPATH = "//a[starts-with(@aria-label,'Extra PIP Package info icon')]";
	@FindBy(xpath = EXTRA_PIP_PACKAGE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement extraPIPPackageLiabilityLabel;
	@FindBy(xpath = EXTRA_PIP_PACKAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement extraPIPPackageLiabilityDropdown;
	@FindBy(xpath = EXTRA_PIP_PACKAGE_FAQ_XPATH)
	private WebElement extraPIPPackageLiabilityFAQ;
	@FindBy(xpath = EXTRA_PIP_PACKAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement extraPIPPackageLiabilityAmount;
	@FindBy(xpath = EXTRA_PIP_PACKAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement extraPIPPackageLiabilityRefreshIcon;
	@FindBy(xpath = EXTRA_PIP_PACKAGE_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement extraPIPPackageLiabilityErrorLabel;
	@FindBy(xpath = EXTRA_PIP_PACKAGE_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement extraPIPPackageLiabilityErrorMessage;

	private static final String FUNERAL_EXPENSE_BENEFITS_FAQ_XPATH = "//a[starts-with(@aria-label,'Funeral Expense Benefits info icon')]";
	@FindBy(xpath = FUNERAL_EXPENSE_BENEFITS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement funeralExpenseBenefitsLiabilityLabel;
	@FindBy(xpath = FUNERAL_EXPENSE_BENEFITS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement funeralExpenseBenefitsLiabilityDropdown;
	@FindBy(xpath = FUNERAL_EXPENSE_BENEFITS_FAQ_XPATH)
	private WebElement funeralExpenseBenefitsLiabilityFAQ;
	@FindBy(xpath = FUNERAL_EXPENSE_BENEFITS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement funeralExpenseBenefitsLiabilityAmount;
	@FindBy(xpath = FUNERAL_EXPENSE_BENEFITS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement funeralExpenseBenefitsLiabilityRefreshIcon;

	private static final String GUEST_PIP_FAQ_XPATH = "//a[starts-with(@aria-label,'Guest PIP info icon')]";
	@FindBy(xpath = GUEST_PIP_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement guestPIPLiabilityLabel;
	@FindBy(xpath = GUEST_PIP_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement guestPIPLiabilityDropdown;
	@FindBy(xpath = GUEST_PIP_FAQ_XPATH)
	private WebElement guestPIPLiabilityFAQ;
	@FindBy(xpath = GUEST_PIP_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement guestPIPLiabilityAmount;
	@FindBy(xpath = GUEST_PIP_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement guestPIPLiabilityRefreshIcon;

	private static final String INCOME_CONTINUATION_FAQ_XPATH = "//a[starts-with(@aria-label,'Income Continuation info icon')]";
	@FindBy(xpath = INCOME_CONTINUATION_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement incomeContinuationLiabilityLabel;
	@FindBy(xpath = INCOME_CONTINUATION_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement incomeContinuationLiabilityDropdown;
	@FindBy(xpath = INCOME_CONTINUATION_FAQ_XPATH)
	private WebElement incomeContinuationLiabilityFAQ;
	@FindBy(xpath = INCOME_CONTINUATION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement incomeContinuationLiabilityAmount;
	@FindBy(xpath = INCOME_CONTINUATION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement incomeContinuationLiabilityRefreshIcon;

	private static final String LAWSUIT_OPTION_FAQ_XPATH = "//a[starts-with(@aria-label,'Lawsuit Option info icon')]";
	@FindBy(xpath = LAWSUIT_OPTION_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement lawsuitOptionLiabilityLabel;
	@FindBy(xpath = LAWSUIT_OPTION_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement lawsuitOptionLiabilityDropdown;
	@FindBy(xpath = LAWSUIT_OPTION_FAQ_XPATH)
	private WebElement lawsuitOptionLiabilityFAQ;
	@FindBy(xpath = LAWSUIT_OPTION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement lawsuitOptionLiabilityAmount;
	@FindBy(xpath = LAWSUIT_OPTION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement lawsuitOptionLiabilityRefreshIcon;

	private static final String MEDICAL_FAQ_XPATH = "//a[starts-with(@aria-label,'Medical info icon')]";
	@FindBy(xpath = MEDICAL_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement medicalLiabilityLabel;
	@FindBy(xpath = MEDICAL_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement medicalLiabilityDropdown;
	@FindBy(xpath = MEDICAL_FAQ_XPATH)
	private WebElement medicalLiabilityFAQ;
	@FindBy(xpath = MEDICAL_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement medicalLiabilityAmount;
	@FindBy(xpath = MEDICAL_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement medicalLiabilityRefreshIcon;
	@FindBy(xpath = MEDICAL_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement medicalLiabilityErrorLabel;
	@FindBy(xpath = MEDICAL_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement medicalLiabilityErrorMessage;

	private static final String MEDICAL_AND_HOSPITAL_FAQ_XPATH = "//a[starts-with(@aria-label,'Medical and Hospital Benefits info icon')]";
	@FindBy(xpath = MEDICAL_AND_HOSPITAL_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement medicalAndHospitalLiabilityLabel;
	@FindBy(xpath = MEDICAL_AND_HOSPITAL_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement medicalAndHospitalLiabilityDropdown;
	@FindBy(xpath = MEDICAL_AND_HOSPITAL_FAQ_XPATH)
	private WebElement medicalAndHospitalLiabilityFAQ;
	@FindBy(xpath = MEDICAL_AND_HOSPITAL_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement medicalAndHospitalLiabilityAmount;
	@FindBy(xpath = MEDICAL_AND_HOSPITAL_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement medicalAndHospitalLiabilityRefreshIcon;

	private static final String MEDICAL_COVERAGE_FAQ_XPATH = "//a[starts-with(@aria-label,'Medical Coverage info icon')]";
	@FindBy(xpath = MEDICAL_COVERAGE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement medicalCoverageLiabilityLabel;
	@FindBy(xpath = MEDICAL_COVERAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement medicalCoverageLiabilityDropdown;
	@FindBy(xpath = MEDICAL_COVERAGE_FAQ_XPATH)
	private WebElement medicalCoverageLiabilityFAQ;
	@FindBy(xpath = MEDICAL_COVERAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement medicalCoverageLiabilityAmount;
	@FindBy(xpath = MEDICAL_COVERAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement medicalCoverageLiabilityRefreshIcon;
	@FindBy(xpath = MEDICAL_COVERAGE_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement medicalCoverageLiabilityErrorLabel;
	@FindBy(xpath = MEDICAL_COVERAGE_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement medicalCoverageLiabilityErrorMessage;

	private static final String MEDICAL_EXPENSE_FAQ_XPATH = "//a[starts-with(@aria-label,'Medical Expense info icon')]";
	@FindBy(xpath = MEDICAL_EXPENSE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement medicalExpenseLabel;
	@FindBy(xpath = MEDICAL_EXPENSE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement medicalExpenseDropdown;
	@FindBy(xpath = MEDICAL_EXPENSE_FAQ_XPATH)
	private WebElement medicalExpenseFAQ;
	@FindBy(xpath = MEDICAL_EXPENSE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement medicalExpenseAmount;
	@FindBy(xpath = MEDICAL_EXPENSE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement medicalExpenseRefreshIcon;

	private static final String OPTIONAL_PIP_FAQ_XPATH = "//a[starts-with(@aria-label,'Optional PIP info icon')]";
	@FindBy(xpath = OPTIONAL_PIP_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement optionalPIPLiabilityLabel;
	@FindBy(xpath = OPTIONAL_PIP_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement optionalPIPLiabilityDropdown;
	@FindBy(xpath = OPTIONAL_PIP_FAQ_XPATH)
	private WebElement optionalPIPLiabilityFAQ;
	@FindBy(xpath = OPTIONAL_PIP_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement optionalPIPLiabilityAmount;
	@FindBy(xpath = OPTIONAL_PIP_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement optionalPIPLiabilityRefreshIcon;

	private static final String PERMISSIVE_USER_LIMIT_FAQ_XPATH = "//a[starts-with(@aria-label,'Permissive User Limit of Liability info icon')]";
	@FindBy(xpath = PERMISSIVE_USER_LIMIT_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement permissiveUserLimitLiabilityLabel;
	@FindBy(xpath = PERMISSIVE_USER_LIMIT_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement permissiveUserLimitLiabilityDropdown;
	@FindBy(xpath = PERMISSIVE_USER_LIMIT_FAQ_XPATH)
	private WebElement permissiveUserLimitLiabilityFAQ;
	@FindBy(xpath = PERMISSIVE_USER_LIMIT_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement permissiveUserLimitLiabilityAmount;
	@FindBy(xpath = PERMISSIVE_USER_LIMIT_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement permissiveUserLimitLiabilityRefreshIcon;

	private static final String PERSONAL_INJURY_PROTECTION_FAQ_XPATH = "//a[starts-with(@aria-label,'Personal Injury Protection info icon')]";
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement personalInjuryProtectionLiabilityLabel;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement personalInjuryProtectionLiabilityDropdown;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_FAQ_XPATH)
	private WebElement personalInjuryProtectionLiabilityFAQ;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement personalInjuryProtectionLiabilityAmount;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement personalInjuryProtectionLiabilityRefreshIcon;

	private static final String PERSONAL_INJURY_PROTECTION_EXCLUSION_FAQ_XPATH = "//a[starts-with(@aria-label,'Personal Injury Protection - Exclusion of Work Loss info icon')]";
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_EXCLUSION_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement personalInjuryProtectionExclusionLiabilityLabel;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_EXCLUSION_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement personalInjuryProtectionExclusionLiabilityDropdown;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_EXCLUSION_FAQ_XPATH)
	private WebElement personalInjuryProtectionExclusionLiabilityFAQ;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_EXCLUSION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement personalInjuryProtectionExclusionLiabilityAmount;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_EXCLUSION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement personalInjuryProtectionExclusionLiabilityRefreshIcon;

	private static final String PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO_FAQ_XPATH = "//a[contains(@aria-label,' Deductible Applies To info icon')]";
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement personalInjuryProtectionDeductibleAppliesToLiabilityLabel;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement personalInjuryProtectionDeductibleAppliesToLiabilityDropdown;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO_FAQ_XPATH)
	private WebElement personalInjuryProtectionDeductibleAppliesToLiabilityFAQ;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement personalInjuryProtectionDeductibleAppliesToLiabilityAmount;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement personalInjuryProtectionDeductibleAppliesToLiabilityRefreshIcon;

	private static final String PRINCIPAL_PIP_FAQ_XPATH = "//a[starts-with(@aria-label,'Principal PIP info icon')]";
	@FindBy(xpath = PRINCIPAL_PIP_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement principalPIPLiabilityLabel;
	@FindBy(xpath = PRINCIPAL_PIP_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement principalPIPLiabilityDropdown;
	@FindBy(xpath = PRINCIPAL_PIP_FAQ_XPATH)
	private WebElement principalPIPLiabilityFAQ;
	@FindBy(xpath = PRINCIPAL_PIP_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement principalPIPLiabilityAmount;
	@FindBy(xpath = PRINCIPAL_PIP_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement principalPIPLiabilityRefreshIcon;

	private static final String PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH = "//a[starts-with(@aria-label,'Principal PIP - Med Exp Only info icon')]";
	@FindBy(xpath = PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement principalPIPMedicalExpensesLiabilityLabel;
	@FindBy(xpath = PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement principalPIPMedicalExpensesLiabilityDropdown;
	@FindBy(xpath = PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH)
	private WebElement principalPIPMedicalExpensesLiabilityFAQ;
	@FindBy(xpath = PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement principalPIPMedicalExpensesLiabilityAmount;
	@FindBy(xpath = PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement principalPIPMedicalExpensesLiabilityRefreshIcon;
	@FindBy(xpath = PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement principalPIPMedicalExpensesLiabilityErrorLabel;
	@FindBy(xpath = PRINCIPAL_PIP_MEDICAL_EXPENSES_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement principalPIPMedicalExpensesLiabilityErrorMessage;

	private static final String PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH = "//a[starts-with(@aria-label,'Property Damage Liability info icon')]";
	@FindBy(xpath = PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement propertyDamageLiabilityLabel;
	@FindBy(xpath = PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement propertyDamageLiabilityDropdown;
	@FindBy(xpath = PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH)
	private WebElement propertyDamageLiabilityFAQ;
	@FindBy(xpath = PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement propertyDamageLiabilityAmount;
	@FindBy(xpath = PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement propertyDamageLiabilityRefreshIcon;
	@FindBy(xpath = PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement propertyDamageLiabilityErrorLabel;
	@FindBy(xpath = PROPERTY_DAMAGE_LIABILITY_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement propertyDamageLiabilityErrorMessage;


	private static final String PROPERTY_DAMAGE_FAQ_XPATH = "//a[starts-with(@aria-label,'Property Damage info icon')]";
	@FindBy(xpath = PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement propertyDamageLabel;
	@FindBy(xpath = PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement propertyDamageDropdown;
	@FindBy(xpath = PROPERTY_DAMAGE_FAQ_XPATH)
	private WebElement propertyDamageFAQ;
	@FindBy(xpath = PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement propertyDamageAmount;
	@FindBy(xpath = PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement propertyDamageRefreshIcon;
	@FindBy(xpath = PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement propertyDamageErrorLabel;
	@FindBy(xpath = PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement propertyDamageErrorMessage;

	private static final String TORT_FAQ_XPATH = "//a[starts-with(@aria-label,'Tort info icon')]";
	@FindBy(xpath = TORT_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement tortLiabilityLabel;
	@FindBy(xpath = TORT_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement tortLiabilityDropdown;
	@FindBy(xpath = TORT_FAQ_XPATH)
	private WebElement tortLiabilityFAQ;
	@FindBy(xpath = TORT_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement tortLiabilityAmount;
	@FindBy(xpath = TORT_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement tortLiabilityRefreshIcon;

	private static final String UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH = "//a[starts-with(@aria-label,'Under Insured Motorist Bodily Injury info icon')]";
	@FindBy(xpath = UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement underSpaceInsuredMotoristBodilyInjuryLiabilityLabel;
	@FindBy(xpath = UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement underSpaceInsuredMotoristBodilyInjuryLiabilityDropdown;
	@FindBy(xpath = UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH)
	private WebElement underSpaceInsuredMotoristBodilyInjuryLiabilityFAQ;
	@FindBy(xpath = UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement underSpaceInsuredMotoristBodilyInjuryLiabilityAmount;
	@FindBy(xpath = UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement underSpaceInsuredMotoristBodilyInjuryLiabilityRefreshIcon;

	private static final String UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH = "//a[starts-with(@aria-label,'Underinsured Motorist Bodily Injury - Stacking Option info icon')]";
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement underinsuredMotoristBodilyInjuryStackingOptionLiabilityLabel;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement underinsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH)
	private WebElement underinsuredMotoristBodilyInjuryStackingOptionLiabilityFAQ;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement underinsuredMotoristBodilyInjuryStackingOptionLiabilityAmount;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement underinsuredMotoristBodilyInjuryStackingOptionLiabilityRefreshIcon;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement underinsuredMotoristBodilyInjuryStackingOptionLiabilityErrorLabel;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement underinsuredMotoristBodilyInjuryStackingOptionLiabilityErrorMessage;

	private static final String UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH = "//a[starts-with(@aria-label,'Under Insured Motorist Property Damage info icon')]";
	@FindBy(xpath = UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement underSpaceInsuredMotoristPropertyDamageLiabilityLabel;
	@FindBy(xpath = UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement underSpaceInsuredMotoristPropertyDamageLiabilityDropdown;
	@FindBy(xpath = UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH)
	private WebElement underSpaceInsuredMotoristPropertyDamageLiabilityFAQ;
	@FindBy(xpath = UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement underSpaceInsuredMotoristPropertyDamageLiabilityAmount;
	@FindBy(xpath = UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement underSpaceInsuredMotoristPropertyDamageLiabilityRefreshIcon;

	private static final String UNINSURED_MOTORIST_BODILY_INJURY_STACKING_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist Bodily Injury - Stacking Option info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredMotoristBodilyInjuryStackingLiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredMotoristBodilyInjuryStackingLiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_FAQ_XPATH)
	private WebElement uninsuredMotoristBodilyInjuryStackingLiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredMotoristBodilyInjuryStackingLiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredMotoristBodilyInjuryStackingLiabilityRefreshIcon;

	private static final String UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_LABEL_XPATH = "//div[contains(@class, 'ffq-coverage-panel-coverage-item-label') and text() = 'Uninsured Motorist Bodily Injury - Stacking Option']";
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_LABEL_XPATH)
	private WebElement uninsuredMotoristBodilyInjuryStackingOptionLiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_LABEL_XPATH + "/../..//div[contains(@class, 'ffq-coverage-items-dropdown')]/lib-select/mat-form-field/div/div/div/mat-select")
	private WebElement uninsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_LABEL_XPATH)
	private WebElement uninsuredMotoristBodilyInjuryStackingOptionLiabilityFAQ;

	private static final String UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist Bodily Injury - Without Stacking info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredMotoristBodilyInjuryWithoutStackingLiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredMotoristBodilyInjuryWithoutStackingLiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING_FAQ_XPATH)
	private WebElement uninsuredMotoristBodilyInjuryWithoutStackingLiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredMotoristBodilyInjuryWithoutStackingLiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredMotoristBodilyInjuryWithoutStackingLiabilityRefreshIcon;

	private static final String UNINSURED_MOTORIST_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredMotoristLiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredMotoristLiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_FAQ_XPATH)
	private WebElement uninsuredMotoristLiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredMotoristLiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredMotoristLiabilityRefreshIcon;
	@FindBy(xpath = UNINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement uninsuredMotoristLiabilityErrorLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement uninsuredMotoristLiabilityErrorMessage;

	private static final String UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist  info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredMotoristNYLiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredMotoristNYLiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH)
	private WebElement uninsuredMotoristNYLiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredMotoristNYLiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredMotoristNYLiabilityRefreshIcon;
	@FindBy(xpath = UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement uninsuredMotoristNYLiabilityErrorLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_ALTERNATE_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement uninsuredMotoristNYLiabilityErrorMessage;

	private static final String UNDER_INSURED_MOTORIST_FAQ_XPATH = "//a[starts-with(@aria-label,'Under Insured Motorist info icon')]";
	@FindBy(xpath = UNDER_INSURED_MOTORIST_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement underSpaceInsuredMotoristLiabilityLabel;
	@FindBy(xpath = UNDER_INSURED_MOTORIST_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement underSpaceInsuredMotoristLiabilityDropdown;
	@FindBy(xpath = UNDER_INSURED_MOTORIST_FAQ_XPATH)
	private WebElement underSpaceInsuredMotoristLiabilityFAQ;
	@FindBy(xpath = UNDER_INSURED_MOTORIST_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement underSpaceInsuredMotoristLiabilityAmount;
	@FindBy(xpath = UNDER_INSURED_MOTORIST_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement underSpaceInsuredMotoristLiabilityRefreshIcon;
	@FindBy(xpath = UNDER_INSURED_MOTORIST_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement underSpaceInsuredMotoristLiabilityErrorLabel;
	@FindBy(xpath = UNDER_INSURED_MOTORIST_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement underSpaceInsuredMotoristLiabilityErrorMessage;

	private static final String UNDERINSURED_MOTORIST_FAQ_XPATH = "//a[starts-with(@aria-label,'Underinsured Motorist info icon')]";
	@FindBy(xpath = UNDERINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement underinsuredMotoristLiabilityLabel;
	@FindBy(xpath = UNDERINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement underinsuredMotoristLiabilityDropdown;
	@FindBy(xpath = UNDERINSURED_MOTORIST_FAQ_XPATH)
	private WebElement underinsuredMotoristLiabilityFAQ;
	@FindBy(xpath = UNDERINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement underinsuredMotoristLiabilityAmount;
	@FindBy(xpath = UNDERINSURED_MOTORIST_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement underinsuredMotoristLiabilityRefreshIcon;

	private static final String UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist Bodily Injury info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredMotoristBodilyInjuryLiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL_ALTERNATE)
	private WebElement uninsuredMotoristBodilyInjuryLiabilityAlternateLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredMotoristBodilyInjuryLiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN_ALTERNATE)
	private WebElement uninsuredMotoristBodilyInjuryLiabilityAlternateDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH)
	private WebElement uninsuredMotoristBodilyInjuryLiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredMotoristBodilyInjuryLiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredMotoristBodilyInjuryLiabilityRefreshIcon;

	private static final String UNINSURED_MOTORIST_BI_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist BI info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredMotoristBILiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredMotoristBILiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_BI_FAQ_XPATH)
	private WebElement uninsuredMotoristBILiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredMotoristBILiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredMotoristBILiabilityRefreshIcon;

	private static final String UNINSURED_MOTORIST_BI_OPTIONS_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist BI Options info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_BI_OPTIONS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredMotoristBIOptionsLiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_BI_OPTIONS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredMotoristBIOptionsLiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_BI_OPTIONS_FAQ_XPATH)
	private WebElement uninsuredMotoristBIOptionsLiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_BI_OPTIONS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredMotoristBIOptionsLiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_BI_OPTIONS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredMotoristBIOptionsLiabilityRefreshIcon;

	private static final String UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH = "//a[starts-with(@aria-label,'Underinsured Motorist Bodily Injury info icon')]";
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement underinsuredMotoristBodilyInjuryLiabilityLabel;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement underinsuredMotoristBodilyInjuryLiabilityDropdown;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH)
	private WebElement underinsuredMotoristBodilyInjuryLiabilityFAQ;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement underinsuredMotoristBodilyInjuryLiabilityAmount;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement underinsuredMotoristBodilyInjuryLiabilityRefreshIcon;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement underinsuredMotoristBodilyInjuryLiabilityErrorLabel;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement underinsuredMotoristBodilyInjuryLiabilityErrorMessage;

	private static final String UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist/Underinsured Motorist Bodily Injury info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredUnderinsuredMotoristBodilyInjuryLiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredUnderinsuredMotoristBodilyInjuryLiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH)
	private WebElement uninsuredUnderinsuredMotoristBodilyInjuryLiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredUnderinsuredMotoristBodilyInjuryLiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredUnderinsuredMotoristBodilyInjuryLiabilityRefreshIcon;

	private static final String UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist/Underinsured Motorist BI info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredUnderinsuredMotoristBILiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredUnderinsuredMotoristBILiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI_FAQ_XPATH)
	private WebElement uninsuredUnderinsuredMotoristBILiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredUnderinsuredMotoristBILiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredUnderinsuredMotoristBILiabilityRefreshIcon;

	private static final String UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist/Under Insured Motorist Bodily Injury info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH)
	private WebElement uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityRefreshIcon;

	private static final String UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_ALTERNATE_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist/Under Insured Motorist Bodily Injury  info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_ALTERNATE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_ALTERNATE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_ALTERNATE_FAQ_XPATH)
	private WebElement uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_ALTERNATE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY_ALTERNATE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityRefreshIcon;

	private static final String UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist / Under Insured Motorist BI info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredUnderSpaceInsuredMotoristBILiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredUnderSpaceInsuredMotoristBILiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_FAQ_XPATH)
	private WebElement uninsuredUnderSpaceInsuredMotoristBILiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredUnderSpaceInsuredMotoristBILiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredUnderSpaceInsuredMotoristBILiabilityRefreshIcon;

	private static final String UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist / Under Insured Motorist BI Conversion info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredUnderInsuredMotoristBIConversionLiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredUnderInsuredMotoristBIConversionLiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH)
	private WebElement uninsuredUnderInsuredMotoristBIConversionLiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredUnderInsuredMotoristBIConversionLiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredUnderInsuredMotoristBIConversionLiabilityRefreshIcon;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement uninsuredUnderInsuredMotoristBIConversionLiabilityErrorLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement uninsuredUnderInsuredMotoristBIConversionLiabilityErrorMessage;

	private static final String UNDERINSURED_MOTORIST_BI_FAQ_XPATH = "//a[starts-with(@aria-label,'Underinsured Motorist BI info icon')]";
	@FindBy(xpath = UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement underinsuredMotoristBILiabilityLabel;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement underinsuredMotoristBILiabilityDropdown;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BI_FAQ_XPATH)
	private WebElement underinsuredMotoristBILiabilityFAQ;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement underinsuredMotoristBILiabilityAmount;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement underinsuredMotoristBILiabilityRefreshIcon;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement underinsuredMotoristBILiabilityErrorLabel;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BI_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement underinsuredMotoristBILiabilityErrorMessage;

	private static final String UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH = "//a[starts-with(@aria-label,'Underinsured Motorist Property Damage info icon')]";
	@FindBy(xpath = UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement underinsuredMotoristPropertyDamageLiabilityLabel;
	@FindBy(xpath = UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement underinsuredMotoristPropertyDamageLiabilityDropdown;
	@FindBy(xpath = UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH)
	private WebElement underinsuredMotoristPropertyDamageLiabilityFAQ;
	@FindBy(xpath = UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement underinsuredMotoristPropertyDamageLiabilityAmount;
	@FindBy(xpath = UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement underinsuredMotoristPropertyDamageLiabilityRefreshIcon;

	private static final String UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist/Under Insured Motorist Property Damage info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH)
	private WebElement uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityRefreshIcon;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityErrorLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityErrorMessage;

	private static final String UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist/Underinsured Motorist Property Damage info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredUnderinsuredMotoristPropertyDamageLiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredUnderinsuredMotoristPropertyDamageLiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH)
	private WebElement uninsuredUnderinsuredMotoristPropertyDamageLiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredUnderinsuredMotoristPropertyDamageLiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredUnderinsuredMotoristPropertyDamageLiabilityRefreshIcon;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement uninsuredUnderinsuredMotoristPropertyDamageLiabilityErrorLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement uninsuredUnderinsuredMotoristPropertyDamageLiabilityErrorMessage;

	private static final String UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist/Underinsured Motorist PD info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredUnderInsuredMotoristPDLiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredUnderInsuredMotoristPDLiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_FAQ_XPATH)
	private WebElement uninsuredUnderInsuredMotoristPDLiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredUnderInsuredMotoristPDLiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredUnderInsuredMotoristPDLiabilityRefreshIcon;

	@FindBy(xpath = "//app-vehicle-coverage/form/lib-coverage-panel/mat-accordion/mat-expansion-panel/mat-expansion-panel-header/span/mat-panel-title/div/div[@class='ffq-coverage-panel-coverage-heading']")
	private List<WebElement> vehicleCoverageHeaders;

	private static final String ACCIDENT_FORGIVENESS_FAQ_XPATH = "//a[starts-with(@aria-label,'Accident Forgiveness info icon')]";
	@FindBy(xpath = ACCIDENT_FORGIVENESS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement accidentForgivenessCoverageLabel;
	@FindBy(xpath = ACCIDENT_FORGIVENESS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement accidentForgivenessCoverageDropdown;
	@FindBy(xpath = ACCIDENT_FORGIVENESS_FAQ_XPATH)
	private WebElement accidentForgivenessCoverageFAQ;
	@FindBy(xpath = ACCIDENT_FORGIVENESS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement accidentForgivenessCoverageAmount;
	@FindBy(xpath = ACCIDENT_FORGIVENESS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement accidentForgivenessCoverageRefreshIcon;

	private static final String COLLISION_FAQ_XPATH = "//a[starts-with(@aria-label,'Collision info icon')]";
	@FindBy(xpath = COLLISION_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement collisionCoverageLabel;
	@FindBy(xpath = COLLISION_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement collisionCoverageDropdown;
	@FindBy(xpath = COLLISION_FAQ_XPATH)
	private WebElement collisionCoverageFAQ;
	@FindBy(xpath = COLLISION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement collisionCoverageAmount;
	@FindBy(xpath = COLLISION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement collisionCoverageRefreshIcon;

	private static final String COLLISION_LOSS_OF_USE_FAQ_XPATH = "//a[starts-with(@aria-label,'Collision Plus/Loss of Use info icon')]";
	@FindBy(xpath = COLLISION_LOSS_OF_USE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement collisionPlusLossOfUseCoverageLabel;
	@FindBy(xpath = COLLISION_LOSS_OF_USE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement collisionPlusLossOfUseCoverageDropdown;
	@FindBy(xpath = COLLISION_LOSS_OF_USE_FAQ_XPATH)
	private WebElement collisionPlusLossOfUseCoverageFAQ;
	@FindBy(xpath = COLLISION_LOSS_OF_USE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement collisionPlusLossOfUseCoverageAmount;
	@FindBy(xpath = COLLISION_LOSS_OF_USE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement collisionPlusLossOfUseCoverageRefreshIcon;

	private static final String COLLISION_LOSS_OF_USE_K5_FAQ_XPATH = "//a[starts-with(@aria-label,'Collision Plus/Loss of Use K5 info icon')]";
	@FindBy(xpath = COLLISION_LOSS_OF_USE_K5_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement collisionPlusLossOfUseK5CoverageLabel;
	@FindBy(xpath = COLLISION_LOSS_OF_USE_K5_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement collisionPlusLossOfUseK5CoverageDropdown;
	@FindBy(xpath = COLLISION_LOSS_OF_USE_K5_FAQ_XPATH)
	private WebElement collisionPlusLossOfUseK5CoverageFAQ;
	@FindBy(xpath = COLLISION_LOSS_OF_USE_K5_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement collisionPlusLossOfUseK5CoverageAmount;
	@FindBy(xpath = COLLISION_LOSS_OF_USE_K5_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement collisionPlusLossOfUseK5CoverageRefreshIcon;

	private static final String COMPREHENSIVE_FAQ_XPATH = "//a[starts-with(@aria-label,'Comprehensive info icon')]";
	@FindBy(xpath = COMPREHENSIVE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement comprehensiveCoverageLabel;
	@FindBy(xpath = COMPREHENSIVE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement comprehensiveCoverageDropdown;
	@FindBy(xpath = COMPREHENSIVE_FAQ_XPATH)
	private WebElement comprehensiveCoverageFAQ;
	@FindBy(xpath = COMPREHENSIVE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement comprehensiveCoverageAmount;
	@FindBy(xpath = COMPREHENSIVE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement comprehensiveCoverageRefreshIcon;

	private static final String DEATH_BENEFIT_FAQ_XPATH = "//a[starts-with(@aria-label,'Death Benefit info icon')]";
	@FindBy(xpath = DEATH_BENEFIT_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement deathBenefitCoverageLabel;
	@FindBy(xpath = DEATH_BENEFIT_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement deathBenefitCoverageDropdown;
	@FindBy(xpath = DEATH_BENEFIT_FAQ_XPATH)
	private WebElement deathBenefitCoverageFAQ;
	@FindBy(xpath = DEATH_BENEFIT_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement deathBenefitCoverageAmount;
	@FindBy(xpath = DEATH_BENEFIT_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement deathBenefitCoverageRefreshIcon;

	private static final String EXTRA_PIP_COVERAGE_FAQ_XPATH = "//a[starts-with(@aria-label,'Extra PIP Package for Primary Insured, Spouse & Resident Relatives info icon')]";
	@FindBy(xpath = EXTRA_PIP_COVERAGE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement extraPIPPackageCoverageLabel;
	@FindBy(xpath = EXTRA_PIP_COVERAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement extraPIPPackageCoverageDropdown;
	@FindBy(xpath = EXTRA_PIP_COVERAGE_FAQ_XPATH)
	private WebElement extraPIPPackageCoverageFAQ;
	@FindBy(xpath = EXTRA_PIP_COVERAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement extraPIPPackageCoverageAmount;
	@FindBy(xpath = EXTRA_PIP_COVERAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement extraPIPPackageCoverageRefreshIcon;

	private static final String FUNERAL_EXPENSES_FAQ_XPATH = "//a[starts-with(@aria-label,'Funeral Expenses info icon')]";
	@FindBy(xpath = FUNERAL_EXPENSES_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement funeralExpensesCoverageLabel;
	@FindBy(xpath = FUNERAL_EXPENSES_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement funeralExpensesCoverageDropdown;
	@FindBy(xpath = FUNERAL_EXPENSES_FAQ_XPATH)
	private WebElement funeralExpensesCoverageFAQ;
	@FindBy(xpath = FUNERAL_EXPENSES_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement funeralExpensesCoverageAmount;
	@FindBy(xpath = FUNERAL_EXPENSES_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement funeralExpensesCoverageRefreshIcon;

	private static final String GLASS_DEDUCTIBLE_BUYBACK_FAQ_XPATH = "//a[starts-with(@aria-label,'Glass Deductible Buyback info icon')]";
	@FindBy(xpath = GLASS_DEDUCTIBLE_BUYBACK_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement glassDeductibleBuybackCoverageLabel;
	@FindBy(xpath = GLASS_DEDUCTIBLE_BUYBACK_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement glassDeductibleBuybackCoverageDropdown;
	@FindBy(xpath = GLASS_DEDUCTIBLE_BUYBACK_FAQ_XPATH)
	private WebElement glassDeductibleBuybackCoverageFAQ;
	@FindBy(xpath = GLASS_DEDUCTIBLE_BUYBACK_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement glassDeductibleBuybackCoverageAmount;
	@FindBy(xpath = GLASS_DEDUCTIBLE_BUYBACK_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement glassDeductibleBuybackCoverageRefreshIcon;

	private static final String GLASS_COVERAGE_100_FAQ_XPATH = "//a[starts-with(@aria-label,'$100 Glass Coverage info icon')]";
	@FindBy(xpath = GLASS_COVERAGE_100_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement glassCoverage100Label;
	@FindBy(xpath = GLASS_COVERAGE_100_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement glassCoverage100Dropdown;
	@FindBy(xpath = GLASS_COVERAGE_100_FAQ_XPATH)
	private WebElement glassCoverage100FAQ;
	@FindBy(xpath = GLASS_COVERAGE_100_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement glassCoverage100Amount;
	@FindBy(xpath = GLASS_COVERAGE_100_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement glassCoverage100RefreshIcon;
	@FindBy(xpath = GLASS_COVERAGE_100_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement glassCoverage100ErrorLabel;
	@FindBy(xpath = GLASS_COVERAGE_100_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement glassCoverage100ErrorMessage;

	private static final String HEALTH_INSURER_FAQ_XPATH = "//a[starts-with(@aria-label,'Health Insurer Primary for PIP info icon')]";
	@FindBy(xpath = HEALTH_INSURER_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement healthInsurerPrimaryCoverageLabel;
	@FindBy(xpath = HEALTH_INSURER_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement healthInsurerPrimaryCoverageDropdown;
	@FindBy(xpath = HEALTH_INSURER_FAQ_XPATH)
	private WebElement healthInsurerPrimaryCoverageFAQ;
	@FindBy(xpath = HEALTH_INSURER_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement healthInsurerPrimaryCoverageAmount;
	@FindBy(xpath = HEALTH_INSURER_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement healthInsurerPrimaryCoverageRefreshIcon;

	private static final String INCOME_DISABILITY_FAQ_XPATH = "//a[starts-with(@aria-label,'Income Disability info icon')]";
	@FindBy(xpath = INCOME_DISABILITY_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement incomeDisabilityCoverageLabel;
	@FindBy(xpath = INCOME_DISABILITY_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement incomeDisabilityCoverageDropdown;
	@FindBy(xpath = INCOME_DISABILITY_FAQ_XPATH)
	private WebElement incomeDisabilityCoverageFAQ;
	@FindBy(xpath = INCOME_DISABILITY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement incomeDisabilityCoverageAmount;
	@FindBy(xpath = INCOME_DISABILITY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement incomeDisabilityCoverageRefreshIcon;

	private static final String INCOME_LOSS_FAQ_XPATH = "//a[starts-with(@aria-label,'Income Loss info icon')]";
	@FindBy(xpath = INCOME_LOSS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement incomeLossCoverageLabel;
	@FindBy(xpath = INCOME_LOSS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement incomeLossCoverageDropdown;
	@FindBy(xpath = INCOME_LOSS_FAQ_XPATH)
	private WebElement incomeLossCoverageFAQ;
	@FindBy(xpath = INCOME_LOSS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement incomeLossCoverageAmount;
	@FindBy(xpath = INCOME_LOSS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement incomeLossCoverageRefreshIcon;

	private static final String LOSS_OF_USE_FAQ_XPATH = "//a[starts-with(@aria-label,'Loss of Use info icon')]";
	@FindBy(xpath = LOSS_OF_USE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement lossOfUseCoverageLabel;
	@FindBy(xpath = LOSS_OF_USE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement lossOfUseCoverageDropdown;
	@FindBy(xpath = LOSS_OF_USE_FAQ_XPATH)
	private WebElement lossOfUseCoverageFAQ;
	@FindBy(xpath = LOSS_OF_USE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement lossOfUseCoverageAmount;
	@FindBy(xpath = LOSS_OF_USE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement lossOfUseCoverageRefreshIcon;

	private static final String MEDICAL_EXPENSE_COVERAGE_FAQ_XPATH = "//a[starts-with(@aria-label,'Medical Expense Coverage info icon')]";
	@FindBy(xpath = MEDICAL_EXPENSE_COVERAGE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement medicalExpenseCoverageLabel;
	@FindBy(xpath = MEDICAL_EXPENSE_COVERAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement medicalExpenseCoverageDropdown;
	@FindBy(xpath = MEDICAL_EXPENSE_COVERAGE_FAQ_XPATH)
	private WebElement medicalExpenseCoverageFAQ;
	@FindBy(xpath = MEDICAL_EXPENSE_COVERAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement medicalExpenseCoverageAmount;
	@FindBy(xpath = MEDICAL_EXPENSE_COVERAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement medicalExpenseCoverageRefreshIcon;

	private static final String RENTAL_FAQ_XPATH = "//a[starts-with(@aria-label,'Rental info icon')]";
	@FindBy(xpath = RENTAL_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement rentalCoverageLabel;
	@FindBy(xpath = RENTAL_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement rentalCoverageDropdown;
	@FindBy(xpath = RENTAL_FAQ_XPATH)
	private WebElement rentalCoverageFAQ;
	@FindBy(xpath = RENTAL_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement rentalCoverageAmount;
	@FindBy(xpath = RENTAL_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement rentalCoverageRefreshIcon;
	@FindBy(xpath = RENTAL_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement rentalCoverageErrorLabel;
	@FindBy(xpath = RENTAL_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement rentalCoverageErrorMessage;

	private static final String RENTAL_REIMBURSEMENT_FAQ_XPATH = "//a[starts-with(@aria-label,'Rental Reimbursement info icon')]";
	@FindBy(xpath = RENTAL_REIMBURSEMENT_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement rentalReimbursementCoverageLabel;
	@FindBy(xpath = RENTAL_REIMBURSEMENT_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement rentalReimbursementCoverageDropdown;
	@FindBy(xpath = RENTAL_REIMBURSEMENT_FAQ_XPATH)
	private WebElement rentalReimbursementCoverageFAQ;
	@FindBy(xpath = RENTAL_REIMBURSEMENT_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement rentalReimbursementCoverageAmount;
	@FindBy(xpath = RENTAL_REIMBURSEMENT_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement rentalReimbursementCoverageRefreshIcon;

	private static final String RIDESHARE_FAQ_XPATH = "//a[starts-with(@aria-label,'Rideshare info icon')]";
	@FindBy(xpath = RIDESHARE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement rideshareCoverageLabel;
	@FindBy(xpath = RIDESHARE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement rideshareCoverageDropdown;
	@FindBy(xpath = RIDESHARE_FAQ_XPATH)
	private WebElement rideshareCoverageFAQ;
	@FindBy(xpath = RIDESHARE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement rideshareCoverageAmount;
	@FindBy(xpath = RIDESHARE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement rideshareCoverageRefreshIcon;

	private static final String RIDESHARE_AND_FOOD_FAQ_XPATH = "//a[starts-with(@aria-label,'Rideshare and Food Delivery info icon')]";
	@FindBy(xpath = RIDESHARE_AND_FOOD_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement rideshareAndFoodDeliveryCoverageLabel;
	@FindBy(xpath = RIDESHARE_AND_FOOD_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement rideshareAndFoodDeliveryCoverageDropdown;
	@FindBy(xpath = RIDESHARE_AND_FOOD_FAQ_XPATH)
	private WebElement rideshareAndFoodDeliveryCoverageFAQ;
	@FindBy(xpath = RIDESHARE_AND_FOOD_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement rideshareAndFoodDeliveryCoverageAmount;
	@FindBy(xpath = RIDESHARE_AND_FOOD_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement rideshareAndFoodDeliveryCoverageRefreshIcon;

	private static final String ROADSIDE_ASSISTANCE_FAQ_XPATH = "//a[starts-with(@aria-label,'Roadside Assistance info icon')]";
	@FindBy(xpath = ROADSIDE_ASSISTANCE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement roadsideAssistanceCoverageLabel;
	@FindBy(xpath = ROADSIDE_ASSISTANCE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement roadsideAssistanceCoverageDropdown;
	@FindBy(xpath = ROADSIDE_ASSISTANCE_FAQ_XPATH)
	private WebElement roadsideAssistanceCoverageFAQ;
	@FindBy(xpath = ROADSIDE_ASSISTANCE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement roadsideAssistanceCoverageAmount;
	@FindBy(xpath = ROADSIDE_ASSISTANCE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement roadsideAssistanceCoverageRefreshIcon;

	private static final String SAFETY_GLASS_WAIVER_FAQ_XPATH = "//a[starts-with(@aria-label,'Safety Glass ')]";
	@FindBy(xpath = SAFETY_GLASS_WAIVER_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement safetyGlassWaiverOfDeductibleCoverageLabel;
	@FindBy(xpath = SAFETY_GLASS_WAIVER_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement safetyGlassWaiverOfDeductibleCoverageDropdown;
	@FindBy(xpath = SAFETY_GLASS_WAIVER_FAQ_XPATH)
	private WebElement safetyGlassWaiverOfDeductibleCoverageFAQ;
	@FindBy(xpath = SAFETY_GLASS_WAIVER_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement safetyGlassWaiverOfDeductibleCoverageAmount;
	@FindBy(xpath = SAFETY_GLASS_WAIVER_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement safetyGlassWaiverOfDeductibleCoverageRefreshIcon;

	private static final String TOWING_AND_ROAD_SERVICE_FAQ_XPATH = "//a[starts-with(@aria-label,'Towing and Road Service info icon')]";
	@FindBy(xpath = TOWING_AND_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement towingAndRoadServiceCoverageLabel;
	@FindBy(xpath = TOWING_AND_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement towingAndRoadServiceCoverageDropdown;
	@FindBy(xpath = TOWING_AND_ROAD_SERVICE_FAQ_XPATH)
	private WebElement towingAndRoadServiceCoverageFAQ;
	@FindBy(xpath = TOWING_AND_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement towingAndRoadServiceCoverageAmount;
	@FindBy(xpath = TOWING_AND_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement towingAndRoadServiceCoverageRefreshIcon;

	private static final String TOWING_AMP_ROAD_SERVICE_FAQ_XPATH = "//a[starts-with(@aria-label,'Towing & Road Service info icon')]";
	@FindBy(xpath = TOWING_AMP_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement towingAmpRoadServiceCoverageLabel;
	@FindBy(xpath = TOWING_AMP_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement towingAmpRoadServiceCoverageDropdown;
	@FindBy(xpath = TOWING_AMP_ROAD_SERVICE_FAQ_XPATH)
	private WebElement towingAmpRoadServiceCoverageFAQ;
	@FindBy(xpath = TOWING_AMP_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement towingAmpRoadServiceCoverageAmount;
	@FindBy(xpath = TOWING_AMP_ROAD_SERVICE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement towingAmpRoadServiceCoverageRefreshIcon;

	private static final String TOWING_LABOR_FAQ_XPATH = "//a[starts-with(@aria-label,'Towing and Labor info icon'))]";
	@FindBy(xpath = TOWING_LABOR_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement towingAndLaborCoverageLabel;
	@FindBy(xpath = TOWING_LABOR_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement towingAndLaborCoverageDropdown;
	@FindBy(xpath = TOWING_LABOR_FAQ_XPATH)
	private WebElement towingAndLaborCoverageFAQ;
	@FindBy(xpath = TOWING_LABOR_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement towingAndLaborCoverageAmount;
	@FindBy(xpath = TOWING_LABOR_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement towingAndLaborCoverageRefreshIcon;

	private static final String TOWING_LABOR_COSTS_FAQ_XPATH = "//a[starts-with(@aria-label,'Towing and Labor Costs info icon')]";
	@FindBy(xpath = TOWING_LABOR_COSTS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement towingAndLaborCostsCoverageLabel;
	@FindBy(xpath = TOWING_LABOR_COSTS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement towingAndLaborCostsCoverageDropdown;
	@FindBy(xpath = TOWING_LABOR_COSTS_FAQ_XPATH)
	private WebElement towingAndLaborCostsCoverageFAQ;
	@FindBy(xpath = TOWING_LABOR_COSTS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement towingAndLaborCostsCoverageAmount;
	@FindBy(xpath = TOWING_LABOR_COSTS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement towingAndLaborCostsCoverageRefreshIcon;

	private static final String UNINSURED_MOTORIST_PD_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist PD info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredMotoristPDCoverageLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredMotoristPDCoverageDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_PD_FAQ_XPATH)
	private WebElement uninsuredMotoristPDCoverageFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredMotoristPDCoverageAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredMotoristPDCoverageRefreshIcon;
	@FindBy(xpath = UNINSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement uninsuredMotoristPDCoverageErrorLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_PD_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement uninsuredMotoristPDCoverageErrorMessage;

	private static final String UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist PD without Collision info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredMotoristPDWithoutUppercaseCollisionCoverageLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredMotoristPDWithoutUppercaseCollisionCoverageDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH)
	private WebElement uninsuredMotoristPDWithoutUppercaseCollisionCoverageFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredMotoristPDWithoutUppercaseCollisionCoverageAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredMotoristPDWithoutUppercaseCollisionCoverageRefreshIcon;
	@FindBy(xpath = UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement uninsuredMotoristPDWithoutUppercaseCollisionCoverageErrorLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_PD_UPPERCASE_NO_COLLISION_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement uninsuredMotoristPDWithoutUppercaseCollisionCoverageErrorMessage;

	private static final String UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist Property Damage info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredMotoristPropertyDamageCoverageLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_LABEL_ALTERNATE)
	private WebElement uninsuredMotoristPropertyDamageCoverageAlternateLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredMotoristPropertyDamageCoverageDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_DROPDOWN_ALTERNATE)
	private WebElement uninsuredMotoristPropertyDamageCoverageAlternateDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH)
	private WebElement uninsuredMotoristPropertyDamageCoverageFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredMotoristPropertyDamageCoverageAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredMotoristPropertyDamageCoverageRefreshIcon;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement uninsuredMotoristPropertyDamageCoverageErrorLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement uninsuredMotoristPropertyDamageCoverageErrorMessage;

	private static final String UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist Property Damage without Collision info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredMotoristPropertyDamageWithoutCollisionCoverageLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredMotoristPropertyDamageWithoutCollisionCoverageDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH)
	private WebElement uninsuredMotoristPropertyDamageWithoutCollisionCoverageFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredMotoristPropertyDamageWithoutCollisionCoverageAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredMotoristPropertyDamageWithoutCollisionCoverageRefreshIcon;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement uninsuredMotoristPropertyDamageWithoutCollisionCoverageErrorLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_NO_COLLISION_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement uninsuredMotoristPropertyDamageWithoutCollisionCoverageErrorMessage;

	private static final String UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITH_COLLISION_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist Property Damage with Collision info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITH_COLLISION_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredMotoristPropertyDamageWithCollisionCoverageLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITH_COLLISION_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredMotoristPropertyDamageWithCollisionCoverageDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITH_COLLISION_FAQ_XPATH)
	private WebElement uninsuredMotoristPropertyDamageWithCollisionCoverageFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITH_COLLISION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredMotoristPropertyDamageWithCollisionCoverageAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITH_COLLISION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredMotoristPropertyDamageWithCollisionCoverageRefreshIcon;

	private static final String VEHICLE_REPLACEMENT_FAQ_XPATH = "//a[starts-with(@aria-label,'Vehicle Replacement Plus info icon')]";
	@FindBy(xpath = VEHICLE_REPLACEMENT_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement vehicleReplacementCoverageLabel;
	@FindBy(xpath = VEHICLE_REPLACEMENT_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement vehicleReplacementCoverageDropdown;
	@FindBy(xpath = VEHICLE_REPLACEMENT_FAQ_XPATH)
	private WebElement vehicleReplacementCoverageFAQ;
	@FindBy(xpath = VEHICLE_REPLACEMENT_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement vehicleReplacementCoverageAmount;
	@FindBy(xpath = VEHICLE_REPLACEMENT_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement vehicleReplacementCoverageRefreshIcon;
	@FindBy(xpath = VEHICLE_REPLACEMENT_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement vehicleReplacementCoverageErrorLabel;
	@FindBy(xpath = VEHICLE_REPLACEMENT_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement vehicleReplacementCoverageErrorMessage;

	private static final String WAIVER_WORK_LOSS_FAQ_XPATH = "//a[starts-with(@aria-label,'Waiver of Work Loss info icon')]";
	@FindBy(xpath = WAIVER_WORK_LOSS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement waiverOfWorkLossCoverageLabel;
	@FindBy(xpath = WAIVER_WORK_LOSS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement waiverOfWorkLossCoverageDropdown;
	@FindBy(xpath = WAIVER_WORK_LOSS_FAQ_XPATH)
	private WebElement waiverOfWorkLossCoverageFAQ;
	@FindBy(xpath = WAIVER_WORK_LOSS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement waiverOfWorkLossCoverageAmount;
	@FindBy(xpath = WAIVER_WORK_LOSS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement waiverOfWorkLossCoverageRefreshIcon;

	//MA specific items
	private static final String COMPULSORY_BODILY_INJURY_FAQ_XPATH = "//a[starts-with(@aria-label,'Compulsory Bodily Injury (Part 1) info icon')]";
	@FindBy(xpath = COMPULSORY_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement compulsoryBodilyInjuryLiabilityLabel;
	@FindBy(xpath = COMPULSORY_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement compulsoryBodilyInjuryLiabilityDropdown;
	@FindBy(xpath = COMPULSORY_BODILY_INJURY_FAQ_XPATH)
	private WebElement compulsoryBodilyInjuryLiabilityFAQ;
	@FindBy(xpath = COMPULSORY_BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement compulsoryBodilyInjuryLiabilityAmount;
	@FindBy(xpath = COMPULSORY_BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement compulsoryBodilyInjuryLiabilityRefreshIcon;

	private static final String OPTIONAL_BODILY_INJURY_FAQ_XPATH = "//a[starts-with(@aria-label,'Optional Bodily Injury (Part 5) info icon')]";
	@FindBy(xpath = OPTIONAL_BODILY_INJURY_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement optionalBodilyInjuryLiabilityLabel;
	@FindBy(xpath = OPTIONAL_BODILY_INJURY_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement optionalBodilyInjuryLiabilityDropdown;
	@FindBy(xpath = OPTIONAL_BODILY_INJURY_FAQ_XPATH)
	private WebElement optionalBodilyInjuryLiabilityFAQ;
	@FindBy(xpath = OPTIONAL_BODILY_INJURY_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement optionalBodilyInjuryLiabilityAmount;
	@FindBy(xpath = OPTIONAL_BODILY_INJURY_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement optionalBodilyInjuryLiabilityRefreshIcon;

	private static final String PROPERTY_DAMAGE_MASS_FAQ_XPATH = "//a[starts-with(@aria-label,'Property Damage (Part 4) info icon')]";
	@FindBy(xpath = PROPERTY_DAMAGE_MASS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement propertyDamageMALabel;
	@FindBy(xpath = PROPERTY_DAMAGE_MASS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement propertyDamageMADropdown;
	@FindBy(xpath = PROPERTY_DAMAGE_MASS_FAQ_XPATH)
	private WebElement propertyDamageMAFAQ;
	@FindBy(xpath = PROPERTY_DAMAGE_MASS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement propertyDamageMAAmount;
	@FindBy(xpath = PROPERTY_DAMAGE_MASS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement propertyDamageMARefreshIcon;

	private static final String UNINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH = "//a[starts-with(@aria-label,'Uninsured Motorist Bodily Injury (Part 3) info icon')]";
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement uninsuredMotoristBodilyInjuryMALiabilityLabel;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement uninsuredMotoristBodilyInjuryMALiabilityDropdown;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH)
	private WebElement uninsuredMotoristBodilyInjuryMALiabilityFAQ;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement uninsuredMotoristBodilyInjuryMALiabilityAmount;
	@FindBy(xpath = UNINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement uninsuredMotoristBodilyInjuryMALiabilityRefreshIcon;

	private static final String UNDERINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH = "//a[starts-with(@aria-label,'Underinsured Motorist Bodily Injury (Part 12) info icon')]";
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement underinsuredMotoristBodilyInjuryMALiabilityLabel;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement underinsuredMotoristBodilyInjuryMALiabilityDropdown;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH)
	private WebElement underinsuredMotoristBodilyInjuryMALiabilityFAQ;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement underinsuredMotoristBodilyInjuryMALiabilityAmount;
	@FindBy(xpath = UNDERINSURED_MOTORIST_BODILY_INJURY_MASS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement underinsuredMotoristBodilyInjuryMALiabilityRefreshIcon;

	private static final String MEDICAL_PAYMENTS_FAQ_XPATH = "//a[starts-with(@aria-label,'Medical Payments (Part 6) info icon')]";
	@FindBy(xpath = MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement medicalPaymentsLiabilityLabel;
	@FindBy(xpath = MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement medicalPaymentsLiabilityDropdown;
	@FindBy(xpath = MEDICAL_PAYMENTS_FAQ_XPATH)
	private WebElement medicalPaymentsLiabilityFAQ;
	@FindBy(xpath = MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement medicalPaymentsLiabilityAmount;
	@FindBy(xpath = MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement medicalPaymentsLiabilityRefreshIcon;
	@FindBy(xpath = MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_ERROR_LABEL)
	private WebElement medicalPaymentsLiabilityErrorLabel;
	@FindBy(xpath = MEDICAL_PAYMENTS_FAQ_XPATH + XPATH_TO_ERROR_MSG)
	private WebElement medicalPaymentsLiabilityErrorMessage;

	private static final String PERSONAL_INJURY_PROTECTION_MASS_FAQ_XPATH = "//a[starts-with(@aria-label,'Personal Injury Protection (Part 2) info icon')]";
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_MASS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement personalInjuryProtectionMALiabilityLabel;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_MASS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement personalInjuryProtectionMALiabilityDropdown;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_MASS_FAQ_XPATH)
	private WebElement personalInjuryProtectionMALiabilityFAQ;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_MASS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement personalInjuryProtectionMALiabilityAmount;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_MASS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement personalInjuryProtectionMALiabilityRefreshIcon;

	private static final String PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_FAQ_XPATH = "//a[starts-with(@aria-label,'Personal Injury Protection - Deductible info icon')]";
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement personalInjuryProtectionDeductibleLiabilityLabel;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement personalInjuryProtectionDeductibleLiabilityDropdown;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_FAQ_XPATH)
	private WebElement personalInjuryProtectionDeductibleLiabilityFAQ;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement personalInjuryProtectionDeductibleLiabilityAmount;
	@FindBy(xpath = PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement personalInjuryProtectionDeductibleLiabilityRefreshIcon;

	private static final String COMPREHENSIVE_MASS_FAQ_XPATH = "//a[starts-with(@aria-label,'Comprehensive (Part 9) info icon')]";
	@FindBy(xpath = COMPREHENSIVE_MASS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement comprehensiveMACoverageLabel;
	@FindBy(xpath = COMPREHENSIVE_MASS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement comprehensiveMACoverageDropdown;
	@FindBy(xpath = COMPREHENSIVE_MASS_FAQ_XPATH)
	private WebElement comprehensiveMACoverageFAQ;
	@FindBy(xpath = COMPREHENSIVE_MASS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement comprehensiveMACoverageAmount;
	@FindBy(xpath = COMPREHENSIVE_MASS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement comprehensiveMACoverageRefreshIcon;

	private static final String COLLISION_MASS_FAQ_XPATH = "//a[starts-with(@aria-label,'Collision (Part 7) info icon')]";
	@FindBy(xpath = COLLISION_MASS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement collisionMACoverageLabel;
	@FindBy(xpath = COLLISION_MASS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement collisionMACoverageDropdown;
	@FindBy(xpath = COLLISION_MASS_FAQ_XPATH)
	private WebElement collisionMACoverageFAQ;
	@FindBy(xpath = COLLISION_MASS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement collisionMACoverageAmount;
	@FindBy(xpath = COLLISION_MASS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement collisionMACoverageRefreshIcon;

	private static final String LIMITED_COLLISION_FAQ_XPATH = "//a[starts-with(@aria-label,'Limited Collision (Part 8) info icon')]";
	@FindBy(xpath = LIMITED_COLLISION_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement limitedCollisionCoverageLabel;
	@FindBy(xpath = LIMITED_COLLISION_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement limitedCollisionCoverageDropdown;
	@FindBy(xpath = LIMITED_COLLISION_FAQ_XPATH)
	private WebElement limitedCollisionCoverageFAQ;
	@FindBy(xpath = LIMITED_COLLISION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement limitedCollisionCoverageAmount;
	@FindBy(xpath = LIMITED_COLLISION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement limitedCollisionCoverageRefreshIcon;

	private static final String TOWING_LABOR_MASS_FAQ_XPATH = "//a[starts-with(@aria-label,'Towing and Labor (Part 11) info icon')]";
	@FindBy(xpath = TOWING_LABOR_MASS_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement towingAndLaborMACoverageLabel;
	@FindBy(xpath = TOWING_LABOR_MASS_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement towingAndLaborMACoverageDropdown;
	@FindBy(xpath = TOWING_LABOR_MASS_FAQ_XPATH)
	private WebElement towingAndLaborMACoverageFAQ;
	@FindBy(xpath = TOWING_LABOR_MASS_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement towingAndLaborMACoverageAmount;
	@FindBy(xpath = TOWING_LABOR_MASS_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement towingAndLaborMACoverageRefreshIcon;

	private static final String SUBSTITUTE_TRANSPORTATION_FAQ_XPATH = "//a[starts-with(@aria-label,'Substitute Transportation (Part 10) info icon')]";
	@FindBy(xpath = SUBSTITUTE_TRANSPORTATION_FAQ_XPATH + XPATH_TO_LABEL)
	private WebElement substituteTransportationCoverageLabel;
	@FindBy(xpath = SUBSTITUTE_TRANSPORTATION_FAQ_XPATH + XPATH_TO_DROPDOWN)
	private WebElement substituteTransportationCoverageDropdown;
	@FindBy(xpath = SUBSTITUTE_TRANSPORTATION_FAQ_XPATH)
	private WebElement substituteTransportationCoverageFAQ;
	@FindBy(xpath = SUBSTITUTE_TRANSPORTATION_FAQ_XPATH + XPATH_TO_SUBTOTAL_AMOUNT)
	private WebElement substituteTransportationCoverageAmount;
	@FindBy(xpath = SUBSTITUTE_TRANSPORTATION_FAQ_XPATH + XPATH_TO_REFRESH_ICON)
	private WebElement substituteTransportationCoverageRefreshIcon;

	private static final String POLICY_PERKS_SECTION_CLASS = "auto-module__policy-perks-header";

	private static final String CROSSSELL_TEXT_XPATH = "//a//div[contains(@class,'ffq-sidepanel-cross-sell-displaylob-text')]";
	private static final String CROSSSELL_ENTRY_XPATH = "//a//div[contains(@class,'ffq-sidepanel-cross-sell-displaylob-text') and text()=";
	private static final String CONDO_CROSSSELL_TEXT_XPATH = CROSSSELL_ENTRY_XPATH + "'Condo Quote']";
	private static final String HOME_CROSSSELL_TEXT_XPATH = CROSSSELL_ENTRY_XPATH + "'Home Quote']";
	private static final String RENTERS_CROSSSELL_TEXT_XPATH = CROSSSELL_ENTRY_XPATH + "'Renters Quote']";
	private static final String VTL_CROSSSELL_TEXT_XPATH = CROSSSELL_ENTRY_XPATH + "'Value Term Life Quote']";

	@FindBy(xpath = CONDO_CROSSSELL_TEXT_XPATH)
	private WebElement crossSellCondoQuote;

	@FindBy(xpath = HOME_CROSSSELL_TEXT_XPATH)
	private WebElement crossSellHomeQuote;

	@FindBy(xpath = RENTERS_CROSSSELL_TEXT_XPATH)
	private WebElement crossSellRentersQuote;

	@FindBy(xpath = VTL_CROSSSELL_TEXT_XPATH)
	private WebElement crossSellVTLQuote;

	public QuotePageAuto() throws Exception {
		isBristolWest = isBristolWestQuote();
	}

	public final boolean isOnLegacyAutoQuotePage() throws Exception {
		waitForPageToRender(EMPTY_STRING);
		return isElementDisplayed(packageHeader, 5);
	}

	private void waitForQuotePageToRender(String quoteNumber) throws KnockoutException{
		waitForPageToRender(quoteNumber);
		waitElementBeVisible(packageHeader);
	}

	private void waitForPageToRender(String quoteNumber) throws KnockoutException {
		waitForSpinnerToBeGone();
		checkForKnockout("QuotePageAuto.waitForPageToRender", quoteNumber);
		if (isElementPresentByClass(quoteRentersProgressPopup)) {
			longWaitForElementToBeGoneByClass(QUOTE_RENTERS_PROGRESS_POPUP_CLASSNAME);
		}
		if (isElementPresentByXPath(CALCULATING_SAVINGS_TEXT_XPATH)) {
			longWaitForElementToBeGoneByXpath(CALCULATING_SAVINGS_TEXT_XPATH);
		}
		if (isElementPresentByID(minimizeChatbotDialog)) {
			clickElement(minimizeChatbotDialog);
			clickElement(quotePageDescription);
		}
		closeSurveyDialog();
	}

	public boolean isPolicyPerksOffered() throws Exception {
		return isElementDisplayed(By.className(POLICY_PERKS_SECTION_CLASS));
	}

	public void validatePage(SqlApplicant applicant, boolean performDeepValidation, FarmersSoftAssert fsa) throws Exception {
		waitForQuotePageToRender(EMPTY_STRING);
		logQuoteNumber(applicant);
		String applicantStateCode = applicant.getStateCode();
		validatePageTitle(fsa);
		validatePageDisclaimer(applicantStateCode, fsa);
		// Phone number issues, disabling tests
		//fsa.assertTrue(validatePhoneNumber(applicantStateCode), "Correct phone number displayed");
		if (!isBristolWestQuote()) {
			validateSelectedPackage(applicantStateCode, applicant.getPrincipalPIP());
		}
		if (applicant.getTestCategory().equals("save completed quote")) {
			saveAutoApplicant(applicant, QUOTE_PAGE_AUTO, getRedesignedQuoteNumber());
		} else if (performDeepValidation  && !isBristolWestQuote()) {
			if (isElementVisible(viewAllPackagesLink, 10)) {
				setPackageTo(FULL_PACKAGE);
			}
			if (getSelectedPackage().equals(FULL_PACKAGE)) {
				getAllCoveragesAndLiabilities(applicantStateCode);
				verifyQualifiedDiscounts(applicant, fsa);
				verifyAllDropdownValues(applicant, fsa);
				verifyDefaultValuesForAllDropdowns(applicant, fsa);
				if (!applicant.getTestCategory().equalsIgnoreCase("small screen")) {
					validateNavigationLinks();
				}
				validateCoveragePackages(applicantStateCode, fsa);
				verifyDependentDropdowns(applicant, fsa);
				validateLabelsAndFAQs(applicant, fsa);
				validateGTMTags(applicantStateCode, fsa);
				verifyStateSpecificScenarios(applicantStateCode, fsa);
			}
		}
		if (isElementVisible(viewAllPackagesLink, 10)) {
			setPackageTo(FULL_PACKAGE);
		}
		if (!isBristolWestQuote() && !applicantStateCode.equals(MI)) {
			validateAmountTotals();
			int numberOfVehicles = limitVehicleCountToMaxAllowed(applicantStateCode, applicant.getVehicles().size());
			if (numberOfVehicles > 1) {
				validateCoverageAmountsDifferentBetweenVehicles(numberOfVehicles);
			}
		}
		if (performDeepValidation  && !isBristolWestQuote() && applicant.getDiscounts().isRentersInsurance() && isRentersBundleState(applicantStateCode)) {
			if (isUseFullStateNameForRentersStates(applicantStateCode)) {
				validateRentersBundle(applicant.getStateName());
			} else {
				validateRentersBundle(applicantStateCode);
			}
		} else {
			fsa.assertFalse(isElementPresentByID(quoteRentersButton), "Renters Bundle option available");
		}
	}

	public void attemptToBuyQuote(SqlApplicant applicant) throws Exception {
		if (!applicant.getDiscounts().isRentersInsurance()) {
			if (getAttributeData(buyNowButton, DATA_GTM).contains("buynow_button")) {
				financedVehicleCheck(applicant);
			} else {
				Log.warn("Quote can't be bound, Continue button found");
			}
			clickBuyNow();
			waitForSpinnerToBeGone();
		}
	}

	public void validatePageTitle(FarmersSoftAssert fsa) throws Exception {
		waitForPageToRender(EMPTY_STRING);
		if (isADATestingEnabled()) {
			performADATesting(getClass().getSimpleName(), MARKETING_IT, "Auto");
			screenCapture(quotePageHeader, getClass().getSimpleName(), LOB_AUTO, false);
		}
		String quotePageHeaderText = getTextFromElement(quotePageHeader);
		boolean isExpectedPageTitle = quotePageHeaderText.equals(QUOTE_PAGE_HEADER) || quotePageHeaderText.equals(QUOTE_PAGE_HEADER_ALTERNATE);
		fsa.assertTrue(isExpectedPageTitle, "Quote page title verification");
	}

	public void validatePageDisclaimer(String stateCode, FarmersSoftAssert fsa) {
		if (isEasternExpansionState(stateCode)) {
			if (stateCode.equals(LA)) {
				fsa.assertEquals(isExpectedTextContainedInElement(quotePageDisclosure1, QUOTE_PAGE_DISCLOSURE_ONE_CA), true, DISCLOSURE1_ERROR);
			} else {
				fsa.assertEquals(isExpectedTextContainedInElement(quotePageDisclosure1, QUOTE_PAGE_DISCLOSURE_ONE), true, DISCLOSURE1_ERROR);
			}
			if (isElementPresentByID(quotePageRentersDisclosure)) {
				fsa.assertEquals(isExpectedTextContainedInElement(quotePageRentersDisclosure, QUOTE_PAGE_RENTERS_DISCLOSURE), true, RENTERS_DISCLOSURE_ERROR);
			} else if (isBristolWestQuote()) {
				fsa.assertEquals(isExpectedTextContainedInElement(quotePageDisclosure2, QUOTE_PAGE_BRISTOL_WEST_DISCLOSURE), true, DISCLOSURE2_ERROR);
			} else {
				fsa.assertEquals(isExpectedTextContainedInElement(quotePageDisclosure3, QUOTE_PAGE_DISCLOSURE_THREE), true, DISCLOSURE3_ERROR);
			}
		} else {
			if (stateCode.equals(NY) || (isBristolWestQuote() && stateCode.equals(FL))) {
				fsa.assertEquals(isExpectedTextContainedInElement(quotePageDisclosure1, QUOTE_PAGE_DISCLOSURE_ONE_CA), true, DISCLOSURE1_ERROR);
			} else if (isElementVisible(quotePageDisclosure1, 3)) {
				fsa.assertEquals(isExpectedTextContainedInElement(quotePageDisclosure1, QUOTE_PAGE_DISCLOSURE_ONE), true, DISCLOSURE1_ERROR);
			}
			if (isElementPresentByID(quotePageRentersDisclosure)) {
				fsa.assertEquals(isExpectedTextContainedInElement(quotePageRentersDisclosure, QUOTE_PAGE_RENTERS_DISCLOSURE), true, RENTERS_DISCLOSURE_ERROR);
			}
			if (isBristolWestQuote()) {
				fsa.assertEquals(isExpectedTextContainedInElement(quotePageDisclosure2, QUOTE_PAGE_BRISTOL_WEST_DISCLOSURE), true, DISCLOSURE2_ERROR);
			} else if (isUseFlexDisclosureThreeState(stateCode)) {
				fsa.assertEquals(isExpectedTextContainedInElement(quotePageDisclosure3, QUOTE_PAGE_DISCLOSURE_THREE_FLEX), true, DISCLOSURE3_ERROR);
			} else {
				fsa.assertEquals(isExpectedTextContainedInElement(quotePageDisclosure3, QUOTE_PAGE_DISCLOSURE_THREE_ALTERNATE), true, DISCLOSURE3_ERROR);
			}
		}
	}

	private boolean isUseFlexDisclosureThreeState(String stateCode) {
		return (stateCode.equals(VA) || isFlexState(stateCode) && !stateCode.equals(CA));
	}

	private boolean validateSelectedPackage(String applicantStateCode, String expectedPackage) {
		if (Arrays.asList(AL, PA, WY).contains(applicantStateCode)) {
			return getSelectedPackage().equals(expectedPackage);
		} else {
			return true;
		}
	}

	private boolean validateAmountTotals() throws Exception {
		double maximumAllowedDifference = 0.06;
	    NumberFormat nf = NumberFormat.getInstance();
	    nf.setMaximumFractionDigits(2);
	    double quoteRate = nf.parse(getPremiumAmount().replaceAll(NON_CURRENCY_CHARS, EMPTY_STRING)).doubleValue();
		List<String> listOfCoverageAndLiabilitiesAmounts = createAmountList(XPATH_TO_COVERAGE_LIABILITY_AMOUNT);
		double quoteTotal = addAmountsInList(listOfCoverageAndLiabilitiesAmounts);
		if (quoteTotal == 0.0) {
			//Cannot confidently produce list of elements, skip check
			return true;
		}
		if (isElementPresentByID(membershipFee)) {
			double membershipFeeAmount =  Double.parseDouble(getTextFromElement(membershipFee).replaceAll(NON_CURRENCY_CHARS, EMPTY_STRING));
			Log.warn("Adding memebrship fee of " + membershipFeeAmount);
			quoteTotal += membershipFeeAmount;
		}
		double difference = quoteRate - quoteTotal;
		boolean areTotalsTheSame = (maximumAllowedDifference > difference) && (difference > -maximumAllowedDifference);
		if (!areTotalsTheSame) {
			Log.warn("Comparing rate " + quoteRate + " to added total " + quoteTotal);
		}
		return areTotalsTheSame;
	}

	private List<String> createAmountList(String xpathToAmounts) throws Exception {
		List<String> amountsFound = new ArrayList<>();
 		List<WebElement> listOfCoverageAndLiabilitiesAmounts = driver().findElements(By.xpath(xpathToAmounts));
		int numberOfAmountsInPage = listOfCoverageAndLiabilitiesAmounts.size();
		for (int i=0; i< numberOfAmountsInPage; i++) {
			try {
				String amountText = getTextFromElement(listOfCoverageAndLiabilitiesAmounts.get(i));
				if (!amountText.equals(EMPTY_STRING)) {
					amountsFound.add(amountText);
				}
			} catch (StaleElementReferenceException see) {
				//Cannot confidently produce list of elements, skip check
				amountsFound.add(SKIP);
			}
		}
		if (numberOfAmountsInPage != amountsFound.size()) {
			Log.error("Amounts listed not the same as those present");
			Log.error("amount of elements found: " + numberOfAmountsInPage + " -> " + amountsFound);
		}
		return amountsFound;
	}

	private boolean validateCoverageAmountsDifferentBetweenVehicles(int numberOfVehicles) throws Exception {
		boolean areListsDifferent = true;
		Map<Integer, List<String>> vehicleAmountMap = new HashMap<>();
		for (int vehicleNumber = 1; vehicleNumber <= numberOfVehicles; vehicleNumber++) {
			List<String> listOfCoverageAndLiabilitiesAmounts = createAmountList(APP_VEHICLE_COVERAGE_FORM_XPATH + vehicleNumber + "]" + XPATH_TO_COVERAGE_LIABILITY_AMOUNT);
			vehicleAmountMap.put(vehicleNumber, listOfCoverageAndLiabilitiesAmounts);
		}
		//Now compare the lists
		for (int vehicleNumber = 1; vehicleNumber <= numberOfVehicles; vehicleNumber++) {
			List<String> currentVehicleAmountList = vehicleAmountMap.get(vehicleNumber);
			String currentVehicleName = getTextFromElement(driver().findElement(By.xpath(APP_VEHICLE_COVERAGE_FORM_XPATH + vehicleNumber + VEHICLE_NAME_XPATH)));
			for (int nextVehicleNumber = vehicleNumber+1; nextVehicleNumber <= numberOfVehicles; nextVehicleNumber++) {
				List<String> compareToVehicleAmountList = vehicleAmountMap.get(nextVehicleNumber);
				double compareToVehicleAmountTotal = addAmountsInList(compareToVehicleAmountList);
				if (compareToVehicleAmountTotal!=0.0) {
					areListsDifferent = !(currentVehicleAmountList.containsAll(compareToVehicleAmountList) &&
							compareToVehicleAmountList.containsAll(currentVehicleAmountList));
					if (!areListsDifferent) {
						Log.info("Vehicles " + vehicleNumber + " and " + nextVehicleNumber + " amount lists are equal");
						Log.info(currentVehicleAmountList + SPACE + compareToVehicleAmountList);
						String compareToVehicleName = getTextFromElement(driver().findElement(By.xpath(APP_VEHICLE_COVERAGE_FORM_XPATH + nextVehicleNumber + VEHICLE_NAME_XPATH)));
						areListsDifferent = currentVehicleName.equals(compareToVehicleName);
						if (areListsDifferent) {
							Log.info("Same vehicles or totals are 0, it's OK for coverages to be equal");
						} else {
							Log.error("[" + currentVehicleName + "] [" + compareToVehicleName + "] ->" + compareToVehicleAmountTotal);
							break;
						}
					}
				}
			}
		}
		return areListsDifferent;
	}

	private double addAmountsInList(List<String> amountList) {
		double runningTotal = 0.00;
		for (String amount : amountList) {
			try {
				if (amount.equals(SKIP)) {
					//Cannot confidently produce list of elements, skip adding them
					return 0.00;
				}
				runningTotal += Double.parseDouble(amount.replaceAll(NON_CURRENCY_CHARS, EMPTY_STRING));
			} catch (Exception pe) {
				Log.warn("Unable to parse [" + amount +"]");
			}
		}
		Log.info("Added total is :" + runningTotal);
		return runningTotal;
	}

	public void validateNavigationLinks() {
		scrollToTopOfPage();
		clickQuickLink(YOUR_INFO);
		clickQuickLink(DRIVERS);
		clickQuickLink(VEHICLES);
		clickQuickLink(DISCOUNTS);
		clickQuickLink(QUOTE);
	}

	public void validateRentersBundle(String stateName) {
		if (isElementPresentByID(quoteRentersButton)) {
			clickElement(quoteRentersButton);
			waitForSpinnerToBeGone();
			Assert.assertTrue(isExpectedTextContainedInElement(rentersQuoteSummaryHeader, RENTERS_SUMMARY_HEADER + stateName), "rentersQuoteSummaryHeader contains " + RENTERS_SUMMARY_HEADER + stateName);
		} else {
			Log.error("+++ Missing renters bundle for " + stateName);
		}
	}

	public void validateLabelsAndFAQs(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		String stateCode = applicant.getStateCode();
		List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC31578", "TC31580", "TC31581", "TC31487", "TC31491", "TC31495"));
		writeTestcaseState("QuotePageAuto.validateLabelsAndFAQs", stateCode, rallyTestcasesCovered, FAILED);
		recalculateQuote();
		scrollToBottomOfPage();
		//Check existence of dropdown appropriately
		checkLabelAndTooltip(!stateCode.equals(MA), bodilyInjuryLiabilityFAQ, bodilyInjuryLiabilityLabel, BODILY_INJURY, BODILY_INJURY_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(!stateCode.equals(MA), collisionCoverageFAQ, collisionCoverageLabel, COLLISION, COLLISION_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(!stateCode.equals(MA), comprehensiveCoverageFAQ, comprehensiveCoverageLabel, COMPREHENSIVE, COMPREHENSIVE_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(isGlassDeductibleState(stateCode), glassDeductibleBuybackCoverageFAQ, glassDeductibleBuybackCoverageLabel, GLASS_DEDUCTIBLE_BUYBACK, GLASS_DEDUCTIBLE_BUYBACK_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(isLossOfUseState(stateCode), lossOfUseCoverageFAQ, lossOfUseCoverageLabel, LOSS_OF_USE, LOSS_OF_USE_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(isMedicalCoverageState(stateCode), medicalCoverageLiabilityFAQ, medicalCoverageLiabilityLabel, MEDICAL_COVERAGE, MEDICAL_COVERAGE_HELP_TEXT, stateCode, fsa);
		String pipHelpText = stateCode.equals(KY)? PERSONAL_INJURY_PROTECTION_ALTERNATE_HELP_TEXT : PERSONAL_INJURY_PROTECTION_HELP_TEXT;
		checkLabelAndTooltip(isPersonalInjuryProtectionState(stateCode), personalInjuryProtectionLiabilityFAQ, personalInjuryProtectionLiabilityLabel, PERSONAL_INJURY_PROTECTION, pipHelpText, stateCode, fsa);
		checkLabelAndTooltip(isPIPDeductibleAppliesToState(stateCode), personalInjuryProtectionDeductibleAppliesToLiabilityFAQ, personalInjuryProtectionDeductibleAppliesToLiabilityLabel, PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO, PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_APPLIES_TO_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(isPropertyDamageLiabilityState(stateCode), propertyDamageLiabilityFAQ, propertyDamageLiabilityLabel, PROPERTY_DAMAGE_LIABILITY, PROPERTY_DAMAGE_LIABILITY_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(isPropertyDamageState(stateCode) && !stateCode.equals(MA), propertyDamageFAQ, propertyDamageLabel, PROPERTY_DAMAGE, PROPERTY_DAMAGE_LIABILITY_HELP_TEXT, stateCode, fsa);
		String safetyGlassHelpTitle = stateCode.equals(MI)? SAFETY_GLASS_WAIVER_OF_DEDUCTIBLE : SAFETY_GLASS_WAIVER_OF_DEDUCTIBLE_SHORT_DASH_LOWERCASE_OF;
		String safetyGlassHelpText = stateCode.equals(MI)? SAFETY_GLASS_WAIVER_OF_DEDUCTIBLE_HELP_TEXT : SAFETY_GLASS_WAIVER_OF_DEDUCTIBLE_AZ_HELP_TEXT;
		checkLabelAndTooltip(isSafetyGlassWaiverOfDeductibleState(stateCode), safetyGlassWaiverOfDeductibleCoverageFAQ, safetyGlassWaiverOfDeductibleCoverageLabel, safetyGlassHelpTitle, safetyGlassHelpText , stateCode, fsa);
		String towingHelpText = (isOldTowingHelpTextState(stateCode))? TOWING_AND_LABOR_HELP_TEXT : TOWING_AND_ROAD_SERVICE_HELP_TEXT;
		checkLabelAndTooltip(isTowingAmpRoadState(stateCode), towingAmpRoadServiceCoverageFAQ, towingAmpRoadServiceCoverageLabel, TOWING_AMP_ROAD_SERVICE, towingHelpText, stateCode, fsa);
		checkLabelAndTooltip(isTowingAndRoadServiceState(stateCode), towingAndRoadServiceCoverageFAQ, towingAndRoadServiceCoverageLabel, TOWING_AND_ROAD_SERVICE, towingHelpText, stateCode, fsa);
		checkLabelAndTooltip(isUnderinsuredMotoristBIState(stateCode), underinsuredMotoristBILiabilityFAQ, underinsuredMotoristBILiabilityLabel, UNDERINSURED_MOTORIST_BI, UNDERINSURED_MOTORIST_HELP_TEXT, stateCode, fsa);
		String uimbiHelpText = isEasternExpansionState(stateCode) && !stateCode.equals(LA)? UNDERINSURED_MOTORIST_HELP_TEXT : UNDERINSURED_MOTORIST_BODILY_INJURY_HELP_TEXT;
		checkLabelAndTooltip(isUnderinsuredMotoristBodilyInjuryState(stateCode), underinsuredMotoristBodilyInjuryLiabilityFAQ, underinsuredMotoristBodilyInjuryLiabilityLabel, UNDERINSURED_MOTORIST_BODILY_INJURY, uimbiHelpText, stateCode, fsa);
		checkLabelAndTooltip(isUnderinsuredMotoristState(stateCode), underinsuredMotoristLiabilityFAQ, underinsuredMotoristLiabilityLabel, UNDERINSURED_MOTORIST, UNDERINSURED_MOTORIST_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(isUnderSpaceInsuredState(stateCode), underSpaceInsuredMotoristLiabilityFAQ, underSpaceInsuredMotoristLiabilityLabel, UNDER_INSURED_MOTORIST, UNDERINSURED_MOTORIST_HELP_TEXT, stateCode, fsa);
		String umbiHelpText = UNINSURED_MOTORIST_HELP_TEXT;
		if (stateCode.equals(IL)) {
			umbiHelpText = UNINSURED_MOTORIST_BI_HELP_TEXT;
		} else if (stateCode.equals(LA)) {
			umbiHelpText = UNDERINSURED_MOTORIST_BODILY_INJURY_HELP_TEXT;
		}
		checkLabelAndTooltip(isUninsuredMotoristBIState(stateCode), uninsuredMotoristBILiabilityFAQ, uninsuredMotoristBILiabilityLabel, UNINSURED_MOTORIST_BI, umbiHelpText, stateCode, fsa);
		WebElement umbiLabel = stateCode.equals(MD)? uninsuredMotoristBodilyInjuryLiabilityAlternateLabel : uninsuredMotoristBodilyInjuryLiabilityLabel;
		checkLabelAndTooltip(isUninsuredMotoristBodilyInjuryState(stateCode), uninsuredMotoristBodilyInjuryLiabilityFAQ, umbiLabel, UNINSURED_MOTORIST_BODILY_INJURY, UNINSURED_MOTORIST_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(isUninsuredMotoristPDState(stateCode), uninsuredMotoristPDCoverageFAQ, uninsuredMotoristPDCoverageLabel, UNINSURED_MOTORIST_PD, UNINSURED_MOTORIST_PROPERTY_DAMAGE_HELP_TEXT, stateCode, fsa);
		WebElement umpdLabel = stateCode.equals(MD)? uninsuredMotoristPropertyDamageCoverageAlternateLabel : uninsuredMotoristPropertyDamageCoverageLabel;
		checkLabelAndTooltip(isUninsuredMotoristPropertyDamageState(stateCode), uninsuredMotoristPropertyDamageCoverageFAQ, umpdLabel, UNINSURED_MOTORIST_PROPERTY_DAMAGE, UNINSURED_MOTORIST_PROPERTY_DAMAGE_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(isUninsuredMotoristPropertyDamageWithoutCollisionState(stateCode), uninsuredMotoristPropertyDamageWithoutCollisionCoverageFAQ, uninsuredMotoristPropertyDamageWithoutCollisionCoverageLabel, UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITHOUT_COLLISION, UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITHOUT_COLLISION_HELP_TEXT, stateCode, fsa);
		WebElement umFAQ = stateCode.equals(NY)? uninsuredMotoristNYLiabilityFAQ : uninsuredMotoristLiabilityFAQ;
		WebElement umll = stateCode.equals(NY)? uninsuredMotoristNYLiabilityLabel : uninsuredMotoristLiabilityLabel;
		checkLabelAndTooltip(isUninsuredMotoristState(stateCode), umFAQ, umll, UNINSURED_MOTORIST, UNINSURED_MOTORIST_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(isUninsuredUnderinsuredMotoristBIState(stateCode), uninsuredUnderinsuredMotoristBILiabilityFAQ, uninsuredUnderinsuredMotoristBILiabilityLabel, UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI, stateCode.equals(NC)? UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_HELP_TEXT: UNDERINSURED_MOTORIST_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(isUninsuredUnderInsuredMotoristBodilyInjuryState(stateCode), uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityFAQ, uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityLabel, UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY, UNDERINSURED_MOTORIST_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(isUninsuredUnderInsuredMotoristBodilyInjuryAlternateState(stateCode), uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityFAQ, uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityLabel, UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY, UNDERINSURED_MOTORIST_HELP_TEXT, stateCode, fsa);
		String rentalHelpText = stateCode.equals(NC)? RENTAL_REIMBURSEMENT_HELP_TEXT_NC: RENTAL_REIMBURSEMENT_HELP_TEXT;
		checkLabelAndTooltip(isEasternExpansionState(stateCode) && !stateCode.equals(MA), rentalReimbursementCoverageFAQ, rentalReimbursementCoverageLabel, RENTAL_REIMBURSEMENT, rentalHelpText , stateCode, fsa);
		checkLabelAndTooltip(isMedicalLiabilityState(stateCode), medicalLiabilityFAQ, medicalLiabilityLabel, MEDICAL, MEDICAL_COVERAGE_HELP_TEXT , stateCode, fsa);
		boolean isValid = Arrays.asList(NC, TX).contains(stateCode);
		String helpText = stateCode.equals(NC)? UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_HELP_TEXT : UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_HELP_TEXT;
		checkLabelAndTooltip(isValid, uninsuredUnderInsuredMotoristPDLiabilityFAQ, uninsuredUnderInsuredMotoristPDLiabilityLabel, UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PD, helpText, stateCode, fsa);
		isValid = Arrays.asList(NM, TX).contains(stateCode);
		checkLabelAndTooltip(isValid, uninsuredUnderinsuredMotoristBodilyInjuryLiabilityFAQ, uninsuredUnderinsuredMotoristBodilyInjuryLiabilityLabel, UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY, UNDERINSURED_MOTORIST_HELP_TEXT, stateCode, fsa);
		isValid = Arrays.asList(CO, LA).contains(stateCode);
		checkLabelAndTooltip(isValid, uninsuredMotoristPDWithoutUppercaseCollisionCoverageFAQ, uninsuredMotoristPDWithoutUppercaseCollisionCoverageLabel, UNINSURED_MOTORIST_PD_WITHOUT_UPPERCASE_COLLISION, UNINSURED_MOTORIST_PD_WITHOUT_COLLISION_HELP_TEXT, stateCode, fsa);
		// Flex state changes
		String rentalCoverageHelpText = stateCode.equals(AZ) || stateCode.equals(IL)? RENTAL_COVERAGE_HELP_TEXT : RENTAL_COVERAGE_ALTERNATE_HELP_TEXT;
		isValid = isFlexState(stateCode);
		checkLabelAndTooltip(isValid && !stateCode.equals(VA), rentalCoverageFAQ, rentalCoverageLabel, RENTAL, rentalCoverageHelpText, stateCode, fsa);
		checkLabelAndTooltip(isValid && !stateCode.equals(VA), roadsideAssistanceCoverageFAQ, roadsideAssistanceCoverageLabel, ROADSIDE_ASSISTANCE, ROADSIDE_ASSISTANCE_HELP_TEXT , stateCode, fsa);
		checkLabelAndTooltip(isValid && !stateCode.equals(VA), vehicleReplacementCoverageFAQ, vehicleReplacementCoverageLabel, VEHICLE_REPLACEMENT_PLUS, VEHICLE_REPLACEMENT_PLUS_HELP_TEXT , stateCode, fsa);
		checkLabelAndTooltip(isValid && !stateCode.equals(AZ), glassCoverage100FAQ, glassCoverage100Label, GLASS_100_COVERAGE, SAFETY_GLASS_WAIVER_OF_DEDUCTIBLE_IL_HELP_TEXT , stateCode, fsa);
		checkLabelAndTooltip(isValid && isRidesharingApplicant(applicant), rideshareAndFoodDeliveryCoverageFAQ, rideshareAndFoodDeliveryCoverageLabel, RIDESHARE_AND_FOOD_DELIVERY, RIDESHARE_AND_FOOD_DELIVERY_HELP_TEXT , stateCode, fsa);
		checkLabelAndTooltip(!isValid && isRidesharingApplicant(applicant), rideshareCoverageFAQ, rideshareCoverageLabel, RIDESHARE, RIDESHARE_HELP_TEXT , stateCode, fsa);

		//Valid in a single state
		boolean validInASingleState = stateCode.equals(AR);
		checkLabelAndTooltip(validInASingleState, medicalAndHospitalLiabilityFAQ, medicalAndHospitalLiabilityLabel, MEDICAL_AND_HOSPITAL_BENEFITS, MEDICAL_AND_HOSPITAL_BENEFITS_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, incomeDisabilityCoverageFAQ, incomeDisabilityCoverageLabel, INCOME_DISABILITY, INCOME_DISABILITY_HELP_TEXT, stateCode, fsa);
		validInASingleState = stateCode.equals(CA);
		checkLabelAndTooltip(validInASingleState, permissiveUserLimitLiabilityFAQ, permissiveUserLimitLiabilityLabel, PERMISSIVE_USER_LIMIT, PERMISSIVE_USER_LIMIT_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, uninsuredMotoristPropertyDamageWithCollisionCoverageFAQ, uninsuredMotoristPropertyDamageWithCollisionCoverageLabel, UNINSURED_MOTORIST_PROPERTY_DAMAGE_WITH_COLLISION, UNINSURED_MOTORIST_PROPERTY_DAMAGE_HELP_TEXT, stateCode, fsa);
		validInASingleState = stateCode.equals(CT);
		checkLabelAndTooltip(validInASingleState, uninsuredUnderSpaceInsuredMotoristBILiabilityFAQ, uninsuredUnderSpaceInsuredMotoristBILiabilityLabel, UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI, UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, uninsuredUnderInsuredMotoristBIConversionLiabilityFAQ, uninsuredUnderInsuredMotoristBIConversionLiabilityLabel, UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION, UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BI_CONVERSION_HELP_TEXT, stateCode, fsa);
		validInASingleState = stateCode.equals(FL);
		checkLabelAndTooltip(validInASingleState, medicalExpenseCoverageFAQ, medicalExpenseCoverageLabel, MEDICAL_EXPENSE_COVERAGE, MEDICAL_EXPENSE_COVERAGE_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, personalInjuryProtectionExclusionLiabilityFAQ, personalInjuryProtectionExclusionLiabilityLabel, PERSONAL_INJURY_DEDUCTIBLE_PROTECTION_EXCLUSION, PERSONAL_INJURY_DEDUCTIBLE_PROTECTION_EXCLUSION_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, uninsuredMotoristBodilyInjuryStackingOptionLiabilityFAQ, uninsuredMotoristBodilyInjuryStackingOptionLiabilityLabel, UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION, UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_HELP_TEXT, stateCode, fsa);
		validInASingleState = stateCode.equals(GA);
		checkLabelAndTooltip(validInASingleState, uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityFAQ, uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityLabel, UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE, UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_HELP_TEXT, stateCode, fsa);
		validInASingleState = stateCode.equals(KY);
		checkLabelAndTooltip(validInASingleState, optionalPIPLiabilityFAQ, optionalPIPLiabilityLabel, OPTIONAL_PIP, OPTIONAL_PIP_HELP_TEXT, stateCode, fsa);
		validInASingleState = stateCode.equals(LA);
		checkLabelAndTooltip(validInASingleState, uninsuredMotoristBIOptionsLiabilityFAQ, uninsuredMotoristBIOptionsLiabilityLabel, UNINSURED_MOTORIST_BI_OPTIONS, UNINSURED_LA_MOTORIST_BI_HELP_TEXT, stateCode, fsa);
		validInASingleState = stateCode.equals(MA);
		checkLabelAndTooltip(validInASingleState, compulsoryBodilyInjuryLiabilityFAQ, compulsoryBodilyInjuryLiabilityLabel, COMPULSORY_BODILY_INJURY_MA, COMPULSORY_BODILY_INJURY_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, optionalBodilyInjuryLiabilityFAQ, optionalBodilyInjuryLiabilityLabel, OPTIONAL_BODILY_INJURY_MA, OPTIONAL_BODILY_INJURY_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, propertyDamageMAFAQ, propertyDamageMALabel, PROPERTY_DAMAGE_MA, PROPERTY_DAMAGE_LIABILITY_HELP_TEXT_MA, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, uninsuredMotoristBodilyInjuryMALiabilityFAQ, uninsuredMotoristBodilyInjuryMALiabilityLabel, UNINSURED_MOTORIST_BODILY_INJURY_MA, UNINSURED_MOTORIST_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, underinsuredMotoristBodilyInjuryMALiabilityFAQ, underinsuredMotoristBodilyInjuryMALiabilityLabel, UNDERINSURED_MOTORIST_BODILY_INJURY_MA, UNDERINSURED_MOTORIST_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, medicalPaymentsLiabilityFAQ, medicalPaymentsLiabilityLabel, MEDICAL_PAYMENTS_MA, MEDICAL_COVERAGE_HELP_TEXT_MA, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, personalInjuryProtectionMALiabilityFAQ, personalInjuryProtectionMALiabilityLabel, PERSONAL_INJURY_PROTECTION_MA, PERSONAL_INJURY_PROTECTION_HELP_TEXT_MA, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, personalInjuryProtectionDeductibleLiabilityFAQ, personalInjuryProtectionDeductibleLiabilityLabel, PERSONAL_INJURY_PROTECTION_DEDUCTIBLE, PERSONAL_INJURY_PROTECTION_DEDUCTIBLE_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, comprehensiveMACoverageFAQ, comprehensiveMACoverageLabel, COMPREHENSIVE_MA, COMPREHENSIVE_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, collisionMACoverageFAQ, collisionMACoverageLabel, COLLISION_MA, COLLISION_HELP_TEXT_MA, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, limitedCollisionCoverageFAQ, limitedCollisionCoverageLabel, LIMITED_COLLISION_MA, LIMITED_COLLISION_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, towingAndLaborMACoverageFAQ, towingAndLaborMACoverageLabel, TOWING_AND_LABOR_MA, TOWING_AND_LABOR_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, substituteTransportationCoverageFAQ, substituteTransportationCoverageLabel, SUBSTITUTE_TRANSPORTATION_MA, SUBSTITUTE_TRANSPORTATION_HELP_TEXT, stateCode, fsa);
		validInASingleState = stateCode.equals(MD);
		checkLabelAndTooltip(validInASingleState, accidentalDeathLiabilityFAQ, accidentalDeathLiabilityLabel, ACCIDENTAL_DEATH, ACCIDENTAL_DEATH_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, guestPIPLiabilityFAQ, guestPIPLiabilityLabel, GUEST_PIP, GUEST_PIP_HELP_TEXT, stateCode, fsa);
		validInASingleState = stateCode.equals(MN);
		checkLabelAndTooltip(validInASingleState, waiverOfWorkLossCoverageFAQ, waiverOfWorkLossCoverageLabel, WAIVER_OF_WORK_LOSS, WAIVER_OF_WORK_LOSS_HELP_TEXT, stateCode, fsa);
		validInASingleState = stateCode.equals(NJ);
		checkLabelAndTooltip(validInASingleState, deathBenefitCoverageFAQ, deathBenefitCoverageLabel, DEATH_BENEFIT, DEATH_BENEFIT_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, essentialServicesLiabilityFAQ, essentialServicesLiabilityLabel, ESSENTIAL_SERVICES, ESSENTIAL_SERVICES_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, extendedMedicalPaymentsLiabilityFAQ, extendedMedicalPaymentsLiabilityLabel, EXTENDED_MEDICAL_PAYMENTS, EXTENDED_MEDICAL_PAYMENTS_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, extraPIPPackageCoverageFAQ, extraPIPPackageCoverageLabel, EXTRA_PIP_PACKAGE_FOR_FAMILY, EXTRA_PIP_PACKAGE_FOR_FAMILY_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, extraPIPPackageLiabilityFAQ, extraPIPPackageLiabilityLabel, EXTRA_PIP_PACKAGE, EXTRA_PIP_PACKAGE_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, funeralExpensesCoverageFAQ, funeralExpensesCoverageLabel, FUNERAL_EXPENSES, FUNERAL_EXPENSES_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, healthInsurerPrimaryCoverageFAQ, healthInsurerPrimaryCoverageLabel, HEALTH_INSURER_PRIMARY, HEALTH_INSURER_PRIMARY_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, incomeContinuationLiabilityFAQ, incomeContinuationLiabilityLabel, INCOME_CONTINUATION, INCOME_CONTINUATION_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, lawsuitOptionLiabilityFAQ, lawsuitOptionLiabilityLabel, LAWSUIT_OPTION, LAWSUIT_OPTION_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, principalPIPLiabilityFAQ, principalPIPLiabilityLabel, PRINCIPAL_PIP, PRINCIPAL_PIP_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, principalPIPMedicalExpensesLiabilityFAQ, principalPIPMedicalExpensesLiabilityLabel, PRINCIPAL_PIP_MEDICAL_EXP_ONLY, PRINCIPAL_PIP_MEDICAL_HELP_TEXT, stateCode, fsa);
		validInASingleState = stateCode.equals(NM);
		checkLabelAndTooltip(validInASingleState, uninsuredUnderinsuredMotoristPropertyDamageLiabilityFAQ, uninsuredUnderinsuredMotoristPropertyDamageLiabilityLabel, UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE, UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_PD_HELP_TEXT, stateCode, fsa);
		validInASingleState = stateCode.equals(PA);
		checkLabelAndTooltip(false, accidentalDeathBenefitsLiabilityFAQ, accidentalDeathBenefitsLiabilityLabel, ACCIDENTAL_DEATH_BENEFITS, ACCIDENTAL_DEATH_BENEFITS_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(false, collisionPlusLossOfUseCoverageFAQ, collisionPlusLossOfUseCoverageLabel, COLLISION_PLUS_LOSS_OF_USE, COLLISION_PLUS_LOSS_OF_USE_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(false, funeralExpenseBenefitsLiabilityFAQ, funeralExpenseBenefitsLiabilityLabel, FUNERAL_EXPENSE_BENEFITS, FUNERAL_EXPENSE_BENEFITS_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(false, incomeLossCoverageFAQ, incomeLossCoverageLabel, INCOME_LOSS, INCOME_LOSS_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, tortLiabilityFAQ, tortLiabilityLabel, TORT, TORT_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, uninsuredMotoristBodilyInjuryStackingLiabilityFAQ, uninsuredMotoristBodilyInjuryStackingLiabilityLabel, UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION, UNINSURED_MOTORIST_BODILY_INJURY_STACKING_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(validInASingleState, underinsuredMotoristBodilyInjuryStackingOptionLiabilityFAQ, underinsuredMotoristBodilyInjuryStackingOptionLiabilityLabel, UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING, UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_HELP_TEXT, stateCode, fsa);
		validInASingleState = stateCode.equals(VA);
		checkLabelAndTooltip(validInASingleState, towingAndLaborCostsCoverageFAQ, towingAndLaborCostsCoverageLabel, TOWING_AND_LABOR_COSTS, TOWING_AND_LABOR_HELP_TEXT, stateCode, fsa);
		validInASingleState = stateCode.equals(WA);
		checkLabelAndTooltip(validInASingleState, underSpaceInsuredMotoristPropertyDamageLiabilityFAQ, underSpaceInsuredMotoristPropertyDamageLiabilityLabel, UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE, UNDER_INSURED_MOTORIST_PROPERTY_DAMAGE_HELP_TEXT, stateCode, fsa);

		// No longer found, should clean up all definitions to reduce file length
		checkLabelAndTooltip(false, underinsuredMotoristPropertyDamageLiabilityFAQ, underinsuredMotoristPropertyDamageLiabilityLabel, UNDERINSURED_MOTORIST_PROPERTY_DAMAGE, UNDERINSURED_MOTORIST_PROPERTY_DAMAGE_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(false, underSpaceInsuredMotoristBodilyInjuryLiabilityFAQ, underSpaceInsuredMotoristBodilyInjuryLiabilityLabel, UNDER_INSURED_MOTORIST_BODILY_INJURY, UNDER_INSURED_MOTORIST_BODILY_INJURY_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(false, uninsuredMotoristBodilyInjuryWithoutStackingLiabilityFAQ, uninsuredMotoristBodilyInjuryWithoutStackingLiabilityLabel, UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING, UNINSURED_MOTORIST_BODILY_INJURY_WITHOUT_STACKING_HELP_TEXT, stateCode, fsa);
		checkLabelAndTooltip(false, collisionPlusLossOfUseK5CoverageFAQ, collisionPlusLossOfUseK5CoverageLabel, COLLISION_PLUS_LOSS_OF_USE_K5, COLLISION_PLUS_LOSS_OF_K5_USE_HELP_TEXT, stateCode, fsa);

	}

	private boolean isMedicalLiabilityState(String stateCode) {
		return Arrays.asList(NE, PA, TN, TX, VA, WY).contains(stateCode) || (isEasternExpansionState(stateCode) && !stateCode.equals(MA));
	}

	private void checkLabelAndTooltip(boolean isValidCheck, WebElement faqButton, WebElement elementLabel, String label, String helpText, String stateCode, FarmersSoftAssert fsa) throws Exception {
		if (isValidCheck) {
			scrollToElementWithOffset(faqButton, 100);
			fsa.assertEquals(getTextFromElement(elementLabel), label, label + " coverage or liability found in page");
			String title = labelToFAQTitleConversion(label, stateCode);
			try {
				if (!title.equals(UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION)) {
					validateFAQ(faqButton, title, helpText, fsa);
				}
			}
			catch (AssertionError ae) {
				writeInfoToFile("Assertion failed in " + stateCode + " for " + title + ": " + ae.getMessage() + NEWLINE);
				if (isElementPresentByClass(faqDialogCloseButton)) {
					Log.info("-- attempting to close FAQ dialog --");
					closeFAQDialog();
				} else {
					Log.warn("++ did not find the close button in the FAQ dialog ++");
				}
			}
		} else {
			if (!label.equals(UNINSURED_MOTORIST_UNDER_INSURED_MOTORIST_BODILY_INJURY)) {
				List<WebElement> lookForElements = driver().findElements(By.xpath("//div[contains(@class, 'ffq-coverage-panel-coverage-item-label') and text()='"+label+"']"));
				fsa.assertEquals(lookForElements.isEmpty(), true, label + " coverage or liability not in page");
			}
		}
	}

	private String labelToFAQTitleConversion(String title, String stateCode) {
		// Special cases where the coverage/liability label on screen does not match the FAQ dialog title
		if (stateCode.equals(MA)) {
			switch(title) {
			case COLLISION_MA:
				title = COLLISION;
				break;
			case COMPREHENSIVE_MA:
				title = COMPREHENSIVE;
				break;
			case COMPULSORY_BODILY_INJURY_MA:
				title = COMPULSORY_BODILY_INJURY;
				break;
			case LIMITED_COLLISION_MA:
				title = LIMITED_COLLISION;
				break;
			case MEDICAL_PAYMENTS_MA:
				title = MEDICAL_PAYMENTS;
				break;
			case OPTIONAL_BODILY_INJURY_MA:
				title = OPTIONAL_BODILY_INJURY;
				break;
			case PERSONAL_INJURY_PROTECTION_MA:
				title = PERSONAL_INJURY_PROTECTION;
				break;
			case PROPERTY_DAMAGE_MA:
				title = PROPERTY_DAMAGE;
				break;
			case SUBSTITUTE_TRANSPORTATION_MA:
				title = SUBSTITUTE_TRANSPORTATION;
				break;
			case TOWING_AND_LABOR_MA:
				title = TOWING_AND_LABOR;
				break;
			case UNDERINSURED_MOTORIST_BODILY_INJURY_MA:
				title = UNDER_CAP_INSURED_MOTORIST_BODILY_INJURY;
				break;
			case UNINSURED_MOTORIST_BODILY_INJURY_MA:
				title = UNINSURED_MOTORIST_BODILY_INJURY;
				break;
			default:
			}
		} else if (isEasternExpansionState(stateCode)) {
			switch(title) {
			case OPTIONAL_PIP:
				if (stateCode.equals(KY)) {
					title = OPTIONAL_PERSONAL_INJURY_PROTECTION_NO_FAULT_COVERAGE;
				}
				break;
			case PERSONAL_INJURY_PROTECTION:
				title = PERSONAL_INJURY_PROTECTION_NO_FAULT_COVERAGE;
				break;
			case UNINSURED_MOTORIST_BI_OPTIONS :
				title = UNINSURED_MOTORIST_BI_LOWERCASE_OPTIONS;
				break;
			case UNINSURED_MOTORIST_BI :
				if (stateCode.equals(LA)) {
					title = UNINSURED_MOTORIST_DASH_BODILY_INJURY;
				} else {
					title = UNINSURED_MOTORIST_BODILY_INJURY;
				}
				break;
			case UNDERINSURED_MOTORIST_BI :
				title = UNDERINSURED_MOTORIST_BODILY_INJURY;
				break;
			case UNINSURED_MOTORIST_PD_WITHOUT_UPPERCASE_COLLISION :
				title = UNINSURED_MOTORIST_PD_WITHOUT_COLLISION;
				break;
			case UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BI :
				title = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_BODILY_INJURY;
				break;
			case UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PD :
				title = UNINSURED_MOTORIST_UNDERINSURED_MOTORIST_PROPERTY_DAMAGE;
				break;
			default:
				break;
			}
		} else {
			switch(title) {
			case GLASS_100_COVERAGE:
				title = GLASS_100_DEDUCTIBLE;
				break;
			case RENTAL:
				if(Arrays.asList(AZ, IL).contains(stateCode)) {
					title = "Rental Coverage";
				}
				break;
			case TOWING_AMP_ROAD_SERVICE:
				title = TOWING_AND_ROAD_SERVICE;
				break;
			case UNINSURED_MOTORIST_PD:
				if(Arrays.asList(MS).contains(stateCode)) {
					title = UNINSURED_MOTORIST_PROPERTY_DAMAGE;
				}
				break;
			default:
				break;
			}
		}
		return title;
	}

	public void verifyQualifiedDiscounts(SqlApplicant applicant, FarmersSoftAssert fsa) {
		String applicantStateCode = applicant.getStateCode();
		scrollToElement(discountsListHeader);
		List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC31608", "TC31609", "TC31610", "TC31611", "TC31612", "TC32269"));
		writeTestcaseState("QuotePageAuto.verifyQualifiedDiscounts", applicantStateCode, rallyTestcasesCovered, FAILED);
		String discountsFound = createDiscountsList().toString();
		writeInfoToFile("Discounts found for " + applicantStateCode + SPACE + "<" +discountsFound + ">" + NEWLINE);
		verifyGoodStudentDiscount(applicant, discountsFound, fsa);
		verifyDistantStudentDiscount(applicant, discountsFound, fsa);
		verifySharedFamilyCarDiscount(applicant, discountsFound, fsa);
		verifyBusinessProfessionalGroupDiscount(applicant, discountsFound, fsa);
		verifyMatureDriverDiscount(applicant, discountsFound, fsa);
		verifyMultiCarDiscount(applicant, discountsFound, fsa);
		verifyBundleDiscounts(applicant, discountsFound, fsa);
		veryfyHomeownerDiscount(applicant, discountsFound, fsa);
		verifyGoodPayerDiscount(isGoodPayerState(applicantStateCode), discountsFound, fsa);
		verifySafeDriverlDiscount(applicantStateCode, discountsFound, fsa);
		verifySignalDiscount(applicant, discountsFound, fsa);
		verifyAutopayDiscount(isAutopayDiscountState(applicantStateCode), discountsFound, fsa);
		verifyFiveYearAccidentFreeDiscount(isAlwaysGiveFiveYearAccidentFreeDiscountState(applicantStateCode) || (isFiveYearAccidentFreeDiscountState(applicantStateCode) && isApplicantAccidentFree(applicant)), discountsFound, fsa);
		verifyPaperlessDiscount(isPaperlessDiscountState(applicantStateCode), discountsFound, fsa);
		verifyWelcomeDiscount(isFlexState(applicantStateCode) && !applicantStateCode.equals(ND), discountsFound, fsa);
		verifyEFTDiscount(isEFTDiscountState(applicantStateCode), discountsFound, fsa);
	}

	public void validateCoveragePackages(String stateCode, FarmersSoftAssert fsa) throws Exception {
		String quoteNumber = getRedesignedQuoteNumber();
		waitForQuotePageToRender(quoteNumber);
		if (isElementVisible(viewAllPackagesLink, 10)) {
			setPackageTo(BASIC_PACKAGE);
			List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC41438", "TC41439", "TC41440", "TC41443", "TC41444", "TC41445", "TC41511", "TC41512", "TC41513"));
			writeTestcaseState("QuotePageAuto.validateCoveragePackages", ALL_STATES, rallyTestcasesCovered, FAILED);
			WebElement elementToModify = stateCode.equals(MA)? optionalBodilyInjuryLiabilityDropdown : bodilyInjuryLiabilityDropdown;
			selectFromDropDownByPosition(elementToModify, LAST_AVAILABLE_OPTION, packageDescription);
			if (isCollisionAndComprehensiveCoverageRequiredState(stateCode)) {
				selectFromDropDownByPosition(collisionCoverageDropdown, SECOND_AVAILABLE_OPTION, packageDescription);
				selectFromDropDownByPosition(comprehensiveCoverageDropdown, SECOND_AVAILABLE_OPTION, packageDescription);
			}
			if (stateCode.equals(OH)) {
				selectValueInDropdown(NO_COVERAGE, uninsuredMotoristPDCoverageDropdown, packageDescription);
			}
			if (getTextFromElement(buyNowButton).equals(RECALCULATE)) {
				clickElement(buyNowButton);
			} else {
				selectFromDropDownByPosition(elementToModify, FIRST_AVAILABLE_OPTION, packageDescription);
				selectFromDropDownByPosition(elementToModify, NEXT_TO_LAST_AVAILABLE_OPTION, packageDescription);
				if (getTextFromElement(buyNowButton).equals(RECALCULATE)) {
					clickElement(buyNowButton);
				} else {
					Log.error("Could not modify selections");
					return;
				}
			}
			waitForQuotePageToRender(quoteNumber);
			if (!noErrorsPresentInPage()) {
				Log.error("Some coverages are reporting in error, cannot progress to custom coverage");
				return;
			}
			longWaitForElementToBeGoneByClass("auto-quote-red-line");
			clickElement(viewAllPackagesLink);
			waitForQuotePageToRender(quoteNumber);
			waitElementBeVisibleClickable(confirmButton);
			fsa.assertTrue(isElementPresentByXPath(COVERAGE_PACKAGE_XPATH + BASIC_COVERAGE_PACKAGE), "Basic coverage package found");
			fsa.assertTrue(isElementPresentByXPath(COVERAGE_PACKAGE_XPATH + ENHANCED_COVERAGE_PACKAGE), "Enhanced coverage package found");
			fsa.assertTrue(isElementPresentByXPath(COVERAGE_PACKAGE_XPATH + FULL_COVERAGE_PACKAGE), "Full coverage package found");
			fsa.assertTrue(isElementPresentByXPath(COVERAGE_PACKAGE_XPATH + CUSTOM_COVERAGE_PACKAGE), "Custom coverage package found");
			// Back to FULL Coverage
			clickElement(fullCoveragePackage);
			clickElement(confirmButton);
			waitForPageToRender(quoteNumber);
		} else {
			Log.info("Unable to test quote coverage packages because View All Packages link was not found");
		}
	}

	public boolean saveQuoteAndFinishLater(SqlApplicant applicant) {
		return saveAutoQuoteAndFinishLater(applicant, QUOTE_PAGE_AUTO, applicant.isSaveAndRetrieveQuotePage());
	}

	public void saveImplicitQuoteAndRetrieveLater(SqlApplicant applicant) throws Exception {
		waitForPageToRender(EMPTY_STRING);
		saveAutoApplicant(applicant, QUOTE_PAGE_AUTO, getRedesignedQuoteNumber());
	}

	private boolean isCollisionAndComprehensiveCoverageRequiredState(String stateCode) {
		List<String> collisionAndComprehensiveCoverageRequiredStates = new ArrayList<>(Arrays.asList(NE, NY, TX));
		return collisionAndComprehensiveCoverageRequiredStates.contains(stateCode);
	}

	private void setPackageTo(String packageName) throws KnockoutException {
		scrollToElement(buyNowButton);
		waitAndClickElement(viewAllPackagesLink);
		switch (packageName) {
		case BASIC_PACKAGE:
			clickElement(basicCoveragePackage);
			break;
		case ENHANCED_PACKAGE:
			clickElement(enhancedCoveragePackage);
			break;
		case FULL_PACKAGE:
			clickElement(fullCoveragePackage);
			break;
		case CUSTOM_PACKAGE:
			clickElement(customCoveragePackage);
			break;
		default:
			Log.error("Invalid package name selected: " + packageName);
			break;
		}
		clickElement(confirmButton);
		waitForQuotePageToRender(EMPTY_STRING);
	}

	private String getSelectedPackage() {
		String selectedPackage = getTextFromElement(packageHeader);
		if (selectedPackage.contains(BASIC_PACKAGE)) {
			return BASIC_PACKAGE;
		} else if (selectedPackage.contains(FULL_PACKAGE)) {
			return FULL_PACKAGE;
		} else if (selectedPackage.contains(ENHANCED_PACKAGE)) {
			return ENHANCED_PACKAGE;
		} else if (selectedPackage.contains(CUSTOM_PACKAGE)) {
			return CUSTOM_PACKAGE;
		} else {
			return selectedPackage;
		}
	}

	public void verifyDependentDropdowns(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		String applicantStateCode = applicant.getStateCode();
		if (!applicantStateCode.equals(MI) && !applicantStateCode.equals(MA)) {
			waitForQuotePageToRender(EMPTY_STRING);
			String tcMethod = "QuotePageAuto.verifyDependentDropdowns";
			if (isUnderSpaceInsuredState(applicantStateCode)) {
				List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC40907", "TC40921", "TC40922"));
				writeTestcaseState(tcMethod, applicantStateCode, rallyTestcasesCovered, FAILED);
				selectFromDropDownByPosition(underSpaceInsuredMotoristLiabilityDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
				selectFromDropDownByPosition(bodilyInjuryLiabilityDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
				if (isPropertyDamageState(applicantStateCode)) {
					selectFromDropDownByPosition(propertyDamageDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
				} else {
					selectFromDropDownByPosition(propertyDamageLiabilityDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
				}
				selectFromDropDownByPosition(underSpaceInsuredMotoristLiabilityDropdown, LAST_AVAILABLE_OPTION, packageDescription);
				validateCoverageErrormessages(underSpaceInsuredMotoristLiabilityErrorLabel, underSpaceInsuredMotoristLiabilityErrorMessage, UNDERINSURED_MOTORIST_LIMIT_ERRORMSG, fsa);
				writeTestcaseState(tcMethod, applicantStateCode, rallyTestcasesCovered, PASSED);
				resetQuotePage();
			} else if (isUnderinsuredMotoristBodilyInjuryState(applicantStateCode)) {
				List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC42186", "TC42194", "TC42202"));
				writeTestcaseState(tcMethod, applicantStateCode, rallyTestcasesCovered, FAILED);
				selectFromDropDownByPosition(underinsuredMotoristBodilyInjuryLiabilityDropdown, LAST_AVAILABLE_OPTION, packageDescription);
				selectFromDropDownByPosition(bodilyInjuryLiabilityDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
				String errorMessage;
				switch (applicantStateCode) {
				case OH : case MN :
					errorMessage = UNDERINSURED_MOTORIST_LIMIT_EQUAL_TO_UNINSURED_MOTORIST_LIMIT_ERRORMSG;
					break;
				case WA :
					errorMessage = UNDER_INSURED_MOTORIST_BI_LIMIT_ERRORMSG;
					break;
				case WY :
					errorMessage = UNDERINSURED_MOTORIST_BI_SELECTED_ERRORMSG;
					break;
				default :
					errorMessage = UNDERINSURED_MOTORIST_BI_LIMIT_SELECTED_ERRORMSG;
					break;
				}
				validateCoverageErrormessages(underinsuredMotoristBodilyInjuryLiabilityErrorLabel, underinsuredMotoristBodilyInjuryLiabilityErrorMessage, errorMessage, fsa);
				writeTestcaseState(tcMethod, applicantStateCode, rallyTestcasesCovered, PASSED);
				resetQuotePage();
			}
			if (applicantStateCode.equals(TX)) {
				List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC42221", "TC42234", "TC42202"));
				writeTestcaseState(tcMethod, applicantStateCode, rallyTestcasesCovered, FAILED);
				selectFromDropDownByPosition(medicalLiabilityDropdown, LAST_AVAILABLE_OPTION, packageDescription);
				selectFromDropDownByPosition(personalInjuryProtectionLiabilityDropdown, LAST_AVAILABLE_OPTION, packageDescription);
				validateCoverageErrormessages(medicalLiabilityErrorLabel, medicalLiabilityErrorMessage, MEDICAL_COVERAGE_AND_PIP_ERRORMSG, fsa);
				writeTestcaseState(tcMethod, applicantStateCode, rallyTestcasesCovered, PASSED);
				resetQuotePage();
			}
			List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC42628", "TC43339", "TC43340", "TC43341", "TC43342", "TC43343"));
			if(Arrays.asList(MS, OH).contains(applicantStateCode)) {
				writeTestcaseState(tcMethod, applicantStateCode, rallyTestcasesCovered, FAILED);
				String errorMessage = applicantStateCode.equals(OH)? UMPD_AND_PD_ERRORMSG_OH : UMPD_AND_PD_ERRORMSG;
				selectFromDropDownByPosition(uninsuredMotoristPDCoverageDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
				if (applicantStateCode.equals(MS)) {
					selectFromDropDownByPosition(propertyDamageDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
					selectFromDropDownByPosition(uninsuredMotoristPDCoverageDropdown, LAST_AVAILABLE_OPTION, packageDescription);
					validateCoverageErrormessages(uninsuredMotoristPDCoverageErrorLabel, uninsuredMotoristPDCoverageErrorMessage, errorMessage, fsa);
				} else {
					selectFromDropDownByPosition(propertyDamageLiabilityDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
					selectFromDropDownByPosition(uninsuredMotoristPDCoverageDropdown, LAST_AVAILABLE_OPTION, packageDescription);
					validateCoverageErrormessages(uninsuredMotoristPDCoverageErrorLabel, uninsuredMotoristPDCoverageErrorMessage, errorMessage, fsa);
				}
				writeTestcaseState(tcMethod, applicantStateCode, rallyTestcasesCovered, PASSED);
				resetQuotePage();
			}
			if(applicantStateCode.equals(AR) || applicantStateCode.equals(NJ)) {
				writeTestcaseState(tcMethod, applicantStateCode, rallyTestcasesCovered, FAILED);
				selectFromDropDownByPosition(uninsuredMotoristPropertyDamageCoverageDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
				if (applicantStateCode.equals(NJ)) {
					selectFromDropDownByPosition(propertyDamageDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
					selectFromDropDownByPosition(uninsuredMotoristPropertyDamageCoverageDropdown, LAST_AVAILABLE_OPTION, packageDescription);
					validateCoverageErrormessages(uninsuredMotoristPropertyDamageCoverageErrorLabel, uninsuredMotoristPropertyDamageCoverageErrorMessage, UMPD_AND_PD_ERRORMSG, fsa );
				} else {
					selectFromDropDownByPosition(propertyDamageLiabilityDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
					selectFromDropDownByPosition(uninsuredMotoristPropertyDamageCoverageDropdown, LAST_AVAILABLE_OPTION, packageDescription);
					validateCoverageErrormessages(uninsuredMotoristPropertyDamageCoverageErrorLabel, uninsuredMotoristPropertyDamageCoverageErrorMessage, UMPD_AND_PD_ERRORMSG, fsa );
				}
				writeTestcaseState(tcMethod, applicantStateCode, rallyTestcasesCovered, PASSED);
				resetQuotePage();
			}
			if (isUninsuredMotoristState(applicantStateCode) && uninsuredMotoristValidDependencyState(applicantStateCode)) {
				String errorMessage = isBILimitErrorMessageState(applicantStateCode)? UNINSURED_MOTORIST_BI_LIMIT_ERRORMSG : UNINSURED_MOTORIST_LIMIT_ERRORMSG;
				List<String> rtcCovered = new ArrayList<>(Arrays.asList("TC40907", "TC40921", "TC40922"));
				writeTestcaseState(tcMethod, applicantStateCode, rtcCovered, FAILED);
				selectFromDropDownByPosition(uninsuredMotoristLiabilityDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
				selectFromDropDownByPosition(bodilyInjuryLiabilityDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
				if (isPropertyDamageState(applicantStateCode)) {
					selectFromDropDownByPosition(propertyDamageDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
				} else {
					selectFromDropDownByPosition(propertyDamageLiabilityDropdown, FIRST_AVAILABLE_OPTION, packageDescription);
				}
				selectFromDropDownByPosition(uninsuredMotoristLiabilityDropdown, LAST_AVAILABLE_OPTION, packageDescription);
				if (Arrays.asList(AL, AZ, MT, ND, SD, UT).contains(applicantStateCode)) {
					validateCoverageErrormessages(uninsuredMotoristLiabilityErrorLabel, uninsuredMotoristLiabilityErrorMessage, errorMessage, fsa);
				} else {
					validateCoverageErrormessages(bodilyInjuryLiabilityErrorLabel, bodilyInjuryLiabilityErrorMessage, errorMessage, fsa);
				}
				writeTestcaseState(tcMethod, applicantStateCode, rtcCovered, PASSED);
				resetQuotePage();
			}
			if (isFlexState(applicantStateCode) && !hasFinancedVehicle(applicant)) {
				scrollElementToMiddle(collisionCoverageDropdown);
				selectValueInDropdown(NO_COVERAGE, collisionCoverageDropdown, packageDescription);
				selectFromDropDownByPosition(comprehensiveCoverageDropdown, NEXT_TO_LAST_AVAILABLE_OPTION, packageDescription);
				selectFromDropDownByPosition(rentalCoverageDropdown, LAST_AVAILABLE_OPTION, packageDescription);
				validateCoverageErrormessages(rentalCoverageErrorLabel, rentalCoverageErrorMessage, RENTAL_REQUIRES_COMP_AND_COLL, fsa);
				resetQuotePage();
				selectValueInDropdown(NO_COVERAGE, comprehensiveCoverageDropdown, packageDescription);
				selectFromDropDownByPosition(collisionCoverageDropdown, NEXT_TO_LAST_AVAILABLE_OPTION, packageDescription);
				selectFromDropDownByPosition(rentalCoverageDropdown, LAST_AVAILABLE_OPTION, packageDescription);
				validateCoverageErrormessages(rentalCoverageErrorLabel, rentalCoverageErrorMessage, RENTAL_REQUIRES_COMP_AND_COLL, fsa);
				resetQuotePage();
				selectValueInDropdown(NO_COVERAGE, collisionCoverageDropdown, packageDescription);
				selectFromDropDownByPosition(comprehensiveCoverageDropdown, NEXT_TO_LAST_AVAILABLE_OPTION, packageDescription);
				selectValueInDropdown(COVERAGE, vehicleReplacementCoverageDropdown, packageDescription);
				validateCoverageErrormessages(vehicleReplacementCoverageErrorLabel, vehicleReplacementCoverageErrorMessage, VEHICLE_REPLACEMENT_REQUIRES_COMP_AND_COLL, fsa);
				resetQuotePage();
				selectValueInDropdown(NO_COVERAGE, comprehensiveCoverageDropdown, packageDescription);
				selectFromDropDownByPosition(collisionCoverageDropdown, NEXT_TO_LAST_AVAILABLE_OPTION, packageDescription);
				selectValueInDropdown(COVERAGE, vehicleReplacementCoverageDropdown, packageDescription);
				validateCoverageErrormessages(vehicleReplacementCoverageErrorLabel, vehicleReplacementCoverageErrorMessage, VEHICLE_REPLACEMENT_REQUIRES_COMP_AND_COLL, fsa);
				resetQuotePage();
				selectValueInDropdown(NO_COVERAGE, comprehensiveCoverageDropdown, packageDescription);
				selectFromDropDownByPosition(collisionCoverageDropdown, NEXT_TO_LAST_AVAILABLE_OPTION, packageDescription);
				selectValueInDropdown(COVERAGE, glassCoverage100Dropdown, packageDescription);
				validateCoverageErrormessages(glassCoverage100ErrorLabel, glassCoverage100ErrorMessage, GLASS_COVERAGE_REQUIRES_COMP, fsa);
				resetQuotePage();
				if (isUnderinsuredMotoristBIState(applicantStateCode) && isUninsuredMotoristBIState(applicantStateCode) && !Arrays.asList(NE, ID).contains(applicantStateCode)) {
					selectValueInDropdown(NO_COVERAGE, uninsuredMotoristBILiabilityDropdown, packageDescription);
					selectFromDropDownByPosition(underinsuredMotoristBILiabilityDropdown, LAST_AVAILABLE_OPTION, packageDescription);
					validateCoverageErrormessages(underinsuredMotoristBILiabilityErrorLabel, underinsuredMotoristBILiabilityErrorMessage, UNDERINSURED_MOTORIST_REQUIRES_UNINSURED_MOTORIST, fsa);
					resetQuotePage();
					if (!(applicantStateCode.equals(AR))) {
						selectFromDropDownByPosition(bodilyInjuryLiabilityDropdown, LAST_AVAILABLE_OPTION, packageDescription);
						selectFromDropDownByPosition(uninsuredMotoristBILiabilityDropdown, NEXT_TO_LAST_AVAILABLE_OPTION, packageDescription);
						selectFromDropDownByPosition(underinsuredMotoristBILiabilityDropdown, LAST_AVAILABLE_OPTION, packageDescription);
						validateCoverageErrormessages(underinsuredMotoristBILiabilityErrorLabel, underinsuredMotoristBILiabilityErrorMessage, UNDERINSURED_MOTORIST_CANT_EXCEED_UNINSURED_MOTORIST, fsa);
						resetQuotePage();
					}
				}
			}
		}
	}

	private void resetQuotePage() throws KnockoutException {
		if (isElementPresentByXPath(VIEW_ALL_PACKAGES_XPATH)) {
			setPackageTo(BASIC_PACKAGE);
			setPackageTo(FULL_PACKAGE);
		} else {
			clickQuickLink(DISCOUNTS);
			clickQuickLink(QUOTE);
		}
	}

	private boolean isBILimitErrorMessageState(String stateCode) {
		List<String> biLimitErrorStates = new ArrayList<>(Arrays.asList(AZ, OK, UT));
		return biLimitErrorStates.contains(stateCode);
	}

	private boolean uninsuredMotoristValidDependencyState(String stateCode) {
		List<String> invalidStates = new ArrayList<>(Arrays.asList(NY, VA));
		return !invalidStates.contains(stateCode);
	}

	public void validateGTMTags(String stateCode, FarmersSoftAssert fsa) throws Exception {
		clickElement(quotePageHeader);
		List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC34003", "TC34010", "TC34013", "TC34020", "TC34023", "TC34024", "TC34025"));
		writeTestcaseState("QuotePageAuto.validateGTMTags", ALL_STATES, rallyTestcasesCovered, FAILED);
		verifyElementExpectedAttribute(getListWithPageElements(stateCode), getMapWithExpectedGTMTags(stateCode), DATA_GTM, fsa);
		writeTestcaseState("QuotePageAuto.validateGTMTags", ALL_STATES, rallyTestcasesCovered, PASSED);
	}

	public void verifyStateSpecificScenarios(String stateCode, FarmersSoftAssert fsa) throws Exception {
		if (stateCode.equals(CT)) {
			selectFromDropDownByPosition(uninsuredUnderSpaceInsuredMotoristBILiabilityDropdown, LAST_AVAILABLE_OPTION, packageDescription);
			selectFromDropDownByPosition(uninsuredUnderInsuredMotoristBIConversionLiabilityDropdown, LAST_AVAILABLE_OPTION, packageDescription);
			validateCoverageErrormessages(uninsuredUnderInsuredMotoristBIConversionLiabilityErrorLabel, uninsuredUnderInsuredMotoristBIConversionLiabilityErrorMessage, UUIMBI_CONVERSION_ERRORMSG, fsa);
			recalculateQuote();
			setPackageTo(FULL_PACKAGE);
		}
		if (stateCode.equals(PA)) {
			setPackageTo(BASIC_PACKAGE);
			fsa.assertTrue(isElementPresent(By.xpath(UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_LABEL_XPATH)), UNINSURED_STACKING_OPTION_DROPDOWN_PRESENT);
			fsa.assertTrue(isElementPresent(By.xpath(UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_LABEL)), UNDERINSURED_STACKING_OPTION_DROPDOWN_PRESENT);
			selectValueInDropdown(NO_COVERAGE, uninsuredMotoristBodilyInjuryLiabilityDropdown, packageDescription);
			fsa.assertFalse(isElementPresent(By.xpath(UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_LABEL_XPATH)), UNINSURED_STACKING_OPTION_DROPDOWN_NOT_PRESENT);
			selectValueInDropdown(NO_COVERAGE, underinsuredMotoristBodilyInjuryLiabilityDropdown, packageDescription);
			fsa.assertFalse(isElementPresent(By.xpath(UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_LABEL)), UNDERINSURED_STACKING_OPTION_DROPDOWN_NOT_PRESENT);
			setPackageTo(ENHANCED_PACKAGE);
			fsa.assertTrue(isElementPresent(By.xpath(UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_LABEL_XPATH)), UNINSURED_STACKING_OPTION_DROPDOWN_PRESENT);
			fsa.assertTrue(isElementPresent(By.xpath(UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_LABEL)), UNDERINSURED_STACKING_OPTION_DROPDOWN_PRESENT);
			selectValueInDropdown(NO_COVERAGE, uninsuredMotoristBodilyInjuryLiabilityDropdown, packageDescription);
			fsa.assertFalse(isElementPresent(By.xpath(UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_LABEL_XPATH)), UNINSURED_STACKING_OPTION_DROPDOWN_NOT_PRESENT);
			selectValueInDropdown(NO_COVERAGE, underinsuredMotoristBodilyInjuryLiabilityDropdown, packageDescription);
			fsa.assertFalse(isElementPresent(By.xpath(UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_LABEL)), UNDERINSURED_STACKING_OPTION_DROPDOWN_NOT_PRESENT);
			setPackageTo(FULL_PACKAGE);
			fsa.assertTrue(isElementPresent(By.xpath(UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_LABEL_XPATH)), UNINSURED_STACKING_OPTION_DROPDOWN_PRESENT);
			fsa.assertTrue(isElementPresent(By.xpath(UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_LABEL)), UNDERINSURED_STACKING_OPTION_DROPDOWN_PRESENT);
			selectValueInDropdown(NO_COVERAGE, uninsuredMotoristBodilyInjuryLiabilityDropdown, packageDescription);
			fsa.assertFalse(isElementPresent(By.xpath(UNINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_LABEL_XPATH)), UNINSURED_STACKING_OPTION_DROPDOWN_NOT_PRESENT);
			selectValueInDropdown(NO_COVERAGE, underinsuredMotoristBodilyInjuryLiabilityDropdown, packageDescription);
			fsa.assertFalse(isElementPresent(By.xpath(UNDERINSURED_MOTORIST_BODILY_INJURY_STACKING_OPTION_FAQ_XPATH + XPATH_TO_LABEL)), UNDERINSURED_STACKING_OPTION_DROPDOWN_NOT_PRESENT);
			setPackageTo(FULL_PACKAGE);
		}
	}

	private void recalculateQuote() throws KnockoutException {
		if (getAttributeData(buyNowButton, DATA_GTM).contains("recalculate") || getTextFromElement(buyNowButton).equals(RECALCULATE)) {
			clickElement(buyNowButton);
			waitForQuotePageToRender(EMPTY_STRING);
		}
	}

	public void clickBuyNow() throws Exception {
		if (isElementPresentByXPath(ACTION_BUTTON_XPATH)) {
			clickElement(buyNowButton);
			longWaitForElementToBeGoneByXpath(BODILY_INJURY_FAQ_XPATH);
			waitForPageToRender(EMPTY_STRING);
			if (isBrightlinedQuote()) {
				continueToBristolWest(true);
				isBristolWest = true;
				waitForQuotePageToRender(EMPTY_STRING);
			}
			waitForSpinnerToBeGone();
		}
	}

	@Override
	public void clickContinueButton() {
		if (getAttributeData(buyNowButton, DATA_GTM).contains("continue")) {
			clickElement(buyNowButton);
			waitForSpinnerToBeGone();
		}
	}

	public void clickOnHomeLob() throws Exception {
		String xPath = CROSSSELL_TEXT_XPATH.substring(0,CROSSSELL_TEXT_XPATH.length()-1);
		WebElement weElement = driver().findElement(By.xpath(xPath + " and text()='Home Quote']"));
		clickElement(weElement);
	}

	public void validateHQMCrossSell(FarmersSoftAssert fsa) throws Exception {
		String discountsList = createDiscountsList().toString();
		fsa.assertTrue(discountsList.contains(AUTO_AMP_HOME), AUTO_AMP_HOME + EXPECTED_TO_BE);
		fsa.assertTrue(discountsList.contains(HOMEOWNER), HOMEOWNER + EXPECTED_TO_BE);
		fsa.assertTrue(getCrossSellLobList().toString().contains("Home quote"), "Auto Quote Page - Home Quote lob link");
	}

	public boolean updateQuoteAndRate(SqlApplicant applicant, boolean tryToUsePackage) throws Exception {
		double quoteRate = Double.parseDouble(getPremiumAmount().replaceAll(NON_CURRENCY_CHARS, EMPTY_STRING));
		closeSurveyDialog();
		if (tryToUsePackage && isElementPresentByXPath(VIEW_ALL_PACKAGES_XPATH)) {
			setPackageTo(FULL_PACKAGE);
		} else if (!applicant.getStateCode().equals(MA)) {
			selectFromDropDownByPosition(bodilyInjuryLiabilityDropdown, NEXT_TO_LAST_AVAILABLE_OPTION, packageDescription);
			selectFromDropDownByPosition(collisionCoverageDropdown, LAST_AVAILABLE_OPTION, packageDescription);
			selectFromDropDownByPosition(comprehensiveCoverageDropdown, LAST_AVAILABLE_OPTION, packageDescription);
			if (getAttributeData(buyNowButton, DATA_GTM).contains("recalculate")) {
				clickElement(buyNowButton);
				waitForQuotePageToRender(EMPTY_STRING);
			} else {
				Assert.fail("Recalculate button not found" + NEWLINE);
			}
		}
		closeSurveyDialog();
		double updatedQuoteRate = Double.parseDouble(getPremiumAmount().replaceAll(NON_CURRENCY_CHARS, EMPTY_STRING));
		return (quoteRate != updatedQuoteRate);
	}

	private void financedVehicleCheck(SqlApplicant applicant) throws Exception {
		if (hasFinancedVehicle(applicant)) {
			updateQuoteAndRate(applicant, applicant.getStateCode().equals(MA));
		}
	}

	private boolean hasFinancedVehicle(SqlApplicant applicant) {
		//Financed vehicles require full coverage
		boolean hasFinancedVehicle = false;
		for (SqlVehicle vehicle : applicant.getVehicles()) {
			if (Arrays.asList("Financed", "Leased").contains(vehicle.getOwnership())) {
				hasFinancedVehicle = true;
				break;
			}
		}
		return hasFinancedVehicle;
	}

	private List<String> getCrossSellLobList() throws Exception {
		List<String> listPageDiscounts = driver().findElements(By.xpath(CROSSSELL_TEXT_XPATH)).stream().
				map(this::getTextFromElement).collect(Collectors.toList());
		Log.info("Cross-sell LOBs: " + listPageDiscounts);
		return listPageDiscounts;
	}

	public String getPremiumAmount() {
		return getTextFromElement(quoteAmountField);
	}

	public boolean hasCrossSellQuote(String quoteType) {
		switch(quoteType) {
		case LOB_CONDO :
			return isElementPresentByXPath(CONDO_CROSSSELL_TEXT_XPATH);
		case LOB_HOME :
			return isElementPresentByXPath(HOME_CROSSSELL_TEXT_XPATH);
		case LOB_LIFE :
			return isElementPresentByXPath(VTL_CROSSSELL_TEXT_XPATH);
		case LOB_RENTERS :
			return isElementPresentByXPath(RENTERS_CROSSSELL_TEXT_XPATH);
		default :
			Assert.fail("Unknown cross sell type: " + quoteType);
			return false;
		}
	}

	public void clickCrossSellQuote(String quoteType) {
		switch (quoteType) {
		case LOB_CONDO :
			scrollAndClickOnElement(crossSellCondoQuote);
			break;
		case LOB_HOME :
			scrollAndClickOnElement(crossSellHomeQuote);
			break;
		case LOB_LIFE :
			scrollAndClickOnElement(crossSellVTLQuote);
			break;
		case LOB_RENTERS :
			scrollAndClickOnElement(crossSellRentersQuote);
			break;
		default :
			Assert.fail("Unknown cross sell LOB type: " + quoteType);
		}
	}

	public void navigateToThankYouPage() throws Exception {
		String buyNowXpath = "//div//button[text()='BUY NOW']";
		String continueXpath = "//div//button[text()='CONTINUE']";
		if (isElementDisplayed(By.xpath(buyNowXpath))) {
			driver().get(driver().getCurrentUrl().replaceFirst("/quote", "/thankyou"));
		} else {
			if (isElementDisplayed(By.xpath(continueXpath))) {
				waitAndClickElement(driver().findElement(By.xpath(continueXpath)));
			}
		}
	}

	public boolean isEligibleToBuyQuote() {
		return getAttributeData(buyNowButton, DATA_GTM).contains("buynow_button");
	}

    private static void writeInfoToFile(String stringToWrite) {
        try {
            Files.write(Paths.get(System.getProperty(USER_DIR_PROPERTY) + "/build/coveragesAndDiscounts.log"), stringToWrite.getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void verifyAllDropdownValues(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		try {
			verifyAllAvailableValuesForMapOfDropdowns(getMapWithQuotePageDropdownExpValues(applicant), packageDescription, fsa);
		} catch (AssertionError ae) {
			Log.error("Quote page dropdown values check failed: " + ae.getMessage());
		}
		scrollToTopOfPage();
		clickQuickLink(DISCOUNTS);
		clickQuickLink(QUOTE);
	}

	private void verifyDefaultValuesForAllDropdowns(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		if (isFlexState(applicant.getStateCode())) {
			setPackageTo(BASIC_PACKAGE);
			if (getSelectedPackage().equals(BASIC_PACKAGE)) {
				try {
					verifyCurrentSelectedValueForMapOfDropdowns(getMapWithBasicDropdownExpValues(applicant), fsa);
				} catch (AssertionError ae) {
					Log.error("Quote page current selected values for basic package check failed: " + ae.getMessage());
				} catch (NoSuchElementException nsee) {
					Log.error("Quote page element error for basic package: " + nsee.getMessage());
				}
			} else {
				Log.error("Could not change to Basic Package");
			}
			setPackageTo(ENHANCED_PACKAGE);
			if (getSelectedPackage().equals(ENHANCED_PACKAGE)) {
				try {
					verifyCurrentSelectedValueForMapOfDropdowns(getMapWithEnhancedDropdownExpValues(applicant), fsa);
				} catch (AssertionError ae) {
					Log.error("Quote page current selected values for enhanced package check failed: " + ae.getMessage());
				} catch (NoSuchElementException nsee) {
					Log.error("Quote page element error for enhanced package: " + nsee.getMessage());
				}
			} else {
				Log.error("Could not change to Enhanced Package");
			}
			setPackageTo(FULL_PACKAGE);
			if (getSelectedPackage().equals(FULL_PACKAGE)) {
				try {
					verifyCurrentSelectedValueForMapOfDropdowns(getMapWithFullDropdownExpValues(applicant), fsa);
				} catch (AssertionError ae) {
					Log.error("Quote page current selected values for full package check failed: " + ae.getMessage());
				} catch (NoSuchElementException nsee) {
					Log.error("Quote page element error for full package: " + nsee.getMessage());
				}
			} else {
				Log.error("Could not change to Full Package");
			}
		}
	}

	public void logQuoteNumber(SqlApplicant applicant) {
		String quoteNumber = getRedesignedQuoteNumber();
		writeRatedQuoteInformationToFile("Legacy Auto - " + quoteNumber + SPACE + applicant.getFirstName() + SPACE + applicant.getLastName() + SPACE + applicant.getResidentAddress1() + SPACE + applicant.getCity() + SPACE + applicant.getStateCode() + SPACE + applicant.getZipCode() + SPACE + getPremiumAmount());
	}

	private void validateCoverageErrormessages(WebElement labelElement, WebElement errorMessageElement, String errorMessage, FarmersSoftAssert fsa) {
		fsa.assertTrue(isElementPresentByClass(quoteAmountFieldStruckthrough), "Premium amount displayed struckout");
		fsa.assertEquals(getTextFromElement(buyNowButton), RECALCULATE, "Text in button");
		String labelInErrorColor = labelElement.getCssValue(COLOR);
		String errorMessageColor = errorMessageElement.getCssValue(COLOR);
		String errorMessageText = getTextFromElement(errorMessageElement);
		fsa.assertEquals(isErrorColor(labelInErrorColor), true, labelElement + COLOR_ERROR_MSG + labelInErrorColor);
		fsa.assertEquals(errorMessageText, errorMessage, errorMessageElement.toString());
		fsa.assertEquals(isErrorColor(errorMessageColor), true, errorMessageElement + COLOR_ERROR_MSG + errorMessageColor);
	}

	private boolean isErrorColor(String checkForColor) {
		List<String> errorColors = new ArrayList<>(Arrays.asList(RED_RGB, RED_RGBA, RED_RGB_AUTO_REDESIGN, RED_RGBA_AUTO_REDESIGN));
		return errorColors.contains(checkForColor);
	}

	private StringBuilder createDiscountsList() {
		StringBuilder sb = new StringBuilder();
		List<String> discountsFound = new ArrayList<>();
		int numberOfDiscountsInPage = listOfDiscounts.size();
		for (int i=0; i< numberOfDiscountsInPage; i++) {
			try {
				String discountText = getTextFromElement(listOfDiscounts.get(i));
				if (!discountText.equals(EMPTY_STRING)) {
					discountsFound.add(discountText);
				}
			} catch (StaleElementReferenceException see) {
				Log.warn("Stale discount element " + see.getMessage());
				String discountText = getTextFromElement(listOfDiscounts.get(i));
				if (!discountText.equals(EMPTY_STRING)) {
					discountsFound.add(discountText);
				}
		}
		}
		Collections.sort(discountsFound);
		for (String discount : discountsFound) {
			sb.append(discount).append("|");
		}
		Log.info("discount elements found: " + numberOfDiscountsInPage + " -> " + sb);
		if (numberOfDiscountsInPage != discountsFound.size()) {
			Log.error("Discounts listed not the same as those present");
		}
		return sb;
	}

	private void verifyBundleDiscounts(SqlApplicant applicant, String discountsFound, FarmersSoftAssert fsa) {
		SqlDiscount applicantDiscount = applicant.getDiscounts();
		String applicantStateCode = applicant.getStateCode();
		fsa.assertEquals(discountsFound.contains(AUTO_AMP_HOME), isAutoHomeBundleState(applicantStateCode) && ((applicantDiscount.isHomeInsurance() && applicantDiscount.getOwnOrRentHome().equals(OWN_A_HOME)) ||
				(applicantDiscount.isCondoInsurance() && applicantDiscount.getOwnOrRentHome().equals(OWN_A_CONDO))), AUTO_AMP_HOME + EXPECTED_TO_BE);
		fsa.assertEquals(discountsFound.contains(AUTO_AMP_RENT), applicantDiscount.isRentersInsurance() && (!applicantStateCode.equals(NC) && !isRentersCrossSellDisabledState(applicantStateCode)), AUTO_AMP_RENT + EXPECTED_TO_BE);
		fsa.assertEquals(discountsFound.contains(AUTO_AMP_UMBRELLA), applicantDiscount.isUmbrellaInsurance() && isUmbrellaInsuranceState(applicantStateCode), AUTO_AMP_UMBRELLA + EXPECTED_TO_BE);
		fsa.assertEquals(discountsFound.contains(AUTO_AMP_BUSINESS), applicantDiscount.isBusinessInsurance() && isBusinessInsuranceDiscountState(applicantStateCode), AUTO_AMP_BUSINESS + EXPECTED_TO_BE);
		fsa.assertEquals(discountsFound.contains(AUTO_AMP_LIFE), applicantDiscount.isValueTermLifeInsurance() && isLifeInsuranceDiscountState(applicantStateCode), AUTO_AMP_LIFE + EXPECTED_TO_BE);
	}

	private boolean isAutoHomeBundleState(String stateCode) {
		List<String> noAutoHomeBundleStates = new ArrayList<>(Arrays.asList(AL, CT, KY, MA));
		return !noAutoHomeBundleStates.contains(stateCode);
	}

	protected boolean isBusinessInsuranceDiscountState(String stateCode) {
		return isBusinessInsuranceState(stateCode) && !isFlexState(stateCode);
	}

	protected boolean isLifeInsuranceDiscountState(String stateCode) {
		return ((isLifeInsuranceOfferingState(stateCode) && !isFlexState(stateCode) && !Arrays.asList(AL, MT).contains(stateCode)) || Arrays.asList(AZ, GA, ID, NE, NJ, NM, TN, TX, WY).contains(stateCode));
	}

	private void verifyMultiCarDiscount(SqlApplicant applicant, String discounts, FarmersSoftAssert fsa) {
		String multiCarDiscountText = applicant.getStateCode().equals(CA)? MULTI_CAR_DISCOUNT : MULTIPLE_CAR_DISCOUNT;
		fsa.assertEquals(discounts.contains(multiCarDiscountText), applicant.getVehicles().size() > 1, multiCarDiscountText + EXPECTED_TO_BE);
	}

	private void verifyMatureDriverDiscount(SqlApplicant applicant, String discounts, FarmersSoftAssert fsa) {
		String applicantStateCode = applicant.getStateCode();
		boolean seniorDiscountApplies = applicant.getAge() >= MIN_OLD_AGE && applicant.isCompletedDriversSafetyCourse();
		if (isFlexState(applicantStateCode)) {
			//Flex rollout 7
			String discountName = applicantStateCode.equals(PA)? DRIVER_IMPROVEMENT_DISCOUNT : MATURE_DRIVER_DISCOUNT;
			fsa.assertEquals(discounts.contains(discountName), seniorDiscountApplies, discountName + EXPECTED_TO_BE);
		} else if (isSeniorDiscountState(applicant.getStateCode())) {
			fsa.assertEquals(discounts.contains(SENIOR_DISCOUNT), seniorDiscountApplies, SENIOR_DISCOUNT + EXPECTED_TO_BE);
		} else {
			fsa.assertFalse(discounts.contains(SENIOR_DISCOUNT) || discounts.contains(MATURE_DRIVER_DISCOUNT), SENIOR_DISCOUNT + " or " + MATURE_DRIVER_DISCOUNT + EXPECTED_TO_BE);
		}
	}

	private void verifyBusinessProfessionalGroupDiscount(SqlApplicant applicant, String discounts, FarmersSoftAssert fsa) {
		boolean businessProfessionalDiscount = (isBusinessProfessionalDiscountState(applicant.getStateCode()) && !applicant.getOccupation().equalsIgnoreCase(OTHER));
		fsa.assertEquals(discounts.contains(BUSINESS_GROUP_DISCOUNT), businessProfessionalDiscount, BUSINESS_GROUP_DISCOUNT_ERROR_MSG + applicant.getOccupation());
	}

	private void verifySharedFamilyCarDiscount(SqlApplicant applicant, String discounts, FarmersSoftAssert fsa) {
		boolean sharedFamilyCarDiscount = (isSharedFamiyDiscountState(applicant.getStateCode()) && applicant.getAge() > MAX_YOUNG_AGE && anyDistantDrivers(applicant, false) && applicant.getVehicles().size() < (applicant.getAdditionalDrivers().size() + 1));
		fsa.assertEquals(discounts.contains(SHARED_FAMILY_CAR_DISCOUNT), sharedFamilyCarDiscount, SHARED_FAMILY_CAR_DISCOUNT + EXPECTED_TO_BE);
	}

	private void verifyGoodPayerDiscount(boolean discountApplies, String discounts, FarmersSoftAssert fsa) {
		fsa.assertEquals(discounts.contains(GOOD_PAYER_DISCOUNT), discountApplies, GOOD_PAYER_DISCOUNT + EXPECTED_TO_BE);
	}

	private void verifyGoodStudentDiscount(SqlApplicant applicant, String discounts, FarmersSoftAssert fsa) {
		boolean goodStudentDiscount = ((applicant.getAge() <= MAX_YOUNG_AGE && applicant.isFullTimeStudentWithHighGPA() && applicant.getMaritalStatus().equalsIgnoreCase(SINGLE)) ||
				anyGoodStudentAdditionalDrivers(applicant));
		fsa.assertEquals(discounts.contains(GOOD_STUDENT_DISCOUNT), goodStudentDiscount, GOOD_STUDENT_DISCOUNT + EXPECTED_TO_BE);
	}

	private boolean anyGoodStudentAdditionalDrivers(SqlApplicant applicant) {
		boolean result = false;
		int additionalDrivers = applicant.getAdditionalDrivers().size();
		if ( additionalDrivers> 0) {
			for (int i=0; i < additionalDrivers; i++) {
				SqlAdditionalDriver additional = applicant.getAdditionalDrivers().get(i);
				if (additional.getAge() <= MAX_YOUNG_AGE && additional.isFullTimeStudentWithHighGPA() && additional.getMaritalStatus().equalsIgnoreCase(SINGLE)) {
					result = true;
					break;
				}
			}
		}
		return result;
	}

	private void verifyDistantStudentDiscount(SqlApplicant applicant, String discounts, FarmersSoftAssert fsa) {
		boolean distantStudentDiscount = anyDistantSchoolDrivers(applicant);
		fsa.assertEquals(discounts.contains(DISTANT_STUDENT_DISCOUNT), distantStudentDiscount, DISTANT_STUDENT_DISCOUNT + EXPECTED_TO_BE);
	}

	private boolean anyDistantDrivers(SqlApplicant applicant, boolean lookForDistantSchoolFlag) {
		boolean result = false;
		int additionalDrivers = applicant.getAdditionalDrivers().size();
		if (isDistantStudentState(applicant.getStateCode()) && additionalDrivers> 0) {
			for (int i=0; i < additionalDrivers; i++) {
				SqlAdditionalDriver additional = applicant.getAdditionalDrivers().get(i);
				if (lookForDistantSchoolFlag) {
					result =  (additional.getAge() <= MAX_YOUNG_AGE && additional.getMaritalStatus().equalsIgnoreCase(SINGLE) && additional.isAttendsDistantSchool() &&
							Arrays.asList(SON, DAUGHTER).contains(additional.getRelationshipToApplicant()));
				} else {
					result = (additional.getAge() <= SHARED_DRIVER_AGE && additional.getMaritalStatus().equalsIgnoreCase(SINGLE) &&
							Arrays.asList(SON, DAUGHTER, GRANDCHILD).contains(additional.getRelationshipToApplicant()));
				}
				if (result) {
					break;
				}
			}
		}
		return result;
	}

	private boolean anyDistantSchoolDrivers(SqlApplicant applicant) {
		return anyDistantDrivers(applicant, true);
	}

	private void veryfyHomeownerDiscount(SqlApplicant applicant, String discounts, FarmersSoftAssert fsa) {
		SqlDiscount applicantDiscounts = applicant.getDiscounts();
		String dwellingStatus = applicantDiscounts.getOwnOrRentHome();
		String stateCode = applicant.getStateCode();
		boolean homeownerDiscount =  (applicantDiscounts.isHomeInsurance() && ((ownsValidDwelling(dwellingStatus) && isHomeownerDiscountState(stateCode)) ||
				  (dwellingStatus.equals(OWN_MOBILE_HOME) && isMobilehomeownerDiscountState(stateCode))))
				|| (applicantDiscounts.isCondoInsurance() && dwellingStatus.equals(OWN_A_CONDO) && !(Arrays.asList(MI, MN, ND, TN).contains(stateCode)));
		fsa.assertEquals(discounts.contains(HOMEOWNER), homeownerDiscount, HOMEOWNER + EXPECTED_TO_BE);
	}

	private boolean ownsValidDwelling(String dwellingOwnershipStatus) {
		List<String> validDwelings = new ArrayList<>(Arrays.asList(OWN_APARTMENT, OWN_A_CONDO, OWN_FARM, OWN_A_HOME));
		return validDwelings.contains(dwellingOwnershipStatus);
	}

	private boolean isHomeownerDiscountState(String stateCode) {
		List<String> neverHomeownerDiscountStates = new ArrayList<>(Arrays.asList(MA, MN, NC));
		return !(neverHomeownerDiscountStates.contains(stateCode) || (isFlexState(stateCode) && !Arrays.asList(CO, VA).contains(stateCode)));
	}

	private boolean isMobilehomeownerDiscountState(String stateCode) {
		return Arrays.asList(AL, IA, IN, KS, KY, LA, MD, MO, MS, MT, NV, NY, OH, UT).contains(stateCode);
	}

	private void verifyEFTDiscount(boolean discountApplies, String discounts, FarmersSoftAssert fsa) {
		fsa.assertEquals(discounts.contains(EFT_DISCOUNT), discountApplies, EFT_DISCOUNT + EXPECTED_TO_BE);
	}

	private boolean isSafeDriverDiscountState(String applicantStateCode) {
		return !applicantStateCode.equals(NC) && (isEasternExpansionState(applicantStateCode) || Arrays.asList(AL, CA, CT, GA, IA, IN, KS, MD, MN, MO, MT, NJ, NY, NV, OH, UT).contains(applicantStateCode));
	}

	private void verifySafeDriverlDiscount(String applicantStateCode, String discounts, FarmersSoftAssert fsa) {
		String safeDriverDiscountString = applicantStateCode.equals(CA) ? "Safe Driving" : "Safe Driver";
 		fsa.assertEquals(discounts.contains(safeDriverDiscountString), isSafeDriverDiscountState(applicantStateCode), safeDriverDiscountString + EXPECTED_TO_BE);
	}

	private void verifySignalDiscount(SqlApplicant applicant, String discountsFound, FarmersSoftAssert fsa) {
		SqlDiscount applicantDiscount = applicant.getDiscounts();
		fsa.assertEquals(discountsFound.contains(SIGNAL_DISCOUNT), applicantDiscount.isSignalSignup() && isSignalSignupDiscountState(applicant.getStateCode()), SIGNAL_DISCOUNT + EXPECTED_TO_BE);
	}

	private boolean isSignalSignupDiscountState(String stateCode) {
		return isFlexState(stateCode) || Arrays.asList(AL, CO, IN, KS, MN, MO, NV, VA).contains(stateCode);
	}

	private void verifyAutopayDiscount(boolean discountApplies, String discounts, FarmersSoftAssert fsa) {
		fsa.assertEquals(discounts.contains(AUTOPAY_DISCOUNT), discountApplies, AUTOPAY_DISCOUNT + EXPECTED_TO_BE);
	}

	private void verifyFiveYearAccidentFreeDiscount(boolean discountApplies, String discounts, FarmersSoftAssert fsa) {
		fsa.assertEquals(discounts.contains(ACCIDENT_FREE_DISCOUNT), discountApplies, ACCIDENT_FREE_DISCOUNT + EXPECTED_TO_BE);
	}

	private boolean isApplicantAccidentFree(SqlApplicant applicant) {
		boolean applicantHasIncidents = applicant.isHaveAccidentOrViolations();
		if (!applicantHasIncidents) {
			for (SqlAdditionalDriver additionalDriver : applicant.getAdditionalDrivers()) {
				applicantHasIncidents &= additionalDriver.isAnyIncident();
			}
		}
		return !applicantHasIncidents;
	}

	private boolean isAutopayDiscountState(String stateCode) {
		return isFlexState(stateCode);
	}

	private boolean isPaperlessDiscountState(String stateCode) {
		return !(isFlexState(stateCode) || isEasternExpansionState(stateCode));
	}

	private void verifyPaperlessDiscount(boolean discountApplies, String discounts, FarmersSoftAssert fsa) {
		fsa.assertEquals(discounts.contains(PAPERLESS_DISCOUNT), discountApplies, PAPERLESS_DISCOUNT + EXPECTED_TO_BE);
	}

	private void verifyWelcomeDiscount(boolean discountApplies, String discounts, FarmersSoftAssert fsa) {
		fsa.assertEquals(discounts.contains(WELCOME_DISCOUNT), discountApplies, WELCOME_DISCOUNT + EXPECTED_TO_BE);
	}

	private List<WebElement> getListWithPageElements(String stateCode) {
		List<WebElement> qpElements = new ArrayList<>();
		if (isViewAllPackagesState(stateCode) && isElementPresentByXPath(VIEW_ALL_PACKAGES_XPATH)) {
			qpElements.add(viewAllPackagesLink);
		}
		qpElements.add(buyNowButton);
		qpElements.add(liabilityCoverageHeaderButton);
		qpElements.add(vehicleCoveragesHeaderButton);
		return qpElements;
	}

	private Map<WebElement, String> getMapWithExpectedGTMTags(String stateCode) throws Exception {
		Map<WebElement,String> expectedElementGTMMap = new HashMap<>();
		if (isViewAllPackagesState(stateCode) && isElementPresentByXPath(VIEW_ALL_PACKAGES_XPATH)) {
			expectedElementGTMMap.put(viewAllPackagesLink, "FFQ_Auto_Quote_viewpackages_button");
		}
		WebElement actionButton = driver().findElement(By.xpath(ACTION_BUTTON_XPATH));
		String buttonLabel = getTextFromElement(actionButton);
		String buttonClass = getAttributeData(actionButton, CLASS);
		String buttonGTMtag = buttonLabel.contains("BUY NOW") ? "FFQ_Auto_Quote_ buynow_button" : "FFQ_Auto_Quote_continue_button";
		if (buttonClass.contains("update")) {
			buttonGTMtag = "FFQ_Auto_Quote_ recalculatecoverage_button";
		}
		expectedElementGTMMap.put(buyNowButton, buttonGTMtag);
		expectedElementGTMMap.put(liabilityCoverageHeaderButton, "FFQ_Auto_Quote_laibcovcollapse_button");
		expectedElementGTMMap.put(vehicleCoveragesHeaderButton, "FFQ_Auto_Quote_vehcovcollapse_button");
		return expectedElementGTMMap;
	}

	private boolean isViewAllPackagesState(String stateCode) {
		List<String> noViewAllPackagesStates = new ArrayList<>(Arrays.asList(CA, OH, OK));
		return !noViewAllPackagesStates.contains(stateCode);
	}

	private boolean isRentersBundleState(String stateCode) {
		List<String> noRentersBundleStates = new ArrayList<>(Arrays.asList(CA, IA, IN, KY, MD, MN, MS, NC));
		return !(isFlexState(stateCode) || noRentersBundleStates.contains(stateCode));
	}

	private boolean isBusinessProfessionalDiscountState(String stateCode) {
		List<String> noOccupationDiscountStates = new ArrayList<>(Arrays.asList(FL, GA, MI, MN, NY, TX));
		return !(isBristolWest || isEasternExpansionState(stateCode) || noOccupationDiscountStates.contains(stateCode));
	}

	private boolean isSharedFamiyDiscountState(String stateCode) {
		List<String> notSharedFamiyDiscountStates = new ArrayList<>(Arrays.asList(FL, NY));
		return !notSharedFamiyDiscountStates.contains(stateCode);
	}

	private boolean isSeniorDiscountState(String stateCode) {
		List<String> seniorDiscountStates = new ArrayList<>(Arrays.asList(CA));
		return seniorDiscountStates.contains(stateCode);
	}

	private boolean isDistantStudentState(String stateCode) {
		return !(stateCode.equalsIgnoreCase(CA) || isEasternExpansionState(stateCode));
	}

	private boolean isEFTDiscountState(String stateCode) {
		List<String> neverEFTDiscountStates = new ArrayList<>(Arrays.asList(CT, NV));
		return !(neverEFTDiscountStates.contains(stateCode)|| isBristolWestQuote() || isFlexState(stateCode) || isEasternExpansionState(stateCode));
	}

	private boolean isAlwaysGiveFiveYearAccidentFreeDiscountState(String stateCode) {
		List<String> statesAlwaysGiveFiveYearAccidentFreeDiscount = new ArrayList<>(Arrays.asList(NM));
		return statesAlwaysGiveFiveYearAccidentFreeDiscount.contains(stateCode);
	}

	private boolean isFiveYearAccidentFreeDiscountState(String stateCode) {
		List<String> statesWithoutFiveYearAccidentFreeDiscount = new ArrayList<>(Arrays.asList(AL, CA, CT, GA, MT, NC, NJ, NY));
		return !statesWithoutFiveYearAccidentFreeDiscount.contains(stateCode);
	}

	private boolean isGoodPayerState(String stateCode) {
		List<String> notGoodPayerStates = new ArrayList<>(Arrays.asList(CA, MD, NC, NY, WA));
		return !(isBristolWestQuote() || notGoodPayerStates.contains(stateCode));
	}

	private boolean isGlassDeductibleState(String stateCode) {
		List<String> notGlassDeductibleStates = new ArrayList<>(Arrays.asList(FL, KY, MA, MI, MN));
		return !(notGlassDeductibleStates.contains(stateCode) || isFlexState(stateCode));
	}

	private boolean isLossOfUseState(String stateCode) {
		List<String> notLossOfUseStates = new ArrayList<>(Arrays.asList(FL, VA));
		return !(notLossOfUseStates.contains(stateCode)|| isEasternExpansionState(stateCode) || isFlexState(stateCode));
	}

	private boolean isMedicalCoverageState(String stateCode) {
		List<String> medicalCoverageStates = new ArrayList<>(Arrays.asList(AL, AZ, CA, CT, GA, IA, ID, IL, IN, MO, MT, NM, NV, OH, OK, WI));
		return medicalCoverageStates.contains(stateCode);
	}

	private boolean isOldTowingHelpTextState(String stateCode) {
		List<String> oldTowingHelpTextStates = new ArrayList<>(Arrays.asList(OR, PA, TX, WA));
		return isEasternExpansionState(stateCode) || oldTowingHelpTextStates.contains(stateCode);
	}

	private boolean isPersonalInjuryProtectionState(String stateCode) {
		List<String> personalInjuryProtectionStates = new ArrayList<>(Arrays.asList(FL, KS, KY, MD, MN, ND, NY, OR, TX, UT, WA));
		return personalInjuryProtectionStates.contains(stateCode);
	}

	private boolean isPIPDeductibleAppliesToState(String stateCode) {
		return stateCode.equals(FL) || stateCode.equals(MA);
	}

	private boolean isPropertyDamageLiabilityState(String stateCode) {
		return !stateCode.equals(WA) && !isPropertyDamageState(stateCode);
	}

	private boolean isPropertyDamageState(String stateCode) {
		List<String> propertyDamageStates = new ArrayList<>(Arrays.asList(AL, CO, GA, IA, MI, MD, MT, ND, NJ, NV, NY, PA, SD, TN, TX, UT, VA, WY));
		return isEasternExpansionState(stateCode) || propertyDamageStates.contains(stateCode);
	}

	private boolean isRideshareState(String stateCode) {
		return !stateCode.equals(NM);
	}

	private boolean isRidesharingApplicant(SqlApplicant applicant) {
		for (SqlVehicle vehicle : applicant.getVehicles()) {
			if (vehicle.isRideSharing()) {
				return true;
			}
		}
		return false;
	}

	private boolean isSafetyGlassWaiverOfDeductibleState(String stateCode) {
		List<String> safetyGlassWaiverOfDeductibleStates = new ArrayList<>(Arrays.asList(AZ, MN));
		return safetyGlassWaiverOfDeductibleStates.contains(stateCode);
	}

	private boolean isTowingAndLaborState(String stateCode) {
		return stateCode.equals(MA) || stateCode.equals(VA);
	}

	private boolean isTowingAmpRoadState(String stateCode) {
		List<String> amperesandStates = new ArrayList<>(Arrays.asList(AL, FL, IA, MT, NJ));
		return amperesandStates.contains(stateCode);
	}

	private boolean isTowingAndRoadServiceState(String stateCode) {
		return (!isFlexState(stateCode) && !isTowingAmpRoadState(stateCode) && !isTowingAndLaborState(stateCode));
	}

	private boolean isUnderinsuredMotoristBodilyInjuryState(String stateCode) {
		List<String> underinsuredMotoristBodilyInjuryStates = new ArrayList<>(Arrays.asList(IN, MN, MO, ND, OH, PA, SD, WA, WY));
		return underinsuredMotoristBodilyInjuryStates.contains(stateCode);
	}

	private boolean isUnderinsuredMotoristBIState(String stateCode) {
		List<String> underinsuredMotoristBIStates = new ArrayList<>(Arrays.asList(AR, IA, ID, KY, NE));
		return underinsuredMotoristBIStates.contains(stateCode);
	}

	private boolean isUnderinsuredMotoristState(String stateCode) {
		List<String> underinsuredMotoristStates = new ArrayList<>(Arrays.asList(AZ, IL, WI));
		return underinsuredMotoristStates.contains(stateCode);
	}

	private boolean isUnderSpaceInsuredState(String stateCode) {
		List<String> underSpaceInsuredMotoristStates = new ArrayList<>(Arrays.asList(MT, UT));
		return underSpaceInsuredMotoristStates.contains(stateCode);
	}

	private boolean isUninsuredMotoristBIState(String stateCode) {
		List<String> uninsuredMotoristBIStates = new ArrayList<>(Arrays.asList(AR, IA, ID, IL, KY, LA, NE, OK, TN, WI));
		return uninsuredMotoristBIStates.contains(stateCode);
	}

	private boolean isUninsuredMotoristBodilyInjuryState(String stateCode) {
		List<String> uninsuredMotoristBodiltyInjuryStates = new ArrayList<>(Arrays.asList(CA, CO, FL, IN, MD, MN, MO, NC, ND, NV, OH, OR, PA, SD, VA, WY));
		return uninsuredMotoristBodiltyInjuryStates.contains(stateCode);
	}

	private boolean isUninsuredMotoristPDState(String stateCode) {
		List<String> uninsuredMotoristPDStates = new ArrayList<>(Arrays.asList(IL, IN, MS, OH, TN));
		return uninsuredMotoristPDStates.contains(stateCode);
	}

	private boolean isUninsuredMotoristPropertyDamageState(String stateCode) {
		List<String> uninsuredMotoristPropertyDamageStates = new ArrayList<>(Arrays.asList(AR, MD, NC, NJ, OR, UT, VA));
		return uninsuredMotoristPropertyDamageStates.contains(stateCode);
	}

	private boolean isUninsuredMotoristPropertyDamageWithoutCollisionState(String stateCode) {
		List<String> uninsuredMotoristPropertyDamageWithoutCollisionStates = new ArrayList<>(Arrays.asList(CA));
		return uninsuredMotoristPropertyDamageWithoutCollisionStates.contains(stateCode);
	}

	private boolean isUninsuredMotoristState(String stateCode) {
		List<String> uninsuredMotoristStates = new ArrayList<>(Arrays.asList(AL, AZ, MT, NY, UT));
		return uninsuredMotoristStates.contains(stateCode);
	}

	private boolean isUninsuredUnderinsuredMotoristBIState(String stateCode) {
		List<String> uninsuredUnderInsuredMotoristBIStates = new ArrayList<>(Arrays.asList(MS, NC));
		return uninsuredUnderInsuredMotoristBIStates.contains(stateCode);
	}

	private boolean isUninsuredUnderInsuredMotoristBodilyInjuryState(String stateCode) {
		List<String> uninsuredUnderInsuredMotoristBodilyInjuryStates = new ArrayList<>(Arrays.asList(MI, NJ));
		return uninsuredUnderInsuredMotoristBodilyInjuryStates.contains(stateCode);
	}

	private boolean isUninsuredUnderInsuredMotoristBodilyInjuryAlternateState(String stateCode) {
		List<String> uninsuredUnderInsuredMotoristBodilyInjuryStates = new ArrayList<>(Arrays.asList(GA, KS));
		return uninsuredUnderInsuredMotoristBodilyInjuryStates.contains(stateCode);
	}

	private boolean isUseFullStateNameForRentersStates(String stateCode) {
		List<String> fullStateNameStates = new ArrayList<>(Arrays.asList(AL, CT, GA, MT, ND, NJ, NY, SD, VA, WY));
		return fullStateNameStates.contains(stateCode);
	}

	//debug method, leave in place
	private int getAllCoveragesAndLiabilities(String stateCode) throws Exception{
		int numberOfCoveragesAndLiabilities = 0;
		try {
			List<WebElement> lookForElements = driver().findElements(By.xpath("//div[contains(@class, 'ffq-coverage-panel-coverage-item-label')]"));
			if (!lookForElements.isEmpty()) {
				List<String> discountList = new ArrayList<>();
				for (WebElement e : lookForElements) {
					String elementText = getTextFromElement(e);
					if (!elementText.equals(EMPTY_STRING)) {
						discountList.add("<"+elementText+">");
					} else {
						Log.warn("no text found for coverage/liability element in " + stateCode);
					}
				}
				discountList = discountList.stream().distinct().collect(Collectors.toList());
				writeInfoToFile("unique listed coverages/liabilities for " + stateCode + " : " + discountList + NEWLINE);
				if (discountList.size() != lookForElements.size()) {
					Log.warn("Should have " + lookForElements.size() +" listed coverages/liabilities for " + stateCode + ", found " + discountList.size() +  " : " + discountList);
				}
				numberOfCoveragesAndLiabilities = discountList.size();
			} else {
				Log.error ("++++++++ Found no coverages   +++++++");
				writeInfoToFile("**** Found no coverages for " + stateCode + "****\n");
			}
		} catch (StaleElementReferenceException see) {
			writeInfoToFile("++++ error finding elements for " + stateCode + "++++\n");
			return getAllCoveragesAndLiabilities(stateCode);
		}
		return numberOfCoveragesAndLiabilities;
	}

	private LinkedHashMap<WebElement, String> getMapWithBasicDropdownExpValues(SqlApplicant applicant) {
		LinkedHashMap<WebElement, String> dropdownsAndValues = new LinkedHashMap<>();
		String applicantStateCode = applicant.getStateCode();
		// Common items
		dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _50K_AND_100K);
		if (isPropertyDamageState(applicantStateCode)) {
			dropdownsAndValues.put(propertyDamageDropdown, _25K);
		} else {
			dropdownsAndValues.put(propertyDamageLiabilityDropdown, _20K);
		}
		if (applicantStateCode.equals(NM)) {
			dropdownsAndValues.put(uninsuredUnderinsuredMotoristBodilyInjuryLiabilityDropdown, _25K_AND_50K);
			dropdownsAndValues.put(uninsuredUnderinsuredMotoristPropertyDamageLiabilityDropdown, _10K);
		} else if (applicantStateCode.equals(TX)) {
			dropdownsAndValues.put(uninsuredUnderinsuredMotoristBodilyInjuryLiabilityDropdown, _30K_AND_60K);
			dropdownsAndValues.put(uninsuredUnderInsuredMotoristPDLiabilityDropdown, _25K_AND_250);
		} else if (isUninsuredMotoristState(applicantStateCode)) {
			dropdownsAndValues.put(uninsuredMotoristLiabilityDropdown, _25K_AND_50K);
			dropdownsAndValues.put(underinsuredMotoristLiabilityDropdown, _25K_AND_50K);
		} else {
			if (isUninsuredMotoristBIState(applicantStateCode)) {
				dropdownsAndValues.put(uninsuredMotoristBILiabilityDropdown, _25K_AND_50K);
			}
			if (isUnderinsuredMotoristBodilyInjuryState(applicantStateCode)) {
				dropdownsAndValues.put(uninsuredMotoristBodilyInjuryLiabilityDropdown, _50K_AND_100K);
				dropdownsAndValues.put(underinsuredMotoristBodilyInjuryLiabilityDropdown, _50K_AND_100K);
			}
		}
		if (isMedicalCoverageState(applicantStateCode)) {
			dropdownsAndValues.put(medicalCoverageLiabilityDropdown, NO_COVERAGE);
		} else if (applicantStateCode.equals(AR)) {
			dropdownsAndValues.put(medicalAndHospitalLiabilityDropdown, NO_COVERAGE);
		} else if (isMedicalLiabilityState(applicantStateCode)){
			dropdownsAndValues.put(medicalLiabilityDropdown, NO_COVERAGE);
		}
		if (hasFinancedVehicle(applicant)) {
			dropdownsAndValues.put(comprehensiveCoverageDropdown, _1000);
			dropdownsAndValues.put(collisionCoverageDropdown, _1000);
		} else {
			dropdownsAndValues.put(comprehensiveCoverageDropdown, NO_COVERAGE);
			dropdownsAndValues.put(collisionCoverageDropdown, NO_COVERAGE);
		}
		dropdownsAndValues.put(roadsideAssistanceCoverageDropdown, NO_COVERAGE);
		dropdownsAndValues.put(rentalCoverageDropdown, NO_COVERAGE);
		dropdownsAndValues.put(vehicleReplacementCoverageDropdown, NO_COVERAGE);
		if (isRidesharingApplicant(applicant)) {
			dropdownsAndValues.put(rideshareAndFoodDeliveryCoverageDropdown, COVERAGE);
		}
		if (applicantStateCode.equals(AZ)) {
			dropdownsAndValues.put(safetyGlassWaiverOfDeductibleCoverageDropdown, NO_COVERAGE);
		} else {
			dropdownsAndValues.put(glassCoverage100Dropdown, NO_COVERAGE);
		}
		// Differences per state
		switch (applicantStateCode) {
		case OR : case TN:
			dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _25K_AND_50K);
			break;
		case NM :
			dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _25K_AND_50K);
			dropdownsAndValues.put(propertyDamageLiabilityDropdown, _10K);
			break;
		case CO :
			dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _25K_AND_50K);
			dropdownsAndValues.put(propertyDamageDropdown, _15K);
			break;
		case ID : case OK :
			dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _25K_AND_50K);
			dropdownsAndValues.put(propertyDamageLiabilityDropdown, _25K);
			break;
		case TX :
			dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _30K_AND_60K);
			break;
		case MI :
			dropdownsAndValues.put(propertyDamageDropdown, _10K);
			break;
		case AR : case NE : case WI :
			dropdownsAndValues.put(propertyDamageLiabilityDropdown, _25K);
			break;
		case AL :
			if (applicant.getDiscounts().isUmbrellaInsurance()) {
				dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _250K_AND_500K);
				dropdownsAndValues.put(propertyDamageLiabilityDropdown, _100K);
				dropdownsAndValues.put(uninsuredMotoristBILiabilityDropdown, _250K_AND_500K);
			}
			break;
		case PA :
			if (applicant.getDiscounts().isUmbrellaInsurance()) {
				dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _250K_AND_500K);
				dropdownsAndValues.put(propertyDamageLiabilityDropdown, _100K);
				dropdownsAndValues.put(uninsuredMotoristBodilyInjuryLiabilityDropdown, _250K_AND_500K);
				dropdownsAndValues.put(underinsuredMotoristBodilyInjuryLiabilityDropdown, _250K_AND_500K);
			} else {
				dropdownsAndValues.put(propertyDamageLiabilityDropdown, _5K);
			}
			dropdownsAndValues.put(uninsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown, NON_STACKING);
			dropdownsAndValues.put(underinsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown, NON_STACKING);
			dropdownsAndValues.put(medicalLiabilityDropdown, _5K);
			dropdownsAndValues.put(tortLiabilityDropdown, LIMITED);
			break;
		case WY :
			dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _25K_AND_50K);
			dropdownsAndValues.put(propertyDamageDropdown, _20K);
			dropdownsAndValues.put(uninsuredMotoristBodilyInjuryLiabilityDropdown, _25K_AND_50K);
			dropdownsAndValues.put(underinsuredMotoristBodilyInjuryLiabilityDropdown, _25K_AND_50K);
			break;
		default :
			break;
		}
		return dropdownsAndValues;
	}

	private LinkedHashMap<WebElement, String> getMapWithEnhancedDropdownExpValues(SqlApplicant applicant) {
		LinkedHashMap<WebElement, String> dropdownsAndValues = new LinkedHashMap<>();
		String applicantStateCode = applicant.getStateCode();
		// Common items
		dropdownsAndValues.put(bodilyInjuryLiabilityDropdown,_50K_AND_100K);
		if (isPropertyDamageState(applicantStateCode)) {
			dropdownsAndValues.put(propertyDamageDropdown, _50K);
		} else {
			dropdownsAndValues.put(propertyDamageLiabilityDropdown, _50K);
		}
		if (Arrays.asList(NM, TX).contains(applicantStateCode)) {
			dropdownsAndValues.put(uninsuredUnderinsuredMotoristBodilyInjuryLiabilityDropdown, _50K_AND_100K);
			if (applicantStateCode.equals(NM)) {
				dropdownsAndValues.put(uninsuredUnderinsuredMotoristPropertyDamageLiabilityDropdown, _10K);
			} else {
				dropdownsAndValues.put(uninsuredUnderInsuredMotoristPDLiabilityDropdown, _50K_AND_250);
			}
		} else if (isUninsuredMotoristState(applicantStateCode)) {
			dropdownsAndValues.put(uninsuredMotoristLiabilityDropdown, _50K_AND_100K);
			dropdownsAndValues.put(underinsuredMotoristLiabilityDropdown, _50K_AND_100K);
		} else {
			if (isUninsuredMotoristBIState(applicantStateCode)) {
				dropdownsAndValues.put(uninsuredMotoristBILiabilityDropdown, _50K_AND_100K);
			}
			if (isUnderinsuredMotoristBodilyInjuryState(applicantStateCode)) {
				dropdownsAndValues.put(uninsuredMotoristBodilyInjuryLiabilityDropdown, _50K_AND_100K);
				dropdownsAndValues.put(underinsuredMotoristBodilyInjuryLiabilityDropdown, _50K_AND_100K);
			}
		}
		if (isMedicalCoverageState(applicantStateCode)) {
			dropdownsAndValues.put(medicalCoverageLiabilityDropdown, NO_COVERAGE);
		} else if (applicantStateCode.equals(AR)) {
			dropdownsAndValues.put(medicalAndHospitalLiabilityDropdown, NO_COVERAGE);
		} else if (isMedicalLiabilityState(applicantStateCode)){
			dropdownsAndValues.put(medicalLiabilityDropdown, NO_COVERAGE);
		}
		if (hasFinancedVehicle(applicant)) {
			dropdownsAndValues.put(comprehensiveCoverageDropdown, _1000);
			dropdownsAndValues.put(collisionCoverageDropdown, _1000);
		} else {
			dropdownsAndValues.put(comprehensiveCoverageDropdown, NO_COVERAGE);
			dropdownsAndValues.put(collisionCoverageDropdown, NO_COVERAGE);
		}
		dropdownsAndValues.put(roadsideAssistanceCoverageDropdown, NO_COVERAGE);
		dropdownsAndValues.put(rentalCoverageDropdown, NO_COVERAGE);
		dropdownsAndValues.put(vehicleReplacementCoverageDropdown, NO_COVERAGE);
		if (isRidesharingApplicant(applicant)) {
			dropdownsAndValues.put(rideshareAndFoodDeliveryCoverageDropdown, COVERAGE);
		}
		if (applicantStateCode.equals(AZ)) {
			dropdownsAndValues.put(safetyGlassWaiverOfDeductibleCoverageDropdown, NO_COVERAGE);
		} else {
			dropdownsAndValues.put(glassCoverage100Dropdown, NO_COVERAGE);
		}
		// Differences per state
		switch (applicantStateCode) {
		case AL :
			if (applicant.getDiscounts().isUmbrellaInsurance()) {
				dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _250K_AND_500K);
				dropdownsAndValues.put(propertyDamageLiabilityDropdown, _250K);
				dropdownsAndValues.put(uninsuredMotoristBILiabilityDropdown, _250K_AND_500K);
			}
			break;
		case MI :
			dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _250K_AND_500K);
			break;
		case PA :
			if (applicant.getDiscounts().isUmbrellaInsurance()) {
				dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _500K_AND_500K);
				dropdownsAndValues.put(propertyDamageLiabilityDropdown, _250K);
				dropdownsAndValues.put(uninsuredMotoristBodilyInjuryLiabilityDropdown, _500K_AND_500K);
				dropdownsAndValues.put(underinsuredMotoristBodilyInjuryLiabilityDropdown, _500K_AND_500K);
			} else {
				dropdownsAndValues.put(propertyDamageLiabilityDropdown, _25K);
			}
			dropdownsAndValues.put(uninsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown, NON_STACKING);
			dropdownsAndValues.put(underinsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown, NON_STACKING);
			dropdownsAndValues.put(medicalLiabilityDropdown, _5K);
			dropdownsAndValues.put(tortLiabilityDropdown, LIMITED);
			break;
		default :
			break;
		}
		return dropdownsAndValues;
	}

	private LinkedHashMap<WebElement, String> getMapWithFullDropdownExpValues(SqlApplicant applicant) {
		LinkedHashMap<WebElement, String> dropdownsAndValues = new LinkedHashMap<>();
		String applicantStateCode = applicant.getStateCode();
		// Common items
		dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _250K_AND_500K);
		if (isPropertyDamageState(applicantStateCode)) {
			dropdownsAndValues.put(propertyDamageDropdown, _100K);
		} else {
			dropdownsAndValues.put(propertyDamageLiabilityDropdown, _100K);
		}
		if (Arrays.asList(NM, TX).contains(applicantStateCode)) {
			dropdownsAndValues.put(uninsuredUnderinsuredMotoristBodilyInjuryLiabilityDropdown, _250K_AND_500K);
			if (applicantStateCode.equals(NM)) {
				dropdownsAndValues.put(uninsuredUnderinsuredMotoristPropertyDamageLiabilityDropdown, _100K);
			} else {
				dropdownsAndValues.put(uninsuredUnderInsuredMotoristPDLiabilityDropdown, _100K_AND_250);
			}
		} else if (isUninsuredMotoristState(applicantStateCode)) {
			dropdownsAndValues.put(uninsuredMotoristLiabilityDropdown, _250K_AND_500K);
			dropdownsAndValues.put(underinsuredMotoristLiabilityDropdown, _250K_AND_500K);
		} else {
			if (isUninsuredMotoristBIState(applicantStateCode)) {
				dropdownsAndValues.put(uninsuredMotoristBILiabilityDropdown, _250K_AND_500K);
			}
			if (isUnderinsuredMotoristBodilyInjuryState(applicantStateCode)) {
				dropdownsAndValues.put(uninsuredMotoristBodilyInjuryLiabilityDropdown, _250K_AND_500K);
				dropdownsAndValues.put(underinsuredMotoristBodilyInjuryLiabilityDropdown, _250K_AND_500K);
			}
		}
		if (isMedicalCoverageState(applicantStateCode)) {
			dropdownsAndValues.put(medicalCoverageLiabilityDropdown, _5K);
		} else if (applicantStateCode.equals(AR)) {
			dropdownsAndValues.put(medicalAndHospitalLiabilityDropdown, _5K);
		} else if (isMedicalLiabilityState(applicantStateCode)){
			if (applicantStateCode.equals(TX)) {
				dropdownsAndValues.put(medicalLiabilityDropdown, NO_COVERAGE);
			} else {
				dropdownsAndValues.put(medicalLiabilityDropdown, _5K);
			}
		}
		dropdownsAndValues.put(comprehensiveCoverageDropdown, _1000);
		dropdownsAndValues.put(collisionCoverageDropdown, _1000);
		dropdownsAndValues.put(roadsideAssistanceCoverageDropdown, STANDARD_ROADSIDE);
		dropdownsAndValues.put(rentalCoverageDropdown, _60_DAILY);
		dropdownsAndValues.put(vehicleReplacementCoverageDropdown, COVERAGE);
		if (isRidesharingApplicant(applicant)) {
			dropdownsAndValues.put(rideshareAndFoodDeliveryCoverageDropdown, COVERAGE);
		}
		if (applicantStateCode.equals(AZ)) {
			dropdownsAndValues.put(safetyGlassWaiverOfDeductibleCoverageDropdown, NO_COVERAGE);
		} else {
			dropdownsAndValues.put(glassCoverage100Dropdown, NO_COVERAGE);
		}
		// Differences per state
		switch (applicantStateCode) {
		case AL :
			if (applicant.getDiscounts().isUmbrellaInsurance()) {
				dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _500K_AND_500K);
				dropdownsAndValues.put(propertyDamageLiabilityDropdown, _500K);
				dropdownsAndValues.put(uninsuredMotoristBILiabilityDropdown, _500K_AND_500K);
			}
			break;
		case PA :
			if (applicant.getDiscounts().isUmbrellaInsurance()) {
				dropdownsAndValues.put(bodilyInjuryLiabilityDropdown, _500K_AND_1M);
				dropdownsAndValues.put(propertyDamageLiabilityDropdown, _500K);
				dropdownsAndValues.put(uninsuredMotoristBodilyInjuryLiabilityDropdown, _500K_AND_1M);
				dropdownsAndValues.put(underinsuredMotoristBodilyInjuryLiabilityDropdown, _500K_AND_1M);
			} else {
				dropdownsAndValues.put(propertyDamageLiabilityDropdown, _50K);
			}
			dropdownsAndValues.put(uninsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown, NON_STACKING);
			dropdownsAndValues.put(underinsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown, NON_STACKING);
			dropdownsAndValues.put(tortLiabilityDropdown, LIMITED);
			break;
		case WY :
			if (createDiscountsList().toString().contains("Umbrella")) {
				dropdownsAndValues.put(propertyDamageDropdown, _100K);
				dropdownsAndValues.put(uninsuredMotoristBodilyInjuryLiabilityDropdown, _250K_AND_500K);
				dropdownsAndValues.put(underinsuredMotoristBodilyInjuryLiabilityDropdown, _250K_AND_500K);
			} else {
				dropdownsAndValues.put(propertyDamageDropdown, _50K);
				dropdownsAndValues.put(uninsuredMotoristBodilyInjuryLiabilityDropdown, _50K_AND_100K);
				dropdownsAndValues.put(underinsuredMotoristBodilyInjuryLiabilityDropdown, _50K_AND_100K);
			}
			break;
		default :
			break;
		}
		return dropdownsAndValues;
	}

	private LinkedHashMap<WebElement, List<String>> getMapWithQuotePageDropdownExpValues(SqlApplicant applicant) {
		LinkedHashMap<WebElement, List<String>> dropdownsAndAvaliableValues = new LinkedHashMap<>();
		String applicantStateCode = applicant.getStateCode();
		//Check existence of dropdown appropriately
		if (!applicantStateCode.equals(MA)) {
			dropdownsAndAvaliableValues.put(bodilyInjuryLiabilityDropdown, bodilyInjuryListOfValues(applicantStateCode));
			dropdownsAndAvaliableValues.put(collisionCoverageDropdown, collisionListOfValues(applicantStateCode));
			dropdownsAndAvaliableValues.put(comprehensiveCoverageDropdown, comprehensiveListOfValues(applicantStateCode));
		}
		if (isGlassDeductibleState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(glassDeductibleBuybackCoverageDropdown, coverageNoCoverage);
		}
		if (isLossOfUseState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(lossOfUseCoverageDropdown, coverageNoCoverage);
		}
		if (isMedicalCoverageState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(medicalCoverageLiabilityDropdown, medicalCoverageListOfValues(applicantStateCode));
		}
		if (isPersonalInjuryProtectionState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(personalInjuryProtectionLiabilityDropdown, personalInjuryProtectionListOfValues(applicantStateCode));
		}
		// This coverage is not enabled
//		if (isPIPDeductibleAppliesToState(applicantStateCode)) {
//			dropdownsAndAvaliableValues.put(personalInjuryProtectionDeductibleAppliesToLiabilityDropdown, COVERAGE_NOCOVERAGE);
//		}
		if (isPropertyDamageLiabilityState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(propertyDamageLiabilityDropdown, propertyDamageLiabilityListOfValues(applicantStateCode));
		}
		if (isPropertyDamageState(applicantStateCode) && !applicantStateCode.equals(MA)) {
			dropdownsAndAvaliableValues.put(propertyDamageDropdown, propertyDamageListOfValues(applicantStateCode));
		}
		if (isSafetyGlassWaiverOfDeductibleState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(safetyGlassWaiverOfDeductibleCoverageDropdown, coverageNoCoverage);
		}
		if (isTowingAmpRoadState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(towingAmpRoadServiceCoverageDropdown, towingAndRoadServicesListOfValues(applicantStateCode));
		}
		if (isTowingAndRoadServiceState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(towingAndRoadServiceCoverageDropdown, towingAndRoadServicesListOfValues(applicantStateCode));
		}
		if (isUnderinsuredMotoristBIState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(underinsuredMotoristBILiabilityDropdown, underinsuredMotoristBIListOfValues(applicantStateCode));
		}
		if (isUnderinsuredMotoristBodilyInjuryState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(underinsuredMotoristBodilyInjuryLiabilityDropdown, underinsuredMotoristBIListOfValues(applicantStateCode));
		}
		if (isUnderinsuredMotoristState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(underinsuredMotoristLiabilityDropdown, underinsuredMotoristListOfValues(applicantStateCode));
		}
		if (isUnderSpaceInsuredState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(underSpaceInsuredMotoristLiabilityDropdown, underInsuredListOfValues(applicantStateCode));
		}
		if (isUninsuredMotoristBIState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(uninsuredMotoristBILiabilityDropdown, uninsuredMotoristBIListOfValues(applicantStateCode));
		}
		if (isUninsuredMotoristBodilyInjuryState(applicantStateCode)) {
			WebElement uimbi = applicantStateCode.equals(MD)? uninsuredMotoristBodilyInjuryLiabilityAlternateDropdown : uninsuredMotoristBodilyInjuryLiabilityDropdown;
			dropdownsAndAvaliableValues.put(uimbi, uninsuredBodilyInjuryListOfValues(applicantStateCode));
		}
		if (isUninsuredMotoristPDState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(uninsuredMotoristPDCoverageDropdown, uninsuredPropertyDamageListOfValues(applicantStateCode));
		}
		if (isUninsuredMotoristPropertyDamageState(applicantStateCode)) {
			WebElement uimpd = applicantStateCode.equals(MD)? uninsuredMotoristPropertyDamageCoverageAlternateDropdown : uninsuredMotoristPropertyDamageCoverageDropdown;
			dropdownsAndAvaliableValues.put(uimpd, uninsuredPropertyDamageListOfValues(applicantStateCode));
		}
		if (isUninsuredMotoristPropertyDamageWithoutCollisionState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(uninsuredMotoristPropertyDamageWithoutCollisionCoverageDropdown, uninsuredMotoristPropertyDamageWithoutCollisionListOfValues(applicantStateCode));
		}
		if (isUninsuredMotoristState(applicantStateCode)) {
			WebElement dropDown = applicantStateCode.equals(NY)? uninsuredMotoristNYLiabilityDropdown : uninsuredMotoristLiabilityDropdown;
			dropdownsAndAvaliableValues.put(dropDown, uninsuredMotoristListOfValues(applicantStateCode));
		}
		if (isUninsuredUnderinsuredMotoristBIState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(uninsuredUnderinsuredMotoristBILiabilityDropdown, uninsuredUnderinsuredMotoristBodilyInjuryListOfValues(applicantStateCode));
		}
		if (isUninsuredUnderInsuredMotoristBodilyInjuryState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(uninsuredUnderSpaceInsuredMotoristBodilyInjuryLiabilityDropdown, uninsuredUnderinsuredMotoristBodilyInjuryListOfValues(applicantStateCode));
		}
		if (isUninsuredUnderInsuredMotoristBodilyInjuryAlternateState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(uninsuredUnderSpaceInsuredMotoristBodilyInjuryGALiabilityDropdown, uninsuredUnderinsuredMotoristBodilyInjuryListOfValues(applicantStateCode));
		}
		if (isEasternExpansionState(applicantStateCode) && !applicantStateCode.equals(MA)) {
			dropdownsAndAvaliableValues.put(rentalReimbursementCoverageDropdown, rentalReimbursementListOfValues(applicantStateCode));
		}
		if (isMedicalLiabilityState(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(medicalLiabilityDropdown, medicalListOfValues(applicantStateCode));
		}
		if (Arrays.asList(NC, TX).contains(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(uninsuredUnderInsuredMotoristPDLiabilityDropdown, uninsuredUnderinsuredMotoristPDListOfValues(applicantStateCode));
		}
		if (Arrays.asList(NM, TX).contains(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(uninsuredUnderinsuredMotoristBodilyInjuryLiabilityDropdown, uninsuredUnderinsuredMotoristBodilyInjuryListOfValues(applicantStateCode));
		}
		if (Arrays.asList(CO, LA).contains(applicantStateCode)) {
			dropdownsAndAvaliableValues.put(uninsuredMotoristPDWithoutUppercaseCollisionCoverageDropdown, uninsuredMotoristPropertyDamageWithoutCollisionListOfValues(applicantStateCode));
		}

		if (isFlexState(applicantStateCode) && !applicantStateCode.equals(VA)) {
			dropdownsAndAvaliableValues.put(rentalCoverageDropdown, new ArrayList<>(Arrays.asList(NO_COVERAGE, _40_DAILY, _60_DAILY, _100_DAILY)));
			dropdownsAndAvaliableValues.put(roadsideAssistanceCoverageDropdown, new ArrayList<>(Arrays.asList(NO_COVERAGE, STANDARD_ROADSIDE, ENHANCED_RAODSIDE)));
			dropdownsAndAvaliableValues.put(vehicleReplacementCoverageDropdown, coverageNoCoverage);
			if (!applicantStateCode.equals(AZ)) {
				dropdownsAndAvaliableValues.put(glassCoverage100Dropdown, coverageNoCoverage);
			}
		}
		if (isRideshareState(applicantStateCode) && isRidesharingApplicant(applicant)) {
			if (isFlexState(applicantStateCode)) {
				dropdownsAndAvaliableValues.put(rideshareAndFoodDeliveryCoverageDropdown, coverageNoCoverage);
			} else {
				dropdownsAndAvaliableValues.put(rideshareCoverageDropdown, coverageNoCoverage);
			}
		}
		if (applicantStateCode.equals(AR)) {
			dropdownsAndAvaliableValues.put(medicalAndHospitalLiabilityDropdown, new ArrayList<>(Arrays.asList(NO_COVERAGE, _5K, _10K)));
			dropdownsAndAvaliableValues.put(incomeDisabilityCoverageDropdown, new ArrayList<>(Arrays.asList(NO_COVERAGE, _140, _200, _300)));
		}
		if (applicantStateCode.equals(CA)) {
			// permissiveUserLimitLiabilityDropdown disabled and should not be included
			dropdownsAndAvaliableValues.put(uninsuredMotoristPropertyDamageWithCollisionCoverageDropdown, coverageNoCoverage);
		}
		if (applicantStateCode.equals(CT)) {
			dropdownsAndAvaliableValues.put(uninsuredUnderSpaceInsuredMotoristBILiabilityDropdown, uninsuredUnderinsuredMotoristBIListOfValues(applicantStateCode));
			dropdownsAndAvaliableValues.put(uninsuredUnderInsuredMotoristBIConversionLiabilityDropdown, new ArrayList<>(Arrays
					.asList(NO_COVERAGE, _25K_AND_50K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _200K_AND_600K, _250K_AND_500K, _500K_AND_500K)));
		}
		if (applicantStateCode.equals(FL)) {
			dropdownsAndAvaliableValues.put(medicalExpenseCoverageDropdown, medicalExpenseCoverageListOfValues(applicantStateCode));
			dropdownsAndAvaliableValues.put(personalInjuryProtectionExclusionLiabilityDropdown, new ArrayList<>(Arrays.asList(NONE, "Named Insured Only", "Named Insured and Resident Dependent Relatives")));
			// personalInjuryProtectionDeductibleAppliesToLiabilityDropdown disabled and should not be included
			dropdownsAndAvaliableValues.put(uninsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown, new ArrayList<>(Arrays.asList("Non-Stacked", "Stacked")));
		}
		if (applicantStateCode.equals(GA)) {
			dropdownsAndAvaliableValues.put(uninsuredUnderSpaceInsuredMotoristPropertyDamageLiabilityDropdown, new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_250, _25K_AND_500, _25K_AND_1000, _50K_AND_250, _50K_AND_500, _50K_AND_1000,
					_100K_AND_250, _100K_AND_500, _100K_AND_1000, _250K_AND_250, _250K_AND_500, _250K_AND_1000, _500K_AND_250, _500K_AND_500, _500K_AND_1000)));
		}
		if (applicantStateCode.equals(KY)) {
			dropdownsAndAvaliableValues.put(optionalPIPLiabilityDropdown, new ArrayList<>(Arrays.asList(NO_COVERAGE, _10K, _20K, _30K, _40K)));
		}
		if (applicantStateCode.equals(LA)) {
			dropdownsAndAvaliableValues.put(uninsuredMotoristBIOptionsLiabilityDropdown, new ArrayList<>(Arrays.asList("Full", "Economic Only")));
		}
		if (applicantStateCode.equals(MA)) {
			// compulsoryBodilyInjuryLiabilityDropdown disabled and should not be included
			dropdownsAndAvaliableValues.put(optionalBodilyInjuryLiabilityDropdown, new ArrayList<>(Arrays.asList(_25K_AND_50K, _35K_AND_80K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K)));
			dropdownsAndAvaliableValues.put(propertyDamageMADropdown, propertyDamageListOfValues(applicantStateCode));
			dropdownsAndAvaliableValues.put(uninsuredMotoristBodilyInjuryMALiabilityDropdown, uninsuredMotoristBIListOfValues(applicantStateCode));
			dropdownsAndAvaliableValues.put(underinsuredMotoristBodilyInjuryMALiabilityDropdown, underinsuredMotoristBIListOfValues(applicantStateCode));
			dropdownsAndAvaliableValues.put(medicalPaymentsLiabilityDropdown, medicalListOfValues(applicantStateCode));
			dropdownsAndAvaliableValues.put(personalInjuryProtectionMALiabilityDropdown, new ArrayList<>(Arrays.asList("Included")));
			dropdownsAndAvaliableValues.put(personalInjuryProtectionDeductibleLiabilityDropdown, personalInjuryProtectionListOfValues(applicantStateCode));
			dropdownsAndAvaliableValues.put(comprehensiveMACoverageDropdown, comprehensiveListOfValues(applicantStateCode));
			dropdownsAndAvaliableValues.put(collisionMACoverageDropdown, collisionListOfValues(applicantStateCode));
			dropdownsAndAvaliableValues.put(limitedCollisionCoverageDropdown, collisionListOfValues(applicantStateCode));
			dropdownsAndAvaliableValues.put(towingAndLaborMACoverageDropdown, coverageNoCoverage);
			dropdownsAndAvaliableValues.put(substituteTransportationCoverageDropdown, new ArrayList<>(Arrays.asList(NO_COVERAGE, _30_DAILY, _50_DAILY, _100_DAILY)));
		}
		if (applicantStateCode.equals(MD)) {
			dropdownsAndAvaliableValues.put(accidentalDeathLiabilityDropdown, new ArrayList<>(Arrays.asList(NO_COVERAGE, _5K, _10K, _15K, _25K)));
			dropdownsAndAvaliableValues.put(guestPIPLiabilityDropdown, new ArrayList<>(Arrays.asList(NO_COVERAGE, _2500, _5K, _10K)));
		}
		// these are disabled in MI and should not be included
		//	pipMedicalSecondCoverageDropdown, pipWorkLossSecondCoverageDropdown, pipWorkLossWaivedCoverageDropdown
		if (applicantStateCode.equals(MN)) {
			dropdownsAndAvaliableValues.put(waiverOfWorkLossCoverageDropdown, new ArrayList<>(Arrays.asList(NO, YES)));
		}
		if (applicantStateCode.equals(NJ)) {
			// these are disabled and should not be included
			//  essentialServicesLiabilityDropdown, extraPIPPackageCoverageDropdown, funeralExpensesCoverageDropdown,
			//  healthInsurerPrimaryCoverageDropdown, incomeContinuationLiabilityDropdown
			dropdownsAndAvaliableValues.put(deathBenefitCoverageDropdown, new ArrayList<>(Arrays.asList(NO_COVERAGE, _10K)));
			dropdownsAndAvaliableValues.put(extendedMedicalPaymentsLiabilityDropdown, new ArrayList<>(Arrays.asList(_1000, _10K)));
			dropdownsAndAvaliableValues.put(extraPIPPackageLiabilityDropdown, coverageNoCoverage);
			dropdownsAndAvaliableValues.put(lawsuitOptionLiabilityDropdown, new ArrayList<>(Arrays.asList("Limitation", "No Limitation")));
			dropdownsAndAvaliableValues.put(principalPIPLiabilityDropdown, new ArrayList<>(Arrays
					.asList(NO_COVERAGE, _15K_AND_250, _15K_AND_500, _15K_AND_1000, _15K_AND_2000, _15K_AND_2500, _50K_AND_250, _50K_AND_500, _50K_AND_1000, _50K_AND_2000, _50K_AND_2500,
							_75K_AND_250, _75K_AND_500, _75K_AND_1000, _75K_AND_2000, _75K_AND_2500, _150K_AND_250, _150K_AND_500, _150K_AND_1000, _150K_AND_2000, _150K_AND_2500,
							_250K_AND_250, _250K_AND_500, _250K_AND_1000, _250K_AND_2000, _250K_AND_2500)));
			dropdownsAndAvaliableValues.put(principalPIPMedicalExpensesLiabilityDropdown, new ArrayList<>(Arrays
					.asList(NO_COVERAGE, _15K_AND_250, _15K_AND_500, _15K_AND_1000, _15K_AND_2000, _15K_AND_2500, _50K_AND_250, _50K_AND_500, _50K_AND_1000, _50K_AND_2000, _50K_AND_2500,
							_75K_AND_250, _75K_AND_500, _75K_AND_1000, _75K_AND_2000, _75K_AND_2500, _150K_AND_250, _150K_AND_500, _150K_AND_1000, _150K_AND_2000, _150K_AND_2500,
							_250K_AND_250, _250K_AND_500, _250K_AND_1000, _250K_AND_2000, _250K_AND_2500)));
		}
		if (applicantStateCode.equals(NM)) {
			dropdownsAndAvaliableValues.put(uninsuredUnderinsuredMotoristPropertyDamageLiabilityDropdown, new ArrayList<>(Arrays.asList(NO_COVERAGE, _10K, _15K, _20K, _25K, _50K, _100K, _250K, _500K)));
		}
		if (applicantStateCode.equals(PA)) {
//			dropdownsAndAvaliableValues.put(accidentalDeathBenefitsLiabilityDropdown, new ArrayList<>(Arrays.asList(NO_COVERAGE, _5K, _10K, _25K)));
//			dropdownsAndAvaliableValues.put(collisionPlusLossOfUseCoverageDropdown, COVERAGE_NOCOVERAGE);
//			dropdownsAndAvaliableValues.put(funeralExpenseBenefitsLiabilityDropdown, new ArrayList<>(Arrays.asList(NO_COVERAGE, _1500, _2500)));
//			dropdownsAndAvaliableValues.put(incomeLossCoverageDropdown, new ArrayList<>(Arrays.asList(NO_COVERAGE, _1000_AND_5000, _1000_AND_15K, _1500_AND_25K, _2500_AND_50K)));
			dropdownsAndAvaliableValues.put(tortLiabilityDropdown, new ArrayList<>(Arrays.asList(FULL, LIMITED)));
			dropdownsAndAvaliableValues.put(uninsuredMotoristBodilyInjuryStackingLiabilityDropdown, new ArrayList<>(Arrays.asList(NON_STACKING, STACKING)));
			dropdownsAndAvaliableValues.put(underinsuredMotoristBodilyInjuryStackingOptionLiabilityDropdown, new ArrayList<>(Arrays.asList(NON_STACKING, STACKING)));
		}
		if (applicantStateCode.equals(VA)) {
			dropdownsAndAvaliableValues.put(towingAndLaborCostsCoverageDropdown, coverageNoCoverage);
		}
		if (applicantStateCode.equals(WA)) {
			dropdownsAndAvaliableValues.put(underSpaceInsuredMotoristPropertyDamageLiabilityDropdown, coverageNoCoverage);
		}
		return dropdownsAndAvaliableValues;
	}

	// List of values for Liability and Coverages
	private List<String> bodilyInjuryListOfValues(String stateCode) {
		switch(stateCode) {
		case FL :
			return new ArrayList<>(Arrays.asList(_10K_AND_20K, _15K_AND_30K, _20K_AND_40K, _25K_AND_50K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _300K_AND_300K, _500K_AND_500K));
		case CA :
			return new ArrayList<>(Arrays.asList(_15K_AND_30K, _25K_AND_50K, _30K_AND_60K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K));
		case CO : case NY : case NJ :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K));
		case AL : case CT : case GA : case ID : case IL : case IN : case KY : case LA : case MO : case MS : case MT : case ND : case NM : case NV:
		case OH : case OK : case OR : case SD : case TN : case WY :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case PA :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K, _500K_AND_1M));
		case UT :
			return new ArrayList<>(Arrays.asList(_25K_AND_65K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case MD : case NC : case VA : case TX :
			return new ArrayList<>(Arrays.asList(_30K_AND_60K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case AR : case AZ : case IA : case KS : case MI : case MN : case NE : case WI :
			return new ArrayList<>(Arrays.asList(_50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		default :
			return new ArrayList<>(Arrays.asList("bodilyInjuryListOfValues" + UNDEFINED + stateCode));
		}
	}

	private List<String> propertyDamageListOfValues(String stateCode) {
		if (isEasternExpansionState(stateCode)) {
			if (stateCode.equals(MA)) {
				return new ArrayList<>(Arrays.asList(_5K, _10K, _25K, _50K, _100K, _250K, _500K));
			} else {
				return new ArrayList<>(Arrays.asList(_25K, _50K, _100K, _250K, _500K));
			}
		} else {
			switch(stateCode) {
			case PA :
				return new ArrayList<>(Arrays.asList(_5K, _10K, _25K, _50K, _100K, _250K, _500K));
			case MI :
				return new ArrayList<>(Arrays.asList(_10K, _15K, _20K, _25K, _40K, _50K, _100K, _250K, _500K));
			case NY :
				return new ArrayList<>(Arrays.asList(_10K, _15K, _25K, _50K, _100K, _250K));
			case UT :
				return new ArrayList<>(Arrays.asList(_15K, _20K, _25K, _40K, _50K, _100K, _250K, _500K));
			case CO: case MD :
				return new ArrayList<>(Arrays.asList(_15K, _20K, _25K, _50K, _100K, _250K, _500K));
			case VA :
				return new ArrayList<>(Arrays.asList(_20K, _25K, _40K, _50K, _100K, _250K, _500K));
			case MT : case NV : case WY :
				return new ArrayList<>(Arrays.asList(_20K, _25K, _50K, _100K, _250K, _500K));
			case AL : case AR : case GA : case IA : case NE : case NJ : case TN : case TX :
				return new ArrayList<>(Arrays.asList(_25K, _50K, _100K, _250K, _500K));
			default :
				return new ArrayList<>(Arrays.asList("propertyDamageListOfValues" + UNDEFINED + stateCode));
			}
		}
	}

	private List<String> propertyDamageLiabilityListOfValues(String stateCode) {
		switch(stateCode) {
		case CA : case NJ :
			return new ArrayList<>(Arrays.asList(_5K, _10K, _25K, _50K, _100K, _250K, _500K));
		case NM :
			return new ArrayList<>(Arrays.asList(_10K, _15K, _20K, _25K, _50K, _100K, _250K, _500K));
		case ID : case TN :
			return new ArrayList<>(Arrays.asList(_15K, _20K, _25K, _50K, _100K, _250K, _500K));
		case OR :
			return new ArrayList<>(Arrays.asList(_20K, _25K, _50K, _100K, _250K, _500K));
		case AR : case CT :case IN : case KS : case KY : case MO : case NE : case ND : case OH : case OK :
		case SD : case TX : case WI :
			return new ArrayList<>(Arrays.asList(_25K, _50K, _100K, _250K, _500K));
		case MN :
			return new ArrayList<>(Arrays.asList(_50K, _100K, _250K, _500K));
		default :
			return new ArrayList<>(Arrays.asList("propertyDamageLiabilityListOfValues" + UNDEFINED + stateCode));
		}
	}

	private List<String> medicalCoverageListOfValues(String stateCode) {
		switch(stateCode) {
		case CA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _1000, _2000, _5K, _5K_AND_500, _10K, _10K_AND_500, _25K_AND_500, _25K));
		case CT : case GA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _500, _1000, _2000, _5K, _10K, _25K, _50K));
		case IN :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _5K, _10K, _25K, _50K, _250K, _500K));
		case MT :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _2000, _5K, _10K, _25K));
		case NM : case NV : case WI :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _1000, _5K, _10K, _25K, _50K));
		case PA :
			return new ArrayList<>(Arrays.asList(_5K, _10K, _25K, _50K, _100K));
		case SD : case VA : case WY :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _2000, _5K, _10K, _25K, _50K));
		case TX :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _2500, _5K, _10K, _25K));
		default :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _5K, _10K, _25K, _50K));
		}
	}

	private List<String> medicalExpenseCoverageListOfValues(String stateCode) {
		if (stateCode.equals(FL)) {
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _500, _750, _1000, _2000, _5K));
		} else {
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _2000, _5K, _10K, _25K, _50K));
		}
	}

	private List<String> medicalListOfValues(String stateCode) {
		switch(stateCode ) {
		case NC:
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _1000, _2000, _5K, _10K));
		case LA: case KY: case MA:
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _1000, _2000, _5K, _10K, _25K, _50K));
		case WY:
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _2000, _5K, _10K, _25K, _50K));
		case TX:
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _2500, _5K, _10K, _25K));
		case NE: case TN:
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _5K, _10K, _25K, _50K));
		case PA:
			return new ArrayList<>(Arrays.asList(_5K, _10K, _25K, _50K, _100K));
		default :
			return new ArrayList<>(Arrays.asList("medicalListOfValues" + UNDEFINED + stateCode));
		}
	}

	// List of values for Vehicle coverages
	private List<String> uninsuredMotoristListOfValues(String stateCode) {
		switch(stateCode) {
		case CA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _15K_AND_30K, _25K_AND_50K, _30K_AND_60K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K));
		case IA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _20K_AND_40K, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case NY :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_50K));
		case CO :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K));
		case AL : case MT :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case UT :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_65K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case MN :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _30K_AND_60K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case VA :
			return new ArrayList<>(Arrays.asList(_30K_AND_60K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case MD :
			return new ArrayList<>(Arrays.asList(_50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		default :
			return new ArrayList<>(Arrays.asList("uninsuredMotoristListOfValues" + UNDEFINED + stateCode));
		}
	}

	private List<String> comprehensiveListOfValues(String stateCode) {
		switch(stateCode) {
		case AL : case CT:
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _100, _250, _500, _750, _1000, _1500, _2500));
		case MD :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _50, _100, _150, _200, _250, _500, _750, _1000, _1500, _2500));
		case NJ :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _100, _150, _250, _500, _750, _1000, _1500, _2000));
		case NY :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _100, _200, _250, _500, _750, _1000, _2500));
		case CA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _100, _250, _500, _750, _1000, _1500, _2500, _5K));
		case GA : case WA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _100, _250, _500, _750, _1000, _2500));
		case NC :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _100, _250, _500, _1000));
		case MA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _300_WITH_0, _500_WITH_0, _750_WITH_0, _1000_WITH_0, _1500_WITH_0, _2500_WITH_0,
					_300_WITH_100, _500_WITH_100, _750_WITH_100, _1000_WITH_100, _1500_WITH_100, _2500_WITH_100));
		default :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _100, _250, _500, _750, _1000, _1500, _2500));
		}
	}

	private List<String> collisionListOfValues(String stateCode) {
		switch(stateCode) {
		case AL : case CT:
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _100, _250, _500, _750, _1000, _1500, _2500));
		case MD :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _50, _100, _150, _200, _250, _500, _750, _1000, _1500, _2500));
		case NJ :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _100, _150, _250, _500, _750, _1000, _1500, _2000));
		case NY :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _100, _200, _250, _500, _750, _1000, _2500));
		case GA : case WA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _100, _250, _500, _750, _1000, _2500));
		case NC :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _100, _250, _500, _1000));
		case CA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _250, _500, _750, _1000, _1500, _2500, _5K));
		case MA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _300, _500, _750, _1000, _1500, _2500));
		default :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _100, _250, _500, _750, _1000, _1500, _2500));
		}
	}

	private List<String> rentalReimbursementListOfValues(String stateCode) {
		if (stateCode.equals(NC)) {
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _15_DAY_450_TOTAL, _30_DAY_900_TOTAL, _50_DAY_1500_TOTAL, _100_DAY_3000_TOTAL));
		} else {
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _30_DAILY, _50_DAILY, _100_DAILY));
		}
	}

	private List<String> personalInjuryProtectionListOfValues(String stateCode) {
		switch(stateCode) {
		case FL :
			return new ArrayList<>(Arrays.asList(BASIC));
		case KS :
			return new ArrayList<>(Arrays.asList(_4500_AND_900, _10K_AND_900, _25K_AND_900));
		case KY :
			return new ArrayList<>(Arrays.asList(_10K_AND_0, _10K_AND_250, _10K_AND_500, _10K_AND_1000));
		case MA :
			return new ArrayList<>(Arrays.asList(_0, _100, _250, _500, _1000, _2000, _4K, _8K));
		case MD : case TX :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _2500, _5K, _10K));
		case MN :
			return new ArrayList<>(Arrays.asList(_20K_0_AND_0, _20K_0_AND_200, _20K_100_AND_0, _20K_100_AND_200, _30K_0_AND_0, _30K_0_AND_200, _30K_100_AND_0, _30K_100_AND_200,
					_40K_0_AND_0, _40K_0_AND_200, _40K_100_AND_0, _40K_100_AND_200, _100K_0_AND_0, _100K_0_AND_200, _100K_100_AND_0, _100K_100_AND_200));
		case ND :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _30K, _70K, _110K));
		case NY :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _50K, _50K_AND_200));
		case OR :
			return new ArrayList<>(Arrays.asList(_15K, _25K, _100K));
		case UT :
			return new ArrayList<>(Arrays.asList(_3K, _5K, _10K));
		case WA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _10K, _35K));
		default :
			return new ArrayList<>(Arrays.asList("personalInjuryProtectionListOfValues" + UNDEFINED + stateCode));
		}
	}

	private List<String> towingAndRoadServicesListOfValues(String stateCode) {
		if (stateCode.equals(TX)) {
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _40, _80, _120));
		} else  {
			return coverageNoCoverage;
		}
	}

	private List<String> underInsuredListOfValues(String stateCode) {
		switch(stateCode) {
		case UT :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _10K_AND_20K, _25K_AND_65K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case IA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _20K_AND_40K, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case MT :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case MN :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _30K_AND_60K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case WI :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		default :
			return new ArrayList<>(Arrays.asList("underInsuredListOfValues" + UNDEFINED + stateCode));
		}
	}

	private List<String> underinsuredMotoristBIListOfValues(String stateCode) {
		switch(stateCode) {
		case PA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _15K_AND_30K, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K, _500K_AND_1M));
		case IA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _20K_AND_40K, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case MA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_50K, _35K_AND_80K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case AR : case ID : case KY : case MO : case ND : case OH : case SD : case WA : case WY :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case IN :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _50K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case WI :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case NE :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case MN :
			return new ArrayList<>(Arrays.asList(_30K_AND_60K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		default :
			return new ArrayList<>(Arrays.asList("underinsuredMotoristBIListOfValues" + UNDEFINED + stateCode));
		}
	}

	private List<String> underinsuredMotoristListOfValues(String stateCode) {
		switch(stateCode) {
		case AZ :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case IL :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case IN :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _50K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case WI :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		default :
			return new ArrayList<>(Arrays.asList("underinsuredMotoristListOfValues" + UNDEFINED + stateCode));
		}
	}

	private List<String> uninsuredBodilyInjuryListOfValues(String stateCode) {
		switch(stateCode) {
		case NC :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE));
		case CA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _15K_AND_30K, _25K_AND_50K, _30K_AND_60K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K));
		case PA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _15K_AND_30K, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K, _500K_AND_1M));
		case CO :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K));
		case IN : case NV : case OH : case WY :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case FL :
			return new ArrayList<>(Arrays.asList(_10K_AND_20K, _15K_AND_30K, _20K_AND_40K, _25K_AND_50K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _250K_AND_500K, _300K_AND_300K, _500K_AND_500K));
		case MO : case ND : case OR : case SD :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case MD : case MN : case VA :
			return new ArrayList<>(Arrays.asList(_30K_AND_60K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		default :
			return new ArrayList<>(Arrays.asList("uninsuredBodilyInjuryListOfValues" + UNDEFINED + stateCode));
		}
	}

	private List<String> uninsuredMotoristBIListOfValues(String stateCode) {
		switch (stateCode) {
		case LA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _15K_AND_30K, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case AR : case IA : case ID : case KY : case OK : case TN : case WI :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case NE : case IL :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case MA :
			return new ArrayList<>(Arrays.asList(_20K_AND_40K, _25K_AND_50K, _35K_AND_80K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		default :
			return new ArrayList<>(Arrays.asList("uninsuredMotoristBIListOfValues" + UNDEFINED + stateCode));
		}
	}

	private List<String> uninsuredPropertyDamageListOfValues(String stateCode) {
		switch(stateCode) {
		case NC :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE));
		case IN :
			return coverageNoCoverage;
		case IL :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _50, _100, _200, _250));
		case OR :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _20K));
		case AR : case MS : case TN :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K, _50K, _100K, _250K, _500K));
		case UT :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _3500_AND_250));
		case OH :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _10K_AND_250));
		case MD :
			return new ArrayList<>(Arrays.asList(_15K_AND_250, _20K_AND_250, _25K_AND_250, _50K_AND_250, _100K_AND_250, _250K_AND_250, _500K_AND_250));
		case VA :
			return new ArrayList<>(Arrays.asList(_20K_AND_250, _25K_AND_250, _40K_AND_250, _50K_AND_250, _100K_AND_250, _250K_AND_250, _500K_AND_250));
		case NJ :
			return new ArrayList<>(Arrays.asList(_25K_AND_500, _50K_AND_500, _100K_AND_500, _250K_AND_500, _500K_AND_500));
		default :
			return new ArrayList<>(Arrays.asList("uninsuredPropertyDamageListOfValues" + UNDEFINED + stateCode));
		}
	}

	private List<String> uninsuredMotoristPropertyDamageWithoutCollisionListOfValues(String stateCode) {
		switch(stateCode) {
		case CA:
			return coverageNoCoverage;
		case CO :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _50, _100, _200, _500, _1000));
		case IL :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _50, _100, _200, _250));
		case LA :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_250));
		default :
			return new ArrayList<>(Arrays.asList("uninsuredMotoristPropertyDamageWithoutCollisionListOfValues" + UNDEFINED + stateCode));
		}
	}

	private List<String> uninsuredUnderinsuredMotoristBIListOfValues(String stateCode) {
		switch(stateCode) {
		case CT :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_50K, _50K_AND_100K, _100K_AND_200K, _100K_AND_300K, _200K_AND_600K, _250K_AND_500K, _500K_AND_500K));
		case TX :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _30K_AND_60K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		default :
			return new ArrayList<>(Arrays.asList("uninsuredUnderinsuredMotoristBIListOfValues" + UNDEFINED + stateCode));
		}
	}

	private List<String> uninsuredUnderinsuredMotoristBodilyInjuryListOfValues(String stateCode) {
		switch(stateCode) {
		case GA : case MS : case NM :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case TX :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _30K_AND_60K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case NJ :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K));
		case KS :
			return new ArrayList<>(Arrays.asList(_25K_AND_50K, _50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		case MI : case NC :
			return new ArrayList<>(Arrays.asList(_50K_AND_100K, _100K_AND_300K, _250K_AND_500K, _500K_AND_500K));
		default :
			return new ArrayList<>(Arrays.asList("uninsuredUnderinsuredMotoristBodilyInjuryListOfValues" + UNDEFINED + stateCode));
		}
	}

	private List<String> uninsuredUnderinsuredMotoristPDListOfValues(String stateCode) {
		switch(stateCode) {
		case NC :
			return new ArrayList<>(Arrays.asList("$25,000 (subject to $100 deductible)", "$50,000 (subject to $100 deductible)", "$100,000 (subject to $100 deductible)", "$250,000 (subject to $100 deductible)", "$500,000 (subject to $100 deductible)"));
		case TX :
			return new ArrayList<>(Arrays.asList(NO_COVERAGE, _25K_AND_250, _50K_AND_250, _100K_AND_250, _250K_AND_250, _500K_AND_250));
		default :
			return new ArrayList<>(Arrays.asList("uninsuredUnderinsuredMotoristPDListOfValues" + UNDEFINED + stateCode));
		}
	}
}
