package com.farmers.ffq.common.pages;

import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.framework.Property;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import static com.farmers.ffq.utils.GlobalVariables.SPACE;

public class MediaAlphaPageHome extends AceHRCBasePage {
    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public MediaAlphaPageHome() throws Exception {
    }

    public boolean isOnMediaAlphaPageHome() {
        return isElementVisible(streetAddress, Property.PAGELOADTIMEOUT);
    }

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-address']")
    private WebElement streetAddress;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'go to step 2')]")
    private WebElement goToStep2Button;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'go to step 3')]")
    private WebElement goToStep3Button;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='currently_insured']")
    private WebElement currentlyInsuredCheckbox;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'Go to Last Step')]")
    private WebElement goToLastStepButton;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(.,'Get Your Quotes')]")
    private WebElement yourQuotesButton;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-name']")
    private WebElement yourName;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-gender-m']")
    private WebElement radioGenderMale;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-gender-m']")
    private WebElement radioGenderFemale;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-married-y']")
    private WebElement radioMarriedYes;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-married-n']")
    private WebElement radioMarriedNo;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-birthday']")
    private WebElement birthday;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-email']")
    private WebElement email;

    @FindBy(xpath = "//table[@id='home-panel-content']//input[@id='f-phone']")
    private WebElement phone;

    @FindBy(xpath = "//table[@id='home-panel-content']//button[contains(@class,'mav-partner__button')]")
    private WebElement viewMyQuoteButton;

    @FindBy(xpath = "//button[@id='redirect-btn'][1]")
    private WebElement redirectButton;

    private void enterAddress(String address) {
        sendKeysToElement(streetAddress, address);
    }

    private void clickGoToStep2Button() {
        waitAndClickElement(goToStep2Button);
    }

    private void clickGoToStep3Button() {
        waitAndClickElement(goToStep3Button);
    }

    private void clickGoToLastStepButton() {
        waitAndClickElement(goToLastStepButton);
    }

    private void clickGetYourQuotesButton() {
        waitAndClickElement(yourQuotesButton);
    }

    private void clickRedirectButton() {
        isElementDisplayed(redirectButton, 10);
        waitAndClickElement(redirectButton);
    }


    private void selectCurrentlyInsured(boolean check) {
        if ((currentlyInsuredCheckbox.isSelected() && !check) ||
                (!currentlyInsuredCheckbox.isSelected() && check)) {
            scrollAndClickOnElement(currentlyInsuredCheckbox);
        }
    }

    private void enterFullName(String fullName) {
        waitAndClickElement(yourName);
        sendKeysToElement(yourName, fullName);
    }

    private void enterGender(String gender) {
        if (gender.equalsIgnoreCase("male")) {
            waitAndClickElement(radioGenderMale);
        } else {
            waitAndClickElement(radioGenderFemale);
        }
    }

    private void enterMaritalStatus(String status) {
        if (status.equalsIgnoreCase("married")) {
            waitAndClickElement(radioMarriedYes);
        } else {
            waitAndClickElement(radioMarriedNo);
        }
    }

    private void enterBirthday(String birthday) {
        waitAndClickElement(this.birthday);
        sendKeysToElementWithoutClearingField(this.birthday, birthday);
    }

    private void enterEmail(String email) {
        waitAndClickElement(this.email);
        sendKeysOneByOne(this.email, email);
    }

    private void enterPhone(String phone) {
        waitAndClickElement(this.phone);
        sendKeysToElementWithoutClearingField(this.phone, phone);
    }

    public void enterHomeApplicantData(ApplicantAceHome applicant) throws Exception {
        enterAddress(applicant.getAddress());
        clickGoToStep2Button();
        clickGoToStep3Button();
        selectCurrentlyInsured(false);
        clickGoToLastStepButton();

        //Enter Applicant's info
        enterFullName(applicant.getFirstName() + SPACE + applicant.getLastName());
        enterGender(applicant.getGender());
        enterMaritalStatus(applicant.getMaritalStatus());
        enterBirthday(applicant.getDateOfBirth());
        enterEmail(applicant.getEmailAddress());
        enterPhone(applicant.getPhoneNumber());
        clickGetYourQuotesButton();
        waitForPageToBeReady();
        switchToNewWindow(viewMyQuoteButton);
        waitElementBeVisible(redirectButton);
        clickRedirectButton();
    }

}
