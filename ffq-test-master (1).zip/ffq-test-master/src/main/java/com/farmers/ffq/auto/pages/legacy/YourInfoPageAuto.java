	package com.farmers.ffq.auto.pages.legacy;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.dataproviders.SqlDataProviders;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.datatransferobjects.SqlRepresentative;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) Auto - Your Info Page.
 */
public class YourInfoPageAuto extends AutoBasePage {

	private static final String NAVIGATING_TO_MONETIZATION_SCREEN = "Navigating to monetization screen";
	private static final String YOUR_INFO_PAGE_HEADER = "We invite you to get a free quote";
	private static final String YOUR_INFO_PAGE_SUBTITLE_BEGIN = "We can get started with just a few personal details.";
	private static final String YOUR_INFO_PAGE_SUBTITLE_END = "Please enter the requested information.";
	private static final String YOUR_INFO_PAGE_SAVE_MONEY = "Save money based on where you work or the groups you belong to";
	private static final String YOUR_INFO_PAGE_QUALIFYING_TEXT = "Check for group discounts with Farmers GroupSelectSM based on your relationship with a qualifying:";
	private static final String YOUR_INFO_PAGE_DISCLAIMER_ENDING = "Farmers entities may use any consumer report information their affiliates might currently have for you for your quote request. " +
			"Our Privacy Notice gives you the choice to opt out of allowing Farmers affiliates to share your consumer report information among Farmers entities. " +
			"You can still opt out of future sharing. By clicking \"Agree\", you acknowledge that you've read & agree to the Privacy Policy and the above consumer report information provisions. " +
			"Otherwise contact a Farmers\u00ae representative to discuss options.";
	private static final String YOUR_INFO_PAGE_DISCLAIMER =
			"In connection with this application for insurance, Farmers may review your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. " +
			"We may use third parties in connection with the development of your insurance scores based on data from traditional credit bureaus. "+
			"If you believe an extraordinary life circumstance has negatively impacted your credit information, you may request, in writing, that we provide reasonable exceptions to our underwriting and/or rating practices. " +
			"Please contact a Farmers\u00ae representative for details on qualifying circumstances and how to request an exception. " + YOUR_INFO_PAGE_DISCLAIMER_ENDING;
	private static final String YOUR_INFO_PAGE_CREDIT_DISCLAIMER_NY =
			"In connection with this application for insurance, we may review your and your spouse's credit report or obtain or use a credit-based insurance score based on the information contained in that report. " +
			"An insurance score uses information from your credit report to help predict how often you are likely to file claims and how expensive those claims will be. " +
			"Typical items from a credit report that could affect a score include, but are not limited to, the following: payment history, number of revolving accounts, number of new accounts, the presence of collection accounts, bankruptcies and foreclosures. " +
			"The information used to develop the insurance score comes from Equifax. " + YOUR_INFO_PAGE_DISCLAIMER_ENDING;
	private static final String FIRSTNAME_ERROR_MESSAGE = "Please enter your first name.";
	private static final String LASTNAME_ERROR_MESSAGE = "Please enter your last name.";
	private static final String DOB_ERROR_MESSAGE = "Please enter your date of birth.";
	private static final String ADDRESS_ERROR_MESSAGE = "Please enter your residential address.";
	private static final String CITY_ERROR_MESSAGE = "Please enter your city.";
	private static final String YOUR_INFO_PAGE_NAME_DOB_SECTION_LABEL = "Name and date of birth";
	private static final String YOUR_INFO_PAGE_ADDRESS_SECTION_LABEL = "Residential address";
	private static final String ADDRESS_HELP_TITLE = "Residential Address";
	private static final String ADDRESS_HELP_TEXT = "Where is your car typically parked overnight? For most, this is a home address. If you regularly park your car elsewhere, such as a paid parking garage, please provide that address.";
	private static final String EXCEPTION_ERROR_STRING = "ERROR is: ";
	private static final String EXCEPTION_ERROR_MESSAGE_STRING = "ERROR message is: ";

	@FindBy(id = "auto-module_header-title")
	private WebElement yourInfoPageHeader;

	@FindBy(xpath = "//div[contains(@class, 'auto-module__discount-journey-text')]")
	private WebElement yourInfoPageSubtitle;

	@FindBy(xpath = "//div[contains(@class, 'auto-module__discount-journey-card')]/div[2]")
	private WebElement yourInfoPageSaveTime;

	@FindBy(xpath = "//div[contains(@class, 'auto-module__discount-journey-card')]/div[3]")
	private WebElement yourInfoPageNeverSellInfo;

	@FindBy(xpath = "//div[@class='auto-module__your-info-card-detail-text-message-header' and contains(text(), 'Name')]")
	private WebElement nameAndDOBSectionLabel;

	@FindBy(xpath = "//div[@id='auto-module__your-info-card-input-fname']/lib-input-text/mat-form-field/div/div/div/input")
	private WebElement firstNameEntryField;

	@FindBy(xpath = "//div[@id='auto-module__your-info-card-input-fname']/lib-input-text/mat-form-field/div/div[contains(@class, 'mat-form-field-subscript-wrapper')]/div/mat-error")
	private WebElement firstNameErrorMessage;

	@FindBy(xpath = "//div[@id='auto-module__your-info-card-input-lname']/lib-input-text/mat-form-field/div/div/div/input")
	private WebElement lastNameEntryField;

	@FindBy(xpath = "//div[@id='auto-module__your-info-card-input-lname']/lib-input-text/mat-form-field/div/div/div/mat-error")
	private WebElement lastNameErrorMessage;

	@FindBy(xpath = "//lib-date-picker/mat-form-field/div/div/div/input[@data-gtm]")
	private WebElement dobEntryField;

	private static final String DOB_ERROR_MESSAGE_XPATH ="//lib-date-picker/mat-form-field/div/div/div/mat-error";
	@FindBy(xpath = DOB_ERROR_MESSAGE_XPATH)
	private WebElement dobErrorMessage;

	@FindBy(id = "auto-module__your-info-card-detail-residential-address-header")
	private WebElement addressSectionLabel;

	@FindBy(className = "info-icon")
	private WebElement addressFAQButton;

	@FindBy(xpath = "//div[@id='auto-module__your-info-card-input-address']//input")
	private WebElement addressEntryField;

	@FindBy(xpath = "//div[@id='auto-module__your-info-card-input-address']//mat-error")
	private WebElement addressErrorMessage;

	@FindBy(xpath = "//div[@class='cdk-overlay-container']/div[@class='cdk-global-overlay-wrapper']/div[@class='cdk-overlay-pane ffq-info-dialog']/mat-dialog-container/lib-info-dialog/div")
	private WebElement addressFAQTitle;

	@FindBy(xpath = "//div[@class='cdk-overlay-container']/div[@class='cdk-global-overlay-wrapper']/div[@class='cdk-overlay-pane ffq-info-dialog']/mat-dialog-container/lib-info-dialog/div[@class='dialog_info-dialog-content']")
	private WebElement addressFAQContent;

	@FindBy(xpath = "//div[@id='auto-module__your-info-card-input-apt']/lib-input-text/mat-form-field/div/div/div/input")
	private WebElement apartmentEntryField;

	@FindBy(xpath = "//div[@id='auto-module__your-info-card-input-city']/lib-input-text/mat-form-field/div/div/div/input")
	private WebElement cityEntryField;

	@FindBy(xpath = "//div[@id='auto-module__your-info-card-input-city']/lib-input-text/mat-form-field/div/div/div/mat-error")
	private WebElement cityEntryFieldErrorMessage;

	@FindBy(xpath = "//div[@id='auto-module__your-info-card-select-city']/lib-select/mat-form-field/div/div/div/mat-select")
	private WebElement citySelectField;

	@FindBy(xpath = "//div[@id='auto-module__your-info-card-select-city']/lib-select/mat-form-field/div/div/div/mat-error")
	private WebElement citySelectErrorMessage;

	private static final String TOWN_DROPDOWN_XPATH ="//mat-select[@data-gtm='FFQ_Auto_Yourinfo_Town_dropdown']";
	@FindBy(xpath = TOWN_DROPDOWN_XPATH)
	private WebElement townSelectField;

	@FindBy(xpath = "//div[@id='auto-module__your-info-card-input-zip']/lib-input-text/mat-form-field/div/div/div/input")
	private WebElement zipCodeEntryField;

	@FindBy(xpath = "//div[@id='auto-module__your-info-card-input-state']/lib-input-text/mat-form-field/div/div/div/input")
	private WebElement stateCodeEntryField;

	private static final String CURRENTLY_INSURED_RADIO_BUTTON_XPATH = "//mat-radio-button[@data-gtm='FFQ_Auto_Yourinfo_haveins_yes_radio']/label/div";
	@FindBy(xpath = CURRENTLY_INSURED_RADIO_BUTTON_XPATH)
	private WebElement currentlyInsuredRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Yourinfo_haveins_yes_radio']")
	private WebElement currentlyInsuredRadioButtonLabel;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Yourinfo_haveins_no_radio']/label/div")
	private WebElement notCurrentlyInsuredRadioButton;

	@FindBy(xpath = "//mat-radio-button[@data-gtm='FFQ_Auto_Yourinfo_haveins_no_radio']")
	private WebElement notCurrentlyInsuredRadioButtonLabel;

	private static final String YIP_NEXT_BUTTON_XPATH = "//div[@id='auto-module__your-info-next-buttton-holder']/div/button[@data-gtm='FFQ_Auto_Yourinfo_next_button']";
	@FindBy(xpath = YIP_NEXT_BUTTON_XPATH)
	private WebElement nextPageButton;

	@FindBy(xpath = "//div[contains(@class, 'auto-module__your-info-card')]/div[@class='auto-module__your-info-employer-box']/div[@class='auto-module__your-info-card-detail-text-employer-header']")
	private WebElement workGroupSavingsText;

	@FindBy(xpath = "//div[contains(@class, 'auto-module__your-info-card')]/div[@class='auto-module__your-info-employer-box']/div[@class='auto-module__your-info-card-detail-text-employer-subheader']")
	private WebElement qualifyingText;

	private static final String EMPLOYER_GROUP_ID = "mat-input-fwsField";
	@FindBy(id = EMPLOYER_GROUP_ID)
	private WebElement yourInfoEmployerGroupDropdown;

	@FindBy(xpath = "//a[@data-gtm='Farmers_COLPGS_FFQLINK_Header' and contains(@class, 'button-cta--desktop')]")
	private WebElement quoteWithFarmersOnlineDesktopLink;

	@FindBy(xpath = "//a[@data-gtm='Farmers_COLPGS_FFQLINK_Header' and contains(@class, 'button-cta--mobile')]")
	private WebElement quoteWithFarmersOnlineMobileLink;

	@FindBy(xpath = "//div[@class='auto-module__your-info-card-text-disclaimer']")
	private WebElement yourInfoPageDisclaimer;

	@FindBy(xpath = "//div[@class='auto-module__your-info-card-text-disclaimer']//p[contains(@class, 'p_disclaimer_text')]")
	private WebElement yourInfoPageAlternateStateDisclaimer;

	@FindBy(xpath = "//div[@class='auto-module__your-info-card-text-disclaimer']/p[2]")
	private WebElement yipAdditionalDisclaimer;

	@FindBy(xpath = "//a[@data-gtm='FFQ_Auto_sidepanel_contactus_link']")
	private WebElement contactUsLink;

	@FindBy(xpath = "//a[@data-gtm='FFQ_Auto_sidepanel_termsofuse_link']")
	private WebElement termsOfUseLink;

	@FindBy(xpath = "//a[@data-gtm='FFQ_Auto_sidepanel_privacypolicy_link']")
	private WebElement privacyPolicyLink;

	@FindBy(xpath = "//a[@data-gtm='FFQ_Auto_sidepanel_noticeinfoprac_link']")
	private WebElement noticeOfInformationPracticesLink;

	@FindBy(linkText = "Personal information use")
	private WebElement personalInfoUseLink;

	@FindBy(id = "auto-module__your-info-next-buttton-holder")
	private WebElement bottomOfYourInfoPageAuto;

	@FindBy(xpath = "//mat-sidenav//div[starts-with(text(), ' Auto Quote ')]")
	private WebElement txtQuoteNumber;

	@FindBy(className = "agent-detail-name")
	private WebElement assignedAgentName;

	@FindBy(id = "mat-checkbox-1")
	private WebElement subscriptionAgreementCheckbox;

	@FindBy(className = "btn-confirm")
	private WebElement continueButton;

	@FindBy(xpath = "//button[@data-gtm='FFQ_Auto_savefinishmodal_Contquote_button']")
	private WebElement closeContinueDialogButton;

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public YourInfoPageAuto() throws Exception {
		super();
	}

	public boolean validatePageTitle() {
		List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC23849", "TC23850", "TC23851"));
		String yourInfoPageHeaderText = getTextFromElement(yourInfoPageHeader);
		boolean retValue = yourInfoPageHeaderText.equals(YOUR_INFO_PAGE_HEADER);
		String result = retValue? PASSED : FAILED;
		writeTestcaseState("YourInfoPageAuto.validatePageTitle", ALL_STATES, rallyTestcasesCovered, result);
		return retValue;
	}

	public boolean validatePageSubtitle() {
		String expectedSubtitle = YOUR_INFO_PAGE_SUBTITLE_BEGIN + SPACE + YOUR_INFO_PAGE_SUBTITLE_END;
		return isExpectedTextDisplayed(yourInfoPageSubtitle, expectedSubtitle);
	}

	public void validateWorkGroupDescription(FarmersSoftAssert fsa) {
		scrollToElement(bottomOfYourInfoPageAuto);
		fsa.assertEquals(getTextFromElement(workGroupSavingsText), YOUR_INFO_PAGE_SAVE_MONEY, YOUR_INFO_PAGE_SAVE_MONEY);
		fsa.assertEquals(getTextFromElement(qualifyingText), YOUR_INFO_PAGE_QUALIFYING_TEXT, YOUR_INFO_PAGE_QUALIFYING_TEXT);
	}

	public boolean isEmployerGroupDropDownPresent() {
		return isElementPresentByID(yourInfoEmployerGroupDropdown);
	}

	public boolean validatePageDisclaimer(SqlApplicant applicant) {
		scrollToElement(nextPageButton);
		waitElementBeVisible(yourInfoPageDisclaimer);
		String separator = isSafariBrowser()? EMPTY_STRING : SPACE;
		String expectedDisclaimerContent = isUseMobileViewEnabled() || applicant.getTestCategory().equals(MOBILE_BROWSER)? "Please review our Personal information use" + separator: EMPTY_STRING;
		return isExpectedTextDisplayed(yourInfoPageDisclaimer, expectedDisclaimerContent.concat(applicant.getStateCode().equals(NY)? YOUR_INFO_PAGE_CREDIT_DISCLAIMER_NY: YOUR_INFO_PAGE_DISCLAIMER));
	}

	public boolean validateHyperlinks() {
		try {
			verifyListOfLinks(getListWithYourInfoFooterLinks(),getMapWithURLsAndPageTitles());
			return true;
		} catch (Exception e) {
			Log.error(EXCEPTION_ERROR_STRING + e);
			Log.error(EXCEPTION_ERROR_MESSAGE_STRING + e.getMessage());
			return false;
		}
	}

	public boolean validateErrorMessages(String stateCode, FarmersSoftAssert fsa) throws Exception{
		try {
			waitAndClickElement(dobEntryField);
			waitAndClickElement(firstNameEntryField);
			waitAndClickElement(lastNameEntryField);
			waitAndClickElement(addressEntryField);
			if (isCityDropdownState(stateCode)) {
				scrollAndClickOnElement(citySelectField);
			} else {
				scrollAndClickOnElement(cityEntryField);
			}
			clickContinueToVehiclesPage();
			List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC23887"));
			writeTestcaseState("YourInfoPageAuto.validateErrorMessages", ALL_STATES, rallyTestcasesCovered, FAILED);
			verifyElementExpectedContent(getListWithPageErrorElements(stateCode), getMapWithExpectedErrorMessages(stateCode), fsa);
			writeTestcaseState("YourInfoPageAuto.validateErrorMessages", ALL_STATES, rallyTestcasesCovered, PASSED);
			return true;
		} catch (Exception e) {
			Log.error(EXCEPTION_ERROR_STRING + e);
			Log.error(EXCEPTION_ERROR_MESSAGE_STRING + e.getMessage());
			return false;
		}
	}

	public void clickContinueToVehiclesPage() {
		scrollAndClickOnElement(nextPageButton);
		waitForSpinnerToBeGone();
	}

	public void validateFAQs(FarmersSoftAssert fsa) throws Exception {
		scrollToElement(addressFAQButton);
		waitElementBeVisibleClickable(addressFAQButton);
		List<String> rallyTestcasesCovered = new ArrayList<>(Arrays.asList("TC23888"));
		writeTestcaseState("YourInfoPageAuto.validateFAQs", ALL_STATES, rallyTestcasesCovered, FAILED);
		validateFAQ(addressFAQButton, ADDRESS_HELP_TITLE, ADDRESS_HELP_TEXT, fsa);
		writeTestcaseState("YourInfoPageAuto.validateFAQs", ALL_STATES, rallyTestcasesCovered, PASSED);
	}

	public boolean validateSectionsLabel() {
		boolean retValue = isExpectedTextContainedInElement(nameAndDOBSectionLabel, YOUR_INFO_PAGE_NAME_DOB_SECTION_LABEL);
		retValue &= isExpectedTextContainedInElement(addressSectionLabel, YOUR_INFO_PAGE_ADDRESS_SECTION_LABEL);
		return retValue;
	}

	public VehiclesPage fillOutPageAndContinue(SqlApplicant applicant) throws Exception {
		String applicantStateCode = applicant.getStateCode();
		String environmentURI = Property.getUri();
		//F51790 Digital Monetization changes
		if (SqlDataProviders.getListOfLegacyAutoMonetizedStates(environmentURI).contains(applicantStateCode)) {
			waitForSpinnerToBeGone();
			boolean isCurrentlyInsured = applicant.isCurrentlyHaveAutoInsurance();
			boolean useBristolWest = !applicant.getCurrentlyInsuredStatus().equalsIgnoreCase("NOBW");
			SqlRepresentative agent = applicant.getRepresentative();
			boolean usingAgentWebsite = (agent != null) && applicantStateCode.equals(agent.getStateCode());
			boolean useFGIA = applicant.getPhoneExtentionNumber().equals("FGIA");
			if  (usingAgentWebsite) {
				continueToBristolWest(useBristolWest);
				if (!useBristolWest) {
					processFGIAModal(useFGIA);
				}
			} else {
				if (Arrays.asList(CA, GA).contains(applicantStateCode)) {
					throw new IllegalStateException(NAVIGATING_TO_MONETIZATION_SCREEN);
				} else if (Arrays.asList(NC, NV).contains(applicantStateCode)) {
					processFGIAModal(useFGIA);
				} else if (applicantStateCode.equals(FL)){
					continueToBristolWest(useBristolWest);
					if (!useBristolWest) {
						throw new IllegalStateException(NAVIGATING_TO_MONETIZATION_SCREEN);
					}
				} else if (Arrays.asList(CT, KY, MA).contains(applicantStateCode)) {
					setCurrentlyInsured(isCurrentlyInsured);
					if (isCurrentlyInsured) {
						processFGIAModal(useFGIA);
					} else {
						continueToBristolWest(useBristolWest);
						if (!useBristolWest) {
							processFGIAModal(useFGIA);
						}
					}
				} else if (Arrays.asList(LA, MS, NJ, NY).contains(applicantStateCode)) {
					setCurrentlyInsured(isCurrentlyInsured);
					if (isCurrentlyInsured) {
						throw new IllegalStateException(NAVIGATING_TO_MONETIZATION_SCREEN);
					} else {
						continueToBristolWest(useBristolWest);
						if (!useBristolWest) {
							throw new IllegalStateException(NAVIGATING_TO_MONETIZATION_SCREEN);
						}
					}
				}
			}
		}
		waitForPage();
		if (isADATestingEnabled()) {
		    scrollAndClickOnElement(addressFAQButton);
		    clickContinueToVehiclesPage();
		    performADATesting(getClass().getSimpleName(), MARKETING_IT, "Auto");
		    screenCapture(firstNameEntryField, getClass().getSimpleName(), LOB_AUTO, false);
		    scrollAndClickOnElement(faqDialogCloseButton);
		}
		sendKeysToElement(firstNameEntryField, applicant.getFirstName());
		sendKeysToElement(lastNameEntryField, applicant.getLastName());
		scrollElementToTop(dobEntryField);
		//NY minimum age limit is 17, not 16 like other states. Adjust the data for that testcase
		if (applicant.getApplicantId() == 24 && applicantStateCode.equals(NY)) {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern(MM_DD_YYYY);
			LocalDateTime nowMinusSeventeenYears = LocalDateTime.now().minusYears(17);
			applicant.setDateOfBirth(dtf.format(nowMinusSeventeenYears));
		}
		sendKeysToElement(dobEntryField, applicant.getDateOfBirth());
		sendKeysToElement(addressEntryField, applicant.getResidentAddress1());
		sendKeysToElement(apartmentEntryField, applicant.getResidentAddress2());
		if (isCityDropdownState(applicantStateCode)) {
			scrollElementToMiddle(citySelectField);
			selectValueInDropdown(applicant.getCity().toUpperCase(Locale.US), citySelectField, addressSectionLabel);
		} else {
			scrollElementToMiddle(cityEntryField);
			if (isElementPresentByXPath(TOWN_DROPDOWN_XPATH)) {
				selectValueInDropdown(applicant.getCity().toUpperCase(Locale.US), townSelectField, addressSectionLabel);
			}
			sendKeysToElement(cityEntryField,applicant.getCity());
		}
		if (isElementPresentByXPath(CURRENTLY_INSURED_RADIO_BUTTON_XPATH)) {
			setCurrentInsuranceStatus(applicant.isCurrentlyHaveAutoInsurance());
			sleep(1);
		}
		selectSubscriptionCheckbox();
		useFarmersGroupSelect(applicant.getTestScenario().equals("FGS"));
		clickContinueToVehiclesPage();
		if (isElementPresent(By.className("btn-confirm"), 5)) {
			clickElement(continueButton);
			waitForSpinnerToBeGone();
		}
		waitElementBeInvisible(nextPageButton);
		return new VehiclesPage();
	}

	public void setCurrentlyInsured(boolean isInsured) {
		if (isElementPresentByXPath(CURRENTLY_INSURED_RADIO_BUTTON_XPATH)) {
			setCurrentInsuranceStatus(isInsured);
			clickElement(closeContinueDialogButton);
		}
	}

	public VehiclesPage fillOutPageAndContinue(ApplicantHQM applicantHqm) throws Exception {
		setCurrentlyInsured(true);
		firstNameEntryField.sendKeys(applicantHqm.firstName);
		lastNameEntryField.sendKeys(applicantHqm.lastName);
		scrollAndClickOnElement(dobEntryField);
		dobEntryField.sendKeys(applicantHqm.dateOfBirth);
		addressEntryField.sendKeys(applicantHqm.addressApt);
		if (isCityDropdownState(applicantHqm.stateCode)) {
			selectValueInDropdown(applicantHqm.city, citySelectField, addressSectionLabel);
		} else {
			cityEntryField.sendKeys(applicantHqm.city);
		}
		clickContinueToVehiclesPage();
		waitForSpinnerToBeGone();
		waitElementBeInvisible(nextPageButton);
		return new VehiclesPage();
	}

	public String getFirstName() {
		return getElementValue(firstNameEntryField, "First Name: ");
	}

	public String getLastName() {
		return getElementValue(lastNameEntryField, "Last Name: ");
	}

	public String getDateOfBirth() {
		return getElementValue(dobEntryField, "Date of birth: ");
	}

	public String getAddress() {
		return getElementValue(addressEntryField, "Street Address: ");
	}

	public String getApartmentNumber() {
		return getElementValue(apartmentEntryField, "Apartment Number: ");
	}

	public String getCity() {
		return getElementValue(cityEntryField, "City: ");
	}

	public String getZipCode() {
		return getElementValue(zipCodeEntryField, "Zip Code: ");
	}

	public String getState() {
		return getElementValue(stateCodeEntryField, "State: ");
	}

	public String getQuoteNumber() {
		return getRedesignedQuoteNumber();
	}

	public void validateData(SqlApplicant applicant, FarmersSoftAssert fsa) {
		fsa.assertEquals(getFirstName(), applicant.getFirstName(), "First name");
		fsa.assertEquals(getLastName(), applicant.getLastName(), "Last name");
		fsa.assertEquals(getDateOfBirth().replace("/", ""), applicant.getDateOfBirth(), "Date of birth");
		fsa.assertEquals(getAddress().toLowerCase(), applicant.getResidentAddress1().toLowerCase(), "Address");
		fsa.assertEquals(getCity(), applicant.getCity(), "City");
		fsa.assertEquals(getState(), applicant.getStateName(), "State");
		fsa.assertEquals(getZipCode(), applicant.getZipCode(), "Zip Code");
	}

	public boolean isAgentAssigned(SqlApplicant applicant) {
		return getAssignedAgentName().toLowerCase().contains(applicant.getRepresentative().getFullName().toLowerCase());
	}

	public void processMonetizedDialog() throws KnockoutException {
		setCurrentlyInsured(false);
		continueToBristolWest(true);
		waitForPage();
	}

	public void continueToDM(String applicantStateCode) {
		boolean askToContinueState = Arrays.asList(NV, NC).contains(applicantStateCode);
		if (askToContinueState) {
			waitAndClickElement(continueToDigitalMonetization);
		}
	}

	public void selectSubscriptionCheckbox() {
		if (isElementPresent(By.id("mat-checkbox-1"), 5)) {
			scrollToElement(nextPageButton);
			setCheckboxTo(subscriptionAgreementCheckbox, true);
		}
	}

	public void validateGTMTags(String stateCode, FarmersSoftAssert fsa) {
		scrollToElement(bottomOfYourInfoPageAuto);
		verifyElementExpectedAttribute(getListWithPageElements(stateCode), getMapWithExpectedGTMTags(stateCode), "data-gtm", fsa);
	}

	public void setCurrentInsuranceStatus(boolean currentlyHaveAutoInsurance) {
		scrollToElement(currentlyInsuredRadioButton);
		if (currentlyHaveAutoInsurance) {
			currentlyInsuredRadioButton.click();
		} else {
			notCurrentlyInsuredRadioButton.click();
		}
	}

	private boolean isCityDropdownState(String stateCode) {
		List<String> cityDropdownStates = new ArrayList<>(Arrays.asList(MI));
		return cityDropdownStates.contains(stateCode);
	}

	private List<WebElement> getListWithYourInfoFooterLinks() {
		return new ArrayList<>(Arrays.asList(personalInfoUseLink, privacyPolicyLink, termsOfUseLink, contactUsLink));
	}

	private LinkedHashMap<String, String> getMapWithURLsAndPageTitles() {
		LinkedHashMap<String, String> urlsAndTitles = new LinkedHashMap<>();
		urlsAndTitles.put(PERSONAL_INFO_USE_URL.toLowerCase(), PERSONAL_INFO_USE_URL.replace("-", SPACE));
		urlsAndTitles.put("donotsell", PERSONAL_INFO_USE_URL.replace("-", SPACE));
		urlsAndTitles.put(TERMS_OF_USE_URL.toLowerCase(), TERMS_OF_USE_URL.replace("-", SPACE));
		urlsAndTitles.put(CONTACT_US_URL.toLowerCase(), CONTACT_US_URL.replace("-", SPACE));
		return urlsAndTitles;
	}

	private List<WebElement> getListWithPageErrorElements(String stateCode) {
		Log.info("Getting List with Your Info Page error label elements");
		List<WebElement> yipErrorElements = new ArrayList<>();
		yipErrorElements.add(firstNameErrorMessage);
		yipErrorElements.add(lastNameErrorMessage);
		yipErrorElements.add(dobErrorMessage);
		yipErrorElements.add(addressErrorMessage);
		if (!isCityDropdownState(stateCode)) {
			yipErrorElements.add(cityEntryFieldErrorMessage);
		}
		return yipErrorElements;
	}

	private Map<WebElement, String> getMapWithExpectedErrorMessages(String stateCode) {
		Log.info("Getting Map with expected Your Info Page error messages");
		Map<WebElement,String> expectedErrorMessagesMap = new HashMap<>();
		expectedErrorMessagesMap.put(firstNameErrorMessage, FIRSTNAME_ERROR_MESSAGE);
		expectedErrorMessagesMap.put(lastNameErrorMessage, LASTNAME_ERROR_MESSAGE);
		expectedErrorMessagesMap.put(dobErrorMessage, DOB_ERROR_MESSAGE);
		expectedErrorMessagesMap.put(addressErrorMessage, ADDRESS_ERROR_MESSAGE);
		if (!isCityDropdownState(stateCode)) {
			expectedErrorMessagesMap.put(cityEntryFieldErrorMessage, CITY_ERROR_MESSAGE);
		}
		return expectedErrorMessagesMap;
	}

	private List<WebElement> getListWithPageElements(String stateCode) {
		Log.info("Getting List with Your Info Page elements");
		List<WebElement> yipElements = new ArrayList<>();
		yipElements.add(firstNameEntryField);
		yipElements.add(lastNameEntryField);
		yipElements.add(dobEntryField);
		yipElements.add(addressEntryField);
		yipElements.add(apartmentEntryField);
		if (isCityDropdownState(stateCode)) {
			yipElements.add(citySelectField);
		} else {
			yipElements.add(cityEntryField);
		}
		yipElements.add(zipCodeEntryField);
		yipElements.add(stateCodeEntryField);
		if (isElementPresentByXPath(CURRENTLY_INSURED_RADIO_BUTTON_XPATH)) {
			yipElements.add(currentlyInsuredRadioButtonLabel);
			yipElements.add(notCurrentlyInsuredRadioButtonLabel);
		}
		yipElements.add(nextPageButton);
		return yipElements;
	}

	private Map<WebElement, String> getMapWithExpectedGTMTags(String stateCode) {
		Log.info("Getting Map with expected Your Info Page elements GTM values");
		Map<WebElement,String> expectedElementGTMMap = new HashMap<>();
		expectedElementGTMMap.put(firstNameEntryField, "FFQ_Auto_Yourinfo_firstname_text");
		expectedElementGTMMap.put(lastNameEntryField, "FFQ_Auto_Yourinfo_lastname_text");
		expectedElementGTMMap.put(dobEntryField, "FFQ_Auto_Yourinfo_DOB_date");
		expectedElementGTMMap.put(addressEntryField, "FFQ_Auto_Yourinfo_resiaddress_text");
		expectedElementGTMMap.put(apartmentEntryField, "FFQ_Auto_Yourinfo_resiaptnumber_text");
		if (isCityDropdownState(stateCode)) {
			expectedElementGTMMap.put(citySelectField, "FFQ_Auto_Yourinfo_resicity_dropdown");
		} else {
			expectedElementGTMMap.put(cityEntryField, "FFQ_ Auto_Yourinfo_resicity_text");
		}
		expectedElementGTMMap.put(zipCodeEntryField, "FFQ_Auto_Yourinfo_resizipcode_text");
		expectedElementGTMMap.put(stateCodeEntryField, "FFQ_Auto_Yourinfo_resistate_text");
		if (isElementPresentByXPath(CURRENTLY_INSURED_RADIO_BUTTON_XPATH)) {
			expectedElementGTMMap.put(currentlyInsuredRadioButtonLabel, "FFQ_Auto_Yourinfo_haveins_yes_radio");
			expectedElementGTMMap.put(notCurrentlyInsuredRadioButtonLabel, "FFQ_Auto_Yourinfo_haveins_no_radio");
		}
		expectedElementGTMMap.put(nextPageButton, "FFQ_Auto_Yourinfo_next_button");
		return expectedElementGTMMap;
	}

	private void processFGIAModal(boolean useFGIA) {
		if (useFGIA) {
			waitAndClickElement(continueToFGIA);
			throw new IllegalStateException("Navigating to FGIA website");
		} else {
			waitAndClickElement(continueToDigitalMonetization);
			throw new IllegalStateException(NAVIGATING_TO_MONETIZATION_SCREEN);
		}
	}

	private void useFarmersGroupSelect(boolean useFGS) throws Exception {
		if (useFGS) {
			enterEmployerGroupInformation("BANK OF AMERICA");
			clickContinueToVehiclesPage();
			quoteWithFarmersOnline();
			waitForSpinnerToBeGone();
		}
	}

	private void enterEmployerGroupInformation(String employerGroup) throws Exception {
		enterValueInField(employerGroup, yourInfoEmployerGroupDropdown, employerGroup);
		selectValueInDropdown(employerGroup, yourInfoEmployerGroupDropdown, workGroupSavingsText);
	}

	private void quoteWithFarmersOnline() {
		if (isMobileApplication()) {
			scrollAndClickOnElement(waitElementBeVisible(quoteWithFarmersOnlineMobileLink));
		} else {
			scrollAndClickOnElement(waitElementBeVisible(quoteWithFarmersOnlineDesktopLink));
		}
	}

	private String getAssignedAgentName() {
		String agentName = getTextFromElement(assignedAgentName);
		Log.warn("Agent's name is :" + agentName + NEWLINE);
		return agentName;
	}

	private void waitForPage() throws KnockoutException {
		waitForSpinnerToBeGone();
		checkForKnockout("YourInfoPageAuto.waitForPage");
		waitElementBeVisible(yourInfoPageHeader);
	}
}
