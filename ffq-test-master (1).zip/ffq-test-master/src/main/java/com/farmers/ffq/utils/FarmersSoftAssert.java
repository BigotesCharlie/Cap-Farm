package com.farmers.ffq.utils;

import static com.farmers.ffq.utils.GlobalVariables.EMPTY_STRING;
import static com.farmers.ffq.utils.GlobalVariables.NEWLINE;
import static com.farmers.framework.AutomationFramework.testStep;
import static com.farmers.framework.saucelabs.SauceRest.getPublicJobLink;

import org.openqa.selenium.WebDriverException;
import org.testng.asserts.IAssert;
import org.testng.asserts.SoftAssert;

import com.farmers.framework.Property;
import com.farmers.framework.driver.Driver;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;

public class FarmersSoftAssert extends SoftAssert {
	@Override
	public void onAssertFailure(IAssert<?> assertCommand, AssertionError ex) {
		String failingMessage = assertCommand.getMessage();
		if (assertCommand.getExpected()!=null && assertCommand.getActual()!=null) {
			String suffix =	String.format("Expected [%s] but found [%s]",
					assertCommand.getExpected().toString(), assertCommand.getActual().toString());
			failingMessage = failingMessage  + " : " + suffix; 
		}
		Reporter.fail(failingMessage);
		try {
			Driver.screenshot(EMPTY_STRING, true, "fail");
		} catch (WebDriverException e) {
			String msg = e.getMessage();
			if (msg != null && (msg.contains("session has already finished") || msg.contains("session deleted") || msg.contains("Session ID is null"))) {
				Log.warn("Screenshot skipped — remote session is no longer active: " + msg.split("\n")[0]);
			} else {
				Log.warn("Screenshot failed: " + e.getMessage());
			}
		}
	}

	@Override
	public void onAssertSuccess(IAssert<?> assertCommand) {
		Reporter.pass(assertCommand.getMessage());
	}

	@Override
	public void assertAll() {
		this.assertAll((String) null);
	}

	@Override
	public void assertAll(String message) {
		super.assertAll(message);
		Reporter.pass("No errors found");
		if (Property.getTestProperty("remote").equalsIgnoreCase("saucelabs")) {
			Reporter.pass(NEWLINE + ">>> SauceLabs link: " + getPublicJobLink() + NEWLINE);
		}
		testStep("End of Test");
	}
}

