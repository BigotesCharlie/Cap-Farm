package com.farmers.ffq.auto.pages.legacy;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.datatransferobjects.SqlPayment;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;

import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PaymentPage extends AutoBasePage  {
	private static final String PAYMENT_PAGE_HEADER = "//div[@id='PaymentContent']/div[@id='Intro']";
	@FindBy(xpath = PAYMENT_PAGE_HEADER + "/p[@title='PAYMENT DETAILS']")
	private WebElement paymentPageTitle;

	@FindBy(xpath = PAYMENT_PAGE_HEADER + "/p[@class='subTitleAlign']")
	private WebElement paymentPageDescription;

	@FindBy(xpath = PAYMENT_PAGE_HEADER + "/p[@id='termPremiumSecText']")
	private WebElement termPremium;

	@FindBy(xpath = "//span[contains(@id,'payment:paymentHeaderText')]")
	private WebElement paymentPlanHeader;

	@FindBy(id = "MoreOptions")
	private WebElement changePaymentPlanLink;
	
	@FindBy(id = "payment:doInitiateESignature")
	private WebElement continueToSignButton;

	@FindBy(id = "disclosureAccepted")
	private WebElement agreeToUseESign;
	
	@FindBy(id = "action-bar-btn-continue")
	private WebElement continueFromESign;
	
	@FindBy (id = "action-bar-btn-finish")
	private WebElement bwFinishDocReviewButton;
	  
	//Select Payment Dialog
	@FindBy(xpath = "//div[contains(@class, 'selectPaymentOptionHeading')]")
	private WebElement selectPaymentDialogTitle;

	private static final String RADIO_BUTTON_SECTION = "//div[contains(@class, 'radioAlign')]";
	private static final String DUE_TODAY_SECTION = "//div[contains(@class, 'dueToday')]";
	private static final String NEXT_PAYMENT_SECTION = "//div[contains(@class, 'nextPaymentDueClass')]";
	private static final String PAYMENT_SCHEDULE_SECTION = "//div[contains(@class, 'paymentScheduleClass')]";

	//Payment plans
	//Pay in Full
	private static final String PAY_IN_FULL_SECTION = "//div[contains(@class, 'A1DivClass')]";
	@FindBy(xpath = PAY_IN_FULL_SECTION)
	private WebElement payInFullOption;

	@FindBy(xpath = PAY_IN_FULL_SECTION + RADIO_BUTTON_SECTION)
	private WebElement payInFullRadioButtonSection;

	@FindBy(xpath = PAY_IN_FULL_SECTION + DUE_TODAY_SECTION)
	private WebElement payInFullDueTodaySection;

	@FindBy(xpath = PAY_IN_FULL_SECTION + NEXT_PAYMENT_SECTION)
	private WebElement payInFullNextPaymentSection;

	@FindBy(xpath = PAY_IN_FULL_SECTION + PAYMENT_SCHEDULE_SECTION)
	private WebElement payInFullPaymentScheduleSection;

	// Monthly Auto Pay - Bank Account
	private static final String MONTHLY_BANK_ACCOUNT_SECTION = "//div[contains(@class, 'MTEFDivClass')]";
	@FindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION)
	private WebElement monthlyBankAccountOption;

	@FindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION + RADIO_BUTTON_SECTION)
	private WebElement monthlyBankAccountRadioButtonSection;

	@FindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION + DUE_TODAY_SECTION)
	private WebElement monthlyBankAccountDueTodaySection;

	@FindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION + NEXT_PAYMENT_SECTION)
	private WebElement monthlyBankAccountNextPaymentSection;

	@FindBy(xpath = MONTHLY_BANK_ACCOUNT_SECTION + PAYMENT_SCHEDULE_SECTION)
	private WebElement monthlyBankAccountPaymentScheduleSection;

	// Monthly Auto Pay - Credit Card
	private static final String MONTHLY_CREDIT_CARD_SECTION = "//div[contains(@class, 'MTPCDivClass')]";
	@FindBy(xpath = MONTHLY_CREDIT_CARD_SECTION)
	private WebElement monthlyCreditCardOption;

	@FindBy(xpath = MONTHLY_CREDIT_CARD_SECTION + RADIO_BUTTON_SECTION)
	private WebElement monthlyCreditCardRadioButtonSection;

	@FindBy(xpath = MONTHLY_CREDIT_CARD_SECTION + DUE_TODAY_SECTION)
	private WebElement monthlyCreditCardDueTodaySection;

	@FindBy(xpath = MONTHLY_CREDIT_CARD_SECTION + NEXT_PAYMENT_SECTION)
	private WebElement monthlyCreditCardNextPaymentSection;

	@FindBy(xpath = MONTHLY_CREDIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION)
	private WebElement monthlyCreditCardPaymentScheduleSection;

	// Monthly Auto Pay - Debit Card
	private static final String MONTHLY_DEBIT_CARD_SECTION = "//div[contains(@class, 'MTPDDivClass')]";
	@FindBy(xpath = MONTHLY_DEBIT_CARD_SECTION)
	private WebElement monthlyDebitCardOption;

	@FindBy(xpath = MONTHLY_DEBIT_CARD_SECTION + RADIO_BUTTON_SECTION)
	private WebElement monthlyDebitCardRadioButtonSection;

	@FindBy(xpath = MONTHLY_DEBIT_CARD_SECTION + DUE_TODAY_SECTION)
	private WebElement monthlyDebitCardDueTodaySection;

	@FindBy(xpath = MONTHLY_DEBIT_CARD_SECTION + NEXT_PAYMENT_SECTION)
	private WebElement monthlyDebitCardNextPaymentSection;

	@FindBy(xpath = MONTHLY_DEBIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION)
	private WebElement monthlyDebitCardPaymentScheduleSection;

	//Monthly Billing
	private static final String MONTHLY_BILLING_SECTION = "//div[contains(@class, 'MTDivClass')]";
	@FindBy(xpath = MONTHLY_BILLING_SECTION)
	private WebElement monthlyBillingOption;

	@FindBy(xpath = MONTHLY_BILLING_SECTION + RADIO_BUTTON_SECTION)
	private WebElement monthlyBillingRadioButtonSection;

	@FindBy(xpath = MONTHLY_BILLING_SECTION + DUE_TODAY_SECTION)
	private WebElement monthlyBillingDueTodaySection;

	@FindBy(xpath = MONTHLY_BILLING_SECTION + NEXT_PAYMENT_SECTION)
	private WebElement monthlyBillingNextPaymentSection;

	@FindBy(xpath = MONTHLY_BILLING_SECTION + PAYMENT_SCHEDULE_SECTION)
	private WebElement monthlyBillingPaymentScheduleSection;

	// Bristol West Payment plans
	// Pay in Full
	private static final String BW_PAY_IN_FULL_SECTION = "//div[contains(@class, 'PIFDivClass')]";
	@FindBy(xpath = BW_PAY_IN_FULL_SECTION)
	private WebElement bwPayInFullOption;

	@FindBy(xpath = BW_PAY_IN_FULL_SECTION + RADIO_BUTTON_SECTION)
	private WebElement bwPayInFullRadioButtonSection;

	@FindBy(xpath = BW_PAY_IN_FULL_SECTION + DUE_TODAY_SECTION)
	private WebElement bwPayInFullDueTodaySection;

	@FindBy(xpath = BW_PAY_IN_FULL_SECTION + NEXT_PAYMENT_SECTION)
	private WebElement bwPayInFullNextPaymentSection;

	@FindBy(xpath = BW_PAY_IN_FULL_SECTION + PAYMENT_SCHEDULE_SECTION)
	private WebElement bwPayInFullPaymentScheduleSection;

	// Monthly Auto Pay - Bank Account
	private static final String BW_MONTHLY_BANK_ACCOUNT_SECTION = "//div[contains(@class, 'EFTBDivClass')]";
	@FindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION)
	private WebElement bwMonthlyBankAccountOption;

	@FindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION + RADIO_BUTTON_SECTION)
	private WebElement bwMonthlyBankAccountRadioButtonSection;

	@FindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION + DUE_TODAY_SECTION)
	private WebElement bwMonthlyBankAccountDueTodaySection;

	@FindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION + NEXT_PAYMENT_SECTION)
	private WebElement bwMonthlyBankAccountNextPaymentSection;

	@FindBy(xpath = BW_MONTHLY_BANK_ACCOUNT_SECTION + PAYMENT_SCHEDULE_SECTION)
	private WebElement bwMonthlyBankAccountPaymentScheduleSection;

	// Monthly Auto Pay - Credit Card
	private static final String BW_MONTHLY_CREDIT_CARD_SECTION = "//div[contains(@class, 'EFTCDivClass')]";
	@FindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION)
	private WebElement bwMonthlyCreditCardOption;

	@FindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION + RADIO_BUTTON_SECTION)
	private WebElement bwMonthlyCreditCardRadioButtonSection;

	@FindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION + DUE_TODAY_SECTION)
	private WebElement bwMonthlyCreditCardDueTodaySection;

	@FindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION + NEXT_PAYMENT_SECTION)
	private WebElement bwMonthlyCreditCardNextPaymentSection;

	@FindBy(xpath = BW_MONTHLY_CREDIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION)
	private WebElement bwMonthlyCreditCardPaymentScheduleSection;

	// Monthly Auto Pay - Debit Card
	private static final String BW_MONTHLY_DEBIT_CARD_SECTION = "//div[contains(@class, 'EFTDDivClass')]";
	@FindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION)
	private WebElement bwMonthlyDebitCardOption;

	@FindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION + RADIO_BUTTON_SECTION)
	private WebElement bwMonthlyDebitCardRadioButtonSection;

	@FindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION + DUE_TODAY_SECTION)
	private WebElement bwMonthlyDebitCardDueTodaySection;

	@FindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION + NEXT_PAYMENT_SECTION)
	private WebElement bwMonthlyDebitCardNextPaymentSection;

	@FindBy(xpath = BW_MONTHLY_DEBIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION)
	private WebElement bwMonthlyDebitCardPaymentScheduleSection;

	//Monthly Billing
	private static final String BW_MONTHLY_BILLING_SECTION = "//div[contains(@class, 'NONDivClass')]";
	@FindBy(xpath = BW_MONTHLY_BILLING_SECTION)
	private WebElement bwMonthlyBillingOption;

	@FindBy(xpath = BW_MONTHLY_BILLING_SECTION + RADIO_BUTTON_SECTION)
	private WebElement bwMonthlyBillingRadioButtonSection;

	@FindBy(xpath = BW_MONTHLY_BILLING_SECTION + DUE_TODAY_SECTION)
	private WebElement bwMonthlyBillingDueTodaySection;

	@FindBy(xpath = BW_MONTHLY_BILLING_SECTION + NEXT_PAYMENT_SECTION)
	private WebElement bwMonthlyBillingNextPaymentSection;

	@FindBy(xpath = BW_MONTHLY_BILLING_SECTION + PAYMENT_SCHEDULE_SECTION)
	private WebElement bwMonthlyBillingPaymentScheduleSection;

	@FindBy(xpath = "//input[@value='Continue']")
	private WebElement continueButton;

	/**
	 * Constructor.
	 *
	 * @throws Exception 
	 */
	public PaymentPage() throws Exception {
		super();
		checkForKnockout("PaymentPage constructor");
		if (!isElementPresentByClass(errorMessageElement)) {
			waitElementBeVisible(selectPaymentDialogTitle);
		}
	}

	public void processPaymentPage(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		if (!isElementPresentByClass(errorMessageElement)) {
			boolean isBristolWestQuote = isBristolWestQuote();
			if (isElementPresentByID(continueToSignButton)) {
				clickElement(continueToSignButton);
				waitForPageToBeReady();
				waitForSpinnerToBeGone();
				waitAndClickElement(agreeToUseESign);
				waitAndClickElement(continueFromESign);			
				waitForPageToBeReady();
				waitForSpinnerToBeGone();
				waitAndClickElement(bwFinishDocReviewButton);
			} else {
				Log.warn("Got to payment page with payment plan: " + applicant.getPayment().getPaymentPlan(), true);
				verifyPaymentPlans(applicant.getStateCode(), isBristolWestQuote, fsa);
				selectPaymentPlan(applicant.getPayment(), isBristolWestQuote);
			}
		}
	}

	private void selectPaymentPlan(SqlPayment paymentObject, boolean isBristolWestQuote) {
		Log.warn("Select payment plan", true);
		if (isBristolWestQuote) {
			switch (paymentObject.getPaymentPlan()) {
			case "Pay in Full" :
				scrollAndClickOnElement(bwPayInFullRadioButtonSection);
				break;
			case "Monthly Automatic - Bank Account" :
				clickElement(bwMonthlyBankAccountRadioButtonSection);
				break;
			case "Monthly Automatic - Credit/Debit Card" :
				if (paymentObject.getPaymentMethod().equals("Credit Card")) {
					clickElement(bwMonthlyCreditCardRadioButtonSection);
				} else {
					clickElement(bwMonthlyDebitCardRadioButtonSection);
				}
				break;
			case "Monthly":
				clickElement(bwMonthlyBillingRadioButtonSection);
				break;
			default:
				throw new IllegalArgumentException("Invalid Payment Plan: <" + paymentObject.getPaymentPlan() + ">");				
			}
		} else {
			switch (paymentObject.getPaymentPlan()) {
			case "Pay in Full" :
				scrollAndClickOnElement(payInFullRadioButtonSection);
				break;
			case "Monthly Automatic - Bank Account" :
				clickElement(monthlyBankAccountRadioButtonSection);
				break;
			case "Monthly Automatic - Credit/Debit Card" :
				clickElement(monthlyCreditCardRadioButtonSection);				
				break;
			case "Monthly":
				clickElement(monthlyBillingRadioButtonSection);
				break;
			default:
				throw new IllegalArgumentException("Invalid Payment Plan: <" + paymentObject.getPaymentPlan() + ">");				
			}
		}
		scrollToElementBottom(continueButton);
		clickElement(continueButton);
	}

	private void verifyPaymentPlans(String stateCode, boolean isBristolWestQuote, FarmersSoftAssert fsa) {
		if (isBristolWestQuote) {
			fsa.assertTrue(getTextFromElement(selectPaymentDialogTitle).contains("How would you like to pay?"), "selectPaymentDialogTitle");	
			fsa.assertTrue(bwPayInFullRadioButtonSection.isDisplayed(), "PayInFull radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwPayInFullRadioButtonSection).contains("Payment in full"), "bwPayInFullRadioButtonSection");
			fsa.assertTrue(bwMonthlyBankAccountRadioButtonSection.isDisplayed(), "MonthlyAutoBankAcnt radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwMonthlyBankAccountRadioButtonSection).contains("Monthly payment (AutoPay) bank account"), "bwMonthlyBankAccountRadioButtonSection");
			fsa.assertTrue(bwMonthlyCreditCardRadioButtonSection.isDisplayed(), "MonthlyAutoCredit radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwMonthlyCreditCardRadioButtonSection).contains("Monthly payment (AutoPay) credit card"), "bwMonthlyCreditCardRadioButtonSection");
			fsa.assertTrue(bwMonthlyDebitCardRadioButtonSection.isDisplayed(), "MonthlyAutoDebit radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwMonthlyDebitCardRadioButtonSection).contains("Monthly payment (AutoPay) debit card"), "bwMonthlyBillingRadioButtonSection");
			fsa.assertTrue(bwMonthlyBillingRadioButtonSection.isDisplayed(), "Monthly radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwMonthlyBillingRadioButtonSection).contains("Monthly billing"), "bwMonthlyBillingRadioButtonSection");
		} else {		
			fsa.assertTrue(getTextFromElement(selectPaymentDialogTitle).contains("SELECT A PAYMENT PLAN"), "selectPaymentDialogTitle");	
			if (isEasternExpansionState(stateCode)) { // LA
				fsa.assertTrue(monthlyBankAccountRadioButtonSection.isDisplayed(), "MonthlyAutoBankAcnt radio button in pop-up window visible!");
				fsa.assertTrue(getTextFromElement(monthlyBankAccountRadioButtonSection).contains("Monthly automatic with bank account"), "monthlyBankAccountRadioButtonSection");
				fsa.assertTrue(monthlyDebitCardRadioButtonSection.isDisplayed(), "MonthlyAutoDebit radio button in pop-up window visible!");
				fsa.assertTrue(getTextFromElement(monthlyDebitCardRadioButtonSection).contains("Monthly automatic with debit card"), "bwMonthlyBillingRadioButtonSection");
				fsa.assertTrue(monthlyCreditCardRadioButtonSection.isDisplayed(), "MonthlyAutoCreditDebit radio button in pop-up window visible!");
				fsa.assertTrue(getTextFromElement(monthlyCreditCardRadioButtonSection).contains("Monthly automatic with credit card"), "monthlyCreditCardRadioButtonSection");
				fsa.assertTrue(payInFullRadioButtonSection.isDisplayed(), "PayInFull radio button in pop-up window visible!");
				fsa.assertTrue(getTextFromElement(payInFullRadioButtonSection).contains("Pay in full"), "payInFullRadioButtonSection");
			} else {
				if (!stateCode.equals(NJ)) {
					fsa.assertTrue(monthlyBankAccountRadioButtonSection.isDisplayed(), "MonthlyAutoBankAcnt radio button in pop-up window visible!");
					fsa.assertTrue(getTextFromElement(monthlyBankAccountRadioButtonSection).contains("Monthly payment (AutoPay) bank account"), "monthlyBankAccountRadioButtonSection");
				}
				fsa.assertTrue(monthlyCreditCardRadioButtonSection.isDisplayed(), "MonthlyAutoCreditDebit radio button in pop-up window visible!");
				if (isDebitListedFirstStates(stateCode)) {
					fsa.assertTrue(getTextFromElement(monthlyCreditCardRadioButtonSection).contains("Monthly payment (AutoPay) debit/credit card"), "monthlyCreditCardRadioButtonSection");
				} else {
					fsa.assertTrue(getTextFromElement(monthlyCreditCardRadioButtonSection).contains("Monthly payment (AutoPay) credit/debit card"), "monthlyCreditCardRadioButtonSection");				
				}
				if (!stateCode.equals(TN)) {
					fsa.assertTrue(payInFullRadioButtonSection.isDisplayed(), "PayInFull radio button in pop-up window visible!");
					fsa.assertTrue(getTextFromElement(payInFullRadioButtonSection).contains("Payment in full"), "payInFullRadioButtonSection");
				}
			}
		}
	}

	private boolean isDebitListedFirstStates(String stateCode) {
		List<String> debitListedFirstStates = new ArrayList<>(Arrays.asList(AL, CT, MT, ND, OR, SD, VA));
		return debitListedFirstStates.contains(stateCode);
	}
}
