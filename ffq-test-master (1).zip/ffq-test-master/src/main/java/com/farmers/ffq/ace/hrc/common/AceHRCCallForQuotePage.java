package com.farmers.ffq.ace.hrc.common;

import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class AceHRCCallForQuotePage extends AceHRCBasePage {

    @FindBy(xpath = "//div//h1")
    private WebElement pageTitle;

    private static final String TEXT_PAGE_TITLE = "Call for your quote";

    @FindBy(xpath = "//div[contains(@class,'aem-Grid aem-Grid--12 aem-Grid--default--12')]//div[@class='row justify-content-center']//p")
    private WebElement pageSubTitle;

//    private static final String TEXT_PAGE_SUBTITLE = "Speaking with one of our knowledgeable representatives is the best way to ensure " +
//            "you're getting all the auto and home insurance savings and discounts you're eligible for. Just call 844-855-8056.";

    @FindBy(xpath = "//div//h1/following-sibling::p/span[1]")
    private WebElement pageSubHeader;
    private static final String TEXT_PAGE_SUBHEADER = "Let's get started!";

    @FindBy(xpath = "//div//h1/following-sibling::p/span[2]")
    private WebElement pageSubHeader3;
    private static final String TEXT_PAGE_SUBHEADER_H3 = "If you'd like to continue your quote and see how much you could save, please give us a call.";

//    @FindBy(xpath = "//a[contains(@class, 'button-cta--desktop') and @data-gtm='Farmers_COLPGS_CallLink_Header']")
//    private WebElement buttonToCallDesktop;
//
//    @FindBy(xpath = "//a[contains(@class, 'button-cta--mobile') and @data-gtm='Farmers_COLPGS_CallLink_Header']")
//    private WebElement buttonToCallMobile;

    @FindBy(xpath = "//a[contains(@href,'tel:')]")
    private WebElement buttonToCall;

    private static final String CONTINUE_FARMERS_QUOTE_ONLINE_TEXT = "I'd rather quote with Farmers Insurance\u00ae online";
    @FindBy(linkText = CONTINUE_FARMERS_QUOTE_ONLINE_TEXT)
    private WebElement linkToContinueFarmersQuoteOnline;

    private static final String EXPECTED_AUTO_SAVINGS_TEXT = "Others have saved 23%* on average by switching their auto insurance";
    private static final String EXPECTED_BUNDLE_SAVINGS_TEXT = "By bundling policies, you could save even more";
    private static final String EXPECTED_WEALTH_DISCOUNT_TEXT = "Get special employee or association member discounts";

    private static final String AUTO_ICON_XPATH = "//img[contains(@data-src, '/Auto')]";
    @FindBy(xpath = AUTO_ICON_XPATH)
    private WebElement autoIcon;

    private static final String BUNDLE_ICON_XPATH = "//img[contains(@data-src, 'Home-and-Auto')]";
    @FindBy(xpath = BUNDLE_ICON_XPATH)
    private WebElement bundleIcon;

    private static final String DOLLAR_ICON_XPATH = "//img[contains(@data-src, 'Wealth')]";
    @FindBy(xpath = DOLLAR_ICON_XPATH)
    private WebElement dollarIcon;

    private static final String ICON_FOLLOWING_SIBLING_XPATH = "/following-sibling::section//p";
    @FindBy(xpath = AUTO_ICON_XPATH + ICON_FOLLOWING_SIBLING_XPATH)
    private WebElement autoSavingsText;

    @FindBy(xpath = BUNDLE_ICON_XPATH + ICON_FOLLOWING_SIBLING_XPATH)
    private WebElement bundleSavingsText;

    @FindBy(xpath = DOLLAR_ICON_XPATH + ICON_FOLLOWING_SIBLING_XPATH)
    private WebElement wealthDiscountText;

    private static final String XPATH_LOGO = "//img[@aria-label='Farmers Insurance Logo']";
    @FindBy(xpath = XPATH_LOGO)
    private WebElement farmersLogo;

    public static final String URBN_GROUP = "URBN";

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public AceHRCCallForQuotePage() throws Exception {
        super();
        waitElementBeVisible(buttonToCall);
    }

    public void validateCallForQuotePageElements(FarmersSoftAssert fsa, String groupName) throws Exception {
        // TODO: Remove commented lines, once the content is finalized for the Call For Quote page.
        waitForSpinnerToBeGone();
        fsa.assertEquals(getTextFromElement(pageTitle), TEXT_PAGE_TITLE, "Call For Quote page - Page Title");
//        fsa.assertEquals(getTextFromElement(pageSubTitle), TEXT_PAGE_SUBTITLE, "Call For Quote page - Page Subtitle");
        fsa.assertEquals(getTextFromElement(pageSubHeader), TEXT_PAGE_SUBHEADER, "Call For Quote page - Page Sub-Header");
        fsa.assertEquals(getTextFromElement(pageSubHeader3), TEXT_PAGE_SUBHEADER_H3, "Call For Quote page - Page Section Sub-Header h3");
//        fsa.assertTrue(isElementVisible(autoIcon, 5), "Call For Quote page - Auto Icon is displayed");
//        fsa.assertEquals(getTextFromElement(autoSavingsText), EXPECTED_AUTO_SAVINGS_TEXT, "Call For Quote page - Auto savings text is matched");
//        fsa.assertTrue(isElementDisplayed(bundleIcon, 5), "Call For Quote page - Bundle Icon is displayed");
//        fsa.assertEquals(getTextFromElement(bundleSavingsText), EXPECTED_BUNDLE_SAVINGS_TEXT, "Call For Quote page - Bundle savings text is matched");
//        fsa.assertTrue(isElementDisplayed(dollarIcon, 5), "Call For Quote page - Dollar Icon is displayed");
//        fsa.assertEquals(getTextFromElement(wealthDiscountText), EXPECTED_WEALTH_DISCOUNT_TEXT, "Call For Quote page - Wealth discount text is matched");
//        WebElement buttonToCall = isUseMobileViewEnabled()? buttonToCallDesktop : buttonToCallMobile;
        String btnToCall = getTextFromElement(buttonToCall);
        Log.info(" Button To Call Text >> " + btnToCall);
        fsa.assertTrue(btnToCall.startsWith("Call 8"), "Call For Quote page - Button To Call Text");
        if (groupName!= null && !groupName.isEmpty()) {
            fsa.assertTrue(isElementDisplayed(By.linkText(CONTINUE_FARMERS_QUOTE_ONLINE_TEXT)), "Call For Quote page - Link back to Farmers quote is displayed.");
        }
        fsa.assertTrue(isElementDisplayed(By.xpath(XPATH_LOGO)), "Call For Quote page - Farmers Insurance Logo is displayed");
    }

    public boolean isOnCallForQuotePage() throws Exception {
       return isElementVisible(linkToContinueFarmersQuoteOnline, 3);
    }

    public void goBackToFarmersQuote() {
        waitAndClickElement(linkToContinueFarmersQuoteOnline);
    }

    public void validateCallForQuote(ApplicantAceHome applicant, String group, FarmersSoftAssert fsa) throws Exception {
        if (!group.equals(URBN_GROUP)) {
            // Call For Quote page - FFQ Ace Integration
            Log.info("FWS Call for quote page, quote number: " + applicant.getQuoteNumber(), true);
            validateCallForQuotePageElements(fsa, group);
            navigateBack(); // US1071371 - Validate that clicking the browser Back button does NOT navigate away from the Call for Quote page.
            Assert.assertTrue(isOnCallForQuotePage(), "User is navigated away from Call For Quote page after clicking browser back button.");
            goBackToFarmersQuote();
        } else {
            // Farmers Insurance Choice page - FFQ Ace Integration
            AceHRCFarmersChoicePage farmersChoicePage = new AceHRCFarmersChoicePage();
            Log.info("Farmers Choice page, quote number: " + applicant.getQuoteNumber(), true);
            farmersChoicePage.verifyPageElements("urbn-logo", fsa);
        }
    }
}
