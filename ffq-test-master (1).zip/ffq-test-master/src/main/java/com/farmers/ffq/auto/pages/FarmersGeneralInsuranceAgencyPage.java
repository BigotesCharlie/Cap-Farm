package com.farmers.ffq.auto.pages;

import com.farmers.framework.report.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.farmers.ffq.utils.FarmersSoftAssert;

import java.util.List;

public class FarmersGeneralInsuranceAgencyPage extends AutoBasePage {

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public FarmersGeneralInsuranceAgencyPage() throws Exception {
    }

    @FindAll({
            @FindBy(xpath = "//div[contains(@class,'fgia-page-container')]/h1"),
            @FindBy(id = "heading-rebrand")
    })
    private WebElement fgiaPromptPageHeader;

    @FindAll({
            @FindBy(xpath = "//div[contains(@class,'fgia-page-container')]/div/div/p"),
            @FindBy(css = "h2[class='tui-h2 mt-10']")
    })
    private WebElement fgiaPromptPageSubHeader;

    @FindAll({
            @FindBy(xpath = "//button/span[contains(text(),'Continue to FGIA')]"),
            @FindBy(xpath = "//div[contains(@class,'fgia-rebrand-cta-section')]//button")
    })
   private WebElement fgiaPromptPageContinueButton;

    @FindBy(xpath = "*//button[contains(text(),'No, thanks')]")
    private WebElement fgiaPromptPageNoThanksButton;

    @FindBy(xpath = "//h1/span[contains(text(),'Welcome to the Farmers General')]")
    private WebElement pageHeaderText;

    @FindBy(xpath = "//h2/span[contains(text(),'What insurance')]")
    private WebElement pageSubHeaderText_1;

    @FindBy(xpath = "//fieldset[@id='in_insurance_type']/legend/h3")
    private WebElement pageSubHeaderText_2;

    @FindBy(xpath = "//div[@class=' s12 10m l7 clm center']/ul/li[1]")
    private WebElement autoLOBCard;

    @FindBy(xpath = "//div[@class=' s12 10m l7 clm center']/ul/li[2]")
    private WebElement homeOwnersLOBCard;

    @FindBy(xpath = "//div[@class=' s12 10m l7 clm center']/ul/li[3]")
    private WebElement rentersLOBCard;

    @FindBy(xpath = "//a[@class='personal-info-farmers']/div")
    private WebElement personalInfromationUseLink;

    @FindBy(xpath = "//button[contains(text(),'Tell us about yourself')]")
    private WebElement continueButton;

    @FindBy(xpath = "//button[contains(@aria-label,'Try That Again')]")
    private List<WebElement> fgiaTryAgain;

    @FindBy(xpath = "//button[@class='button medium action fill primary-btn next-step next']")
    private WebElement fgiaTellUsAboutYourselfButton;

    @FindBy(xpath = "//div[@id='container_in_alt_address']//div//span//span[2]")
    private WebElement fgiaZipCode;


    public static final String FGIA_PROMPT_PAGE_HEADER = "Continue your quote request with Farmers General Insurance Agency, Inc.";
    public static final String FGIA_PROMPT_PAGE_HEADER_2 = "Continue your quote with Farmers General Insurance Agency, Inc.";

    public static final String FGIA_PROMPT_PAGE_SUB_HEADER = "We are unable to offer you an online quote for a Farmers-branded policy at this time. However, Farmers General Insurance Agency, Inc. (FGIA) may be able to offer you a quote through other companies.";

    private static final String PAGE_TITLE = "Farmers Insurance Choice | Enter ZIP Code";
    private static final String PAGE_HEADER_TEXT = "Welcome to the Farmers General Insurance Agency quoting tool. Answer a few quick questions about yourself and we'll share customized quotes that can help you find the coverage you want -- and may save you money too. Let's get started! ";
    private static final String PAGE_SUB_HEADER_TEXT_1 = "What insurance do you need today?";
    private static final String PAGE_SUB_HEADER_TEXT_2 = "Looking for more than one policy? Select exactly what you need, even if it's more than one.";

    public void validateFGIAPromptPage(FarmersSoftAssert fsa, boolean continueToFGIA, String zipCode) throws Exception {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(fgiaPromptPageHeader)), "It's not you. It's us.", this.getClass().getSimpleName() + " Page header validation");
        fsa.assertEquals(getTextFromElement(fgiaPromptPageSubHeader), "You're still on your way to new coverage.", this.getClass().getSimpleName() + " Page subheader validation");
        fsa.assertTrue(fgiaPromptPageContinueButton.isEnabled() && fgiaPromptPageContinueButton.isDisplayed(), "Continue to FGIA  button is displayed and enabled");
        testStep("FGIA prompt page validation", true);
        // Click on Continue to land on FGIA Page
        if (continueToFGIA) {
            waitAndClickElement(fgiaPromptPageContinueButton);
            sleep(3);
            if(!fgiaTryAgain.isEmpty()) {
                waitAndClickElement(fgiaTryAgain.get(0));
            }
            wait.until(ExpectedConditions.titleContains("Farmers General Insurance Agency, Inc. | Select insurance type"));
            fsa.assertTrue(driver().getCurrentUrl().contains(String.format("zipcode=%s", zipCode )), "Zipcode in the url is matching");
            waitAndClickElement(fgiaTellUsAboutYourselfButton);
            fsa.assertTrue(isElementPresent(By.xpath(String.format("//span[@class='text-right zip-text h4']//span[contains(.,'%s')]", zipCode)),5), "Zip code on the page is matching");
            testStep("FGIA page title validated", true);
        }
    }

}
