package com.farmers.ffq.common.pages;

import com.farmers.framework.Property;
import com.farmers.framework.report.Reporter;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.SkipException;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class ForemostStartPage extends BasePage {
    /**
     * Constructor.
     *
     * @throws Exception if driver() call fails
     */
    public ForemostStartPage() throws Exception {
    }

    public boolean isOnForemostStartPage() {
        return isElementPresent(By.className("navbar-header"), 10);
    }

    @FindBy (xpath = "//a[contains(@href, '/insurance')][@class]")
    private WebElement seeAllOurProductsButtonElement;

    private static final String LINK_TO_PRODUCT_XPATH = "//a[@href='/insurance/%s/']";

    @FindBy (id = "zip")
    private WebElement zipCodeInputField;

    @FindBy (xpath = "//input[contains(@class,'mdc-checkbox')]")
    private WebElement shortTermRentalCheckbox;

    @FindBy (xpath  = "//input[@data-gtm='Get a Quote'] | //a[contains(., 'Get a quote')]")
    private WebElement getAQuoteButton;

    public void processForemostStartPage(String zipcode, String lob) throws Exception {
        String urlForemost = Property.getEnvironmentProperty("foremost_url");
        if (urlForemost==null || urlForemost.isBlank()) {
        	throw new SkipException ("Foremost site definition not found for " + Property.getTestProperty("environment"));
        }
        if (isUseMobileViewEnabled()) {
            setBrowserDimensionToMobileBreakPoint();
        } else {
            maximizeTheBrowser();
        }
        driver().navigate().to(urlForemost);
        Assert.assertTrue(isOnForemostStartPage(), "Did not reach Foremost launch page.");
        scrollAndClickOnElement(seeAllOurProductsButtonElement);
        String product;
        switch (lob) {
        	case MOBILE_HOME:
        		product = "mobile-home";
        		break;
			case RENT:
			case SHORTRENT_DWELLING:
				product = "landlord-and-rental-home";
				break;
			case PARTTIME:
			case SECONDARY:
				product = "seasonal-home";
				break;
			case UNOCCUPIED:
				product = "vacant-home";
				break;
			case RENTERS:
				product = "renters-insurance";
				break;
			default:
				product = lob;
				break;
        }
        scrollAndClickOnElement(driver().findElement(By.xpath(String.format(LINK_TO_PRODUCT_XPATH, product))));
        if (!isElementPresent(By.id("zip"), 10)) {
        	throw new SkipException (String.format("Foremost %s page not reached", product));
        }
        sendKeysToElement(zipCodeInputField, zipcode);
        if (lob.equals(SHORTRENT_DWELLING)) {
        	clickElement(shortTermRentalCheckbox);
        }
        Reporter.pass(String.format("Starting a %s quote from %s", product, urlForemost));
        scrollToElement(getAQuoteButton);
        switchToNewWindow(getAQuoteButton);
		waitForSpinnerToBeGone();
		acceptCookies();
    }
}
