package com.farmers.ffq.hqm.pages;

import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.QuoteRateHQM;
import com.farmers.ffq.datatransferobjects.hqm.StaticContentHQM;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import javax.annotation.Nullable;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.Year;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.urlContains;
import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOf;

/**
 * Farmers Fast Quote (FFQ) - Quote Page - Home Quote Modernization (HQM).
 */

public class QuotePage extends HqmBasePage {

    private static final String QUOTE_PAGE_TITLE = "AND HERE IS\nYOUR QUOTE";
    private static final String QUOTE_PAGE_SUBTITLE = "Based on your estimated reconstruction cost of";
    @FindBy(xpath = "//mat-card[contains(@class,'mat-card')]")
    private WebElement quoteCard;

    @FindBy(xpath = "//mat-card[contains(@class,'mat-card')]//h2")
    private WebElement titleQuoteType;

    @FindBy(xpath = "//mat-card[contains(@class,'mat-card')]//div[@id='monthlyPremium']")
    private WebElement textQuotePricePerMonth;

    @FindBy(xpath = "//mat-card[contains(@class,'mat-card')]//span[@class='cost-size']/../span[contains(@class,'sub-title-one')]")
    private WebElement textQuotePricePerMonthCents;

    @FindBy(xpath = "//mat-card[contains(@class,'mat-card')]//span[contains(@class,'overline')]")
    private WebElement textQuotePricePerYear;

    @FindBy(xpath = "//mat-card[contains(@class,'mat-card')]//div[@id='yearlyPremium']")
    private WebElement textQuotePricePerYearCA;

    private static final String BUTTON_QUOTE_DETAILS_XPATH = "//button[@id='adjustView']";
    @FindBy(xpath = BUTTON_QUOTE_DETAILS_XPATH)
    private WebElement btnQuoteDetails;

    @FindBy(xpath = "//mat-dialog-container[@aria-modal='true']")
    private WebElement quoteDetailsDialog;

    @FindBy(xpath = "//farmers-home-quote-details-dialog//mat-icon[contains(text(),'close')]")
    private WebElement btnCloseModal;

    @FindBy(xpath = "//farmers-home-quote-details-dialog//button[contains(.,'RECALCULATE')]")
    private WebElement btnRecalculate;

    @FindBy(xpath = "//farmers-home-quote-details-dialog//button[contains(text(),'RESET')]")
    private WebElement btnReset;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Dwelling')]" +
            "/../../div[contains(@class,'mat-slider')]//span[@class='mat-slider-thumb-label-text']")
    private WebElement textSliderDwelling;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Dwelling')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderDwelling;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Extended Replacement Cost')]" +
            "/../../div[contains(@class,'mat-slider')]//span[@class='mat-slider-thumb-label-text']")
    private WebElement textSliderExtendedReplacement;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Extended Replacement Cost')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderExtendedReplacement;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Property')]" +
            "/../../div[contains(@class,'mat-slider')]//span[@class='mat-slider-thumb-label-text']")
    private WebElement textSliderPersonalProperty;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Property')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderPersonalProperty;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'All Peril')]" +
            "/../../div[contains(@class,'mat-slider')]//span[@class='mat-slider-thumb-label-text']")
    private WebElement textSliderAllPeril;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'All Peril')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderAllPeril;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Wind & Hail')]" +
            "/../../div[contains(@class,'mat-slider')]//span[@class='mat-slider-thumb-label-text']")
    private WebElement textSliderWindAndHail;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Wind & Hail')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderWindAndHail;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Hurricane')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderHurricane;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Liability')]" +
            "/../../div[contains(@class,'mat-slider')]//span[@class='mat-slider-thumb-label-text']")
    private WebElement textSliderPersonalLiability;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Personal Liability')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderPersonalLiability;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Medical Payments to Others')]" +
            "/../../div[contains(@class,'mat-slider')]//span[@class='mat-slider-thumb-label-text']")
    private WebElement textSliderMedicalPaymentsToOthers;

    @FindBy(xpath = "//div[@class='coverage-content']/h5[contains(text(),'Medical Payments to Others')]" +
            "/../../div[contains(@class,'mat-slider')]")
    private WebElement sliderMedicalPaymentsToOthers;

    @FindBy(xpath = "//farmers-home-quote-details-dialog//span[contains(@class,'overline')]")
    private WebElement popupYearlyPremium;

    @FindBy(xpath = "//farmers-home-quote-details-dialog//div[contains(@class,'cost-block')]")
    private WebElement popupMonthlyPremium;

    @FindBy(xpath = "//farmers-home-quote-details-dialog//h2[contains(@class,'header-title')]")
    private WebElement popupTitle;

    private final By textAppliedDiscounts = By.xpath("//farmers-home-quote//mat-card//p[contains(@class,'quote-step-caption')]/span[not(@aria-hidden)]");

    @FindBy(xpath = "//farmers-home-quote//h1")
    private WebElement textPageTitle;

    @FindBy(xpath = "//farmers-home-quote//span[@class='tui-subtitle-text-1']")
    private WebElement textPageSubTitle;

    @FindBy(xpath = "//farmers-home-quote//span[@class='tui-subtitle-text-1']/strong")
    private WebElement textReconstructionCost;

    @FindBy(xpath = "//farmers-home-quote//farmers-home-quote-discount-journey//img[contains(@class,'discount-journey-card__potential')]/..")
    private WebElement discountSubTitlePiggy;

    private static final String TEXT_DISCOUNT_PIGGY = " potential savings/discounts - subject to validation and eligibility requirements. View discounts";

    private static final String VIEW_DISCOUNTS_XPATH = "//farmers-home-quote//div[@class='discount-journey-card']//a[contains(@class,'view-discounts')]";
    @FindBy(xpath = VIEW_DISCOUNTS_XPATH)
    private WebElement linkViewDiscounts;

    private static final String STANDARD_QUOTE_TEXT = "An affordable home coverage package that includes fundamental coverage " +
            "levels that can be customized to provide additional protection for things that matter most.";

    private static  final String ROOF_PAYMENT_TEXT = "Quote includes scheduled roof payment. Replacement cost may be available by contacting an agent.";

    private static final String STANDARD_CUSTOM_QUOTE_TEXT = "Your standard custom package with the options you selected.";

    private static final String DISCLAIMERS_XPATH = "//farmers-home-quote//p[@id='disclaimerText']/../p";
    private final List<String> footersQuotePage = Arrays.asList("* Based on paying premium automatically. Service fees and fees " +
            "permitted by state law are not shown. Amounts and service fees differ based on pay plan and automatic payment " +
            "selection. The premium shown may include a Preferred Payment discount. This discount is only available on a " +
            "monthly basis, if you choose the monthly mortgage pay plan.\n\n",
            "* Based on paying premium automatically. Service fees and fees permitted by state law are not shown. Amounts " +
            "and service fees differ based on pay plan and automatic payment selection.\n\n",
            "This is a preliminary rate (\"quote\") for the insurance you selected. This quote is not a policy of insurance " +
            "or application, offer to insure or binder. Certain assumptions may have been made and this quote reflects rates " +
            "in effect the day of the quote and are subject to change. Premium may vary based on additional information, " +
            "coverages and deductibles that you select, underwriting criteria, and any changes to assumptions. Farmers " +
            "reserves the right to accept, reject, or modify this quote after review of an application and other underwriting " +
            "information. Applications are subject to underwriting approval. Farmers online home quotes are available for new " +
            "customers.");

    private static final String QUOTE_PAGE_FOOTER_CT = "* Price includes a $12.00 CT Healthy Home Surcharge.\n\n";

    private static final String QUOTE_PAGE_FOOTER_KY1 = "Unless you waive in writing, we are required to provide you with mine subsidence " +
            "coverage when you purchase a homeowners insurance policy if your structure is located in one of the following " +
            "counties: Bell, Boyd, Breathitt, Butler, Carter, Christian, Clay, Daviess, Edmonson, Elliott, Floyd, Greenup, " +
            "Hancock, Harlan, Henderson, Hopkins, Jackson, Johnson, Knott, Knox, Laurel, Lawrence, Lee, Leslie, Letcher, " +
            "Martin, McCreary, McLean, Morgan, Muhlenberg, Ohio, Owsley, Perry, Union, Webster, Whitley and Wolfe.\n\n";

    private static final String QUOTE_PAGE_FOOTER_KY2 = "* Based on paying premium automatically. Service fees and fees permitted by " +
            "state law are not shown. Amounts and service fees differ based on pay plan and automatic payment selection. " +
            "Additional taxes and fees may apply.\n\n";

    private static final String QUOTE_PAGE_FOOTER_KY3 = "This is a preliminary rate (\"quote\") for the insurance you selected. This " +
            "quote is not a policy of insurance or application, offer to insure or binder. Certain assumptions may have " +
            "been made and this quote reflects rates in effect the day of the quote and are subject to change. Premium may " +
            "vary based on additional information, coverages and deductibles that you select, underwriting criteria, and " +
            "any changes to assumptions. In order to purchase a policy, information about your spouse may be necessary. " +
            "Farmers reserves the right to accept, reject, or modify this quote after review of an application and other " +
            "underwriting information. Applications are subject to underwriting approval. Farmers online home quotes are " +
            "available for new customers.";

    private static final String QUOTE_PAGE_FOOTER_MALA = "* Based on paying premium automatically from a bank account. Service fees " +
            "and fees permitted by state law are not shown. Amounts and service fees differ based on pay plan and automatic " +
            "payment selection. Additional taxes and fees may apply.\n\n";

    private static final String QUOTE_PAGE_FOOTER_LA = "Do you qualify for a discount? Louisiana Law requires insurers to provide " +
            "a discount for insureds who build or retrofit a structure to comply with the State Uniform Construction Code " +
            "and/or install mitigation improvements or retrofit their property using construction techniques demonstrated to " +
            "reduce the amount of loss from a windstorm or hurricane. If you have made these improvements and believe that " +
            "your home qualifies for this discount, please talk to one of our Customer Representatives to find out more.\n\n";

    private static final String QUOTE_PAGE_FOOTER_TX = "* Price includes FAIR Plan Assessment Recoupment.\n\n";

    private static final String QUOTE_PAGE_FOOTER_NE = "* The amount shown applies when premium is paid automatically on a monthly basis. " +
            "Monthly payment amount may be different if payments are not made automatically. The amount shown does not include monthly " +
            "service fees. Amounts charged for service fees also differ based on billing and pay plan selections. Please see your Farmers " +
            "agent for details.\n\n";

    private List<String> policyPerksDisclaimerList = Arrays.asList("POLICY PERKS\u2120 ARE NOT AVAILABLE IN EVERY STATE.\n\n" +
            "POLICY PERKS ARE AVAILABLE WITH SELECT FARMERS\u00ae BRANDED POLICIES. NOT AVAILABLE WITH ALL FARMERS BRANDED POLICIES. " +
            "CERTAIN POLICY PERKS ARE OPTIONAL COVERAGES AVAILABLE AT ADDITIONAL COST. Subject to terms and conditions. Underwritten " +
            "by Farmers, Truck or Fire Insurance Exchanges or affiliated insurer. Products not available in every state.",
            "DECLINING DEDUCTIBLES\u00ae IS NOT AVAILABLE IN CA & FL.\n\n" +
            "DECLINING DEDUCTIBLES IS AVAILABLE WITH FARMERS\u00ae BRANDED SMART PLAN HOMEOWNERS POLICIES. NOT AVAILABLE WITH ALL FARMERS " +
            "BRANDED POLICIES. Subject to terms and conditions. Underwritten by Farmers, Truck or Fire Insurance Exchanges or affiliated " +
            "insurer. Products not available in every state.",
            "CLAIM FORGIVENESS IS AVAILABLE WITH FARMERS\u00ae BRANDED SMART PLAN HOMEOWNERS POLICIES. NOT AVAILABLE WITH ALL FARMERS " +
            "BRANDED POLICIES. Subject to terms, conditions, and eligibility requirements. Underwritten by Farmers, Truck or Fire " +
            "Insurance Exchanges or affiliated insurer. Products not available in every state.",
            "CLAIM FREE DISCOUNT IS NOT AVAILABLE IN OK. IN FL, 5 CONSECUTIVE YEARS IS REQUIRED TO RECEIVE THE CLAIM FREE DISCOUNT.\n\n" +
            "CLAIM FREE DISCOUNT IS AVAILABLE WITH FARMERS\u00ae BRANDED SMART PLAN HOMEOWNERS POLICIES. NOT AVAILABLE WITH ALL FARMERS " +
            "BRANDED POLICIES. Subject to terms, conditions, and eligibility requirements. Underwritten by Farmers, Truck or Fire " +
            "Insurance Exchanges or affiliated insurer. Products not available in every state.");

    @FindBy(xpath = "//farmers-home-quote//mat-card-content//p[@class='tui-subtitle-text-1']")
    private WebElement textQuoteTypeSubtitle;

    @FindBy(xpath = "//farmers-home-quote//mat-card-content//p[@role='note']")
    private WebElement textQuoteNoteSubtitle;

    @FindBy(xpath = "//farmers-home-quote//button[@id='emailIcon']")
    private WebElement btnEmail;

    private final By btnEmailIcon = By.xpath("//farmers-home-quote//button[@id='emailIcon']//mat-icon");

    @FindBy(xpath = "//farmers-home-quote-email-dialog//h2[contains(@class,'mat-dialog-title')]")
    private WebElement emailDialogTitle;

    @FindBy(xpath = "//farmers-home-quote-email-dialog//mat-dialog-content/p[@class='sub-title-one']")
    private WebElement emailDialogContent;

    @FindBy(xpath = "//farmers-home-quote-email-dialog//mat-dialog-actions/button[.='OK']")
    private WebElement emailDialogBtnOK;

    @FindBy(xpath = "//farmers-home-quote//div[a[starts-with(@href,'tel:1-8')]]")
    private WebElement textContactUs;

    private static final String CONTACT_US_STR = "For any questions, contact us at %s";

    private static final String PRINT_ICON_XPATH = "//farmers-home-quote//button[@id='printIcon']";
    @FindBy(xpath = PRINT_ICON_XPATH)
    private WebElement btnPrint;

    @FindBy(xpath = "//mat-drawer[contains(@class,'mat-drawer-side')]//a[contains(@href,'&Flow=RS')]")
    private WebElement autoLobLink;

    private static final String totalDiscAmtXpath = "//farmers-home-quote//div[h4[@id='hqm-applied-discounts']]//div[contains(@class,'total-disc-amt')]";
    @FindBy(xpath = totalDiscAmtXpath)
    private WebElement totalDiscAmt;

    private static final String TOTAL_SAVINGS_TEXT = "Your policy premium includes a Total Discount Savings of";

    private static final String CROSSSELL_LIFE_XPATH = "//mat-drawer[contains(@class,'mat-drawer-side')]//a[contains(@href,'&flow=CS')]";

    @FindBy(xpath = "//farmers-home-quote-policy-perks//div[contains(@class,'perk-title')]/img")
    private WebElement policyPerksTitle;

    private static final String POLICY_PERKS_HEADER_TEXT =  "Purchase a policy with Farmers\u00ae and you can unlock discounts, save money, " +
          "and get policy benefits \u2014 all with Farmers Policy Perks SM. Learn moreopen_in_new";

    @FindBy(xpath = "//farmers-home-quote-policy-perks//p[contains(@class,'tui-text-prominent')]")
    private WebElement policyPerksHeader;

    @FindBy(xpath = "//farmers-home-quote-policy-perks//p[contains(@class,'tui-text-prominent')]//a[starts-with(@href,'https://www.farmers.com/policy-perks/')]")
    private WebElement policyPerksHeaderLink;

    private static final String POLICY_PERKS_PARAGRAPH_HEADER_XPATH = "//farmers-home-quote-policy-perks//div[contains(@class,'tui-subtitle-text-2')]";
    private static final String POLICY_PERKS_PARAGRAPH_CONTENT_XPATH = "//farmers-home-quote-policy-perks//div[contains(@class,'tui-text-prominent')]";

    private List<String> textPerksHeaders = Stream.of("Declining Deductibles\u00ae", "Claim Forgiveness", "Claim Free Discount").collect(Collectors.toList());

    private List<String> textPerksContents = Stream.of("Earn $50 toward your home deductible each year your home policy remains in force.",
            "We won\u2019t raise your premium because of a claim, once you\u2019ve gone claim-free with Farmers for five years.",
            "You will receive a discount on your Home insurance if you\u2019ve been claim-free for three years.").collect(Collectors.toList());

    private static final String IMAGE_FLO_XPATH = "//div[contains(@class,'waterLeakProtectionDiv')]//img[contains(@class,'waterLeakProtectionNoneImg')]";
    @FindBy(xpath = IMAGE_FLO_XPATH)
    private WebElement imageFloByMoen;

    private static final String TEXT_FLO_BY_MOEN_XPATH = "//div[contains(@class,'waterLeakProtectionDiv')]/span[contains(@class,'Its-as-easy-as-enro')]";
    @FindBy(xpath = TEXT_FLO_BY_MOEN_XPATH)
    private WebElement textFloByMoen;

    private static final String FLO_BY_MOEN_TEXT = "A water leak detection device like Flo could save you money on your homeowners " +
            "insurance. Talk to a Farmers representative or click Learn More for more information.";

    private static final String LINK_FLO_BY_MOEN_XPATH = "//div[contains(@class,'waterLeakProtectionDiv')]/span[contains(@class," +
            "'Its-as-easy-as-enro')]/a[@href='https://partner.meetflo.com/farmers/']";
    @FindBy(xpath = LINK_FLO_BY_MOEN_XPATH)
    private WebElement linkFloByMoen;

    @FindBy(xpath = "//div[contains(@class,'waterLeakProtectionDiv')]/div/a[starts-with(@href,'tel:1-8')]")
    private WebElement contactUsFloByMoen;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public QuotePage() throws Exception {
        super();
        try {
            wait.until(ExpectedConditions.or(visibilityOf(btnQuoteDetails),urlContains("knockout"),urlContains("maintenance")));
            if (!driver().getCurrentUrl().contains("quote")) {
                throw new NotFoundException("Quote Summary page was not displayed within expected time.");
            }
        } catch (StaleElementReferenceException e) {
            sleep (1);
            wait.until(ExpectedConditions.or(visibilityOf(btnQuoteDetails),urlContains("knockout"),urlContains("maintenance")));
            if (!driver().getCurrentUrl().contains("quote")) {
                throw new NotFoundException("Quote Summary page was not displayed within expected time.");
            }
        } finally {
            try {
                driver().findElement(By.xpath(SURVEY_POPUP_XPATH));
                waitAndClickElement(closeSurveyButton);
            } catch (NoSuchElementException ignored) {}
        }
    }

    private static final String SURVEY_POPUP_XPATH = "//div[contains(@class,'PopOverContainer')]//img[contains(@src,'svg-close-btn-black')]";
    @FindBy(xpath = SURVEY_POPUP_XPATH)
    private WebElement closeSurveyButton;

    public String getQuoteType() {
        return getTextFromElement(titleQuoteType);
    }

    public String getQuotePremiumMonthly() {
        String text = getAttributeData(textQuotePricePerMonth, "textContent");
        Log.info("Quote Premium Monthly: " + text);
        return text.split("/")[0].trim();
    }

    public String getQuotePremiumYearly(String stateCode) {
        String text;
        if (!isHqmDigitalMonetizationState(stateCode)) {
            text = getTextFromElement(textQuotePricePerYear);
        } else {
            text = getTextFromElement(textQuotePricePerYearCA);
        }
        Log.info("Quote Premium Yearly: " + text);
        return text.split("/")[0].replace(SPACE,"").replace("\n","");
    }

    public void clickQuoteDetails() {
        waitAndClickElement(btnQuoteDetails);
    }

    public List<String> getDiscounts() throws Exception {
        List<String> listPageDiscounts = driver().findElements(textAppliedDiscounts).stream().map(this::getTextFromElement)
                .collect(Collectors.toList());
        Log.info("Found Quote page Applied discounts: " + listPageDiscounts);
        return listPageDiscounts;
    }

    public String getTotalDiscAmt() {
        String discAmt = "";
        waitElementBeVisibleClickable(totalDiscAmt);
        discAmt = getTextFromElement(totalDiscAmt).replace(TOTAL_SAVINGS_TEXT,"");
        return discAmt;
    }

    public void validateQuoteDiscounts(ApplicantHQM applicant, FarmersSoftAssert fsa, QuoteRateHQM quoteRate) throws Exception {
        List<String> appliedDiscounts = this.getDiscounts();
        List<String> preDiscounts = new ArrayList<>();
        if (applicant.centralBurglarAlarm) {
            preDiscounts.add("central burglar alarm");
        }
        if (applicant.centralFireAlarm) {
            preDiscounts.add("central fire alarm");
        }
        if (applicant.theftAlarm) {
            preDiscounts.add("theft protection");
        }
        if (applicant.fireAlarm) {
            preDiscounts.add("fire protection");
        }
        if (applicant.waterShutoff) {
            preDiscounts.add("water protection");
        }
        if (applicant.fortifiedHome) {
            if (applicant.stateCode.equals(KY) || isFlexState(applicant.stateCode)) {
                preDiscounts.add("fortified home");
            } else if (applicant.stateCode.equals(MS)) {
                preDiscounts.add("windstorm mitigation");
            }
        }
        if (applicant.ceaCoverage) {
            preDiscounts.add("home cea");
        }
        if (applicant.adtSecurity) {
            preDiscounts.add("home protection and loss prevention");
        }
        if (applicant.lifeInsurance) {
            preDiscounts.add("farmers life customer");
        }
        if (applicant.autoInsurance) {
            preDiscounts.add("farmers auto customer");
        }
        if (applicant.commercial) {
            preDiscounts.add("farmers commercial customer");
        }
        if (applicant.boatWaterCraft) {
            preDiscounts.add("recreational boat/watercraft insurance");
        }
        if (applicant.offRoad) {
            preDiscounts.add("off-road vehicle insurance");
        }
        if (applicant.motorHome) {
            preDiscounts.add("motorhome, travel trailer or 5th wheel insurance");
        }
        Year currentYear = Year.now();
        if (currentYear.minusYears(applicant.yearBuilt).getValue() < 14 && !applicant.stateCode.equals(MN) && !isFlexState(applicant.stateCode)) {
        	preDiscounts.add("New Home");
        }
        if (!applicant.centralAlarm.isEmpty() || !applicant.directAlarm.isEmpty() || !applicant.localAlarm.isEmpty() ||
            !applicant.autoSmokeDetectors.isEmpty() || !applicant.autoSprinklerSystem.isEmpty()) {
            preDiscounts.add("protective device");
        }
        if (isEarlyShoppingFactorState(applicant.stateCode) && !applicant.earlyShoppingFactor.isBlank()) {
            if (applicant.earlyShoppingFactor.equalsIgnoreCase(TRUE)) {
                preDiscounts.add("Early Shopping");
            } else if (LocalDate.parse(applicant.earlyShoppingFactor, DateTimeFormatter.ofPattern(MM_DD_YYYY))
                        .isAfter(LocalDate.now().plusDays(6))) {
                    preDiscounts.add("Early Shopping");
            }
        }
        if (isFlexState(applicant.stateCode)) {
            if (!applicant.stateCode.equals(CA)) {
                preDiscounts.add("Good Payer");
            }
            if (applicant.newlyOwned) {
                preDiscounts.add("Home Buyer");
            }
        }
        appliedDiscounts = appliedDiscounts.stream().map(String::toLowerCase)
                .sorted(Comparator.naturalOrder()).collect(Collectors.toList());
        preDiscounts = preDiscounts.stream().map(String::toLowerCase)
                .sorted(Comparator.naturalOrder()).collect(Collectors.toList());
        Log.info("Pre-applied discounts: " + preDiscounts);
        Log.info("Applied discounts: " + appliedDiscounts);
        fsa.assertTrue(new HashSet<>(appliedDiscounts).containsAll(preDiscounts), "Validate Quote page - pre-selected discounts are displayed");

        List<String> discounts;
        if (quoteRate != null) {
            discounts = quoteRate.getAppliedDiscounts();
            Log.info("Applied discounts from Postgres: " + discounts);
            if (isFlexState(applicant.stateCode)) {
                int ind = discounts.indexOf("preferred payment");
                if (ind > 0) {
                    discounts.set(ind, "preferred payment plan");
                }
                ind = discounts.indexOf("welcome discount");
                if (ind > 0 ) {
                    discounts.set(discounts.indexOf("welcome discount"), "welcome");
                }
            }
            // removing non-HQM (Ace Home-related) discounts from API response
            discounts.remove("electrical system replacement");
            discounts.remove("plumbing system replacement");
            //
            fsa.assertEquals(appliedDiscounts, discounts, "Validate Quote page - All Postgres getQuoteRate API discounts are displayed");
            if (isElementDisplayed(By.xpath(totalDiscAmtXpath))) {
                fsa.assertEquals(this.getTotalDiscAmt(), "$" + quoteRate.getTotalDiscAmt(), "Quote page - Total Discount Amount verified");
            }
        } else {  // in case there is no Postgres connection
            discounts = new ArrayList<>(preDiscounts);
            if (!Arrays.asList(KY,CA,NC).contains(applicant.stateCode)) {
                discounts.add("paperless");
            }
            discounts.add("claim free");
            if (!applicant.stateCode.equals(CA)) {
                discounts.add("good payer");
                discounts.add("preferred payment");
            }
            fsa.assertTrue(new HashSet<>(appliedDiscounts).containsAll(discounts), "Validate Quote page - Contains all expected discounts displayed. (no Postgres connection)");
        }
    }

    public void validatePageTitles(QuoteRateHQM quoteRate, FarmersSoftAssert fsa, @Nullable StaticContentHQM staticContent) {
        fsa.assertEquals(getTextFromElement(textPageTitle), QUOTE_PAGE_TITLE, "Quote page - page Title h1");
        if (quoteRate != null) {
            fsa.assertEquals(getTextFromElement(textPageSubTitle), QUOTE_PAGE_SUBTITLE + " $" +
                    String.format("%,.0f", Double.parseDouble(quoteRate.getReconstructionCost())), "Quote page - page SubTitle1");
        } else {
            fsa.assertTrue(getTextFromElement(textPageSubTitle).startsWith(QUOTE_PAGE_SUBTITLE + " $"),
                    "Quote page - page SubTitle");
        }
        if (staticContent != null) {
            fsa.assertEquals(staticContent.getQuoteTitle(), QUOTE_PAGE_TITLE, "Quote page - page Title h1 (AEM).");
            if (quoteRate != null) {
                fsa.assertEquals(staticContent.getQuoteCaption(), QUOTE_PAGE_SUBTITLE, "Quote page - page SubTitle1 (AEM).");
            } else {
                fsa.assertTrue(staticContent.getQuoteCaption().startsWith(QUOTE_PAGE_SUBTITLE),
                        "Quote page - page SubTitle (AEM).");
            }
        }
    }

    public void validateSubtitlesDiscountJourney(FarmersSoftAssert fsa) throws Exception {
        List<String> discountsAvailable = this.getDiscounts();
        int discountCount = discountsAvailable.size();
        fsa.assertEquals(getTextFromElement(discountSubTitlePiggy), discountCount + TEXT_DISCOUNT_PIGGY,
                "Quote page - Discount Journey Subtitle Lock image.");
        fsa.assertTrue(isElementDisplayed(By.xpath(VIEW_DISCOUNTS_XPATH)), "Quote page - Link to View discounts is displayed.");
        waitAndClickElement(linkViewDiscounts);
    }

    public void validatePageFooters(ApplicantHQM applicant, @Nullable StaticContentHQM staticContent) throws Exception {
        List<String> disclaimersList = driver().findElements(By.xpath(DISCLAIMERS_XPATH)).stream()
                .map(this::getTextFromElement).filter(((Predicate<String>) String::isEmpty).negate()).collect(Collectors.toList());
        Log.info("Found Quote page footers disclaimers: " + disclaimersList);
        List<String> footers = new ArrayList<>();
        switch (applicant.stateCode) {
            case CT:
                footers.add(footersQuotePage.get(0).replace(". The premium", ".The premium")
                        + QUOTE_PAGE_FOOTER_CT + footersQuotePage.get(2));
                break;
            case CA:
                footers.add(footersQuotePage.get(0).replace("\n\n", "\n").substring(0,
                        footersQuotePage.get(0).indexOf("The premium shown may include a Preferred Payment discount.") - 1)
                        + "\n\n" + footersQuotePage.get(2));
                break;
            case AZ:
            case IL:
            case PA:
            case WY:
            case OK:
            case ID:
            case NM:
            case OR:
            case WI:
                footers.add(footersQuotePage.get(1) + footersQuotePage.get(2));
                break;
            case CO:
            case ND:
            case SD:
            case VA:
                footers.add(footersQuotePage.get(1) + footersQuotePage.get(2)
                        .replace("Farmers online home quotes are available for new customers.",
                                "Farmers online quotes are available for new customers."));
                break;
            case KY:
                footers.add(QUOTE_PAGE_FOOTER_KY1 + QUOTE_PAGE_FOOTER_KY2 + QUOTE_PAGE_FOOTER_KY3);
                break;
            case MS:
            case NV:
            case MO:
            case IN:
            case KS:
            case MD:
            case MN:
            case OH:
            case WA:
                footers.add(QUOTE_PAGE_FOOTER_KY2 + QUOTE_PAGE_FOOTER_KY3);
                break;
            case TX:
                footers.add(QUOTE_PAGE_FOOTER_KY2 + QUOTE_PAGE_FOOTER_TX + QUOTE_PAGE_FOOTER_KY3);
                break;
            case MA:
            case NC:
                footers.add(QUOTE_PAGE_FOOTER_MALA + QUOTE_PAGE_FOOTER_KY3);
                break;
            case LA:
                footers.add(QUOTE_PAGE_FOOTER_MALA + QUOTE_PAGE_FOOTER_LA + QUOTE_PAGE_FOOTER_KY3);
                break;
            case NE:
            case TN:
            case GA:
                footers.add(QUOTE_PAGE_FOOTER_NE + footersQuotePage.get(2)
                        .replace("Farmers online home quotes are available for new customers.",
                                "Farmers online home quotes are available for new home customers."));
                break;
            default:
                footers.add(footersQuotePage.get(0) + footersQuotePage.get(2));
                break;
        }
        Assert.assertEquals(disclaimersList.subList(0,1), footers, "Quote page - Validate Quote page footers.");

        //Policy Perks footer disclaimers
        /* -- Disabled until further notice
        List<String> policyPerksDisclaimers = new ArrayList<>(policyPerksDisclaimerList);
        if (!isFlexState(applicant.stateCode)) {
            disclaimersList.remove(0);
            if (applicant.stateCode.equals(CA)) {
                policyPerksDisclaimers.removeIf(s -> s.startsWith("DECLINING DEDUCTIBLES")); // CA - no DECLINING DEDUCTIBLES disclaimer
            }
            if (applicant.stateCode.equals(OK)) {
                policyPerksDisclaimers.removeIf(s -> s.startsWith("CLAIM FREE"));            // OK - no CLAIM FREE disclaimer
            }
            Assert.assertEquals(disclaimersList, policyPerksDisclaimers, "Quote page - Validate Policy Perks Disclaimers text.");
        } else {
            Assert.assertFalse(disclaimersList.size() > 1, "Quote page - No Policy Perks Disclaimers for Flex states.");
        }
         -- Disabled until further notice */

        if (staticContent != null) {
            String footersString = String.join("", footers);
            if (isFlexState(applicant.stateCode)) {
                footersString = footersString.startsWith("* ") ? footersString : "* " + footersString;
            }
            Assert.assertEquals(staticContent.getQuoteDisclaimer(), footersString,
                    "Quote page - Validate Quote page footers (AEM).");
            /* -- Disabled until further notice
            if (!isFlexState(applicant.stateCode)) {
                List<String> policyPerksDisclaimersAem = new ArrayList<>();
                policyPerksDisclaimersAem.add(staticContent.getQuoteDisclaimerPolicyPerks());
                if (!applicant.stateCode.equals(CA)) {
                    policyPerksDisclaimersAem.add(staticContent.getQuoteDisclaimerDecliningDeductibles());
                }
                policyPerksDisclaimersAem.add(staticContent.getQuoteDisclaimerClaimForgiveness());
                if (!applicant.stateCode.equals(OK)) {
                    policyPerksDisclaimersAem.add(staticContent.getRateSummaryDisclaimerClaimFree());
                }
                Assert.assertEquals(policyPerksDisclaimersAem, policyPerksDisclaimers,
                        "Quote page - Validate Policy Perks Disclaimers (AEM).");
            }
            -- Disabled until further notice */
        }
    }

    public void validatePolicyPerks(ApplicantHQM applicant) throws Exception {
        /* -- Disabled until further notice
        List<String> perksHeaders = driver().findElements(By.xpath(POLICY_PERKS_PARAGRAPH_HEADER_XPATH))
                .stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> perksContents = driver().findElements(By.xpath(POLICY_PERKS_PARAGRAPH_CONTENT_XPATH))
                .stream().map(this::getTextFromElement).collect(Collectors.toList());
        if (!isFlexState(applicant.stateCode)) {
            sa.assertEquals(policyPerksTitle, "alt"), "policy Perks", "Quote page - Policy Perks Title.");
            sa.assertEquals(policyPerksHeader.getText(), POLICY_PERKS_HEADER_TEXT, "Quote page - Policy Perks Header.");
            sa.assertEquals(policyPerksHeaderLink.getText(), "Learn moreopen_in_new", "Quote page - Policy Perks Header Link.");
            if (applicant.stateCode.equals(CA)) {
                textPerksHeaders.removeIf(s -> s.startsWith("Declining Deductibles"));
                textPerksContents.removeIf(s -> s.startsWith("Earn $50"));
            } else if (applicant.stateCode.equals(OK)) {
                textPerksHeaders.removeIf(s -> s.startsWith("Claim Free"));
                textPerksContents.removeIf(s -> s.contains("claim-free for three years"));
            }
            sa.assertEquals(perksHeaders, textPerksHeaders, "Quote page - Policy Perks Paragraph Header");
            sa.assertEquals(perksContents, textPerksContents, "Quote page - Policy Perks Paragraph Content.");
        } else {
            sa.assertTrue(perksHeaders.isEmpty(), "Quote page - No Policy Perks Header for Flex states");
            sa.assertTrue(perksContents.isEmpty(), "Quote page - No Policy Perks Content for Flex states");
            sa.assertFalse(isElementPresentByID(policyPerksHeaderLink), "Quote page - No Policy Perks Link for Flex states.");
        }
        -- Disabled until further notice */
    }

    public void validatePolicyFloAd(ApplicantHQM applicant, String quoteSource, FarmersSoftAssert fsa) throws Exception {
        if (isEasternExpansionState(applicant.stateCode) && !applicant.waterShutoff) {
            fsa.assertTrue(isElementDisplayed(By.xpath(IMAGE_FLO_XPATH)), "Quote page - Image Flo by Moen is displayed");
            fsa.assertEquals(getTextFromElement(textFloByMoen), FLO_BY_MOEN_TEXT, "Quote page - Text Flo by Moen is displayed");
            fsa.assertTrue(isElementDisplayed(By.xpath(LINK_FLO_BY_MOEN_XPATH)), "Quote page - link to Learn More about " +
                    "Flo by Moen is displayed");
            fsa.assertEquals(getAttributeData(contactUsFloByMoen, ARIA_LABEL),
                    "For any questions, contact us at " + getContactUsPhoneNumber(applicant, quoteSource, true),
                    "Quote page - link to Contact Us about Flo by Moen is displayed");
        } else {
            fsa.assertFalse(isElementDisplayed(By.xpath(IMAGE_FLO_XPATH)), "Quote page - Image Flo by Moen is not displayed");
            fsa.assertFalse(isElementDisplayed(By.xpath(TEXT_FLO_BY_MOEN_XPATH)), "Quote page - Text Flo by Moen is not displayed");
        }
    }

    public void validatePageCardTitles(ApplicantHQM applicant, QuoteRateHQM quoteRate, boolean basicQuote, String quoteSource, FarmersSoftAssert fsa) throws Exception {
        // @quoteSource param is re-used as AEM campaign phone number, when it's not null and not QQ.
        String quoteType;
        if (quoteRate != null) {
            quoteType = quoteRate.getQuoteType();
        } else {
            quoteType = (basicQuote) ? "Standard" : "StandardCustom";
        }
        fsa.assertEquals(this.getQuoteType().replace(SPACE, ""), quoteType, "Quote page - Quote Type Title");
        if (basicQuote) {
            // The if statement below based on F55906 requirements
            if (isPLAState(applicant.stateCode) || ((LocalDate.now().getYear() - applicant.getYearBuilt()) < 10)) {
                fsa.assertEquals(getTextFromElement(textQuoteTypeSubtitle), STANDARD_QUOTE_TEXT, "Quote page - Standard Quote Type SubTitle.");
            } else {
                fsa.assertEquals(getTextFromElement(textQuoteTypeSubtitle), STANDARD_QUOTE_TEXT + SPACE + ROOF_PAYMENT_TEXT, "Quote page - Standard Quote Type SubTitle (includes roof payment).");
            }
        } else {
            fsa.assertEquals(getTextFromElement(textQuoteTypeSubtitle), STANDARD_CUSTOM_QUOTE_TEXT, "Quote page - Standard Custom Quote Type Subtitle.");
        }
        fsa.assertEquals(getTextFromElement(textContactUs).replace("\n",SPACE), String.format(CONTACT_US_STR,
                getContactUsPhoneNumber(applicant, quoteSource, true)), "Quote Page - Contact Us Subtitle");
        if (Arrays.asList(MS, NC).contains(applicant.stateCode)) {
            final String windAndHailEndorsementNote = "Please note that \u201cWind and Hail Exclusion\u201d endorsement may be required.";
            fsa.assertEquals(getTextFromElement(textQuoteNoteSubtitle), windAndHailEndorsementNote, "Quote page - Quote Wind & Hail Endorsement Note");
        }
    }

    public void validateQuotePremiums(ApplicantHQM applicant, QuoteRateHQM quoteRate, Double quoteDelta, FarmersSoftAssert fsa) throws Exception {

        Log.info("Quote Type: " + this.getQuoteType());
        String quotePremiumMonthly;
        double dQuotePremiumMonthly = 0;
        if (!isHqmDigitalMonetizationState(applicant.stateCode)) {
            quotePremiumMonthly = this.getQuotePremiumMonthly();
            dQuotePremiumMonthly = NumberFormat.getCurrencyInstance(Locale.US).parse(quotePremiumMonthly).doubleValue();
            Log.info("Quote Price Per Month: " + quotePremiumMonthly);
        }
        String quotePremiumYearly = this.getQuotePremiumYearly(applicant.stateCode);
        double dQuotePremiumYearly = NumberFormat.getCurrencyInstance(Locale.US).parse(quotePremiumYearly).doubleValue();
        Log.info("Quote Price Per Year:  " + quotePremiumYearly);

        if (!isHqmDigitalMonetizationState(applicant.stateCode)) {
            fsa.assertEquals(Math.round(dQuotePremiumYearly), Math.round(dQuotePremiumMonthly * 12), 1,
                    "Quote Page - [Monthly premium * 12] equals to [Yearly Premium]");
        }
        if (quoteRate != null) {
            if (!isHqmDigitalMonetizationState(applicant.stateCode)) {
                fsa.assertEquals(dQuotePremiumMonthly, Double.parseDouble(quoteRate.getMonthlyPremium()),
                        "Quote page - Monthly Premium validation vs. Postgres value.");
            } else {
                fsa.assertEquals(dQuotePremiumYearly, Double.parseDouble(quoteRate.getYearlyPremium()),
                        "Quote page - Yearly Premium for Monetization states validation vs. Postgres value.");
            }
        } else {
            fsa.assertEquals(dQuotePremiumMonthly, Double.parseDouble(applicant.quoteRate),
                    Double.parseDouble(applicant.quoteRate) * quoteDelta,
                    "Quote page - Monthly Premium validation vs. datasource saved value.");
        }
    }

    public void validateSendEmail(ApplicantHQM applicant, FarmersSoftAssert fsa) throws Exception {
        if (!isHqmDigitalMonetizationState(applicant.stateCode)) {
            waitForPageToBeReady();
            waitElementBeVisibleClickable(btnEmail);
            this.validateEmailIconState(true, fsa);
            try {
                waitAndClickElement(btnEmail);
            } catch (StaleElementReferenceException e) {
                new QuotePage();
                waitAndClickElement(btnEmail);
            }
            driverWait(Property.PAGELOADTIMEOUT).until(visibilityOf(emailDialogTitle));
            fsa.assertEquals(getTextFromElement(emailDialogTitle), "Email quote", "Quote page - Email popup title");
            fsa.assertEquals(getTextFromElement(emailDialogContent), "We sent your quote to " + applicant.emailAddress,
                    "Quote Page - Email popup content");
            waitAndClickElement(emailDialogBtnOK);
            driverWait(5).until(ExpectedConditions.invisibilityOf(emailDialogBtnOK));
            this.validateEmailIconState(false, fsa);
        }
    }

    public void validateEmailIconState(boolean enabled, FarmersSoftAssert fsa) throws Exception {
        if (enabled) {
            fsa.assertEquals(getAttributeData(btnEmail, ARIA_LABEL), "email icon, on click will Open a model dialog box and " +
                            "sends qoute to your email", "Quote page - Email icon aria-label points out the icon is enabled");
            fsa.assertFalse(getAttributeData(driver().findElement(btnEmailIcon), CLASS).contains(DISABLED),
                    "Quote page - Email icon is disabled");
        } else {
            fsa.assertEquals(getAttributeData(btnEmail, ARIA_LABEL), "email icon is disabled",
                    "Quote page - Email icon aria-label points out the icon is disabled");
            fsa.assertTrue(getAttributeData(driver().findElement(btnEmailIcon), CLASS).contains(DISABLED),
                    "Quote page - Email icon becomes disabled after the email was sent");
            Log.info(">>> mat-icon @class:" + getAttributeData(btnEmail.findElement(By.xpath("//mat-icon")), CLASS));
        }
    }

    public String getQuoteReconstructionCost() {
        return getTextFromElement(textReconstructionCost);
    }

    public void clickPrint() {
        waitAndClickElement(btnPrint);
    }

    public void switchToNewTab() throws Exception {
        ArrayList<String> tabs = new ArrayList<>(driver().getWindowHandles());
        driver().switchTo().window(tabs.get(1));
    }

    public void switchToMainTab() throws Exception {
        ArrayList<String> tabs = new ArrayList<>(driver().getWindowHandles());
        driver().switchTo().window(tabs.get(0));
    }

    public void validateAutoLobLink() {
        Assert.assertEquals(getTextFromElement(autoLobLink), "Auto quote", "HQM Quote Page - Auto LOB quote link found.");
    }

    public void toggleToAutoLob() throws Exception {
        if (!isElementVisible(autoLobLink,3) && isSideDrawerCollapsed()) {
            waitAndClickElement(summaryMobileIcon);
        }
        waitAndClickElement(autoLobLink);
    }

    public void validateLifeLobLinks(List<String> lobNames) throws Exception {
        List<String> lobList = driver().findElements(By.xpath(CROSSSELL_LIFE_XPATH)).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        Log.info("Life LOB quotes links found: " + lobList);
        Assert.assertEquals(lobList, lobNames, "HQM Quote Page - All Expected Life LOB quote links found.");
    }

    public boolean isEmailButtonDisplayed() throws Exception {
        return isElementDisplayed(btnEmailIcon);
    }

    public boolean isPrintButtonDisplayed() throws Exception {
        return isElementDisplayed(By.xpath(PRINT_ICON_XPATH));
    }

}
