package com.farmers.ffq.hqm.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class InterstitialPage extends HqmBasePage {

    @FindBy(xpath = "//app-fgia-popup/mat-dialog-content//div[@role='heading']")
    private WebElement pageTitle;

    @FindBy(xpath = "//app-fgia-popup/mat-dialog-content//div[@id='dnqMessage']")
    private WebElement pageContents;

    @FindBy(xpath = "//button[contains(.,'Continue to FGIA')]")
    private WebElement buttonContinueToFGIA;

    @FindBy(xpath = "//button[contains(.,'No, thanks')]")
    private WebElement buttonNoThanks;

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public InterstitialPage() throws Exception {
        super();
        wait.until(ExpectedConditions.urlContains("/fastquote/interstitial"));
    }

    public boolean isPageTitleTextExists() throws Exception {
        final String pageTitleText = "Continue your quote request with Farmers General Insurance Agency, Inc";
        return getTextFromElement(pageTitle).contains(pageTitleText);
    }

    public boolean isPageContentsTextExists() throws Exception {
        final String pageTitleText = "We are unable to offer you an online quote for a Farmers-branded policy at this time. " +
                "Farmers General Insurance Agency, Inc. (FGIA) may be able to offer you a quote through other companies, " +
                "or you can contact a Farmers agent in your area.";
        return getTextFromElement(pageContents).contains(pageTitleText);
    }

    public boolean isButtonContinueToFGIAExists() throws Exception {
		return buttonContinueToFGIA.isDisplayed();
    }

    public boolean isButtonNoThanksExists() throws Exception {
        return buttonNoThanks.isDisplayed();
    }

    public void clickContinueToFGIA() {
        waitAndClickElement(buttonContinueToFGIA);
    }

    public void clickNoThanks() {
        waitAndClickElement(buttonNoThanks);
    }
}
