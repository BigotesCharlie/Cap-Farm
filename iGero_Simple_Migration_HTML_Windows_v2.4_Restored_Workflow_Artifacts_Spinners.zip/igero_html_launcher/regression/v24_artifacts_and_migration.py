"""v2.4 regressions: an empty Playwright registry must not prevent Java→JSON+Prompt→spec generation.
Simulated Copilot/Playwright only. Never calls real QA or uses real AI credits.
"""
import os, tempfile, subprocess, pathlib, json, time, urllib.request, urllib.parse, shutil
root=pathlib.Path(tempfile.mkdtemp(prefix='igero_v24_'))
java=root/'java'; ts=root/'pw'; bins=root/'bin'; launcher=root/'launcher'
javafile=java/'src/test/java/com/farmers/ffq/acehome/AceHomePilotTest.java'
javafile.parent.mkdir(parents=True)
javafile.write_text('public class AceHomePilotTest { @Test public void testContentPilot() { Assert.assertTrue(true); } }')
(ts/'tests/acehome').mkdir(parents=True)
(ts/'node_modules/@playwright/test').mkdir(parents=True)
(ts/'node_modules/@playwright/test/package.json').write_text('{}')
(ts/'node_modules/.bin').mkdir(parents=True)
(ts/'node_modules/.bin/playwright').touch()
bins.mkdir();launcher.mkdir()
(bins/'npx').write_text('''#!/usr/bin/env python3
import sys
if '--list' in sys.argv: print('Error: No tests found.');sys.exit(1)
print('TypeScript mock PASS');sys.exit(0)
''')
(bins/'copilot').write_text('#!/bin/sh\necho CopilotMock\nexit 0\n')
(bins/'pwsh').write_text('''#!/usr/bin/env python3
import sys,os,re,pathlib,json
p=pathlib.Path(sys.argv[sys.argv.index('-PromptFile')+1]); txt=p.read_text(); root=pathlib.Path(os.environ['MOCK_PROJECT'])
with pathlib.Path(os.environ['MOCK_INVOKES']).open('a') as f:f.write('X\\n')
if 'extract' in p.name:
 m=re.search(r'Output JSON: (.*)',txt); j=pathlib.Path(m.group(1).strip()); j.parent.mkdir(parents=True,exist_ok=True)
 j.write_text(json.dumps({'className':'AceHomePilotTest','methodName':'testContentPilot','steps':[{'action':'visible content'}],'assertions':[{'id':'A01'}],'unresolved':[]}))
 (j.parent/'prompt.md').write_text('Implement this content validation method exactly as the original Java source defines it.')
else:
 s=root/'tests/acehome/AceHomePilotTest.spec.ts';s.parent.mkdir(parents=True,exist_ok=True)
 s.write_text("import {test,expect} from '@playwright/test';\\ntest('testContentPilot',async()=>{expect(1).toBe(1)});\\n")
print('MOCK step completed: generated local files only')
''')
(bins/'npm').write_text('#!/bin/sh\nexit 0\n')
for b in bins.iterdir():b.chmod(0o755)
source=pathlib.Path(__file__).resolve().parents[1]
for name in ('server.mjs','index.html','app.js','registry-isolation.mjs','focused-test-resolver.mjs','lob-catalog.mjs','invoke-copilot.ps1'):
 shutil.copy2(source/name,launcher/name)
port='18878'
env=os.environ.copy();env.update({'IGERO_PANEL_PORT':port,'PATH':str(bins)+os.pathsep+env['PATH'],'MOCK_INVOKES':str(root/'invokes'),'MOCK_PROJECT':str(ts)})
proc=subprocess.Popen(['node','server.mjs'],cwd=launcher,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
def api(url,data=None):
 req=urllib.request.Request('http://127.0.0.1:'+port+url,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=45) as resp:return json.load(resp)
try:
 for i in range(80):
  try:api('/api/job');break
  except Exception:time.sleep(.1)
 api('/api/config',{'javaRoot':str(java),'playwrightRoot':str(ts),'autoTypecheck':True,'autoFunctionalCheck':True,'testEnv':'MA11'})
 mid='AceHomePilotTest#testContentPilot'
 out0=api('/api/outputs?id='+urllib.parse.quote(mid))
 assert not any(x['exists'] for x in out0['fileStatus'].values()),out0['fileStatus']
 print('PASS: absent source artifacts display false status')
 data=api('/api/start',{'methodId':mid,'mode':'all'})
 print('start',data)
 state={}
 for _ in range(450):
  state=api('/api/job')
  if state['status']!='running':break
  time.sleep(.1)
 assert state['status']=='blocked',state
 assert 'PLAYWRIGHT_REGISTRY_PREFLIGHT_FAILED' not in str(state.get('error'))
 assert state['steps'][1]['status']=='pass' and state['steps'][2]['status']=='pass',state['steps']
 assert (root/'invokes').read_text().count('X')>=2,'Copilot mock not invoked for both generation steps'
 out=api('/api/outputs?id='+urllib.parse.quote(mid))
 assert all(x['exists'] and x['valid'] for x in out['fileStatus'].values()),out['fileStatus']
 print('PASS: both source artifacts and actual TS spec produced even when Playwright registers zero tests')
 assert out['specPath'].endswith('AceHomePilotTest.spec.ts')
 assert state['steps'][5]['status']=='skipped' and state['functional']['counts']['total']==0
 print('PASS: no false functional PASS when runner discovery remains broken')
 # Basic file content mismatch cannot falsely pass just because the path exists
 (pathlib.Path(out['outputDir'])/'contract.json').write_text('{}')
 out2=api('/api/outputs?id='+urllib.parse.quote(mid))
 assert out2['fileStatus']['json']=={'exists':True,'valid':False},out2['fileStatus']['json']
 print('PASS: invalid JSON emits negative status despite existing file')
 print('MOCK_ONLY_RESULTS=PASS')
finally:
 proc.terminate()
 try:proc.wait(timeout=4)
 except Exception:proc.kill()
 shutil.rmtree(root,ignore_errors=True)
