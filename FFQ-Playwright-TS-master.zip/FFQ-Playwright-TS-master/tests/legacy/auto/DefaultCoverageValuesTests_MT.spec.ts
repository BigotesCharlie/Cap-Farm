// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT', () => {
  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_25K_50K_NO_UMBRELLA
  test('testDefaultCoverageValues_25K_50K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_25K_50K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 12,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_25K_50K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_30K_60K_NO_UMBRELLA
  test('testDefaultCoverageValues_MT_30K_60K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_30K_60K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 18,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_30K_60K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_35K_70K_NO_UMBRELLA
  test('testDefaultCoverageValues_MT_35K_70K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_35K_70K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 23,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_35K_70K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_50K_100K_NO_UMBRELLA
  test('testDefaultCoverageValues_MT_50K_100K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_50K_100K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 28,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_50K_100K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_100K_200K_NO_UMBRELLA
  test('testDefaultCoverageValues_MT_100K_200K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_100K_200K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 33,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_100K_200K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_100K_300K_NO_UMBRELLA
  test('testDefaultCoverageValues_MT_100K_300K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_100K_300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 38,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_100K_300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_250K_500K_NO_UMBRELLA
  test('testDefaultCoverageValues_MT_250K_500K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_250K_500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 43,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_250K_500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_500K_500K_NO_UMBRELLA
  test('testDefaultCoverageValues_MT_500K_500K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_500K_500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 48,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_500K_500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_500K_NO_UMBRELLA
  test('testDefaultCoverageValues_MT_500K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 53,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_25K_50K_UMBRELLA
  test('testDefaultCoverageValues_25K_50K_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_25K_50K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 59,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_25K_50K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_30K_60K_UMBRELLA
  test('testDefaultCoverageValues_MT_30K_60K_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_30K_60K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 65,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_30K_60K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_35K_70K_UMBRELLA
  test('testDefaultCoverageValues_MT_35K_70K_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_35K_70K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 70,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_35K_70K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_50K_100K_UMBRELLA
  test('testDefaultCoverageValues_MT_50K_100K_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_50K_100K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 75,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_50K_100K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_100K_200K_UMBRELLA
  test('testDefaultCoverageValues_MT_100K_200K_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_100K_200K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 80,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_100K_200K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_100K_300K_UMBRELLA
  test('testDefaultCoverageValues_MT_100K_300K_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_100K_300K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 85,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_100K_300K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_250K_500K_UMBRELLA
  test('testDefaultCoverageValues_MT_250K_500K_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_250K_500K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 90,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_250K_500K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_500K_500K_UMBRELLA
  test('testDefaultCoverageValues_MT_500K_500K_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_500K_500K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 95,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_500K_500K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_500K_UMBRELLA
  test('testDefaultCoverageValues_MT_500K_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.DefaultCoverageValuesTests_MT#testDefaultCoverageValues_MT_500K_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/DefaultCoverageValuesTests_MT.java',
      sourceLine: 100,
      className: 'DefaultCoverageValuesTests_MT',
      method: 'testDefaultCoverageValues_MT_500K_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT})}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = true)',
    });
  });
});
