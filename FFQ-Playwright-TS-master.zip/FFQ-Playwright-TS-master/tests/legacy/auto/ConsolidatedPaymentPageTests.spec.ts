// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests', () => {
  // legacy-id: com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#validateAceAutoPaymentSummaryPage
  test('validateAceAutoPaymentSummaryPage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#validateAceAutoPaymentSummaryPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/ConsolidatedPaymentPageTests.java',
      sourceLine: 32,
      className: 'ConsolidatedPaymentPageTests',
      method: 'validateAceAutoPaymentSummaryPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, CONSOLIDATED_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NM, OK, PA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#consolidatePaymentPageValidatePayments_F76393
  test('consolidatePaymentPageValidatePayments_F76393', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#consolidatePaymentPageValidatePayments_F76393',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/ConsolidatedPaymentPageTests.java',
      sourceLine: 48,
      className: 'ConsolidatedPaymentPageTests',
      method: 'consolidatePaymentPageValidatePayments_F76393',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, CONSOLIDATED_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NM, OK, PA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#validatePremiumChangeMessageAndGoingBackToQuoteScreenPage_F76393
  test('validatePremiumChangeMessageAndGoingBackToQuoteScreenPage_F76393', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#validatePremiumChangeMessageAndGoingBackToQuoteScreenPage_F76393',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/ConsolidatedPaymentPageTests.java',
      sourceLine: 63,
      className: 'ConsolidatedPaymentPageTests',
      method: 'validatePremiumChangeMessageAndGoingBackToQuoteScreenPage_F76393',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, CONSOLIDATED_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NM, OK, PA, TN, UT, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#validateIframeContents
  test('validateIframeContents', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#validateIframeContents',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/ConsolidatedPaymentPageTests.java',
      sourceLine: 78,
      className: 'ConsolidatedPaymentPageTests',
      method: 'validateIframeContents',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, CONSOLIDATED_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NM, OK, PA, WA}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#validateIframeErrorMessages
  test('validateIframeErrorMessages', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#validateIframeErrorMessages',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/ConsolidatedPaymentPageTests.java',
      sourceLine: 91,
      className: 'ConsolidatedPaymentPageTests',
      method: 'validateIframeErrorMessages',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, CONSOLIDATED_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NM, OK, PA, WA}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#testIframeValidation
  test('testIframeValidation', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#testIframeValidation',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/ConsolidatedPaymentPageTests.java',
      sourceLine: 103,
      className: 'ConsolidatedPaymentPageTests',
      method: 'testIframeValidation',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NM, OK, PA, WA}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#validatePreviouslyAddedPaymentMethodIsDeleted
  test('validatePreviouslyAddedPaymentMethodIsDeleted', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#validatePreviouslyAddedPaymentMethodIsDeleted',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/ConsolidatedPaymentPageTests.java',
      sourceLine: 115,
      className: 'ConsolidatedPaymentPageTests',
      method: 'validatePreviouslyAddedPaymentMethodIsDeleted',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, CONSOLIDATED_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, KY, MO, NM, OK, PA, WA}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#validateBackAndForthValidation
  test('validateBackAndForthValidation', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#validateBackAndForthValidation',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/ConsolidatedPaymentPageTests.java',
      sourceLine: 140,
      className: 'ConsolidatedPaymentPageTests',
      method: 'validateBackAndForthValidation',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, CONSOLIDATED_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NM, OK, PA, WA}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#validatePaymentMethodChangesAndPurchase
  test('validatePaymentMethodChangesAndPurchase', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.ConsolidatedPaymentPageTests#validatePaymentMethodChangesAndPurchase',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/ConsolidatedPaymentPageTests.java',
      sourceLine: 178,
      className: 'ConsolidatedPaymentPageTests',
      method: 'validatePaymentMethodChangesAndPurchase',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, CONSOLIDATED_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CO, FL, ID, KS, MO, NM, OK, PA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})',
    });
  });
});
