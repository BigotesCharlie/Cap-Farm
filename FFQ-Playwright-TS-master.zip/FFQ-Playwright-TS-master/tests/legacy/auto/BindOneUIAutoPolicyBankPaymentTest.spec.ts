// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest', () => {
  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest#monthlyPayBankIframeContentValidation
  test.skip('monthlyPayBankIframeContentValidation', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest#monthlyPayBankIframeContentValidation',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPolicyBankPaymentTest.java',
      sourceLine: 30,
      className: 'BindOneUIAutoPolicyBankPaymentTest',
      method: 'monthlyPayBankIframeContentValidation',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT',
      groups: '{FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest#monthlyPayBankIframeErrorValidation
  test.skip('monthlyPayBankIframeErrorValidation', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest#monthlyPayBankIframeErrorValidation',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPolicyBankPaymentTest.java',
      sourceLine: 63,
      className: 'BindOneUIAutoPolicyBankPaymentTest',
      method: 'monthlyPayBankIframeErrorValidation',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT',
      groups: '{FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest#monthlyPayBankIframeValidation
  test.skip('monthlyPayBankIframeValidation', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest#monthlyPayBankIframeValidation',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPolicyBankPaymentTest.java',
      sourceLine: 100,
      className: 'BindOneUIAutoPolicyBankPaymentTest',
      method: 'monthlyPayBankIframeValidation',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT',
      groups: '{FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest#payInFullBankIframeValidation
  test.skip('payInFullBankIframeValidation', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest#payInFullBankIframeValidation',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPolicyBankPaymentTest.java',
      sourceLine: 187,
      className: 'BindOneUIAutoPolicyBankPaymentTest',
      method: 'payInFullBankIframeValidation',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT',
      groups: '{FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest#payInFullBankToDebitCardPaymentMethodChange
  test.skip('payInFullBankToDebitCardPaymentMethodChange', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest#payInFullBankToDebitCardPaymentMethodChange',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPolicyBankPaymentTest.java',
      sourceLine: 273,
      className: 'BindOneUIAutoPolicyBankPaymentTest',
      method: 'payInFullBankToDebitCardPaymentMethodChange',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT',
      groups: '{FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest#monthlyPayBankToCreditCardPaymentMethodChange
  test.skip('monthlyPayBankToCreditCardPaymentMethodChange', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest#monthlyPayBankToCreditCardPaymentMethodChange',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPolicyBankPaymentTest.java',
      sourceLine: 325,
      className: 'BindOneUIAutoPolicyBankPaymentTest',
      method: 'monthlyPayBankToCreditCardPaymentMethodChange',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT',
      groups: '{FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest#validatePreviouslyAddedPaymentMethodIsDeleted
  test.skip('validatePreviouslyAddedPaymentMethodIsDeleted', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.bind.BindOneUIAutoPolicyBankPaymentTest#validatePreviouslyAddedPaymentMethodIsDeleted',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/BindOneUIAutoPolicyBankPaymentTest.java',
      sourceLine: 377,
      className: 'BindOneUIAutoPolicyBankPaymentTest',
      method: 'validatePreviouslyAddedPaymentMethodIsDeleted',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT',
      groups: '{FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)',
    });
  });
});
