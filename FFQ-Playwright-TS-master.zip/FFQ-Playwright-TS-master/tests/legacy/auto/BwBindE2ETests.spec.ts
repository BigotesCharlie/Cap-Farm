// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.bind.bw.BwBindE2ETests', () => {
  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBindE2ETestsPayInFull_NeverHadInsurance
  test('bwBindE2ETestsPayInFull_NeverHadInsurance', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBindE2ETestsPayInFull_NeverHadInsurance',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 28,
      className: 'BwBindE2ETests',
      method: 'bwBindE2ETestsPayInFull_NeverHadInsurance',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBindE2ETestsMonthlyAutoPayBank_NeverHadInsurance
  test('bwBindE2ETestsMonthlyAutoPayBank_NeverHadInsurance', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBindE2ETestsMonthlyAutoPayBank_NeverHadInsurance',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 34,
      className: 'BwBindE2ETests',
      method: 'bwBindE2ETestsMonthlyAutoPayBank_NeverHadInsurance',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBindE2ETestsMonthlyAutoPayCard_NeverHadInsurance
  test('bwBindE2ETestsMonthlyAutoPayCard_NeverHadInsurance', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBindE2ETestsMonthlyAutoPayCard_NeverHadInsurance',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 40,
      className: 'BwBindE2ETests',
      method: 'bwBindE2ETestsMonthlyAutoPayCard_NeverHadInsurance',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBindE2ETestsMonthlyDirectBill_NeverHadInsurance
  test('bwBindE2ETestsMonthlyDirectBill_NeverHadInsurance', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBindE2ETestsMonthlyDirectBill_NeverHadInsurance',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 46,
      className: 'BwBindE2ETests',
      method: 'bwBindE2ETestsMonthlyDirectBill_NeverHadInsurance',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsPayInFull_Expired
  test('bwE2ETestsPayInFull_Expired', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsPayInFull_Expired',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 52,
      className: 'BwBindE2ETests',
      method: 'bwE2ETestsPayInFull_Expired',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsMonthlyAutoPayBank_Expired
  test('bwE2ETestsMonthlyAutoPayBank_Expired', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsMonthlyAutoPayBank_Expired',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 59,
      className: 'BwBindE2ETests',
      method: 'bwE2ETestsMonthlyAutoPayBank_Expired',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsMonthlyAutoPayCard_Expired
  test('bwE2ETestsMonthlyAutoPayCard_Expired', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsMonthlyAutoPayCard_Expired',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 66,
      className: 'BwBindE2ETests',
      method: 'bwE2ETestsMonthlyAutoPayCard_Expired',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsMonthlyDirectBill_Expired
  test('bwE2ETestsMonthlyDirectBill_Expired', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsMonthlyDirectBill_Expired',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 73,
      className: 'BwBindE2ETests',
      method: 'bwE2ETestsMonthlyDirectBill_Expired',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsPayInFull_ForeignDriver
  test('bwE2ETestsPayInFull_ForeignDriver', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsPayInFull_ForeignDriver',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 80,
      className: 'BwBindE2ETests',
      method: 'bwE2ETestsPayInFull_ForeignDriver',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsMonthlyAutoPayBank_ForeignDriver
  test('bwE2ETestsMonthlyAutoPayBank_ForeignDriver', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsMonthlyAutoPayBank_ForeignDriver',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 86,
      className: 'BwBindE2ETests',
      method: 'bwE2ETestsMonthlyAutoPayBank_ForeignDriver',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, MS, MT, ND, NE, NM, NV, OH, OK, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E}, enabled = true)',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsMonthlyAutoPayCard_ForeignDriver
  test('bwE2ETestsMonthlyAutoPayCard_ForeignDriver', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsMonthlyAutoPayCard_ForeignDriver',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 92,
      className: 'BwBindE2ETests',
      method: 'bwE2ETestsMonthlyAutoPayCard_ForeignDriver',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsMonthlyDirectBill_ForeignDriver
  test('bwE2ETestsMonthlyDirectBill_ForeignDriver', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETestsMonthlyDirectBill_ForeignDriver',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 98,
      className: 'BwBindE2ETests',
      method: 'bwE2ETestsMonthlyDirectBill_ForeignDriver',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, CT, FL, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_QuoteCustomized_ForeignDriver
  test('bwE2ETests_QuoteCustomized_ForeignDriver', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_QuoteCustomized_ForeignDriver',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 104,
      className: 'BwBindE2ETests',
      method: 'bwE2ETests_QuoteCustomized_ForeignDriver',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_QuoteCustomized_NeverHadInsurance
  test('bwE2ETests_QuoteCustomized_NeverHadInsurance', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_QuoteCustomized_NeverHadInsurance',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 111,
      className: 'BwBindE2ETests',
      method: 'bwE2ETests_QuoteCustomized_NeverHadInsurance',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_QuoteCustomized_Expired
  test('bwE2ETests_QuoteCustomized_Expired', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_QuoteCustomized_Expired',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 117,
      className: 'BwBindE2ETests',
      method: 'bwE2ETests_QuoteCustomized_Expired',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NV, OH, OK, OR, PA, SD, TN, TX, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_QuoteCustomized_FinancialFilingInState
  test('bwE2ETests_QuoteCustomized_FinancialFilingInState', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_QuoteCustomized_FinancialFilingInState',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 123,
      className: 'BwBindE2ETests',
      method: 'bwE2ETests_QuoteCustomized_FinancialFilingInState',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, GA, ID, IL, MI, MO, SD, ND, NE, OR, TN, TX, UT, VA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_Deployed
  test('bwE2ETests_Deployed', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_Deployed',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 129,
      className: 'BwBindE2ETests',
      method: 'bwE2ETests_Deployed',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MI, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_NotRequired
  test('bwE2ETests_NotRequired', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_NotRequired',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 135,
      className: 'BwBindE2ETests',
      method: 'bwE2ETests_NotRequired',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_MultipleVehicleDriver
  test('bwE2ETests_MultipleVehicleDriver', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_MultipleVehicleDriver',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 141,
      className: 'BwBindE2ETests',
      method: 'bwE2ETests_MultipleVehicleDriver',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_MoreThanOneInjury
  test('bwE2ETests_MoreThanOneInjury', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_MoreThanOneInjury',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 150,
      className: 'BwBindE2ETests',
      method: 'bwE2ETests_MoreThanOneInjury',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_LessThan6Month
  test('bwE2ETests_LessThan6Month', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwE2ETests_LessThan6Month',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 162,
      className: 'BwBindE2ETests',
      method: 'bwE2ETests_LessThan6Month',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBackAndForthTest_NotRequired
  test('bwBackAndForthTest_NotRequired', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBackAndForthTest_NotRequired',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 178,
      className: 'BwBindE2ETests',
      method: 'bwBackAndForthTest_NotRequired',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBackAndForthTest_Foreign
  test('bwBackAndForthTest_Foreign', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBackAndForthTest_Foreign',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 189,
      className: 'BwBindE2ETests',
      method: 'bwBackAndForthTest_Foreign',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBackAndForthTest_Deployed
  test('bwBackAndForthTest_Deployed', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBackAndForthTest_Deployed',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 200,
      className: 'BwBindE2ETests',
      method: 'bwBackAndForthTest_Deployed',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_BIND_E2E}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBindE2ETestsPayInFull_NeverHadInsuranceTempTestForTesla
  test('bwBindE2ETestsPayInFull_NeverHadInsuranceTempTestForTesla', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#bwBindE2ETestsPayInFull_NeverHadInsuranceTempTestForTesla',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 262,
      className: 'BwBindE2ETests',
      method: 'bwBindE2ETestsPayInFull_NeverHadInsuranceTempTestForTesla',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BDQ_TESTS_TESLA}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS_TESLA})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwBindE2ETests#validateCoBranding
  test('validateCoBranding', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwBindE2ETests#validateCoBranding',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwBindE2ETests.java',
      sourceLine: 286,
      className: 'BwBindE2ETests',
      method: 'validateCoBranding',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES',
      groups: '{BW_ACE_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {PA })}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS})',
    });
  });
});
