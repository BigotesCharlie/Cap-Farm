// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX', () => {
  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_None_Unk_NO_UMBRELLA
  test.skip('testDefaultCoverageValues_TX_None_Unk_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_None_Unk_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 14,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_None_Unk_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_30K60K_NO_UMBRELLA
  test.skip('testDefaultCoverageValues_TX_30K60K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_30K60K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 23,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_30K60K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_35K70K_NO_UMBRELLA
  test.skip('testDefaultCoverageValues_TX_35K70K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_35K70K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 31,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_35K70K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_50K100K_NO_UMBRELLA
  test.skip('testDefaultCoverageValues_TX_50K100K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_50K100K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 38,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_50K100K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_100K200K_NO_UMBRELLA
  test.skip('testDefaultCoverageValues_TX_100K200K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_100K200K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 46,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_100K200K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_100K300K_NO_UMBRELLA
  test.skip('testDefaultCoverageValues_TX_100K300K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_100K300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 54,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_100K300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_250K500K_NO_UMBRELLA
  test.skip('testDefaultCoverageValues_TX_250K500K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_250K500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 62,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_250K500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_300K300K_NO_UMBRELLA
  test.skip('testDefaultCoverageValues_TX_300K300K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_300K300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 70,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_300K300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_500K500K_NO_UMBRELLA
  test('testDefaultCoverageValues_TX_500K500K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_500K500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 77,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_500K500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_500K1000K_NO_UMBRELLA
  test('testDefaultCoverageValues_TX_500K1000K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_500K1000K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 84,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_500K1000K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_50K_NO_UMBRELLA
  test('testDefaultCoverageValues_TX_50K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_50K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 91,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_50K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_75K_NO_UMBRELLA
  test('testDefaultCoverageValues_TX_75K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_75K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 98,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_75K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_200K_NO_UMBRELLA
  test('testDefaultCoverageValues_TX_200K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_200K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 105,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_200K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_300K_NO_UMBRELLA
  test('testDefaultCoverageValues_TX_300K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 112,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_500K_NO_UMBRELLA
  test('testDefaultCoverageValues_TX_500K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCoverageValuesTests_TX#testDefaultCoverageValues_TX_500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCoverageValuesTests_TX.java',
      sourceLine: 119,
      className: 'BWDefaultCoverageValuesTests_TX',
      method: 'testDefaultCoverageValues_TX_500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TX)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });
});
