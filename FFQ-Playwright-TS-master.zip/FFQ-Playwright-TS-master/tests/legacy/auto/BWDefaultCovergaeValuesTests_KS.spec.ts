// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS', () => {
  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_None_Unk_NO_UMBRELLA
  test('testDefaultCoverageValues_KS_None_Unk_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_None_Unk_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCovergaeValuesTests_KS.java',
      sourceLine: 12,
      className: 'BWDefaultCovergaeValuesTests_KS',
      method: 'testDefaultCoverageValues_KS_None_Unk_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_25K50K_NO_UMBRELLA
  test('testDefaultCoverageValues_KS_25K50K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_25K50K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCovergaeValuesTests_KS.java',
      sourceLine: 21,
      className: 'BWDefaultCovergaeValuesTests_KS',
      method: 'testDefaultCoverageValues_KS_25K50K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_30K60K_NO_UMBRELLA
  test('testDefaultCoverageValues_KS_30K60K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_30K60K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCovergaeValuesTests_KS.java',
      sourceLine: 28,
      className: 'BWDefaultCovergaeValuesTests_KS',
      method: 'testDefaultCoverageValues_KS_30K60K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_35K70K_NO_UMBRELLA
  test('testDefaultCoverageValues_KS_35K70K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_35K70K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCovergaeValuesTests_KS.java',
      sourceLine: 35,
      className: 'BWDefaultCovergaeValuesTests_KS',
      method: 'testDefaultCoverageValues_KS_35K70K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_100K200K_NO_UMBRELLA
  test('testDefaultCoverageValues_KS_100K200K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_100K200K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCovergaeValuesTests_KS.java',
      sourceLine: 42,
      className: 'BWDefaultCovergaeValuesTests_KS',
      method: 'testDefaultCoverageValues_KS_100K200K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_100K300K_NO_UMBRELLA
  test('testDefaultCoverageValues_KS_100K300K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_100K300K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCovergaeValuesTests_KS.java',
      sourceLine: 49,
      className: 'BWDefaultCovergaeValuesTests_KS',
      method: 'testDefaultCoverageValues_KS_100K300K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_250K500K_NO_UMBRELLA
  test('testDefaultCoverageValues_KS_250K500K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_250K500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCovergaeValuesTests_KS.java',
      sourceLine: 56,
      className: 'BWDefaultCovergaeValuesTests_KS',
      method: 'testDefaultCoverageValues_KS_250K500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_500K500K_NO_UMBRELLA
  test('testDefaultCoverageValues_KS_500K500K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_500K500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCovergaeValuesTests_KS.java',
      sourceLine: 63,
      className: 'BWDefaultCovergaeValuesTests_KS',
      method: 'testDefaultCoverageValues_KS_500K500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_500K1000K_NO_UMBRELLA
  test('testDefaultCoverageValues_KS_500K1000K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_500K1000K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCovergaeValuesTests_KS.java',
      sourceLine: 70,
      className: 'BWDefaultCovergaeValuesTests_KS',
      method: 'testDefaultCoverageValues_KS_500K1000K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_500K_NO_UMBRELLA
  test('testDefaultCoverageValues_KS_500K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_500K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCovergaeValuesTests_KS.java',
      sourceLine: 77,
      className: 'BWDefaultCovergaeValuesTests_KS',
      method: 'testDefaultCoverageValues_KS_500K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_1000K_NO_UMBRELLA
  test('testDefaultCoverageValues_KS_1000K_NO_UMBRELLA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.defaultcoverage.BWDefaultCovergaeValuesTests_KS#testDefaultCoverageValues_KS_1000K_NO_UMBRELLA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/defaultcoverage/BWDefaultCovergaeValuesTests_KS.java',
      sourceLine: 83,
      className: 'BWDefaultCovergaeValuesTests_KS',
      method: 'testDefaultCoverageValues_KS_1000K_NO_UMBRELLA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{AUTO_COVERAGE_VALIDATION}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})',
    });
  });
});
