// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.QuoteSummaryTests', () => {
  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testAutoQuoteSummaryLiabilityCoverageSectionContent
  test('testAutoQuoteSummaryLiabilityCoverageSectionContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testAutoQuoteSummaryLiabilityCoverageSectionContent',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 44,
      className: 'QuoteSummaryTests',
      method: 'testAutoQuoteSummaryLiabilityCoverageSectionContent',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {WA, FL})}, groups = {QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testAutoQuoteSummaryLiabilityAndVehicleTable
  test('testAutoQuoteSummaryLiabilityAndVehicleTable', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testAutoQuoteSummaryLiabilityAndVehicleTable',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 55,
      className: 'QuoteSummaryTests',
      method: 'testAutoQuoteSummaryLiabilityAndVehicleTable',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, ID, KS, ND, UT})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateLeasedOrFinancedVehicleCompCollisionMandatory
  test('validateLeasedOrFinancedVehicleCompCollisionMandatory', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateLeasedOrFinancedVehicleCompCollisionMandatory',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 76,
      className: 'QuoteSummaryTests',
      method: 'validateLeasedOrFinancedVehicleCompCollisionMandatory',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MI}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testAutoQuoteSummaryPageEmailConfirmation
  test('testAutoQuoteSummaryPageEmailConfirmation', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testAutoQuoteSummaryPageEmailConfirmation',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 89,
      className: 'QuoteSummaryTests',
      method: 'testAutoQuoteSummaryPageEmailConfirmation',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI, BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {NJ, FL, WA})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testAutoQuoteSummaryVehicleCoverageSectionContent
  test('testAutoQuoteSummaryVehicleCoverageSectionContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testAutoQuoteSummaryVehicleCoverageSectionContent',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 100,
      className: 'QuoteSummaryTests',
      method: 'testAutoQuoteSummaryVehicleCoverageSectionContent',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateOrderOfVehiclesInQuoteReviewPage_ADPFDATA
  test('validateOrderOfVehiclesInQuoteReviewPage_ADPFDATA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateOrderOfVehiclesInQuoteReviewPage_ADPFDATA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 109,
      className: 'QuoteSummaryTests',
      method: 'validateOrderOfVehiclesInQuoteReviewPage_ADPFDATA',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_AND_VEHICLES)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateOrderOfVehiclesInQuoteReviewPage_Non_ADPFDATA
  test('validateOrderOfVehiclesInQuoteReviewPage_Non_ADPFDATA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateOrderOfVehiclesInQuoteReviewPage_Non_ADPFDATA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 135,
      className: 'QuoteSummaryTests',
      method: 'validateOrderOfVehiclesInQuoteReviewPage_Non_ADPFDATA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, QUOTE_SUMMARY}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=9"}), @CustomAttribute(name = EXCLUDED_STATES, values = {WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_SUMMARY})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testDiscountRulesAndDiscountCountOnQuoteSummaryCard
  test('testDiscountRulesAndDiscountCountOnQuoteSummaryCard', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testDiscountRulesAndDiscountCountOnQuoteSummaryCard',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 176,
      className: 'QuoteSummaryTests',
      method: 'testDiscountRulesAndDiscountCountOnQuoteSummaryCard',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateVehicleReplacementPlusCoverage_US819667
  test.skip('validateVehicleReplacementPlusCoverage_US819667', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateVehicleReplacementPlusCoverage_US819667',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 202,
      className: 'QuoteSummaryTests',
      method: 'validateVehicleReplacementPlusCoverage_US819667',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MA, NC, NV, MS, KY, LA, OR, FL, MT, CA, CT, AL, AZ, IL, OK}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testIfLiabilityAndVehicleCoverageQuotePriceGeneratedRealistic
  test('testIfLiabilityAndVehicleCoverageQuotePriceGeneratedRealistic', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testIfLiabilityAndVehicleCoverageQuotePriceGeneratedRealistic',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 216,
      className: 'QuoteSummaryTests',
      method: 'testIfLiabilityAndVehicleCoverageQuotePriceGeneratedRealistic',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testInfoPersistenceOnNavigationAndRefresh
  test('testInfoPersistenceOnNavigationAndRefresh', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testInfoPersistenceOnNavigationAndRefresh',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 235,
      className: 'QuoteSummaryTests',
      method: 'testInfoPersistenceOnNavigationAndRefresh',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, MS}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testLiabilityAndVehicleCoverageSelectedByDefault
  test('testLiabilityAndVehicleCoverageSelectedByDefault', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testLiabilityAndVehicleCoverageSelectedByDefault',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 265,
      className: 'QuoteSummaryTests',
      method: 'testLiabilityAndVehicleCoverageSelectedByDefault',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, NC})}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testMultipleReRatingPremiumAndCoverageDisplay
  test('testMultipleReRatingPremiumAndCoverageDisplay', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testMultipleReRatingPremiumAndCoverageDisplay',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 273,
      className: 'QuoteSummaryTests',
      method: 'testMultipleReRatingPremiumAndCoverageDisplay',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL,NC})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testPerformRateQuoteAPI
  test('testPerformRateQuoteAPI', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testPerformRateQuoteAPI',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 357,
      className: 'QuoteSummaryTests',
      method: 'testPerformRateQuoteAPI',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI, QUOTE_SUMMARY}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {LA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_SUMMARY})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateCAQuotesOnlyOfferPayInFullAndMonthlyAmount
  test('validateCAQuotesOnlyOfferPayInFullAndMonthlyAmount', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateCAQuotesOnlyOfferPayInFullAndMonthlyAmount',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 377,
      className: 'QuoteSummaryTests',
      method: 'validateCAQuotesOnlyOfferPayInFullAndMonthlyAmount',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testSignalDiscountIsGiven
  test('testSignalDiscountIsGiven', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testSignalDiscountIsGiven',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 389,
      className: 'QuoteSummaryTests',
      method: 'testSignalDiscountIsGiven',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testSignalDiscountIsNotGiven
  test('testSignalDiscountIsNotGiven', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testSignalDiscountIsNotGiven',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 412,
      className: 'QuoteSummaryTests',
      method: 'testSignalDiscountIsNotGiven',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {AL, AK, CA, CT, DC, DE, FL, HI, ME, MT, NH, NJ, NY, OH, RI, SC, VT, WV})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testQuoteSummaryAutoPageFullPriceAndMonthlyPrice
  test('testQuoteSummaryAutoPageFullPriceAndMonthlyPrice', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testQuoteSummaryAutoPageFullPriceAndMonthlyPrice',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 425,
      className: 'QuoteSummaryTests',
      method: 'testQuoteSummaryAutoPageFullPriceAndMonthlyPrice',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {WA, FL, CA})}, dataProviderClass = AutoDataProviders.class, groups = {QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testQuoteSummaryAutoPageRecalculateLiabilityCoveragePrice
  test('testQuoteSummaryAutoPageRecalculateLiabilityCoveragePrice', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testQuoteSummaryAutoPageRecalculateLiabilityCoveragePrice',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 440,
      className: 'QuoteSummaryTests',
      method: 'testQuoteSummaryAutoPageRecalculateLiabilityCoveragePrice',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testQuoteSummaryAutoPageRecalculateVehicleCoveragePrice
  test('testQuoteSummaryAutoPageRecalculateVehicleCoveragePrice', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testQuoteSummaryAutoPageRecalculateVehicleCoveragePrice',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 451,
      className: 'QuoteSummaryTests',
      method: 'testQuoteSummaryAutoPageRecalculateVehicleCoveragePrice',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, groups = {QUOTEONEUI, QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testStartCheckoutButtonRedirectsToJustFewMoreThings
  test('testStartCheckoutButtonRedirectsToJustFewMoreThings', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testStartCheckoutButtonRedirectsToJustFewMoreThings',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 479,
      className: 'QuoteSummaryTests',
      method: 'testStartCheckoutButtonRedirectsToJustFewMoreThings',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testTotalSumOfLiabilityVehicleCoverageQuoteSum
  test('testTotalSumOfLiabilityVehicleCoverageQuoteSum', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testTotalSumOfLiabilityVehicleCoverageQuoteSum',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 494,
      className: 'QuoteSummaryTests',
      method: 'testTotalSumOfLiabilityVehicleCoverageQuoteSum',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {WA, MA})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateQuoteFlowWithEmploymentNotSelected
  test('validateQuoteFlowWithEmploymentNotSelected', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateQuoteFlowWithEmploymentNotSelected',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 503,
      className: 'QuoteSummaryTests',
      method: 'validateQuoteFlowWithEmploymentNotSelected',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, QUOTE_SUMMARY}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_SUMMARY})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateQuoteFlowWithEmploymentSelected
  test('validateQuoteFlowWithEmploymentSelected', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateQuoteFlowWithEmploymentSelected',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 514,
      className: 'QuoteSummaryTests',
      method: 'validateQuoteFlowWithEmploymentSelected',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, QUOTE_SUMMARY}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA, FL, KY, LA, MA, MS, NC})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_SUMMARY})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateDiscountsAndCoveragesPersistViaForthAndBack
  test('validateDiscountsAndCoveragesPersistViaForthAndBack', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateDiscountsAndCoveragesPersistViaForthAndBack',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 556,
      className: 'QuoteSummaryTests',
      method: 'validateDiscountsAndCoveragesPersistViaForthAndBack',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateBackAndForthNavigationAndRerate
  test('validateBackAndForthNavigationAndRerate', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateBackAndForthNavigationAndRerate',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 565,
      className: 'QuoteSummaryTests',
      method: 'validateBackAndForthNavigationAndRerate',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CA, TX})}, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateQuoteCustomization
  test('validateQuoteCustomization', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateQuoteCustomization',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 611,
      className: 'QuoteSummaryTests',
      method: 'validateQuoteCustomization',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE',
      groups: '{FFQ_ONEUI, QUOTE_SUMMARY}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, TX})}, testName = AutoDataProviders.AUTO_APPLICANT_FROM_EACH_STATE, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_SUMMARY})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateCustomizationAfterRetrieval
  test('validateCustomizationAfterRetrieval', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateCustomizationAfterRetrieval',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 625,
      className: 'QuoteSummaryTests',
      method: 'validateCustomizationAfterRetrieval',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, QUOTE_SUMMARY}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_SUMMARY})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testValidateSafeDriverDiscountForVAState_QuoteSummaryTests
  test('testValidateSafeDriverDiscountForVAState_QuoteSummaryTests', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testValidateSafeDriverDiscountForVAState_QuoteSummaryTests',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 642,
      className: 'QuoteSummaryTests',
      method: 'testValidateSafeDriverDiscountForVAState_QuoteSummaryTests',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI, QUOTE_SUMMARY}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=6"}), @CustomAttribute(name = VA)}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTE_SUMMARY})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateMultipleVehicleWithSameYMMScenario
  test('validateMultipleVehicleWithSameYMMScenario', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateMultipleVehicleWithSameYMMScenario',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 654,
      className: 'QuoteSummaryTests',
      method: 'validateMultipleVehicleWithSameYMMScenario',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA}), @CustomAttribute(name = FILTER, values = "applicantId=9")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateDiscountsE2E
  test('validateDiscountsE2E', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateDiscountsE2E',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 671,
      className: 'QuoteSummaryTests',
      method: 'validateDiscountsE2E',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, NJ, CT, MT, AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA}), @CustomAttribute(name = FILTER, values = "applicantId=10")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateBusinessDiscount
  test('validateBusinessDiscount', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateBusinessDiscount',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 707,
      className: 'QuoteSummaryTests',
      method: 'validateBusinessDiscount',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {MN, WA, OH, MD, IA, IN, MT, KS, NV, FL, NJ, LA, MS, MA, NC, KY}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateRideShareCoverage_CA_State
  test('validateRideShareCoverage_CA_State', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateRideShareCoverage_CA_State',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 732,
      className: 'QuoteSummaryTests',
      method: 'validateRideShareCoverage_CA_State',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = "applicantId=34")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateUMBILimitDontExceedBiLimitFarmers
  test('validateUMBILimitDontExceedBiLimitFarmers', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateUMBILimitDontExceedBiLimitFarmers',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 767,
      className: 'QuoteSummaryTests',
      method: 'validateUMBILimitDontExceedBiLimitFarmers',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX, PA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateUMBILimitDontExceedBiLimitBW
  test('validateUMBILimitDontExceedBiLimitBW', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateUMBILimitDontExceedBiLimitBW',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 781,
      className: 'QuoteSummaryTests',
      method: 'validateUMBILimitDontExceedBiLimitBW',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, BW_ACE_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateUserCanReduceBI
  test('validateUserCanReduceBI', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateUserCanReduceBI',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 799,
      className: 'QuoteSummaryTests',
      method: 'validateUserCanReduceBI',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, BW_ACE_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, NM, WI}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateCompIsRequiredWithLimitedColl
  test('validateCompIsRequiredWithLimitedColl', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateCompIsRequiredWithLimitedColl',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 817,
      className: 'QuoteSummaryTests',
      method: 'validateCompIsRequiredWithLimitedColl',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, BW_ACE_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateBwPromoCardSectionOnReviewQuotePage
  test('validateBwPromoCardSectionOnReviewQuotePage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateBwPromoCardSectionOnReviewQuotePage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 835,
      className: 'QuoteSummaryTests',
      method: 'validateBwPromoCardSectionOnReviewQuotePage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, BW_ACE_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testAutoFGIAOptionChanges
  test('testAutoFGIAOptionChanges', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testAutoFGIAOptionChanges',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 855,
      className: 'QuoteSummaryTests',
      method: 'testAutoFGIAOptionChanges',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX, PA, MD, TN, MI, AZ, IL, OH, MO, OK, VA, AR, CO, OR, AL, WI, MN}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testWAStateBI_PD_Restrictions_BW
  test('testWAStateBI_PD_Restrictions_BW', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testWAStateBI_PD_Restrictions_BW',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 871,
      className: 'QuoteSummaryTests',
      method: 'testWAStateBI_PD_Restrictions_BW',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testWAStateBI_PD_Restrictions_BDQ
  test('testWAStateBI_PD_Restrictions_BDQ', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#testWAStateBI_PD_Restrictions_BDQ',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 885,
      className: 'QuoteSummaryTests',
      method: 'testWAStateBI_PD_Restrictions_BDQ',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validate_MA_State_Vehicle_Garage_parketAtResidentAddress
  test('validate_MA_State_Vehicle_Garage_parketAtResidentAddress', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validate_MA_State_Vehicle_Garage_parketAtResidentAddress',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 898,
      className: 'QuoteSummaryTests',
      method: 'validate_MA_State_Vehicle_Garage_parketAtResidentAddress',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validate_MA_State_Vehicle_Garage_is_Not_parketAtResidentAddress
  test('validate_MA_State_Vehicle_Garage_is_Not_parketAtResidentAddress', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.QuoteSummaryTests#validate_MA_State_Vehicle_Garage_is_Not_parketAtResidentAddress',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 910,
      className: 'QuoteSummaryTests',
      method: 'validate_MA_State_Vehicle_Garage_is_Not_parketAtResidentAddress',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validate_PIP_CoverageHandling_MA_State_Farmers
  test('validate_PIP_CoverageHandling_MA_State_Farmers', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validate_PIP_CoverageHandling_MA_State_Farmers',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 924,
      className: 'QuoteSummaryTests',
      method: 'validate_PIP_CoverageHandling_MA_State_Farmers',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validate_PIP_CoverageHandling_MA_State_BW
  test('validate_PIP_CoverageHandling_MA_State_BW', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validate_PIP_CoverageHandling_MA_State_BW',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 936,
      className: 'QuoteSummaryTests',
      method: 'validate_PIP_CoverageHandling_MA_State_BW',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, BW_ACE_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateAgentFlowBindIsNotEnabledForCA
  test('validateAgentFlowBindIsNotEnabledForCA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateAgentFlowBindIsNotEnabledForCA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 949,
      className: 'QuoteSummaryTests',
      method: 'validateAgentFlowBindIsNotEnabledForCA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validatePDDoesNotOffer15K_with_rideshare
  test('validatePDDoesNotOffer15K_with_rideshare', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validatePDDoesNotOffer15K_with_rideshare',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 970,
      className: 'QuoteSummaryTests',
      method: 'validatePDDoesNotOffer15K_with_rideshare',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateRideShareDoesNotAllowLessThan50k_IN_State
  test('validateRideShareDoesNotAllowLessThan50k_IN_State', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateRideShareDoesNotAllowLessThan50k_IN_State',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 989,
      className: 'QuoteSummaryTests',
      method: 'validateRideShareDoesNotAllowLessThan50k_IN_State',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {IN}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateWithoutRideshareAndUpdateTheQuoteWithRideShare
  test('validateWithoutRideshareAndUpdateTheQuoteWithRideShare', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateWithoutRideshareAndUpdateTheQuoteWithRideShare',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1012,
      className: 'QuoteSummaryTests',
      method: 'validateWithoutRideshareAndUpdateTheQuoteWithRideShare',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {IN}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateRideShareMinLiabilityLimitsForBW
  test('validateRideShareMinLiabilityLimitsForBW', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateRideShareMinLiabilityLimitsForBW',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1026,
      className: 'QuoteSummaryTests',
      method: 'validateRideShareMinLiabilityLimitsForBW',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, NC}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateTwoVehiclesRideshareWithBusinessUseGoesToKO
  test('validateTwoVehiclesRideshareWithBusinessUseGoesToKO', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateTwoVehiclesRideshareWithBusinessUseGoesToKO',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1049,
      className: 'QuoteSummaryTests',
      method: 'validateTwoVehiclesRideshareWithBusinessUseGoesToKO',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, BW_ACE_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, KS, MI, MN, MO, NM, OK, TN, TX, VA, WA}), @CustomAttribute(name = FILTER, values = {"applicantId=36"})}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateThreeRideShareVehicleGoesToKO
  test('validateThreeRideShareVehicleGoesToKO', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateThreeRideShareVehicleGoesToKO',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1091,
      className: 'QuoteSummaryTests',
      method: 'validateThreeRideShareVehicleGoesToKO',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES',
      groups: '{QUOTE_SUMMARY, BW_ACE_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, KS, MI, WA})}, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, BW_ACE_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateLiabilityAndVehicleCoverageTotalIsMatching
  test('validateLiabilityAndVehicleCoverageTotalIsMatching', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateLiabilityAndVehicleCoverageTotalIsMatching',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1142,
      className: 'QuoteSummaryTests',
      method: 'validateLiabilityAndVehicleCoverageTotalIsMatching',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {QUOTE_SUMMARY, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateSidePanelClosedWithEscapeKey_ADA
  test('validateSidePanelClosedWithEscapeKey_ADA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateSidePanelClosedWithEscapeKey_ADA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1200,
      className: 'QuoteSummaryTests',
      method: 'validateSidePanelClosedWithEscapeKey_ADA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, GA, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, WI})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateGAStateAccidentDeathCoverageCustomization
  test('validateGAStateAccidentDeathCoverageCustomization', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateGAStateAccidentDeathCoverageCustomization',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1212,
      className: 'QuoteSummaryTests',
      method: 'validateGAStateAccidentDeathCoverageCustomization',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {GA})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateComboDiscount
  test('validateComboDiscount', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateComboDiscount',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1225,
      className: 'QuoteSummaryTests',
      method: 'validateComboDiscount',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {IL, OR, AZ, CA, CO, FL, ID, KS, MA, MO, NM, OK, PA, NJ, NV})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateComboDiscountRetrieval
  test('validateComboDiscountRetrieval', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateComboDiscountRetrieval',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1244,
      className: 'QuoteSummaryTests',
      method: 'validateComboDiscountRetrieval',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {IL, OR, AZ, CA, CO, FL, ID, KS, MA, MO, NM, OK, PA, NJ, NV})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateBI_UIM_MinimumLimits_NJ
  test('validateBI_UIM_MinimumLimits_NJ', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateBI_UIM_MinimumLimits_NJ',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1276,
      className: 'QuoteSummaryTests',
      method: 'validateBI_UIM_MinimumLimits_NJ',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {NJ})}, groups = {QUOTE_SUMMARY, FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateUMPDIsNotHigherThanPD_OR
  test('validateUMPDIsNotHigherThanPD_OR', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateUMPDIsNotHigherThanPD_OR',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1315,
      className: 'QuoteSummaryTests',
      method: 'validateUMPDIsNotHigherThanPD_OR',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, BDQ_TESTS, BW_ACE_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {OR})}, groups = {QUOTE_SUMMARY, BDQ_TESTS, BW_ACE_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateUserIsAbleToUpdatePDTo_30_MA
  test('validateUserIsAbleToUpdatePDTo_30_MA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateUserIsAbleToUpdatePDTo_30_MA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1333,
      className: 'QuoteSummaryTests',
      method: 'validateUserIsAbleToUpdatePDTo_30_MA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MA})}, groups = {QUOTE_SUMMARY, BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateUmUimSelectionAfterDeselection_TN_State
  test('validateUmUimSelectionAfterDeselection_TN_State', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateUmUimSelectionAfterDeselection_TN_State',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1361,
      className: 'QuoteSummaryTests',
      method: 'validateUmUimSelectionAfterDeselection_TN_State',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {TN})}, groups = {QUOTE_SUMMARY, BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validate50_100_25_LimitsAreEnforcedWithSingleRideShareVeh
  test('validate50_100_25_LimitsAreEnforcedWithSingleRideShareVeh', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validate50_100_25_LimitsAreEnforcedWithSingleRideShareVeh',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1382,
      className: 'QuoteSummaryTests',
      method: 'validate50_100_25_LimitsAreEnforcedWithSingleRideShareVeh',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {MT, IL})}, groups = {BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateMatureDriverDiscount
  test.skip('validateMatureDriverDiscount', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateMatureDriverDiscount',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1398,
      className: 'QuoteSummaryTests',
      method: 'validateMatureDriverDiscount',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES',
      groups: '{FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {TX,MO,NE,OK,FL,GA,PA,OR,NJ,IA, CA,MT,IN,KY,KS,LA,NV,AR,CO,TN,NM,IL,UT,MS,MN,MI,AZ,VA,MD,ID,MA,WA,OH})}, groups = {FFQ_ONEUI})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateIfSignalDiscountGetsRemovedInQuoteReviewPage
  test('validateIfSignalDiscountGetsRemovedInQuoteReviewPage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateIfSignalDiscountGetsRemovedInQuoteReviewPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1414,
      className: 'QuoteSummaryTests',
      method: 'validateIfSignalDiscountGetsRemovedInQuoteReviewPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateCustomizedCompCollCoveragesAreRetainedWithRetrieval
  test('validateCustomizedCompCollCoveragesAreRetainedWithRetrieval', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateCustomizedCompCollCoveragesAreRetainedWithRetrieval',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1448,
      className: 'QuoteSummaryTests',
      method: 'validateCustomizedCompCollCoveragesAreRetainedWithRetrieval',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {CA, CO})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateQuoteRatingAfterPermissiveUserLimitOfLiabilityUpdateToLimited
  test('validateQuoteRatingAfterPermissiveUserLimitOfLiabilityUpdateToLimited', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.QuoteSummaryTests#validateQuoteRatingAfterPermissiveUserLimitOfLiabilityUpdateToLimited',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1461,
      className: 'QuoteSummaryTests',
      method: 'validateQuoteRatingAfterPermissiveUserLimitOfLiabilityUpdateToLimited',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {CA})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#verifyCustomizedCoverageValuesForCAAutoQuoteOnRetrieval
  test('verifyCustomizedCoverageValuesForCAAutoQuoteOnRetrieval', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#verifyCustomizedCoverageValuesForCAAutoQuoteOnRetrieval',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1477,
      className: 'QuoteSummaryTests',
      method: 'verifyCustomizedCoverageValuesForCAAutoQuoteOnRetrieval',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {CA})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#testVerifyResetButtonDisablesAfterRevertingAllCoveragesToOriginal
  test('testVerifyResetButtonDisablesAfterRevertingAllCoveragesToOriginal', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.QuoteSummaryTests#testVerifyResetButtonDisablesAfterRevertingAllCoveragesToOriginal',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1495,
      className: 'QuoteSummaryTests',
      method: 'testVerifyResetButtonDisablesAfterRevertingAllCoveragesToOriginal',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateTheTlSourceCodeFunctionality
  test('validateTheTlSourceCodeFunctionality', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateTheTlSourceCodeFunctionality',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1514,
      className: 'QuoteSummaryTests',
      method: 'validateTheTlSourceCodeFunctionality',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI, BW_ACE_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI, BW_ACE_TESTS}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL, AZ, AR, GA, ID, KY, OH, OK, OR, SD, WA, WY}), @CustomAttribute(name = FILTER, values = "applicantId=1")})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateTheMLBSourceCodeFunctionality
  test('validateTheMLBSourceCodeFunctionality', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateTheMLBSourceCodeFunctionality',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1552,
      className: 'QuoteSummaryTests',
      method: 'validateTheMLBSourceCodeFunctionality',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI, BW_ACE_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI, BW_ACE_TESTS}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {OR, WA,AL, AR, CA, CO, CT, FL, IL, IN, IA, KS, KY, LA, MD, MI, MS, MO, NV, NM, OH, OK, TX, TN, VA, WI,MT,ID}), @CustomAttribute(name = FILTER, values = "applicantId=1")})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateNoExceptionOnBrowserBackNavigationFromSignalPage
  test('validateNoExceptionOnBrowserBackNavigationFromSignalPage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateNoExceptionOnBrowserBackNavigationFromSignalPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1609,
      className: 'QuoteSummaryTests',
      method: 'validateNoExceptionOnBrowserBackNavigationFromSignalPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateADPFOrderedFlagInQuoteXML
  test('validateADPFOrderedFlagInQuoteXML', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateADPFOrderedFlagInQuoteXML',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1632,
      className: 'QuoteSummaryTests',
      method: 'validateADPFOrderedFlagInQuoteXML',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {CO})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateADPFNotOrderedFlagInQuoteXML_NonAdpf_Data
  test('validateADPFNotOrderedFlagInQuoteXML_NonAdpf_Data', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateADPFNotOrderedFlagInQuoteXML_NonAdpf_Data',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1656,
      className: 'QuoteSummaryTests',
      method: 'validateADPFNotOrderedFlagInQuoteXML_NonAdpf_Data',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA})})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#verifyPayRollDeductionForNonAWSFlow
  test('verifyPayRollDeductionForNonAWSFlow', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#verifyPayRollDeductionForNonAWSFlow',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1681,
      className: 'QuoteSummaryTests',
      method: 'verifyPayRollDeductionForNonAWSFlow',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{ADDRESS_ONEUI, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#verifyPayRollDeductionForAWSFlow
  test('verifyPayRollDeductionForAWSFlow', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#verifyPayRollDeductionForAWSFlow',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1719,
      className: 'QuoteSummaryTests',
      method: 'verifyPayRollDeductionForAWSFlow',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{ADDRESS_ONEUI, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {ADDRESS_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.QuoteSummaryTests#validateMarinersPopUpOnReviewQuoteScreen
  test('validateMarinersPopUpOnReviewQuoteScreen', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.QuoteSummaryTests#validateMarinersPopUpOnReviewQuoteScreen',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/QuoteSummaryTests.java',
      sourceLine: 1760,
      className: 'QuoteSummaryTests',
      method: 'validateMarinersPopUpOnReviewQuoteScreen',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{QUOTE_SUMMARY, FFQ_ONEUI}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI}, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {ID, MT, OR, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")})',
    });
  });
});
