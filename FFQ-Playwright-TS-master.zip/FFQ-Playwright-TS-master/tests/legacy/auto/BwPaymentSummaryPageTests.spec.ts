// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests', () => {
  // legacy-id: com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateBwPaymentSummaryPageWithRetrieval
  test('validateBwPaymentSummaryPageWithRetrieval', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateBwPaymentSummaryPageWithRetrieval',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwPaymentSummaryPageTests.java',
      sourceLine: 38,
      className: 'BwPaymentSummaryPageTests',
      method: 'validateBwPaymentSummaryPageWithRetrieval',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}) }, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validatePayInFullPage
  test('validatePayInFullPage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validatePayInFullPage',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwPaymentSummaryPageTests.java',
      sourceLine: 63,
      className: 'BwPaymentSummaryPageTests',
      method: 'validatePayInFullPage',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, IL, IN, MO, OH, OK, OR, TX, UT, WI, SD, MI, PA, WY, KS, CO, NM, IA, VA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateMonthlyPayBank
  test('validateMonthlyPayBank', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateMonthlyPayBank',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwPaymentSummaryPageTests.java',
      sourceLine: 78,
      className: 'BwPaymentSummaryPageTests',
      method: 'validateMonthlyPayBank',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, IL, IN, MO, OH, OK, OR, TX, UT, WI, SD, MI, PA, WY, KS, CO, NM, IA, VA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateMonthlyPayCard
  test('validateMonthlyPayCard', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateMonthlyPayCard',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwPaymentSummaryPageTests.java',
      sourceLine: 93,
      className: 'BwPaymentSummaryPageTests',
      method: 'validateMonthlyPayCard',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, IL, IN, MO, OH, OK, OR, TX, UT, WI, SD, MI, PA, WY, KS, CO, NM, IA, VA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateMonthlyDirectBill
  test('validateMonthlyDirectBill', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateMonthlyDirectBill',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwPaymentSummaryPageTests.java',
      sourceLine: 108,
      className: 'BwPaymentSummaryPageTests',
      method: 'validateMonthlyDirectBill',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, IL, IN, MO, OH, OK, OR, TX, UT, WI, SD, MI, PA, WY, KS, CO, NM, IA, VA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#switchPaymentMethodAndBind
  test('switchPaymentMethodAndBind', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#switchPaymentMethodAndBind',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwPaymentSummaryPageTests.java',
      sourceLine: 130,
      className: 'BwPaymentSummaryPageTests',
      method: 'switchPaymentMethodAndBind',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {MT, CA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_PayInFull
  test('validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_PayInFull', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_PayInFull',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwPaymentSummaryPageTests.java',
      sourceLine: 172,
      className: 'BwPaymentSummaryPageTests',
      method: 'validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_PayInFull',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyAutoPayBank
  test('validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyAutoPayBank', async ({
    page,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyAutoPayBank',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwPaymentSummaryPageTests.java',
      sourceLine: 198,
      className: 'BwPaymentSummaryPageTests',
      method: 'validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyAutoPayBank',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyAutoPayCard
  test('validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyAutoPayCard', async ({
    page,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyAutoPayCard',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwPaymentSummaryPageTests.java',
      sourceLine: 224,
      className: 'BwPaymentSummaryPageTests',
      method: 'validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyAutoPayCard',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyDirectBill
  test('validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyDirectBill', async ({
    page,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyDirectBill',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwPaymentSummaryPageTests.java',
      sourceLine: 250,
      className: 'BwPaymentSummaryPageTests',
      method: 'validateUserIsAbleAddPaymentMethodFromScratchAfterDeclinePopUp_MonthlyDirectBill',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateGoodDistantStudentDiscountAreNotDroppedAfterVerifyBW
  test('validateGoodDistantStudentDiscountAreNotDroppedAfterVerifyBW', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.bind.bw.BwPaymentSummaryPageTests#validateGoodDistantStudentDiscountAreNotDroppedAfterVerifyBW',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/bind/bw/BwPaymentSummaryPageTests.java',
      sourceLine: 300,
      className: 'BwPaymentSummaryPageTests',
      method: 'validateGoodDistantStudentDiscountAreNotDroppedAfterVerifyBW',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, BDQ_TESTS}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"}), @CustomAttribute(name = INCLUDED_STATES, values = {GA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, BDQ_TESTS})',
    });
  });
});
