// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.DriverReviewTests', () => {
  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#testReviewDrivers_happy_path
  test('testReviewDrivers_happy_path', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#testReviewDrivers_happy_path',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 36,
      className: 'DriverReviewTests',
      method: 'testReviewDrivers_happy_path',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CO, MI, AR, AZ, ID, IL, IN, MN, MO, NM, OH, OK, OR, TN, VA, WA, GA, WI})}, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validatePageWithMarriedApplicant
  test('validatePageWithMarriedApplicant', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validatePageWithMarriedApplicant',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 45,
      className: 'DriverReviewTests',
      method: 'validatePageWithMarriedApplicant',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=31"}), @CustomAttribute(name = EXCLUDED_STATES, values = {GA, WI, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NM, NJ, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validatePageWithTwoAdditionalDrivers
  test('validatePageWithTwoAdditionalDrivers', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validatePageWithTwoAdditionalDrivers',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 52,
      className: 'DriverReviewTests',
      method: 'validatePageWithTwoAdditionalDrivers',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=30"}), @CustomAttribute(name = EXCLUDED_STATES, values = {GA, WI, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validatePageWithThreeAdditionalDrivers
  test('validatePageWithThreeAdditionalDrivers', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validatePageWithThreeAdditionalDrivers',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 59,
      className: 'DriverReviewTests',
      method: 'validatePageWithThreeAdditionalDrivers',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=31"}), @CustomAttribute(name = EXCLUDED_STATES, values = {GA, WI, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validatePageWithFourAdditionalDrivers
  test('validatePageWithFourAdditionalDrivers', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validatePageWithFourAdditionalDrivers',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 66,
      className: 'DriverReviewTests',
      method: 'validatePageWithFourAdditionalDrivers',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=12"}), @CustomAttribute(name = EXCLUDED_STATES, values = {GA, WI, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, FL})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validatePageWithYoungApplicant
  test('validatePageWithYoungApplicant', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validatePageWithYoungApplicant',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 73,
      className: 'DriverReviewTests',
      method: 'validatePageWithYoungApplicant',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=22"}), @CustomAttribute(name = EXCLUDED_STATES, values = {GA, WI, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, FL})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validatePageWithOldApplicant
  test('validatePageWithOldApplicant', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validatePageWithOldApplicant',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 80,
      className: 'DriverReviewTests',
      method: 'validatePageWithOldApplicant',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=7"}), @CustomAttribute(name = EXCLUDED_STATES, values = {GA, WI, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, FL})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validatePageWithIncidents
  test('validatePageWithIncidents', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validatePageWithIncidents',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 87,
      className: 'DriverReviewTests',
      method: 'validatePageWithIncidents',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=28"}), @CustomAttribute(name = EXCLUDED_STATES, values = {GA, WI, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, FL})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validateDisplayedOccupationList
  test('validateDisplayedOccupationList', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validateDisplayedOccupationList',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 94,
      className: 'DriverReviewTests',
      method: 'validateDisplayedOccupationList',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW, "occupationListValidation"}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=28"}), @CustomAttribute(name = EXCLUDED_STATES, values = {GA, WI, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, FL})}, groups = {FFQ_ONEUI, DRIVER_REVIEW, "occupationListValidation"})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validateOccupationCodes
  test.skip('validateOccupationCodes', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validateOccupationCodes',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 104,
      className: 'DriverReviewTests',
      method: 'validateOccupationCodes',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW, "occupationListValidation"}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {GA, WI, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, FL})}, groups = {FFQ_ONEUI, DRIVER_REVIEW, "occupationListValidation"})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validateDriverLicenseAgeSection
  test('validateDriverLicenseAgeSection', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validateDriverLicenseAgeSection',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 113,
      className: 'DriverReviewTests',
      method: 'validateDriverLicenseAgeSection',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE',
      groups: '{FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA, LA, MA})}, groups = {FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validateDriverLicenseNumberInputSection
  test('validateDriverLicenseNumberInputSection', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validateDriverLicenseNumberInputSection',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 136,
      className: 'DriverReviewTests',
      method: 'validateDriverLicenseNumberInputSection',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{BW_ACE_TESTS, ADA_SUITE, ACE_AUTO_ADA_SUITE, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MA}), @CustomAttribute(name = FILTER, values = "applicantId=34")}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, ADA_SUITE, ACE_AUTO_ADA_SUITE, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validateStudentDiscountsNotRemovedWhenLicenseCheckboxUnchecked
  test('validateStudentDiscountsNotRemovedWhenLicenseCheckboxUnchecked', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validateStudentDiscountsNotRemovedWhenLicenseCheckboxUnchecked',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 172,
      className: 'DriverReviewTests',
      method: 'validateStudentDiscountsNotRemovedWhenLicenseCheckboxUnchecked',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"}), @CustomAttribute(name = EXCLUDED_STATES, values = {KY, NC, LA, MA, CA, AR, AZ, CO, ID, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, WI, GA})}, dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#testGoodStudentQuestionAndDiscount
  test('testGoodStudentQuestionAndDiscount', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#testGoodStudentQuestionAndDiscount',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 192,
      className: 'DriverReviewTests',
      method: 'testGoodStudentQuestionAndDiscount',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, FL, GA, ID, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, SD, TN, VA, WA, WI})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#testDistantStudentQuestionAndDiscount
  test('testDistantStudentQuestionAndDiscount', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#testDistantStudentQuestionAndDiscount',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 203,
      className: 'DriverReviewTests',
      method: 'testDistantStudentQuestionAndDiscount',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=10"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, GA, WI})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#testSharedFamilyCarQuestionAndDiscount
  test('testSharedFamilyCarQuestionAndDiscount', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#testSharedFamilyCarQuestionAndDiscount',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 214,
      className: 'DriverReviewTests',
      method: 'testSharedFamilyCarQuestionAndDiscount',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=34"}), @CustomAttribute(name = EXCLUDED_STATES, values = {WA, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, MT, GA, WI})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validateOrderOfDriversInDriversReviewPage_ADPFDATA
  test('validateOrderOfDriversInDriversReviewPage_ADPFDATA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validateOrderOfDriversInDriversReviewPage_ADPFDATA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 226,
      className: 'DriverReviewTests',
      method: 'validateOrderOfDriversInDriversReviewPage_ADPFDATA',
      parameters: 'ADPFApplicant applicant',
      dataProvider: 'AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: '',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_AND_VEHICLES), @CustomAttribute(name = EXCLUDED_STATES, values = {CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, GA, WI})}, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validateOrderOfDriversInDriversReviewPage_NonADPFDATA
  test('validateOrderOfDriversInDriversReviewPage_NonADPFDATA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validateOrderOfDriversInDriversReviewPage_NonADPFDATA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 232,
      className: 'DriverReviewTests',
      method: 'validateOrderOfDriversInDriversReviewPage_NonADPFDATA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=12"}), @CustomAttribute(name = EXCLUDED_STATES, values = {MT, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, GA, WI})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validateNon_DriverSpouseHandling
  test('validateNon_DriverSpouseHandling', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validateNon_DriverSpouseHandling',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 250,
      className: 'DriverReviewTests',
      method: 'validateNon_DriverSpouseHandling',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=5"), @CustomAttribute(name = INCLUDED_STATES, values = {CA, PA, TX})}, groups = {FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validateMatureDriverFunctionalityNonStreamLine
  test('validateMatureDriverFunctionalityNonStreamLine', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validateMatureDriverFunctionalityNonStreamLine',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 314,
      className: 'DriverReviewTests',
      method: 'validateMatureDriverFunctionalityNonStreamLine',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL, CT, KS, KY, MA, MS, MT, ND, NV, SD, UT, WY, PA}), @CustomAttribute(name = FILTER, values = "applicantId=26")}, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validateMatureDriverDiscountBDQNonStreamLine
  test('validateMatureDriverDiscountBDQNonStreamLine', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validateMatureDriverDiscountBDQNonStreamLine',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 345,
      className: 'DriverReviewTests',
      method: 'validateMatureDriverDiscountBDQNonStreamLine',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BDQ_TESTS, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=26"), @CustomAttribute(name = INCLUDED_STATES, values = {AL, CT, FL, IA, KS, KY, LA, MA, MD, MS, MT, NC, ND, NE, NJ, NV, OH, PA, SD, TX, UT, WY})}, groups = {BDQ_TESTS, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validateMatureDriverDiscountAfterBrightLineNonStreamLine
  test('validateMatureDriverDiscountAfterBrightLineNonStreamLine', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validateMatureDriverDiscountAfterBrightLineNonStreamLine',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 384,
      className: 'DriverReviewTests',
      method: 'validateMatureDriverDiscountAfterBrightLineNonStreamLine',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{BW_ACE_TESTS, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL, CT, FL, IA, KS, KY, LA, MA, MD, MS, MT, NC, ND, NE, NJ, NV, OH, PA, SD, TX, UT, WY}), @CustomAttribute(name = FILTER, values = "applicantId=26")}, groups = {BW_ACE_TESTS, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#testFinancialResponsibilityCaseNumberField
  test('testFinancialResponsibilityCaseNumberField', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#testFinancialResponsibilityCaseNumberField',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 426,
      className: 'DriverReviewTests',
      method: 'testFinancialResponsibilityCaseNumberField',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.FINANCIAL_RESPONSIBILITY_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.FINANCIAL_RESPONSIBILITY_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {FL})}, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#verifySpouseNonDriverStatusPersistsAndIsNotAutoUpdatedAfterRefresh
  test('verifySpouseNonDriverStatusPersistsAndIsNotAutoUpdatedAfterRefresh', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.auto.DriverReviewTests#verifySpouseNonDriverStatusPersistsAndIsNotAutoUpdatedAfterRefresh',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 439,
      className: 'DriverReviewTests',
      method: 'verifySpouseNonDriverStatusPersistsAndIsNotAutoUpdatedAfterRefresh',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=5"), @CustomAttribute(name = INCLUDED_STATES, values = {CA, TX})}, groups = {FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, DRIVER_REVIEW})',
    });
  });

  // legacy-id: com.farmers.ffq.auto.DriverReviewTests#validateErrorsForAgeLicensedInBackAndForthTest
  test('validateErrorsForAgeLicensedInBackAndForthTest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.DriverReviewTests#validateErrorsForAgeLicensedInBackAndForthTest',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/DriverReviewTests.java',
      sourceLine: 450,
      className: 'DriverReviewTests',
      method: 'validateErrorsForAgeLicensedInBackAndForthTest',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{FFQ_ONEUI, DRIVER_REVIEW}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=24"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, GA, WI})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})',
    });
  });
});
