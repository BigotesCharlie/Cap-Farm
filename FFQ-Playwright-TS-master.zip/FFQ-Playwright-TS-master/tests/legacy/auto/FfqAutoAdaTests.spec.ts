// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.auto.FfqAutoAdaTests', () => {
  // legacy-id: com.farmers.ffq.auto.FfqAutoAdaTests#validateADA
  test('validateADA', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.auto.FfqAutoAdaTests#validateADA',
      domain: 'auto',
      sourceFile: 'src/test/java/com/farmers/ffq/auto/FfqAutoAdaTests.java',
      sourceLine: 26,
      className: 'FfqAutoAdaTests',
      method: 'validateADA',
      parameters: 'AutoApplicant applicant',
      dataProvider: 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER',
      dataProviderClass: 'AutoDataProviders.class',
      testName: 'AutoDataProviders.RANDOM_AUTO_APPLICANT',
      groups: '{ADA_SUITE, ACE_AUTO_ADA_SUITE}',
      annotation:
        '@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {ADA_SUITE, ACE_AUTO_ADA_SUITE})',
    });
  });
});
