// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPartnerIntegrationTests', () => {
  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPartnerIntegrationTests#verifyMediaAlphaSpecialtyDwellingPropertyTypePageContent
  test.skip('verifyMediaAlphaSpecialtyDwellingPropertyTypePageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPartnerIntegrationTests#verifyMediaAlphaSpecialtyDwellingPropertyTypePageContent',
      domain: 'specialtyDwelling',
      sourceFile:
        'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPartnerIntegrationTests.java',
      sourceLine: 22,
      className: 'AceHomeSpecialtyDwellingPartnerIntegrationTests',
      method: 'verifyMediaAlphaSpecialtyDwellingPropertyTypePageContent',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {SPECIALTY_DWELLING}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPartnerIntegrationTests#verifyMediaAlphaQuoteReviewPageContentParttime
  test.skip('verifyMediaAlphaQuoteReviewPageContentParttime', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPartnerIntegrationTests#verifyMediaAlphaQuoteReviewPageContentParttime',
      domain: 'specialtyDwelling',
      sourceFile:
        'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPartnerIntegrationTests.java',
      sourceLine: 29,
      className: 'AceHomeSpecialtyDwellingPartnerIntegrationTests',
      method: 'verifyMediaAlphaQuoteReviewPageContentParttime',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {SPECIALTY_DWELLING}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPartnerIntegrationTests#verifyMediaAlphaQuoteReviewPageContentRenter
  test.skip('verifyMediaAlphaQuoteReviewPageContentRenter', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPartnerIntegrationTests#verifyMediaAlphaQuoteReviewPageContentRenter',
      domain: 'specialtyDwelling',
      sourceFile:
        'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPartnerIntegrationTests.java',
      sourceLine: 36,
      className: 'AceHomeSpecialtyDwellingPartnerIntegrationTests',
      method: 'verifyMediaAlphaQuoteReviewPageContentRenter',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {SPECIALTY_DWELLING}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPartnerIntegrationTests#verifyMediaAlphaQuoteReviewPageContentShortRenter
  test.skip('verifyMediaAlphaQuoteReviewPageContentShortRenter', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPartnerIntegrationTests#verifyMediaAlphaQuoteReviewPageContentShortRenter',
      domain: 'specialtyDwelling',
      sourceFile:
        'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPartnerIntegrationTests.java',
      sourceLine: 43,
      className: 'AceHomeSpecialtyDwellingPartnerIntegrationTests',
      method: 'verifyMediaAlphaQuoteReviewPageContentShortRenter',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {SPECIALTY_DWELLING}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPartnerIntegrationTests#verifyMediaAlphaQuoteReviewPageContentVacant
  test.skip('verifyMediaAlphaQuoteReviewPageContentVacant', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPartnerIntegrationTests#verifyMediaAlphaQuoteReviewPageContentVacant',
      domain: 'specialtyDwelling',
      sourceFile:
        'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPartnerIntegrationTests.java',
      sourceLine: 50,
      className: 'AceHomeSpecialtyDwellingPartnerIntegrationTests',
      method: 'verifyMediaAlphaQuoteReviewPageContentVacant',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {SPECIALTY_DWELLING}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPartnerIntegrationTests#verifyMediaAlphaExpectedDiscounts
  test.skip('verifyMediaAlphaExpectedDiscounts', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPartnerIntegrationTests#verifyMediaAlphaExpectedDiscounts',
      domain: 'specialtyDwelling',
      sourceFile:
        'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPartnerIntegrationTests.java',
      sourceLine: 57,
      className: 'AceHomeSpecialtyDwellingPartnerIntegrationTests',
      method: 'verifyMediaAlphaExpectedDiscounts',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = EXCLUDE_UNCONFIGURED_MEDIA_ALPHA_STATES)}, groups = {SPECIALTY_DWELLING}, enabled = false)',
    });
  });
});
