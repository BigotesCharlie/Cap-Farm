// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests', () => {
  // legacy-id: com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests#verifyForemostDwellingTellUsMorePageContent
  test('verifyForemostDwellingTellUsMorePageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests#verifyForemostDwellingTellUsMorePageContent',
      domain: 'specialtyDwelling',
      sourceFile:
        'src/test/java/com/farmers/ffq/specialtyDwelling/ForemostHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 24,
      className: 'ForemostHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyForemostDwellingTellUsMorePageContent',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests#verifyForemostAdditionalDwellingInformationPageContent
  test('verifyForemostAdditionalDwellingInformationPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests#verifyForemostAdditionalDwellingInformationPageContent',
      domain: 'specialtyDwelling',
      sourceFile:
        'src/test/java/com/farmers/ffq/specialtyDwelling/ForemostHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 30,
      className: 'ForemostHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyForemostAdditionalDwellingInformationPageContent',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests#verifyForemostOtherPolicyQuestionsPageContent
  test('verifyForemostOtherPolicyQuestionsPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests#verifyForemostOtherPolicyQuestionsPageContent',
      domain: 'specialtyDwelling',
      sourceFile:
        'src/test/java/com/farmers/ffq/specialtyDwelling/ForemostHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 36,
      className: 'ForemostHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyForemostOtherPolicyQuestionsPageContent',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, GA, MO, PA})}, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests#verifyForemostQuoteReviewPageContentParttime
  test('verifyForemostQuoteReviewPageContentParttime', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests#verifyForemostQuoteReviewPageContentParttime',
      domain: 'specialtyDwelling',
      sourceFile:
        'src/test/java/com/farmers/ffq/specialtyDwelling/ForemostHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 43,
      className: 'ForemostHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyForemostQuoteReviewPageContentParttime',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, GA, MO, PA})}, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests#verifyForemostQuoteReviewPageContentRenter
  test('verifyForemostQuoteReviewPageContentRenter', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests#verifyForemostQuoteReviewPageContentRenter',
      domain: 'specialtyDwelling',
      sourceFile:
        'src/test/java/com/farmers/ffq/specialtyDwelling/ForemostHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 50,
      className: 'ForemostHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyForemostQuoteReviewPageContentRenter',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests#verifyForemostQuoteReviewPageContentShortRenter
  test('verifyForemostQuoteReviewPageContentShortRenter', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests#verifyForemostQuoteReviewPageContentShortRenter',
      domain: 'specialtyDwelling',
      sourceFile:
        'src/test/java/com/farmers/ffq/specialtyDwelling/ForemostHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 56,
      className: 'ForemostHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyForemostQuoteReviewPageContentShortRenter',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests#verifyForemostQuoteReviewPageContentVacant
  test('verifyForemostQuoteReviewPageContentVacant', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.ForemostHomeSpecialtyDwellingPageValidationTests#verifyForemostQuoteReviewPageContentVacant',
      domain: 'specialtyDwelling',
      sourceFile:
        'src/test/java/com/farmers/ffq/specialtyDwelling/ForemostHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 62,
      className: 'ForemostHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyForemostQuoteReviewPageContentVacant',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, groups = {SPECIALTY_DWELLING})',
    });
  });
});
