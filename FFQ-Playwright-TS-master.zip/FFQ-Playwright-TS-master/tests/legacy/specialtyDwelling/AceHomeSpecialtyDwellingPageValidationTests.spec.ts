// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests', () => {
  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyPropertyTypePageContent
  test('verifyPropertyTypePageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyPropertyTypePageContent',
      domain: 'specialtyDwelling',
      sourceFile: 'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 25,
      className: 'AceHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyPropertyTypePageContent',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING)}, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyDwellingTellUsMorePageContent
  test('verifyDwellingTellUsMorePageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyDwellingTellUsMorePageContent',
      domain: 'specialtyDwelling',
      sourceFile: 'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 31,
      className: 'AceHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyDwellingTellUsMorePageContent',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES)}, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#validateDwellingTellUsMoreErrorHandling
  test('validateDwellingTellUsMoreErrorHandling', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#validateDwellingTellUsMoreErrorHandling',
      domain: 'specialtyDwelling',
      sourceFile: 'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 37,
      className: 'AceHomeSpecialtyDwellingPageValidationTests',
      method: 'validateDwellingTellUsMoreErrorHandling',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES)}, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyAdditionalDwellingInformationPageContent
  test('verifyAdditionalDwellingInformationPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyAdditionalDwellingInformationPageContent',
      domain: 'specialtyDwelling',
      sourceFile: 'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 43,
      className: 'AceHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyAdditionalDwellingInformationPageContent',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES)}, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyOtherPolicyQuestionsPageContent
  test('verifyOtherPolicyQuestionsPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyOtherPolicyQuestionsPageContent',
      domain: 'specialtyDwelling',
      sourceFile: 'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 49,
      className: 'AceHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyOtherPolicyQuestionsPageContent',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, GA, MO, PA})}, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyQuoteReviewPageContentParttime
  test('verifyQuoteReviewPageContentParttime', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyQuoteReviewPageContentParttime',
      domain: 'specialtyDwelling',
      sourceFile: 'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 55,
      className: 'AceHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyQuoteReviewPageContentParttime',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES), @CustomAttribute(name = EXCLUDED_STATES, values = {AZ, GA, MO, PA})}, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyQuoteReviewPageContentRenter
  test('verifyQuoteReviewPageContentRenter', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyQuoteReviewPageContentRenter',
      domain: 'specialtyDwelling',
      sourceFile: 'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 61,
      className: 'AceHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyQuoteReviewPageContentRenter',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES)}, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyQuoteReviewPageContentShortRenter
  test('verifyQuoteReviewPageContentShortRenter', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyQuoteReviewPageContentShortRenter',
      domain: 'specialtyDwelling',
      sourceFile: 'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 67,
      className: 'AceHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyQuoteReviewPageContentShortRenter',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES), @CustomAttribute(name = EXCLUDED_STATES, values = {CA})}, groups = {SPECIALTY_DWELLING})',
    });
  });

  // legacy-id: com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyQuoteReviewPageContentVacant
  test('verifyQuoteReviewPageContentVacant', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.specialtyDwelling.AceHomeSpecialtyDwellingPageValidationTests#verifyQuoteReviewPageContentVacant',
      domain: 'specialtyDwelling',
      sourceFile: 'src/test/java/com/farmers/ffq/specialtyDwelling/AceHomeSpecialtyDwellingPageValidationTests.java',
      sourceLine: 73,
      className: 'AceHomeSpecialtyDwellingPageValidationTests',
      method: 'verifyQuoteReviewPageContentVacant',
      parameters: 'ApplicantAceHome specialtyDwellingApplicant',
      dataProvider: 'DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER',
      dataProviderClass: 'DataProviders.class',
      testName: 'DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES',
      groups: '{SPECIALTY_DWELLING}',
      annotation:
        '@Test(dataProviderClass = DataProviders.class, dataProvider = DataProviders.ACE_MOBILEHOME_APPLICANTS_DATA_PROVIDER, testName = DataProviders.ONE_MOBILEHOME_APPLICANT_PER_RANDOM_STATES, attributes = {@CustomAttribute(name = SPECIALTY_DWELLING), @CustomAttribute(name = REMOVE_SPECIALTY_REDSTATES)}, groups = {SPECIALTY_DWELLING})',
    });
  });
});
