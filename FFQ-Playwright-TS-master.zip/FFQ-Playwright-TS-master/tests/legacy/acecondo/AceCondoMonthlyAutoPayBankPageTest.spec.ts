// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayBankPageTest', () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayBankPageTest#testValidateContentOfMonthlyAutoPayBankPageOnLandingAceCondo
  test('testValidateContentOfMonthlyAutoPayBankPageOnLandingAceCondo', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayBankPageTest#testValidateContentOfMonthlyAutoPayBankPageOnLandingAceCondo',
      domain: 'acecondo',
      sourceFile: 'src/test/java/com/farmers/ffq/acecondo/AceCondoMonthlyAutoPayBankPageTest.java',
      sourceLine: 20,
      className: 'AceCondoMonthlyAutoPayBankPageTest',
      method: 'testValidateContentOfMonthlyAutoPayBankPageOnLandingAceCondo',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MT,NC,MS,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayBankPageTest#testChangingMonthlyPayBankToPayInFullCardPaymentAceCondo
  test('testChangingMonthlyPayBankToPayInFullCardPaymentAceCondo', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayBankPageTest#testChangingMonthlyPayBankToPayInFullCardPaymentAceCondo',
      domain: 'acecondo',
      sourceFile: 'src/test/java/com/farmers/ffq/acecondo/AceCondoMonthlyAutoPayBankPageTest.java',
      sourceLine: 35,
      className: 'AceCondoMonthlyAutoPayBankPageTest',
      method: 'testChangingMonthlyPayBankToPayInFullCardPaymentAceCondo',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_CONDO, FFQ_ACE_HOME_BIND, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_HOME_BIND, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayBankPageTest#testMonthlyAutoPayCreditCardPaymentEndToEndAceCondo
  test('testMonthlyAutoPayCreditCardPaymentEndToEndAceCondo', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayBankPageTest#testMonthlyAutoPayCreditCardPaymentEndToEndAceCondo',
      domain: 'acecondo',
      sourceFile: 'src/test/java/com/farmers/ffq/acecondo/AceCondoMonthlyAutoPayBankPageTest.java',
      sourceLine: 74,
      className: 'AceCondoMonthlyAutoPayBankPageTest',
      method: 'testMonthlyAutoPayCreditCardPaymentEndToEndAceCondo',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayBankPageTest#testMonthlyAutoPayBankChangeBankPaymentToCardEndToEndAceCondo
  test('testMonthlyAutoPayBankChangeBankPaymentToCardEndToEndAceCondo', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayBankPageTest#testMonthlyAutoPayBankChangeBankPaymentToCardEndToEndAceCondo',
      domain: 'acecondo',
      sourceFile: 'src/test/java/com/farmers/ffq/acecondo/AceCondoMonthlyAutoPayBankPageTest.java',
      sourceLine: 98,
      className: 'AceCondoMonthlyAutoPayBankPageTest',
      method: 'testMonthlyAutoPayBankChangeBankPaymentToCardEndToEndAceCondo',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_CONDO, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayBankPageTest#testMonthlyAutoPayBankChangeCreditCardPaymentToBankEndToEndAceCondo
  test('testMonthlyAutoPayBankChangeCreditCardPaymentToBankEndToEndAceCondo', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acecondo.AceCondoMonthlyAutoPayBankPageTest#testMonthlyAutoPayBankChangeCreditCardPaymentToBankEndToEndAceCondo',
      domain: 'acecondo',
      sourceFile: 'src/test/java/com/farmers/ffq/acecondo/AceCondoMonthlyAutoPayBankPageTest.java',
      sourceLine: 126,
      className: 'AceCondoMonthlyAutoPayBankPageTest',
      method: 'testMonthlyAutoPayBankChangeCreditCardPaymentToBankEndToEndAceCondo',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_CONDO, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_MONTHLY_AUTOPAY_BANK_PAGE})',
    });
  });
});
