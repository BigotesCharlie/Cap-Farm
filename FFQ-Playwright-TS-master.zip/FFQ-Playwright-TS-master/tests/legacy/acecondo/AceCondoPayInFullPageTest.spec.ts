// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.acecondo.AceCondoPayInFullPageTest', () => {
  // legacy-id: com.farmers.ffq.acecondo.AceCondoPayInFullPageTest#testValidateContentOfPayInFullPageAndNavigateToJFMTPageAceCondo
  test('testValidateContentOfPayInFullPageAndNavigateToJFMTPageAceCondo', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acecondo.AceCondoPayInFullPageTest#testValidateContentOfPayInFullPageAndNavigateToJFMTPageAceCondo',
      domain: 'acecondo',
      sourceFile: 'src/test/java/com/farmers/ffq/acecondo/AceCondoPayInFullPageTest.java',
      sourceLine: 23,
      className: 'AceCondoPayInFullPageTest',
      method: 'testValidateContentOfPayInFullPageAndNavigateToJFMTPageAceCondo',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoPayInFullPageTest#testValidateContentOfPayInFullPageAndECheckoutWithLenderSelectedAceCondo
  test('testValidateContentOfPayInFullPageAndECheckoutWithLenderSelectedAceCondo', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acecondo.AceCondoPayInFullPageTest#testValidateContentOfPayInFullPageAndECheckoutWithLenderSelectedAceCondo',
      domain: 'acecondo',
      sourceFile: 'src/test/java/com/farmers/ffq/acecondo/AceCondoPayInFullPageTest.java',
      sourceLine: 44,
      className: 'AceCondoPayInFullPageTest',
      method: 'testValidateContentOfPayInFullPageAndECheckoutWithLenderSelectedAceCondo',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoPayInFullPageTest#testValidateContentOfPayInFullPageAndECheckoutWithRenewalSelectedAceCondo
  test('testValidateContentOfPayInFullPageAndECheckoutWithRenewalSelectedAceCondo', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acecondo.AceCondoPayInFullPageTest#testValidateContentOfPayInFullPageAndECheckoutWithRenewalSelectedAceCondo',
      domain: 'acecondo',
      sourceFile: 'src/test/java/com/farmers/ffq/acecondo/AceCondoPayInFullPageTest.java',
      sourceLine: 60,
      className: 'AceCondoPayInFullPageTest',
      method: 'testValidateContentOfPayInFullPageAndECheckoutWithRenewalSelectedAceCondo',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoPayInFullPageTest#validatePaymentByChangingPayInFullBankToMonthlyPayCardAceCondo
  test('validatePaymentByChangingPayInFullBankToMonthlyPayCardAceCondo', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acecondo.AceCondoPayInFullPageTest#validatePaymentByChangingPayInFullBankToMonthlyPayCardAceCondo',
      domain: 'acecondo',
      sourceFile: 'src/test/java/com/farmers/ffq/acecondo/AceCondoPayInFullPageTest.java',
      sourceLine: 82,
      className: 'AceCondoPayInFullPageTest',
      method: 'validatePaymentByChangingPayInFullBankToMonthlyPayCardAceCondo',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MO,MS,MT,NC,UT})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoPayInFullPageTest#testPayInFullCreditCardEndToEndAceCondo
  test('testPayInFullCreditCardEndToEndAceCondo', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acecondo.AceCondoPayInFullPageTest#testPayInFullCreditCardEndToEndAceCondo',
      domain: 'acecondo',
      sourceFile: 'src/test/java/com/farmers/ffq/acecondo/AceCondoPayInFullPageTest.java',
      sourceLine: 117,
      className: 'AceCondoPayInFullPageTest',
      method: 'testPayInFullCreditCardEndToEndAceCondo',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_CRITICAL, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoPayInFullPageTest#testPayInFullChangeBankPaymentToCardPaymentEndToEndAceCondo
  test('testPayInFullChangeBankPaymentToCardPaymentEndToEndAceCondo', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acecondo.AceCondoPayInFullPageTest#testPayInFullChangeBankPaymentToCardPaymentEndToEndAceCondo',
      domain: 'acecondo',
      sourceFile: 'src/test/java/com/farmers/ffq/acecondo/AceCondoPayInFullPageTest.java',
      sourceLine: 141,
      className: 'AceCondoPayInFullPageTest',
      method: 'testPayInFullChangeBankPaymentToCardPaymentEndToEndAceCondo',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_CONDO, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acecondo.AceCondoPayInFullPageTest#testPayInFullChangeCreditCardPaymentToBankPaymentEndToEndAceCondo
  test('testPayInFullChangeCreditCardPaymentToBankPaymentEndToEndAceCondo', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acecondo.AceCondoPayInFullPageTest#testPayInFullChangeCreditCardPaymentToBankPaymentEndToEndAceCondo',
      domain: 'acecondo',
      sourceFile: 'src/test/java/com/farmers/ffq/acecondo/AceCondoPayInFullPageTest.java',
      sourceLine: 166,
      className: 'AceCondoPayInFullPageTest',
      method: 'testPayInFullChangeCreditCardPaymentToBankPaymentEndToEndAceCondo',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_CONDO, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,MT,NC})}, groups = {FFQ_ACE_CONDO, FFQ_ACE_CONDO_PAY_IN_FULL_PAGE})',
    });
  });
});
