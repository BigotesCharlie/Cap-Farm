// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.acebundle.AceAutoRentersBundleTests', () => {
  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#aceAutoRentersBundleE2ETest
  test('aceAutoRentersBundleE2ETest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#aceAutoRentersBundleE2ETest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 34,
      className: 'AceAutoRentersBundleTests',
      method: 'aceAutoRentersBundleE2ETest',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyPaymentPagesContentAndUseSamePaymentDialogFunctionalityAR
  test('verifyPaymentPagesContentAndUseSamePaymentDialogFunctionalityAR', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyPaymentPagesContentAndUseSamePaymentDialogFunctionalityAR',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 49,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyPaymentPagesContentAndUseSamePaymentDialogFunctionalityAR',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAutoPayInFullCardAndRentersPayInFullBank
  test('verifyAutoPayInFullCardAndRentersPayInFullBank', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAutoPayInFullCardAndRentersPayInFullBank',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 86,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAutoPayInFullCardAndRentersPayInFullBank',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAutoMonthlyPayBankAndRentersMonthlyPayCard
  test('verifyAutoMonthlyPayBankAndRentersMonthlyPayCard', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAutoMonthlyPayBankAndRentersMonthlyPayCard',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 116,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAutoMonthlyPayBankAndRentersMonthlyPayCard',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#aceBWAutoRentersBundleE2EWithAutoMonthlyPayCardAndRentersMonthlyPayInBank
  test('aceBWAutoRentersBundleE2EWithAutoMonthlyPayCardAndRentersMonthlyPayInBank', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#aceBWAutoRentersBundleE2EWithAutoMonthlyPayCardAndRentersMonthlyPayInBank',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 141,
      className: 'AceAutoRentersBundleTests',
      method: 'aceBWAutoRentersBundleE2EWithAutoMonthlyPayCardAndRentersMonthlyPayInBank',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAutoPayInFullCardAndRentersPayInFullCardWithOneTimePayment
  test('verifyAutoPayInFullCardAndRentersPayInFullCardWithOneTimePayment', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAutoPayInFullCardAndRentersPayInFullCardWithOneTimePayment',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 160,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAutoPayInFullCardAndRentersPayInFullCardWithOneTimePayment',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAutoPolicyStartDatePageAndRC2PageContentAR
  test('verifyAutoPolicyStartDatePageAndRC2PageContentAR', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAutoPolicyStartDatePageAndRC2PageContentAR',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 186,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAutoPolicyStartDatePageAndRC2PageContentAR',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceBundleRentersFinalReviewQuotePage
  test('verifyAceBundleRentersFinalReviewQuotePage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceBundleRentersFinalReviewQuotePage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 198,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAceBundleRentersFinalReviewQuotePage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceBundleRentersJFMTPageAndNavigateBackToAutoJFMTP
  test('verifyAceBundleRentersJFMTPageAndNavigateBackToAutoJFMTP', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceBundleRentersJFMTPageAndNavigateBackToAutoJFMTP',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 210,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAceBundleRentersJFMTPageAndNavigateBackToAutoJFMTP',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceBundleRentersPropertyQuestionsPageContent
  test('verifyAceBundleRentersPropertyQuestionsPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceBundleRentersPropertyQuestionsPageContent',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 226,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAceBundleRentersPropertyQuestionsPageContent',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceAutoRentersBundleReviewPageContent
  test('verifyAceAutoRentersBundleReviewPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceAutoRentersBundleReviewPageContent',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 236,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAceAutoRentersBundleReviewPageContent',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceBWAutoRentersBundleReviewPageContent
  test('verifyAceBWAutoRentersBundleReviewPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceBWAutoRentersBundleReviewPageContent',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 249,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAceBWAutoRentersBundleReviewPageContent',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceAutoRentersBundleAutoQuoteReviewPageContent
  test('verifyAceAutoRentersBundleAutoQuoteReviewPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceAutoRentersBundleAutoQuoteReviewPageContent',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 262,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAceAutoRentersBundleAutoQuoteReviewPageContent',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceAutoRentersBundleAutoQuoteEditCoverage
  test('verifyAceAutoRentersBundleAutoQuoteEditCoverage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceAutoRentersBundleAutoQuoteEditCoverage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 272,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAceAutoRentersBundleAutoQuoteEditCoverage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceBundleRentersQuoteReviewPageContent
  test('verifyAceBundleRentersQuoteReviewPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceBundleRentersQuoteReviewPageContent',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 283,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAceBundleRentersQuoteReviewPageContent',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#aceBundleRentersRestrictedMonolineAutoTest
  test('aceBundleRentersRestrictedMonolineAutoTest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#aceBundleRentersRestrictedMonolineAutoTest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 301,
      className: 'AceAutoRentersBundleTests',
      method: 'aceBundleRentersRestrictedMonolineAutoTest',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, LA, MA, MS, MT})},dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#aceBundleMonolineRentersTest
  test('aceBundleMonolineRentersTest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#aceBundleMonolineRentersTest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 313,
      className: 'AceAutoRentersBundleTests',
      method: 'aceBundleMonolineRentersTest',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MT, TX})},dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyLimitedAvailabilityDialogContentAutoRentersBundleUnavailable
  test('verifyLimitedAvailabilityDialogContentAutoRentersBundleUnavailable', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyLimitedAvailabilityDialogContentAutoRentersBundleUnavailable',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 335,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyLimitedAvailabilityDialogContentAutoRentersBundleUnavailable',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyLimitedAvailabilityDialogContentRentersBundleAutoRestricted
  test('verifyLimitedAvailabilityDialogContentRentersBundleAutoRestricted', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyLimitedAvailabilityDialogContentRentersBundleAutoRestricted',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 345,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyLimitedAvailabilityDialogContentRentersBundleAutoRestricted',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#aceBundleAutoRestrictedRentersKnockoutTest
  test('aceBundleAutoRestrictedRentersKnockoutTest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#aceBundleAutoRestrictedRentersKnockoutTest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 359,
      className: 'AceAutoRentersBundleTests',
      method: 'aceBundleAutoRestrictedRentersKnockoutTest',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#validateBundleFlowWhenSelectedTwoOrMoreClaimsAR
  test('validateBundleFlowWhenSelectedTwoOrMoreClaimsAR', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#validateBundleFlowWhenSelectedTwoOrMoreClaimsAR',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 374,
      className: 'AceAutoRentersBundleTests',
      method: 'validateBundleFlowWhenSelectedTwoOrMoreClaimsAR',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAR
  test('verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAR', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAR',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 403,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAR',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionARBW
  test('verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionARBW', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionARBW',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 415,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionARBW',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyLandedOnRentersQuoteSummaryPageWhenSelectRentersFromBundleOptionAR
  test('verifyLandedOnRentersQuoteSummaryPageWhenSelectRentersFromBundleOptionAR', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyLandedOnRentersQuoteSummaryPageWhenSelectRentersFromBundleOptionAR',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 424,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyLandedOnRentersQuoteSummaryPageWhenSelectRentersFromBundleOptionAR',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyLandedOnRentersQuoteSummaryPageWhenSelectRentersFromBundleOptionARBW
  test('verifyLandedOnRentersQuoteSummaryPageWhenSelectRentersFromBundleOptionARBW', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyLandedOnRentersQuoteSummaryPageWhenSelectRentersFromBundleOptionARBW',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 433,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyLandedOnRentersQuoteSummaryPageWhenSelectRentersFromBundleOptionARBW',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#validateBWLogoInAutoPagesBundleARBW
  test('validateBWLogoInAutoPagesBundleARBW', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#validateBWLogoInAutoPagesBundleARBW',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 477,
      className: 'AceAutoRentersBundleTests',
      method: 'validateBWLogoInAutoPagesBundleARBW',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#validateBundleChangesForRentersContactInfoPage
  test('validateBundleChangesForRentersContactInfoPage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#validateBundleChangesForRentersContactInfoPage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 491,
      className: 'AceAutoRentersBundleTests',
      method: 'validateBundleChangesForRentersContactInfoPage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#validateBundleChangesForAutoFewMoreThingsPageARAndNavigateBackToPropertyTypePage
  test('validateBundleChangesForAutoFewMoreThingsPageARAndNavigateBackToPropertyTypePage', async ({
    page,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#validateBundleChangesForAutoFewMoreThingsPageARAndNavigateBackToPropertyTypePage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 501,
      className: 'AceAutoRentersBundleTests',
      method: 'validateBundleChangesForAutoFewMoreThingsPageARAndNavigateBackToPropertyTypePage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyLandedOnRentersReviewQuotePageWhenUsingKOVINAR
  test('verifyLandedOnRentersReviewQuotePageWhenUsingKOVINAR', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyLandedOnRentersReviewQuotePageWhenUsingKOVINAR',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 531,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyLandedOnRentersReviewQuotePageWhenUsingKOVINAR',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceAutoRentersPolicyStartDateInFewMoreThingsPage
  test('verifyAceAutoRentersPolicyStartDateInFewMoreThingsPage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceAutoRentersPolicyStartDateInFewMoreThingsPage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 556,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAceAutoRentersPolicyStartDateInFewMoreThingsPage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceAutoRentersBundleRetrievedQuoteAllowsMonolineChoice
  test('verifyAceAutoRentersBundleRetrievedQuoteAllowsMonolineChoice', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceAutoRentersBundleRetrievedQuoteAllowsMonolineChoice',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 566,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAceAutoRentersBundleRetrievedQuoteAllowsMonolineChoice',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#validateChangeZipcodeDifferentState
  test('validateChangeZipcodeDifferentState', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#validateChangeZipcodeDifferentState',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 594,
      className: 'AceAutoRentersBundleTests',
      method: 'validateChangeZipcodeDifferentState',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX, VA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#validateChangeZipcodeSameState
  test('validateChangeZipcodeSameState', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#validateChangeZipcodeSameState',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 604,
      className: 'AceAutoRentersBundleTests',
      method: 'validateChangeZipcodeSameState',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#validateChangeZipcodeInvalidState
  test('validateChangeZipcodeInvalidState', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#validateChangeZipcodeInvalidState',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 614,
      className: 'AceAutoRentersBundleTests',
      method: 'validateChangeZipcodeInvalidState',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceAutoRentersBundleWhenSelectingRentersLOBInLandingPage
  test('verifyAceAutoRentersBundleWhenSelectingRentersLOBInLandingPage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceAutoRentersBundleWhenSelectingRentersLOBInLandingPage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 633,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAceAutoRentersBundleWhenSelectingRentersLOBInLandingPage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#aceBundlePEWCScreen
  test('aceBundlePEWCScreen', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#aceBundlePEWCScreen',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 644,
      className: 'AceAutoRentersBundleTests',
      method: 'aceBundlePEWCScreen',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'PEWC',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, KY, LA, MA, MS, MT, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = PEWC)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceAutoRentersBundleLandedOnOptionalCoveragePageProd
  test('verifyAceAutoRentersBundleLandedOnOptionalCoveragePageProd', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#verifyAceAutoRentersBundleLandedOnOptionalCoveragePageProd',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 652,
      className: 'AceAutoRentersBundleTests',
      method: 'verifyAceAutoRentersBundleLandedOnOptionalCoveragePageProd',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE',
      groups: '{PRODUCTION_VALIDATION}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,TX})}, dataProviderClass = AceBundleDataProviders.class, groups = {PRODUCTION_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#landingPageContentAndErrorMessagesTest
  test('landingPageContentAndErrorMessagesTest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#landingPageContentAndErrorMessagesTest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 664,
      className: 'AceAutoRentersBundleTests',
      method: 'landingPageContentAndErrorMessagesTest',
      parameters: 'State state',
      dataProvider: 'SqlDataProviders.STATES_DATA_PROVIDER_NAME',
      dataProviderClass: 'SqlDataProviders.class',
      testName: '',
      groups: 'BUNDLE',
      annotation:
        '@Test (dataProvider = SqlDataProviders.STATES_DATA_PROVIDER_NAME, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = RANDOM_STATE)}, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoRentersBundleTests#autoRentersBundleEnvironmentStabilityTest
  test('autoRentersBundleEnvironmentStabilityTest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoRentersBundleTests#autoRentersBundleEnvironmentStabilityTest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoRentersBundleTests.java',
      sourceLine: 673,
      className: 'AceAutoRentersBundleTests',
      method: 'autoRentersBundleEnvironmentStabilityTest',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'ACE_STABILITY',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = ACE_STABILITY)',
    });
  });
});
