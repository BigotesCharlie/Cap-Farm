// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.acebundle.AceAutoHomeBundleTests', () => {
  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#aceAutoHomeBundleE2ETest
  test('aceAutoHomeBundleE2ETest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#aceAutoHomeBundleE2ETest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 34,
      className: 'AceAutoHomeBundleTests',
      method: 'aceAutoHomeBundleE2ETest',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#aceBWAutoHomeBundleE2EWithAutoMonthlyPayCardAndHomePayInFullCard
  test('aceBWAutoHomeBundleE2EWithAutoMonthlyPayCardAndHomePayInFullCard', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#aceBWAutoHomeBundleE2EWithAutoMonthlyPayCardAndHomePayInFullCard',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 50,
      className: 'AceAutoHomeBundleTests',
      method: 'aceBWAutoHomeBundleE2EWithAutoMonthlyPayCardAndHomePayInFullCard',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#aceBWAutoHomeBundleE2EWithAutoMonthlyPayCardAndHomeMonthlyPayInBank
  test('aceBWAutoHomeBundleE2EWithAutoMonthlyPayCardAndHomeMonthlyPayInBank', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#aceBWAutoHomeBundleE2EWithAutoMonthlyPayCardAndHomeMonthlyPayInBank',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 77,
      className: 'AceAutoHomeBundleTests',
      method: 'aceBWAutoHomeBundleE2EWithAutoMonthlyPayCardAndHomeMonthlyPayInBank',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyPaymentPagesContentAndUseSamePaymentDialogFunctionalityAH
  test('verifyPaymentPagesContentAndUseSamePaymentDialogFunctionalityAH', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyPaymentPagesContentAndUseSamePaymentDialogFunctionalityAH',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 101,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyPaymentPagesContentAndUseSamePaymentDialogFunctionalityAH',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAutoPayInFullCardAndHomeMonthlyPayBank
  test('verifyAutoPayInFullCardAndHomeMonthlyPayBank', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAutoPayInFullCardAndHomeMonthlyPayBank',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 136,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAutoPayInFullCardAndHomeMonthlyPayBank',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAutoPayInFullBankAndHomePayInFullBankWithOneTimePayment
  test('verifyAutoPayInFullBankAndHomePayInFullBankWithOneTimePayment', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAutoPayInFullBankAndHomePayInFullBankWithOneTimePayment',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 161,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAutoPayInFullBankAndHomePayInFullBankWithOneTimePayment',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceBundleHomeFinalReviewQuotePage
  test('verifyAceBundleHomeFinalReviewQuotePage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceBundleHomeFinalReviewQuotePage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 186,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceBundleHomeFinalReviewQuotePage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceBundleHomeJFMTPageAndNavigateBackToAutoJFMTP
  test('verifyAceBundleHomeJFMTPageAndNavigateBackToAutoJFMTP', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceBundleHomeJFMTPageAndNavigateBackToAutoJFMTP',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 198,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceBundleHomeJFMTPageAndNavigateBackToAutoJFMTP',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceBundleLetsBeginPageContent
  test('verifyAceBundleLetsBeginPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceBundleLetsBeginPageContent',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 214,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceBundleLetsBeginPageContent',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAutoPolicyStartDatePageAndRC2PageContentAH
  test('verifyAutoPolicyStartDatePageAndRC2PageContentAH', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAutoPolicyStartDatePageAndRC2PageContentAH',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 225,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAutoPolicyStartDatePageAndRC2PageContentAH',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceBundleHomePropertyQuestionsPageContent
  test('verifyAceBundleHomePropertyQuestionsPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceBundleHomePropertyQuestionsPageContent',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 242,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceBundleHomePropertyQuestionsPageContent',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleReviewPageContent
  test('verifyAceAutoHomeBundleReviewPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleReviewPageContent',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 252,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceAutoHomeBundleReviewPageContent',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceBWAutoHomeBundleReviewPageContent
  test('verifyAceBWAutoHomeBundleReviewPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceBWAutoHomeBundleReviewPageContent',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 265,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceBWAutoHomeBundleReviewPageContent',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleAutoQuoteReviewPageContent
  test('verifyAceAutoHomeBundleAutoQuoteReviewPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleAutoQuoteReviewPageContent',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 278,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceAutoHomeBundleAutoQuoteReviewPageContent',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleAutoQuoteEditCoverage
  test('verifyAceAutoHomeBundleAutoQuoteEditCoverage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleAutoQuoteEditCoverage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 288,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceAutoHomeBundleAutoQuoteEditCoverage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceBundleHomeQuoteReviewPageContent
  test('verifyAceBundleHomeQuoteReviewPageContent', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceBundleHomeQuoteReviewPageContent',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 299,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceBundleHomeQuoteReviewPageContent',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAH
  test('verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAH', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAH',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 319,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAH',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAHBW
  test('verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAHBW', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAHBW',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 328,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyLandedOnAutoQuoteSummaryPageWhenSelectAutoFromBundleOptionAHBW',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLandedOnHomeQuoteSummaryPageWhenSelectHomeFromBundleOptionAH
  test('verifyLandedOnHomeQuoteSummaryPageWhenSelectHomeFromBundleOptionAH', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLandedOnHomeQuoteSummaryPageWhenSelectHomeFromBundleOptionAH',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 337,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyLandedOnHomeQuoteSummaryPageWhenSelectHomeFromBundleOptionAH',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLandedOnHomeQuoteSummaryPageWhenSelectHomeFromBundleOptionAHBW
  test('verifyLandedOnHomeQuoteSummaryPageWhenSelectHomeFromBundleOptionAHBW', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLandedOnHomeQuoteSummaryPageWhenSelectHomeFromBundleOptionAHBW',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 346,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyLandedOnHomeQuoteSummaryPageWhenSelectHomeFromBundleOptionAHBW',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{BUNDLE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {BUNDLE})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateInEscrowAceAutoHomeBundleAdditionalInfoPage
  test('validateInEscrowAceAutoHomeBundleAdditionalInfoPage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateInEscrowAceAutoHomeBundleAdditionalInfoPage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 393,
      className: 'AceAutoHomeBundleTests',
      method: 'validateInEscrowAceAutoHomeBundleAdditionalInfoPage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateBundleFlowWhenSelectingPropertyTypeOtherAH
  test('validateBundleFlowWhenSelectingPropertyTypeOtherAH', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateBundleFlowWhenSelectingPropertyTypeOtherAH',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 406,
      className: 'AceAutoHomeBundleTests',
      method: 'validateBundleFlowWhenSelectingPropertyTypeOtherAH',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#aceBundleMonolineAutoTestHomeRestricted
  test('aceBundleMonolineAutoTestHomeRestricted', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#aceBundleMonolineAutoTestHomeRestricted',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 415,
      className: 'AceAutoHomeBundleTests',
      method: 'aceBundleMonolineAutoTestHomeRestricted',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {LA, MA, MS})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#aceBundleMonolineHomeTest
  test.skip('aceBundleMonolineHomeTest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#aceBundleMonolineHomeTest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 427,
      className: 'AceAutoHomeBundleTests',
      method: 'aceBundleMonolineHomeTest',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLimitedAvailabilityDialogContentAutoHomeBundleUnavailable
  test('verifyLimitedAvailabilityDialogContentAutoHomeBundleUnavailable', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLimitedAvailabilityDialogContentAutoHomeBundleUnavailable',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 452,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyLimitedAvailabilityDialogContentAutoHomeBundleUnavailable',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {LA, MA, MS})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLimitedAvailabilityDialogContentHomeBundleAutoRestricted
  test('verifyLimitedAvailabilityDialogContentHomeBundleAutoRestricted', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLimitedAvailabilityDialogContentHomeBundleAutoRestricted',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 462,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyLimitedAvailabilityDialogContentHomeBundleAutoRestricted',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLimitedAvailabilityDialogContentHomeRestricted
  test('verifyLimitedAvailabilityDialogContentHomeRestricted', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLimitedAvailabilityDialogContentHomeRestricted',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 475,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyLimitedAvailabilityDialogContentHomeRestricted',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX, VA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#allLOBsRestrictedKnockoutTest
  test.skip('allLOBsRestrictedKnockoutTest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#allLOBsRestrictedKnockoutTest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 488,
      className: 'AceAutoHomeBundleTests',
      method: 'allLOBsRestrictedKnockoutTest',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#aceBundleAutoRestrictedHomeKnockoutTest
  test('aceBundleAutoRestrictedHomeKnockoutTest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#aceBundleAutoRestrictedHomeKnockoutTest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 507,
      className: 'AceAutoHomeBundleTests',
      method: 'aceBundleAutoRestrictedHomeKnockoutTest',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {TX})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateAutoReviewQuotePageWhenSelectedUnfencedPoolForHomeAH
  test('validateAutoReviewQuotePageWhenSelectedUnfencedPoolForHomeAH', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateAutoReviewQuotePageWhenSelectedUnfencedPoolForHomeAH',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 525,
      className: 'AceAutoHomeBundleTests',
      method: 'validateAutoReviewQuotePageWhenSelectedUnfencedPoolForHomeAH',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, MT, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateAutoReviewQuotePageWhenSelectedUnfencedTrampolineForHome
  test('validateAutoReviewQuotePageWhenSelectedUnfencedTrampolineForHome', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateAutoReviewQuotePageWhenSelectedUnfencedTrampolineForHome',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 542,
      className: 'AceAutoHomeBundleTests',
      method: 'validateAutoReviewQuotePageWhenSelectedUnfencedTrampolineForHome',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, MT, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateBundleFlowWhenSelectedTwoOrMoreClaimsAH
  test('validateBundleFlowWhenSelectedTwoOrMoreClaimsAH', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateBundleFlowWhenSelectedTwoOrMoreClaimsAH',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 559,
      className: 'AceAutoHomeBundleTests',
      method: 'validateBundleFlowWhenSelectedTwoOrMoreClaimsAH',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateBundleFlowWhenSelectedPrimaryResidenceAsNoAH
  test('validateBundleFlowWhenSelectedPrimaryResidenceAsNoAH', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateBundleFlowWhenSelectedPrimaryResidenceAsNoAH',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 569,
      className: 'AceAutoHomeBundleTests',
      method: 'validateBundleFlowWhenSelectedPrimaryResidenceAsNoAH',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AZ, CA, CT, LA, MA, MN, MS, NC, NE, OH, OR, PA, TX, UT, WI, WY}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateHomeChangeCoveragesDeductibleAndPackages
  test('validateHomeChangeCoveragesDeductibleAndPackages', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateHomeChangeCoveragesDeductibleAndPackages',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 587,
      className: 'AceAutoHomeBundleTests',
      method: 'validateHomeChangeCoveragesDeductibleAndPackages',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateBWLogoInAutoPagesBundleAHBW
  test('validateBWLogoInAutoPagesBundleAHBW', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateBWLogoInAutoPagesBundleAHBW',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 605,
      className: 'AceAutoHomeBundleTests',
      method: 'validateBWLogoInAutoPagesBundleAHBW',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA, IA, MD, ND, TX, WI}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateBundleChangesForHomeContactInfoPage
  test('validateBundleChangesForHomeContactInfoPage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateBundleChangesForHomeContactInfoPage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 619,
      className: 'AceAutoHomeBundleTests',
      method: 'validateBundleChangesForHomeContactInfoPage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateBundleChangesForAutoFewMoreThingsPageAHAndNavigateBackToPropertyTypePage
  test('validateBundleChangesForAutoFewMoreThingsPageAHAndNavigateBackToPropertyTypePage', async ({
    page,
  }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateBundleChangesForAutoFewMoreThingsPageAHAndNavigateBackToPropertyTypePage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 633,
      className: 'AceAutoHomeBundleTests',
      method: 'validateBundleChangesForAutoFewMoreThingsPageAHAndNavigateBackToPropertyTypePage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT_WITH_THREE_VEHICLES',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT_WITH_THREE_VEHICLES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLandedOnHomeReviewQuotePageWhenUsingKOVINAH
  test('verifyLandedOnHomeReviewQuotePageWhenUsingKOVINAH', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyLandedOnHomeReviewQuotePageWhenUsingKOVINAH',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 689,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyLandedOnHomeReviewQuotePageWhenUsingKOVINAH',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomePolicyStartDateInFewMoreThingsPage
  test('verifyAceAutoHomePolicyStartDateInFewMoreThingsPage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomePolicyStartDateInFewMoreThingsPage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 721,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceAutoHomePolicyStartDateInFewMoreThingsPage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyThankYouPageWhenQuoteIsBindDisabled
  test('verifyThankYouPageWhenQuoteIsBindDisabled', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyThankYouPageWhenQuoteIsBindDisabled',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 731,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyThankYouPageWhenQuoteIsBindDisabled',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {VA}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleAutoForeignDriverKnockout
  test('verifyAceAutoHomeBundleAutoForeignDriverKnockout', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleAutoForeignDriverKnockout',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 790,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceAutoHomeBundleAutoForeignDriverKnockout',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleLandedOnOptionalCoveragePageProd
  test('verifyAceAutoHomeBundleLandedOnOptionalCoveragePageProd', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleLandedOnOptionalCoveragePageProd',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 809,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceAutoHomeBundleLandedOnOptionalCoveragePageProd',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE',
      groups: '{PRODUCTION_VALIDATION}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.ONE_BUNDLE_APPLICANT_PER_STATE, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ,TX})}, dataProviderClass = AceBundleDataProviders.class, groups = {PRODUCTION_VALIDATION})',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleRetrievedQuoteAllowsMonolineChoice
  test('verifyAceAutoHomeBundleRetrievedQuoteAllowsMonolineChoice', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleRetrievedQuoteAllowsMonolineChoice',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 821,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceAutoHomeBundleRetrievedQuoteAllowsMonolineChoice',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyReverseBrightlineLoaderPage
  test('verifyReverseBrightlineLoaderPage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyReverseBrightlineLoaderPage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 853,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyReverseBrightlineLoaderPage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleFromInterstitialPage
  test('verifyAceAutoHomeBundleFromInterstitialPage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleFromInterstitialPage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 863,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceAutoHomeBundleFromInterstitialPage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleWhenSelectingHomeLOBInLandingPage
  test.skip('verifyAceAutoHomeBundleWhenSelectingHomeLOBInLandingPage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyAceAutoHomeBundleWhenSelectingHomeLOBInLandingPage',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 873,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyAceAutoHomeBundleWhenSelectingHomeLOBInLandingPage',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyHomeQualityGradeDialogPath
  test('verifyHomeQualityGradeDialogPath', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#verifyHomeQualityGradeDialogPath',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 884,
      className: 'AceAutoHomeBundleTests',
      method: 'verifyHomeQualityGradeDialogPath',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#autoHomeBundleEnvironmentStabilityTest
  test('autoHomeBundleEnvironmentStabilityTest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#autoHomeBundleEnvironmentStabilityTest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 909,
      className: 'AceAutoHomeBundleTests',
      method: 'autoHomeBundleEnvironmentStabilityTest',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'ACE_STABILITY',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CT, IN, KY, LA, MA, MS, NC})}, dataProviderClass = AceBundleDataProviders.class, groups = ACE_STABILITY)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateMLBCampaignFunctionalityRefreshTest
  test('validateMLBCampaignFunctionalityRefreshTest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateMLBCampaignFunctionalityRefreshTest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 919,
      className: 'AceAutoHomeBundleTests',
      method: 'validateMLBCampaignFunctionalityRefreshTest',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CA, CO, CT, FL, IA, ID, IL, IN, KS, KY, LA, MD, MI, MO, MS, MT, NM, NV, OH, OK, OR, TN, TX, VA, WA, WI})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateMLBCampaignFunctionalityBackNavigationTest
  test('validateMLBCampaignFunctionalityBackNavigationTest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateMLBCampaignFunctionalityBackNavigationTest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 932,
      className: 'AceAutoHomeBundleTests',
      method: 'validateMLBCampaignFunctionalityBackNavigationTest',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CA, CO, CT, FL, IA, ID, IL, IN, KS, KY, LA, MD, MI, MO, MS, MT, NM, NV, OH, OK, OR, TN, TX, VA, WA, WI})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateMLBCampaignFunctionalityRetrievalTest
  test('validateMLBCampaignFunctionalityRetrievalTest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#validateMLBCampaignFunctionalityRetrievalTest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 946,
      className: 'AceAutoHomeBundleTests',
      method: 'validateMLBCampaignFunctionalityRetrievalTest',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, CA, CO, CT, FL, IA, ID, IL, IN, KS, KY, LA, MD, MI, MO, MS, MT, NM, NV, OH, OK, OR, TN, TX, VA, WA, WI})}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });

  // legacy-id: com.farmers.ffq.acebundle.AceAutoHomeBundleTests#autoHomeBundleWildfireMitigationTest
  test('autoHomeBundleWildfireMitigationTest', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acebundle.AceAutoHomeBundleTests#autoHomeBundleWildfireMitigationTest',
      domain: 'acebundle',
      sourceFile: 'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
      sourceLine: 961,
      className: 'AceAutoHomeBundleTests',
      method: 'autoHomeBundleWildfireMitigationTest',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: 'BUNDLE',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = CO)}, dataProviderClass = AceBundleDataProviders.class, groups = BUNDLE)',
    });
  });
});
