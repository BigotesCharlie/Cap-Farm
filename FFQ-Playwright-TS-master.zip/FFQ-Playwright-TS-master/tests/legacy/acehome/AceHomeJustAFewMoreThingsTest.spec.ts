// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest', () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testValidateContentOfJustFewMoreThingsPageHomeLob
  test('testValidateContentOfJustFewMoreThingsPageHomeLob', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testValidateContentOfJustFewMoreThingsPageHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeJustAFewMoreThingsTest.java',
      sourceLine: 25,
      className: 'AceHomeJustAFewMoreThingsTest',
      method: 'testValidateContentOfJustFewMoreThingsPageHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_JAFMT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_JAFMT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testUnrepairedStructureKnockOutScreenHomeLob
  test('testUnrepairedStructureKnockOutScreenHomeLob', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testUnrepairedStructureKnockOutScreenHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeJustAFewMoreThingsTest.java',
      sourceLine: 54,
      className: 'AceHomeJustAFewMoreThingsTest',
      method: 'testUnrepairedStructureKnockOutScreenHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testBusinessOperatedOnPremisesKnockOutScreenHomeLob
  test('testBusinessOperatedOnPremisesKnockOutScreenHomeLob', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testBusinessOperatedOnPremisesKnockOutScreenHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeJustAFewMoreThingsTest.java',
      sourceLine: 66,
      className: 'AceHomeJustAFewMoreThingsTest',
      method: 'testBusinessOperatedOnPremisesKnockOutScreenHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testPetWithBiteHistoryKnockOutScreenHomeLob
  test('testPetWithBiteHistoryKnockOutScreenHomeLob', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testPetWithBiteHistoryKnockOutScreenHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeJustAFewMoreThingsTest.java',
      sourceLine: 79,
      className: 'AceHomeJustAFewMoreThingsTest',
      method: 'testPetWithBiteHistoryKnockOutScreenHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testPlumbingOtherThanCopperPEXPVCKnockOutScreenHomeLob
  test('testPlumbingOtherThanCopperPEXPVCKnockOutScreenHomeLob', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testPlumbingOtherThanCopperPEXPVCKnockOutScreenHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeJustAFewMoreThingsTest.java',
      sourceLine: 92,
      className: 'AceHomeJustAFewMoreThingsTest',
      method: 'testPlumbingOtherThanCopperPEXPVCKnockOutScreenHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testPrimaryHeatingSourceKnockOutScreenHomeLob
  test('testPrimaryHeatingSourceKnockOutScreenHomeLob', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testPrimaryHeatingSourceKnockOutScreenHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeJustAFewMoreThingsTest.java',
      sourceLine: 105,
      className: 'AceHomeJustAFewMoreThingsTest',
      method: 'testPrimaryHeatingSourceKnockOutScreenHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testDogsOnPremisesKnockOutScreenHomeLob
  test.skip('testDogsOnPremisesKnockOutScreenHomeLob', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testDogsOnPremisesKnockOutScreenHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeJustAFewMoreThingsTest.java',
      sourceLine: 119,
      className: 'AceHomeJustAFewMoreThingsTest',
      method: 'testDogsOnPremisesKnockOutScreenHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testKnockOutScreenWhenAllOtherQuestionsAreSelectedHomeLob
  test('testKnockOutScreenWhenAllOtherQuestionsAreSelectedHomeLob', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testKnockOutScreenWhenAllOtherQuestionsAreSelectedHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeJustAFewMoreThingsTest.java',
      sourceLine: 131,
      className: 'AceHomeJustAFewMoreThingsTest',
      method: 'testKnockOutScreenWhenAllOtherQuestionsAreSelectedHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testContinueToBindWhenCantFindLenderSelectedHomeLob
  test('testContinueToBindWhenCantFindLenderSelectedHomeLob', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testContinueToBindWhenCantFindLenderSelectedHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeJustAFewMoreThingsTest.java',
      sourceLine: 143,
      className: 'AceHomeJustAFewMoreThingsTest',
      method: 'testContinueToBindWhenCantFindLenderSelectedHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_JFMTP_KO,attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#validateDefaultValuesInFortifiedHomeSectionHomeLob
  test('validateDefaultValuesInFortifiedHomeSectionHomeLob', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#validateDefaultValuesInFortifiedHomeSectionHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeJustAFewMoreThingsTest.java',
      sourceLine: 153,
      className: 'AceHomeJustAFewMoreThingsTest',
      method: 'validateDefaultValuesInFortifiedHomeSectionHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_JAFMT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_FORTIFIED_HOME_SECTION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_JAFMT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testDataSaveWhenNavigatedBackAndForthJFMTPageHomeLob
  test('testDataSaveWhenNavigatedBackAndForthJFMTPageHomeLob', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testDataSaveWhenNavigatedBackAndForthJFMTPageHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeJustAFewMoreThingsTest.java',
      sourceLine: 163,
      className: 'AceHomeJustAFewMoreThingsTest',
      method: 'testDataSaveWhenNavigatedBackAndForthJFMTPageHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testHomePurchaseDatePicker
  test('testHomePurchaseDatePicker', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeJustAFewMoreThingsTest#testHomePurchaseDatePicker',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeJustAFewMoreThingsTest.java',
      sourceLine: 179,
      className: 'AceHomeJustAFewMoreThingsTest',
      method: 'testHomePurchaseDatePicker',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_JAFMT_PAGE})',
    });
  });
});
