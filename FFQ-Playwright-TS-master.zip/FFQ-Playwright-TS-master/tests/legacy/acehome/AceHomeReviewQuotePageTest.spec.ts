// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.acehome.AceHomeReviewQuotePageTest', () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#testValidateReviewQuotePageAndRC2screenHomeLob
  test('testValidateReviewQuotePageAndRC2screenHomeLob', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#testValidateReviewQuotePageAndRC2screenHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeReviewQuotePageTest.java',
      sourceLine: 34,
      className: 'AceHomeReviewQuotePageTest',
      method: 'testValidateReviewQuotePageAndRC2screenHomeLob',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateContentOfReviewQuoteComparePackageSideSheetHomeLob
  test('validateContentOfReviewQuoteComparePackageSideSheetHomeLob', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateContentOfReviewQuoteComparePackageSideSheetHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeReviewQuotePageTest.java',
      sourceLine: 136,
      className: 'AceHomeReviewQuotePageTest',
      method: 'validateContentOfReviewQuoteComparePackageSideSheetHomeLob',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateEditPrimaryCoveragesHomeLob
  test('validateEditPrimaryCoveragesHomeLob', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateEditPrimaryCoveragesHomeLob',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeReviewQuotePageTest.java',
      sourceLine: 145,
      className: 'AceHomeReviewQuotePageTest',
      method: 'validateEditPrimaryCoveragesHomeLob',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AR,AZ,CO,ID,IL,MO,ND,NE,NM,OK,OR,PA,SD,UT,VA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateRoofMaterialAndFortifiedRoofCoverage
  test('validateRoofMaterialAndFortifiedRoofCoverage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateRoofMaterialAndFortifiedRoofCoverage',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeReviewQuotePageTest.java',
      sourceLine: 173,
      className: 'AceHomeReviewQuotePageTest',
      method: 'validateRoofMaterialAndFortifiedRoofCoverage',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateReviewQuoteStepper
  test('validateReviewQuoteStepper', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateReviewQuoteStepper',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeReviewQuotePageTest.java',
      sourceLine: 187,
      className: 'AceHomeReviewQuotePageTest',
      method: 'validateReviewQuoteStepper',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateCAMinimumWaterPerilDeductibleInTerritories9n10
  test.skip('validateCAMinimumWaterPerilDeductibleInTerritories9n10', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateCAMinimumWaterPerilDeductibleInTerritories9n10',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeReviewQuotePageTest.java',
      sourceLine: 206,
      className: 'AceHomeReviewQuotePageTest',
      method: 'validateCAMinimumWaterPerilDeductibleInTerritories9n10',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateCAWildfireRiskReductionEligibilityByRoofType
  test.skip('validateCAWildfireRiskReductionEligibilityByRoofType', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateCAWildfireRiskReductionEligibilityByRoofType',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeReviewQuotePageTest.java',
      sourceLine: 234,
      className: 'AceHomeReviewQuotePageTest',
      method: 'validateCAWildfireRiskReductionEligibilityByRoofType',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CONTACT_INFO_PAGE}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#testCAQuoteFAIRPlanExclusionCoverage
  test.skip('testCAQuoteFAIRPlanExclusionCoverage', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#testCAQuoteFAIRPlanExclusionCoverage',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeReviewQuotePageTest.java',
      sourceLine: 262,
      className: 'AceHomeReviewQuotePageTest',
      method: 'testCAQuoteFAIRPlanExclusionCoverage',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}, enabled = false)',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateBundleInterstitialToHomeMonoline
  test('validateBundleInterstitialToHomeMonoline', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateBundleInterstitialToHomeMonoline',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeReviewQuotePageTest.java',
      sourceLine: 294,
      className: 'AceHomeReviewQuotePageTest',
      method: 'validateBundleInterstitialToHomeMonoline',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateBundleDiscountOnReviewQuotePageHome
  test('validateBundleDiscountOnReviewQuotePageHome', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#validateBundleDiscountOnReviewQuotePageHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeReviewQuotePageTest.java',
      sourceLine: 308,
      className: 'AceHomeReviewQuotePageTest',
      method: 'validateBundleDiscountOnReviewQuotePageHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: 'RANDOM_ROW',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER, dataProviderClass = AceHomeDataProviders.class, testName = RANDOM_ROW, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {OR})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#testHomeMonolineToAutoBundleQuoteVariant1
  test('testHomeMonolineToAutoBundleQuoteVariant1', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#testHomeMonolineToAutoBundleQuoteVariant1',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeReviewQuotePageTest.java',
      sourceLine: 330,
      className: 'AceHomeReviewQuotePageTest',
      method: 'testHomeMonolineToAutoBundleQuoteVariant1',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#testHomeMonolineToAutoBundleQuoteVariant2
  test('testHomeMonolineToAutoBundleQuoteVariant2', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#testHomeMonolineToAutoBundleQuoteVariant2',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeReviewQuotePageTest.java',
      sourceLine: 359,
      className: 'AceHomeReviewQuotePageTest',
      method: 'testHomeMonolineToAutoBundleQuoteVariant2',
      parameters: 'AceBundleApplicant bundleApplicant',
      dataProvider: 'AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER',
      dataProviderClass: 'AceBundleDataProviders.class',
      testName: 'AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}',
      annotation:
        '@Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {OR}), @CustomAttribute(name = REMOVE_AUTO_REDSTATES)}, dataProviderClass = AceBundleDataProviders.class, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#testPayrollDeductionBannerForNonAWSFlow
  test('testPayrollDeductionBannerForNonAWSFlow', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#testPayrollDeductionBannerForNonAWSFlow',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeReviewQuotePageTest.java',
      sourceLine: 393,
      className: 'AceHomeReviewQuotePageTest',
      method: 'testPayrollDeductionBannerForNonAWSFlow',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_PAYROLL_DEDUCTION, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#testPayrollDeductionBannerForAWSFlow
  test('testPayrollDeductionBannerForAWSFlow', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId: 'com.farmers.ffq.acehome.AceHomeReviewQuotePageTest#testPayrollDeductionBannerForAWSFlow',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeReviewQuotePageTest.java',
      sourceLine: 419,
      className: 'AceHomeReviewQuotePageTest',
      method: 'testPayrollDeductionBannerForAWSFlow',
      parameters: 'ApplicantAceHome applicant',
      dataProvider: 'AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.ACE_HOME_APPLICANT_WITH_UNMODIFIED_NAME, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_PAYROLL_DEDUCTION, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_REVIEW_QUOTE_PAGE})',
    });
  });
});
