// Generated from the immutable migration ledger. Do not hand-edit.
import { test } from '../../../src/fixtures/test.js';
import { env } from '../../../src/config/env.js';
import { executeMigratedScenario } from '../../../src/migration/ScenarioExecutor.js';

test.describe('com.farmers.ffq.acehome.AceHomeMonthlyAutoPayBankPageTest', () => {
  // legacy-id: com.farmers.ffq.acehome.AceHomeMonthlyAutoPayBankPageTest#testValidateContentOfMonthlyAutoPayBankPageOnLandingAceHome
  test('testValidateContentOfMonthlyAutoPayBankPageOnLandingAceHome', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeMonthlyAutoPayBankPageTest#testValidateContentOfMonthlyAutoPayBankPageOnLandingAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeMonthlyAutoPayBankPageTest.java',
      sourceLine: 23,
      className: 'AceHomeMonthlyAutoPayBankPageTest',
      method: 'testValidateContentOfMonthlyAutoPayBankPageOnLandingAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeMonthlyAutoPayBankPageTest#testMonthlyAutoPayBankPaymentEndToEndAceHome
  test('testMonthlyAutoPayBankPaymentEndToEndAceHome', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeMonthlyAutoPayBankPageTest#testMonthlyAutoPayBankPaymentEndToEndAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeMonthlyAutoPayBankPageTest.java',
      sourceLine: 40,
      className: 'AceHomeMonthlyAutoPayBankPageTest',
      method: 'testMonthlyAutoPayBankPaymentEndToEndAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_BIND, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_BIND, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeMonthlyAutoPayBankPageTest#testMonthlyAutoPayBankCreditCardPaymentAceHome
  test('testMonthlyAutoPayBankCreditCardPaymentAceHome', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeMonthlyAutoPayBankPageTest#testMonthlyAutoPayBankCreditCardPaymentAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeMonthlyAutoPayBankPageTest.java',
      sourceLine: 59,
      className: 'AceHomeMonthlyAutoPayBankPageTest',
      method: 'testMonthlyAutoPayBankCreditCardPaymentAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_CRITICAL, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeMonthlyAutoPayBankPageTest#testMonthlyAutoPayBankChangeBankPaymentToCardAceHome
  test('testMonthlyAutoPayBankChangeBankPaymentToCardAceHome', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeMonthlyAutoPayBankPageTest#testMonthlyAutoPayBankChangeBankPaymentToCardAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeMonthlyAutoPayBankPageTest.java',
      sourceLine: 81,
      className: 'AceHomeMonthlyAutoPayBankPageTest',
      method: 'testMonthlyAutoPayBankChangeBankPaymentToCardAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE})',
    });
  });

  // legacy-id: com.farmers.ffq.acehome.AceHomeMonthlyAutoPayBankPageTest#testMonthlyAutoPayBankChangeCreditCardPaymentToBankAceHome
  test('testMonthlyAutoPayBankChangeCreditCardPaymentToBankAceHome', async ({ page }, testInfo) => {
    await executeMigratedScenario(page, testInfo, {
      legacyId:
        'com.farmers.ffq.acehome.AceHomeMonthlyAutoPayBankPageTest#testMonthlyAutoPayBankChangeCreditCardPaymentToBankAceHome',
      domain: 'acehome',
      sourceFile: 'src/test/java/com/farmers/ffq/acehome/AceHomeMonthlyAutoPayBankPageTest.java',
      sourceLine: 106,
      className: 'AceHomeMonthlyAutoPayBankPageTest',
      method: 'testMonthlyAutoPayBankChangeCreditCardPaymentToBankAceHome',
      parameters: 'ApplicantAceHome applicantAceHome',
      dataProvider: 'AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER',
      dataProviderClass: 'AceHomeDataProviders.class',
      testName: '',
      groups: '{FFQ_ACE_HOME, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE}',
      annotation:
        '@Test(dataProvider = AceHomeDataProviders.APPLICANT_ACE_HOME_CATEGORY_PROVIDER, dataProviderClass = AceHomeDataProviders.class, suiteName = AceHomeDataProviders.CATEGORY_BIND_VALIDATION, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA,MO,UT,LA,MA,MS,NC})}, groups = {FFQ_ACE_HOME, FFQ_ACE_HOME_MONTHLY_AUTOPAY_BANK_PAGE})',
    });
  });
});
