# Golden Auto Implementation Report

## Status

BLOCKED

The requested scope remained limited to Phase 0, Phase 1, and exactly one Golden scenario: `com.farmers.ffq.auto.e2e.QuoteE2ETests#aceAutoEndToEndOneRandomApplicant`.

No additional scenario handlers were implemented. No generated test files were edited. No runtime certification entry was added.

## Scope Completed

- Preserved fail-closed execution and certification gating.
- Kept execution restricted to the Golden legacy ID through `MIGRATION_CERTIFICATION_ALLOWLIST`.
- Updated the Golden auto flow to match the current FFQ landing and early personal-info/address screens.
- Normalized Excel provider values so date/object cells no longer collapse to `[object Object]`.
- Preserved recovery guard max behavior and narrowed knockout detection to avoid false positives from normal landing content.

## Key Code Changes

- `src/pages/auto/StartQuotePage.ts`
  - Adapted landing selectors to the modern FFQ Auto tile, cookie prompts, ZIP field, and start CTA.
- `src/pages/auto/NameDobPage.ts`
  - Switched to current personal-info inputs and added DOB masked-field fallback typing with verification.
- `src/pages/auto/AddressPage.ts`
  - Adapted address/contact selectors to modern visible controls and added explicit field verification for email and phone.
- `src/data/providers/AutoApplicantProvider.ts`
  - Added normalization for Excel `Date`, `.text`, and `.result` cell shapes.
  - Preferred non-`knockoutExpected` candidates when selecting the Golden random applicant pool.
- `src/core/RecoveryGuard.ts`
  - Narrowed knockout markers to avoid recovery loops on benign landing text.
- `src/flows/auto/AceAutoNavigationFlow.ts`
  - Added modern-stage handling around start, address submit, BW transitions, and vehicle/driver progression attempts.
- `src/pages/auto/QuoteSummaryPage.ts`
  - Relaxed summary assertion to accept heading-first rendering before checkout CTA appears.

## Validation Executed

All runs used:

- `EXECUTE_MIGRATED_TESTS=true`
- `MIGRATION_ALLOW_UNCERTIFIED_CERTIFICATION_RUN=true`
- `MIGRATION_CERTIFICATION_ALLOWLIST=com.farmers.ffq.auto.e2e.QuoteE2ETests#aceAutoEndToEndOneRandomApplicant`

Validation commands:

```powershell
npm run typecheck
npx playwright test tests/legacy/auto/QuoteE2ETests.spec.ts --project=chromium --headed --grep "aceAutoEndToEndOneRandomApplicant"
```

Observed results:

- `npm run typecheck`: PASS on the final code state.
- Golden headed Chromium execution: FAIL.

## Final Failure Boundary

The Golden path progressed materially farther than the initial state:

- Landing page interaction works on the modern FFQ experience.
- Name and DOB entry works after provider/date normalization and masked-input fallback.
- Address page fields are detected on the modern form.

The scenario still does not complete.

Current blockers observed in final validation:

1. Random applicant instability remains for some allowed states/data rows.
   - Example: some selected applicants still redirect to `call-for-quote` before the Name/DOB page, despite the narrowed selection pool.
2. On non-redirecting runs, the flow stalls after address submission on the `Who should we insure?` screen.
   - The page shows a visible `Add vehicles and drivers` CTA and a lookup message, but the migrated flow does not advance deterministically into the downstream vehicle/driver review path.
3. Because the flow never reaches a real review-quote page in the final validation run, payment selection is not reached and the scenario cannot be truthfully certified.

Representative evidence from the final attempts:

- Main run failure: redirect to `call-for-quote` before the personal-info page.
- Retry failure: stalled on `Who should we insure?` with Bristol West branding and visible `Add vehicles and drivers` CTA, then failed at quote-summary assertion because no review-quote screen was reached.

## Certification And Registry Counts

Session-before state:

- Mapped scenarios: 2941
- Implemented handlers: 0
- Runtime-certified handlers: 0

Session-after state:

- Mapped scenarios: 2941
- Implemented handlers: 1
- Runtime-certified handlers: 0

Notes:

- The single implemented handler is `com.farmers.ffq.auto.e2e.QuoteE2ETests#aceAutoEndToEndOneRandomApplicant`.
- `src/migration/registry/RuntimeCertification.ts` remains empty.
- No certification allowlist or runtime-certified IDs were modified in source.

## Guardrail Compliance

- No Java execution was introduced.
- No sleeps were added.
- No generated files were edited.
- No false PASS or certification claim was made.
- Scope remained limited to the single Golden scenario.

## Recommended Next Debug Slice

The next smallest defensible slice is to treat `Who should we insure?` as the controlling page and instrument or model its exact post-click state transition before changing broader flow logic. The two most likely causes are:

- applicant/state-specific backend lookup behavior that returns a manual onboarding branch not yet modeled by the migrated flow, or
- a client-side transition on `Add vehicles and drivers` that requires page-state waits more specific than `domcontentloaded`.
