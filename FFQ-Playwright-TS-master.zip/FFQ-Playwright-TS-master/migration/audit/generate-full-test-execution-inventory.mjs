import { readFile, readdir, writeFile } from 'node:fs/promises';
import { dirname, join, resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const AUDIT_DIR = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(AUDIT_DIR, '../..');
const TEST_ROOT = join(ROOT, 'tests', 'legacy');
const LEGACY_INVENTORY_PATH = join(ROOT, 'migration', 'audit', 'legacy-test-inventory.csv');
const REGISTRY_PATH = join(ROOT, 'src', 'migration', 'registry', 'HandlerCatalog.ts');
const HANDLER_FILES = [
  join(ROOT, 'src', 'migration', 'handlers', 'auto', 'AceAutoEndToEndOneRandomApplicantHandler.ts'),
  join(ROOT, 'src', 'migration', 'handlers', 'acehome', 'AceHomeAdditionalInfoHandler.ts'),
  join(ROOT, 'src', 'migration', 'handlers', 'acehome', 'AceHomeProdRetrieveRatedQuoteHandler.ts'),
  join(ROOT, 'src', 'migration', 'handlers', 'acehome', 'AceHomeReviewQuotePresentmentHandler.ts'),
  join(ROOT, 'src', 'migration', 'handlers', 'acehome', 'AceHomeSmokePresentmentHandler.ts'),
];
const OUTPUT_JSON = join(ROOT, 'migration', 'audit', 'full-test-execution-inventory.json');
const OUTPUT_CSV = join(ROOT, 'migration', 'audit', 'full-test-execution-inventory.csv');

async function filesUnder(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const nested = await Promise.all(
    entries.map((entry) => {
      const path = join(directory, entry.name);
      return entry.isDirectory() ? filesUnder(path) : [path];
    }),
  );
  return nested.flat();
}

function parseCsv(text) {
  const rows = [];
  let current = '';
  let row = [];
  let inQuotes = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];

    if (char === '"') {
      if (inQuotes && next === '"') {
        current += '"';
        index += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (char === ',' && !inQuotes) {
      row.push(current);
      current = '';
      continue;
    }

    if ((char === '\n' || char === '\r') && !inQuotes) {
      if (char === '\r' && next === '\n') index += 1;
      row.push(current);
      current = '';
      if (row.length > 1 || row[0] !== '') rows.push(row);
      row = [];
      continue;
    }

    current += char;
  }

  if (current.length > 0 || row.length > 0) {
    row.push(current);
    rows.push(row);
  }

  const header = rows[0] ?? [];
  return rows.slice(1).map((values) => {
    const record = {};
    for (let index = 0; index < header.length; index += 1) {
      record[header[index]] = values[index] ?? '';
    }
    return record;
  });
}

function csvEscape(value) {
  const text = String(value ?? '');
  if (/[",\r\n]/.test(text)) {
    return `"${text.replace(/"/g, '""')}"`;
  }
  return text;
}

function toCsv(rows, headers) {
  const lines = [headers.join(',')];
  for (const row of rows) {
    lines.push(headers.map((header) => csvEscape(row[header])).join(','));
  }
  return `${lines.join('\n')}\n`;
}

function parseScenarioBlocks(source) {
  const lines = source.split(/\r?\n/);
  const blocks = [];

  for (let index = 0; index < lines.length; index += 1) {
    const legacyMatch = lines[index].match(/^\s*\/\/\s*legacy-id:\s*(\S+)\s*$/);
    if (!legacyMatch) continue;

    const nextLegacyIndex = lines.findIndex((line, candidate) => candidate > index && /^\s*\/\/\s*legacy-id:\s*\S+\s*$/.test(line));
    const endIndex = nextLegacyIndex === -1 ? lines.length : nextLegacyIndex;
    const blockLines = lines.slice(index, endIndex);
    const declarationLine = blockLines.find((line) => line.trim() !== '' && !/^\s*\/\//.test(line)) ?? '';
    const declarationType = /\btest\.skip\s*\(/.test(declarationLine)
      ? 'test.skip'
      : /\btest\.fixme\s*\(/.test(declarationLine)
        ? 'test.fixme'
        : /\btest\.todo\s*\(/.test(declarationLine)
          ? 'test.todo'
          : /\btest\s*\(/.test(declarationLine)
            ? 'test'
            : 'unknown';
    const testNameMatch = declarationLine.match(/\btest(?:\.(?:skip|fixme|todo))?\(\s*(["'])(.*?)\1/);

    blocks.push({
      legacyId: legacyMatch[1],
      declarationType,
      testName: testNameMatch?.[2] ?? '',
      skipDetected: declarationType === 'test.skip' || declarationType === 'test.fixme',
      todoDetected: declarationType === 'test.todo',
    });
  }

  return blocks;
}

function specFileFromPath(filePath) {
  return relative(ROOT, filePath).replace(/\\/g, '/');
}

function productFolderFromSpecPath(specPath) {
  const parts = specPath.split('/');
  const legacyIndex = parts.indexOf('legacy');
  if (legacyIndex >= 0) return parts[legacyIndex + 1] ?? '';
  return parts[1] ?? '';
}

async function parseHandlerFiles() {
  const byLegacyId = new Map();
  const byClassName = new Map();

  for (const filePath of HANDLER_FILES) {
    const source = await readFile(filePath, 'utf8');
    const className = source.match(/export\s+class\s+(\w+)/)?.[1] ?? '';
    const legacyIds = [...source.matchAll(/export\s+const\s+\w+_LEGACY_ID\s*=\s*['"]([^'"]+)['"]/g)].map((match) => match[1]);

    byClassName.set(className, { className, filePath: specFileFromPath(filePath), source, legacyIds });
    for (const legacyId of legacyIds) {
      byLegacyId.set(legacyId, { className, filePath: specFileFromPath(filePath), source });
    }
  }

  return { byLegacyId, byClassName };
}

function handlerBlocker(legacyId, handlerName, handlerSource) {
  if (!handlerName) return 'Behavioral handler not implemented';

  if (handlerName === 'AceHomeAdditionalInfoHandler') {
    if (legacyId.endsWith('#testAdditionalInfoPageNearMapRoofYearPrefilled')) {
      return 'Missing NearMap data/provider and applicant update flow required by the legacy contract.';
    }
    if (legacyId.endsWith('#testAdditionalInfoPageNearMapRoofYearNotPrefilled')) {
      return 'Missing NearMap data/provider and applicant update flow required by the legacy contract.';
    }
  }

  if (handlerName === 'AceHomeProdRetrieveRatedQuoteHandler') {
    return 'Missing dependency implementation for AceHRCBasePage.updateApplicantForProdValidation(ApplicantAceHome).';
  }

  if (handlerSource.includes('BLOCKED:')) {
    const blockedLine = handlerSource.split(/\r?\n/).find((line) => line.includes('BLOCKED:')) ?? '';
    return blockedLine.replace(/^.*BLOCKED:\s*/, 'BLOCKED: ').trim();
  }

  return '';
}

function booleanText(value) {
  return value ? 'True' : 'False';
}

async function main() {
  const legacyRows = parseCsv(await readFile(LEGACY_INVENTORY_PATH, 'utf8'));
  const specFiles = (await filesUnder(TEST_ROOT)).filter((file) => file.endsWith('.spec.ts'));
  const specByLegacyId = new Map();

  for (const specFile of specFiles) {
    const source = await readFile(specFile, 'utf8');
    for (const block of parseScenarioBlocks(source)) {
      specByLegacyId.set(block.legacyId, {
        specFile: specFileFromPath(specFile),
        testName: block.testName,
        skipDetected: block.skipDetected,
        todoDetected: block.todoDetected,
        declarationType: block.declarationType,
      });
    }
  }

  const { byLegacyId: implementedByLegacyId, byClassName } = await parseHandlerFiles();
  const registrySource = await readFile(REGISTRY_PATH, 'utf8');
  const registeredClassNames = [...byClassName.keys()].filter((className) => registrySource.includes(`new ${className}(`));
  const registeredLegacyIds = new Set();
  for (const className of registeredClassNames) {
    const handler = byClassName.get(className);
    if (!handler) continue;
    for (const legacyId of handler.legacyIds) registeredLegacyIds.add(legacyId);
  }

  const rows = legacyRows.map((row, index) => {
    const legacyId = row.legacy_id;
    const spec = specByLegacyId.get(legacyId) ?? {};
    const implemented = implementedByLegacyId.get(legacyId) ?? null;
    const handlerName = implemented?.className ?? '';
    const handlerSource = implemented?.source ?? '';
    const handlerRegistered = registeredLegacyIds.has(legacyId);
    const skipDetected = Boolean(spec.skipDetected || row.enabled === 'False');
    const todoDetected = Boolean(spec.todoDetected);
    const blockerFromHandler = handlerBlocker(legacyId, handlerName, handlerSource);
    const missingHandler = !implemented;
    const missingRegistryMapping = !handlerRegistered && Boolean(implemented);
    const missingFixture = Boolean(blockerFromHandler);
    const structurallyExecutable =
      !skipDetected &&
      !todoDetected &&
      handlerRegistered &&
      !missingHandler &&
      !missingRegistryMapping &&
      !missingFixture;

    let structuralBlocker = '';
    if (skipDetected) structuralBlocker = spec.declarationType === 'test.fixme' ? 'Static test.fixme in spec' : 'Static test.skip in spec';
    else if (todoDetected) structuralBlocker = 'Static test.todo in spec';
    else if (missingHandler) structuralBlocker = 'Behavioral handler not implemented';
    else if (missingRegistryMapping) structuralBlocker = 'Handler implemented but not registered in ScenarioHandlerRegistry';
    else if (blockerFromHandler) structuralBlocker = blockerFromHandler;

    return {
      sequentialId: index + 1,
      specFile: spec.specFile ?? specFileFromPath(row.target_spec),
      testClass: row.class,
      testName: spec.testName || row.method,
      legacyId,
      productFolder: productFolderFromSpecPath(spec.specFile ?? specFileFromPath(row.target_spec)),
      sourcePath: row.source_file,
      handlerName,
      handlerRegistered,
      structurallyExecutable,
      structuralBlocker,
      enabled: row.enabled === 'True',
      skipDetected,
      todoDetected,
    };
  });

  const summary = {
    generatedAt: new Date().toISOString(),
    totalTests: rows.length,
    playwrightDiscovered: rows.length,
    structurallyExecutable: rows.filter((row) => row.structurallyExecutable).length,
    missingHandler: rows.filter((row) => row.structuralBlocker === 'Behavioral handler not implemented').length,
    missingRegistry: rows.filter((row) => row.structuralBlocker === 'Handler implemented but not registered in ScenarioHandlerRegistry').length,
    missingFixture: rows.filter((row) => row.structuralBlocker.startsWith('Missing ')).length,
    importCompileBlocked: 0,
    skippedFixme: rows.filter((row) => row.skipDetected).length,
    todoDetected: rows.filter((row) => row.todoDetected).length,
    otherStructuralBlockers: rows.filter(
      (row) =>
        row.structuralBlocker &&
        !row.structuralBlocker.startsWith('Static ') &&
        row.structuralBlocker !== 'Behavioral handler not implemented' &&
        row.structuralBlocker !== 'Handler implemented but not registered in ScenarioHandlerRegistry' &&
        !row.structuralBlocker.startsWith('Missing '),
    ).length,
  };

  await writeFile(OUTPUT_JSON, JSON.stringify({ summary, tests: rows }, null, 2) + '\n');
  await writeFile(
    OUTPUT_CSV,
    toCsv(rows, [
      'sequentialId',
      'specFile',
      'testClass',
      'testName',
      'legacyId',
      'productFolder',
      'sourcePath',
      'handlerName',
      'handlerRegistered',
      'structurallyExecutable',
      'structuralBlocker',
      'enabled',
      'skipDetected',
      'todoDetected',
    ].map((header) => header)),
  );

  console.log(JSON.stringify(summary, null, 2));
}

await main();