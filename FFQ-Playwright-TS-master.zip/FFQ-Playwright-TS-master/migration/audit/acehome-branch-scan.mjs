import { chromium } from '@playwright/test';
import ExcelJS from 'exceljs';

function seededRng(seed) {
  let state = seed >>> 0;
  return () => {
    state = (1664525 * state + 1013904223) >>> 0;
    return state / 0x100000000;
  };
}

function classify(url, title, headingText) {
  const u = (url || '').toLowerCase();
  const t = (title || '').toLowerCase();
  const h = (headingText || '').toLowerCase();

  if (h.includes('review quote') || u.includes('/review-quote')) return 'REVIEW_QUOTE_COMPATIBLE';
  if (u.includes('call-for-quote') || t.includes('call for quote')) return 'CALL_FOR_QUOTE';
  if (u.includes('quote-and-buy') || t.includes('customerengage quote and buy')) return 'GUIDEWIRE_BRANCH';
  if (h.includes("it's not you") || h.includes('unable to offer') || h.includes('continue your quote request')) return 'KNOCKOUT';
  if (u.includes('/quote/home/personal-info') || h.includes('what\'s the address') || h.includes('contact information')) return 'PERSONAL_INFO_BRANCH';
  if (u.includes('/quote/home/property-type') || h.includes('what type of property') || h.includes('tell us more about your home')) return 'PROPERTY_TYPE_BRANCH';
  if (h.includes('property information') || h.includes('property info')) return 'PROPERTY_INFO_BRANCH';
  return 'OTHER';
}

async function loadRows() {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile('data/legacy/AceHomeTestData.xlsx');
  const ws = wb.getWorksheet('ApplicantHome');
  if (!ws) throw new Error('ApplicantHome worksheet missing');

  const headers = ws.getRow(1).values.slice(1).map((v) => String(v || '').trim());
  const idx = (name) => headers.indexOf(name) + 1;

  const rows = [];
  ws.eachRow((row, rowNumber) => {
    if (rowNumber === 1) return;
    let hasValue = false;
    for (let i = 1; i <= headers.length; i += 1) {
      const v = row.getCell(i).value;
      if (v !== null && v !== undefined && v !== '') {
        hasValue = true;
        break;
      }
    }
    if (!hasValue) return;

    const id = Number(String(row.getCell(idx('id')).text || '').trim());
    const stateCode = String(row.getCell(idx('stateCode')).text || '').trim();
    const zipCode = String(row.getCell(idx('zipCode')).text || '').replace(/\D/g, '').slice(0, 5);
    const testCategory = String(row.getCell(idx('testCategory')).text || '').trim();
    const numberOfStories = String(row.getCell(idx('numberOfStories')).text || '').trim();
    const roofCover = String(row.getCell(idx('roofCover')).text || '').trim();
    const heatingSystem = String(row.getCell(idx('heatingSystem')).text || '').trim();

    rows.push({ rowNumber, id, stateCode, zipCode, testCategory, numberOfStories, roofCover, heatingSystem });
  });

  return rows;
}

function uniqueRowSeeds(rows, maxSeed = 4000) {
  const byRow = new Map();
  for (let seed = 1; seed <= maxSeed; seed += 1) {
    const rng = seededRng(seed);
    const index = Math.min(Math.floor(rng() * rows.length), rows.length - 1);
    const row = rows[index];
    if (!byRow.has(row.rowNumber)) byRow.set(row.rowNumber, seed);
    if (byRow.size === rows.length) break;
  }
  return byRow;
}

async function scanCandidate(baseUrl, candidate, browser) {
  const { seed, row } = candidate;
  const correlationId = `acehome-${row.id}-${row.stateCode}-${row.rowNumber}`;
  const page = await browser.newPage();

  try {
    await page.goto(baseUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });

    const reject = page.getByRole('button', { name: /^reject$/i }).first();
    if (await reject.isVisible({ timeout: 500 }).catch(() => false)) await reject.click();

    const close = page.getByRole('button', { name: /^close$/i }).first();
    if (await close.isVisible({ timeout: 300 }).catch(() => false)) await close.click();

    const homeOption = page.getByRole('option', { name: /home icon/i }).first();
    await homeOption.click({ timeout: 12000 });

    const zip = page.getByRole('textbox', { name: /zip code/i }).first();
    await zip.fill(row.zipCode);
    await zip.press('Tab').catch(() => {});

    const start = page.getByRole('button', { name: /start\s*my\s*quote|start\s*quote|get\s*my\s*quote/i }).first();
    await start.click({ timeout: 12000 });

    await page.waitForLoadState('domcontentloaded', { timeout: 12000 }).catch(() => {});

    const headingText = await page
      .locator('h1:visible, h2:visible, h3:visible, [role="heading"]:visible')
      .allInnerTexts()
      .then((arr) => arr.join(' | '))
      .catch(() => '');

    const url = page.url();
    const title = await page.title().catch(() => '');
    const firstBranch = classify(url, title, headingText);

    return {
      workbook: 'legacy/AceHomeTestData.xlsx',
      worksheet: 'ApplicantHome',
      row: row.rowNumber,
      seed,
      correlationId,
      stateCode: row.stateCode,
      propertyType: row.numberOfStories,
      eligibility: {
        testCategory: row.testCategory,
        roofCover: row.roofCover,
        heatingSystem: row.heatingSystem,
      },
      firstBranch,
      url,
      title,
    };
  } catch (error) {
    return {
      workbook: 'legacy/AceHomeTestData.xlsx',
      worksheet: 'ApplicantHome',
      row: row.rowNumber,
      seed,
      correlationId,
      stateCode: row.stateCode,
      propertyType: row.numberOfStories,
      eligibility: {
        testCategory: row.testCategory,
        roofCover: row.roofCover,
        heatingSystem: row.heatingSystem,
      },
      firstBranch: 'OTHER',
      url: page.url(),
      title: await page.title().catch(() => ''),
      error: String(error?.message || error),
    };
  } finally {
    await page.close();
  }
}

async function main() {
  const baseUrl = process.env.FFQ_BASE_URL || 'https://ffqautouiqa.farmers.com/fastquote/';
  const limit = Number(process.env.ACEHOME_SCAN_LIMIT || '80');

  const rows = await loadRows();
  const seedsByRow = uniqueRowSeeds(rows, 4000);
  const candidates = rows
    .map((row) => ({ row, seed: seedsByRow.get(row.rowNumber) }))
    .filter((x) => x.seed !== undefined)
    .slice(0, limit);

  const browser = await chromium.launch({ headless: true });
  const results = [];
  let compatible = null;

  for (const candidate of candidates) {
    const result = await scanCandidate(baseUrl, candidate, browser);
    results.push(result);
    console.log(JSON.stringify(result));

    if (result.firstBranch === 'REVIEW_QUOTE_COMPATIBLE' || result.firstBranch === 'PROPERTY_INFO_BRANCH') {
      compatible = result;
      break;
    }
  }

  await browser.close();

  const summary = {
    scanned: results.length,
    compatible,
    counts: results.reduce((acc, r) => {
      acc[r.firstBranch] = (acc[r.firstBranch] || 0) + 1;
      return acc;
    }, {}),
  };

  console.log('SUMMARY=' + JSON.stringify(summary));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
