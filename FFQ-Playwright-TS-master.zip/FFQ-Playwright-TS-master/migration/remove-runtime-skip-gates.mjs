import { readFile, readdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const INVENTORY_TOTAL = 2941;
const INVENTORY_ENABLED = 2691;
const INVENTORY_DISABLED = 250;
const RUNTIME_SKIP_GATE_REGEX =
  /^\s*test\.skip\(\s*!env\.EXECUTE_MIGRATED_TESTS\s*,\s*'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment\.'\s*\);\s*$/;

async function filesUnder(directory) {
  const entries = await readdir(directory, { withFileTypes: true }).catch(() => []);
  const nested = await Promise.all(
    entries.map((entry) => {
      const path = join(directory, entry.name);
      return entry.isDirectory() ? filesUnder(path) : [path];
    }),
  );
  return nested.flat();
}

function parseCsv(text) {
  const rows = [];
  let current = '';
  let row = [];
  let inQuotes = false;

  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    const next = text[i + 1];

    if (char === '"') {
      if (inQuotes && next === '"') {
        current += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (char === ',' && !inQuotes) {
      row.push(current);
      current = '';
      continue;
    }

    if ((char === '\n' || char === '\r') && !inQuotes) {
      if (char === '\r' && next === '\n') i += 1;
      row.push(current);
      current = '';
      if (row.length > 1 || row[0] !== '') rows.push(row);
      row = [];
      continue;
    }

    current += char;
  }

  if (current.length > 0 || row.length > 0) {
    row.push(current);
    rows.push(row);
  }

  const header = rows[0] ?? [];
  const dataRows = rows.slice(1).map((values) => {
    const record = {};
    for (let i = 0; i < header.length; i += 1) {
      record[header[i]] = values[i] ?? '';
    }
    return record;
  });

  return { rows: dataRows };
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function parseBlocks(lines) {
  const legacyLineIndexes = [];
  for (let i = 0; i < lines.length; i += 1) {
    if (/^\s*\/\/\s*legacy-id:\s*\S+\s*$/.test(lines[i])) legacyLineIndexes.push(i);
  }

  return legacyLineIndexes.map((startIndex, idx) => {
    const endIndex = idx + 1 < legacyLineIndexes.length ? legacyLineIndexes[idx + 1] : lines.length;
    const idMatch = lines[startIndex].match(/^\s*\/\/\s*legacy-id:\s*(\S+)\s*$/);
    const legacyId = idMatch?.[1];
    if (!legacyId) throw new Error(`Unable to parse legacy-id at line ${startIndex + 1}.`);

    let declarationLineIndex = -1;
    for (let i = startIndex + 1; i < endIndex; i += 1) {
      if (lines[i].trim() === '') continue;
      if (/^\s*\/\//.test(lines[i])) continue;
      declarationLineIndex = i;
      break;
    }

    if (declarationLineIndex < 0) {
      throw new Error(`No declaration found for ${legacyId}.`);
    }

    const declarationLine = lines[declarationLineIndex];
    const declarationType = /\btest\.skip\s*\(/.test(declarationLine)
      ? 'test.skip'
      : /\btest\s*\(/.test(declarationLine)
        ? 'test'
        : 'unknown';

    return {
      legacyId,
      startIndex,
      endIndex,
      declarationType,
    };
  });
}

async function main() {
  const inventoryCsv = await readFile(new URL('./audit/legacy-test-inventory.csv', import.meta.url), 'utf8');
  const { rows } = parseCsv(inventoryCsv);

  const inventoryByLegacyId = new Map();
  for (const row of rows) {
    const legacyId = row.legacy_id;
    if (!legacyId) throw new Error('Inventory row missing legacy_id.');
    if (inventoryByLegacyId.has(legacyId)) {
      throw new Error(`Duplicate legacy_id in inventory: ${legacyId}`);
    }
    inventoryByLegacyId.set(legacyId, row);
  }

  const enabledCount = [...inventoryByLegacyId.values()].filter((row) => row.enabled === 'True').length;
  const disabledCount = [...inventoryByLegacyId.values()].filter((row) => row.enabled === 'False').length;

  assert(
    inventoryByLegacyId.size === INVENTORY_TOTAL,
    `Inventory total mismatch: expected ${INVENTORY_TOTAL}, got ${inventoryByLegacyId.size}`,
  );
  assert(
    enabledCount === INVENTORY_ENABLED,
    `Enabled inventory mismatch: expected ${INVENTORY_ENABLED}, got ${enabledCount}`,
  );
  assert(
    disabledCount === INVENTORY_DISABLED,
    `Disabled inventory mismatch: expected ${INVENTORY_DISABLED}, got ${disabledCount}`,
  );

  const testRoot = fileURLToPath(new URL('../tests/legacy', import.meta.url));
  const specFiles = (await filesUnder(testRoot)).filter((path) => path.endsWith('.spec.ts'));

  let declarations = 0;
  let normalDeclarations = 0;
  let staticSkipDeclarations = 0;
  let runtimeSkipBefore = 0;
  let runtimeSkipAfter = 0;
  let removedRuntimeSkips = 0;

  const seenLegacyIds = new Set();

  for (const file of specFiles) {
    const source = await readFile(file, 'utf8');
    const lines = source.split(/\r?\n/);
    const blocks = parseBlocks(lines);

    let fileChanged = false;

    for (const block of blocks) {
      declarations += 1;
      if (seenLegacyIds.has(block.legacyId)) {
        throw new Error(`Duplicate legacy-id across specs: ${block.legacyId}`);
      }
      seenLegacyIds.add(block.legacyId);

      const inventory = inventoryByLegacyId.get(block.legacyId);
      if (!inventory) {
        throw new Error(`Legacy ID present in tests but missing from inventory: ${block.legacyId}`);
      }

      const blockLines = lines.slice(block.startIndex, block.endIndex);
      const runtimeGateIndexes = [];
      for (let i = 0; i < blockLines.length; i += 1) {
        if (RUNTIME_SKIP_GATE_REGEX.test(blockLines[i])) runtimeGateIndexes.push(i);
      }

      runtimeSkipBefore += runtimeGateIndexes.length;

      if (inventory.enabled === 'True') {
        if (block.declarationType !== 'test') {
          throw new Error(`Enabled legacy ID must use test(): ${block.legacyId} (found ${block.declarationType})`);
        }
        normalDeclarations += 1;

        if (runtimeGateIndexes.length > 1) {
          throw new Error(`Multiple runtime gates found in enabled test block: ${block.legacyId}`);
        }
        if (runtimeGateIndexes.length === 1) {
          const absoluteIndex = block.startIndex + runtimeGateIndexes[0];
          lines[absoluteIndex] = '__REMOVE_RUNTIME_SKIP_GATE__';
          removedRuntimeSkips += 1;
          fileChanged = true;
        }
      } else if (inventory.enabled === 'False') {
        if (block.declarationType !== 'test.skip') {
          throw new Error(
            `Disabled legacy ID must use test.skip(): ${block.legacyId} (found ${block.declarationType})`,
          );
        }
        staticSkipDeclarations += 1;

        if (runtimeGateIndexes.length > 0) {
          throw new Error(`Runtime gate found inside disabled test block: ${block.legacyId}`);
        }
      } else {
        throw new Error(`Unexpected enabled value for ${block.legacyId}: ${inventory.enabled}`);
      }
    }

    if (fileChanged) {
      const nextLines = lines.filter((line) => line !== '__REMOVE_RUNTIME_SKIP_GATE__');
      await writeFile(file, `${nextLines.join('\n')}\n`, 'utf8');
    }
  }

  const missingLegacyIds = [...inventoryByLegacyId.keys()].filter((legacyId) => !seenLegacyIds.has(legacyId));
  assert(missingLegacyIds.length === 0, `Missing legacy IDs in specs: ${missingLegacyIds.length}`);

  for (const file of specFiles) {
    const source = await readFile(file, 'utf8');
    runtimeSkipAfter += (source.match(/test\.skip\(\s*!env\.EXECUTE_MIGRATED_TESTS\s*,/g) ?? []).length;
  }

  const summary = {
    declarations,
    normalDeclarations,
    staticSkipDeclarations,
    runtimeSkipBefore,
    runtimeSkipAfter,
    removedRuntimeSkips,
    idempotent: runtimeSkipAfter === 0,
  };

  console.log(JSON.stringify(summary, null, 2));

  assert(
    declarations === INVENTORY_TOTAL,
    `Declaration total mismatch: expected ${INVENTORY_TOTAL}, got ${declarations}`,
  );
  assert(
    normalDeclarations === INVENTORY_ENABLED,
    `Enabled declaration mismatch: expected ${INVENTORY_ENABLED}, got ${normalDeclarations}`,
  );
  assert(
    staticSkipDeclarations === INVENTORY_DISABLED,
    `Disabled declaration mismatch: expected ${INVENTORY_DISABLED}, got ${staticSkipDeclarations}`,
  );
  assert(runtimeSkipAfter === 0, `Runtime skip gates remain: ${runtimeSkipAfter}`);
}

await main();
