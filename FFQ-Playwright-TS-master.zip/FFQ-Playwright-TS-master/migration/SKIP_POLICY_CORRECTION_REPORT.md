# Skip Policy Correction Report

## Objective

Apply a strict skip policy correction across migrated Playwright specs while preserving migration safety and certification governance.

Required invariants:

- Originally enabled legacy methods remain normal `test(...)` declarations.
- Originally disabled legacy methods remain declaration-level `test.skip(...)`.
- No global environment gate can skip originally enabled tests at runtime.
- Missing functional handlers fail closed with a clear error.

## Root Cause

Generated migrated specs contained runtime skip gates inside enabled test bodies:

- `test.skip(!env.EXECUTE_MIGRATED_TESTS, 'Set EXECUTE_MIGRATED_TESTS=true after configuring the target environment.');`

This caused enabled tests to be discovered but skipped during execution, masking real migration status.

## Remediation Implemented

1. Added deterministic skip-policy audit utility:

- `migration/check-skip-policy.mjs`

2. Added deterministic runtime-skip removal utility:

- `migration/remove-runtime-skip-gates.mjs`

3. Removed runtime skip gates only from enabled scenario blocks in generated specs.

4. Enforced fail-closed behavior in executor boundary:

- `src/migration/ScenarioExecutor.ts`
- Missing handler now throws:
  - `Behavioral handler not implemented for <legacyId>`
- Execution disabled via env now throws configuration error (no skip).
- Uncertified execution requires explicit certification-mode allow + explicit allowlist membership.

5. Added command wiring:

- `package.json`
  - `audit:skip-policy`
  - `migration:remove-runtime-skip-gates`

6. Added local env documentation example:

- `.env.example`

## Before vs After (Skip Policy)

Baseline audit (before removal):

- totalLegacyIds: 2941
- enabledExpected: 2691
- disabledExpected: 250
- runtimeSkipGatesInEnabled: 2691

Post-remediation audit:

- totalLegacyIds: 2941
- enabledExpected: 2691
- disabledExpected: 250
- enabledDeclaredAsTest: 2691
- disabledDeclaredAsSkip: 250
- runtimeSkipGatesInEnabled: 0
- duplicate/missing/extra ids: 0
- specFiles scanned: 218

## Validation Results

### Static validations

1. `npm run typecheck`

- Result: PASS (`tsc --noEmit` completed with no errors)

2. `npm run audit:parity`

- Result: PASS
- Original: 2941
- Migrated: 2941
- Remaining: 0
- Duplicates: 0

3. `npm run audit:skip-policy`

- Result: PASS
- Counts matched exactly and runtime gates in enabled blocks were 0

4. `npm run test:list`

- Result: PASS
- Discovery summary: `Total: 2941 tests in 218 files`

### Runtime spot validations (targeted)

1. Golden Auto scenario (enabled + implemented uncertified handler)

- Command: `npx playwright test tests/legacy/auto/QuoteE2ETests.spec.ts --project=chromium --headed --grep "aceAutoEndToEndOneRandomApplicant"`
- Result: EXECUTED (not skipped), entered scenario executor and handler path.
- Observed failure location:
  - `src/pages/auto/QuoteSummaryPage.ts:26`
  - `expect(locator).toBeVisible()` for review quote heading
- Interpretation: policy fix is correct (test is running), and this is an application/flow assertion failure, not a skip-policy regression.

2. Enabled but unimplemented Home scenario

- Command: `npx playwright test tests/legacy/home/QuoteScenarios.spec.ts --project=chromium --grep "getHomeQuote"`
- Result: FAIL CLOSED as required.
- Observed error:
  - `Behavioral handler not implemented for com.farmers.ffq.home.QuoteScenarios#getHomeQuote`
- Source:
  - `src/migration/ScenarioExecutor.ts:48`

3. Originally disabled scenario

- Command: `npx playwright test tests/legacy/acebundle/AceAutoCondoBundleTests.spec.ts --project=chromium --grep "aceAutoCondoBundleE2ETest"`
- Result: SKIPPED (declaration-level skip preserved)

## Governance and Safety Confirmation

- No broad conversion of disabled methods to enabled.
- No runtime skip gate remains in enabled migrated blocks.
- Certification architecture remains intact and enforced.
- No runtime-certified promotion was applied as part of this correction.
- Full suite was not executed; only targeted validations were run.
- Golden Auto work was preserved and exercised through live execution path.

## Residual Known Issue

Golden scenario currently fails at a quote summary visibility assertion in the application flow:

- `src/pages/auto/QuoteSummaryPage.ts:26`

This is outside skip-policy correction scope and should be tracked as a functional behavior/debug follow-up.

## Final Status

Skip-policy correction is complete and validated against all required invariants.
