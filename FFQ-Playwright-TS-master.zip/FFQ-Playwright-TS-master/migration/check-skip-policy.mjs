import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const INVENTORY_TOTAL = 2941;
const INVENTORY_ENABLED = 2691;
const INVENTORY_DISABLED = 250;
const RUNTIME_SKIP_GATE = 'test.skip(!env.EXECUTE_MIGRATED_TESTS';

async function filesUnder(directory) {
  const entries = await readdir(directory, { withFileTypes: true }).catch(() => []);
  const nested = await Promise.all(
    entries.map((entry) => {
      const path = join(directory, entry.name);
      return entry.isDirectory() ? filesUnder(path) : [path];
    }),
  );
  return nested.flat();
}

function parseCsv(text) {
  const rows = [];
  let current = '';
  let row = [];
  let inQuotes = false;

  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    const next = text[i + 1];

    if (char === '"') {
      if (inQuotes && next === '"') {
        current += '"';
        i += 1;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (char === ',' && !inQuotes) {
      row.push(current);
      current = '';
      continue;
    }

    if ((char === '\n' || char === '\r') && !inQuotes) {
      if (char === '\r' && next === '\n') i += 1;
      row.push(current);
      current = '';
      if (row.length > 1 || row[0] !== '') rows.push(row);
      row = [];
      continue;
    }

    current += char;
  }

  if (current.length > 0 || row.length > 0) {
    row.push(current);
    rows.push(row);
  }

  const header = rows[0] ?? [];
  const dataRows = rows.slice(1).map((values) => {
    const record = {};
    for (let i = 0; i < header.length; i += 1) {
      record[header[i]] = values[i] ?? '';
    }
    return record;
  });

  return { header, rows: dataRows };
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function parseScenarioBlocks(source) {
  const lines = source.split(/\r?\n/);
  const legacyLineIndexes = [];
  for (let i = 0; i < lines.length; i += 1) {
    if (/^\s*\/\/\s*legacy-id:\s*\S+\s*$/.test(lines[i])) legacyLineIndexes.push(i);
  }

  return legacyLineIndexes.map((startIndex, idx) => {
    const endIndex = idx + 1 < legacyLineIndexes.length ? legacyLineIndexes[idx + 1] : lines.length;
    const idMatch = lines[startIndex].match(/^\s*\/\/\s*legacy-id:\s*(\S+)\s*$/);
    const legacyId = idMatch?.[1];
    if (!legacyId) {
      throw new Error(`Unable to parse legacy-id comment at line ${startIndex + 1}.`);
    }

    let declarationLineIndex = -1;
    for (let i = startIndex + 1; i < endIndex; i += 1) {
      if (lines[i].trim() === '') continue;
      if (/^\s*\/\//.test(lines[i])) continue;
      declarationLineIndex = i;
      break;
    }

    if (declarationLineIndex < 0) {
      throw new Error(`No test declaration found for ${legacyId}.`);
    }

    const declarationLine = lines[declarationLineIndex];
    const declarationType = /\btest\.skip\s*\(/.test(declarationLine)
      ? 'test.skip'
      : /\btest\s*\(/.test(declarationLine)
        ? 'test'
        : 'unknown';

    const blockLines = lines.slice(startIndex, endIndex);
    const hasRuntimeSkipGate = blockLines.some((line) => line.includes(RUNTIME_SKIP_GATE));

    return {
      legacyId,
      startIndex,
      endIndex,
      declarationLineIndex,
      declarationType,
      hasRuntimeSkipGate,
    };
  });
}

async function main() {
  const inventoryCsv = await readFile(new URL('./audit/legacy-test-inventory.csv', import.meta.url), 'utf8');
  const { rows } = parseCsv(inventoryCsv);

  const inventoryByLegacyId = new Map();
  for (const row of rows) {
    const legacyId = row.legacy_id;
    if (!legacyId) throw new Error('Inventory row missing legacy_id.');
    if (inventoryByLegacyId.has(legacyId)) {
      throw new Error(`Duplicate legacy_id in inventory: ${legacyId}`);
    }
    inventoryByLegacyId.set(legacyId, row);
  }

  const enabledCount = [...inventoryByLegacyId.values()].filter((row) => row.enabled === 'True').length;
  const disabledCount = [...inventoryByLegacyId.values()].filter((row) => row.enabled === 'False').length;

  const testRoot = fileURLToPath(new URL('../tests/legacy', import.meta.url));
  const specFiles = (await filesUnder(testRoot)).filter((path) => path.endsWith('.spec.ts'));

  const declaredLegacyIds = [];
  let normalDeclarations = 0;
  let staticSkipDeclarations = 0;
  let runtimeSkipGatesInEnabled = 0;
  let runtimeSkipGatesInDisabled = 0;
  let testFixmeCount = 0;
  let describeSkipCount = 0;

  for (const file of specFiles) {
    const source = await readFile(file, 'utf8');
    testFixmeCount += (source.match(/\btest\.fixme\s*\(/g) ?? []).length;
    describeSkipCount += (source.match(/\bdescribe\.skip\s*\(/g) ?? []).length;

    const blocks = parseScenarioBlocks(source);
    for (const block of blocks) {
      declaredLegacyIds.push(block.legacyId);
      const inventory = inventoryByLegacyId.get(block.legacyId);
      if (!inventory) {
        throw new Error(`Legacy ID present in tests but not inventory: ${block.legacyId}`);
      }

      if (inventory.enabled === 'True') {
        if (block.declarationType !== 'test') {
          throw new Error(
            `Enabled legacy ID must be declared with test(): ${block.legacyId} (found ${block.declarationType})`,
          );
        }
        normalDeclarations += 1;
        if (block.hasRuntimeSkipGate) runtimeSkipGatesInEnabled += 1;
      } else if (inventory.enabled === 'False') {
        if (block.declarationType !== 'test.skip') {
          throw new Error(
            `Disabled legacy ID must be declared with test.skip(): ${block.legacyId} (found ${block.declarationType})`,
          );
        }
        staticSkipDeclarations += 1;
        if (block.hasRuntimeSkipGate) runtimeSkipGatesInDisabled += 1;
      } else {
        throw new Error(`Unexpected enabled value for ${block.legacyId}: ${inventory.enabled}`);
      }
    }
  }

  const uniqueDeclared = new Set(declaredLegacyIds);
  const duplicateLegacyIds = declaredLegacyIds.length - uniqueDeclared.size;

  const missingLegacyIds = [...inventoryByLegacyId.keys()].filter((legacyId) => !uniqueDeclared.has(legacyId));
  const extraLegacyIds = [...uniqueDeclared].filter((legacyId) => !inventoryByLegacyId.has(legacyId));

  const totalDeclarations = normalDeclarations + staticSkipDeclarations;
  const summary = {
    inventoryTotal: inventoryByLegacyId.size,
    inventoryEnabled: enabledCount,
    inventoryDisabled: disabledCount,
    totalDeclarations,
    normalEnabledDeclarations: normalDeclarations,
    staticDisabledDeclarations: staticSkipDeclarations,
    runtimeSkipGatesInEnabled,
    runtimeSkipGatesInDisabled,
    duplicateLegacyIds,
    missingLegacyIds: missingLegacyIds.length,
    extraLegacyIds: extraLegacyIds.length,
    testFixmeCount,
    describeSkipCount,
    specFiles: specFiles.length,
  };

  console.log(JSON.stringify(summary, null, 2));

  assert(
    inventoryByLegacyId.size === INVENTORY_TOTAL,
    `Inventory total mismatch: expected ${INVENTORY_TOTAL}, got ${inventoryByLegacyId.size}`,
  );
  assert(
    enabledCount === INVENTORY_ENABLED,
    `Enabled inventory mismatch: expected ${INVENTORY_ENABLED}, got ${enabledCount}`,
  );
  assert(
    disabledCount === INVENTORY_DISABLED,
    `Disabled inventory mismatch: expected ${INVENTORY_DISABLED}, got ${disabledCount}`,
  );
  assert(
    totalDeclarations === INVENTORY_TOTAL,
    `Declaration total mismatch: expected ${INVENTORY_TOTAL}, got ${totalDeclarations}`,
  );
  assert(
    normalDeclarations === INVENTORY_ENABLED,
    `Enabled declaration mismatch: expected ${INVENTORY_ENABLED}, got ${normalDeclarations}`,
  );
  assert(
    staticSkipDeclarations === INVENTORY_DISABLED,
    `Disabled declaration mismatch: expected ${INVENTORY_DISABLED}, got ${staticSkipDeclarations}`,
  );
  assert(runtimeSkipGatesInEnabled === 0, `Runtime skip gates remain in enabled tests: ${runtimeSkipGatesInEnabled}`);
  assert(duplicateLegacyIds === 0, `Duplicate legacy IDs found in tests: ${duplicateLegacyIds}`);
  assert(missingLegacyIds.length === 0, `Missing legacy IDs in tests: ${missingLegacyIds.length}`);
  assert(extraLegacyIds.length === 0, `Unexpected extra legacy IDs in tests: ${extraLegacyIds.length}`);
}

await main();
