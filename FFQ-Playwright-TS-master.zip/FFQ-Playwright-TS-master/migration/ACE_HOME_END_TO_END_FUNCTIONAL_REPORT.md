# ACE Home End-to-End Functional Report

## Scope and Guardrails

- Scope limited to the 3 scenarios in tests/legacy/acehome/AceHomeEndToEndTest.spec.ts.
- Generated spec remained immutable.
- Auto implementation was not modified.
- Runtime remained fail-closed (no false PASS behavior).

## Scenario Matrix

| Legacy ID                                                                               | Test                                        | DataProvider                                                                                                 | Attempts | Last checkpoint                    | Handler                              | Runtime result                                                                                                                                                             | Evidence                                                                                                                                                                                                                       | Status  |
| --------------------------------------------------------------------------------------- | ------------------------------------------- | ------------------------------------------------------------------------------------------------------------ | -------: | ---------------------------------- | ------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------- |
| com.farmers.ffq.acehome.AceHomeEndToEndTest#testReviewQuotePagePresentmentCardHome      | testReviewQuotePagePresentmentCardHome      | AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER (RANDOM_ROW, no excluded states)                       |        4 | provider-init                      | AceHomeReviewQuotePresentmentHandler | Throws required-secret error before navigation.                                                                                                                            | Terminal run output: `Required secret FFQ_PRODUCTION_APPLICANT_FIRST_NAME is not configured.`                                                                                                                                  | BLOCKED |
| com.farmers.ffq.acehome.AceHomeEndToEndTest#testSmokeReviewQuotePagePresentmentCardHome | testSmokeReviewQuotePagePresentmentCardHome | AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER (RANDOM_ROW, EXCLUDED_STATES={CA,LA,MA,MS,NC})         |       10 | 01-home-start / start-quote-submit | AceHomeSmokePresentmentHandler       | Landing flow is non-deterministic across environment branches and does not reliably reach Property Information; handler now fails closed with explicit BLOCKED diagnostic. | test-results/artifacts/legacy-acehome-AceHomeEndT-24fc0-uotePagePresentmentCardHome-chromium/error-context.md, test-results/artifacts/legacy-acehome-AceHomeEndT-24fc0-uotePagePresentmentCardHome-chromium/01-home-start.json | BLOCKED |
| com.farmers.ffq.acehome.AceHomeEndToEndTest#testProdRetrieveRatedQuoteAceHome           | testProdRetrieveRatedQuoteAceHome           | AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER (CATEGORY_BIND_VALIDATION, INCLUDED_STATES={AZ,TX}) |        2 | provider-init                      | AceHomeProdRetrieveRatedQuoteHandler | Throws explicit dependency blocker by design.                                                                                                                              | Terminal run output: `BLOCKED: Missing dependency implementation for AceHRCBasePage.updateApplicantForProdValidation(ApplicantAceHome)...`                                                                                     | BLOCKED |

## Mapping and Implementation Notes

- Handlers mapped through registry and executed via executeMigratedScenario.
- DataProvider semantics implemented:
  - RANDOM_ROW selection with merged EXCLUDED_STATES.
  - ENVIRONMENT_STABILITY with CATEGORY_BIND_VALIDATION filtering and INCLUDED_STATES enforcement.
  - Deterministic seed override via ACE_HOME_PROVIDER_SEED.
- Sentinel/recovery behavior:
  - Recovery evidence enriched with legacyId, logical checkpoint, and correlation id.
  - Scenario 2 now annotates expected-knockout to avoid misleading recovery-limit noise when knockout branches appear.
- Copy DOM checkpointing:
  - HTML + PNG + JSON emitted for logical checkpoints.
  - JSON includes logicalScreenName, legacyId, testName, correlation id, URL/title/timestamp.

## AutoDebug History Summary (Scenario 2)

- Iteration 1: start CTA selector mismatch fixed (actual path required product selection + zip + Start my Quote + cookie handling).
- Iteration 2: flow advanced but diverged into unsupported branches (FGIA interstitial and alternate quote entry hosts).
- Iteration 3+: added explicit fail-closed BLOCKED diagnostics when Property Information contract is not reached.

## Assertions Migrated

- Review quote/additional coverages assertions are implemented in handlers and page objects with SoftAssertCollector evidence capture.
- No scenario reported PASS unless functional assertions complete.

## External Blockers

- Missing runtime secrets for scenario 1:
  - FFQ_PRODUCTION_APPLICANT_FIRST_NAME
  - FFQ_PRODUCTION_APPLICANT_LAST_NAME
  - FFQ_PRODUCTION_APPLICANT_EMAIL
- Missing legacy dependency source for scenario 3:
  - AceHRCBasePage.updateApplicantForProdValidation(ApplicantAceHome)
- Environment branch divergence for scenario 2 prevents deterministic progression to Property Information using currently available contract/source mapping.

## Invariant Validation

- typecheck: PASS (`tsc --noEmit`)
- test inventory: PASS (`Total: 2941 tests in 218 files`)
- parity: PASS (`original=2941 migrated=2941 remaining=0 duplicates=0`)
- skip-policy: PASS (`enabled=2691 disabled=250 runtimeSkipGates=0 missing=0 duplicates=0`)

## Metrics

- Target suite migration coverage: 3/3 handlers implemented (100%).
- Target suite runtime PASS: 0/3 (0.0%).
- Target suite runtime BLOCKED: 3/3 (100.0%).
- Share of total inventory represented by this suite: 3/2941 = 0.10%.
