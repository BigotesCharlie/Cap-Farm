import { existsSync } from 'node:fs';
import { readdir } from 'node:fs/promises';
import { join } from 'node:path';

const sourceRoots = ['src', 'tests'];
const rootArtifacts = ['playwright.config.js', 'playwright.config.js.map', 'playwright.config.d.ts'];
const generatedArtifactPattern = /\.(?:[cm]?js|[cm]?js\.map|d\.[cm]?ts)$/;

async function findGeneratedArtifacts(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const findings = await Promise.all(
    entries.map(async (entry) => {
      const entryPath = join(directory, entry.name);
      if (entry.isDirectory()) return findGeneratedArtifacts(entryPath);
      return generatedArtifactPattern.test(entry.name) ? [entryPath] : [];
    }),
  );
  return findings.flat();
}

const artifacts = [
  ...(await Promise.all(sourceRoots.map(findGeneratedArtifacts))).flat(),
  ...rootArtifacts.filter((artifact) => existsSync(artifact)),
];
if (artifacts.length > 0) {
  console.error('Generated JavaScript artifacts must not be committed:');
  artifacts.forEach((artifact) => console.error(`- ${artifact}`));
  process.exitCode = 1;
}
