# FFQ Playwright TypeScript

Playwright and TypeScript automation for Farmers Fast Quote (FFQ). The repository is a migration and stabilization effort for Auto, AceHome, and legacy FFQ scenarios. A test is complete only when it reaches its intended business flow and passes its functional assertions; declaration parity alone is not runtime certification.

## Contents

- [Quick Start](#quick-start)
- [Configuration](#configuration)
- [Architecture](#architecture)
- [Repository Structure](#repository-structure)
- [Libraries](#libraries)
- [Commands](#commands)
- [Quality Standards](#quality-standards)
- [Commit Convention](#commit-convention)
- [CI and Artifacts](#ci-and-artifacts)
- [Maintenance Rules](#maintenance-rules)

## Quick Start

### Prerequisites

- Node.js 22.x. The repository pins the major version in `.nvmrc`.
- npm, included with Node.js.
- Playwright browsers, installed by the command below.
- Access to the target FFQ environment and any required secrets.

```bash
# Optional when using nvm
nvm use

# Install exact dependency versions from package-lock.json.
npm ci

# Install the Chromium browser used by the default project.
npx playwright install chromium

# Create local environment configuration.
copy .env.example .env

# Run the local/CI quality gate.
npm run verify
```

PowerShell users can create the environment file with:

```powershell
Copy-Item .env.example .env
```

`npm install` also runs the Husky setup hook. Do not commit `.env` or secret values.

## Configuration

Environment variables are parsed and validated by [src/config/env.ts](src/config/env.ts). The defaults and available variables are documented in [.env.example](.env.example).

Important variables:

| Variable                                       | Purpose                                                                                                            |
| ---------------------------------------------- | ------------------------------------------------------------------------------------------------------------------ |
| `TEST_ENV`                                     | Logical target environment name. Defaults to `MA11`.                                                               |
| `FFQ_BASE_URL`                                 | Valid FFQ URL. Defaults to the QA Fast Quote URL.                                                                  |
| `HEADLESS`                                     | Runs the browser headlessly when `true`.                                                                           |
| `WORKERS`, `RETRIES`                           | Playwright parallelism and retry configuration.                                                                    |
| `*_TIMEOUT_MS`                                 | Test, assertion, action, and navigation timeouts.                                                                  |
| `FFQ_DEBUG_VISUAL`                             | Runs visual debugging settings.                                                                                    |
| `FFQ_KEEP_BROWSER_OPEN`                        | Pauses after a failed test for investigation.                                                                      |
| `EXECUTE_MIGRATED_TESTS`                       | Safety gate for migrated scenarios. Keep `false` until the environment, data, and runtime certification are ready. |
| `AUTO_PROVIDER_SEED`, `ACE_HOME_PROVIDER_SEED` | Makes provider selection reproducible.                                                                             |

Secrets such as Artifactory, database, Rally, Sauce, and production credentials must be supplied through local environment configuration or CI secrets. Never place them in source files, test data, or commits.

## Architecture

```text
Playwright test
	-> custom fixture
	-> migration scenario executor or product flow
	-> page objects
	-> browser UI

Excel workbook
	-> ExcelDataSource
	-> product data provider
	-> typed applicant/model
	-> flow and page object
```

- **Fixtures** configure the Playwright test object, recovery guard, browser zoom, evidence collection, and `afterEach` diagnostics.
- **Flows** coordinate page objects for a business journey. They own navigation sequencing, not individual selectors.
- **Page objects** own locators and page actions. Keep selectors and UI-specific behavior here.
- **Data providers** read Excel workbooks, filter/select data, and build typed models used by flows.
- **Migration components** map legacy test metadata to handlers and protect against false passes for uncertified scenarios.
- **Reporting** writes runtime evidence, final DOM snapshots, and Playwright output for diagnosis.

### Diagnostics and Recovery

The framework captures checkpoints and runtime evidence around failures. `RecoveryGuard` recognizes known environment states such as `KNOCKOUT`, `INCONVENIENCE`, and `TRY_AGAIN`; recovery is bounded to avoid infinite loops. Use captured DOM and evidence before changing locators or business flow logic.

## Repository Structure

```text
config/                  Test-case configuration
data/legacy/             Excel workbooks used by providers
migration/               Migration audits, reports, and maintenance scripts
scripts/                 Repository automation and validation scripts
src/
	config/                Validated environment configuration
	core/                  BasePage, browser helpers, checkpoints, recovery, assertions
	data/                  Excel source and product data providers
	fixtures/              Custom Playwright fixtures and lifecycle hooks
	flows/                 Auto and AceHome business-flow orchestration
	migration/             Scenario executor, registries, and handler implementations
	models/                Typed test-data models
	pages/                 Product and legacy page objects
	reporting/             Evidence models and custom Playwright reporter
tests/
	Auto/                  Modern Auto tests
	config/                Configuration tests
	data/                  Data tests
	legacy/                Generated legacy-migration tests
```

### Folder Ownership

- Add a selector or page interaction to `src/pages/<product>/`.
- Add multi-page orchestration to `src/flows/<product>/`.
- Add workbook parsing or selection logic to `src/data/` and `src/data/providers/`.
- Add a typed business-data shape to `src/models/`.
- Add a new test under the product or test category it validates; do not place tests in `src/`.
- Treat `migration/` and `tests/legacy/` as migration artifacts. Avoid hand-editing generated legacy tests unless the migration workflow explicitly requires it.

Keep this section current when adding a top-level folder, a new product area, or a new cross-cutting framework component. A maintained folder map makes onboarding and code ownership substantially easier.

## Libraries

| Library                                                   | Purpose                                                               |
| --------------------------------------------------------- | --------------------------------------------------------------------- |
| `@playwright/test`                                        | Browser automation, assertions, fixtures, reporters, and test runner. |
| `typescript`                                              | Strictly typed implementation. Compilation is non-emitting.           |
| `exceljs`                                                 | Excel workbook test-data access.                                      |
| `zod`                                                     | Environment-variable validation.                                      |
| `dotenv`                                                  | Local `.env` loading.                                                 |
| `eslint`, `typescript-eslint`, `eslint-plugin-playwright` | Static analysis for TypeScript and Playwright tests.                  |
| `prettier`                                                | Formatting.                                                           |
| `husky`, `lint-staged`                                    | Git-hook and staged-file quality enforcement.                         |
| `@commitlint/*`                                           | Conventional Commit validation.                                       |

See [package.json](package.json) for the pinned dependency versions and all available scripts.

## Commands

### Quality and Maintenance

| Command                      | Description                                                                                                                             |
| ---------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| `npm run verify`             | CI-equivalent preflight: formatting, linting, typecheck, generated-JS detection, and test discovery. It does not execute browser tests. |
| `npm run format`             | Format supported files with Prettier.                                                                                                   |
| `npm run format:check`       | Verify Prettier formatting without changing files.                                                                                      |
| `npm run lint`               | Run ESLint.                                                                                                                             |
| `npm run lint:fix`           | Apply safe ESLint fixes.                                                                                                                |
| `npm run typecheck`          | Run `tsc --noEmit`.                                                                                                                     |
| `npm run check:generated-js` | Fail if compiler output is present under `src` or `tests`, or beside the Playwright config.                                             |
| `npm run clean`              | Remove local Playwright report and test-result folders.                                                                                 |

### Playwright

| Command               | Description                                              |
| --------------------- | -------------------------------------------------------- |
| `npm run test`        | Run the Chromium project.                                |
| `npm run test:all`    | Run all configured browser projects.                     |
| `npm run test:headed` | Run Chromium with a visible browser.                     |
| `npm run test:debug`  | Run Chromium in Playwright debug mode.                   |
| `npm run test:ui`     | Open Playwright UI mode.                                 |
| `npm run test:list`   | Discover and list Chromium tests without executing them. |
| `npm run report`      | Open the latest HTML report.                             |

Run one spec or one test title with Playwright directly:

```bash
npx playwright test tests/Auto/auto-quote-start.spec.ts --project=chromium
npx playwright test --project=chromium --grep "case:AUTO-001"
```

### Migration Audits

| Command                                       | Description                            |
| --------------------------------------------- | -------------------------------------- |
| `npm run audit:parity`                        | Check migration parity data.           |
| `npm run audit:skip-policy`                   | Audit skip-policy conformance.         |
| `npm run migration:remove-runtime-skip-gates` | Maintain migration runtime skip gates. |

## Quality Standards

- TypeScript is strict, uses NodeNext module resolution, and has `noEmit: true` in [tsconfig.json](tsconfig.json). Do not commit generated `.js`, `.d.ts`, or source-map output from TypeScript source.
- Prettier uses single quotes, trailing commas, 120-character print width, and LF line endings. Use `.editorconfig` in supported editors.
- ESLint applies TypeScript and Playwright rules to maintained source and tests. Run `npm run lint` before opening a pull request.
- The pre-commit hook runs lint-staged against staged files. The commit-message hook runs Commitlint.
- `npm run verify` is the required local preflight and the CI validation command.

## Commit Convention

Commitlint requires Conventional Commits. Use this format:

```text
type(scope): concise imperative summary
```

Examples:

```text
feat(auto): add address page guard
fix(recovery): handle inconvenience state
test(acehome): add quality grade coverage
docs(readme): document local setup
chore(tooling): add quality checks
ci(workflow): run verification gate
```

Common types are `feat`, `fix`, `docs`, `style`, `refactor`, `perf`, `test`, `build`, `ci`, and `chore`. Keep the first line focused; add a blank line followed by bullet points when a body is useful.

## CI and Artifacts

The GitHub Actions workflow in [.github/workflows/playwright.yml](.github/workflows/playwright.yml) runs on pull requests, pushes to `main`, and manual dispatches. It installs Node from `.nvmrc`, uses `npm ci`, installs Chromium, then runs `npm run verify`.

`verify` runs test discovery only; it does not execute browser scenarios. The workflow requires a valid `FFQ_BASE_URL` when it injects that secret. Leave the secret unset only if the workflow does not override the valid default defined in `env.ts`.

Playwright can produce HTML reports, test results, screenshots, traces, videos, coverage, runtime evidence, and final DOM snapshots. Generated local artifacts are ignored by Git according to [.gitignore](.gitignore). CI uploads `playwright-report/` and `test-results/` when they exist.

## Maintenance Rules

1. Keep page objects narrow and product-specific; put cross-page sequencing in flows.
2. Reuse `BasePage`, browser helpers, fixtures, data providers, and reporting utilities before creating another implementation.
3. Validate environment variables and test data at boundaries; do not silently substitute invalid business data.
4. Do not add production credentials, API keys, URLs with credentials, or personal data to source control.
5. Keep generated JavaScript and Playwright runtime artifacts out of Git.
6. Update this README when setup, top-level structure, CI behavior, quality gates, libraries, or contributor workflow changes.
7. Run `npm run verify` before raising a pull request, then include focused browser-test evidence when the change affects runtime behavior.

## Troubleshooting

| Symptom                      | Action                                                                                                                   |
| ---------------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| `FFQ_BASE_URL: Invalid URL`  | Check `.env` and CI secrets. An empty environment variable overrides the default and fails validation.                   |
| Playwright browser missing   | Run `npx playwright install chromium`.                                                                                   |
| Commit blocked by Commitlint | Change the first line to `type(scope): summary`, for example `fix(auto): correct date input`.                            |
| Commit blocked by Husky      | Run `npm run lint` and `npm run format:check`; stage the resulting fixes.                                                |
| Generated-JS check fails     | Delete the generated output, keep the `.ts` source, and use `npm run typecheck` rather than a emitting compiler command. |

## Project Status

The migration foundation and test inventory are present. Functional debugging, runtime certification, locator validation, data validation, and end-to-end verification remain ongoing. Preserve legacy test intent, avoid false pass results, and use checkpoints and runtime evidence to guide stabilization work.
