export interface HomeQuoteState {
  quoteNumber: string;
  dwellingCoverageAmount: string;
  dwellingCoverageQualityGrade: string;
  quotePriceBeforeRetrieve: string;
  discountsBeforeRetrieve: string[];
}
