export interface AutoVehicle {
  readonly vehicleId: number;
  readonly applicantId: number;
  readonly vehicleStateCode: string;
  readonly vehicleYear: string;
  readonly vehicleMake: string;
  readonly vehicleModel: string;
  readonly vehicleVIN: string;
  readonly vehicleType: string;
  readonly ownership: string;
  readonly purchaseDate: string;
  readonly vehicleUsage: string;
  readonly oneWayMiles: string;
  readonly commute: string;
  readonly annualMiles: string;
  readonly parkInresidentAddress: boolean;
  readonly rideSharing: boolean;
  readonly alternativeFuels: boolean;
  readonly antiTheftDevice: string;
  readonly passiveRestraint: string;
  readonly airBagSeatBelt: string;
  readonly antiLockBrakes: string;
  readonly stabilityControl: string;
  readonly daytimeLights: string;
  readonly theftRecoverySystem: string;
  readonly vinEtching: boolean;
  readonly lessorStateName: string;
  readonly lessor: string;
  readonly currentOdometerReading: string;
  readonly dateOfReading: string;
  readonly useVIN: boolean;
  readonly garagingAddress: string;
  readonly garagingApt: string;
  readonly garagingCity: string;
  readonly garagingZip: string;
  readonly mediaAlphaModel: string;
  readonly submodel: string;
  readonly mediaAlphaAnnualMiles: string;
  readonly collisionDeductible: string;
  readonly comprehensiveDeductible: string;
}

export interface AutoAdditionalDriver {
  readonly additionalDriverId: number;
  readonly applicantId: number;
  readonly incidentId: number;
  readonly firstName: string;
  readonly lastName: string;
  readonly age: number;
  readonly dateOfBirth: string;
  readonly relationshipToApplicant: string;
  readonly maritalStatus: string;
  readonly gender: string;
  readonly occupation: string;
  readonly otherOccupation: string;
  readonly licenseToDriveInUSA: string;
  readonly firstAgeUnitedStatesDriverLicense: number;
  readonly firstAgeForeignDriverLicense: number;
  readonly fullTimeStudentWithHighGPA: boolean;
  readonly attendsDistantSchool: boolean;
  readonly completedDriversSafetyCourse: boolean;
  readonly financialFiling: string;
  readonly anyIncident: boolean;
  readonly driversLicense: string;
  readonly licenseIssueStateName: string;
  readonly mediaAlphaCurrentlyInsured: string;
  readonly signalMobilePhone: string;
}

export interface AutoIncident {
  readonly incidentId: number;
  readonly applicantId: number;
  readonly additionalDriverId: number;
  readonly incidentType: string;
  readonly description: string;
  readonly dateOccuredOffsetInDays: string;
  readonly dateOccured: string;
  readonly anyInjuries: boolean;
  readonly mediaAlphaIncidentType: string;
  readonly mediaAlphaIncidentDescription: string;
  readonly mediaAlphaAmountPaidByInsurance: string;
  readonly mediaAlphaDamageTo: string;
  readonly mediaAlphaDriverAtFault: string;
}

export interface AutoDiscount {
  readonly discountId: number;
  readonly applicantId: number;
  readonly paymentMethod: string;
  readonly startDateOfNewPolicy: string;
  readonly homeInsurance: boolean;
  readonly rentersInsurance: boolean;
  readonly condoInsurance: boolean;
  readonly valueTermLifeInsurance: boolean;
  readonly umbrellaInsurance: boolean;
  readonly businessInsurance: boolean;
  readonly ownOrRentHome: string;
  readonly paymentMethodForDiscount: string;
  readonly mediaAlphaTimeAtResidence: string;
  readonly mediaAlphaHasGarage: string;
  readonly signalSignup: boolean;
}

export interface AutoPayment {
  readonly paymentId: number;
  readonly applicantId: number;
  readonly paymentPlan: string;
  readonly paymentMethod: string;
  readonly accountHolderName: string;
  readonly routingNumber: string;
  readonly bankAccountNumber: string;
  readonly bankName: string;
  readonly creditCardType: string;
  readonly debitCardType: string;
  readonly nameOnCard: string;
  readonly cardNumber: string;
  readonly expirationDate: string;
  readonly billingZipCode: string;
}

export interface AutoApplicant {
  readonly applicantId: number;
  readonly testCategory: string;
  readonly testScenario: string;
  readonly gender: string;
  readonly residentAddress1: string;
  readonly residentAddress2: string;
  readonly city: string;
  readonly zipCode: string;
  readonly stateCode: string;
  readonly stateName: string;
  readonly maritalStatus: string;
  readonly occupation: string;
  readonly currentlyInsuredStatus: string;
  readonly currentInsuranceCompany: string;
  readonly continuosInsurancePeriod: string;
  readonly currentBodilyInjuryLimit: string;
  readonly financialFiling: string;
  readonly firstName: string;
  readonly lastName: string;
  readonly age: number;
  readonly otherOccupation: string;
  readonly dateOfBirth: string;
  readonly mailingAddressDifferent: boolean;
  readonly currentlyHaveAutoInsurance: string;
  readonly principalPIP: string;
  readonly firstAgeUnitedStatesDriverLicense: number;
  readonly firstAgeForeignDriverLicense: number;
  readonly fullTimeStudentWithHighGPA: boolean;
  readonly email: string;
  readonly phoneNumber: string;
  readonly phoneExtentionNumber: string;
  readonly knockoutExpected: boolean;
  readonly completedDriversSafetyCourse: boolean;
  readonly havePersonalInjuryLoss: boolean;
  readonly haveAccidentOrViolations: boolean;
  readonly currentInsuranceExpirationDate: string;
  readonly driversLicense: string;
  readonly licenseIssueStateName: string;
  readonly attemptToBind: string;
  readonly garagingAddress: string;
  readonly vehicles: readonly AutoVehicle[];
  readonly additionalDrivers: readonly AutoAdditionalDriver[];
  readonly incidents: readonly AutoIncident[];
  readonly discounts: readonly AutoDiscount[];
  readonly payments: readonly AutoPayment[];
}

export interface SelectedAutoApplicant {
  readonly workbook: string;
  readonly worksheet: string;
  readonly rowNumber: number;
  readonly correlationId: string;
  readonly applicant: AutoApplicant;
}
