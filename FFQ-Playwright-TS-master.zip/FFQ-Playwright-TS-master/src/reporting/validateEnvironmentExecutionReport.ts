import assert from 'node:assert/strict';
import { access } from 'node:fs/promises';
import ExcelJS from 'exceljs';
import { loadInventory, rebuildEnvironmentExecutionWorkbook } from './EnvironmentExecutionReport.js';
import PlaywrightEnvironmentExecutionReporter from './PlaywrightEnvironmentExecutionReporter.js';

async function main(): Promise<void> {
  const inventory = await loadInventory();
  assert(inventory.tests.length >= 3, 'Expected at least three inventory rows for synthetic validation.');

  const [first, second, third] = inventory.tests;
  assert(first && second && third, 'Inventory did not return three rows.');

  const reporter = new PlaywrightEnvironmentExecutionReporter();
  await reporter.onBegin({} as never);

  await reporter.onTestEnd(
    {
      id: 'synthetic-pass',
      title: first.testName,
      location: { file: first.specFile, line: 1, column: 1 },
    } as never,
    {
      retry: 0,
      duration: 100,
      startTime: new Date('2026-09-21T08:00:01'),
      status: 'passed',
      error: undefined,
      errors: [],
    } as never,
  );

  await reporter.onTestEnd(
    {
      id: 'synthetic-blocked',
      title: second.testName,
      location: { file: second.specFile, line: 1, column: 1 },
    } as never,
    {
      retry: 0,
      duration: 100,
      startTime: new Date('2026-09-21T08:00:02'),
      status: 'failed',
      error: {
        message: 'Environment baseline blocked by INCONVENIENCE during validate:after.',
        stack: 'EnvironmentBaselineBlockedError: Environment baseline blocked by INCONVENIENCE during validate:after.',
      },
      errors: [],
    } as never,
  );

  await reporter.onTestEnd(
    {
      id: 'synthetic-failed',
      title: third.testName,
      location: { file: third.specFile, line: 1, column: 1 },
    } as never,
    {
      retry: 0,
      duration: 100,
      startTime: new Date('2026-09-21T08:00:03'),
      status: 'timedOut',
      error: {
        message: 'locator.click: Timeout 30000ms exceeded',
        stack: 'TimeoutError: locator.click: Timeout 30000ms exceeded\n    at src/flows/example.ts:42:13',
      },
      errors: [],
    } as never,
  );

  await reporter.onEnd({} as never);

  const workbookPath = await rebuildEnvironmentExecutionWorkbook();
  await access(workbookPath);
  await rebuildEnvironmentExecutionWorkbook();

  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(workbookPath);

  const executionResults = workbook.getWorksheet('Execution Results');
  const summary = workbook.getWorksheet('Summary');
  const testInventory = workbook.getWorksheet('Test Inventory');
  const lists = workbook.getWorksheet('Lists');

  assert(executionResults, 'Execution Results sheet was not created.');
  assert(summary, 'Summary sheet was not created.');
  assert(testInventory, 'Test Inventory sheet was not created.');
  assert(lists, 'Lists sheet was not created.');

  const workbookExecutionId = String(executionResults.getCell('A2').value ?? '');
  assert.match(workbookExecutionId, /^FFQ-\d{8}-\d{6}$/, 'Execution ID format is incorrect.');
  assert.equal(summary.getCell('B1').value, workbookExecutionId, 'Summary execution ID does not match execution rows.');

  assert.equal(executionResults.views[0]?.state, 'frozen', 'Execution Results header was not frozen.');
  assert.equal(executionResults.views[0]?.ySplit, 1, 'Execution Results did not freeze the first row.');
  assert.equal(
    executionResults.getCell('A3').value,
    workbookExecutionId,
    'Execution ID was not applied consistently across rows.',
  );
  assert.match(String(executionResults.getCell('F2').value ?? ''), /^\d{2}\/\d{2}\/\d{4}$/, 'Day format is incorrect.');
  assert.match(
    String(executionResults.getCell('G2').value ?? ''),
    /^\d{2}:\d{2}:\d{2} (AM|PM)$/,
    'Time format is incorrect.',
  );
  assert.equal(executionResults.getCell('J2').dataValidation.type, 'list', 'Status dropdown was not applied.');
  assert.equal(executionResults.getCell('I2').dataValidation.type, 'list', 'Root cause dropdown was not applied.');
  assert.equal((executionResults.getColumn('H').alignment ?? {}).wrapText, true, 'Error column is not wrapping text.');
  assert.ok(
    (executionResults.model as { tables?: unknown[] }).tables?.length,
    'Execution Results is not stored as an Excel table.',
  );

  assert.equal(summary.getCell('B3').value, inventory.tests.length, 'Summary total inventory count is incorrect.');
  assert.equal(summary.getCell('B4').value, 3, 'Summary executed count is incorrect.');
  assert.equal(summary.getCell('B5').value, 1, 'Summary pass count is incorrect.');
  assert.equal(summary.getCell('B6').value, 1, 'Summary failed count is incorrect.');
  assert.equal(summary.getCell('B7').value, 1, 'Summary blocked count is incorrect.');
  assert.equal(summary.getCell('A11').value, 'INCONVENIENCE', 'Root cause summary section is misaligned.');
  assert.equal(summary.getCell('B11').value, 1, 'INCONVENIENCE root cause count is incorrect.');
  assert.equal(summary.getCell('A14').value, 'TIMEOUT', 'TIMEOUT root cause label is missing.');
  assert.equal(summary.getCell('B14').value, 1, 'TIMEOUT root cause count is incorrect.');

  assert.ok(testInventory.rowCount > 10, 'Test Inventory sheet was not populated from Phase 1 inventory.');
  assert.equal(lists.getCell('A2').value, 'PASS', 'Lists sheet status values were not created.');
  assert.equal(lists.getCell('B2').value, 'INCONVENIENCE', 'Lists sheet root causes were not created.');

  console.log(`Validated workbook generation at ${workbookPath}`);
}

void main().catch((error: unknown) => {
  console.error(error);
  process.exitCode = 1;
});
