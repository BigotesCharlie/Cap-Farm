import type { FullConfig, FullResult, Reporter, TestCase, TestError, TestResult } from '@playwright/test/reporter';
import { basename } from 'node:path';
import {
  buildRuntimeRecord,
  generateExecutionId,
  inventoryLookupKey,
  loadInventory,
  prepareReportRun,
  readRuntimeEvidence,
  rebuildEnvironmentExecutionWorkbook,
  specFileFromTestLocation,
  writeRuntimeResultRecord,
  type ExecutionStatus,
  type InventoryRow,
  type RootCause,
  type RuntimeEvidence,
} from './EnvironmentExecutionReport.js';

function firstLine(value: string): string {
  return (
    value
      .split(/\r?\n/)
      .map((line) => line.trim())
      .find(Boolean) ?? ''
  );
}

function extractRelevantLocation(stack: string | undefined): string {
  if (!stack) return '';
  return (
    stack
      .split(/\r?\n/)
      .map((line) => line.trim())
      .find((line) => /tests\/|src\//.test(line.replace(/\\/g, '/'))) ?? ''
  );
}

function summarizeError(error: TestError | undefined): string {
  if (!error) return '';
  const nameMatch = (error.stack ?? error.message ?? '').match(/^([A-Za-z0-9_]+Error):/);
  const name = nameMatch?.[1] ?? 'Error';
  const message = firstLine(error.message ?? '') || 'No message';
  const location = extractRelevantLocation(error.stack);
  return [name, message, location].filter(Boolean).join(' | ').slice(0, 2000);
}

function firstError(result: TestResult): TestError | undefined {
  return result.error ?? result.errors[0];
}

function findBlockedCauseFromEvidence(evidence: RuntimeEvidence | undefined, errorText: string): RootCause | undefined {
  const pageClassification = evidence?.pageSummary?.pageClassification?.toUpperCase();
  if (pageClassification === 'INCONVENIENCE') return 'INCONVENIENCE';
  if (pageClassification === 'KNOCKOUT') return 'KNOCKOUT';
  if (pageClassification === 'TRY_AGAIN') return 'TRY_AGAIN';

  const annotations = evidence?.annotations ?? [];
  const expectedKnockout = annotations.some(
    (annotation) => annotation.type === 'expected-knockout' && annotation.description === 'true',
  );
  if (expectedKnockout && /knockout|unable to continue|unable to offer|not eligible/i.test(errorText))
    return 'KNOCKOUT';

  if (/EnvironmentBaselineBlockedError/i.test(errorText)) {
    if (/INCONVENIENCE/i.test(errorText)) return 'INCONVENIENCE';
    if (/KNOCKOUT/i.test(errorText)) return 'KNOCKOUT';
    if (/TRY_AGAIN/i.test(errorText)) return 'TRY_AGAIN';
  }

  if (/sorry for the inconvenience|inconvenience/i.test(errorText)) return 'INCONVENIENCE';
  if (/try again/i.test(errorText)) return 'TRY_AGAIN';
  if (/knockout|unable to continue|unable to offer|not eligible|call-for-quote/i.test(errorText)) return 'KNOCKOUT';

  return undefined;
}

function classifyFailure(
  result: TestResult,
  evidence: RuntimeEvidence | undefined,
  inventoryRow: InventoryRow | undefined,
  errorText: string,
): { rootCause: RootCause | ''; status: ExecutionStatus } {
  if (result.status === 'passed') {
    return { rootCause: '', status: 'PASS' };
  }

  const blockedCause = findBlockedCauseFromEvidence(evidence, errorText);
  if (blockedCause) {
    return { rootCause: blockedCause, status: 'BLOCKED' };
  }

  if (/Behavioral handler not implemented/i.test(errorText)) {
    return { rootCause: 'MISSING_HANDLER', status: 'FAILED' };
  }

  if (
    /Missing .*provider|Missing .*fixture|Missing dependency implementation|Missing NearMap|Missing immutable migration contract/i.test(
      errorText,
    )
  ) {
    return { rootCause: 'MISSING_FIXTURE', status: 'FAILED' };
  }

  if (
    /Execution blocked .*EXECUTE_MIGRATED_TESTS|Required secret .* is not configured|Production execution is blocked/i.test(
      errorText,
    )
  ) {
    return { rootCause: 'CONFIGURATION_ERROR', status: result.status === 'skipped' ? 'BLOCKED' : 'FAILED' };
  }

  if (result.status === 'skipped') {
    if (inventoryRow?.structuralBlocker === 'Behavioral handler not implemented') {
      return { rootCause: 'MISSING_HANDLER', status: 'BLOCKED' };
    }
    if ((inventoryRow?.structuralBlocker ?? '').startsWith('Missing ')) {
      return { rootCause: 'MISSING_FIXTURE', status: 'BLOCKED' };
    }
    return { rootCause: 'CONFIGURATION_ERROR', status: 'BLOCKED' };
  }

  if (result.status === 'timedOut' || /TimeoutError|timeout \d+ms exceeded|timed out/i.test(errorText)) {
    return { rootCause: 'TIMEOUT', status: 'FAILED' };
  }

  if (/net::|ECONN|ENOTFOUND|socket hang up|network/i.test(errorText)) {
    return { rootCause: 'NETWORK_ERROR', status: 'FAILED' };
  }

  if (/HTTP \d{3}|status code \d{3}|ERR_HTTP/i.test(errorText)) {
    return { rootCause: 'HTTP_ERROR', status: 'FAILED' };
  }

  if (/Target page, context or browser has been closed|browser has been closed|crash/i.test(errorText)) {
    return { rootCause: 'BROWSER_ERROR', status: 'FAILED' };
  }

  if (/page.goto|waitForURL|navigation|navigat/i.test(errorText)) {
    return { rootCause: 'NAVIGATION_ERROR', status: 'FAILED' };
  }

  if (
    (evidence?.pageSummary?.validationMessages.length ?? 0) > 0 ||
    /validation|assertAll|expected .* to/i.test(errorText)
  ) {
    return { rootCause: 'VALIDATION_ERROR', status: 'FAILED' };
  }

  if (/expect\(|locator\.|strict mode violation|toBeVisible|toHaveText|toHaveValue/i.test(errorText)) {
    return { rootCause: 'TEST_AUTOMATION_ERROR', status: 'FAILED' };
  }

  if (/TypeError|ReferenceError|SyntaxError|RangeError/i.test(errorText)) {
    return { rootCause: 'TEST_AUTOMATION_ERROR', status: 'FAILED' };
  }

  if (/application|server error|unexpected error|internal error/i.test(errorText)) {
    return { rootCause: 'APPLICATION_ERROR', status: 'FAILED' };
  }

  return { rootCause: 'UNKNOWN', status: 'FAILED' };
}

function fallbackProductSuite(specFile: string): string {
  const parts = specFile.split('/');
  const legacyIndex = parts.indexOf('legacy');
  if (legacyIndex >= 0) return parts[legacyIndex + 1] ?? 'unmapped';
  return parts.at(-2) ?? 'unmapped';
}

export default class PlaywrightEnvironmentExecutionReporter implements Reporter {
  private executionId = generateExecutionId();
  private inventoryByKey = new Map<string, InventoryRow>();

  public async onBegin(_config: FullConfig): Promise<void> {
    this.executionId = generateExecutionId();
    await prepareReportRun(this.executionId);
    const inventory = await loadInventory();
    this.inventoryByKey = new Map(inventory.tests.map((row) => [inventoryLookupKey(row.specFile, row.testName), row]));
  }

  public async onTestEnd(test: TestCase, result: TestResult): Promise<void> {
    const specFile = specFileFromTestLocation(test.location.file);
    const inventoryRow = this.inventoryByKey.get(inventoryLookupKey(specFile, test.title));
    const evidence = await readRuntimeEvidence(test.id, result.retry);
    const error = firstError(result);
    const errorText = `${summarizeError(error)} ${error?.stack ?? ''}`.trim();
    const classification = classifyFailure(result, evidence, inventoryRow, errorText);

    const record = buildRuntimeRecord({
      recordKey: test.id,
      executionId: this.executionId,
      specFile,
      testClass: inventoryRow?.testClass ?? basename(specFile, '.spec.ts'),
      testName: inventoryRow?.testName ?? test.title,
      legacyId: inventoryRow?.legacyId ?? '',
      productSuite: inventoryRow?.productFolder ?? fallbackProductSuite(specFile),
      timestamp: new Date(result.startTime.getTime() + result.duration),
      error:
        classification.status === 'PASS'
          ? ''
          : summarizeError(error) || `${classification.rootCause || 'UNKNOWN'} detected`,
      rootCause: classification.rootCause,
      status: classification.status,
      mappedToInventory: Boolean(inventoryRow),
    });

    await writeRuntimeResultRecord(test.id, record);
  }

  public async onEnd(_result: FullResult): Promise<void> {
    await rebuildEnvironmentExecutionWorkbook(this.executionId);
  }
}
