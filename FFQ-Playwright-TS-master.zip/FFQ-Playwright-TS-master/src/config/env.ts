import 'dotenv/config';
import { z } from 'zod';

const optionalSecret = z.preprocess((value) => (value === '' ? undefined : value), z.string().min(1).optional());

const booleanFromString = z
  .enum(['true', 'false'])
  .default('true')
  .transform((value) => value === 'true');

const falseByDefault = z
  .enum(['true', 'false'])
  .default('false')
  .transform((value) => value === 'true');

const optionalInteger = z.preprocess(
  (value) => (value === '' || value === undefined ? undefined : value),
  z.coerce.number().int().nonnegative().optional(),
);

const positiveInteger = (fallback: number) => z.coerce.number().int().positive().default(fallback);

const schema = z.object({
  TEST_ENV: z.string().min(1).default('MA11'),
  FFQ_BASE_URL: z.url().default('https://ffqautouiqa.farmers.com/fastquote/'),
  HEADLESS: booleanFromString,
  FFQ_DEBUG_VISUAL: falseByDefault,
  FFQ_KEEP_BROWSER_OPEN: falseByDefault,
  WORKERS: positiveInteger(4),
  RETRIES: z.coerce.number().int().nonnegative().default(1),
  TEST_TIMEOUT_MS: positiveInteger(120_000),
  EXPECT_TIMEOUT_MS: positiveInteger(15_000),
  ACTION_TIMEOUT_MS: positiveInteger(30_000),
  NAVIGATION_TIMEOUT_MS: positiveInteger(60_000),
  RECOVERY_MAX_ATTEMPTS: z.coerce.number().int().min(0).max(2).default(2),
  RECOVERY_POLL_INTERVAL_MS: positiveInteger(350),
  FFQ_ENVIRONMENT_BASELINE: falseByDefault,
  FFQ_ENVIRONMENT_BASELINE_MODE: falseByDefault,
  EXECUTE_MIGRATED_TESTS: falseByDefault,
  MIGRATION_ALLOW_UNCERTIFIED_CERTIFICATION_RUN: falseByDefault,
  MIGRATION_CERTIFICATION_ALLOWLIST: optionalSecret,
  AUTO_PROVIDER_SEED: optionalInteger,
  ACE_HOME_PROVIDER_SEED: optionalInteger,
  FFQ_ALLOW_PRODUCTION_EXECUTION: falseByDefault,
  FFQ_PRODUCTION_APPLICANT_FIRST_NAME: optionalSecret,
  FFQ_PRODUCTION_APPLICANT_LAST_NAME: optionalSecret,
  FFQ_PRODUCTION_APPLICANT_EMAIL: optionalSecret,
  ARTIFACTORY_USERNAME: optionalSecret,
  ARTIFACTORY_PASSWORD: optionalSecret,
  POSTGRES_URL: optionalSecret,
  POSTGRES_SCHEMA: optionalSecret,
  POSTGRES_USERNAME: optionalSecret,
  POSTGRES_PASSWORD: optionalSecret,
  RALLY_API_KEY: optionalSecret,
  RALLY_WORKSPACE_REF: optionalSecret,
  RALLY_PROJECT_REF: optionalSecret,
  SAUCE_USERNAME: optionalSecret,
  SAUCE_ACCESS_KEY: optionalSecret,
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  const issues = parsed.error.issues.map((issue) => `${issue.path.join('.')}: ${issue.message}`).join('\n');
  throw new Error(`Invalid environment configuration:\n${issues}`);
}

export const env = Object.freeze(parsed.data);
export type Environment = typeof env;

export function requireSecret<Key extends keyof Environment>(key: Key): NonNullable<Environment[Key]> {
  const value = env[key];
  if (value === undefined || value === '') {
    throw new Error(`Required secret ${String(key)} is not configured.`);
  }
  return value as NonNullable<Environment[Key]>;
}
