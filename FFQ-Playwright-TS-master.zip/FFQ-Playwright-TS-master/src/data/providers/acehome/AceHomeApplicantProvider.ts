import { randomInt } from 'node:crypto';
import { env } from '../../../config/env.js';
import { ExcelDataSource, type ExcelRecord } from '../../ExcelDataSource.js';
import type { LegacyTestMetadata } from '../../../migration/LegacyTestMetadata.js';
import type { ApplicantAceHome, HomeDiscount, SelectedAceHomeApplicant } from '../../../models/acehome/ApplicantAceHome.js';

const WORKBOOK = 'legacy/AceHomeTestData.xlsx';
const APPLICANT_PROVIDER = 'AceHomeDataProviders.APPLICANT_ACE_HOME_DATA_PROVIDER';
const ENV_STABILITY_PROVIDER = 'AceHomeDataProviders.ENVIRONMENT_STABILITY_DATA_PROVIDER';
const RANDOM_ROW = 'RANDOM_ROW';
const CATEGORY_BIND_VALIDATION = 'Bind validation';

function normalizeText(value: unknown): string {
  if (value instanceof Date) {
    const mm = String(value.getMonth() + 1).padStart(2, '0');
    const dd = String(value.getDate()).padStart(2, '0');
    const yyyy = String(value.getFullYear());
    return `${mm}/${dd}/${yyyy}`;
  }
  if (typeof value === 'object' && value !== null) {
    const record = value as Record<string, unknown>;
    if (typeof record.text === 'string') return record.text.trim();
    if ('result' in record) return normalizeText(record.result);
  }
  return String(value ?? '').trim();
}

function normalizeBoolean(value: unknown): boolean {
  const normalized = normalizeText(value).toLowerCase();
  return normalized === 'true' || normalized === 'yes' || normalized === 'y' || normalized === '1';
}

function normalizeNumber(value: unknown): number {
  const parsed = Number(normalizeText(value));
  return Number.isFinite(parsed) ? parsed : 0;
}

function seededRng(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (1664525 * state + 1013904223) >>> 0;
    return state / 0x100000000;
  };
}

function parseExcludedStates(annotation: string): Set<string> {
  const match = annotation.match(/EXCLUDED_STATES\s*,\s*values\s*=\s*\{([^}]*)\}/i);
  if (!match) return new Set<string>();
  return new Set(
    (match[1] ?? '')
      .split(',')
      .map((entry) => entry.trim())
      .filter(Boolean),
  );
}

function parseIncludedStates(annotation: string): Set<string> {
  const match = annotation.match(/INCLUDED_STATES\s*,\s*values\s*=\s*\{([^}]*)\}/i);
  if (!match) return new Set<string>();
  return new Set(
    (match[1] ?? '')
      .split(',')
      .map((entry) => entry.trim())
      .filter(Boolean),
  );
}

function correlationId(id: number, stateCode: string, rowNumber: number): string {
  return `acehome-${id}-${stateCode}-${rowNumber}`;
}

function mapDiscount(record: ExcelRecord): HomeDiscount {
  return {
    discountId: normalizeNumber(record.discountId),
    applicantId: normalizeNumber(record.applicantId),
    paymentMethod: normalizeText(record.paymentMethod),
    startDateOfNewPolicy: normalizeText(record.startDateOfNewPolicy),
    autoInsurance: normalizeBoolean(record.autoInsurance),
    umbrellaInsurance: normalizeBoolean(record.umbrellaInsurance),
    lifeInsurance: normalizeBoolean(record.lifeInsurance),
    homeInsurance: normalizeBoolean(record.homeInsurance),
    rentersInsurance: normalizeBoolean(record.rentersInsurance),
    condoInsurance: normalizeBoolean(record.condoInsurance),
    valueTermLifeInsurance: normalizeBoolean(record.valueTermLifeInsurance),
    recreationalBoatWatercraftInsurance: normalizeBoolean(record.recreationalBoatWatercraftInsurance),
    motorcycleInsurance: normalizeBoolean(record.motorcycleInsurance),
    businessInsurance: normalizeBoolean(record.businessInsurance),
    ownOrRentHome: normalizeText(record.ownOrRentHome),
    paymentMethodForDiscount: normalizeText(record.paymentMethodForDiscount),
    mediaAlphaTimeAtResidence: normalizeText(record.mediaAlphaTimeAtResidence),
    mediaAlphaHasGarage: normalizeText(record.mediaAlphaHasGarage),
    signalSignup: normalizeBoolean(record.signalSignup),
    multiPolicyCEA: normalizeBoolean(record.multiPolicyCEA),
  };
}

function mapApplicant(record: ExcelRecord, discounts: readonly HomeDiscount[]): ApplicantAceHome {
  return {
    id: normalizeNumber(record.id),
    testCategory: normalizeText(record.testCategory),
    firstName: normalizeText(record.firstName),
    lastName: normalizeText(record.lastName),
    dateOfBirth: normalizeText(record.dateOfBirth),
    gender: normalizeText(record.gender),
    maritalStatus: normalizeText(record.maritalStatus),
    spouseFirstName: normalizeText(record.spouseFirstName),
    spouseLastName: normalizeText(record.spouseLastName),
    spouseDateOfBirth: normalizeText(record.spouseDateOfBirth),
    spouseGender: normalizeText(record.spouseGender),
    address: normalizeText(record.address),
    unit: normalizeText(record.unit),
    city: normalizeText(record.city),
    county: normalizeText(record.county),
    stateCode: normalizeText(record.stateCode),
    state: normalizeText(record.state),
    zipCode: normalizeText(record.zipCode),
    priorOrCurrentAddress: normalizeText(record.priorOrCurrentAddress),
    priorOrCurrentUnit: normalizeText(record.priorOrCurrentUnit),
    priorOrCurrentCity: normalizeText(record.priorOrCurrentCity),
    priorOrCurrentCounty: normalizeText(record.priorOrCurrentCounty),
    priorOrCurrentStateCode: normalizeText(record.priorOrCurrentStateCode),
    priorOrCurrentState: normalizeText(record.priorOrCurrentState),
    priorOrCurrentZipCode: normalizeText(record.priorOrCurrentZipCode),
    yearBuilt: normalizeText(record.yearBuilt),
    squareFeet: normalizeText(record.squareFeet),
    numberOfStories: normalizeText(record.numberOfStories),
    bathrooms: normalizeText(record.bathrooms),
    foundationType: normalizeText(record.foundationType),
    exteriorWallFinish: normalizeText(record.exteriorWallFinish),
    roofCover: normalizeText(record.roofCover),
    floorCoverings: normalizeText(record.floorCoverings),
    heatingSystem: normalizeText(record.heatingSystem),
    fireplace: normalizeText(record.fireplace),
    garageCarport: normalizeText(record.garageCarport),
    garageStyle: normalizeText(record.garageStyle),
    mailingAddressDifferent: normalizeBoolean(record.mailingAddressDifferent),
    emailAddress: normalizeText(record.emailAddress),
    phoneNumber: normalizeText(record.phoneNumber),
    occupation: normalizeText(record.occupation),
    centralBurglarAlarm: normalizeBoolean(record.centralBurglarAlarm),
    centralFireAlarm: normalizeBoolean(record.centralFireAlarm),
    localBurglarAlarm: normalizeBoolean(record.localBurglarAlarm),
    localFireAlarm: normalizeBoolean(record.localFireAlarm),
    burglarAlarm: normalizeBoolean(record.burglarAlarm),
    fireAlarm: normalizeBoolean(record.fireAlarm),
    alarmSystem: normalizeBoolean(record.alarmSystem),
    sprinklerSystem: normalizeBoolean(record.sprinklerSystem),
    smokeAlarm: normalizeBoolean(record.smokeAlarm),
    waterLeakProtection: normalizeBoolean(record.waterLeakProtection),
    fortifiedHome: normalizeText(record.fortifiedHome),
    nonSmoker: normalizeBoolean(record.nonSmoker),
    temporaryRentals: normalizeBoolean(record.temporaryRentals),
    swimmingPool: normalizeBoolean(record.swimmingPool),
    solarPanels: normalizeBoolean(record.solarPanels),
    trampoline: normalizeBoolean(record.trampoline),
    ulRoof: normalizeBoolean(record.ulRoof),
    roofReplaced: normalizeBoolean(record.roofReplaced),
    mineSubsidence: normalizeBoolean(record.mineSubsidence),
    newlyOwned: normalizeBoolean(record.newlyOwned),
    inEscrow: normalizeBoolean(record.inEscrow),
    fireHydrant: normalizeText(record.fireHydrant),
    homeVisible: normalizeText(record.homeVisible),
    secondaryHeatingSource: normalizeText(record.secondaryHeatingSource),
    wroughtIronBars: normalizeText(record.wroughtIronBars),
    previousInsurance: normalizeText(record.previousInsurance),
    wildFireRisk: normalizeText(record.wildFireRisk),
    stormShutters: normalizeText(record.stormShutters),
    electricalUpdated: normalizeText(record.electricalUpdated),
    plumbingUpdated: normalizeText(record.plumbingUpdated),
    hvacUpdated: normalizeText(record.hvacUpdated),
    earlyShoppingFactor: normalizeText(record.earlyShoppingFactor),
    agentId: normalizeText(record.agentId),
    lenderBank: normalizeText(record.lenderBank),
    lenderBankName: normalizeText(record.lenderBankName),
    lenderIncompleteSelection: normalizeText(record.lenderIncompleteSelection),
    impoundAccountSelection: normalizeText(record.impoundAccountSelection),
    plumbingOtherThanCopperPexPVC: normalizeText(record.plumbingOtherThanCopperPexPVC),
    primaryHeatingSource: normalizeText(record.primaryHeatingSource),
    updatedPrimaryHeatingSource: normalizeText(record.updatedPrimaryHeatingSource),
    unrepairedStructures: normalizeText(record.unrepairedStructures),
    businessOperatedOnPremises: normalizeText(record.businessOperatedOnPremises),
    dogsOnPremises: normalizeText(record.dogsOnPremises),
    updatedDogsOnPremises: normalizeText(record.updatedDogsOnPremises),
    petWithBiteHistory: normalizeText(record.petWithBiteHistory),
    discounts,
  };
}

export class AceHomeApplicantProvider {
  private readonly dataSource: ExcelDataSource;

  public constructor(dataSource = new ExcelDataSource()) {
    this.dataSource = dataSource;
  }

  public async selectForRandomRow(
    metadata: LegacyTestMetadata,
    extraExcludedStates: readonly string[],
  ): Promise<SelectedAceHomeApplicant> {
    if (metadata.dataProvider !== APPLICANT_PROVIDER) {
      throw new Error(
        `Unsupported provider ${metadata.dataProvider}. Expected ${APPLICANT_PROVIDER} for ${metadata.legacyId}.`,
      );
    }
    if (metadata.testName !== RANDOM_ROW) {
      throw new Error(`Unsupported testName ${metadata.testName}. Expected ${RANDOM_ROW}.`);
    }

    const worksheet = 'ApplicantHome';
    const annotationExcluded = parseExcludedStates(metadata.annotation);
    const mergedExcluded = new Set<string>([
      ...annotationExcluded,
      ...extraExcludedStates.map((state) => state.trim()).filter(Boolean),
    ]);

    return this.selectCandidate(
      metadata,
      worksheet,
      (row) => !mergedExcluded.has(normalizeText(row.stateCode)),
    );
  }

  public async selectForEnvironmentStability(metadata: LegacyTestMetadata): Promise<SelectedAceHomeApplicant> {
    if (metadata.dataProvider !== ENV_STABILITY_PROVIDER) {
      throw new Error(
        `Unsupported provider ${metadata.dataProvider}. Expected ${ENV_STABILITY_PROVIDER} for ${metadata.legacyId}.`,
      );
    }

    const worksheet = this.resolveEnvironmentStabilityWorksheet();
    const includedStates = parseIncludedStates(metadata.annotation);

    return this.selectCandidate(metadata, worksheet, (row) => {
      const category = normalizeText(row.testCategory);
      const stateCode = normalizeText(row.stateCode);
      if (category !== CATEGORY_BIND_VALIDATION) return false;
      if (includedStates.size > 0 && !includedStates.has(stateCode)) return false;
      return true;
    });
  }

  private resolveEnvironmentStabilityWorksheet(): string {
    const envName = env.TEST_ENV.toUpperCase();
    if (envName === 'PROD' || envName === 'PRODUCTION') {
      return 'ApplicantHome';
    }
    return 'PageValidationApplicantAceHome';
  }

  private providerSeed(): number {
    if (env.ACE_HOME_PROVIDER_SEED !== undefined) return env.ACE_HOME_PROVIDER_SEED;
    return randomInt(1, 2_147_483_647);
  }

  private async selectCandidate(
    metadata: LegacyTestMetadata,
    worksheet: string,
    predicate: (row: ExcelRecord) => boolean,
  ): Promise<SelectedAceHomeApplicant> {
    const applicants = await this.dataSource.rows(WORKBOOK, worksheet);
    const candidates = applicants.filter(predicate);
    if (candidates.length === 0) {
      throw new Error(
        `No valid applicant found for ${metadata.legacyId} using ${WORKBOOK}:${worksheet}.`,
      );
    }

    const discountRecords = (await this.dataSource.rows(WORKBOOK, 'discounts')).map(mapDiscount);
    const discountByApplicant = new Map<number, HomeDiscount[]>();
    for (const discount of discountRecords) {
      const bucket = discountByApplicant.get(discount.applicantId);
      if (bucket) bucket.push(discount);
      else discountByApplicant.set(discount.applicantId, [discount]);
    }

    const seed = this.providerSeed();
    const rng = seededRng(seed);
    const index = Math.min(Math.floor(rng() * candidates.length), candidates.length - 1);
    const selectedRecord = candidates[index];
    if (!selectedRecord) {
      throw new Error(`Candidate selection failed for ${metadata.legacyId}.`);
    }

    const id = normalizeNumber(selectedRecord.id);
    if (!id) throw new Error(`Selected applicant has empty id for ${metadata.legacyId}.`);
    const mapped = mapApplicant(selectedRecord, discountByApplicant.get(id) ?? []);

    const rowNumber = applicants.findIndex((row) => normalizeNumber(row.id) === id) + 2;
    return {
      workbook: WORKBOOK,
      worksheet,
      rowNumber,
      seed,
      correlationId: correlationId(id, mapped.stateCode, rowNumber),
      applicant: mapped,
    };
  }
}
