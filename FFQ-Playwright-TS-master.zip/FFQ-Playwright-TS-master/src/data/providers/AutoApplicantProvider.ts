import { randomInt } from 'node:crypto';
import { ExcelDataSource, type ExcelRecord } from '../ExcelDataSource.js';
import type { LegacyTestMetadata } from '../../migration/LegacyTestMetadata.js';
import type {
  AutoAdditionalDriver,
  AutoApplicant,
  AutoDiscount,
  AutoIncident,
  AutoPayment,
  AutoVehicle,
  SelectedAutoApplicant,
} from '../../models/auto/AutoApplicant.js';
import { env } from '../../config/env.js';

const AUTO_APPLICANT_PROVIDER = 'AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER';
const RANDOM_AUTO_APPLICANT = 'AutoDataProviders.RANDOM_AUTO_APPLICANT';
const WORKBOOK = 'legacy/AutoTestData.xlsx';
const APPLICANT_SHEET = 'applicant';

type Rng = () => number;

function formatDate(value: Date): string {
  const mm = String(value.getMonth() + 1).padStart(2, '0');
  const dd = String(value.getDate()).padStart(2, '0');
  const yyyy = String(value.getFullYear());
  return `${mm}/${dd}/${yyyy}`;
}

function asString(value: unknown): string {
  if (value instanceof Date) {
    return formatDate(value);
  }
  if (typeof value === 'object' && value !== null) {
    const record = value as Record<string, unknown>;
    if ('text' in record && typeof record.text === 'string') {
      return record.text.trim();
    }
    if ('result' in record) {
      return asString(record.result);
    }
  }
  return String(value ?? '').trim();
}

function asNumber(value: unknown): number {
  const parsed = Number(asString(value));
  return Number.isFinite(parsed) ? parsed : 0;
}

function asBoolean(value: unknown): boolean {
  const normalized = asString(value).toLowerCase();
  return normalized === 'true' || normalized === 'yes' || normalized === 'y' || normalized === '1';
}

function cleanAttributeValue(value: string): string {
  return value.replace(/[{}]/g, '').replace(/"/g, '').trim();
}

function parseFilter(annotation: string): string {
  const filterMatch = annotation.match(/name\s*=\s*FILTER\s*,\s*values\s*=\s*([^,)]+)/i);
  if (!filterMatch) return '';
  return cleanAttributeValue(filterMatch[1] ?? '');
}

function parseExcludedStates(annotation: string): Set<string> {
  const excludedMatch = annotation.match(
    /name\s*=\s*EXCLUDED_STATES\s*,\s*values\s*=\s*\{([^}]*)\}/i,
  );
  if (!excludedMatch) return new Set<string>();
  const values = (excludedMatch[1] ?? '')
    .split(',')
    .map((value) => value.trim())
    .filter(Boolean);
  return new Set(values);
}

function seededRng(seed: number): Rng {
  let state = seed >>> 0;
  return () => {
    state = (1664525 * state + 1013904223) >>> 0;
    return state / 0x100000000;
  };
}

function pickRandomIndex(length: number, rng: Rng): number {
  if (length <= 0) throw new Error('Cannot pick from an empty list.');
  const randomValue = rng();
  return Math.min(Math.floor(randomValue * length), length - 1);
}

function getCorrelationId(applicantId: number, stateCode: string, rowNumber: number): string {
  return `auto-${applicantId}-${stateCode}-${rowNumber}`;
}

function mapVehicle(record: ExcelRecord): AutoVehicle {
  return {
    vehicleId: asNumber(record.vehicleId),
    applicantId: asNumber(record.applicantId),
    vehicleStateCode: asString(record.vehicleStateCode),
    vehicleYear: asString(record.vehicleYear),
    vehicleMake: asString(record.vehicleMake),
    vehicleModel: asString(record.vehicleModel),
    vehicleVIN: asString(record.vehicleVIN),
    vehicleType: asString(record.vehicleType),
    ownership: asString(record.ownership),
    purchaseDate: asString(record.purchaseDate),
    vehicleUsage: asString(record.vehicleUsage),
    oneWayMiles: asString(record.oneWayMiles),
    commute: asString(record.commute),
    annualMiles: asString(record.annualMiles),
    parkInresidentAddress: asBoolean(record.parkInresidentAddress),
    rideSharing: asBoolean(record.rideSharing),
    alternativeFuels: asBoolean(record.alternativeFuels),
    antiTheftDevice: asString(record.antiTheftDevice),
    passiveRestraint: asString(record.passiveRestraint),
    airBagSeatBelt: asString(record.airBagSeatBelt),
    antiLockBrakes: asString(record.antiLockBrakes),
    stabilityControl: asString(record.stabilityControl),
    daytimeLights: asString(record.daytimeLights),
    theftRecoverySystem: asString(record.theftRecoverySystem),
    vinEtching: asBoolean(record.vinEtching),
    lessorStateName: asString(record.lessorStateName),
    lessor: asString(record.lessor),
    currentOdometerReading: asString(record.currentOdometerReading),
    dateOfReading: asString(record.dateOfReading),
    useVIN: asBoolean(record.useVIN),
    garagingAddress: asString(record.garagingAddress),
    garagingApt: asString(record.garagingApt),
    garagingCity: asString(record.garagingCity),
    garagingZip: asString(record.garagingZip),
    mediaAlphaModel: asString(record.mediaAlphaModel),
    submodel: asString(record.submodel),
    mediaAlphaAnnualMiles: asString(record.mediaAlphaAnnualMiles),
    collisionDeductible: asString(record.collisionDeductible),
    comprehensiveDeductible: asString(record.comprehensiveDeductible),
  };
}

function mapAdditionalDriver(record: ExcelRecord): AutoAdditionalDriver {
  return {
    additionalDriverId: asNumber(record.additionalDriverId),
    applicantId: asNumber(record.applicantId),
    incidentId: asNumber(record.incidentId),
    firstName: asString(record.firstName),
    lastName: asString(record.lastName),
    age: asNumber(record.age),
    dateOfBirth: asString(record.dateOfBirth),
    relationshipToApplicant: asString(record.relationshipToApplicant),
    maritalStatus: asString(record.maritalStatus),
    gender: asString(record.gender),
    occupation: asString(record.occupation),
    otherOccupation: asString(record.otherOccupation),
    licenseToDriveInUSA: asString(record.licenseToDriveInUSA),
    firstAgeUnitedStatesDriverLicense: asNumber(record.firstAgeUnitedStatesDriverLicense),
    firstAgeForeignDriverLicense: asNumber(record.firstAgeForeignDriverLicense),
    fullTimeStudentWithHighGPA: asBoolean(record.fullTimeStudentWithHighGPA),
    attendsDistantSchool: asBoolean(record.attendsDistantSchool),
    completedDriversSafetyCourse: asBoolean(record.completedDriversSafetyCourse),
    financialFiling: asString(record.financialFiling),
    anyIncident: asBoolean(record.anyIncident),
    driversLicense: asString(record.driversLicense),
    licenseIssueStateName: asString(record.licenseIssueStateName),
    mediaAlphaCurrentlyInsured: asString(record.mediaAlphaCurrentlyInsured),
    signalMobilePhone: asString(record.signalMobilePhone),
  };
}

function mapIncident(record: ExcelRecord): AutoIncident {
  return {
    incidentId: asNumber(record.incidentId),
    applicantId: asNumber(record.applicantId),
    additionalDriverId: asNumber(record.additionalDriverId),
    incidentType: asString(record.incidentType),
    description: asString(record.description),
    dateOccuredOffsetInDays: asString(record.dateOccuredOffsetInDays),
    dateOccured: asString(record.dateOccured),
    anyInjuries: asBoolean(record.anyInjuries),
    mediaAlphaIncidentType: asString(record.mediaAlphaIncidentType),
    mediaAlphaIncidentDescription: asString(record.mediaAlphaIncidentDescription),
    mediaAlphaAmountPaidByInsurance: asString(record.mediaAlphaAmountPaidByInsurance),
    mediaAlphaDamageTo: asString(record.mediaAlphaDamageTo),
    mediaAlphaDriverAtFault: asString(record.mediaAlphaDriverAtFault),
  };
}

function mapDiscount(record: ExcelRecord): AutoDiscount {
  return {
    discountId: asNumber(record.discountId),
    applicantId: asNumber(record.applicantId),
    paymentMethod: asString(record.paymentMethod),
    startDateOfNewPolicy: asString(record.startDateOfNewPolicy),
    homeInsurance: asBoolean(record.homeInsurance),
    rentersInsurance: asBoolean(record.rentersInsurance),
    condoInsurance: asBoolean(record.condoInsurance),
    valueTermLifeInsurance: asBoolean(record.valueTermLifeInsurance),
    umbrellaInsurance: asBoolean(record.umbrellaInsurance),
    businessInsurance: asBoolean(record.businessInsurance),
    ownOrRentHome: asString(record.ownOrRentHome),
    paymentMethodForDiscount: asString(record.paymentMethodForDiscount),
    mediaAlphaTimeAtResidence: asString(record.mediaAlphaTimeAtResidence),
    mediaAlphaHasGarage: asString(record.mediaAlphaHasGarage),
    signalSignup: asBoolean(record.signalSignup),
  };
}

function mapPayment(record: ExcelRecord): AutoPayment {
  return {
    paymentId: asNumber(record.paymentId),
    applicantId: asNumber(record.applicantId),
    paymentPlan: asString(record.paymentPlan),
    paymentMethod: asString(record.paymentMethod),
    accountHolderName: asString(record.accountHolderName),
    routingNumber: asString(record.routingNumber),
    bankAccountNumber: asString(record.bankAccountNumber),
    bankName: asString(record.bankName),
    creditCardType: asString(record.creditCardType),
    debitCardType: asString(record.debitCardType),
    nameOnCard: asString(record.nameOnCard),
    cardNumber: asString(record.cardNumber),
    expirationDate: asString(record.expirationDate),
    billingZipCode: asString(record.billingZipCode),
  };
}

function groupByApplicantId<T extends { applicantId: number }>(items: readonly T[]): Map<number, T[]> {
  const map = new Map<number, T[]>();
  for (const item of items) {
    const bucket = map.get(item.applicantId);
    if (bucket) bucket.push(item);
    else map.set(item.applicantId, [item]);
  }
  return map;
}

export class AutoApplicantProvider {
  private readonly dataSource: ExcelDataSource;

  public constructor(dataSource = new ExcelDataSource()) {
    this.dataSource = dataSource;
  }

  public async selectRandomApplicant(metadata: LegacyTestMetadata): Promise<SelectedAutoApplicant> {
    if (metadata.dataProvider !== AUTO_APPLICANT_PROVIDER) {
      throw new Error(
        `Unsupported provider for this migration stage: ${metadata.dataProvider}. Expected ${AUTO_APPLICANT_PROVIDER}.`,
      );
    }
    if (metadata.testName !== RANDOM_AUTO_APPLICANT) {
      throw new Error(
        `Unsupported provider testName for this migration stage: ${metadata.testName}. Expected ${RANDOM_AUTO_APPLICANT}.`,
      );
    }

    const annotationFilter = parseFilter(metadata.annotation);
    const excludedStates = parseExcludedStates(metadata.annotation);

    const applicantRows = await this.dataSource.rows(WORKBOOK, APPLICANT_SHEET);
    const prefilteredRows = annotationFilter
      ? this.dataSource.filter(applicantRows, annotationFilter)
      : [...applicantRows];
    const candidates = prefilteredRows.filter(
      (row) => !excludedStates.has(asString(row.stateCode)),
    );

    const nonKnockoutCandidates = candidates.filter((row) => !asBoolean(row.knockoutExpected));
    const selectionPool = nonKnockoutCandidates.length > 0 ? nonKnockoutCandidates : candidates;

    if (selectionPool.length === 0) {
      throw new Error(
        `No applicants matched provider selection for ${metadata.legacyId}. Filter: ${annotationFilter || 'none'}, excluded: ${[...excludedStates].join(',') || 'none'}.`,
      );
    }

    const allVehicles = (await this.dataSource.rows(WORKBOOK, 'vehicles')).map(mapVehicle);
    const allDrivers = (await this.dataSource.rows(WORKBOOK, 'additionalDriver')).map(mapAdditionalDriver);
    const allIncidents = (await this.dataSource.rows(WORKBOOK, 'incidents')).map(mapIncident);
    const allDiscounts = (await this.dataSource.rows(WORKBOOK, 'discounts')).map(mapDiscount);
    const allPayments = (await this.dataSource.rows(WORKBOOK, 'payments')).map(mapPayment);

    const vehiclesByApplicant = groupByApplicantId(allVehicles);
    const driversByApplicant = groupByApplicantId(allDrivers);
    const incidentsByApplicant = groupByApplicantId(allIncidents);
    const discountsByApplicant = groupByApplicantId(allDiscounts);
    const paymentsByApplicant = groupByApplicantId(allPayments);

    const seed = env.AUTO_PROVIDER_SEED;
    const rng: Rng = seed === undefined ? () => randomInt(0, 1_000_000) / 1_000_000 : seededRng(seed);
    const selectedIndex = pickRandomIndex(selectionPool.length, rng);
    const selectedRecord = selectionPool[selectedIndex];
    if (!selectedRecord) {
      throw new Error(`Random selection failed for ${metadata.legacyId}: no candidate record.`);
    }
    const selectedApplicantId = asNumber(selectedRecord.applicantId);

    const applicant: AutoApplicant = {
      applicantId: selectedApplicantId,
      testCategory: asString(selectedRecord.testCategory),
      testScenario: asString(selectedRecord.testScenario),
      gender: asString(selectedRecord.gender),
      residentAddress1: asString(selectedRecord.residentAddress1),
      residentAddress2: asString(selectedRecord.residentAddress2),
      city: asString(selectedRecord.city),
      zipCode: asString(selectedRecord.zipCode),
      stateCode: asString(selectedRecord.stateCode),
      stateName: asString(selectedRecord.stateName),
      maritalStatus: asString(selectedRecord.maritalStatus),
      occupation: asString(selectedRecord.occupation),
      currentlyInsuredStatus: asString(selectedRecord.currentlyInsuredStatus),
      currentInsuranceCompany: asString(selectedRecord.currentInsuranceCompany),
      continuosInsurancePeriod: asString(selectedRecord.continuosInsurancePeriod),
      currentBodilyInjuryLimit: asString(selectedRecord.currentBodilyInjuryLimit),
      financialFiling: asString(selectedRecord.financialFiling),
      firstName: asString(selectedRecord.firstName),
      lastName: asString(selectedRecord.lastName),
      age: asNumber(selectedRecord.age),
      otherOccupation: asString(selectedRecord.otherOccupation),
      dateOfBirth: asString(selectedRecord.dateOfBirth),
      mailingAddressDifferent: asBoolean(selectedRecord.mailingAddressDifferent),
      currentlyHaveAutoInsurance: asString(selectedRecord.currentlyHaveAutoInsurance),
      principalPIP: asString(selectedRecord.principalPIP),
      firstAgeUnitedStatesDriverLicense: asNumber(selectedRecord.firstAgeUnitedStatesDriverLicense),
      firstAgeForeignDriverLicense: asNumber(selectedRecord.firstAgeForeignDriverLicense),
      fullTimeStudentWithHighGPA: asBoolean(selectedRecord.fullTimeStudentWithHighGPA),
      email: asString(selectedRecord.email),
      phoneNumber: asString(selectedRecord.phoneNumber),
      phoneExtentionNumber: asString(selectedRecord.phoneExtentionNumber),
      knockoutExpected: asBoolean(selectedRecord.knockoutExpected),
      completedDriversSafetyCourse: asBoolean(selectedRecord.completedDriversSafetyCourse),
      havePersonalInjuryLoss: asBoolean(selectedRecord.havePersonalInjuryLoss),
      haveAccidentOrViolations: asBoolean(selectedRecord.haveAccidentOrViolations),
      currentInsuranceExpirationDate: asString(selectedRecord.currentInsuranceExpirationDate),
      driversLicense: asString(selectedRecord.driversLicense),
      licenseIssueStateName: asString(selectedRecord.licenseIssueStateName),
      attemptToBind: asString(selectedRecord.attemptToBind),
      garagingAddress: asString(selectedRecord.garagingAddress),
      vehicles: Object.freeze(vehiclesByApplicant.get(selectedApplicantId) ?? []),
      additionalDrivers: Object.freeze(driversByApplicant.get(selectedApplicantId) ?? []),
      incidents: Object.freeze(incidentsByApplicant.get(selectedApplicantId) ?? []),
      discounts: Object.freeze(discountsByApplicant.get(selectedApplicantId) ?? []),
      payments: Object.freeze(paymentsByApplicant.get(selectedApplicantId) ?? []),
    };

    const rowNumber = selectedIndex + 2;
    const correlationId = getCorrelationId(applicant.applicantId, applicant.stateCode, rowNumber);
    console.info(
      `[AutoApplicantProvider] workbook=${WORKBOOK} sheet=${APPLICANT_SHEET} row=${rowNumber} applicantId=${applicant.applicantId} state=${applicant.stateCode} correlationId=${correlationId}`,
    );

    return {
      workbook: WORKBOOK,
      worksheet: APPLICANT_SHEET,
      rowNumber,
      correlationId,
      applicant,
    };
  }
}
