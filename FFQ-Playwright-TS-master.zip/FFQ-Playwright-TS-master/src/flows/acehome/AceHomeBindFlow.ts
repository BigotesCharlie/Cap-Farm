import type { Page } from '@playwright/test';
import type { ApplicantAceHome } from '../../models/acehome/ApplicantAceHome.js';
import type { FlowHooks } from './AceHomeNavigationFlow.js';
import { AceHomeNavigationFlow } from './AceHomeNavigationFlow.js';

export class AceHomeBindFlow {
  public constructor(
    private readonly page: Page,
    private readonly hooks: FlowHooks,
  ) {}

  public async continueFromReviewQuote(applicant: ApplicantAceHome): Promise<void> {
    const flow = new AceHomeNavigationFlow(this.page, this.hooks);
    await flow.continueFromReviewToPayment(applicant);
  }
}
