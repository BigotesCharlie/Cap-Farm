import type { Page } from '@playwright/test';
import { AceHomeQuoteRetrievalPage, AceHomeReviewQuotePage } from '../../pages/acehome/AceHomePages.js';
import type { FlowHooks } from './AceHomeNavigationFlow.js';

export class AceHomeRetrieveQuoteFlow {
  public constructor(
    private readonly page: Page,
    private readonly hooks: FlowHooks,
  ) {}

  public async retrieveByQuoteNumber(quoteNumber: string): Promise<AceHomeReviewQuotePage> {
    const retrieval = new AceHomeQuoteRetrievalPage(this.page);
    await retrieval.retrieveByQuoteNumber(quoteNumber);
    this.hooks.annotate('logical-checkpoint', 'quote-retrieval-submit');

    const review = new AceHomeReviewQuotePage(this.page);
    await review.assertOnPage();
    await this.hooks.checkpoint('11-review-quote-retrieved');
    return review;
  }
}
