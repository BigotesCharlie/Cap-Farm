import { promises as fs } from 'node:fs';
import { expect, type Locator, type Page, type TestInfo } from '@playwright/test';

type PageSummary = {
  readonly url: string;
  readonly title: string;
  readonly heading: string;
  readonly pageClassification: string;
  readonly visibleButtons: Array<{
    text: string;
    id: string;
    disabled: boolean;
    ariaDisabled: string;
    visible: boolean;
  }>;
  readonly selectedValues: string[];
  readonly validationMessages: string[];
  readonly overlayVisible: boolean;
  readonly overlayText: string[];
  readonly zoom: string;
};

function checkpointPrefix(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

function classifyPage(url: string, heading: string, overlayVisible: boolean): string {
  const normalizedHeading = heading.toLowerCase();
  const normalizedUrl = url.toLowerCase();

  if (/inconvenience/.test(normalizedUrl) || /sorry for the inconvenience|inconvenience/.test(normalizedHeading))
    return 'INCONVENIENCE';
  if (/try again/.test(normalizedHeading) || /try-again/.test(normalizedUrl)) return 'TRY_AGAIN';
  if (/knockout|unable to continue|cannot continue|not eligible|unable to offer/.test(normalizedHeading))
    return 'KNOCKOUT';
  if (
    /review-quote/.test(normalizedUrl) &&
    (/one moment|loading|processing|please wait/.test(normalizedHeading) || overlayVisible)
  )
    return 'REVIEW_QUOTE_LOADING';
  if (/review-quote/.test(normalizedUrl) || /review quote|review your quote/.test(normalizedHeading))
    return 'REVIEW_QUOTE';
  if (/dwelling/.test(normalizedUrl) || /dwelling coverage/.test(normalizedHeading)) return 'DWELLING_COVERAGE';
  return 'UNKNOWN';
}

export async function collectPageSummary(page: Page): Promise<PageSummary> {
  const summary = await page
    .evaluate(() => {
      const isVisible = (element: Element): boolean => {
        const html = element as HTMLElement;
        const style = window.getComputedStyle(html);
        if (style.visibility === 'hidden' || style.display === 'none') return false;
        const rect = html.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0;
      };

      const textOf = (element: Element): string => (element.textContent ?? '').replace(/\s+/g, ' ').trim();

      const visibleButtons = Array.from(document.querySelectorAll('button, [role="button"]'))
        .filter(isVisible)
        .slice(0, 40)
        .map((node) => {
          const html = node as HTMLElement;
          return {
            text: textOf(node) || html.getAttribute('aria-label') || '',
            id: html.id || '',
            disabled: html instanceof HTMLButtonElement ? html.disabled : html.getAttribute('aria-disabled') === 'true',
            ariaDisabled: html.getAttribute('aria-disabled') || '',
            visible: true,
          };
        });

      const selectedValues = Array.from(
        document.querySelectorAll('input:checked, option:checked, [aria-checked="true"]'),
      )
        .filter(isVisible)
        .slice(0, 40)
        .map(textOf);

      const validationMessages = Array.from(
        document.querySelectorAll('[role="alert"], .mat-error, .error, .validation-message, [aria-invalid="true"]'),
      )
        .filter(isVisible)
        .slice(0, 40)
        .map(textOf)
        .filter(Boolean);

      const overlayText = Array.from(
        document.querySelectorAll(
          '[role="progressbar"], .spinner, .loading, [aria-busy="true"], .mat-progress-spinner',
        ),
      )
        .filter(isVisible)
        .slice(0, 20)
        .map(textOf)
        .filter(Boolean);

      const heading =
        Array.from(document.querySelectorAll('h1, h2, h3, [role="heading"]'))
          .filter(isVisible)
          .map(textOf)
          .find(Boolean) ?? '';

      return {
        heading,
        visibleButtons,
        selectedValues,
        validationMessages,
        overlayVisible: overlayText.length > 0,
        overlayText,
        zoom: document.documentElement.style.zoom || '',
      };
    })
    .catch(() => ({
      heading: '',
      visibleButtons: [] as PageSummary['visibleButtons'],
      selectedValues: [] as string[],
      validationMessages: [] as string[],
      overlayVisible: false,
      overlayText: [] as string[],
      zoom: '',
    }));

  return {
    url: page.url(),
    title: await page.title().catch(() => ''),
    pageClassification: classifyPage(page.url(), summary.heading, summary.overlayVisible),
    heading: summary.heading,
    visibleButtons: summary.visibleButtons,
    selectedValues: summary.selectedValues,
    validationMessages: summary.validationMessages,
    overlayVisible: summary.overlayVisible,
    overlayText: summary.overlayText,
    zoom: summary.zoom,
  };
}

export async function applyGlobalBrowserZoom(page: Page, zoom = 0.75): Promise<void> {
  const percent = `${Math.round(zoom * 100)}%`;

  await page.context().addInitScript((zoomValue) => {
    const applyZoom = (): void => {
      if (document.documentElement) {
        document.documentElement.style.zoom = zoomValue;
      }
    };

    applyZoom();
    document.addEventListener('DOMContentLoaded', applyZoom);
    window.addEventListener('pageshow', applyZoom);
  }, percent);

  await page.evaluate((zoomValue) => {
    if (document.documentElement) {
      document.documentElement.style.zoom = zoomValue;
    }
  }, percent);

  const applied = await page.evaluate(() => document.documentElement?.style.zoom ?? '').catch(() => '');
  if (applied !== percent) {
    throw new Error(`Global zoom not applied. Expected ${percent}, got ${applied || 'unset'}.`);
  }
}

export async function prepareLocatorForClick(locator: Locator, page?: Page, name = 'click-target'): Promise<void> {
  await locator.waitFor({ state: 'attached' });
  await locator.scrollIntoViewIfNeeded();
  await expect(locator, `${name} should be visible`).toBeVisible();
  await expect(locator, `${name} should be enabled`).toBeEnabled();

  if (page) {
    const overlay = page
      .locator('[role="progressbar"], .spinner, .loading, [aria-busy="true"], .mat-progress-spinner')
      .first();
    if (await overlay.isVisible().catch(() => false)) {
      await expect(overlay, `${name} overlay should clear before click`).toBeHidden({ timeout: 5000 });
    }
  }
}

export async function clickAfterReadiness(locator: Locator, page?: Page, name = 'click-target'): Promise<void> {
  if (!page) {
    await prepareLocatorForClick(locator, undefined, name);
    await locator.click();
    return;
  }

  await safeScrollAndClick(locator, name, { page });
}

async function waitForAnimationFrame(page: Page): Promise<void> {
  await page.evaluate(
    () =>
      new Promise<void>((resolve) => {
        requestAnimationFrame(() => requestAnimationFrame(() => resolve()));
      }),
  );
}

async function getLocatorState(locator: Locator): Promise<{
  attached: boolean;
  visible: boolean;
  enabled: boolean;
  boundingBox: { x: number; y: number; width: number; height: number } | null;
  computed: { display: string; visibility: string; pointerEvents: string; ariaDisabled: string; disabled: boolean };
}> {
  const attached = await locator
    .count()
    .then((count) => count > 0)
    .catch(() => false);
  const visible = await locator.isVisible().catch(() => false);
  const enabled = await locator.isEnabled().catch(() => false);
  const boundingBox = await locator.boundingBox().catch(() => null);
  const computed = await locator
    .evaluate((node) => {
      const element = node as HTMLElement;
      const style = window.getComputedStyle(element);
      return {
        display: style.display,
        visibility: style.visibility,
        pointerEvents: style.pointerEvents,
        ariaDisabled: element.getAttribute('aria-disabled') ?? '',
        disabled: element instanceof HTMLButtonElement ? element.disabled : element.getAttribute('disabled') !== null,
      };
    })
    .catch(() => ({
      display: 'unknown',
      visibility: 'unknown',
      pointerEvents: 'unknown',
      ariaDisabled: 'unknown',
      disabled: false,
    }));

  return { attached, visible, enabled, boundingBox, computed };
}

async function waitForStableLocator(
  locator: Locator,
  page: Page,
  logicalName: string,
): Promise<{
  boundingBox: { x: number; y: number; width: number; height: number } | null;
  state: Awaited<ReturnType<typeof getLocatorState>>;
}> {
  const deadline = Date.now() + 2500;
  let lastBox: { x: number; y: number; width: number; height: number } | null = null;
  let stableCount = 0;
  let state = await getLocatorState(locator);

  while (Date.now() < deadline) {
    if (state.boundingBox) {
      const { x, y, width, height } = state.boundingBox;
      const isWithinViewport = await page
        .evaluate(
          (box) => {
            const vw = window.innerWidth;
            const vh = window.innerHeight;
            return box.x >= 0 && box.y >= 0 && box.x + box.width <= vw && box.y + box.height <= vh;
          },
          { x, y, width, height },
        )
        .catch(() => true);

      if (!isWithinViewport) {
        stableCount = 0;
        lastBox = state.boundingBox;
        await waitForAnimationFrame(page);
        state = await getLocatorState(locator);
        continue;
      }

      if (
        lastBox &&
        lastBox.x === state.boundingBox.x &&
        lastBox.y === state.boundingBox.y &&
        lastBox.width === state.boundingBox.width &&
        lastBox.height === state.boundingBox.height
      ) {
        stableCount += 1;
      } else {
        stableCount = 0;
      }

      lastBox = state.boundingBox;

      if (stableCount >= 1) {
        return { boundingBox: state.boundingBox, state };
      }
    }

    await waitForAnimationFrame(page);
    state = await getLocatorState(locator);
  }

  throw new Error(`Layout stability timeout for ${logicalName}`);
}

export async function safeScrollAndClick(
  locator: Locator,
  logicalName: string,
  options: {
    page: Page;
    stageLabel?: string;
    beforeRealClick?: () => Promise<void>;
    afterRealClick?: () => Promise<void>;
  },
): Promise<void> {
  const { page, stageLabel = logicalName, beforeRealClick, afterRealClick } = options;

  console.log(`[${stageLabel}] Scroll requested`);
  await locator.waitFor({ state: 'attached' });
  await locator.waitFor({ state: 'visible' });

  await expect(locator, `${stageLabel} should be enabled before scroll`).toBeEnabled();

  await locator.scrollIntoViewIfNeeded();
  console.log(`[${stageLabel}] Scroll completed`);

  console.log(`[${stageLabel}] Waiting for layout stability`);
  const stabilized = await waitForStableLocator(locator, page, logicalName);

  const readyState = await getLocatorState(locator);
  const trialClickPassed = await locator
    .click({ trial: true })
    .then(() => true)
    .catch(() => false);
  const readyForClick = readyState.attached && readyState.visible && readyState.enabled && trialClickPassed;

  console.log(`[${stageLabel}] Button stable`);
  console.log(
    `[${stageLabel}] Attached=${readyState.attached} Visible=${readyState.visible} Enabled=${readyState.enabled} BoundingBox=${JSON.stringify(stabilized.boundingBox)}`,
  );
  console.log(`[${stageLabel}] Trial click actionability=${trialClickPassed ? 'PASS' : 'FAIL'}`);

  if (!readyForClick) {
    throw new Error(`Button not actionable after stability wait for ${logicalName}`);
  }

  if (beforeRealClick) {
    await beforeRealClick();
  }

  console.log(`[${stageLabel}] REAL CLICK`);
  await locator.click();
  console.log(`[${stageLabel}] Click completed`);

  if (afterRealClick) {
    await afterRealClick();
  }
}

export async function captureAutoDebuggingEvidence(page: Page, testInfo: TestInfo, checkpoint: string): Promise<void> {
  const safeName = checkpointPrefix(checkpoint);
  const summary = await collectPageSummary(page);
  const legacyId =
    testInfo.annotations.filter((annotation) => annotation.type === 'legacy-id').at(-1)?.description ?? 'unknown';
  const applicantCorrelationId =
    testInfo.annotations.filter((annotation) => annotation.type === 'applicant-correlation-id').at(-1)?.description ??
    'unknown';

  await fs.writeFile(
    testInfo.outputPath(`autodebug-${safeName}.json`),
    JSON.stringify(
      {
        legacyId,
        applicantCorrelationId,
        checkpoint,
        timestamp: new Date().toISOString(),
        ...summary,
      },
      null,
      2,
    ),
    'utf8',
  );
}
