import { expect, type Locator, type Page } from '@playwright/test';
import { clickAfterReadiness } from './BrowserUi.js';

export abstract class BasePage {
  protected constructor(protected readonly page: Page) {}

  protected async open(path = ''): Promise<void> {
    await this.page.goto(path, { waitUntil: 'domcontentloaded' });
  }

  protected async click(locator: Locator): Promise<void> {
    await clickAfterReadiness(locator, this.page, 'base-page-click');
  }

  protected async fill(locator: Locator, value: string): Promise<void> {
    await expect(locator).toBeEditable();
    await locator.fill(value);
  }

  protected async selectByText(locator: Locator, value: string): Promise<void> {
    await expect(locator).toBeVisible();
    await locator.selectOption({ label: value });
  }
}
