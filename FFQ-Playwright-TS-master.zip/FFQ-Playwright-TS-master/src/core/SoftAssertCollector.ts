import { promises as fs } from 'node:fs';
import type { Page, TestInfo } from '@playwright/test';

interface SoftFailure {
  readonly checkpoint: string;
  readonly message: string;
  readonly details?: string;
  readonly artifactPrefix: string;
}

export class SoftAssertCollector {
  private readonly failures: SoftFailure[] = [];
  private counter = 0;

  public constructor(
    private readonly page: Page,
    private readonly testInfo: TestInfo,
    private readonly legacyId: string,
  ) {}

  public async check(condition: boolean, message: string, checkpoint: string, details?: string): Promise<void> {
    if (condition) return;
    this.counter += 1;
    const artifactPrefix = `soft-assert-${String(this.counter).padStart(2, '0')}`;
    await this.captureFailureArtifacts(artifactPrefix, checkpoint, message, details);
    this.failures.push(
      details === undefined
        ? { checkpoint, message, artifactPrefix }
        : { checkpoint, message, details, artifactPrefix },
    );
  }

  public async equal<T>(actual: T, expected: T, message: string, checkpoint: string): Promise<void> {
    if (actual === expected) return;
    await this.check(
      false,
      message,
      checkpoint,
      `expected=${JSON.stringify(expected)} actual=${JSON.stringify(actual)}`,
    );
  }

  public async assertAll(summary: string): Promise<void> {
    if (this.failures.length === 0) return;
    const formatted = this.failures
      .map((failure, index) => {
        const line = `${index + 1}. [${failure.checkpoint}] ${failure.message}`;
        const detail = failure.details ? ` | ${failure.details}` : '';
        return `${line}${detail} | evidence=${failure.artifactPrefix}`;
      })
      .join('\n');

    throw new Error(`${summary}\n${formatted}`);
  }

  private applicantCorrelationId(): string {
    return (
      this.testInfo.annotations.filter((annotation) => annotation.type === 'applicant-correlation-id').at(-1)
        ?.description ?? 'unknown'
    );
  }

  private async captureFailureArtifacts(
    prefix: string,
    checkpoint: string,
    message: string,
    details?: string,
  ): Promise<void> {
    await this.page.screenshot({ path: this.testInfo.outputPath(`${prefix}.png`), fullPage: true });
    await fs.writeFile(this.testInfo.outputPath(`${prefix}.html`), await this.page.content(), 'utf8');
    await fs.writeFile(
      this.testInfo.outputPath(`${prefix}.json`),
      JSON.stringify(
        {
          legacyId: this.legacyId,
          checkpoint,
          message,
          details,
          url: this.page.url(),
          title: await this.page.title().catch(() => ''),
          testName: this.testInfo.title,
          timestamp: new Date().toISOString(),
          applicantCorrelationId: this.applicantCorrelationId(),
        },
        null,
        2,
      ),
      'utf8',
    );
  }
}
