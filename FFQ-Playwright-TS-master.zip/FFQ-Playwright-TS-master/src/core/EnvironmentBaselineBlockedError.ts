import type { RootCause } from '../reporting/EnvironmentExecutionReport.js';

export class EnvironmentBaselineBlockedError extends Error {
  public readonly rootCause: RootCause;

  public constructor(rootCause: Extract<RootCause, 'INCONVENIENCE' | 'KNOCKOUT' | 'TRY_AGAIN'>, message: string) {
    super(message);
    this.name = 'EnvironmentBaselineBlockedError';
    this.rootCause = rootCause;
  }
}
