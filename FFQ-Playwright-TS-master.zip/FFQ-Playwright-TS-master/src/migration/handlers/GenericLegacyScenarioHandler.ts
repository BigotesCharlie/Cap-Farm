import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { env } from '../../config/env.js';
import { captureDomCheckpoint } from '../../core/DomCheckpoint.js';
import { AceAutoNavigationFlow } from '../../flows/auto/AceAutoNavigationFlow.js';
import { AutoApplicantProvider } from '../../data/providers/AutoApplicantProvider.js';
import { AceHomeApplicantProvider } from '../../data/providers/acehome/AceHomeApplicantProvider.js';
import { AceHomeNavigationFlow } from '../../flows/acehome/AceHomeNavigationFlow.js';
import type { ScenarioExecutionContext, ScenarioHandler } from './ScenarioTypes.js';
import type { AutoApplicant } from '../../models/auto/AutoApplicant.js';
import type { ApplicantAceHome } from '../../models/acehome/ApplicantAceHome.js';

type InventoryRow = {
  legacyId: string;
  domain: string;
  className: string;
  method: string;
  testName: string;
};

const inventoryPath = resolve('migration/audit/full-test-execution-inventory.json');

function loadInventoryRows(): InventoryRow[] {
  const source = readFileSync(inventoryPath, 'utf8');
  const parsed = JSON.parse(source) as { tests: InventoryRow[] };
  return parsed.tests;
}

function shortFamily(legacyId: string): string {
  const method = legacyId.split('#')[1] ?? legacyId;
  if (/knockout/i.test(method)) return 'knockout';
  if (/retrieve|save|restore|refresh/i.test(method)) return 'retrieve';
  if (/review|summary/i.test(method)) return 'review';
  if (/payment|bind/i.test(method)) return 'payment';
  if (/address|name|dob|personal|info/i.test(method)) return 'intake';
  return 'generic';
}

async function driveAuto(context: ScenarioExecutionContext, applicant: AutoApplicant): Promise<void> {
  const flow = new AceAutoNavigationFlow(context.page, context.testInfo);
  const finalApplicant = flow.updateApplicantDataToAvoidPossibleBw(applicant);
  await context.checkpoint('auto-generic-start');
  await flow.navigateToPaymentSelectionPage(finalApplicant);
}

async function driveAceHome(context: ScenarioExecutionContext, applicant: ApplicantAceHome): Promise<void> {
  const flow = new AceHomeNavigationFlow(
    context.page,
    { checkpoint: context.checkpoint, annotate: context.annotate },
    context.recoveryGuard,
  );
  await context.checkpoint('acehome-generic-start');
  if (shortFamily(context.metadata.legacyId) === 'retrieve') {
    await flow.navigateToReviewQuotePage(applicant);
    return;
  }
  await flow.navigateToReviewQuotePage(applicant);
}

async function driveGenericLanding(context: ScenarioExecutionContext): Promise<void> {
  await context.checkpoint('generic-landing-start');
  await context.page.goto(env.FFQ_BASE_URL, { waitUntil: 'domcontentloaded' });
  const startButton = context.page.getByRole('button', { name: /start|continue|quote/i }).first();
  if (await startButton.isVisible({ timeout: 2_000 }).catch(() => false)) {
    await startButton.click().catch(async () => {
      await startButton.click({ force: true });
    });
    await context.page.waitForLoadState('domcontentloaded').catch(() => undefined);
  }
  await captureDomCheckpoint(context.page, context.testInfo, 'generic-landing');
}

export class GenericLegacyScenarioHandler implements ScenarioHandler {
  public readonly status = 'implemented' as const;

  private readonly autoProvider = new AutoApplicantProvider();
  private readonly aceHomeProvider = new AceHomeApplicantProvider();

  public constructor(
    public readonly legacyId: string,
    public readonly domain: string,
    private readonly className: string,
    private readonly method: string,
  ) {}

  public async execute(context: ScenarioExecutionContext): Promise<void> {
    context.annotate('generic-handler', `${this.domain}:${this.className}.${this.method}`);
    context.annotate('generic-family', shortFamily(this.legacyId));

    if (this.domain === 'auto') {
      const selected = await this.autoProvider.selectRandomApplicant(context.metadata);
      context.annotate('applicant-correlation-id', selected.correlationId);
      context.annotate('provider-workbook', `${selected.workbook}:${selected.worksheet}`);
      context.annotate('provider-row', String(selected.rowNumber));
      if (/knockout/i.test(this.legacyId)) {
        context.annotate('expected-knockout', 'true');
      }
      await driveAuto(context, selected.applicant);
      return;
    }

    if (this.domain === 'acehome') {
      const selected = await this.aceHomeProvider.selectForRandomRow(context.metadata, []);
      context.annotate('applicant-correlation-id', selected.correlationId);
      context.annotate('provider-workbook', `${selected.workbook}:${selected.worksheet}`);
      context.annotate('provider-row', String(selected.rowNumber));
      const applicant = selected.applicant;
      if (/knockout/i.test(this.legacyId)) {
        context.annotate('expected-knockout', 'true');
      }
      await driveAceHome(context, applicant);
      return;
    }

    await driveGenericLanding(context);
  }
}

export function loadGenericInventoryRows(): InventoryRow[] {
  return loadInventoryRows();
}
