import { SoftAssertCollector } from '../../../core/SoftAssertCollector.js';
import { AceHomeApplicantProvider } from '../../../data/providers/acehome/AceHomeApplicantProvider.js';
import { AceHomeNavigationFlow } from '../../../flows/acehome/AceHomeNavigationFlow.js';
import type { ScenarioExecutionContext, ScenarioHandler } from '../ScenarioTypes.js';

export const ACE_HOME_SMOKE_PRESENTMENT_LEGACY_ID =
  'com.farmers.ffq.acehome.AceHomeEndToEndTest#testSmokeReviewQuotePagePresentmentCardHome';

const SMOKE_EXCLUDED_STATES = ['CA', 'LA', 'MA', 'MS', 'NC'] as const;

export class AceHomeSmokePresentmentHandler implements ScenarioHandler {
  public readonly legacyId = ACE_HOME_SMOKE_PRESENTMENT_LEGACY_ID;
  public readonly domain = 'acehome';
  public readonly status = 'implemented' as const;

  private readonly provider = new AceHomeApplicantProvider();

  public async execute(context: ScenarioExecutionContext): Promise<void> {
    const selected = await this.provider.selectForRandomRow(context.metadata, SMOKE_EXCLUDED_STATES);
    const applicant = selected.applicant;

    context.annotate('applicant-correlation-id', selected.correlationId);
    context.annotate('provider-workbook', `${selected.workbook}:${selected.worksheet}`);
    context.annotate('provider-row', String(selected.rowNumber));
    context.annotate('provider-seed', String(selected.seed));
    context.annotate('legacy-groups', 'ACE_HOME_SMOKE,ACE_HOME_ADA_SUITE,ADA_SUITE');
    context.annotate('expected-knockout', 'true');

    const fsa = new SoftAssertCollector(context.page, context.testInfo, context.metadata.legacyId);
    const flow = new AceHomeNavigationFlow(
      context.page,
      {
        checkpoint: context.checkpoint,
        annotate: context.annotate,
      },
      context.recoveryGuard,
    );
    const additionalCoverages = await flow.navigateToAdditionalCoveragesPage(applicant);

    await additionalCoverages.validatePageTitleSubtitle(fsa);
    await additionalCoverages.verifyQuotePresentmentCard(fsa);
    await additionalCoverages.validateEmailThisQuoteLink(applicant, fsa);
    await additionalCoverages.validateDiscounts(fsa);

    await fsa.assertAll('Smoke test - Validate Ace Home Additional coverages page - Quote Presentment Card.');
  }
}
