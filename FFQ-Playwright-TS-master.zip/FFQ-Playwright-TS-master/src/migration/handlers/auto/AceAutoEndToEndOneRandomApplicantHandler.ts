import { AutoApplicantProvider } from '../../../data/providers/AutoApplicantProvider.js';
import { AceAutoNavigationFlow } from '../../../flows/auto/AceAutoNavigationFlow.js';
import type { ScenarioExecutionContext, ScenarioHandler } from '../ScenarioTypes.js';

export const GOLDEN_LEGACY_ID = 'com.farmers.ffq.auto.e2e.QuoteE2ETests#aceAutoEndToEndOneRandomApplicant';

export class AceAutoEndToEndOneRandomApplicantHandler implements ScenarioHandler {
  public readonly legacyId = GOLDEN_LEGACY_ID;
  public readonly domain = 'auto';
  public readonly status = 'implemented' as const;

  private readonly provider = new AutoApplicantProvider();

  public async execute(context: ScenarioExecutionContext): Promise<void> {
    const selected = await this.provider.selectRandomApplicant(context.metadata);
    context.annotate('applicant-correlation-id', selected.correlationId);
    context.annotate('provider-workbook', `${selected.workbook}:${selected.worksheet}`);
    context.annotate('provider-row', String(selected.rowNumber));

    const flow = new AceAutoNavigationFlow(context.page, context.testInfo);
    const bwSafeApplicant = flow.updateApplicantDataToAvoidPossibleBw(selected.applicant);
    const finalApplicant = { ...bwSafeApplicant, lastName: 'Brown' };

    await context.checkpoint('00-selected-applicant');
    const result = await flow.navigateToPaymentSelectionPage(finalApplicant);
    context.annotate('quote-number', result.quoteNumber);
  }
}
