export const RUNTIME_CERTIFIED_LEGACY_IDS: readonly string[] = [];

const certifiedSet = new Set<string>(RUNTIME_CERTIFIED_LEGACY_IDS);

export function isRuntimeCertified(legacyId: string): boolean {
  return certifiedSet.has(legacyId);
}

export function getRuntimeCertifiedIds(): readonly string[] {
  return [...certifiedSet.values()];
}
