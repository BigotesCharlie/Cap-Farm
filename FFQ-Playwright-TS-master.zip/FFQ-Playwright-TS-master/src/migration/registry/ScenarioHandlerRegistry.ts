import type { ScenarioHandler } from '../handlers/ScenarioTypes.js';

export interface RegistryMetrics {
  readonly mappedScenarios: number;
  readonly implementedHandlers: number;
  readonly runtimeCertifiedHandlers: number;
  readonly remainingScenarios: number;
}

export class ScenarioHandlerRegistry {
  private readonly handlers = new Map<string, ScenarioHandler>();

  public register(handler: ScenarioHandler): void {
    const existing = this.handlers.get(handler.legacyId);
    if (existing) {
      throw new Error(
        `Duplicate handler registration for ${handler.legacyId}. Existing: ${existing.constructor.name}, New: ${handler.constructor.name}`,
      );
    }
    this.handlers.set(handler.legacyId, handler);
  }

  public resolve(legacyId: string): ScenarioHandler | undefined {
    return this.handlers.get(legacyId);
  }

  public implementedCount(): number {
    return this.handlers.size;
  }

  public runtimeCertifiedCount(isCertified: (legacyId: string) => boolean): number {
    let count = 0;
    for (const key of this.handlers.keys()) {
      if (isCertified(key)) count += 1;
    }
    return count;
  }

  public byDomain(domain: string): ScenarioHandler[] {
    return [...this.handlers.values()].filter((handler) => handler.domain === domain);
  }

  public metrics(mappedScenarios: number, isCertified: (legacyId: string) => boolean): RegistryMetrics {
    const implementedHandlers = this.implementedCount();
    const runtimeCertifiedHandlers = this.runtimeCertifiedCount(isCertified);
    return {
      mappedScenarios,
      implementedHandlers,
      runtimeCertifiedHandlers,
      remainingScenarios: Math.max(mappedScenarios - runtimeCertifiedHandlers, 0),
    };
  }
}
