import { readFile } from 'node:fs/promises';
import type { Page, TestInfo } from '@playwright/test';
import { env } from '../config/env.js';
import { captureDomCheckpoint } from '../core/DomCheckpoint.js';
import type { RecoveryGuard } from '../core/RecoveryGuard.js';
import type { ScenarioExecutionContext } from './handlers/ScenarioTypes.js';
import type { LegacyMethodContract, LegacyTestMetadata } from './LegacyTestMetadata.js';
import { getHandlerRegistry } from './registry/HandlerCatalog.js';
import { getRuntimeCertifiedIds, isRuntimeCertified } from './registry/RuntimeCertification.js';

let contracts: Promise<Record<string, LegacyMethodContract>> | undefined;

async function loadContracts(): Promise<Record<string, LegacyMethodContract>> {
  contracts ??= readFile('migration/audit/legacy-method-contracts.json', 'utf8').then(
    (source) => JSON.parse(source) as Record<string, LegacyMethodContract>,
  );
  return contracts;
}

function parseAllowlist(raw: string | undefined): Set<string> {
  if (!raw) return new Set<string>();
  const normalize = (value: string): string => {
    const trimmed = value.trim();
    const unquoted = trimmed.replace(/^['"](.*)['"]$/, '$1');
    return unquoted.trim();
  };
  return new Set(raw.split(',').map(normalize).filter(Boolean));
}

/**
 * Auditable execution boundary for generated tests.
 *
 * A behavioral handler must be registered for a test before the safety gate is
 * enabled. This deliberately fails closed: an unmigrated scenario can never be
 * reported as a false PASS merely because the FFQ landing page loaded.
 */
export async function executeMigratedScenario(
  page: Page,
  testInfo: TestInfo,
  metadata: LegacyTestMetadata,
  recoveryGuard?: RecoveryGuard,
): Promise<void> {
  const allContracts = await loadContracts();
  const contract = allContracts[metadata.legacyId];
  if (!contract) throw new Error(`Missing immutable migration contract: ${metadata.legacyId}`);

  const registry = getHandlerRegistry();
  const handler = registry.resolve(metadata.legacyId);
  if (!handler) {
    throw new Error(`Behavioral handler not implemented for ${metadata.legacyId}`);
  }

  const mappedScenarios = Object.keys(allContracts).length;
  const metrics = registry.metrics(mappedScenarios, isRuntimeCertified);
  const certified = isRuntimeCertified(metadata.legacyId);
  const handlerStatus = certified ? 'runtime-certified' : 'implemented';

  testInfo.annotations.push(
    { type: 'legacy-id', description: metadata.legacyId },
    { type: 'legacy-source', description: `${metadata.sourceFile}:${metadata.sourceLine}` },
    { type: 'data-provider', description: metadata.dataProvider || 'none' },
    { type: 'handler-domain', description: handler.domain },
    { type: 'handler-status', description: handlerStatus },
  );

  await testInfo.attach('legacy-contract.json', {
    body: Buffer.from(JSON.stringify(contract, null, 2)),
    contentType: 'application/json',
  });
  await testInfo.attach('handler-metadata.json', {
    body: Buffer.from(
      JSON.stringify(
        {
          legacyId: metadata.legacyId,
          domain: handler.domain,
          status: handlerStatus,
          certifiedIds: getRuntimeCertifiedIds(),
        },
        null,
        2,
      ),
    ),
    contentType: 'application/json',
  });
  await testInfo.attach('migration-registry-metrics.json', {
    body: Buffer.from(JSON.stringify(metrics, null, 2)),
    contentType: 'application/json',
  });

  if (!env.EXECUTE_MIGRATED_TESTS) {
    throw new Error(
      `Execution blocked for ${metadata.legacyId}. ` +
        'Set EXECUTE_MIGRATED_TESTS=true to authorize migrated scenario execution.',
    );
  }

  if (!certified) {
    const certificationRun = env.MIGRATION_ALLOW_UNCERTIFIED_CERTIFICATION_RUN;
    if (!certificationRun) {
      throw new Error(
        `Behavioral handler is implemented but runtime certification is pending for ${metadata.legacyId}. ` +
          'Set MIGRATION_ALLOW_UNCERTIFIED_CERTIFICATION_RUN=true and include the exact legacy ID in MIGRATION_CERTIFICATION_ALLOWLIST for controlled certification runs.',
      );
    }

    const allowlist = parseAllowlist(env.MIGRATION_CERTIFICATION_ALLOWLIST);
    const allowAll = allowlist.has('*');
    if (!allowAll && !allowlist.has(metadata.legacyId)) {
      throw new Error(
        `Behavioral handler is implemented but runtime certification is pending for ${metadata.legacyId}. ` +
          `Add the exact legacy ID or "*" to MIGRATION_CERTIFICATION_ALLOWLIST for controlled certification runs.`,
      );
    }
  }

  const context: ScenarioExecutionContext = {
    page,
    testInfo,
    metadata,
    contract,
    recoveryGuard,
    checkpoint: async (name: string) => {
      testInfo.annotations.push({ type: 'logical-checkpoint', description: name });
      await captureDomCheckpoint(page, testInfo, name);
    },
    annotate: (type: string, description: string) => {
      testInfo.annotations.push({ type, description });
    },
  };

  await handler.execute(context);
}
