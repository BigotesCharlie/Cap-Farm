import { expect, type Locator, type Page } from '@playwright/test';
import type { ApplicantAceHome } from '../../models/acehome/ApplicantAceHome.js';
import type { SoftAssertCollector } from '../../core/SoftAssertCollector.js';
import { clickAfterReadiness, safeScrollAndClick } from '../../core/BrowserUi.js';
import { AceHomePageClassifier } from './AceHomePageClassifier.js';

interface AppStoreEnvelope {
  readonly home?: {
    readonly dwellingCoverage?: string;
    readonly reconstructionCost?: string;
    readonly quote?: {
      readonly quoteNumber?: string;
    };
  };
}

function normalizeCurrency(raw: string): string {
  const digits = raw.replace(/[^0-9.-]/g, '');
  if (!digits) return '$0';
  const amount = Math.trunc(Number(digits));
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(Number.isFinite(amount) ? amount : 0);
}

export class AceHomeAppStoreReader {
  public constructor(private readonly page: Page) {}

  public async read(): Promise<AppStoreEnvelope> {
    const json = await this.page.evaluate(() => {
      const key = Object.keys(window.sessionStorage).find((candidate) =>
        /appstore|app-store|state-store/i.test(candidate),
      );
      if (!key) return '';
      return window.sessionStorage.getItem(key) ?? '';
    });
    if (!json) return {};

    try {
      const parsed = JSON.parse(json) as Record<string, unknown>;
      const root =
        (parsed.appStore as Record<string, unknown> | undefined) ??
        (parsed.state as Record<string, unknown> | undefined) ??
        parsed;
      return root as AppStoreEnvelope;
    } catch {
      return {};
    }
  }

  public async dwellingCoverageCurrency(): Promise<string> {
    const appStore = await this.read();
    const raw = appStore.home?.dwellingCoverage ?? appStore.home?.reconstructionCost ?? '';
    return normalizeCurrency(raw);
  }

  public async quoteNumber(): Promise<string> {
    return (await this.read()).home?.quote?.quoteNumber ?? '';
  }
}

export class AceHomeReviewQuotePage {
  private classifier: AceHomePageClassifier;

  public constructor(private readonly page: Page) {
    this.classifier = new AceHomePageClassifier(page);
  }

  public async assertOnPage(): Promise<void> {
    const classification = await this.classifier.detect();
    const isReviewQuote = classification.type === 'REVIEW_QUOTE';

    if (!isReviewQuote) {
      throw new Error(
        `PAGE_CONTRACT_MISMATCH: Expected REVIEW_QUOTE, got ${classification.type}.\n` +
          `${await this.classifier.describeCurrentPage()}`,
      );
    }
  }

  public async quotePriceOnCard(): Promise<string> {
    const price = this.page.locator('tui-quote-presentment tui-price, app-home-quote-review tui-price').first();
    await expect(price).toBeVisible();
    return (await price.innerText()).trim();
  }

  public async discounts(): Promise<string[]> {
    const entries = this.page.locator('app-home-discount li, .discount-description p, [data-testid*="DISCOUNT"]');
    const count = await entries.count();
    const values: string[] = [];
    for (let i = 0; i < count; i += 1) {
      const text = (await entries.nth(i).innerText()).trim();
      if (text) values.push(text);
    }
    return values;
  }

  public async validatePageTitleSubtitle(fsa: SoftAssertCollector, expectedDwellingCoverage: string): Promise<void> {
    await this.assertOnPage();
    // Classifier has already confirmed we're on REVIEW_QUOTE page
    // Just verify presentment card and key elements are visible
    const presentmentCard = this.page.locator('tui-quote-presentment, app-home-quote-review').first();
    const subtitle = this.page.locator('app-home-quote-review .tui-stacking-top-md, [class*="subtitle"]').first();

    const cardVisible = await presentmentCard.isVisible().catch(() => false);
    await fsa.check(cardVisible, 'Review Quote presentment card not visible.', 'review-quote-card');

    const subtitleVisible = await subtitle.isVisible().catch(() => false);
    await fsa.check(subtitleVisible, 'Review Quote subtitle not visible.', 'review-quote-subtitle');
    if (subtitleVisible) {
      const subtitleText = (await subtitle.innerText()).trim();
      await fsa.check(
        subtitleText.includes(expectedDwellingCoverage),
        'Review Quote subtitle missing dwelling coverage currency.',
        'review-quote-subtitle',
        `expected=${expectedDwellingCoverage} actual=${subtitleText}`,
      );
    }
  }

  public async verifyQuotePresentmentCard(stateCode: string, fsa: SoftAssertCollector): Promise<void> {
    const card = this.page.locator('tui-quote-presentment, .quote-presentment, app-home-quote-review').first();
    const visible = await card.isVisible().catch(() => false);
    await fsa.check(visible, 'Quote presentment card is not visible.', 'review-quote-presentment');
    if (!visible) return;

    const text = (await card.innerText()).trim();
    await fsa.check(
      /quote|coverage|discount|monthly|pay in full/i.test(text),
      'Quote presentment card content is incomplete.',
      'review-quote-presentment',
      text,
    );
    await fsa.check(Boolean(stateCode), 'State code is empty for presentment validation.', 'review-quote-presentment');
  }

  public async validateEmailThisQuoteLink(applicant: ApplicantAceHome, fsa: SoftAssertCollector): Promise<void> {
    const emailLink = this.page
      .locator('#emailLink, [data-testid="EMAIL_QUOTE_LINK"], a:has-text("Email this quote")')
      .first();
    const visible = await emailLink.isVisible().catch(() => false);
    await fsa.check(visible, 'Email This Quote link is not visible.', 'review-quote-email-link');
    await fsa.check(Boolean(applicant.emailAddress), 'Applicant email is empty.', 'review-quote-email-link');
  }

  public async validateQuoteSavedText(quoteNumber: string, fsa: SoftAssertCollector): Promise<void> {
    const saved = this.page.locator('text=/quote\\s*(saved|number)/i').first();
    const visible = await saved.isVisible().catch(() => false);
    await fsa.check(visible, 'Quote Saved text not visible.', 'review-quote-saved-text');
    if (!visible) return;

    const text = (await saved.innerText()).trim();
    await fsa.check(
      text.includes(quoteNumber),
      'Quote Saved text does not include expected quote number.',
      'review-quote-saved-text',
      `expected=${quoteNumber} actual=${text}`,
    );
  }

  public async validatePageLinksText(fsa: SoftAssertCollector): Promise<void> {
    const link = this.page.getByRole('link', { name: /change coverage/i }).first();
    await fsa.check(
      await link.isVisible().catch(() => false),
      'Change Coverage link not visible.',
      'review-quote-page-links',
    );
  }

  public async validatePageLinksNavigationTitles(fsa: SoftAssertCollector): Promise<void> {
    const links = this.page.getByRole('link');
    await fsa.check((await links.count()) > 0, 'No links found on Review Quote.', 'review-quote-page-links-navigation');
  }

  public async clickChangeCoverage(): Promise<void> {
    const link = this.page.getByRole('link', { name: /change coverage/i }).first();
    await clickAfterReadiness(link, this.page, 'change-coverage-link');
  }

  public async clickContinue(): Promise<void> {
    const button = this.page.getByRole('button', { name: /continue|review optional coverages|next/i }).first();
    await clickAfterReadiness(button, this.page, 'review-quote-continue');
  }

  public async selectEnterInfoStepper(): Promise<void> {
    const stepper = this.page.getByRole('button', { name: /enter info|property info|enter information/i }).first();
    await clickAfterReadiness(stepper, this.page, 'enter-info-stepper');
  }

  public async isWelcomeBackMessageDisplayed(firstName: string): Promise<boolean> {
    return this.page
      .getByText(new RegExp(`welcome back\\s+${firstName}`, 'i'))
      .first()
      .isVisible()
      .catch(() => false);
  }
}

export class AceHomeAdditionalCoveragesPage {
  public constructor(private readonly page: Page) {}

  public async assertOnPage(): Promise<void> {
    await expect(
      this.page.getByRole('heading', { name: /additional coverages|optional coverages/i }).first(),
    ).toBeVisible();
  }

  public async validatePageTitleSubtitle(fsa: SoftAssertCollector): Promise<void> {
    await this.assertOnPage();
    const subtitle = this.page
      .locator('app-home-additional-coverages .tui-stacking-top-md, app-home-additional-coverages p')
      .first();
    await fsa.check(
      await subtitle.isVisible().catch(() => false),
      'Additional Coverages subtitle not visible.',
      'additional-coverages-subtitle',
    );
  }

  public async verifyQuotePresentmentCard(fsa: SoftAssertCollector): Promise<void> {
    const card = this.page.locator('tui-quote-presentment, .quote-presentment').first();
    await fsa.check(
      await card.isVisible().catch(() => false),
      'Additional Coverages presentment card not visible.',
      'additional-coverages-presentment',
    );
  }

  public async validateEmailThisQuoteLink(applicant: ApplicantAceHome, fsa: SoftAssertCollector): Promise<void> {
    const emailLink = this.page.locator('#emailLink, a:has-text("Email this quote")').first();
    await fsa.check(
      await emailLink.isVisible().catch(() => false),
      'Additional Coverages email link not visible.',
      'additional-coverages-email-link',
    );
    await fsa.check(Boolean(applicant.emailAddress), 'Applicant email is empty.', 'additional-coverages-email-link');
  }

  public async validateDiscounts(fsa: SoftAssertCollector): Promise<void> {
    const discounts = this.page.locator('app-home-discount li, .discount-description p, [data-testid*="DISCOUNT"]');
    await fsa.check(
      (await discounts.count()) > 0,
      'No discounts displayed on Additional Coverages.',
      'additional-coverages-discounts',
    );
  }

  public async clickContinue(): Promise<void> {
    const button = this.page.getByRole('button', { name: /continue|next/i }).first();
    await clickAfterReadiness(button, this.page, 'additional-coverages-continue');
  }
}

export class AceHomeDwellingCoveragePage {
  private classifier: AceHomePageClassifier;

  public constructor(private readonly page: Page) {
    this.classifier = new AceHomePageClassifier(page);
  }

  public async assertOnPage(): Promise<void> {
    const classification = await this.classifier.detect();
    const isDwellingCoverage = classification.type === 'DWELLING_COVERAGE';
    const isReviewQuote = classification.type === 'REVIEW_QUOTE';
    const isAdditionalInfo = classification.type === 'ADDITIONAL_INFO';

    if (!isDwellingCoverage && !isReviewQuote && !isAdditionalInfo) {
      throw new Error(
        `PAGE_CONTRACT_MISMATCH: Expected DWELLING_COVERAGE/REVIEW_QUOTE/ADDITIONAL_INFO, got ${classification.type}.\n` +
          `${await this.classifier.describeCurrentPage()}`,
      );
    }
  }

  public async dwellingCoverageAmount(): Promise<string> {
    const value = this.page.locator('text=/\\$[0-9,]{2,}/').first();
    await expect(value).toBeVisible();
    return (await value.innerText()).trim();
  }

  public async dwellingCoverageQualityGrade(): Promise<string> {
    const quality = this.page.locator('text=/quality grade/i').first();
    if (!(await quality.isVisible().catch(() => false))) return '';
    return (await quality.innerText()).trim();
  }

  public continueButton(): import('@playwright/test').Locator {
    const continueBtn = this.page.locator('#continueButton').first();
    return continueBtn;
  }

  public async changeDwellingCoverage(): Promise<void> {
    const radios = this.page.locator('app-edit-coverage mat-radio-button, app-dwelling-coverage-list mat-radio-button');
    if ((await radios.count()) > 1) {
      await clickAfterReadiness(radios.nth(1), this.page, 'dwelling-coverage-radio');
      const save = this.page.getByRole('button', { name: /save|recalculate|update/i }).first();
      if (await save.isVisible().catch(() => false))
        await clickAfterReadiness(save, this.page, 'dwelling-coverage-save');
      return;
    }

    const change = this.page.getByRole('button', { name: /edit coverage|change coverage/i }).first();
    if (await change.isVisible().catch(() => false)) {
      await clickAfterReadiness(change, this.page, 'dwelling-coverage-change');
      if ((await radios.count()) > 1) {
        await clickAfterReadiness(radios.nth(1), this.page, 'dwelling-coverage-radio');
      }
      const save = this.page.getByRole('button', { name: /save|recalculate|update/i }).first();
      if (await save.isVisible().catch(() => false))
        await clickAfterReadiness(save, this.page, 'dwelling-coverage-save');
    }
  }

  public async displayedQuoteNumber(): Promise<string> {
    const quote = this.page.locator('text=/quote\\s*#|quote number/i').first();
    if (!(await quote.isVisible().catch(() => false))) return '';
    const text = (await quote.innerText()).trim();
    const token = text.match(/[A-Z0-9]{6,}/);
    return token?.[0] ?? text;
  }

  public async discounts(): Promise<string[]> {
    const entries = this.page.locator('app-home-discount li, .discount-description p, [data-testid*="DISCOUNT"]');
    const values: string[] = [];
    for (let i = 0; i < (await entries.count()); i += 1) {
      const text = (await entries.nth(i).innerText()).trim();
      if (text) values.push(text);
    }
    return values.sort();
  }

  public async clickContinue(): Promise<void> {
    // Real dwelling coverage page Continue button: id=continueButton, type=button (not submit)
    const continueBtn = this.continueButton();

    const button = (await continueBtn.isVisible({ timeout: 500 }).catch(() => false))
      ? continueBtn
      : this.page.getByRole('button', { name: /^Continue$/i }).first();

    // Verify button state before clicking
    const isVisible = await button.isVisible({ timeout: 500 }).catch(() => false);
    const isEnabled = await button.isEnabled({ timeout: 100 }).catch(() => false);
    const computedStyle = await button
      .evaluate((el) => {
        const style = window.getComputedStyle(el);
        return {
          display: style.display,
          visibility: style.visibility,
          pointerEvents: style.pointerEvents,
        };
      })
      .catch(() => ({ display: 'unknown', visibility: 'unknown', pointerEvents: 'unknown' }));

    console.log('🔍 Dwelling Continue Button State:', { isVisible, isEnabled, computedStyle });

    await expect(button).toBeVisible();
    await expect(button).toBeEnabled();

    console.log('📤 Clicking Dwelling Coverage Continue button...');
    try {
      await safeScrollAndClick(button, 'DWELLING', {
        page: this.page,
      });
    } catch (error) {
      console.error('❌ Click failed:', error);
      throw error;
    }
    console.log('✅ Dwelling Coverage button clicked');
  }
}

export class AceHomePropertyInfoPage {
  public constructor(private readonly page: Page) {}

  public async assertOnPage(): Promise<void> {
    await expect(this.page.getByRole('heading', { name: /property information|property info/i }).first()).toBeVisible();
  }

  public async clickContinue(): Promise<void> {
    const button = this.page.locator('#continueButton, button:has-text("Continue")').first();
    await clickAfterReadiness(button, this.page, 'property-info-continue');
  }
}

export class AceHomeQualityGradePage {
  public constructor(private readonly page: Page) {}

  public async isQualityGradePageAlone(): Promise<boolean> {
    return this.page
      .getByRole('heading', { name: /quality grade/i })
      .first()
      .isVisible()
      .catch(() => false);
  }

  public async assertStandalone(fsa: SoftAssertCollector): Promise<void> {
    await fsa.check(
      await this.isQualityGradePageAlone(),
      'Quality Grade page not visible.',
      'quality-grade-standalone',
    );
  }

  public async assertCombined(fsa: SoftAssertCollector): Promise<void> {
    const combined = this.page.locator('text=/property details|quality grade/i').first();
    await fsa.check(
      await combined.isVisible().catch(() => false),
      'Combined Property Details + Quality Grade page not visible.',
      'quality-grade-combined',
    );
  }

  public async validateAddressAndFeatures(fsa: SoftAssertCollector): Promise<void> {
    const address = this.page.locator('text=/,\\s*[A-Z]{2}\\s+\\d{5}/').first();
    await fsa.check(
      await address.isVisible().catch(() => false),
      'Quality Grade address not visible.',
      'quality-grade-address',
    );

    const features = this.page.locator('app-home-quality-grade li, .feature, [data-testid*="feature"]');
    await fsa.check((await features.count()) > 0, 'Quality Grade features not visible.', 'quality-grade-features');
  }

  public async clickContinueIfVisible(): Promise<void> {
    const button = this.page.locator('#continueButton, button:has-text("Continue")').first();
    if (await button.isVisible().catch(() => false))
      await clickAfterReadiness(button, this.page, 'quality-grade-continue');
  }
}

export class AceHomePropertyDetailsPage {
  private classifier: AceHomePageClassifier;

  public constructor(private readonly page: Page) {
    this.classifier = new AceHomePageClassifier(page);
  }

  public async assertOnPage(): Promise<void> {
    const classification = await this.classifier.detect();
    const isPropertyDetails = classification.type === 'PROPERTY_DETAILS';
    const isAdditionalInfo = classification.type === 'ADDITIONAL_INFO';

    if (!isPropertyDetails && !isAdditionalInfo) {
      throw new Error(
        `PAGE_CONTRACT_MISMATCH: Expected PROPERTY_DETAILS or ADDITIONAL_INFO, got ${classification.type}.\n` +
          `${await this.classifier.describeCurrentPage()}`,
      );
    }
  }

  public async pageTitle(): Promise<string> {
    return (
      await this.page
        .getByRole('heading', { name: /here's what we have so far|property details/i })
        .first()
        .innerText()
    ).trim();
  }

  public async validateSavedQuote(quoteNumber: string, fsa: SoftAssertCollector): Promise<void> {
    const saved = this.page.locator('text=/quote\\s*(saved|number)/i').first();
    const visible = await saved.isVisible().catch(() => false);
    await fsa.check(visible, 'Property Details quote saved text missing.', 'property-details-quote-saved');
    if (!visible) return;

    const text = (await saved.innerText()).trim();
    await fsa.check(
      text.includes(quoteNumber),
      'Property Details quote number mismatch.',
      'property-details-quote-saved',
      text,
    );
  }

  public async validateDiscounts(expected: readonly string[], fsa: SoftAssertCollector): Promise<void> {
    const discounts = this.page.locator('app-home-discount li, .discount-description p, [data-testid*="DISCOUNT"]');
    const found: string[] = [];
    for (let i = 0; i < (await discounts.count()); i += 1) {
      const text = (await discounts.nth(i).innerText()).trim();
      if (text) found.push(text);
    }
    await fsa.check(found.length > 0, 'No discounts on Property Details.', 'property-details-discounts');
    if (found.length > 0) {
      await fsa.check(
        found.sort().join('|') === [...expected].sort().join('|'),
        'Property Details discounts mismatch.',
        'property-details-discounts',
        `expected=${expected.join('|')} actual=${found.join('|')}`,
      );
    }
  }

  public async clickContinue(): Promise<void> {
    const button = this.page.locator('#continueButton, button:has-text("Continue")').first();
    await clickAfterReadiness(button, this.page, 'property-details-continue');
  }
}

export class AceHomeAdditionalInfoPage {
  public constructor(private readonly page: Page) {}

  private roofSection(): Locator {
    return this.page.locator('#roofCoverage, div[id*="roofCoverage"], div[class*="roof-question"]').first();
  }

  private roofToggleButtons(): Locator {
    return this.page.locator('#roofCoverage button, #roofCoverage [role="button"]').filter({ hasText: /yes|no/i });
  }

  private roofYesButton(): Locator {
    return this.page
      .locator('#roofCoverage button, #roofCoverage [role="button"]')
      .filter({ hasText: /^yes$/i })
      .first();
  }

  private roofNoButton(): Locator {
    return this.page
      .locator('#roofCoverage button, #roofCoverage [role="button"]')
      .filter({ hasText: /^no$/i })
      .first();
  }

  private roofYearInput(): Locator {
    return this.page
      .locator(
        '#roofCoverage input[aria-labelledby="roofReplacedLabel"], #roofCoverage .roof-question input, #roofCoverage input',
      )
      .first();
  }

  private roofYearText(): Locator {
    return this.page.locator('#roofCoverage .roof-year span, #roofCoverage div[id="roofReplacement"] span').first();
  }

  private plumbingSection(): Locator {
    return this.page.locator('#plumbingReplacement20yearBuiltCheck').first();
  }

  private temporaryRentalSection(): Locator {
    return this.page.locator('div[class*="home-additional-info-rentals"], #temporaryRental').first();
  }

  private swimmingPoolSection(): Locator {
    return this.page.locator('#swimmingPool, div[id*="swimmingPool"]').first();
  }

  private impactResistantGlassSection(): Locator {
    return this.page.getByText(/impact resistant glass/i).first();
  }

  private oilTankSection(): Locator {
    return this.page.getByText(/oil tank/i).first();
  }

  private floorResidenceSection(): Locator {
    return this.page.locator('#floorResidence, #floorResidenceContactInfo, [id*="floorResidence"]').first();
  }

  private continueButton(): Locator {
    return this.page.locator('#continueButton, button:has-text("Continue")').first();
  }

  private async checkboxByText(label: RegExp): Promise<Locator | null> {
    const labelLocator = this.page.getByText(label).first();
    if (!(await labelLocator.isVisible().catch(() => false))) return null;

    const container = labelLocator.locator('xpath=ancestor::*[self::mat-checkbox or self::div][1]').first();
    const input = container.locator('input[type="checkbox"]').first();
    if (await input.count().catch(() => 0)) return input;
    return null;
  }

  public async assertOnPage(): Promise<void> {
    await expect(
      this.page.getByRole('heading', { name: /additional information|additional info/i }).first(),
    ).toBeVisible();
  }

  public async isNewFlowEnabledState(stateCode: string): Promise<boolean> {
    const states = new Set(['AZ', 'TX', 'CA']);
    return states.has(stateCode.toUpperCase());
  }

  public async validateSelections(fsa: SoftAssertCollector): Promise<void> {
    const selected = this.page.locator('mat-button-toggle.mat-button-toggle-checked, input:checked');
    await fsa.check(
      (await selected.count()) > 0,
      'No selections detected on Additional Information.',
      'additional-info-selections',
    );
  }

  public async validateCoreContent(fsa: SoftAssertCollector, stateCode: string): Promise<void> {
    await this.assertOnPage();
    await fsa.check(
      await this.roofSection()
        .isVisible()
        .catch(() => false),
      'Roof section not visible.',
      'additional-info-content-roof',
    );
    await fsa.check(
      await this.swimmingPoolSection()
        .isVisible()
        .catch(() => false),
      'Swimming pool section not visible.',
      'additional-info-content-pool',
    );
    await fsa.check(
      await this.continueButton()
        .isVisible()
        .catch(() => false),
      'Continue button not visible.',
      'additional-info-content-continue',
    );

    const interactiveCount = await this.page
      .locator('input:visible, button:visible, [role="button"]:visible, mat-checkbox:visible')
      .count()
      .catch(() => 0);
    await fsa.check(
      interactiveCount >= 4,
      'Additional Info page has too few visible interactive controls.',
      'additional-info-content-controls',
      `count=${interactiveCount}`,
    );

    const normalizedState = stateCode.toUpperCase();
    if (normalizedState === 'CT') {
      await fsa.check(
        await this.impactResistantGlassSection()
          .isVisible()
          .catch(() => false),
        'Impact resistant glass section missing for CT.',
        'additional-info-content-impact-glass',
      );
    }
    if (normalizedState === 'MA') {
      await fsa.check(
        await this.oilTankSection()
          .isVisible()
          .catch(() => false),
        'Oil tank section missing for MA.',
        'additional-info-content-oil-tank',
      );
    }
    if (normalizedState === 'AL') {
      await fsa.check(
        await this.floorResidenceSection()
          .isVisible()
          .catch(() => false),
        'Floor residence section missing for AL.',
        'additional-info-content-floor-residence',
      );
    }

    const plumbingVisible = await this.plumbingSection()
      .isVisible()
      .catch(() => false);
    if (Number(applicantYearOrZero()) >= 0) {
      await fsa.check(
        plumbingVisible ||
          (await this.temporaryRentalSection()
            .isVisible()
            .catch(() => false)),
        'Neither plumbing nor temporary rental section is visible.',
        'additional-info-content-secondary-sections',
      );
    }
  }

  public async roofYearPrefilledByNearMap(): Promise<string> {
    const roofText = this.roofYearText();
    if (await roofText.isVisible().catch(() => false)) {
      const text = (await roofText.innerText()).trim();
      const match = text.match(/(19|20)\d{2}/);
      if (match) return match[0];
    }

    const input = this.roofYearInput();
    if (await input.isVisible().catch(() => false)) {
      const value = (await input.inputValue().catch(() => '')).trim();
      const match = value.match(/(19|20)\d{2}/);
      return match?.[0] ?? value;
    }

    return '';
  }

  public async numberOfRoofReplacedToggleButtons(): Promise<number> {
    return this.roofToggleButtons().count();
  }

  public async validateFloorResidenceIsLocatedOnSection(): Promise<boolean> {
    const section = this.floorResidenceSection();
    if (await section.isVisible().catch(() => false)) return true;
    return this.page
      .getByText(/floor residence.*located/i)
      .first()
      .isVisible()
      .catch(() => false);
  }

  public async triggerValidationErrors(): Promise<void> {
    const roofYes = this.roofYesButton();
    if (await roofYes.isVisible().catch(() => false)) {
      await clickAfterReadiness(roofYes, this.page, 'additional-info-roof-yes');
      const roofYear = this.roofYearInput();
      if (await roofYear.isVisible().catch(() => false)) {
        await roofYear.fill('1800');
      }
    }

    await this.clickContinue();
  }

  public async visibleValidationErrors(): Promise<string[]> {
    const errors = this.page.locator('mat-error:visible, [role="alert"]:visible, .tui-error:visible');
    const values: string[] = [];
    for (let i = 0; i < (await errors.count().catch(() => 0)); i += 1) {
      const text = (
        await errors
          .nth(i)
          .innerText()
          .catch(() => '')
      )
        .replace(/\s+/g, ' ')
        .trim();
      if (text) values.push(text);
    }
    return values;
  }

  public async majorSectionState(): Promise<Record<string, boolean>> {
    return {
      roof: await this.roofSection()
        .isVisible()
        .catch(() => false),
      plumbing: await this.plumbingSection()
        .isVisible()
        .catch(() => false),
      temporaryRental: await this.temporaryRentalSection()
        .isVisible()
        .catch(() => false),
      swimmingPool: await this.swimmingPoolSection()
        .isVisible()
        .catch(() => false),
      floorResidence: await this.floorResidenceSection()
        .isVisible()
        .catch(() => false),
    };
  }

  public async mutateForPersistence(): Promise<{ field: string; value: string; kind: 'input' | 'checkbox' }> {
    const roofYear = this.roofYearInput();
    const roofYes = this.roofYesButton();
    if (await roofYes.isVisible().catch(() => false)) {
      await clickAfterReadiness(roofYes, this.page, 'additional-info-persistence-roof-yes');
    }
    if (await roofYear.isVisible().catch(() => false)) {
      const value = '1999';
      await roofYear.fill(value);
      return { field: 'roofYear', value, kind: 'input' };
    }

    const swimmingPoolCheckbox = await this.checkboxByText(/swimming pool/i);
    if (swimmingPoolCheckbox) {
      const wasChecked = await swimmingPoolCheckbox.isChecked().catch(() => false);
      if (wasChecked) {
        await swimmingPoolCheckbox.uncheck().catch(async () => {
          await clickAfterReadiness(swimmingPoolCheckbox, this.page, 'additional-info-persistence-pool-toggle');
        });
        return { field: 'swimmingPool', value: 'false', kind: 'checkbox' };
      }
      await swimmingPoolCheckbox.check().catch(async () => {
        await clickAfterReadiness(swimmingPoolCheckbox, this.page, 'additional-info-persistence-pool-toggle');
      });
      return { field: 'swimmingPool', value: 'true', kind: 'checkbox' };
    }

    const temporaryRentalCheckbox = await this.checkboxByText(/temporary rental|rentals/i);
    if (temporaryRentalCheckbox) {
      const wasChecked = await temporaryRentalCheckbox.isChecked().catch(() => false);
      if (wasChecked) {
        await temporaryRentalCheckbox.uncheck().catch(async () => {
          await clickAfterReadiness(temporaryRentalCheckbox, this.page, 'additional-info-persistence-rental-toggle');
        });
        return { field: 'temporaryRental', value: 'false', kind: 'checkbox' };
      }
      await temporaryRentalCheckbox.check().catch(async () => {
        await clickAfterReadiness(temporaryRentalCheckbox, this.page, 'additional-info-persistence-rental-toggle');
      });
      return { field: 'temporaryRental', value: 'true', kind: 'checkbox' };
    }

    throw new Error('No mutable Additional Info field found for persistence validation.');
  }

  public async validateMutationValue(mutation: {
    field: string;
    value: string;
    kind: 'input' | 'checkbox';
  }): Promise<boolean> {
    if (mutation.field === 'roofYear') {
      return (await this.roofYearPrefilledByNearMap()) === mutation.value;
    }

    const checkbox =
      mutation.field === 'swimmingPool'
        ? await this.checkboxByText(/swimming pool/i)
        : await this.checkboxByText(/temporary rental|rentals/i);
    if (!checkbox) return false;
    const checked = await checkbox.isChecked().catch(() => false);
    return String(checked) === mutation.value;
  }

  public async navigateBack(): Promise<void> {
    await this.page.goBack({ waitUntil: 'domcontentloaded' }).catch(() => undefined);
  }

  public async clickContinue(): Promise<void> {
    const button = this.continueButton();
    await clickAfterReadiness(button, this.page, 'additional-info-continue');
  }
}

function applicantYearOrZero(): number {
  return 0;
}

export class AceHomeAboutYouPage {
  private classifier: AceHomePageClassifier;

  public constructor(private readonly page: Page) {
    this.classifier = new AceHomePageClassifier(page);
  }

  public async assertOnPage(): Promise<void> {
    const classification = await this.classifier.detect();
    const isAboutYou = classification.type === 'ABOUT_YOU';
    const isAddressContact = classification.type === 'ADDRESS_CONTACT';
    const isAdditionalInfo = classification.type === 'ADDITIONAL_INFO';

    if (!isAboutYou && !isAddressContact && !isAdditionalInfo) {
      throw new Error(
        `PAGE_CONTRACT_MISMATCH: Expected ABOUT_YOU/ADDRESS_CONTACT/ADDITIONAL_INFO, got ${classification.type}.\n` +
          `${await this.classifier.describeCurrentPage()}`,
      );
    }
  }

  public async validateSelections(fsa: SoftAssertCollector): Promise<void> {
    const selected = this.page.locator('mat-button-toggle.mat-button-toggle-checked, input:checked');
    await fsa.check((await selected.count()) > 0, 'No selections detected on About You.', 'about-you-selections');
  }

  public async clickContinue(): Promise<void> {
    const button = this.page.locator('#continueButton, button:has-text("Continue")').first();
    await clickAfterReadiness(button, this.page, 'about-you-continue');
  }
}

export class AceHomeContactInfoPage {
  private classifier: AceHomePageClassifier;

  public constructor(private readonly page: Page) {
    this.classifier = new AceHomePageClassifier(page);
  }

  public async assertOnPage(): Promise<void> {
    const classification = await this.classifier.detect();
    const isContactInfo = classification.type === 'CONTACT_INFO';
    const isAddressContact = classification.type === 'ADDRESS_CONTACT';
    const isAdditionalInfo = classification.type === 'ADDITIONAL_INFO';

    if (!isContactInfo && !isAddressContact && !isAdditionalInfo) {
      throw new Error(
        `PAGE_CONTRACT_MISMATCH: Expected CONTACT_INFO/ADDRESS_CONTACT/ADDITIONAL_INFO, got ${classification.type}.\n` +
          `${await this.classifier.describeCurrentPage()}`,
      );
    }
  }

  public async validateSelections(applicant: ApplicantAceHome, fsa: SoftAssertCollector): Promise<void> {
    const email = this.page.locator('input[type="email"]:visible').first();
    const phone = this.page.locator('input[type="tel"]:visible').first();
    await fsa.check(
      await email.isVisible().catch(() => false),
      'Contact info email field not visible.',
      'contact-info-email',
    );
    await fsa.check(
      await phone.isVisible().catch(() => false),
      'Contact info phone field not visible.',
      'contact-info-phone',
    );
    await fsa.check(Boolean(applicant.phoneNumber), 'Applicant phone is empty.', 'contact-info-phone');
  }

  public async clickAgreeAndSubmit(): Promise<void> {
    // Form boundary analysis identified the real submit button:
    // - ID: contactInfoCTAButton
    // - Text: "Continue" (visible)
    // - Note: Hidden duplicate exists with text "Agree and submit" (never use)
    // - Located in the main form

    // Pre-submit validation: wait for any validation errors to clear (max 3s)
    const page = this.page;
    await page
      .waitForFunction(
        () => {
          const alerts = document.querySelectorAll('[role="alert"]');
          if (alerts.length === 0) return true;
          for (const alert of alerts) {
            const text = (alert.textContent ?? '').toLowerCase();
            if (text.includes('required')) return false;
          }
          return true;
        },
        undefined,
        { timeout: 3000 },
      )
      .catch(() => {
        // If validation errors persist, log them but continue anyway
        console.warn('⚠️  Validation alerts still present after 3s, proceeding with submit');
      });

    const button = this.page.getByRole('button', { name: /^Continue$/i }).first();

    await expect(button).toHaveCount(1);
    await expect(button).toBeVisible();
    await expect(button).toBeEnabled();

    // Intercept network and console errors
    const networkErrors: string[] = [];
    const consoleErrors: string[] = [];

    page.on('response', (response) => {
      const status = response.status();
      const url = response.url();
      if (status >= 400) {
        networkErrors.push(`${status} ${url}`);
      }
    });

    page.on('console', (msg) => {
      if (msg.type() === 'error') {
        consoleErrors.push(msg.text());
      }
    });

    console.log('📤 Submitting form via Continue button...');
    await clickAfterReadiness(button, this.page, 'contact-info-submit');

    // Wait for the form submission boundary to settle.
    await page.waitForLoadState('domcontentloaded').catch(() => undefined);

    if (networkErrors.length > 0) {
      console.warn('🔴 Network errors after submit:', networkErrors);
    }
    if (consoleErrors.length > 0) {
      console.warn('🔴 Console errors after submit:', consoleErrors);
    }
    console.log('✅ Form submitted, waiting for navigation...');
  }
}

export class AceHomeJustAFewMoreThingsPage {
  public constructor(private readonly page: Page) {}

  public async assertOnPage(): Promise<void> {
    await expect(this.page.getByRole('heading', { name: /just a few more things/i }).first()).toBeVisible();
  }

  public async fillOut(applicant: ApplicantAceHome): Promise<void> {
    const policyStartDate = this.page
      .locator('input[aria-label*="Policy start date" i], input[name*="policyStart" i]')
      .first();
    if (await policyStartDate.isVisible().catch(() => false)) {
      const value = await policyStartDate.inputValue();
      if (!value) {
        const today = new Date();
        const mm = String(today.getMonth() + 1).padStart(2, '0');
        const dd = String(today.getDate()).padStart(2, '0');
        const yyyy = String(today.getFullYear());
        await policyStartDate.fill(`${mm}/${dd}/${yyyy}`);
      }
    }

    const lender = this.page.locator('input[aria-label*="Lender" i], input[name*="lender" i]').first();
    if ((await lender.isVisible().catch(() => false)) && applicant.lenderBankName) {
      const current = await lender.inputValue();
      if (!current) await lender.fill(applicant.lenderBankName);
    }
  }

  public async clickContinue(): Promise<void> {
    const button = this.page.getByRole('button', { name: /continue|next/i }).first();
    await clickAfterReadiness(button, this.page, 'just-a-few-more-things-continue');
  }
}

export class AceHomePaymentSelectionPage {
  public constructor(private readonly page: Page) {}

  public async assertOnPage(): Promise<void> {
    await expect(this.page.getByRole('heading', { name: /payment/i }).first()).toBeVisible();
  }

  public async selectPayInFullCard(): Promise<void> {
    const payInFull = this.page.getByRole('button', { name: /pay in full|card/i }).first();
    await clickAfterReadiness(payInFull, this.page, 'payment-select-pay-in-full');
  }
}

export class AceHomePaymentPage {
  public constructor(private readonly page: Page) {}

  public async assertOnPage(): Promise<void> {
    await expect(this.page.getByRole('heading', { name: /payment/i }).first()).toBeVisible();
  }
}

export class AceHomeQuoteRetrievalPage {
  public constructor(private readonly page: Page) {}

  public async retrieveByQuoteNumber(quoteNumber: string): Promise<void> {
    const quoteInput = this.page
      .locator('input[aria-label*="quote number" i], input[name*="quote" i], input[id*="quote" i]')
      .first();
    const retrieveButton = this.page.getByRole('button', { name: /retrieve|find quote|continue/i }).first();

    await expect(quoteInput).toBeVisible();
    await quoteInput.fill(quoteNumber);
    await clickAfterReadiness(retrieveButton, this.page, 'quote-retrieval-submit');
  }
}

export { AceHomePageClassifier };
