import type { Page } from '@playwright/test';

export type AceHomePageType =
  | 'FASTQUOTE_START'
  | 'LETS_BEGIN'
  | 'PERSONAL_INFO'
  | 'PROPERTY_TYPE'
  | 'PROPERTY_INFO'
  | 'QUALITY_GRADE'
  | 'PROPERTY_DETAILS'
  | 'ADDITIONAL_INFO'
  | 'ABOUT_YOU'
  | 'ADDRESS_CONTACT'
  | 'CONTACT_INFO'
  | 'DWELLING_COVERAGE'
  | 'REVIEW_QUOTE_LOADING'
  | 'REVIEW_QUOTE'
  | 'PAYMENT'
  | 'KNOCKOUT'
  | 'INCONVENIENCE'
  | 'TRY_AGAIN'
  | 'CALL_FOR_QUOTE'
  | 'UNKNOWN';

export interface PageClassificationResult {
  type: AceHomePageType;
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
  url: string;
  heading: string;
  evidence: string[];
}

export class AceHomePageClassifier {
  public constructor(private readonly page: Page) {}

  public async detect(): Promise<PageClassificationResult> {
    const url = this.page.url();
    const heading = await this.getMainHeading();

    // Recovery states (high priority)
    if (await this.isKnockoutPage()) {
      return {
        type: 'KNOCKOUT',
        confidence: 'HIGH',
        url,
        heading,
        evidence: ['matched knockout text pattern', `heading: "${heading}"`],
      };
    }

    if (await this.isInconveniencePage()) {
      return {
        type: 'INCONVENIENCE',
        confidence: 'HIGH',
        url,
        heading,
        evidence: ['matched inconvenience text pattern', `heading: "${heading}"`],
      };
    }

    if (await this.isTryAgainPage()) {
      return {
        type: 'TRY_AGAIN',
        confidence: 'HIGH',
        url,
        heading,
        evidence: ['matched try-again text pattern', `heading: "${heading}"`],
      };
    }

    // Call for quote
    if (url.includes('call-for-quote')) {
      return {
        type: 'CALL_FOR_QUOTE',
        confidence: 'HIGH',
        url,
        heading,
        evidence: ['URL contains call-for-quote'],
      };
    }

    // FastQuote start
    if (await this.isStartPage()) {
      return {
        type: 'FASTQUOTE_START',
        confidence: 'HIGH',
        url,
        heading,
        evidence: ['matched start page patterns', `heading: "${heading}"`, 'detected product selector or start button'],
      };
    }

    // Let's Begin (personal info entry)
    if (await this.isLetsBeginPage()) {
      return {
        type: 'LETS_BEGIN',
        confidence: 'HIGH',
        url,
        heading,
        evidence: [`heading matches "Let's begin"`, 'has personal info fields (first name, last name, DOB)'],
      };
    }

    // Property Type
    if (await this.isPropertyTypePage()) {
      return {
        type: 'PROPERTY_TYPE',
        confidence: 'HIGH',
        url: url,
        heading,
        evidence: ['URL path includes /property-type', 'has property type radio buttons', `heading: "${heading}"`],
      };
    }

    // Property Info / Tell us more about your home
    if (await this.isPropertyInfoPage()) {
      return {
        type: 'PROPERTY_INFO',
        confidence: 'HIGH',
        url,
        heading,
        evidence: ['heading includes property/home indicators', 'has home detail form fields', `heading: "${heading}"`],
      };
    }

    // Quality Grade
    if (await this.isQualityGradePage()) {
      return {
        type: 'QUALITY_GRADE',
        confidence: 'HIGH',
        url,
        heading,
        evidence: ['heading includes quality grade', `heading: "${heading}"`],
      };
    }

    // Property Details
    if (await this.isPropertyDetailsPage()) {
      return {
        type: 'PROPERTY_DETAILS',
        confidence: 'HIGH',
        url,
        heading,
        evidence: ['heading includes property details', `heading: "${heading}"`],
      };
    }

    // Additional Information
    if (await this.isAdditionalInfoPage()) {
      return {
        type: 'ADDITIONAL_INFO',
        confidence: 'HIGH',
        url,
        heading,
        evidence: ['heading includes additional information', `heading: "${heading}"`],
      };
    }

    // Address/Contact (combined form: "Hi {Name}" + address + email + phone)
    if (await this.isAddressContactPage()) {
      return {
        type: 'ADDRESS_CONTACT',
        confidence: 'HIGH',
        url,
        heading,
        evidence: [
          'greeting heading detected',
          'has address combobox + email + phone fields',
          '"Agree and submit" button present',
          `heading: "${heading}"`,
        ],
      };
    }

    // Contact Info (standalone)
    if (await this.isContactInfoPage()) {
      return {
        type: 'CONTACT_INFO',
        confidence: 'HIGH',
        url,
        heading,
        evidence: ['heading includes contact information', 'has email + phone fields', `heading: "${heading}"`],
      };
    }

    // About You
    if (await this.isAboutYouPage()) {
      return {
        type: 'ABOUT_YOU',
        confidence: 'HIGH',
        url,
        heading,
        evidence: ['heading includes about you', `heading: "${heading}"`],
      };
    }

    // Dwelling Coverage
    if (await this.isDwellingCoveragePage()) {
      return {
        type: 'DWELLING_COVERAGE',
        confidence: 'HIGH',
        url,
        heading,
        evidence: ['heading includes dwelling/coverage', `heading: "${heading}"`],
      };
    }

    // Review Quote Loading (intermediate state during async transition)
    if (await this.isReviewQuoteLoadingPage()) {
      return {
        type: 'REVIEW_QUOTE_LOADING',
        confidence: 'HIGH',
        url,
        heading,
        evidence: [
          'URL is /review-quote path',
          'heading shows loading message (One moment, please)',
          `heading: "${heading}"`,
        ],
      };
    }

    // Review Quote
    if (await this.isReviewQuotePage()) {
      return {
        type: 'REVIEW_QUOTE',
        confidence: 'HIGH',
        url,
        heading,
        evidence: ['heading includes review/quote', 'has presentment card elements', `heading: "${heading}"`],
      };
    }

    // Payment
    if (await this.isPaymentPage()) {
      return {
        type: 'PAYMENT',
        confidence: 'HIGH',
        url,
        heading,
        evidence: ['heading includes payment', 'has payment form elements', `heading: "${heading}"`],
      };
    }

    // Unknown
    return {
      type: 'UNKNOWN',
      confidence: 'LOW',
      url,
      heading,
      evidence: ['no page patterns matched', `heading: "${heading}"`, `url: "${url}"`],
    };
  }

  private async getMainHeading(): Promise<string> {
    return (
      (await this.page
        .locator('h1')
        .first()
        .textContent()
        .catch(() => '')) ??
      (await this.page
        .locator('h2')
        .first()
        .textContent()
        .catch(() => '')) ??
      ''
    ).trim();
  }

  private async isKnockoutPage(): Promise<boolean> {
    return this.page
      .getByText(
        /unable to continue|cannot continue|unable to offer|not eligible|it's not you\.? it's us\.?|we just can'?t offer you a farmers/i,
      )
      .isVisible({ timeout: 100 })
      .catch(() => false);
  }

  private async isInconveniencePage(): Promise<boolean> {
    return this.page
      .getByText(/sorry for the inconvenience|we're doing a bit of maintenance/i)
      .isVisible({ timeout: 100 })
      .catch(() => false);
  }

  private async isTryAgainPage(): Promise<boolean> {
    return this.page
      .getByText(/try again/i)
      .isVisible({ timeout: 100 })
      .catch(() => false);
  }

  private async isStartPage(): Promise<boolean> {
    const hasProductSelector = await this.page
      .getByRole('option', { name: /home icon/i })
      .isVisible({ timeout: 100 })
      .catch(() => false);
    const hasStartButton = await this.page
      .getByRole('button', { name: /start|get my quote/i })
      .isVisible({ timeout: 100 })
      .catch(() => false);
    return hasProductSelector || hasStartButton;
  }

  private async isLetsBeginPage(): Promise<boolean> {
    const heading = await this.getMainHeading();
    const letsBeginMatch = /let'?s begin/i.test(heading);
    if (!letsBeginMatch) return false;

    // Verify it has personal info fields
    const hasFirstName = await this.page
      .getByLabel(/first name/i)
      .isVisible({ timeout: 100 })
      .catch(() => false);
    return hasFirstName;
  }

  private async isPropertyTypePage(): Promise<boolean> {
    const urlMatch = /\/quote\/home\/property-type/i.test(this.page.url());
    if (urlMatch) return true;

    const heading = await this.getMainHeading();
    return /what type of property|property type/i.test(heading);
  }

  private async isPropertyInfoPage(): Promise<boolean> {
    const heading = await this.getMainHeading();
    const headingMatch = /tell us more about your home|property information/i.test(heading);
    if (!headingMatch) return false;

    // Verify property info controls
    const hasPropertyControls = await this.page
      .locator('input[type="number"], select, input[placeholder*="year"], input[placeholder*="square"]')
      .first()
      .isVisible({ timeout: 100 })
      .catch(() => false);
    return hasPropertyControls;
  }

  private async isQualityGradePage(): Promise<boolean> {
    const heading = await this.getMainHeading();
    return /quality grade/i.test(heading);
  }

  private async isPropertyDetailsPage(): Promise<boolean> {
    const heading = await this.getMainHeading();
    return /here's what we have so far|property details/i.test(heading);
  }

  private async isAdditionalInfoPage(): Promise<boolean> {
    const heading = await this.getMainHeading();
    const headingMatch = /additional information|other policy questions|just a few more things|more details/i.test(
      heading,
    );
    if (!headingMatch) return false;

    // Verify it has policy start date or bundle/personal info fields
    const hasPolicyStart = await this.page
      .getByLabel(/policy start|begin/i)
      .isVisible({ timeout: 100 })
      .catch(() => false);
    const hasGender = await this.page
      .getByLabel(/gender|male|female/i)
      .isVisible({ timeout: 100 })
      .catch(() => false);

    return hasPolicyStart || hasGender;
  }

  private async isAddressContactPage(): Promise<boolean> {
    // Distinctive pattern: greeting + address combobox + email + phone + "Agree and submit"
    const hasAddressCombo = await this.page
      .getByRole('combobox', { name: /address/i })
      .isVisible({ timeout: 100 })
      .catch(() => false);
    if (!hasAddressCombo) return false;

    const hasEmailInput = await this.page
      .getByLabel(/email|e-mail/i)
      .isVisible({ timeout: 100 })
      .catch(() => false);

    const hasPhoneInput = await this.page
      .getByLabel(/phone|mobile/i)
      .isVisible({ timeout: 100 })
      .catch(() => false);

    const hasAgreeButton = await this.page
      .getByRole('button', { name: /agree and submit/i })
      .isVisible({ timeout: 100 })
      .catch(() => false);

    return hasEmailInput && hasPhoneInput && hasAgreeButton;
  }

  private async isContactInfoPage(): Promise<boolean> {
    const heading = await this.getMainHeading();
    return /contact information/i.test(heading);
  }

  private async isAboutYouPage(): Promise<boolean> {
    const heading = await this.getMainHeading();
    return /about you/i.test(heading);
  }

  private async isDwellingCoveragePage(): Promise<boolean> {
    const heading = await this.getMainHeading();
    return /dwelling|coverage/i.test(heading);
  }

  private async isReviewQuoteLoadingPage(): Promise<boolean> {
    const url = this.page.url();
    const heading = await this.getMainHeading();

    // Review quote loading state: correct URL but heading shows "One moment, please"
    const urlMatch = /\/quote\/home\/review-quote|\/review-quote\/?$/i.test(url);
    if (!urlMatch) return false;

    // Must show loading message, NOT actual review quote content
    const isLoading = /one moment|please wait|loading|processing/i.test(heading);
    const notReadyYet = !/review quote|review your|quote presentment/i.test(heading);

    return isLoading && notReadyYet;
  }

  private async isReviewQuotePage(): Promise<boolean> {
    const url = this.page.url();
    const heading = await this.getMainHeading();

    // Check URL first (most reliable during loading)
    const urlMatch = /\/quote\/home\/review-quote|\/review-quote\/?$/i.test(url);

    // Check heading (may show "One moment, please" during loading, or "Review your quote", etc.)
    const headingMatch = /review quote|review your quote|coverage details|one moment please/i.test(heading);

    if (!urlMatch && !headingMatch) return false;

    // Verify presentment card or loading state
    const hasPresentmentCard = await this.page
      .locator('text=/quote|presentment|coverage|one moment/i')
      .first()
      .isVisible({ timeout: 100 })
      .catch(() => false);
    return hasPresentmentCard || urlMatch; // URL match is sufficient indicator
  }

  private async isPaymentPage(): Promise<boolean> {
    const heading = await this.getMainHeading();
    return /payment|choose your payment/i.test(heading);
  }

  public async describeCurrentPage(): Promise<string> {
    const classification = await this.detect();
    return `Page: ${classification.type} | URL: ${classification.url} | Heading: "${classification.heading}" | Confidence: ${classification.confidence} | Evidence: ${classification.evidence.join('; ')}`;
  }
}
