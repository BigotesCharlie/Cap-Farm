import { expect, type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';
import type { AutoApplicant } from '../../models/auto/AutoApplicant.js';

export class AddressPage extends BasePage {
  private readonly address: Locator;
  private readonly city: Locator;
  private readonly zipCode: Locator;
  private readonly email: Locator;
  private readonly mobilePhone: Locator;
  private readonly pageHeading: Locator;
  private readonly continueButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.address = page
      .getByRole('combobox', { name: /home address|address/i })
      .or(page.getByRole('textbox', { name: /home address|address/i }))
      .first();
    this.city = page.getByRole('textbox', { name: /city/i }).first();
    this.zipCode = page.getByRole('textbox', { name: /zipCode|zip|postal/i }).first();
    this.email = page
      .locator(
        'input[type="email"]:visible, input[formcontrolname="email"]:visible, input[aria-label*="Email"]:visible',
      )
      .first();
    this.mobilePhone = page
      .locator(
        'input[type="tel"]:visible, input[formcontrolname="phoneNumber"]:visible, input[aria-label*="phone"]:visible',
      )
      .first();
    this.pageHeading = page.getByRole('heading', { name: /^hi,/i }).first();
    this.continueButton = page.getByRole('button', { name: /agree and submit|continue/i }).first();
  }

  public async isOnPage(): Promise<boolean> {
    return this.address.isVisible({ timeout: 2_000 }).catch(() => false);
  }

  public async fillAndContinue(applicant: AutoApplicant): Promise<void> {
    await expect(this.pageHeading).toBeVisible();
    await expect(this.address).toBeVisible();
    await this.fill(this.address, applicant.residentAddress1);
    if ((await this.city.inputValue().catch(() => '')) === '') {
      await this.fill(this.city, applicant.city);
    }
    await this.fill(this.zipCode, applicant.zipCode);

    const emailValue = (await this.email.inputValue().catch(() => '')).trim();
    if (emailValue === '' && applicant.email.trim() !== '') {
      await this.email.click();
      await this.email.fill(applicant.email);
    }
    const persistedEmailValue = (await this.email.inputValue().catch(() => '')).trim();
    if (persistedEmailValue === '' && applicant.email.trim() !== '') {
      throw new Error(`Unable to populate email field with value: "${applicant.email}"`);
    }

    const phoneValue = (await this.mobilePhone.inputValue().catch(() => '')).trim();
    const normalizedPhone = applicant.phoneNumber.replace(/\D/g, '').slice(0, 10);
    if (phoneValue === '' && normalizedPhone !== '') {
      await this.mobilePhone.click();
      await this.mobilePhone.type(normalizedPhone);
    }
    const persistedPhoneValue = (await this.mobilePhone.inputValue().catch(() => '')).trim();
    if (persistedPhoneValue === '' && normalizedPhone !== '') {
      throw new Error(`Unable to populate mobile phone field with value: "${normalizedPhone}"`);
    }

    await this.click(this.continueButton);
    await this.page.waitForLoadState('domcontentloaded');
  }
}
