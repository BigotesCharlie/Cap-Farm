import { expect, type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';
import type { AutoApplicant } from '../../models/auto/AutoApplicant.js';

export class NameDobPage extends BasePage {
  private readonly firstName: Locator;
  private readonly lastName: Locator;
  private readonly dateOfBirth: Locator;
  private readonly pageHeading: Locator;
  private readonly continueButton: Locator;

  public constructor(page: Page) {
    super(page);
    this.firstName = page.locator('input#mat-input-0').first();
    this.lastName = page.locator('input#mat-input-1').first();
    this.dateOfBirth = page.locator('input#mat-input-2').first();
    this.pageHeading = page.getByRole('heading', { name: /let'?s begin/i }).first();
    this.continueButton = page
      .locator('[data-tui-tracking-id="personal-info__continue-button-cta"]')
      .or(page.getByRole('button', { name: /agree and submit|agree|continue/i }))
      .first();
  }

  public async isOnPage(): Promise<boolean> {
    const headingVisible = await this.pageHeading.isVisible({ timeout: 15_000 }).catch(() => false);
    if (headingVisible) return true;
    return this.firstName.isVisible({ timeout: 15_000 }).catch(() => false);
  }

  public async fillAndContinueIfPresent(applicant: AutoApplicant): Promise<boolean> {
    if (!(await this.isOnPage())) return false;
    await this.fillAndContinue(applicant);
    return true;
  }

  public async fillAndContinue(applicant: AutoApplicant): Promise<void> {
    await expect(this.firstName).toBeVisible();
    await this.fill(this.firstName, applicant.firstName);
    await this.fill(this.lastName, applicant.lastName);
    const normalizedDob = this.normalizeDob(applicant.dateOfBirth);
    await this.fill(this.dateOfBirth, normalizedDob);
    if ((await this.dateOfBirth.inputValue().catch(() => '')).trim() === '') {
      await this.dateOfBirth.click();
      await this.dateOfBirth.type(normalizedDob.replace(/\D/g, ''));
    }
    if ((await this.dateOfBirth.inputValue().catch(() => '')).trim() === '') {
      throw new Error(`Unable to populate DOB field with value: "${normalizedDob}"`);
    }
    await this.click(this.continueButton);
    await this.page.waitForLoadState('domcontentloaded');
  }

  private normalizeDob(rawDob: string): string {
    const value = rawDob.trim();
    if (/^\d{2}\/\d{2}\/\d{4}$/.test(value)) return value;

    const digits = value.replace(/\D/g, '');
    if (digits.length === 8) {
      const maybeYear = Number(digits.slice(0, 4));
      if (maybeYear >= 1900 && maybeYear <= 2099) {
        const mm = digits.slice(4, 6);
        const dd = digits.slice(6, 8);
        return `${mm}/${dd}/${digits.slice(0, 4)}`;
      }
      const mm = digits.slice(0, 2);
      const dd = digits.slice(2, 4);
      const yyyy = digits.slice(4, 8);
      return `${mm}/${dd}/${yyyy}`;
    }

    return value;
  }
}
