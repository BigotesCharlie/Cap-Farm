import { type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';

export class PaymentSelectionPage extends BasePage {
  private readonly paymentMarker: Locator;
  private readonly bwMarker: Locator;
  private readonly consolidatedMarker: Locator;

  public constructor(page: Page) {
    super(page);
    this.paymentMarker = page.getByRole('heading', { name: /payment/i }).first();
    this.bwMarker = page.getByText(/bristol west/i).first();
    this.consolidatedMarker = page.getByRole('heading', { name: /consolidated payment/i }).first();
  }

  public async isOnPage(): Promise<boolean> {
    const payment = await this.paymentMarker.isVisible({ timeout: 2_000 }).catch(() => false);
    const bw = await this.bwMarker.isVisible({ timeout: 2_000 }).catch(() => false);
    const consolidated = await this.consolidatedMarker.isVisible({ timeout: 2_000 }).catch(() => false);
    return payment || bw || consolidated;
  }
}
