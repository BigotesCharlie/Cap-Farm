import { type Locator, type Page } from '@playwright/test';
import { BasePage } from '../../core/BasePage.js';

export class AdditionalInfoPage extends BasePage {
  private readonly pageMarker: Locator;
  private readonly continueToPayment: Locator;

  public constructor(page: Page) {
    super(page);
    this.pageMarker = page.getByRole('heading', { name: /just a few more things|additional information/i }).first();
    this.continueToPayment = page.getByRole('button', { name: /continue to payment|continue/i }).first();
  }

  public async isOnPage(): Promise<boolean> {
    const markerVisible = await this.pageMarker.isVisible({ timeout: 2_000 }).catch(() => false);
    if (markerVisible) return true;
    return this.continueToPayment.isVisible({ timeout: 2_000 }).catch(() => false);
  }

  public async continue(): Promise<void> {
    await this.click(this.continueToPayment);
    await this.page.waitForLoadState('domcontentloaded');
  }
}
