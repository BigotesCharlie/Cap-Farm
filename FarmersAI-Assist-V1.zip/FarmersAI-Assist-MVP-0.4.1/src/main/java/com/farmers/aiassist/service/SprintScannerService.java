package com.farmers.aiassist.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.farmers.aiassist.config.RallyProperties;
import com.farmers.aiassist.model.SprintScanResult;
import com.farmers.aiassist.model.UserStorySnapshot;
import com.farmers.aiassist.rally.MockRallyClient;
import com.farmers.aiassist.rally.RallyClient;
import com.farmers.aiassist.rally.WsapiRallyClient;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class SprintScannerService {

    private static final DateTimeFormatter FILE_TS =
            DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")
                    .withZone(ZoneOffset.UTC);

    private final RallyProperties properties;
    private final MockRallyClient mockRallyClient;
    private final WsapiRallyClient wsapiRallyClient;
    private final ObjectMapper objectMapper;

    public SprintScannerService(
            RallyProperties properties,
            MockRallyClient mockRallyClient,
            WsapiRallyClient wsapiRallyClient,
            ObjectMapper objectMapper) {

        this.properties = properties;
        this.mockRallyClient = mockRallyClient;
        this.wsapiRallyClient = wsapiRallyClient;
        this.objectMapper = objectMapper.copy()
                .findAndRegisterModules()
                .enable(SerializationFeature.INDENT_OUTPUT);
    }

    public SprintScanResult scan(String project, String sprint, Boolean forceMock) {
        validate(project, sprint);

        boolean mock = forceMock != null ? forceMock : properties.isMockMode();
        RallyClient client = mock ? mockRallyClient : wsapiRallyClient;

        List<UserStorySnapshot> stories =
                client.findUserStoriesBySprint(project.trim(), sprint.trim());

        SprintScanResult result = new SprintScanResult();
        result.setProject(project.trim());
        result.setSprint(sprint.trim());
        result.setScannedAt(Instant.now());
        result.setMock(mock);
        result.setUserStories(stories);

        if (stories.isEmpty()) {
            result.getWarnings().add("No User Stories were found for the selected project/sprint.");
        }

        saveSnapshot(result);
        return result;
    }

    private void saveSnapshot(SprintScanResult result) {
        try {
            Path dir = Path.of("data", "snapshots");
            Files.createDirectories(dir);

            String safeProject = sanitize(result.getProject());
            String safeSprint = sanitize(result.getSprint());
            String timestamp = FILE_TS.format(result.getScannedAt());

            Path file = dir.resolve(
                    safeProject + "__" + safeSprint + "__" + timestamp + ".json");

            objectMapper.writeValue(file.toFile(), result);
        } catch (Exception e) {
            result.getWarnings().add("Snapshot could not be saved: " + e.getMessage());
        }
    }

    private void validate(String project, String sprint) {
        if (project == null || project.isBlank()) {
            throw new IllegalArgumentException("Project is required.");
        }
        if (sprint == null || sprint.isBlank()) {
            throw new IllegalArgumentException("Sprint is required.");
        }
    }

    private String sanitize(String value) {
        return value.replaceAll("[^a-zA-Z0-9._-]+", "_");
    }
}
