package com.farmers.aiassist.playwright;

import com.microsoft.playwright.*;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

/**
 * Playwright foundation for FarmersAI Assist UI testing.
 *
 * Enable after the Spring Boot application is running locally.
 */
class FarmersAiAssistPlaywrightSmokeTest {

    @Test
    @Disabled("Enable after FarmersAI Assist is running at http://localhost:8080")
    void dashboardLoads() {
        try (Playwright playwright = Playwright.create()) {
            Browser browser = playwright.chromium().launch(
                    new BrowserType.LaunchOptions().setHeadless(false));

            Page page = browser.newPage();
            page.navigate("http://localhost:8080");

            assertThat(page.getByRole(
                    AriaRole.HEADING,
                    new Page.GetByRoleOptions().setName("FarmersAI Assist")))
                    .isVisible();

            browser.close();
        }
    }
}
