# FarmersAI Assist — MVP 0.4

FarmersAI Assist is a Java-based QA intelligence layer designed to read Rally sprint data, analyze User Stories, and later propose editable Test Cases and Tasks before publishing approved items back to Rally.

## Current MVP

This first version intentionally performs **read-only Rally scanning**.

Implemented:

- Spring Boot WebApp foundation.
- Java 17.
- Microsoft Playwright Java dependency.
- Executable sprint scanner.
- Rally WSAPI client.
- Mock mode for development without Rally credentials.
- User Story snapshot model.
- JSON scan snapshots.
- Web dashboard to launch scans.
- REST endpoint to scan a sprint.
- No Rally write operations.
- No AI generation yet.
- No Copilot dependency.

## Important terminology

Rally IDs beginning with `US` are User Stories (`HierarchicalRequirement` in WSAPI). FarmersAI Assist will later support Portfolio Features separately.

## Requirements

- JDK 17+
- Maven 3.9+
- IntelliJ IDEA
- Access to Rally
- A read-only Rally API key for real scanning

## First run — MOCK MODE

The project starts in mock mode by default.

### WebApp

Run:

`FarmersAiAssistApplication.java`

or:

`mvn spring-boot:run`

Open:

`http://localhost:8080`

Enter:

- Project: `SWAT`
- Sprint: `Sprint 42.3`

and click **Scan Sprint**.

### Scanner executable

Run directly from IntelliJ:

`SprintScannerLauncher.java`

Program arguments:

`--project=SWAT --sprint="Sprint 42.3" --mock=true`

or Maven:

`mvn exec:java -Dexec.mainClass=com.farmers.aiassist.scanner.SprintScannerLauncher -Dexec.args='--project=SWAT --sprint="Sprint 42.3" --mock=true'`

## Real Rally mode

Set environment variables:

`RALLY_BASE_URL=https://rally1.rallydev.com`

`RALLY_API_KEY=<READ_ONLY_API_KEY>`

`RALLY_PROJECT=SWAT`

`RALLY_MOCK_MODE=false`

Then run:

`--project=SWAT --sprint="Sprint 42.3" --mock=false`

The API key is never stored in source code.

## Rally endpoint used

The first scanner reads Rally User Stories using WSAPI 2.0:

`/slm/webservice/v2.0/hierarchicalrequirement`

The query is scoped to:

- Iteration.Name
- Project.Name

## Local snapshots

Each scan is stored under:

`data/snapshots/`

This gives FarmersAI Assist a historical baseline for later NEW / CHANGED / UNCHANGED / REMOVED detection.

## Next planned phases

1. Validate real Rally connectivity.
2. Add schema discovery and custom fields.
3. Read Tasks linked to each US.
4. Read Test Cases linked to each US.
5. Read attachments and relationships.
6. Add delta detection between scans.
7. Add requirement/risk analysis.
8. Generate proposed Tasks.
9. Generate proposed Test Cases.
10. Add editable TC/Task UI including Expected Result images.
11. Add human approval workflow.
12. Add Rally Publisher behind explicit approval.
13. Add MCP layer for GitHub Copilot.

## Security rule

The Rally publisher does not exist in MVP 0.1. Rally is read-only by design.


## MVP 0.4 visual update

- Approved FarmersAI Assist dashboard design.
- Farmers Insurance logo included as a local static asset.
- Blue / red / white / pink palette.
- Sidebar reduced to Dashboard only.
- Hierarchical selector: Project → Sprint / Iteration → Feature → User Story.
- User Story breadcrumb is blue.
- Mock hierarchy is intentionally isolated so the next phase can replace it with Rally MCP data.
- Rally remains read-only.


## MVP 0.4

Nine WebApp screens are now scaffolded. See `docs/SCREEN-INVENTORY.md`.


## MVP 0.4

Functional demonstrative screen navigation and Dashboard discard-confirmation modal were added.
