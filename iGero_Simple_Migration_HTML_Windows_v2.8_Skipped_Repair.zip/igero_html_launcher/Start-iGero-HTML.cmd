@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
 echo Node.js was not found. Install Node.js and launch this file again.
 pause
 exit /b 1
)
start "iGero Simple Migration" /min cmd /k "node server.mjs"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8766/"
echo iGero launched. Close its server command window to stop the local service.
exit /b 0
