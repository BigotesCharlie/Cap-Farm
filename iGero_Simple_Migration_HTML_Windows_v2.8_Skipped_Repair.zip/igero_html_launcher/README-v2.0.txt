iGERO SIMPLE MIGRATION v2.0 — GLOBAL PLAYWRIGHT DISCOVERY FIX
===============================================================

WHAT WAS FIXED
--------------
The v1.8/v1.9 discovery attempted to run:
  npx playwright test <candidate.spec.ts> --list
This returns "No tests found" when the candidate exists on disk but isn't
registered in the ACTIVE Playwright testDir/testMatch/testIgnore configuration.
It also failed to recognize that one Test Case can be listed in six different
browser projects (chromium, firefox, webkit, edge, mobile-chrome, mobile-safari).

Now iGero:
  1. Queries Playwright's GLOBAL registered test inventory first, without
     filtering by Java method name or guessing the test file path.
  2. Searches in tests/, suites/ and other source-test folders (not only tests/).
  3. Maps exact Java source identity to a registered test title, file and line.
  4. Selects desktop chromium for the same test when browser projects differ.
  5. Lists candidate spec files that exist but ARE NOT registered, with clear
     SPEC_NOT_REGISTERED_BY_PLAYWRIGHT diagnostics.
  6. On a full/stage-two migration, makes ONE bounded Copilot registration
     repair attempt, then re-discovers. No infinite retries; no global config
     rewrite; no QA browser is started by the repair itself.
  7. Executes only an exact, registered test in headed Playwright, with one
     worker and zero retries, when the selected Java scenario is authorized.
  8. Distinguishes skipped tests and real browser results from successful
     source-assertion parity. A Playwright-only PASS is labelled
     PLAYWRIGHT_PASS_PARITY_UNVERIFIED and is NOT a full TC certification.

SENSITIVE SCENARIOS
-------------------
For bank, payment, Bind, purchase, email, policy-binding and signing flows,
Functional TC Check still does NOT launch the browser automatically. These
need separate explicit QA/business authorization. Do not weaken the guard to
force Chrome to launch.

INSTALL / UPGRADE
-----------------
1. Close the old Start-iGero-HTML.cmd console (stop the server).
2. Back up the current launcher directory and any modified workspace files.
3. Extract the v2.0 ZIP into a directory on the Windows machine.
4. Copy over the old launcher files (server.mjs, index.html, app.js,
   focused-test-resolver.mjs, lob-catalog.mjs and other included files).
5. Keep the old config.local.json so project roots remain configured.
6. Double-click Start-iGero-HTML.cmd and open http://127.0.0.1:8766/.
7. Hard-refresh with Ctrl+F5.
8. Select LOB -> suite -> Java method.
9. Click "Discover runnable tests". It now queries the GLOBAL Playwright
   registry; unregistered candidate files show diagnostic messages.
10. For an already registered and safe test, use "Run Functional TC Check".
    To author/repair an unregistered test, use "2 · Generate TypeScript".

CURRENT DEFAULT PROJECTS
------------------------
Java (read only instructions):
D:\Users\CARLOS.GARCIA19\Master\ffq-test-master

Playwright TS:
D:\Users\CARLOS.GARCIA19\PW-TS-MM\FFQ-Playwright-TS-master

The Java/Excel read-only policy is backed by an after-operation fingerprint
check, NOT by OS file permissions. You should separately protect the original
Java and Excel files with Windows read permissions and have a Git backup.

VALIDATION PERFORMED
--------------------
- JavaScript source syntax checks.
- 16/16 focused Node regressions.
- LOB + suite + functional mock integration.
- Global registry + 6-browser variants + skip classification integration.
- One bounded Copilot CLI registration repair (mock) integration.
- No real corporate Copilot call, no MA11 Chrome execution, no QA external side
  effects; real workstation validation is still necessary.

NOTE ABOUT 'NO TESTS FOUND'
---------------------------
A spec file existing on disk does NOT mean Playwright has registered it. The
source must be located where the project's configured testDir/testMatch can
see it. Also, --list means the test is registered, not that the test will
pass. A test may be skipped or blocked by the application or data provider.

If registration still fails, inspect the generated LIVE error and run from
the Playwright project in PowerShell:
  $env:TEST_ENV = 'MA11'
  npx playwright test --list

The command above is non-executing. Do NOT use the real browser for sensitive
Bind/payment TCs without explicit authorization.
