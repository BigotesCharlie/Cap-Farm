import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import { parsePlaywrightList, methodRelevance, chooseFocusedTest, canonicalFocusedTests } from './focused-test-resolver.mjs';
import { classifyLob, buildLobCatalog, filterMethods, SKIPPED_SUITE, sourceSkipReason } from './lob-catalog.mjs';
import { isolatePlaywrightRegistry, classifyRegistryFailure } from './registry-isolation.mjs';
import { resolvePlaywrightInvocation } from './playwright-launcher.mjs';
import { classifyFunctionalVerdict, runtimeSkipReason } from './skip-result-classifier.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const HOST = '127.0.0.1';
const PORT = Number(process.env.IGERO_PANEL_PORT || 8766);
const CONFIG_FILE = path.join(HERE, 'config.local.json');
const DEFAULT = {
  javaRoot: 'D:\\Users\\CARLOS.GARCIA19\\Master\\ffq-test-master',
  playwrightRoot: 'D:\\Users\\CARLOS.GARCIA19\\PW-TS-MM\\FFQ-Playwright-TS-master',
  autoTypecheck: true,
  autoFunctionalCheck: true,
  testEnv: 'MA11', // Select only the configured QA lane; never invent RA11 URLs.
};
// In automatic mode no artificial --max-ai-credits flag is supplied.
// Existing config.local.json files may still contain maxAiCredits from v1.2.
// Ignore that legacy value, but preserve their source/destination paths.
let config = fs.existsSync(CONFIG_FILE) ? { ...DEFAULT, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) } : { ...DEFAULT };
delete config.maxAiCredits;
let currentJob = null;
let runningProcess = null;
let activeCopilotStage = null;
let copilotStopReason = null;
const CREDIT_LIMIT_RE = /\b(?:session limit reached|ai credit(?:s)? (?:session )?limit reached|credit limit reached|future model calls (?:will )?stop|maximum ai credits reached|credit budget exceeded)\b/i;
const CONTINUE_LIMIT_RE = /\b(?:autopilot (?:continuation|continue) limit reached|max(?:imum)? autopilot continues reached)\b/i;
let dispatchPending = false;
// Discovery is scoped to one dashboard job; never cache registered tests across edits.
let registrationSnapshot = null;
let methodCache = [];
let lastMethodScan = 0;
const clients = new Set();
const MAX_LOGS = 1500;
const STATUSES = ['pending','running','pass','blocked','skipped'];
const STEP_NAMES = ['Locate Java method', 'Copilot: generate JSON + prompt.md', 'Validate generated contract', 'Discover and map registered Playwright test', 'Validate TypeScript', 'Functional TC Check — Playwright', 'Save results'];
function sendEvent(event, data) {
  for (const res of clients) { try { res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); } catch { clients.delete(res); } }
}
function jobPublic() {
  if (!currentJob) return null;
  const {id, methodId, status, startedAt, endedAt, steps, logs, artifacts, error, aiCreditsObserved, functional} = currentJob;
  return {id, methodId, status, startedAt, endedAt, steps, logs: logs.slice(-200), artifacts, error, aiCreditMode:'automatic', aiCreditsObserved, functional};
}
function log(message, kind='log') {
  if (!currentJob) return;
  // CLI usage information is informational, not an authoritative billing total.
  // It may be absent depending on CLI version and log format.
  if (activeCopilotStage && currentJob) {
    const raw = String(message);
    const usage = raw.match(/\bAI Credits?\s+([0-9]+(?:\.[0-9]+)?)(?=\s|$|\()/i)
      || raw.match(/\b([0-9]+(?:\.[0-9]+)?)\s*\/\s*[0-9]+(?:\.[0-9]+)?\s+AI Credits? used\b/i);
    if (usage) {
      const number = Number(usage[1]);
      if (Number.isFinite(number) && number >= 0)
        currentJob.aiCreditsObserved[activeCopilotStage] = Math.max(currentJob.aiCreditsObserved[activeCopilotStage] || 0, number);
    }
    if (CREDIT_LIMIT_RE.test(raw)) copilotStopReason = 'Copilot reached a CLI or organization AI-credit limit';
    if (CONTINUE_LIMIT_RE.test(raw)) copilotStopReason = 'Copilot reached the automatic-continuation limit';
  }
  const line = { t: new Date().toLocaleTimeString(), text: String(message).slice(0, 1200), kind };
  currentJob.logs.push(line);
  if (currentJob.logs.length > MAX_LOGS) currentJob.logs.shift();
  sendEvent('log', line);
}
function step(index, status, note='') {
  if (!currentJob) return;
  currentJob.steps[index] = {name: STEP_NAMES[index], status, note};
  sendEvent('status', jobPublic());
}
function json(res, status, value) {
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  res.end(JSON.stringify(value));
}
function safeText(s){ return String(s||'').replace(/\x1b\[[0-9;]*m/g,'').replace(/\r/g,''); }
function validRoot(p) {try { return fs.statSync(p).isDirectory(); } catch { return false; }}
function rootChecks() {
  const j=validRoot(config.javaRoot), p=validRoot(config.playwrightRoot);
  return { javaExists:j, targetExists:p, javaRoot:config.javaRoot, playwrightRoot:config.playwrightRoot, ready:j&&p};
}
// Non-invasive readiness checks: no login, no AI request and no browser is launched.
async function probeCommand(command, args=[], cwd=HERE, timeoutMs=6000) {
  return await new Promise(resolve=>{
    let output='';let done=false;let child;
    const finish=(ok, note='')=>{if(done)return;done=true;clearTimeout(timer);resolve({ok,detail:safeText(output).trim().slice(0,240)||note});};
    const timer=setTimeout(()=>{try{child?.kill()}catch{}finish(false,'Version check timed out')},timeoutMs);
    try {
      child=spawn(command,args,{cwd,windowsHide:true,env:{...process.env,NO_COLOR:'1'}});
      const add=b=>{output+=b.toString();if(output.length>2000)output=output.slice(-2000)};
      child.stdout.on('data',add);child.stderr.on('data',add);
      child.once('error',e=>finish(false,e.code==='ENOENT'?'Command not found':e.message));
      child.once('close',code=>finish(code===0,code===0?'Version available':`Exit code ${code}`));
    } catch(e){finish(false,e.message)}
  });
}
async function systemReadiness() {
  const roots=rootChecks();
  const major=Number((process.version.match(/^v(\d+)/)||[])[1]||0);
  const node={status:major>=22?'PASS':'FAIL',value:process.version,
    detail:major>=22?'Node.js is running this local dashboard.':'Node.js 22 or newer is required by this launcher.'};
  const copilotProbe=process.platform==='win32'
    ? await probeCommand('powershell.exe',['-NoProfile','-NonInteractive','-Command','& copilot --version'],HERE)
    : await probeCommand('copilot',['--version'],HERE);
  const copilot={status:copilotProbe.ok?'PASS':'FAIL',value:copilotProbe.ok?copilotProbe.detail:'Unavailable',
    detail:copilotProbe.ok?'Copilot CLI is callable from the same server environment. Authentication is verified only when a real prompt runs.':
      'Copilot CLI was not found or cannot start. Run copilot --version and, if necessary, copilot login in PowerShell.'};
  const java={status:roots.javaExists?'PASS':'FAIL',value:roots.javaRoot,detail:roots.javaExists?'Source folder accessible (read-only policy).':'Java source folder unavailable.'};
  const target={status:roots.targetExists?'PASS':'FAIL',value:roots.playwrightRoot,detail:roots.targetExists?'Playwright target folder accessible.':'Playwright target folder unavailable.'};
  let packageFound=false;let executableFound=false;
  if(roots.targetExists){
    const nm=path.join(roots.playwrightRoot,'node_modules');
    packageFound=fs.existsSync(path.join(nm,'@playwright','test','package.json'));
    executableFound=fs.existsSync(path.join(nm,'.bin',process.platform==='win32'?'playwright.cmd':'playwright'));
  }
  const playwright={status:packageFound&&executableFound?'PASS':'FAIL',value:packageFound?'@playwright/test detected':'Not installed',
    detail:packageFound&&executableFound?'Project-local Playwright CLI and test package are present. Actual browser and config are checked during Functional TC Check.':
      'Missing project-local @playwright/test or Playwright binary. Check npm install in the target project.'};
  const authentication={status:'INFO',value:'NOT VERIFIED',detail:'A CLI version check cannot verify GitHub login or corporate entitlement. If Copilot prompts fail, use copilot login or verify organization access.'};
  const checks={node,copilot,java,target,playwright,authentication};
  return {checkedAt:new Date().toISOString(),checks,
    migrationReady:[node,copilot,java,target,playwright].every(v=>v.status==='PASS'),
    functionalReady:[node,java,target,playwright].every(v=>v.status==='PASS'),
    note:'Non-invasive preflight: no AI credits consumed, no browser launched, no authentication token exposed.'};
}
async function walk(root, limit=4000) {
  const result=[]; const stack=[root];
  while(stack.length && result.length < limit){
    const dir=stack.pop();
    let entries=[]; try{entries=await fsp.readdir(dir,{withFileTypes:true});}catch{continue;}
    for(const e of entries){
      if(e.name.startsWith('.') || ['build','target','node_modules','out','gradle'].includes(e.name))continue;
      const file=path.join(dir,e.name);
      if(e.isDirectory())stack.push(file);else if(e.isFile() && e.name.endsWith('.java'))result.push(file);
    }
  }
  return result;
}
async function collectMethods(){
  const javaDir = path.join(config.javaRoot, 'src','test','java');
  if(!validRoot(javaDir))return [];
  const files=await walk(javaDir);
  const found=[];
  for(const file of files){
    let txt;try{txt=await fsp.readFile(file,'utf8')}catch{continue;}
    const className = (txt.match(/\bclass\s+(\w+)/)||[])[1] || path.basename(file,'.java');
    // Associate each @Test annotation with the next method declaration, not every helper.
    const re=/@Test\b/g; let match;
    while((match=re.exec(txt))!==null){
      const before=txt.slice(Math.max(0, match.index-25),match.index);
      if(/\/\/[^\n]*$/.test(before))continue;
      const rest=txt.slice(match.index,match.index+1300);
      const method=rest.match(/(?:public|protected)\s+(?:(?:static|final|synchronized)\s+)*[\w<>\[\], ?]+?\s+(\w+)\s*\([^)]*\)\s*(?:throws\s+[\w, ]+)?\s*\{/);
      if(!method)continue;
      const name=method[1]; if(['if','for','while'].includes(name))continue;
      const id=`${className}#${name}`;
      const relativePath=path.relative(config.javaRoot,file).replace(/\\/g,'/');
      if(found.some(x=>x.id===id && x.relativePath===relativePath))continue;
      const lob=classifyLob(relativePath);
      // Source-of-truth is Java: do not reclassify runtime skip branches as disabled.
      // Include annotations directly adjacent to this method, never unrelated test bodies.
      const methodStart=match.index + (rest.indexOf(method[0]));
      const previousBoundary=Math.max(txt.lastIndexOf('}',match.index),txt.lastIndexOf(';',match.index));
      const annotationHeader=txt.slice(Math.max(previousBoundary+1,match.index-160),methodStart);
      const skipReason=sourceSkipReason(annotationHeader);
      found.push({ id, className, name, relativePath, file, lob:lob.id, lobLabel:lob.label, suite:relativePath, skipped:Boolean(skipReason), skipReason });
    }
  }
  return found.sort((a,b)=>a.id.localeCompare(b.id));
}
async function findMethod(id) {
  if(!/^[A-Za-z_$][\w$]*#[A-Za-z_$][\w$]*$/.test(id))throw new Error('Use JavaClass#methodName');
  if(Date.now()-lastMethodScan>120000 || !methodCache.length){ methodCache=await collectMethods();lastMethodScan=Date.now(); }
  let selected=methodCache.find(x=>x.id===id);
  if(!selected){methodCache=await collectMethods();lastMethodScan=Date.now();selected=methodCache.find(x=>x.id===id);}
  if(!selected)throw new Error(`Java @Test method ${id} was not found in the selected source project.`);
  return selected;
}
function artifactPaths(selected){
  const dir=path.join(config.playwrightRoot,'migration','pervez-json',`${selected.className}__${selected.name}`);
  return {dir,json:path.join(dir,'contract.json'),prompt:path.join(dir,'prompt.md'),runLog:path.join(dir,'copilot-run.log'),specManifest:path.join(dir,'spec-manifest.json'),functionalReport:path.join(dir,'functional-report.json'),functionalSummary:path.join(dir,'functional-summary.json')};
}
function promptForExtraction(sel,a){
return `TASK: Export the COMPLETE REAL Java Selenium/TestNG test source contract into exactly TWO files.\nJava repository (READ-ONLY): ${config.javaRoot}\nJava class: ${sel.className}\nExact @Test method: ${sel.name}\nJava source file: ${sel.file}\nOutput JSON: ${a.json}\nOutput method prompt: ${a.prompt}\n\nRead the actual Java test and follow the required helper, inherited method, Page Object, DataProvider and assertion call graphs. Preserve conditional branches, input provenance, class/method names, navigation and functional acceptance boundaries. Record unresolved dependencies explicitly instead of guessing. The JSON MUST be valid JSON and have top-level keys className, methodName, sourcePath, dataProvider, steps, assertions, unresolved; the arrays steps, assertions and unresolved must be arrays. For each reference record actual Java source location. The prompt.md should be short and instruct the subsequent agent to mirror the whole Java behavior using this contract and the original source.\nDO NOT modify ANY file under ${config.javaRoot}; do not modify original Excel. Do NOT create TypeScript during this step. Do not execute Java, Playwright, QA websites, email, bank, payment, or binding actions. Write only into ${a.dir} for this operation, with two named deliverables. End by listing those two paths, true source coverage and unresolved items. Do not claim functional PASS.\n`;
}
function promptForMigration(sel,a){
return `TASK: Implement ONE COMPLETE Selenium Java TestNG method in the EXISTING Playwright TypeScript project.\nLine of Business: ${sel.lobLabel}\nJava source suite: ${sel.className} (${sel.relativePath})\nJava source (READ-ONLY): ${config.javaRoot}\nSource method: ${sel.className}#${sel.name}\nSource Java disabled: ${sel.skipped?'YES — '+sel.skipReason:'NO (statically recognized)'}\nSource file: ${sel.file}\nSource-derived JSON: ${a.json}\nSource-derived prompt: ${a.prompt}\nTarget project root: ${config.playwrightRoot}\n\nRead BOTH generated files completely, inspect original Java source when necessary. Use the method-specific prompt and JSON to faithfully mirror the complete Selenium behavior: fixture, DataProvider, source-eligible state, source Excel workbook/worksheet and filters, conditional branches, Page Objects, helpers, all required assertions, and final acceptance boundary. Use the EXISTING ${sel.lobLabel} Playwright project layout and its fixtures, providers and Page Objects; locate actual target directories, do not force all LOBs into tests/acehome. Original Java and Excel MUST remain read-only. No Faker or hardcoded applicant identities. Do not force TX; TX fallback is only allowed when source permits it. Do not change global configuration, J03, or iGero infrastructure unless a confirmed defect prevents this test.\nCreate or complete the actual dedicated .spec.ts (not just helpers). Carry out source-contract comparison and scoped offline validation. Do not execute external QA Chrome test, email, purchase, payment, banking or policy binding in this step. Do not modify unrelated suites, commit, push, or start the queue. Before finishing, use the project's actual Playwright configuration to place the spec inside the ACTIVE testDir/testMatch; verify its registration with npx playwright test --list (TEST_ENV=MA11 unless source specifies otherwise), without executing the browser. Include the exact original Java method name in the Playwright test title. If Java explicitly disables this method, preserve test.skip and place it in SKIPPED SCENARIOS; if the test is intentionally skipped due to unsupported state, report it truthfully; do not remove source exclusions to force a PASS. Keep user-facing test titles and diagnostics in English. Report the final spec path, source assertion mapping, real implementation status and unresolved issues. Never claim FUNCTIONAL_PASS without real runtime execution.\n`;
}
async function writePromptFile(a, name, prompt) {
  await fsp.mkdir(a.dir,{recursive:true}); const p=path.join(a.dir,name);await fsp.writeFile(p,prompt,'utf8');return p;
}
function spawnAndLog(command,args,opts, capture=null, quiet=false) {
  return new Promise((resolve,reject)=>{
    const child=spawn(command,args,{...opts, windowsHide:true,env:{...process.env,...(opts.env||{}),NO_COLOR:'1'}});
    runningProcess=child;
    let buffer='';
    const collect=(data)=>{buffer+=safeText(data.toString()); let lines=buffer.split('\n');buffer=lines.pop();for(const line of lines){if(line.trim()){if(capture)capture.push(line);if(!quiet)log(line);}}};
    child.stdout?.on('data',collect);child.stderr?.on('data',collect);
    child.once('error',e=>{runningProcess=null;reject(e)});
    child.once('close',code=>{if(buffer.trim()){if(capture)capture.push(buffer);if(!quiet)log(buffer);}runningProcess=null;resolve(code);});
  });
}
async function invokeCopilot(promptFile, stage){
  // The selected roots are passed to the wrapper; no manual credit cap is supplied.
  const script=path.join(HERE,'invoke-copilot.ps1');
  const args=['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',script,'-PromptFile',promptFile,'-TargetRoot',config.playwrightRoot,'-SourceRoot',config.javaRoot];
  const cmd=process.platform==='win32'?'powershell.exe':'pwsh';
  activeCopilotStage = stage;
  copilotStopReason = null;
  try {
    const code = await spawnAndLog(cmd,args,{cwd:config.playwrightRoot});
    return {code, stopReason:copilotStopReason};
  } finally {
    activeCopilotStage = null;
    copilotStopReason = null;
  }
}
async function runTypecheck() {
  const cmd=process.platform==='win32'?'cmd.exe':'npm';
  const args=process.platform==='win32'?['/d','/s','/c','npx --no-install tsc --noEmit']:['exec','--','tsc','--noEmit'];
  return spawnAndLog(cmd,args,{cwd:config.playwrightRoot,env:{TEST_ENV:config.testEnv}});
}
async function fingerprintTree(dir){
  const files=[]; const stack=[dir];
  while(stack.length && files.length<10000){
    const d=stack.pop(); let ents=[];
    try{ents=await fsp.readdir(d,{withFileTypes:true});}catch{continue;}
    for(const e of ents){
      if(['.git','.gradle','.idea','build','target','node_modules','out'].includes(e.name))continue;
      const fp=path.join(d,e.name);
      if(e.isDirectory())stack.push(fp);
      else if(e.isFile() && /\.(java|xlsx|xls)$/i.test(e.name))files.push(fp);
    }
  }
  const dig=crypto.createHash('sha256');
  for(const f of files.sort()){
    const content=await fsp.readFile(f).catch(()=>null);
    if(content){dig.update(f);dig.update(content);}
  }
  return dig.digest('hex');
}
async function listSpecVersions(target){
  // Different LOBs use tests/, suites/, and occasionally src/ test folders.
  // Do not assume all Playwright TCs are under tests/acehome.
  const out={}; const stack=[{dir:target,depth:0}];
  let visited=0;
  while(stack.length && visited<16000){
    const {dir,depth}=stack.pop(); visited++;
    let ent=[];try{ent=await fsp.readdir(dir,{withFileTypes:true});}catch{continue;}
    for(const e of ent){
      if(['.git','node_modules','.idea','.next','dist','build','target','out','playwright-report','test-results','migration','.cache'].includes(e.name))continue;
      const f=path.join(dir,e.name);
      if(e.isDirectory() && depth<9)stack.push({dir:f,depth:depth+1});
      else if(e.isFile() && /\.(?:spec|test)\.[cm]?[jt]sx?$/.test(e.name)){
        const st=await fsp.stat(f);out[f]=`${st.size}:${st.mtimeMs}`;
      }
    }
  }
  return out;
}
function sanitizeReportText(value) {
  // Only sanitized summaries are exposed through the HTTP API; raw reporter JSON stays local.
  return String(value||'').replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi,'[REDACTED_EMAIL]')
    .replace(/\b\d{9,19}\b/g,'[REDACTED_NUMBER]').replace(/(https?:\/\/[^\s?]+)\?[^\s]+/gi,'$1?[REDACTED]')
    .replace(/\b(?:password|ssn|socialSecurityNumber|cardNumber|routingNumber|accountNumber)\s*[:=]\s*[^\s,;]+/gi,'[REDACTED_FIELD]')
    .slice(0,1400);
}
// Safety review uses the SELECTED executable method, not arbitrary Excel column names,
// shared imports, or the entire JSON contract. A filename/data provider may contain
// "bank" even when this Test Case never performs a bank operation.
function selectedJavaMethod(source, methodName) {
  const re=new RegExp('\\b(?:public|private|protected)\\s+(?:(?:static|final|synchronized)\\s+)*[\\w<>\\[\\], ?]+?\\s+'+methodName+'\\s*\\([^)]*\\)\\s*(?:throws\\s+[\\w, ]+)?\\s*\\{','g');
  const m=re.exec(source);if(!m)return null;
  let depth=1,i=re.lastIndex,quote='',escaped=false,lineComment=false,blockComment=false;
  for(;i<source.length;i++){
    const c=source[i],n=source[i+1];
    if(lineComment){if(c==='\n')lineComment=false;continue;}
    if(blockComment){if(c==='*'&&n==='/'){blockComment=false;i++}continue;}
    if(quote){if(escaped){escaped=false;continue}if(c==='\\'){escaped=true;continue}if(c===quote)quote='';continue;}
    if(c==='/'&&n==='/'){lineComment=true;i++;continue;}
    if(c==='/'&&n==='*'){blockComment=true;i++;continue;}
    if(c==='"'||c==="'"){quote=c;continue;}
    if(c==='{')depth++;else if(c==='}'&&--depth===0)return source.slice(re.lastIndex,i);
  }
  return null;
}
function isSensitiveActionCode(text){
  const stripped=String(text).replace(/\/\/[^\n]*|\/\*[\s\S]*?\*\/|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g,' ');
  // Match executable identifiers, not words in unrelated descriptions or source data.
  return /\b(?:[\w$]*(?:quoteAndBind|policyBind|bindPolicy|completePurchase|payment|bankAccount|bankPayment|makePayment|purchasePolicy|sendEmail|sendMail|sendMessage|signDocuments|startSigning)[\w$]*)\s*\(/i.test(stripped)
      || /\bnew\s+[\w$]*(?:BankPayment|PaymentPage|PolicyBind|BankAccount)[\w$]*\s*\(/i.test(stripped);
}
async function scenarioSafety(sel,contract){
  const label=`${sel.className}#${sel.name}`;
  if(/(?:quoteAndBind|goToPayment|payment|bankAccount|bankPayment|policyBind|completePurchase|purchasePolicy|sendEmail|sendMail|startSigning)/i.test(label))
    return {sensitive:true,reason:'The selected Java test name explicitly targets a sensitive operation.'};
  const source=await fsp.readFile(sel.file,'utf8').catch(()=>null);
  const body=source&&selectedJavaMethod(source,sel.name);
  if(body===null)return {sensitive:true,reason:'Could not safely isolate the source Java test body. Manual review is required before real execution.'};
  if(isSensitiveActionCode(body))return {sensitive:true,reason:'The selected Java test body invokes a bank, payment, binding, purchase, signing or email operation.'};
  // Structured step *actions* only; ignore DataProvider fields, test metadata and generic descriptions.
  for(const step of contract?.steps||[]){
    if(!step||typeof step!=='object')continue;
    const operation=[step.action,step.operation,step.methodCall,step.invocation].filter(x=>typeof x==='string').join(' ');
    if(/\b(?:submit\s+(?:payment|bank|purchase)|(?:complete|confirm|perform|execute|click|enter|send|bind|sign|purchase|pay)\s+(?:\w+\s+){0,3}(?:payment|bank(?:ing)?|bind|policy|purchase|email|signing))\b/i.test(operation))
      return {sensitive:true,reason:'A source-contract executable action requires separate business execution approval.'};
  }
  return {sensitive:false,reason:'No explicit sensitive operation found in the selected Java test body or structured executable actions. This is a static safety precheck, not permission to ignore corporate QA policy.'};
}
function withinTarget(file) {
  const root=path.resolve(config.playwrightRoot);const resolved=path.resolve(file);
  return resolved.startsWith(root+path.sep) && resolved.endsWith('.spec.ts') && !resolved.includes(`${path.sep}node_modules${path.sep}`);
}
// Try the active project configuration first, then discovered Playwright configs.
// Some FFQ workspaces contain a separate config under a product/suite folder.
// These are read-only --list checks, never browser launches or configuration edits.
async function listPlaywrightConfigs(root) {
  const result=[];const seen=new Set();const queue=[{dir:root,depth:0}];
  while(queue.length && result.length<12){
    const {dir,depth}=queue.shift();let items=[];
    try{items=await fsp.readdir(dir,{withFileTypes:true});}catch{continue;}
    for(const item of items){
      if(item.isFile() && /^playwright\.config\.(?:ts|mts|cts|js|mjs|cjs)$/i.test(item.name)){
        const full=path.join(dir,item.name);if(!seen.has(full)){result.push(full);seen.add(full);}
      } else if(item.isDirectory() && depth<3 && !['node_modules','.git','migration','test-results','playwright-report','target','dist','build','coverage','.next','.idea'].includes(item.name)){
        queue.push({dir:path.join(dir,item.name),depth:depth+1});
      }
    }
  }
  return result.sort((a,b)=>{
    const da=path.relative(root,a).split(path.sep).length,db=path.relative(root,b).split(path.sep).length;
    return da-db||a.localeCompare(b);
  });
}
function isSkippedDeclaration(fileContents, line){
  if(!fileContents||!line)return false;
  const lines=fileContents.split(/\r?\n/);const snippet=lines.slice(Math.max(0,line-2),Math.min(lines.length,line+2)).join(' ');
  return /\b(?:test|it)\.skip\s*\(|\btest\.describe\.skip\s*\(/.test(snippet);
}
async function describePlaywrightSources(method){
  const inventory=await listSpecVersions(config.playwrightRoot);
  const specs=Object.keys(inventory);const sample=[];
  for(const file of specs){
    const rel=path.relative(config.playwrightRoot,file).replace(/\\/g,'/');
    if(!rel.toLowerCase().includes(method.className.toLowerCase())){
      const txt=await fsp.readFile(file,'utf8').catch(()=>'');
      if(!txt.includes(method.name))continue;
      sample.push({file:rel,skipDeclared:/\btest\.skip\s*\(|\btest\.describe\.skip\s*\(/.test(txt)});
    }else{
      const txt=await fsp.readFile(file,'utf8').catch(()=>'');
      sample.push({file:rel,skipDeclared:/\btest\.skip\s*\(|\btest\.describe\.skip\s*\(/.test(txt)});
    }
    if(sample.length>=8)break;
  }
  // Specs under the migration artifact directory are not active Playwright tests,
  // but show them here when determining why no tests are discovered.
  const artifacts=artifactPaths(method);
  const names=await fsp.readdir(artifacts.dir).catch(()=>[]);
  for(const name of names.filter(n=>/\.(?:spec|test)\.[cm]?[jt]sx?$/.test(n)).slice(0,5)){
    const file=path.join(artifacts.dir,name);
    const text=await fsp.readFile(file,'utf8').catch(()=>'');
    sample.push({file:path.relative(config.playwrightRoot,file).replace(/\\/g,'/'),
      skipDeclared:/\btest\.skip\s*\(/.test(text),artifactOnly:true});
  }
  return {specCount:specs.length,relatedSpecs:sample};
}
async function configFileHints(configs,root){
  const hints=[];
  for(const file of configs.slice(0,8)){
    const code=await fsp.readFile(file,'utf8').catch(()=>'');
    // Human-readable hints only; never execute or rewrite a config file.
    const take=key=>{
      const found=code.match(new RegExp('\\b'+key+'\\s*:\\s*([^,\\n]+)','m'));
      return found?found[1].trim().slice(0,150):null;
    };
    hints.push({config:path.relative(root,file).replace(/\\/g,'/'),
      testDir:take('testDir'),testMatch:take('testMatch'),testIgnore:take('testIgnore'),
      dynamicEnvironment:/\b(?:TEST_ENV|process\.env)\b/.test(code)});
  }
  return hints;
}
function tailForDiscovery(output){return String(output||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean).slice(-7).map(x=>x.slice(0,250));}
async function queryPlaywrightRegistry(method) {
  const configs=await listPlaywrightConfigs(config.playwrightRoot);
  const attempts=[];
  const candidates=[{label:'default (cwd project root)',configFile:null},
    ...configs.slice(0,6).map(c=>({label:path.relative(config.playwrightRoot,c).replace(/\\/g,'/'),configFile:c}))];
  for(const candidate of candidates){
    const captured=[];
    const args=['--list',...(candidate.configFile?['--config',candidate.configFile]:[])];
    log(`Playwright --list using ${candidate.label}; TEST_ENV=${config.testEnv}`);
    const cmd=playwrightCommand(args);
    const exitCode=await spawnAndLog(cmd.cmd,cmd.args,{cwd:config.playwrightRoot,env:{TEST_ENV:config.testEnv}},captured,true);
    const output=captured.join('\n');const entries=parsePlaywrightList(output);
    attempts.push({config:candidate.label,exitCode,registered:entries.length,runner:cmd.origin,runnerExecutable:cmd.executable,outputTail:tailForDiscovery(output)});
    if(exitCode===0 && entries.length){
      return {entries,configFile:candidate.configFile,diagnostics:{status:'REGISTERED',activeConfig:candidate.label,
        cwd:config.playwrightRoot,environment:config.testEnv,attempts,configFiles:configs.map(x=>path.relative(config.playwrightRoot,x).replace(/\\/g,'/')),configHints:await configFileHints(configs,config.playwrightRoot)}};
    }
  }
  // First distinguish a broken runner from a healthy runner with an excluding project config.
  // This probe ONLY uses --list, never launches browsers, and cleans up its files.
  const runnerIsolation=await isolatePlaywrightRegistry({projectRoot:config.playwrightRoot,invoke:async tempConfig=>{
    const captured=[];
    const cmd=playwrightCommand(['--list','--config',tempConfig]);
    const exitCode=await spawnAndLog(cmd.cmd,cmd.args,{cwd:config.playwrightRoot,env:{TEST_ENV:config.testEnv}},captured,true);
    return {exitCode,output:captured.join('\n')};
  }});
  const sources=await describePlaywrightSources(method);
  const registryDiagnosis=classifyRegistryFailure({baselineTotal:0,isolatedRegistered:runnerIsolation.status==='PASS'?1:0,sourceCount:sources.specCount});
  log(`Playwright isolated runner: ${runnerIsolation.status}; ${registryDiagnosis.code}; ${runnerIsolation.outputTail.slice(0,450)}`,runnerIsolation.status==='PASS'?'success':'warning');
  return {entries:[],configFile:null,diagnostics:{status:'NO_REGISTERED_TESTS',activeConfig:null,runnerIsolation,registryDiagnosis,
    cwd:config.playwrightRoot,environment:config.testEnv,attempts,configFiles:configs.map(x=>path.relative(config.playwrightRoot,x).replace(/\\/g,'/')),configHints:await configFileHints(configs,config.playwrightRoot),...sources,
    nextAction:'Before spending more Copilot credits: repair Playwright test discovery using the dedicated Repair Playwright Registry action. Review the isolated runner probe, effective testDir/testMatch/testIgnore and active config. Preserve test.skip and original Java/Excel. No Chrome until a real runnable TC is registered.'}};
}
async function persistDiscoveryDiagnostic(sel,a,report){
  if(a){await fsp.mkdir(a.dir,{recursive:true});await fsp.writeFile(path.join(a.dir,'discovery-diagnostics.json'),JSON.stringify(report,null,2),'utf8');}
  log(`Playwright discovery status: ${report.status}; config=${report.activeConfig||'none'}; ${report.attempts?.map(x=>x.config+': '+x.registered+' (exit '+x.exitCode+')').join('; ')}`,
    report.status==='REGISTERED'?'success':'warning');
}
// Playwright is the authority for runnable titles. A Selenium method name is
// NOT automatically the Playwright title; never grep using the Java name.
function playwrightCommand(args) {
  return resolvePlaywrightInvocation(config.playwrightRoot,args);
}
function normalizeRegistryFile(listingFile, versionMap, configFile=null) {
  const rel=String(listingFile||'').replace(/\\/g,'/').replace(/^\.\//,'');
  const absolute=path.resolve(config.playwrightRoot,rel);
  if(versionMap[absolute])return absolute;
  if(configFile){const fromConfig=path.resolve(path.dirname(configFile),rel);if(versionMap[fromConfig])return fromConfig;}
  // Some Playwright configs report paths relative to testDir rather than cwd.
  const matches=Object.keys(versionMap).filter(file=> {
    const r=path.relative(config.playwrightRoot,file).replace(/\\/g,'/');
    return r===rel || r.endsWith('/'+rel);
  });
  return matches.length===1?matches[0]:null;
}
async function discoverFocusedSpecs(sel) {
  // Authority: globally registered tests from Playwright itself. Never assume a
  // source file is runnable just because it exists or contains the Java name.
  const versionMap=await listSpecVersions(config.playwrightRoot);
  const inspected=await queryPlaywrightRegistry(sel);
  const listed=inspected.entries;
  const a=artifactPaths(sel);
  await persistDiscoveryDiagnostic(sel,a,inspected.diagnostics);
  registrationSnapshot={listedCount:listed.length,configFile:inspected.configFile,
    diagnostics:inspected.diagnostics};
  if(!listed.length){
    const related=inspected.diagnostics.relatedSpecs||[];
    const skip=related.filter(x=>x.skipDeclared);
    const clue=skip.length?` Related spec(s) contain test.skip: ${skip.map(x=>x.file).join(', ')}; a skipped test cannot receive Functional PASS.`:'';
    throw new Error(`PLAYWRIGHT_PROJECT_NO_TESTS: zero tests registered across ${inspected.diagnostics.attempts.length} checked configuration(s); TEST_ENV=${config.testEnv}. See ${path.relative(config.playwrightRoot,a.dir).replace(/\\/g,'/')}/discovery-diagnostics.json. ${inspected.diagnostics.specCount||0} candidate spec file(s) found on disk.${clue}`);
  }
  const relevant=[];
  const resolvedPathCache=new Map();
  const locateRegisteredFile=(listingFile)=>{
    if(!resolvedPathCache.has(listingFile))resolvedPathCache.set(listingFile,normalizeRegistryFile(listingFile,versionMap,inspected.configFile));
    return resolvedPathCache.get(listingFile);
  };
  // Inspect only source files actually registered by Playwright, plus a small
  // number of plausible unregistered files to explain config exclusions.
  const cache=new Map();
  for(const test of listed){
    const file=locateRegisteredFile(test.listingFile);
    if(!file || !withinTarget(file))continue;
    if(!cache.has(file))cache.set(file,await fsp.readFile(file,'utf8').catch(()=>''));
    const relative=path.relative(config.playwrightRoot,file).replace(/\\/g,'/');
    const text=cache.get(file);
    const mentions=text.includes(sel.name) || text.includes(sel.className+'#'+sel.name);
    const relevance=methodRelevance(sel,relative,test.title,mentions);
    if(relevance.eligible || mentions){
      relevant.push({specPath:file,relativePath:relative,sourceMentionsMethod:mentions,
        project:test.project,line:test.line,column:test.column,title:test.title,
        runnable:true,eligible:relevance.eligible,score:relevance.score,
        evidence:relevance.evidence,exitCode:0,configFile:inspected.configFile,skipDeclared:isSkippedDeclaration(text,test.line)});
    }
  }
  const unique=[];
  const seen=new Set();
  for(const x of relevant){
    const key=[x.specPath,x.project,x.line,x.title].join('|');
    if(!seen.has(key)){seen.add(key);unique.push(x);}
  }
  const unregistered=[];
  const registeredFiles=new Set(listed.map(t=>locateRegisteredFile(t.listingFile)).filter(Boolean));
  for(const [file] of Object.entries(versionMap)){
    if(registeredFiles.has(file))continue;
    const relative=path.relative(config.playwrightRoot,file).replace(/\\/g,'/');
    const byName=relative.toLowerCase().includes(sel.className.toLowerCase());
    if(!byName && unregistered.length>=30)continue;
    const text=await fsp.readFile(file,'utf8').catch(()=>'');
    if((byName || text.includes(sel.name)) && unregistered.length<40){
      unregistered.push({specPath:file,relativePath:relative,project:'',line:0,column:0,title:'',
        runnable:false,eligible:false,score:0,evidence:[],
        diagnostic:'Source file exists but Playwright does not register it. Check testDir, testMatch, testIgnore and configuration-specific projects. test.skip is a separate runtime skip condition.',skipDeclared:/\btest\.skip\s*\(/.test(text)});
    }
  }
  registrationSnapshot={...registrationSnapshot,unregistered:unregistered.map(e=>e.relativePath)};
  if(!unique.some(e=>e.eligible)){
    const preview=unregistered.slice(0,6).map(x=>x.relativePath).join(', ');
    log(preview?`Found unregistered candidate spec file(s): ${preview}`:'No confident Java-to-Playwright test mapping in the registered suite.','warning');
  }
  return [...unique,...unregistered];
}
async function repairProjectRegistry(sel) {
  const a=artifactPaths(sel);
  const baseline=await queryPlaywrightRegistry(sel);
  await persistDiscoveryDiagnostic(sel,a,baseline.diagnostics);
  if(baseline.entries.length)return {ok:true,alreadyHealthy:true,registered:baseline.entries.length,diagnostics:baseline.diagnostics};
  if(baseline.diagnostics.runnerIsolation?.status!=='PASS') {
    throw new Error('RUNNER_NOT_READY: Playwright failed even in a temporary isolation probe. No Copilot repair was started. Check Node/Playwright package resolution and the probe output.');
  }
  const instructions=`Fix the existing Playwright test discovery, not the Java migration.\n`+
    `Playwright project: ${config.playwrightRoot}\nSelected Java method: ${sel.id}\n`+
    `Before spending more effort, read these existing diagnostics: ${path.join(a.dir,'discovery-diagnostics.json')}\n`+
    `CLI: TEST_ENV=${config.testEnv} npx playwright test --list returned NO TESTS FOUND in every discovered configuration while a temporary isolated Playwright --list probe registered one test.\n`+
    `Inspect the real project layout and effective configuration; resolve the ACTUAL mismatch in testDir, testMatch, testIgnore, project filters, cwd or config selection. Check git diff/history for recent config changes; restore only a proven erroneous configuration change and preserve unrelated modifications. `+
    `There are source .spec.ts files on disk. Fix the smallest proven defect, not by rewriting the framework or inventing additional tests. `+
    `Check whether tests live in a nested FFQ-Playwright-TS/ directory, which changes config-relative testDir. `+
    `Preserve existing fixtures, tests, assertions, source state exclusions and legitimate test.skip. Do not fake a test registration or add expect(true). `+
    `Do not modify the Java source or Excel, do not launch the QA browser, do not run Bind/payment/purchase/email, do not install software, commit, or push. `+
    `After repair run TEST_ENV=${config.testEnv} npx playwright test --list with the appropriate real configuration and report test count and exact executable spec. `+
    `If the real project intentionally registers zero tests, do not fabricate success; explain why and leave it blocked.\n`;
  const prompt=await writePromptFile(a,'00-repair-playwright-registry.txt',instructions);
  const sourceBefore=await fingerprintTree(config.javaRoot);
  const result=await invokeCopilot(prompt,'migrate');
  if(result.stopReason||result.code!==0)throw new Error(`Playwright registry repair did not complete: ${result.stopReason||'Copilot exit '+result.code}`);
  if(await fingerprintTree(config.javaRoot)!==sourceBefore)throw new Error('ALERT: Java/Excel changed during registry repair. Do not proceed.');
  const after=await queryPlaywrightRegistry(sel);
  await persistDiscoveryDiagnostic(sel,a,after.diagnostics);
  if(!after.entries.length)throw new Error('PLAYWRIGHT_REGISTRY_STILL_EMPTY: Copilot repair finished but the real config still registers 0 tests. Inspect discovery-diagnostics.json; no Chrome was launched.');
  return {ok:true,registered:after.entries.length,diagnostics:after.diagnostics};
}
async function attemptRegistrationRepair(sel,a,originalFailure) {
  // One bounded project-local Copilot repair; no QA browser or external business
  // action. Do not weaken test.skip, source eligibility or required assertions.
  log('One bounded Copilot registration repair is starting; no browser will launch.','warning');
  const instructions=`TASK: Fix Playwright TEST DISCOVERY for the selected migrated method.\n`+
    `Java source method: ${sel.className}#${sel.name}\n`+
    `Original Java (READ ONLY): ${sel.file}\n`+
    `Playwright target: ${config.playwrightRoot}\n`+
    `Source contract: ${a.json}\nSource prompt: ${a.prompt}\n`+
    `Observed registration failure: ${originalFailure}\n\n`+
    `Read playwright.config.ts, relevant testDir/testMatch/testIgnore and configured projects, then locate any implementation already created for this exact method. Ensure a dedicated .spec.ts inside the ACTIVE configured test directory that actually registers ONE correctly mapped Playwright test. Prefer editing the existing spec or using an existing suite location; do NOT rewrite global Playwright configuration or clone unrelated tests. The test must contain the source-defined functional actions and assertions, not expect(true). If source or scenario legitimately requires test.skip, preserve it and say so explicitly. Validate registration via TEST_ENV=${config.testEnv} npx playwright test --list (no QA browser). No migrations outside the selected method; no Java/Excel changes, commit, push, payment, bank, purchase or Bind execution. Do not claim FUNCTIONAL_PASS.\n`;
  const prompt=await writePromptFile(a,'03-repair-test-registration.txt',instructions);
  const result=await invokeCopilot(prompt,'migrate');
  if(result.stopReason)throw new Error(`Registration repair interrupted: ${result.stopReason}`);
  if(result.code!==0)throw new Error(`Registration repair exited ${result.code}`);
}
async function resolveFocusedTest(sel,a,touched=[],requestedSelection=null){
  const manifest=await fsp.readFile(a.specManifest,'utf8').then(JSON.parse).catch(()=>null);
  const found=await discoverFocusedSpecs(sel);
  let chosen;
  try{chosen=chooseFocusedTest(found,sel.id,manifest,requestedSelection,{touchedSpecs:touched});}
  catch(err){
    const unregistered=found.filter(x=>!x.runnable).map(x=>x.relativePath);
    if(/NO_MAPPED_EXECUTABLE_TEST/.test(err.message) && unregistered.length)
      throw new Error('SPEC_NOT_REGISTERED_BY_PLAYWRIGHT: '+unregistered.slice(0,6).join(', ')+'. Source files exist but are outside active testDir/testMatch or filtered by configuration. Repair spec registration in the actual Playwright test directory; do not treat file creation as a PASS.');
    throw err;
  }
  if(!withinTarget(chosen.specPath))throw new Error('Selected test is outside the Playwright project.');
  if(chosen.skipDeclared){
    const contract=await fsp.readFile(a.json,'utf8').then(JSON.parse).catch(()=>null);
    const sourceEnabled=contract?.testAnnotation?.enabled;
    const error=new Error(`${sourceEnabled===true?'JAVA_ENABLED_PLAYWRIGHT_SKIPPED':'PLAYWRIGHT_TEST_SKIPPED'}: ${chosen.relativePath}:${chosen.line} declares test.skip. Do not remove a legitimate skip to fabricate PASS.`);
    error.skipCandidate={specPath:chosen.specPath,relativePath:chosen.relativePath,line:chosen.line,title:chosen.title,project:chosen.project};
    throw error;
  }
  const modified=touched.includes(chosen.specPath);
  await fsp.mkdir(a.dir,{recursive:true});
  await fsp.writeFile(a.specManifest,JSON.stringify({methodId:sel.id,specPath:chosen.specPath,
    testTitle:chosen.title,line:chosen.line,project:chosen.project,configFile:chosen.configFile||null,modifiedInCurrentRun:modified,
    mappingEvidence:chosen.evidence,sourceAssertionParity:'NOT_INDEPENDENTLY_VERIFIED',
    confirmedAt:new Date().toISOString()},null,2));
  log(`Mapped Java ${sel.id} to Playwright [${chosen.project}] ${chosen.relativePath}:${chosen.line} › ${chosen.title}`,'success');
  return chosen;
}
function collectPlaywrightResults(report){
  const tests=[];
  function walkSuite(suite,parents=[]){
    const pathParts=suite.title?[...parents,suite.title]:parents;
    for(const spec of suite.specs||[]){
      for(const t of spec.tests||[]){
        const result=t.results||[];
        const last=result.at(-1)||{};
        const status=t.status || last.status || 'unknown';
        const allSteps=[];
        function walkSteps(items,depth=0){
          for(const st of items||[]){
            if(allSteps.length>=2500)return;
            allSteps.push({title:sanitizeReportText(st.title),category:st.category||'',duration:st.duration||0,
              error:st.error?sanitizeReportText(st.error.message||st.error.value||''):null,depth});
            walkSteps(st.steps,depth+1);
          }
        }
        walkSteps(last.steps||[]);
        tests.push({title:sanitizeReportText([...pathParts,spec.title].filter(Boolean).join(' › ')),
          project:t.projectName||'', status, expectedStatus:t.expectedStatus||'passed',
          duration:result.reduce((n,r)=>n+(r.duration||0),0), retries:Math.max(0,result.length-1),
          errors:(last.errors||[]).map(e=>sanitizeReportText(e.message||e.value||e.stack||'')).slice(0,10),
          annotations:(t.annotations||[]).map(a=>({type:sanitizeReportText(a.type),description:sanitizeReportText(a.description)})).slice(0,20),
          steps:allSteps});
      }
    }
    for(const sub of suite.suites||[])walkSuite(sub,pathParts);
  }
  for(const suite of report.suites||[])walkSuite(suite);
  return tests;
}
function summarizeFunctionalReport(report, exitCode, selectedSpec, jsonFile, methodId, projectName) {
  const tests=collectPlaywrightResults(report);
  const counts={total:tests.length,passed:0,failed:0,skipped:0,timedOut:0,interrupted:0,other:0};
  for(const t of tests){
    if(t.status==='expected' && t.expectedStatus==='passed')counts.passed++;
    else if(t.status==='unexpected'){counts.failed++;if(t.errors.some(e=>/timeout/i.test(e)))counts.timedOut++;}
    else if(t.status==='skipped')counts.skipped++;
    else if(t.status==='interrupted')counts.interrupted++;
    else counts.other++;
  }
  const verdict=classifyFunctionalVerdict(counts,exitCode);
  const reason=verdict==='SKIPPED_RUNTIME' ? runtimeSkipReason(tests) :
    verdict==='PARTIALLY_SKIPPED' ? 'One or more Playwright tests were skipped; mandatory runtime coverage is not verified.' :
    verdict==='NO_TEST_RESULTS' ? 'The Playwright JSON report contains no tests for the selected run.' : null;
  return {methodId,verdict,exitCode,counts,tests,selectedSpec,projectName,reason,
    reportPath:jsonFile,executedAt:new Date().toISOString(),javaRuntimeParity:'NOT_VERIFIED',
    sourceContractParity:'NOT_INDEPENDENTLY_VERIFIED',
    note:'A real Playwright report is available. A skipped test has not executed its mandatory assertions; Playwright PASS alone is not Java-source parity certification.'};
}
async function runFunctionalCheck(sel,a,contract,touched=[],manual=false,requestedSpec=null) {
  await fsp.mkdir(a.dir,{recursive:true});
  await fsp.rm(a.functionalSummary,{force:true}); // Never display a previous run as the current result.
  if(sel.skipped){
    const reason=`SOURCE_TEST_SKIPPED: ${sel.skipReason}. Java disables this method; it is listed only under SKIPPED SCENARIOS. No browser was launched.`;
    currentJob.functional={verdict:'SOURCE_TEST_SKIPPED',reason,counts:{total:0,passed:0,failed:0,skipped:0},tests:[],methodId:sel.id};
    await fsp.writeFile(a.functionalSummary,JSON.stringify(currentJob.functional,null,2));
    step(5,'skipped',reason);log(reason,'warning');return;
  }
  const safety=await scenarioSafety(sel,contract);
  if(safety.sensitive) {
    const reason=`Safety gate: ${safety.reason} No browser was launched.`;
    currentJob.functional={verdict:'SKIPPED_SAFETY',reason,counts:{total:0,passed:0,failed:0,skipped:0},tests:[],methodId:sel.id};
    await fsp.writeFile(a.functionalSummary,JSON.stringify(currentJob.functional,null,2));
    step(5,'skipped',reason);log(reason,'warning');return;
  }
  // User policy: headed Chrome is attempted for every eligible, source-enabled, safe TC.
  // Historical autoFunctionalCheck=false values do not disable this requirement.
  step(5,'running','Selecting the exact migrated test in the Playwright TypeScript project');
  let target;
  try { target=await resolveFocusedTest(sel,a,touched,requestedSpec); }
  catch(error) {
    if(error.skipCandidate && /PLAYWRIGHT_TEST_SKIPPED|JAVA_ENABLED_PLAYWRIGHT_SKIPPED/.test(error.message)){
      const c=error.skipCandidate;
      const reason=`SKIPPED_IMPLEMENTATION: ${c.relativePath}:${c.line} declares test.skip. Java source disablement was not detected; resolve the actual source/fixture/dependency reason before attempting an unskip. No browser was launched.`;
      currentJob.functional={methodId:sel.id,verdict:'SKIPPED_IMPLEMENTATION',reason,selectedSpec:c.specPath,projectName:c.project,
        counts:{total:0,passed:0,failed:0,skipped:0},tests:[],javaRuntimeParity:'NOT_VERIFIED',sourceContractParity:'NOT_INDEPENDENTLY_VERIFIED'};
      await fsp.writeFile(a.functionalSummary,JSON.stringify(currentJob.functional,null,2));
      step(5,'skipped',reason);log(reason,'warning');return;
    }
    throw error;
  }
  const relative=target.relativePath;
  // File:line filters the exact Playwright-registered test without depending on
  // the original Java method name. This is an official Playwright CLI feature.
  const focus=`${relative}:${target.line}`;
  const runtimeEnv={TEST_ENV:config.testEnv};
  const listArgs=[focus,...(target.configFile?['--config',target.configFile]:[]),...(target.project?['--project',target.project]:[]),'--list'];
  const listOutput=[];
  log(`Functional TC discovery: ${focus} [${target.project}] (${target.title})`);
  const listCmd=playwrightCommand(listArgs);
  const listed=await spawnAndLog(listCmd.cmd,listCmd.args,{cwd:config.playwrightRoot,env:runtimeEnv},listOutput);
  if(listed!==0)throw new Error(`Playwright focused discovery failed (${listed}); browser not launched.`);
  const actual=parsePlaywrightList(listOutput.join('\n'));
  if(actual.length!==1 || actual[0].title!==target.title || actual[0].project!==target.project)
    throw new Error(`TARGET_NOT_UNIQUE: file:line discovery returned ${actual.length} tests, not the exact registered title. Browser not launched.`);
  const project=target.project;
  await fsp.mkdir(a.dir,{recursive:true});
  const reportFile=a.functionalReport;
  await fsp.rm(reportFile,{force:true});
  const runArgs=[focus,...(target.configFile?['--config',target.configFile]:[]),...(project?['--project',project]:[]),'--headed','--workers=1','--retries=0','--forbid-only','--reporter=json'];
  log(`Starting focused headed Playwright execution: ${relative}${project?' ['+project+']':''}`);
  const runCmd=playwrightCommand(runArgs);
  const code=await spawnAndLog(runCmd.cmd,runCmd.args,{
    cwd:config.playwrightRoot,
    env:{...runtimeEnv,PLAYWRIGHT_JSON_OUTPUT_NAME:reportFile,CI:''}
  });
  const report=await fsp.readFile(reportFile,'utf8').then(JSON.parse).catch(()=>null);
  if(!report){
    currentJob.functional={verdict:'REPORT_MISSING',reason:'Playwright JSON report was not generated or could not be parsed.',methodId:sel.id,
      counts:{total:0,passed:0,failed:0,skipped:0},tests:[],exitCode:code};
    await fsp.writeFile(a.functionalSummary,JSON.stringify(currentJob.functional,null,2));
    throw new Error(`Playwright execution exited ${code}, but no valid JSON report exists. Functional PASS cannot be claimed.`);
  }
  const summary=summarizeFunctionalReport(report,code,target.specPath,reportFile,sel.id,project||'default');
  currentJob.functional=summary;
  await fsp.writeFile(a.functionalSummary,JSON.stringify(summary,null,2),'utf8');
  if(summary.verdict==='PLAYWRIGHT_PASS_PARITY_UNVERIFIED'){
    step(5,'pass',`${summary.counts.passed}/${summary.counts.total} Playwright tests passed; SOURCE CONTRACT PARITY NOT VERIFIED.`);
    log(`PLAYWRIGHT EXECUTION PASS (not source-parity certification): ${summary.counts.passed}/${summary.counts.total}; report: ${a.functionalSummary}`,'success');
  } else if(summary.verdict==='SKIPPED_RUNTIME' || summary.verdict==='PARTIALLY_SKIPPED') {
    // A skipped Playwright test is not an assertion failure. Keep the actual
    // report and allow an explicit focused repair request for source-enabled TCs.
    step(5,'skipped',`${summary.counts.skipped} skipped; ${summary.counts.failed} failed. ${summary.reason}`);
    log(`PLAYWRIGHT SKIPPED — not a Functional PASS: ${summary.reason}. Use Repair skipped TC only if Java is enabled and the skip is not source-required.`,'warning');
  } else {
    throw new Error(`Functional TC Check ${summary.verdict}: ${summary.counts.passed} passed, ${summary.counts.failed} failed, ${summary.counts.skipped} skipped, ${summary.counts.other} other. See saved per-test results.`);
  }
}
// Explicit, one-shot repair for a Java-enabled TC whose actual focused
// Playwright run was SKIPPED. It never removes a legitimate source skip,
// never launches QA Chrome, and never alters the existing runner or iGero UI.
async function repairSkippedTest(sel) {
  if(sel.skipped) throw new Error(`SOURCE_TEST_SKIPPED: ${sel.skipReason}; do not enable this test.`);
  const a=artifactPaths(sel);
  const last=await fsp.readFile(a.functionalSummary,'utf8').then(JSON.parse).catch(()=>null);
  if(!last || !['SKIPPED_RUNTIME','PARTIALLY_SKIPPED','SKIPPED_IMPLEMENTATION'].includes(last.verdict) || last.methodId!==sel.id)
    throw new Error('SKIP_REPAIR_NOT_ELIGIBLE: run the focused Functional TC Check first and obtain a real SKIPPED result for this Java method.');
  const contract=await fsp.readFile(a.json,'utf8').then(JSON.parse).catch(()=>null);
  if(!contract || contract.className!==sel.className || contract.methodName!==sel.name)
    throw new Error('SKIP_REPAIR_BLOCKED: no matching source JSON contract.');
  const safety=await scenarioSafety(sel,contract);
  if(safety.sensitive)throw new Error(`SKIP_REPAIR_BLOCKED_SAFETY: ${safety.reason}`);
  const file=path.resolve(String(last.selectedSpec||''));
  if(!withinTarget(file)||!fs.existsSync(file)||!/(?:\.spec|\.test)\.[cm]?[jt]sx?$/.test(file))
    throw new Error('SKIP_REPAIR_BLOCKED: last runtime report does not contain a verified target spec.');
  const beforeSource=await fingerprintTree(config.javaRoot);
  const beforeSpecs=await listSpecVersions(config.playwrightRoot);
  const original=await fsp.readFile(file);
  const backup=path.join(a.dir,'repair-backups',`${path.basename(file)}.${new Date().toISOString().replace(/[:.]/g,'-')}.before-repair`);
  await fsp.mkdir(path.dirname(backup),{recursive:true});
  await fsp.writeFile(backup,original);
  const sourceEnabled=contract?.testAnnotation?.enabled;
  if(sourceEnabled===false)throw new Error('SOURCE_TEST_SKIPPED: the Java contract explicitly disables this method. No automated unskip is allowed.');
  const info=[`Java: ${sel.className}#${sel.name}`,`Source: ${sel.file}`,`Playwright spec: ${file}`,`Last verdict: ${last.verdict}`,`Selected test: ${last.tests?.[0]?.title||''}`,`Skipped test annotations: ${JSON.stringify(last.tests?.[0]?.annotations||[])}`,`Skip evidence: ${last.reason||'No exact Playwright reason was recorded'}`,`Java annotation enabled: ${sourceEnabled===undefined?'UNVERIFIED':sourceEnabled}`].join('\n');
  const instructions=`TASK: TARGETED REPAIR of the SINGLE selected Playwright TC which was SKIPPED by a genuine headed Chromium test run.\n${info}\n\n`+
    `READ ONLY: ${config.javaRoot} (Java and Excel).\nSource contract: ${a.json}\nSource prompt: ${a.prompt}\n`+
    `Inspect actual source annotations including disabled/skip, conditional state exclusions, Excel provider, reachable helpers, and runtime Playwright skip guards. `+
    `Only if Java is ENABLED, data and all mandatory dependencies are available, and the skip is UNJUSTIFIED, correct the minimum code in THIS EXISTING SPEC: ${file}. `+
    `Do not blindly remove test.skip/test.fixme or weaken assertions; do not add expect(true), fake navigation, mocks, forced state, hardcoded identities or skipped mandatory branches. `+
    `If the source disables the TC, or mandatory dependencies remain unavailable, PRESERVE the skip and explain the source-supported blocker. `+
    `DO NOT modify any other spec, helper, Page Object, fixture, Playwright/global config, iGero file, Java or Excel. `+
    `DO NOT run browser, bank, payment, email, purchase, bind, commit or push. Do not re-generate JSON/Prompt. `+
    `Typecheck the target with existing project commands and verify focused Playwright --list registration; report exact changes and remaining blocker. `+
    `No Functional PASS until a separately authorized real headed Chrome run passes mandatory assertions.\n`;
  const prompt=await writePromptFile(a,'04-repair-skipped-test.txt',instructions);
  const outcome=await invokeCopilot(prompt,'migrate');
  if(outcome.code!==0||outcome.stopReason)throw new Error(`SKIP_REPAIR_INTERRUPTED: ${outcome.stopReason||'Copilot exit '+outcome.code}. Original spec backup: ${backup}`);
  if(await fingerprintTree(config.javaRoot)!==beforeSource)throw new Error('ALERT: Java/Excel source changed during focused skip repair. Review immediately.');
  const afterSpecs=await listSpecVersions(config.playwrightRoot);
  const unrelated=Object.entries(afterSpecs).filter(([name,stat])=>name!==file && beforeSpecs[name]!==stat).map(([name])=>path.relative(config.playwrightRoot,name));
  if(unrelated.length)throw new Error(`SKIP_REPAIR_SCOPE_VIOLATION: other spec(s) modified: ${unrelated.slice(0,5).join(', ')}. Review changes; no browser was launched.`);
  const typecheck=await runTypecheck();
  if(typecheck!==0)throw new Error(`SKIP_REPAIR_TYPECHECK_FAILED: exit ${typecheck}. Original spec backup: ${backup}`);
  const hasChanged=!original.equals(await fsp.readFile(file));
  return {changed:hasChanged,specPath:file,backup,typecheck:'PASS',
    note:hasChanged?'Scoped spec updated and TypeScript check passed. Run Functional TC Check to establish actual status; no browser was launched by repair.':
      'Copilot preserved the spec; likely a legitimate source/dependency skip. No browser launched and no Functional PASS claimed.'};
}
async function archivePreviousFunctionalSummary(a) {
  if(!fs.existsSync(a.functionalSummary))return;
  const historicalDir=path.join(a.dir,'functional-history');
  await fsp.mkdir(historicalDir,{recursive:true});
  const archivedName=`functional-summary-${new Date().toISOString().replace(/[:.]/g,'-')}-${crypto.randomBytes(3).toString('hex')}.json`;
  await fsp.rename(a.functionalSummary,path.join(historicalDir,archivedName));
}
async function executeJob(sel, mode, requestedSelection=null){
  const a=artifactPaths(sel);
  const stageOne=(mode==='all'||mode==='extract');
  const stageTwo=(mode==='all'||mode==='migrate');
  const functionalOnly=mode==='functional';
  // Create the current job BEFORE any asynchronous preflight. Otherwise the
  // browser can briefly display the previous completed job after Start.
  currentJob={id:crypto.randomUUID(),methodId:sel.id,status:'running',startedAt:new Date().toISOString(),endedAt:null,steps:STEP_NAMES.map(name=>({name,status:'pending',note:''})),logs:[],artifacts:{json:a.json,prompt:a.prompt, outputDir:a.dir},aiCreditsObserved:{extract:null,migrate:null},functional:null,error:null};
  sendEvent('status',jobPublic());
  try{
    const sourceFingerprint=await fingerprintTree(config.javaRoot);
    await archivePreviousFunctionalSummary(a); // Keep history, never reuse a stale verdict.
    step(0,'running','Verifying the selected Java @Test method');
    if(!fs.existsSync(sel.file))throw new Error('The selected Java source file does not exist.');
    step(0,'pass',sel.relativePath);
    // v2.4: Source generation must never depend on an EXISTING Playwright test.
    // An empty registry is normal when bootstrapping the first migrated method.
    // Registration is validated AFTER TypeScript generation. Explicit diagnostics
    // and registry repair are still available from the HTML separately.
    if(stageTwo){
      log('Migration preflight: Java source and target paths verified. Playwright registry is checked AFTER spec generation; zero existing tests will not block creating the first test.','success');
    }
    if(stageOne){
      step(1,'running','Copilot is generating the contract and prompt');
      const p=await writePromptFile(a,'01-extract-instructions.txt',promptForExtraction(sel,a));
      const ret=await invokeCopilot(p,'extract'); if(ret.stopReason)throw new Error(`${ret.stopReason} during extraction. This step cannot be marked complete.`); if(ret.code!==0)throw new Error(`Copilot extraction exited with code ${ret.code}.`);
      const afterExtract=await fingerprintTree(config.javaRoot);
      if(sourceFingerprint!==afterExtract)throw new Error('ALERT: Java/Excel source files changed during extraction. Stage 2 was cancelled.');
      step(1,'pass','Copilot exited 0; Java/Excel files remained unchanged');
    }else step(1,'skipped','Existing artifacts reused');
    step(2,'running','Validating the generated JSON contract');
    let contract;
    try{contract=JSON.parse(await fsp.readFile(a.json,'utf8'))}catch{throw new Error('No valid contract.json was found. Migration stopped.');}
    if(contract.className!==sel.className || contract.methodName!==sel.name || !Array.isArray(contract.assertions) || !Array.isArray(contract.steps))throw new Error('Contract does not match the selected class/method or lacks valid steps/assertions.');
    const promptContent=await fsp.readFile(a.prompt,'utf8').catch(()=>''), promptValid=promptContent.length>=40;
    if(!promptValid)throw new Error('The generated prompt.md is missing or incomplete.');
    step(2,'pass',`${contract.assertions.length} assertion records in JSON`);
    if(stageTwo){
      step(3,'running','Copilot is implementing the TypeScript spec');
      const beforeSpecs=await listSpecVersions(config.playwrightRoot);
      const p=await writePromptFile(a,'02-migrate-instructions.txt',promptForMigration(sel,a));
      const ret=await invokeCopilot(p,'migrate'); if(ret.stopReason)throw new Error(`${ret.stopReason} during migration. Existing changes are preserved but not certified.`); if(ret.code!==0)throw new Error(`Copilot migration exited with code ${ret.code}.`);
      const afterMigration=await fingerprintTree(config.javaRoot);
      if(sourceFingerprint!==afterMigration)throw new Error('ALERT: Java/Excel source files changed during implementation.');
      const afterSpecs=await listSpecVersions(config.playwrightRoot);
      const touched=Object.entries(afterSpecs).filter(([file,version])=>beforeSpecs[file]!==version).map(([file])=>file);
      if(sel.skipped){
        const skipMessage=`Java source disabled: ${sel.skipReason}. Kept under SKIPPED SCENARIOS; Playwright registration and headed Chrome are not required.`;
        const related=[...touched,...Object.keys(afterSpecs).filter(f=>path.basename(f).toLowerCase().includes(sel.className.toLowerCase()))];
        const unique=[...new Set(related)].filter(f=>fs.existsSync(f));
        const candidates=[];
        for(const file of unique){const source=await fsp.readFile(file,'utf8').catch(()=>'');if(source.includes(sel.name))candidates.push(file);}
        if(candidates.length){currentJob.artifacts.specs=candidates;currentJob.artifacts.specMode='SOURCE_SKIPPED';step(3,'skipped',`Source-disabled TC: ${candidates.length} matching spec(s) present. ${skipMessage}`);}
        else step(3,'skipped',`Source-disabled TC: no verified spec file. ${skipMessage}`);
        if(config.autoTypecheck){step(4,'running','Validating TypeScript without browser');const code=await runTypecheck();if(code)throw new Error(`TypeScript typecheck exited ${code}.`);step(4,'pass','TypeScript typecheck passed; SOURCE SKIPPED, no Functional PASS');}
        else step(4,'skipped','Typecheck disabled in settings');
        await runFunctionalCheck(sel,a,contract,[],false,requestedSelection);
      }else{
      let selection;
      try {selection=await resolveFocusedTest(sel,a,touched,requestedSelection);}
      catch(firstError){
        if(!requestedSelection && /SPEC_NOT_REGISTERED_BY_PLAYWRIGHT|NO_MAPPED_EXECUTABLE_TEST/.test(firstError.message)){
          log(`Registered test not found after Copilot implementation: ${firstError.message}`,'warning');
          await attemptRegistrationRepair(sel,a,firstError.message);
          if(sourceFingerprint!==await fingerprintTree(config.javaRoot))throw new Error('ALERT: Java/Excel source changed during registration repair.');
          selection=await resolveFocusedTest(sel,a,touched,requestedSelection);
        }else throw firstError;
      }
      const selectedSpec=selection.specPath;
      const repairedVersions=await listSpecVersions(config.playwrightRoot);
      if(beforeSpecs[selectedSpec]!==repairedVersions[selectedSpec] && !touched.includes(selectedSpec))touched.push(selectedSpec);
      currentJob.artifacts.specs=[selectedSpec];
      currentJob.artifacts.specMode=touched.includes(selectedSpec)?'MODIFIED':'REUSED_EXISTING';
      if(touched.includes(selectedSpec)) {
        step(3,'pass',`Playwright REGISTERED: ${path.relative(config.playwrightRoot,selectedSpec)}; source-assertion parity NOT INDEPENDENTLY VERIFIED`);
      } else {
        log(`Existing source-referenced spec reused unchanged: ${path.relative(config.playwrightRoot,selectedSpec)}. Copilot made no spec edit; that is not a failure and not a Functional PASS.`,'warning');
        step(3,'pass',`REGISTERED EXISTING SPEC (unchanged); source-assertion parity NOT VERIFIED`);
      }
      if(config.autoTypecheck){step(4,'running','npx tsc --noEmit');const c=await runTypecheck();if(c===0)step(4,'pass','TypeScript typecheck passed; NOT a Functional PASS');else throw new Error(`TypeScript typecheck exited with code ${c}; implementation not verified.`);}
      else step(4,'skipped','Typecheck disabled in settings');
      // Execute the real migrated method only after typecheck and safe scenario gating.
      if(!config.autoTypecheck){
        currentJob.functional={verdict:'NOT_EXECUTED',reason:'TypeScript validation is disabled. Functional execution cannot start.',counts:{total:0,passed:0,failed:0,skipped:0},tests:[]};
        step(5,'skipped','Typecheck is disabled; functional check cannot start.');
      }else await runFunctionalCheck(sel,a,contract,[selectedSpec],false,requestedSelection);
      }
    }else{step(3,'skipped',functionalOnly?'Using existing spec':'Extraction only');
      if(functionalOnly){step(4,'running','Validating TypeScript before the focused Playwright run');
        const c=await runTypecheck();if(c!==0)throw new Error(`TypeScript typecheck failed (${c}); functional execution aborted.`);
        step(4,'pass','TypeScript typecheck passed');await runFunctionalCheck(sel,a,contract,[],true,requestedSelection);
      }else{step(4,'skipped','Extraction only');step(5,'skipped','Extraction only');}}
    const after=await fingerprintTree(config.javaRoot);
    if(sourceFingerprint!==after)throw new Error('ALERT: a Java source file changed. Review changes immediately.');
    step(6,'pass','Java unchanged; generated files and runtime results saved in target project');
    if(currentJob.status==='cancelled')throw new Error('Job cancelled by user.');
    // Finishing the conversion is distinct from completing a REAL functional run.
    const functionalWasRequested=(stageTwo || functionalOnly);
    if(functionalWasRequested && currentJob.functional?.verdict==='PLAYWRIGHT_PASS_PARITY_UNVERIFIED') {
      currentJob.status='partial';
      log('Playwright runtime PASSED; complete Java-source assertion parity remains NOT VERIFIED. No certified full migration PASS.','warning');
    }else if(functionalWasRequested){
      currentJob.status='partial';
      log('Conversion stages ended without a verified Playwright runtime PASS. See Section 7.','warning');
    }else{
      currentJob.status='completed';
      log('Requested generation stage finished. Runtime execution not requested.','success');
    }
  }catch(err){
    currentJob.status=currentJob.status==='cancelled'?'cancelled':'blocked';currentJob.error=err.message;
    log(`BLOCKED: ${err.message}`,'error');
    if(!currentJob.functional) {
      const reachedFunctional=currentJob.steps[5]?.status==='running';
      currentJob.functional={methodId:sel.id,verdict:reachedFunctional?'BLOCKED':'NOT_EXECUTED',
        reason:reachedFunctional?`Functional execution failed before a verified result: ${err.message}`:
          `Functional TC Check was not reached: ${err.message}`,
        counts:{total:0,passed:0,failed:0,skipped:0},tests:[]};
      await fsp.writeFile(a.functionalSummary,JSON.stringify(currentJob.functional,null,2)).catch(()=>{});
    }
    const ix=currentJob.steps.findIndex(x=>x.status==='running');if(ix>=0)step(ix,'blocked',err.message);
    if(currentJob.steps[5]?.status==='pending')step(5,'skipped','NOT EXECUTED — earlier stage blocked; no browser was launched');
  }finally{currentJob.endedAt=new Date().toISOString();sendEvent('status',jobPublic());}
}
function parseBody(req){return new Promise((resolve,reject)=>{let body='';req.on('data',d=>{body+=d; if(body.length>100000){reject(new Error('Request body too large'));req.destroy();}});req.on('end',()=>{try{resolve(JSON.parse(body||'{}'))}catch{reject(new Error('Invalid JSON'))}});req.on('error',reject);});}
function originAllowed(req){if(!req.headers.origin)return true;try{const u=new URL(req.headers.origin);return u.hostname==='127.0.0.1'&&Number(u.port)===PORT;}catch{return false;}}
const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,`http://${HOST}:${PORT}`);
    if(req.method==='GET' && url.pathname==='/'){const html=await fsp.readFile(path.join(HERE,'index.html'));res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'"});res.end(html);return;}
    if(req.method==='GET' && url.pathname==='/app.js'){const data=await fsp.readFile(path.join(HERE,'app.js'));res.writeHead(200,{'Content-Type':'application/javascript; charset=utf-8','Cache-Control':'no-store'});res.end(data);return;}
    if(req.method==='GET'&&url.pathname==='/api/events'){
      res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'});
      res.write('retry: 2000\n\n');clients.add(res);res.write(`event: status\ndata: ${JSON.stringify(jobPublic())}\n\n`);req.on('close',()=>clients.delete(res));return;
    }
    if(req.method==='GET' && url.pathname==='/api/system'){json(res,200,await systemReadiness());return;}
    if(req.method==='GET' && url.pathname==='/api/config'){json(res,200,{...config,...rootChecks()});return;}
    if(req.method==='GET'&&url.pathname==='/api/lob-catalog'){
      if(!rootChecks().javaExists){json(res,400,{error:'Java source directory is unavailable'});return;}
      if(url.searchParams.get('refresh')==='1'||Date.now()-lastMethodScan>120000||!methodCache.length){methodCache=await collectMethods();lastMethodScan=Date.now();}
      const catalog=buildLobCatalog(methodCache);
      json(res,200,{total:methodCache.length,lobs:catalog});return;
    }
    if(req.method==='GET'&&url.pathname==='/api/methods'){
      if(!rootChecks().javaExists){json(res,400,{error:'Java source directory is unavailable'});return;}
      if(Date.now()-lastMethodScan>120000||!methodCache.length){methodCache=await collectMethods();lastMethodScan=Date.now();}
      const q=url.searchParams.get('q')||'';
      const lob=url.searchParams.get('lob')||'',suite=url.searchParams.get('suite')||'';
      const all=filterMethods(methodCache,{lob,suite,q});
      json(res,200,{total:methodCache.length,filteredTotal:all.length,lob,suite,
        methods:all.slice(0,400).map(({id,relativePath,className,lob,suite:sourceSuite,skipped,skipReason})=>({id,relativePath,className,lob,suite:skipped?SKIPPED_SUITE:sourceSuite,sourceSuite,skipped,skipReason}))});return;
    }
    if(req.method==='GET'&&url.pathname==='/api/method-preview'){
      const sel=await findMethod(url.searchParams.get('id')||''); const raw=await fsp.readFile(sel.file,'utf8');
      const start=Math.max(0,raw.search(new RegExp('\\b'+sel.name+'\\s*\\('))-400);
      json(res,200,{id:sel.id,relativePath:sel.relativePath,javaPreview:raw.slice(start,start+14000),skipped:sel.skipped,skipReason:sel.skipReason});return;
    }
    if(req.method==='GET'&&url.pathname==='/api/outputs'){
      const sel=await findMethod(url.searchParams.get('id')||'');const a=artifactPaths(sel);
      const exists={json:fs.existsSync(a.json),prompt:fs.existsSync(a.prompt)};
      let contract='';let prompt='';let contractFull='';if(exists.json){contractFull=await fsp.readFile(a.json,'utf8');contract=contractFull.slice(0,22000);}if(exists.prompt)prompt=(await fsp.readFile(a.prompt,'utf8')).slice(0,22000);
      const specMap=await listSpecVersions(config.playwrightRoot);
      const manifest=await fsp.readFile(a.specManifest,'utf8').then(JSON.parse).catch(()=>null);
      let specPath=manifest?.methodId===sel.id&&specMap[manifest.specPath]?manifest.specPath:'';
      if(!specPath){
        for(const f of Object.keys(specMap)){
          const source=await fsp.readFile(f,'utf8').catch(()=>'');
          if(source.includes(sel.name) && (source.includes(sel.className)||path.basename(f).toLowerCase().includes(sel.className.toLowerCase()))){specPath=f;break;}
        }
      }
      const specFull=specPath?(await fsp.readFile(specPath,'utf8')):'';
      const specPreview=specFull.slice(0,35000);
      const jsonValid=exists.json && (()=>{try{const c=JSON.parse(contractFull);return c.className===sel.className && c.methodName===sel.name;}catch{return false;}})();
      const promptValid=exists.prompt && prompt.trim().length>=40;
      // These booleans represent files on disk and basic identity checks, NOT
      // functional completeness, Playwright registration or Java assertion parity.
      const fileStatus={json:{exists:exists.json,valid:!!jsonValid},prompt:{exists:exists.prompt,valid:!!promptValid},spec:{exists:!!specPath,valid:!!specPath&&specFull.includes(sel.name),path:specPath||null}};
      const functional=await fsp.readFile(a.functionalSummary,'utf8').then(JSON.parse).catch(()=>null);
      json(res,200,{...exists,contract,prompt,outputDir:a.dir,specPath,specPreview,specExists:!!specPath,fileStatus,functional});return;
    }
    if(req.method==='GET'&&url.pathname==='/api/playwright-diagnostics'){
      if(currentJob?.status==='running'){json(res,409,{error:'Wait until the migration finishes before running configuration diagnostics.'});return;}
      const sel=await findMethod(url.searchParams.get('id')||'');
      const report=await queryPlaywrightRegistry(sel);
      await persistDiscoveryDiagnostic(sel,artifactPaths(sel),report.diagnostics);
      json(res,200,report.diagnostics);return;
    }
    if(req.method==='POST' && url.pathname==='/api/repair-skipped-test') {
      if(!originAllowed(req)){json(res,403,{error:'Origin not allowed'});return;}
      if(dispatchPending||currentJob?.status==='running'){json(res,409,{error:'Another iGero operation is running.'});return;}
      const body=await parseBody(req);
      const sel=await findMethod(String(body.methodId||''));
      dispatchPending=true;
      currentJob={id:crypto.randomUUID(),methodId:sel.id,status:'running',startedAt:new Date().toISOString(),endedAt:null,
        steps:STEP_NAMES.map(name=>({name,status:'pending',note:''})),logs:[],artifacts:{},aiCreditsObserved:{extract:null,migrate:null},functional:null,error:null};
      sendEvent('status',jobPublic());
      try{
        log('Starting explicit one-shot SKIPPED TC repair: Java/Excel read-only; no browser run.');
        step(3,'running','Reviewing and correcting only the selected source-enabled skipped test');
        const result=await repairSkippedTest(sel);
        step(3,'pass',result.note);
        currentJob.status='completed';
        json(res,200,{ok:true,...result});
      }catch(e){
        currentJob.status='blocked';currentJob.error=e.message;step(3,'blocked',e.message);log(`SKIP REPAIR BLOCKED: ${e.message}`,'error');
        json(res,422,{error:e.message});
      }finally{currentJob.endedAt=new Date().toISOString();dispatchPending=false;sendEvent('status',jobPublic());}
      return;
    }
    if(req.method==='POST' && url.pathname==='/api/repair-playwright-registry') {
      // This route is handled before the general POST handler so it can run a
      // bounded, explicit user-triggered repair without modifying migration status.
      if(!originAllowed(req)){json(res,403,{error:'Origin not allowed'});return;}
      if(dispatchPending||currentJob?.status==='running'){json(res,409,{error:'Another iGero operation is running.'});return;}
      const body=await parseBody(req);
      const sel=await findMethod(String(body.methodId||''));
      dispatchPending=true;
      // Treat it as a focused job to provide live logs and avoid concurrent Copilot invocations.
      currentJob={id:crypto.randomUUID(),methodId:sel.id,status:'running',startedAt:new Date().toISOString(),endedAt:null,
        steps:STEP_NAMES.map(name=>({name,status:'pending',note:''})),logs:[],artifacts:{},aiCreditsObserved:{extract:null,migrate:null},functional:null,error:null};
      sendEvent('status',jobPublic());
      try{
        log('Starting one explicitly requested Playwright registry repair. Source Java/Excel stays read-only.');
        step(3,'running','Checking baseline runner and applying one bounded configuration repair');
        const result=await repairProjectRegistry(sel);
        step(3,'pass',`Playwright now registers ${result.registered} tests. Test execution and source parity are not claimed.`);
        currentJob.status='completed';
        json(res,200,{ok:true,...result});
      }catch(e){
        currentJob.status='blocked';currentJob.error=e.message;step(3,'blocked',e.message);log(`Registry repair BLOCKED: ${e.message}`,'error');
        json(res,422,{error:e.message});
      }finally{currentJob.endedAt=new Date().toISOString();dispatchPending=false;sendEvent('status',jobPublic());}
      return;
    }
    if(req.method==='GET'&&url.pathname==='/api/spec-candidates'){
      if(currentJob?.status==='running'){json(res,409,{error:'Wait until the current migration finishes before discovering specs.'});return;}
      const sel=await findMethod(url.searchParams.get('id')||'');
      let entries=[],discoveryError=null;
      try{entries=await discoverFocusedSpecs(sel);}catch(e){
        if(!/PLAYWRIGHT_PROJECT_NO_TESTS/.test(e.message))throw e;
        discoveryError=e.message;
      }
      const canonical=canonicalFocusedTests(entries);
      const unregistered=entries.filter(x=>!x.runnable);
      json(res,200,{methodId:sel.id,entries:[...canonical,...unregistered],discoveryError,diagnostics:registrationSnapshot?.diagnostics||null,
        registered:canonical.length,rawRegistrations:entries.filter(x=>x.runnable && x.eligible).length,globallyListed:registrationSnapshot?.listedCount||0,
        note:'Global Playwright registry is the authority. An existing .spec.ts outside testDir/testMatch is not runnable; test.skip is not a PASS.'});return;
    }
    if(req.method==='GET' && url.pathname==='/api/job'){json(res,200,jobPublic());return;}
    if(req.method==='POST'){
      if(!originAllowed(req)){json(res,403,{error:'Origin not allowed'});return;}
      const body=await parseBody(req);
      if(url.pathname==='/api/config'){
        if(currentJob?.status==='running')throw new Error('Cannot change project paths while a job is running.');
        const javaRoot=String(body.javaRoot||'').trim(),playwrightRoot=String(body.playwrightRoot||'').trim();
        if(!validRoot(javaRoot)||!validRoot(playwrightRoot))throw new Error('One or both project directories do not exist.');
        if(path.resolve(javaRoot)===path.resolve(playwrightRoot))throw new Error('Source and target directories cannot be the same.');
        const testEnv=String(body.testEnv||'MA11').trim().toUpperCase();
        if(!['MA11','RA11'].includes(testEnv))throw new Error('Select MA11 (QA) or RA11 (UAT).');
        config={javaRoot,playwrightRoot,autoTypecheck:body.autoTypecheck!==false,autoFunctionalCheck:body.autoFunctionalCheck!==false,testEnv};
        await fsp.writeFile(CONFIG_FILE,JSON.stringify(config,null,2));methodCache=[];lastMethodScan=0;
        json(res,200,{ok:true,...config,...rootChecks()});return;
      }
      if(url.pathname==='/api/start'){
        if(dispatchPending||currentJob?.status==='running'){json(res,409,{error:'A migration is already running.'});return;}
        if(!rootChecks().ready)throw new Error('Verify that both project folders exist.');
        const preflight=await systemReadiness();
        if(!preflight.functionalReady)throw new Error('System Readiness FAILED. Check Node.js, project paths and Playwright dependencies before running.');
        if(body.mode!=='functional' && !preflight.migrationReady)throw new Error('GitHub Copilot CLI is not ready. Open System Readiness for details.');
        const mode=body.mode; if(!['extract','migrate','all','functional'].includes(mode))throw new Error('Invalid execution mode.');
        const sel=await findMethod(String(body.methodId||''));
        if(body.lob && sel.lob!==body.lob)throw new Error('Selected Java method does not belong to the chosen Line of Business.');
        if(body.suite && (body.suite===SKIPPED_SUITE ? !sel.skipped : sel.suite!==body.suite || sel.skipped))throw new Error('Selected Java method does not belong to the chosen suite.');
        const selected=body.testSelection;
        const requestedSelection=selected && typeof selected==='object' ? {relativePath:String(selected.relativePath||''),line:Number(selected.line),title:String(selected.title||''),project:String(selected.project||'')} : null;
        if(requestedSelection && (requestedSelection.relativePath.includes('..') || path.isAbsolute(requestedSelection.relativePath)))throw new Error('Select a project-relative Playwright test.');
        dispatchPending=true;executeJob(sel,mode,requestedSelection).finally(()=>{dispatchPending=false;});json(res,202,{started:true,id:sel.id,mode});return;
      }
      if(url.pathname==='/api/cancel'){
        if(!currentJob || currentJob.status!=='running')throw new Error('No migration is currently running.');
        currentJob.status='cancelled';log('Cancellation requested; stopping only the process started by this panel.','warning');
        if(runningProcess){if(process.platform==='win32')spawn('taskkill',['/PID',String(runningProcess.pid),'/T','/F'],{windowsHide:true});else runningProcess.kill('SIGTERM');}
        json(res,200,{cancelled:true});return;
      }
    }
    json(res,404,{error:'Endpoint not found'});
  }catch(err){json(res,400,{error:err.message});}
});
server.listen(PORT,HOST,()=>console.log(`iGero Simple Migration UI: http://${HOST}:${PORT}/`));
