iGero Simple Migration v2.7 — Focused Test Mapping Regression Fix
===============================================================

BASELINE IS PRESERVED
---------------------
This is a minimal patch on v2.6, itself based on v2.5.
No config.local.json is bundled. Java, original Excel, existing Playwright
specs, user migrations and QA environments are not modified by installation.

ONLY THESE EXISTING FILES CHANGED:
- focused-test-resolver.mjs: collapse per-browser variants separately for EACH
  registered test; select a unique touched spec only if it is an eligible,
  Playwright-registered candidate; prefer a unique exact title or filename;
  never guess when multiple source-mapped tests remain.
- server.mjs: pass current-migration touched spec paths into the resolver;
  show canonical test options and raw browser-registration count to the UI.
- app.js: on AMBIGUOUS_TEST_MAPPING, automatically fetch matching registered
  test choices in the existing dropdown; no extra Copilot run or browser run.
- VERSION.txt

ADDED REGRESSIONS:
- regression/v27_ambiguous_mapping.test.mjs
- regression/v27_api_candidates.py

WHY THE TWO TESTS FAILED
------------------------
A single Playwright TC may be registered for Chromium, Firefox, WebKit, Edge,
and mobile projects. If TWO distinct source-mapped specs each register in six
projects, the old resolver counted 12 candidates. THREE specs create 18.
v2.6 only collapsed browser variations when every result came from one file,
so it incorrectly blocked these common cases.

NOW:
1. Collapse variants of each distinct test, retaining desktop Chromium.
2. If Copilot modified exactly one eligible registered spec during this run,
   select it without guessing from other stale/legacy specs.
3. Otherwise prefer a UNIQUE exact method-title or class+method file match.
4. If distinct implementations remain ambiguous, automatically populate the
   dropdown. Select the intended Chromium test and click Run Functional TC
   Check. You do NOT need to re-run JSON extraction or TypeScript generation.
5. Source-defined skip, assertions, security and corporate QA authorization
   are unchanged. Payment/Bank/Bind cases remain restricted: a successful
   mapping is not permission to launch payment transactions.

INSTALL
-------
1. Close the existing launcher server process.
2. Back up your existing config.local.json and custom artifacts.
3. Extract this ZIP and copy igero_html_launcher files into the existing
   launcher folder. Do NOT remove or replace config.local.json.
4. Start via Start-iGero-HTML.cmd and hard-refresh the browser (Ctrl+F5).
5. For a safe HOME content test, run Functional TC Check or Full Migration.
6. When a true ambiguity remains, use the now automatically filled
   PLAYWRIGHT REGISTERED TEST dropdown and run Functional TC Check.

TESTS EXECUTED (MOCKS ONLY)
---------------------------
- node --test regression/*.test.mjs: 42/42 PASS
- regression/integration_regression.py: PASS
- regression/v26_source_skip_api.py: PASS
- regression/v26_expandable_ui.py: PASS
- regression/v27_api_candidates.py: PASS (18 browser registrations become 3)

All test executions above were on a synthetic project and/or simulated
Playwright runner, not the local Farmers checkout. Real runtime functional
results remain NOT VERIFIED until executed on the authorized QA machine.
