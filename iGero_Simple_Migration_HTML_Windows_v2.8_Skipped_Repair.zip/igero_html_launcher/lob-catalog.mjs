// Pure helpers for grouping actual Java @Test methods. LOB comes from
// the source-package directory, not a keyword in a method or class name.
const DEFINITIONS = [
  {id:'home', label:'Home', dirs:['acehome','home']},
  {id:'auto', label:'Auto', dirs:['aceauto','auto']},
  {id:'condo', label:'Condo', dirs:['acecondo']},
  {id:'renters', label:'Renters', dirs:['acerenters','acerenter','renters']},
  {id:'mobile-home', label:'Mobile Home', dirs:['acemobilehome','mobilehome']},
  {id:'life', label:'Life', dirs:['acelife']},
  {id:'bundle', label:'Bundle', dirs:['acebundle']},
  {id:'business', label:'Business', dirs:['acebusiness']},
  {id:'specialty-dwelling', label:'Specialty Dwelling', dirs:['specialtydwelling']},
];
export function classifyLob(relativePath){
  const segments=String(relativePath).replaceAll('\\','/').toLowerCase().split('/');
  const match=DEFINITIONS.find(entry=>entry.dirs.some(dir=>segments.includes(dir)));
  return match?{id:match.id,label:match.label}:{id:'other',label:'Other'};
}
// Virtual suite only: disabled Java methods remain in their original source files.
// It is never a physical folder and never changes source TestNG annotations.
export const SKIPPED_SUITE = '__IGERO_SKIPPED_SCENARIOS__';
export function sourceSkipReason(annotationText='') {
  const header=String(annotationText);
  if (/@Test\b[\s\S]*?\benabled\s*=\s*false\b/.test(header)) return '@Test(enabled=false)';
  if (/@(?:Ignore|Disabled)\b/.test(header)) return '@Ignore/@Disabled';
  return '';
}
export function buildLobCatalog(methods){
  const byLob=new Map();
  for(const m of methods){
    const lobId=m.lob||classifyLob(m.relativePath).id;
    const label=m.lobLabel||classifyLob(m.relativePath).label;
    const suiteId=m.skipped?SKIPPED_SUITE:(m.suite||m.relativePath);
    if(!byLob.has(lobId))byLob.set(lobId,{id:lobId,label,count:0,suites:[],_suites:new Map()});
    const lob=byLob.get(lobId);lob.count++;
    if(!lob._suites.has(suiteId)){
      const suite={id:suiteId,label:m.skipped?'SKIPPED SCENARIOS':m.className,relativePath:m.skipped?'Disabled Java @Test methods (no browser execution)':m.relativePath,count:0};
      lob._suites.set(suiteId,suite);lob.suites.push(suite);
    }
    lob._suites.get(suiteId).count++;
  }
  const order=DEFINITIONS.map(x=>x.id);
  return [...byLob.values()].map(({_suites,...lob})=>({
    ...lob,suites:lob.suites.sort((a,b)=>(a.id===SKIPPED_SUITE?1:0)-(b.id===SKIPPED_SUITE?1:0)||a.label.localeCompare(b.label))
  })).sort((a,b)=>{
    const ai=order.indexOf(a.id),bi=order.indexOf(b.id);
    return (ai<0?999:ai)-(bi<0?999:bi)||a.label.localeCompare(b.label);
  });
}
export function filterMethods(methods,{lob='',suite='',q=''}={}){
  const term=String(q).toLowerCase().trim();
  return methods.filter(m=>(!lob||m.lob===lob)&&(!suite||(suite===SKIPPED_SUITE?Boolean(m.skipped):m.suite===suite&&!m.skipped))&&
    (!term||m.id.toLowerCase().includes(term))).sort((a,b)=>a.id.localeCompare(b.id));
}
