iGERO SIMPLE MIGRATION v2.5 — RUNNER RESOLUTION & DOWNLOADABLE DIAGNOSTICS
===========================================================================

This is a focused fix built on v2.4 (vertical white/pink/blue interface,
LOB/Suite filters, file checkmarks, button spinners, Copilot two-step workflow).
The original source and Excel workbooks are never intentionally edited.

WHY IT WAS CHANGED
- Earlier versions invoked 'npx --no-install playwright test' for --list.
  On Windows, npx may resolve a CLI that is different from the copy inside
  the selected Playwright repository. This is a possible cause of the
  continued 0-tests reports; it has NOT yet been confirmed on your PC.
- The previous isolated diagnostic used a .spec.cjs sample. The new one
  uses a .spec.ts sample, like the project's migrated tests.
- When a project still registers zero tests, the raw isolated-probe output
  and the exact selected runner are captured, not hidden behind a generic
  NO_TESTS message.

WHAT v2.5 DOES
1. Prefers <PlaywrightRoot>\\node_modules\\playwright\\cli.js using the SAME
   Node executable that launched the panel. It next tries
   node_modules\\@playwright\\test\\cli.js. npx is a fallback only.
2. Diagnoses the configured real project via --list WITHOUT opening Chrome.
3. Preserves all generated JSON, prompt and spec files regardless of --list.
4. Adds 'Download diagnostics JSON' next to 'Diagnose Playwright config'.
5. Retains Step 4 registration and Functional Check gates; no skipped test or
   fabricated assertion may become a PASS.

INSTALL ON WINDOWS
1. Stop all prior iGero server cmd windows.
2. Extract this ZIP and replace the old igero_html_launcher folder contents.
3. Keep your own config.local.json if it exists.
4. Double-click Start-iGero-HTML.cmd and Ctrl+F5 in the browser.

NEXT ACTION (NO AI CREDITS)
1. Select a simple HOME content-validation method (not Quote & Bind).
2. Click 'Diagnose Playwright config'.
3. Click 'Download diagnostics JSON'.
4. If registered tests are 0, read the runner origin, attempts' outputTail,
   runnerIsolation.status and runnerIsolation.outputTail. Share the JSON for
   a project-specific repair before re-running Copilot.

If the isolated probe fails too, do NOT assume testDir is the cause.
The local Node/Playwright CLI or module resolution may be broken.
If the probe passes but the real config lists zero tests, inspect the
config-specific testDir/testMatch/testIgnore and generated test registration.

VALIDATION
- 30/30 Node regression tests PASS.
- Existing mocked server integration tests PASS.
- Offline Chromium diagnostics download test PASS.
- No access to the live Windows project or Farmers QA was available.
- Version 2.5 is NOT certified as an end-to-end Farmers functional fix.

SECURITY
Use only under company-approved local tooling rules. Functional QA execution
of bank, payment, Bind, purchase, email or policy binding still needs explicit
authorization. A generated file or typecheck result is never Functional PASS.
