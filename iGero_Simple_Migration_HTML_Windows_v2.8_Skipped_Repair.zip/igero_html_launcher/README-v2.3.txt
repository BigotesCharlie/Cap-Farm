iGero Simple Migration v2.3 — Vertical Workspace

This is a UI-only release built on v2.2. All server-side runner preflight, registry repair, Copilot migration, Java read-only behavior and functional verification logic remain unchanged.

What changed:
- One vertical column for System Readiness, Project Configuration, Java selection, Java preview, Migration setup, Generated Files, and Functional TC Check.
- The five existing migration command buttons stay sticky at the top of the viewport. Their IDs and event handlers are unchanged.
- Migration checks are at the end of the page, after Functional TC Check.
- LIVE Copilot logs follow the migration checks.
- Entire interface palette changed to white, pink and blue.
- No page-wide horizontal scrolling; long paths, logs and code wrap inside their own panels.
- All UI text remains English.

Install:
1. Close the previous iGero local server.
2. Extract this ZIP, replacing old app files but preserving your private config.local.json.
3. Double-click Start-iGero-HTML.cmd.
4. Refresh the browser with Ctrl+F5.

The runner discovery problem (0 registered tests) remains a separate Playwright project issue: these changes do not claim to repair or certify any real Farmers tests.
