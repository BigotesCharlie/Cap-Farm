iGero Simple Migration v2.6 — MINIMAL ENHANCEMENTS ON TOP OF v2.5
===================================================================

BASELINE / PROTECTION
---------------------
This package is a narrowly patched copy of the working v2.5 package.
No config.local.json, Java source, Excel workbook, test case, or migration
artifact is bundled or overwritten by the ZIP. The current config.local.json
inside your installed launcher contains your two project paths and settings.
BACK IT UP before replacing code, then keep it in place.
The companion BASELINE-v2.5-SHA256.txt identifies the original v2.5 ZIP.

Only these existing application files changed:
  lob-catalog.mjs — virtual SKIPPED SCENARIOS suite in each LOB
  server.mjs — source-disabled TestNG detection; skip safety; eligible Chrome
  app.js — expandable Migration Checks; skipped-method labels; auto-run checkbox
  index.html — accordion styles and auto-run rule text
  VERSION.txt — v2.6 label
The original v2.5 handlers for Copilot extraction, implementation, Playwright
runner and registry, JSON reporting, artifact marks and button spinners remain.

1. SKIPPED SCENARIOS
--------------------
For each Line of Business, a virtual 'SKIPPED SCENARIOS' suite appears ONLY if
explicitly disabled Java TestNG methods are found. It recognizes:
  @Test(enabled=false)       (including multiline annotations)
  @Ignore / @Disabled        (when attached to the Java @Test method)
Regular class suites exclude these disabled methods; the virtual suite lists
them instead. Java files and original suite membership are not edited.

This is source-defined skip; conditional runtime SkipException and environmental
restrictions cannot always be statically classified, and do not automatically
become a permanently disabled test.

A Java-disabled method may still be exported/migrated on request, but its
Functional TC Check is SOURCE_TEST_SKIPPED and NEVER launches Chrome or claims
Functional PASS. Missing mandatory source dependencies are not resolved by
removing 'test.skip' from generated specs.

2. AUTOMATIC HEADED BROWSER FOR ELIGIBLE TCs
--------------------------------------------
The launcher automatically attempts the focused Playwright Chrome execution
after TypeScript validation for every enabled, source-aligned and safe migrated
TC. The previous optional 'autoFunctionalCheck' setting no longer suppresses
an eligible execution; the HTML shows this policy as always enabled.

No browser launches when:
  - Java explicitly disables the TC (SKIPPED SCENARIOS)
  - The source/contract targets payment, banking, Bind, purchasing, email or
    similar sensitive business side effects without separately established
    QA/business execution approval
  - TypeScript, Playwright discovery or other required gates fail
  - The user explicitly stops the process
These are reported as SKIPPED / BLOCKED / NOT EXECUTED, never PASS.
Browser runs remain headed, with 1 worker, 0 retries and a focused TC.
The launcher does NOT automatically approve QA transactions.

3. EXPANDABLE MIGRATION CHECKS
------------------------------
In Section 7, click any check row (green/yellow/red/gray) to expand:
  Expected — the requirement for that stage
  Observed — the actual response/status note from the runner
  Status   — PASS/RUNNING/BLOCKED/SKIPPED/PENDING
Open rows remain expanded when LIVE status updates arrive.

UPGRADE STEPS
-------------
1. Stop every prior iGero launcher/server process.
2. Make a backup copy of your existing config.local.json and any local logs.
3. Extract this ZIP and copy the igero_html_launcher files over your existing
   launcher installation. Do not delete the existing folder first.
4. Keep your ORIGINAL config.local.json. This ZIP does not contain that file.
5. Double click Start-iGero-HTML.cmd and refresh http://127.0.0.1:8766/.
6. Select a LOB. Disabled Java methods (if present) are found in the virtual
   SKIPPED SCENARIOS suite; enabled methods stay in their Java class suites.
7. Expand Section 7 checks to see Expected / Observed / Status.

VALIDATION SCOPE
----------------
Regression tests of the launcher, source skipped grouping, mock focused
Playwright execution, browser UI and responsive layout were run locally.
This does NOT certify a real Chrome run against Farmers QA on your Windows PC.
Functional PASS must be established by real Playwright evidence and the
source-required assertions; passing typecheck or file creation is insufficient.

Support boundaries: no migrations in Auto/Bundle/etc performed by this update;
existing LOB selections and project paths are unchanged.
