/**
 * Resolve the Playwright runner belonging to the selected TypeScript repository.
 * Using the launcher Node executable and the project-local CLI avoids npx PATH
 * resolution selecting a different Playwright installation on Windows.
 * Never invokes QA; only returns a command specification.
 */
import fs from 'node:fs';
import path from 'node:path';

export function resolvePlaywrightInvocation(projectRoot, cliArgs, options={}) {
  const exists = options.exists || fs.existsSync;
  const nodeExecutable = options.nodeExecutable || process.execPath;
  const platform = options.platform || process.platform;
  const localCandidates = [
    path.join(projectRoot,'node_modules','playwright','cli.js'),
    path.join(projectRoot,'node_modules','@playwright','test','cli.js'),
  ];
  for (const candidate of localCandidates) {
    if (exists(candidate)) {
      return {
        cmd:nodeExecutable,
        args:[candidate,'test',...cliArgs],
        origin:'project-local-cli',
        executable:candidate,
      };
    }
  }
  if(platform==='win32') {
    const escape = x => `"${String(x).replace(/["\r\n]/g,'')}"`;
    return {
      cmd:'cmd.exe',
      args:['/d','/s','/c',`npx --no-install playwright test ${cliArgs.map(escape).join(' ')}`],
      origin:'npx-fallback',
      executable:'npx --no-install playwright',
    };
  }
  return {cmd:'npx', args:['--no-install','playwright','test',...cliArgs], origin:'npx-fallback',executable:'npx --no-install playwright'};
}
