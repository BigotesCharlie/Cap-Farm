const $ = id => document.getElementById(id);
const stepNames = ['Locate Java method','Copilot: generate JSON + prompt.md','Validate generated contract','Discover and map registered Playwright test','Validate TypeScript','Functional TC Check — Playwright','Save results'];
let selected = '', selectedTab='json', cachedOutput={}, liveJob=null, methodList=[];
let lastDiscoveryDiagnostic=null;
let lobCatalog=[], currentLob='', currentSuite='', methodRequestId=0;
function text(id,s){$(id).textContent=s}
// Every button shows an activity spinner when clicked. Long operations retain
// their spinner until the request finishes; migration commands retain it until
// their SSE job reaches a terminal status. No decorative/inert indicators.
let activeJobButtonId=null;
let lastAutoDiscoveredJobId=null;
const clickSpinnerTimers=new WeakMap();
function spin(btn,keep=false){
  if(!btn||btn.disabled)return;
  btn.classList.add('action-loading');btn.setAttribute('aria-busy','true');
  const pending=clickSpinnerTimers.get(btn);if(pending)clearTimeout(pending);
  if(keep){clickSpinnerTimers.set(btn,null);return;}
  clickSpinnerTimers.set(btn,setTimeout(()=>{if(btn.dataset.longBusy!=='1'){btn.classList.remove('action-loading');btn.removeAttribute('aria-busy');}clickSpinnerTimers.delete(btn);},550));
}
function stopSpin(btn){if(!btn)return;const pending=clickSpinnerTimers.get(btn);if(pending)clearTimeout(pending);clickSpinnerTimers.delete(btn);btn.dataset.longBusy='0';btn.classList.remove('action-loading');btn.removeAttribute('aria-busy');}
async function withSpin(id,fn){const btn=typeof id==='string'?$(id):id;if(btn){btn.dataset.longBusy='1';spin(btn,true);}try{return await fn();}finally{if(btn){btn.dataset.longBusy='0';setTimeout(()=>stopSpin(btn),180);}}}
document.addEventListener('click',e=>{const btn=e.target.closest('button');if(!btn||btn.disabled)return;spin(btn,btn.dataset.longBusy==='1');},true);
function setFileMark(id,exists,valid){const el=$(id);if(!el)return;const ok=Boolean(exists&&valid);el.className='file-mark '+(ok?'present':'missing');el.textContent=ok?'✓':'✗';el.title=ok?'Generated and basic file identity verified':'Missing or invalid artifact';el.setAttribute('aria-label',el.title);}
function renderFileMarks(result){const status=result?.fileStatus||{};
 setFileMark('fileStatusJson',status.json?.exists??result?.json,status.json?.valid??result?.json);
 setFileMark('fileStatusPrompt',status.prompt?.exists??result?.prompt,status.prompt?.valid??result?.prompt);
 setFileMark('fileStatusSpec',status.spec?.exists??result?.specExists,status.spec?.valid??result?.specExists);
}

function enableControls(running){for(const id of ['extractBtn','migrateBtn','allBtn','functionalBtn','saveBtn','reloadMethods','discoverSpecBtn','repairRegistryBtn','discoveryDiagnoseBtn','lobSelect','suiteSelect','methodSearch'])$(id).disabled=running; $('stopBtn').disabled=!running; const id=$('manualId').value.trim()||selected; const f=(liveJob?.methodId===id?liveJob.functional:cachedOutput?.functional); $('repairSkippedBtn').disabled=running||!['SKIPPED_RUNTIME','PARTIALLY_SKIPPED','SKIPPED_IMPLEMENTATION'].includes(f?.verdict);}
async function request(url,body){const opts=body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)};const r=await fetch(url,opts);const obj=await r.json();if(!r.ok)throw new Error(obj.error||`HTTP ${r.status}`);return obj;}
function err(e){text('pathStatus',e.message);$('pathStatus').className='status bad';addLog({text:e.message,kind:'error',t:new Date().toLocaleTimeString()})}
function renderSystem(data){
  const grid=$('readinessGrid');grid.replaceChildren();
  const labels={node:'Node.js',copilot:'GitHub Copilot CLI',java:'Selenium Java source',target:'Playwright target',playwright:'Playwright dependencies',authentication:'Copilot authentication'};
  for(const [key,label] of Object.entries(labels)){
    const c=data.checks?.[key]||{status:'INFO',value:'UNKNOWN',detail:'No data'};
    const box=document.createElement('div');box.className='readinessitem '+c.status.toLowerCase();
    const title=document.createElement('strong');title.textContent=label;
    const badge=document.createElement('span');badge.className='readystatus';badge.textContent=c.status;
    const heading=document.createElement('strong');heading.append(document.createTextNode(label),badge);
    const value=document.createElement('code');value.textContent=c.value||'';
    const detail=document.createElement('p');detail.textContent=c.detail||'';
    box.append(heading,value,detail);grid.append(box);
  }
  const ready=data.migrationReady;
  text('systemVerdict',ready?'READY':data.functionalReady?'COPILOT NOT READY':'ACTION REQUIRED');
  $('systemVerdict').className='status '+(ready?'ok':'bad');
  text('systemNotes',data.note+' · Login is not checked by version probing. Configure QA runtime separately if test discovery reports a missing environment URL.');
  text('runtimeStatus',data.migrationReady?`Local service connected · Node ${data.checks?.node?.value||'available'} · Copilot CLI ready · Playwright dependencies ready`:
    `Local service connected · ${data.functionalReady?'Copilot CLI needs attention':'Check System Readiness for missing prerequisites'}`);
}
async function refreshSystem(){
  $('systemBtn').disabled=true;text('systemVerdict','CHECKING');
  try{renderSystem(await request('/api/system'))}catch(e){text('systemVerdict','CHECK FAILED');err(e)}
  finally{$('systemBtn').disabled=false}
}
// Details disclose the expected gate and the actual recorded outcome; status remains unchanged.
const stepExpectations=[
  'The selected Java @Test exists in the requested LOB/suite; Java and Excel remain unchanged.',
  'Copilot exports a method-specific contract.json and prompt.md without editing Java or Excel.',
  'contract.json and prompt.md parse correctly and match the selected Java class and method.',
  'The active Playwright configuration registers the exact target test; source-disabled Java tests remain SKIPPED.',
  'Target TypeScript compiles with the existing project configuration; compilation is not a functional PASS.',
  'Every source-enabled, QA-authorized, non-sensitive TC attempts a headed Chrome run; actual assertions determine the result. Explicitly disabled Java tests and sensitive operations must not be launched.',
  'Generated artifacts and genuine execution evidence are preserved in the TypeScript project, with source Java untouched.'
];
function renderSteps(steps){const cont=$('checklist');const expanded=new Set([...cont.querySelectorAll('details[open]')].map(el=>el.dataset.step));cont.replaceChildren();(steps||stepNames.map(name=>({name,status:'pending'}))).forEach((s,i)=>{
  const el=document.createElement('details');el.className='checkrow '+s.status;el.dataset.step=String(i);el.open=expanded.has(String(i));
  const header=document.createElement('summary');header.className='checksummary';
  const dot=document.createElement('span');dot.className='circle';dot.textContent={pass:'✓',running:'◌',blocked:'×',skipped:'—',pending:'·'}[s.status]||'·';
  const box=document.createElement('span');box.className='checkname';const title=document.createElement('b');title.textContent=s.name;
  const label=document.createElement('span');label.textContent=s.note||({pass:'PASS',running:'Running…',blocked:'BLOCKED',skipped:'Skipped',pending:'Pending'}[s.status]);box.append(title,label);
  header.append(dot,box);el.append(header);
  const detail=document.createElement('div');detail.className='checkdetails';
  const expected=document.createElement('p');const strong=document.createElement('strong');strong.textContent='Expected: ';expected.append(strong,document.createTextNode(stepExpectations[i]||'Source-defined gate completes without regression.'));
  const actual=document.createElement('p');const lab=document.createElement('strong');lab.textContent='Observed: ';actual.append(lab,document.createTextNode(s.note||'No result yet.'));
  const status=document.createElement('p');const statusLabel=document.createElement('strong');statusLabel.textContent='Status: ';status.append(statusLabel,document.createTextNode((s.status||'pending').toUpperCase()));
  detail.append(expected,actual,status);el.append(detail);cont.append(el);
});}
function addLog(line){const el=document.createElement('div');el.className='line '+(line.kind||'');el.textContent=`[${line.t||''}] ${line.text||''}`;$('console').append(el);$('console').scrollTop=$('console').scrollHeight;if($('console').childElementCount>280)$('console').firstChild.remove();}
function renderFunctional(result){
  const c=result?.counts||{};text('fcTotal',String(c.total||0));text('fcPassed',String(c.passed||0));text('fcFailed',String(c.failed||0));text('fcSkipped',String(c.skipped||0));
  $('downloadFunctionalBtn').disabled=!result;
  $('repairSkippedBtn').disabled=!['SKIPPED_RUNTIME','PARTIALLY_SKIPPED','SKIPPED_IMPLEMENTATION'].includes(result?.verdict) || Boolean(liveJob?.status==='running');
  const status=result?.verdict||'NOT EXECUTED';text('statRuntime',status==='FUNCTIONAL_PASS'?'PASS':status==='PLAYWRIGHT_PASS_PARITY_UNVERIFIED'?'PW PASS*':status==='FUNCTIONAL_FAILED'?'FAIL':['SKIPPED_SAFETY','SKIPPED_RUNTIME','PARTIALLY_SKIPPED','SKIPPED_IMPLEMENTATION','SOURCE_TEST_SKIPPED'].includes(status)?'SKIP':'—');text('functionalVerdict',status.replaceAll('_',' '));
  $('functionalVerdict').className='status '+(status==='FUNCTIONAL_PASS'?'ok':status==='FUNCTIONAL_FAILED'||status==='REPORT_MISSING'?'bad':'');
  const details=result?.reason || (result?.executedAt?`Executed: ${result.executedAt} · Project: ${result.projectName||'default'} · Java runtime parity: NOT VERIFIED`:
    'No real Playwright functional execution has been recorded for this method.');
  text('functionalMeta',details);
  const cont=$('functionalResults');cont.replaceChildren();
  if(!result?.tests?.length){const empty=document.createElement('p');empty.className='fine';empty.textContent='No individual test results available.';cont.append(empty);return;}
  for(const t of result.tests){
    const box=document.createElement('div');box.className='resultitem '+(t.status==='expected' && t.expectedStatus==='passed'?'pass':t.status==='skipped'?'skip':'fail');
    const name=document.createElement('div');name.className='resulttitle';name.textContent=t.title;
    const meta=document.createElement('div');meta.className='resultmeta';meta.textContent=`${(t.status||'unknown').toUpperCase()} · ${t.duration||0} ms · ${t.project||result.projectName||'default'} · Attempts: ${(t.retries||0)+1}`;
    box.append(name,meta);
    for(const e of t.errors||[]){const er=document.createElement('div');er.className='resultError';er.textContent=e;box.append(er);}
    if(t.steps?.length){const detail=document.createElement('details');const summary=document.createElement('summary');summary.textContent=`Show all ${t.steps.length} recorded Playwright steps`;detail.append(summary);
      for(const st of t.steps){const line=document.createElement('div');line.className='resultstep '+(st.error?'fail':'');line.style.paddingLeft=`${7+Math.min(st.depth||0,6)*9}px`;
        line.textContent=`${st.error?'✗ ':'• '}${st.title} (${st.duration||0} ms)`;detail.append(line);
        if(st.error){const er=document.createElement('div');er.className='resultError';er.textContent=st.error;detail.append(er);}
      }box.append(detail);}
    cont.append(box);
  }
}
function renderJob(job, full=false){
  if (job?.aiCreditsObserved) {
    const measured=Object.entries(job.aiCreditsObserved).filter(([,v])=>Number.isFinite(v));
    const total=measured.reduce((sum,[,v])=>sum+v,0);
    text('aiCreditUsage',measured.length
      ? `AI Credits reported by CLI (approx.): ${total.toFixed(2)} · no manual cap`
      : 'AI Credits: automatic · CLI usage not reported');
  } else text('aiCreditUsage','AI Credits: automatic · usage not reported');
  liveJob=job;if(job?.methodId && job.methodId===($('manualId').value.trim()||selected))renderFunctional(job.functional||null);enableControls(job?.status==='running');if(job?.status!=='running'&&activeJobButtonId){stopSpin($(activeJobButtonId));activeJobButtonId=null;}renderSteps(job?.steps);text('jobSummary',job?`${job.status.toUpperCase()} · ${job.methodId}`:'No active job');const m=$('jobMarker');m.textContent=job?`${job.status==='completed'?'✓ ':job.status==='blocked'?'✕ ':'◌ '}${job.methodId} · ${job.status}`:'No migration started yet';m.className='marker '+(job?.status==='completed'?'ready':job?.status==='blocked'?'block':job?.status==='partial'?'warn':'');if(full&&job?.logs){$('console').replaceChildren();job.logs.forEach(addLog)}if(job?.status==='completed'||job?.status==='blocked'||job?.status==='partial')refreshOutputs().catch(()=>{});if(job?.status==='blocked' && /AMBIGUOUS_TEST_MAPPING/.test(job.error||'') &&
    job?.methodId===selected && job.id!==lastAutoDiscoveredJobId){
    lastAutoDiscoveredJobId=job.id;
    // Display exact registered choices automatically. The next action requires
    // a real click; never silently spend credits or launch a browser.
    discoverSpecChoices().catch(e=>addLog({t:new Date().toLocaleTimeString(),kind:'warning',text:'Could not load test choices: '+e.message}));
  }}
function renderMethods(items){const container=$('methodList');container.replaceChildren();if(!items.length){const p=document.createElement('p');p.className='fine';p.textContent='No Java @Test methods match this suite and search. Choose another suite or clear the search.';container.append(p);return;}for(const item of items){const btn=document.createElement('button');btn.className='method'+(selected===item.id?' on':'');const strong=document.createElement('b');strong.textContent=item.id;const small=document.createElement('small');small.textContent=item.relativePath+(item.skipped?' · SOURCE SKIPPED ('+item.skipReason+')':'');btn.append(strong,small);btn.addEventListener('click',()=>withSpin(btn,()=>selectMethod(item.id)).catch(err));container.append(btn);}}
async function selectMethod(id){
  if(!methodList.some(m=>m.id===id&&m.lob===currentLob&&m.suite===currentSuite)){
    throw new Error('Select a method displayed in the selected Line of Business and suite.');
  }
  selected=id;resetSpecChoices();$('manualId').value=id;renderMethods(methodList);
  text('javaPreview','Loading Java source…');
  try{const m=await request('/api/method-preview?id='+encodeURIComponent(id));
    if(selected!==id)return;
    text('javaPreview',m.javaPreview);$('javaPreview').classList.remove('empty');
    text('javaFilePath',m.relativePath+(m.skipped?' · SKIPPED SCENARIOS · '+m.skipReason:''));await refreshOutputs();
  }catch(e){err(e)}
}
function clearMethodSelection(){
  renderFileMarks(null);
  selected='';$('manualId').value='';cachedOutput={};resetSpecChoices();renderDiscoveryDiagnostic(null);
  text('javaFilePath','No method selected');text('javaPreview','Select a method from this suite to preview its Java code.');
  $('javaPreview').classList.add('empty');text('outputDir','No generated artifacts');
  text('statJson','0');text('statPrompt','0');text('generatedPreview','Generated artifacts will appear here.');
  renderFunctional(null);
}
function populateSuiteOptions(preferred=''){
  const lob=lobCatalog.find(x=>x.id===currentLob);const suites=lob?.suites||[];
  const select=$('suiteSelect');select.replaceChildren();
  if(!suites.length){const option=new Option('No suites available','');select.add(option);currentSuite='';return;}
  for(const suite of suites){const option=new Option(`${suite.label} · ${suite.count} methods`,suite.id);option.title=suite.relativePath;select.add(option);}
  currentSuite=suites.some(s=>s.id===preferred)?preferred:suites[0].id;
  select.value=currentSuite;
}
async function refreshCatalog(force=false){
  const previousLob=currentLob,previousSuite=currentSuite;
  const data=await request('/api/lob-catalog'+(force?'?refresh=1':''));
  lobCatalog=data.lobs||[];
  const lobSelect=$('lobSelect');lobSelect.replaceChildren();
  if(!lobCatalog.length){lobSelect.add(new Option('No Java LOBs found',''));currentLob='';currentSuite='';methodList=[];renderMethods([]);text('methodCount','0');return;}
  for(const lob of lobCatalog)lobSelect.add(new Option(`${lob.label} · ${lob.count} methods`,lob.id));
  currentLob=lobCatalog.some(l=>l.id===previousLob)?previousLob:(lobCatalog.find(l=>l.id==='home')||lobCatalog[0]).id;
  lobSelect.value=currentLob;populateSuiteOptions(previousLob===currentLob?previousSuite:'');
  clearMethodSelection();await refreshMethods();
}
async function refreshMethods(){
  const requestId=++methodRequestId;
  if(!currentLob||!currentSuite){methodList=[];renderMethods([]);text('methodCount','0');return;}
  try{
    const params=new URLSearchParams({q:$('methodSearch').value.trim(),lob:currentLob,suite:currentSuite});
    const data=await request('/api/methods?'+params.toString());
    if(requestId!==methodRequestId||data.lob!==currentLob||data.suite!==currentSuite)return;
    methodList=data.methods;text('methodCount',data.filteredTotal);
    const lob=lobCatalog.find(x=>x.id===currentLob);
    const suite=lob?.suites.find(s=>s.id===currentSuite);
    text('suiteSummary',`${lob?.label||''} / ${suite?.label||''} — ${data.filteredTotal} matching @Test methods · ${suite?.relativePath||''}`);
    renderMethods(methodList);
  }catch(e){err(e)}
}
async function refreshOutputs(){const id=($('manualId').value.trim()||selected);if(!id){renderFileMarks(null);return;}try{const out=await request('/api/outputs?id='+encodeURIComponent(id));if(id!==($('manualId').value.trim()||selected))return;cachedOutput=out;renderFileMarks(out);text('statJson',out.json?'1':'0');text('statPrompt',out.prompt?'1':'0');text('outputDir',out.outputDir);displayGenerated();if(liveJob?.methodId===id)renderFunctional(liveJob.functional||null);else renderFunctional(out.functional||null);}catch(e){renderFileMarks(null);err(e);}}
function displayGenerated(){const display=selectedTab==='json'?(cachedOutput.contract||'contract.json does not exist yet'):(selectedTab==='prompt'?(cachedOutput.prompt||'prompt.md does not exist yet'):(cachedOutput.specPreview||'The .spec.ts has not been found yet'));text('generatedPreview',display);$('tabJson').classList.toggle('on',selectedTab==='json');$('tabPrompt').classList.toggle('on',selectedTab==='prompt');$('tabSpec').classList.toggle('on',selectedTab==='spec');}
function resetSpecChoices(){const sel=$('specChoice');sel.replaceChildren();const opt=document.createElement('option');opt.value='';opt.textContent='Automatic (match registered Playwright test)';sel.append(opt);text('specChoiceStatus','The Playwright test title may differ from its Java method name. Discover registered tests if mapping is ambiguous.');}
async function discoverSpecChoices(){const id=$('manualId').value.trim()||selected;if(!id)throw new Error('Select a Java method first.');
  const data=await request('/api/spec-candidates?id='+encodeURIComponent(id));resetSpecChoices();
  if(data.diagnostics)renderDiscoveryDiagnostic(data.diagnostics);
  for(const item of data.entries){if(!item.runnable||!item.eligible)continue;const opt=document.createElement('option');opt.value=JSON.stringify({relativePath:item.relativePath,line:item.line,title:item.title,project:item.project});opt.textContent=`[${item.project}] ${item.relativePath}:${item.line} › ${item.title}`;$('specChoice').append(opt)}
  text('specChoiceStatus',data.discoveryError|| (data.registered===1?'One source-mapped registered test found. Automatic selection is available.':
    data.registered>1?`${data.registered} distinct runnable tests (${data.rawRegistrations||data.registered} browser registrations). Choose the correct spec/title, then click Run Functional TC Check — do not regenerate JSON or TypeScript.`:
    (data.entries.some(e=>!e.runnable)
      ? `Found .spec.ts file(s) outside active test discovery: ${data.entries.filter(e=>!e.runnable).map(e=>e.relativePath).slice(0,3).join(', ')}. Playwright globally lists ${data.globallyListed} test entries. Fix testDir/testMatch or generate a dedicated registered spec.`
      : `No source-mapped registered test found among ${data.globallyListed} Playwright entries. Check active testDir and exact test title.`)));
}
async function start(mode){const id=selected;if(!id||!methodList.some(m=>m.id===id&&m.lob===currentLob&&m.suite===currentSuite)){err(new Error('Select a Java test method from the chosen suite before starting.'));return}const btnId={extract:'extractBtn',migrate:'migrateBtn',all:'allBtn',functional:'functionalBtn'}[mode];activeJobButtonId=btnId;const btn=$(btnId);if(btn){btn.dataset.longBusy='1';spin(btn,true);}try{const testSelection=$('specChoice').value?JSON.parse($('specChoice').value):null;const result=await request('/api/start',{methodId:id,mode,testSelection,lob:currentLob,suite:currentSuite});$('console').replaceChildren();addLog({t:new Date().toLocaleTimeString(),text:`Started ${mode}: ${result.id}`,kind:'success'});renderFunctional(null);const job=await request('/api/job');renderJob(job);}catch(e){if(activeJobButtonId===btnId){activeJobButtonId=null;stopSpin(btn);}err(e)}}
async function requestSkipRepair(){
  const id=$('manualId').value.trim()||selected;
  if(!id)throw new Error('Select a Java test method first.');
  const result=liveJob?.methodId===id?liveJob.functional:cachedOutput?.functional;
  if(!['SKIPPED_RUNTIME','PARTIALLY_SKIPPED','SKIPPED_IMPLEMENTATION'].includes(result?.verdict))throw new Error('Run Functional TC Check and obtain a real SKIPPED result first.');
  text('functionalMeta','Focused repair requested. Only the selected TC may be edited; no browser will launch during repair.');
  const r=await request('/api/repair-skipped-test',{methodId:id});
  text('functionalMeta',r.note||'Repair completed. Run Functional TC Check again to verify.');
  addLog({t:new Date().toLocaleTimeString(),kind:'warning',text:r.note||'Skip repair returned. Run Functional TC Check to verify the result.'});
  await refreshOutputs();
}
$('repairSkippedBtn').addEventListener('click',()=>withSpin('repairSkippedBtn',requestSkipRepair).catch(err));
async function init(){renderSteps();await refreshSystem();const cfg=await request('/api/config');$('javaRoot').value=cfg.javaRoot;$('pwRoot').value=cfg.playwrightRoot;$('typecheck').checked=cfg.autoTypecheck;$('functionalCheck').checked=true;$('testEnv').value=cfg.testEnv||'MA11';showPath(cfg);await refreshCatalog().catch(err);const job=await request('/api/job');renderJob(job,true);}
function showPath(c){const yes=c.javaExists&&c.targetExists;text('pathStatus',`Java: ${c.javaExists?'OK':'UNAVAILABLE'} · Playwright: ${c.targetExists?'OK':'UNAVAILABLE'}`);$('pathStatus').className='status '+(yes?'ok':'bad');text('connectionBadge',yes?'● Projects connected':'● Check project paths');}
$('verifyBtn').addEventListener('click',()=>withSpin('verifyBtn',async()=>{try{const c=await request('/api/config');showPath(c);await refreshSystem()}catch(e){err(e)}}));
$('systemBtn').addEventListener('click',()=>withSpin('systemBtn',refreshSystem));
$('saveBtn').addEventListener('click',()=>withSpin('saveBtn',async()=>{try{const c=await request('/api/config',{javaRoot:$('javaRoot').value.trim(),playwrightRoot:$('pwRoot').value.trim(),autoTypecheck:$('typecheck').checked,autoFunctionalCheck:true,testEnv:$('testEnv').value});showPath(c);await refreshSystem();selected='';$('manualId').value='';text('javaPreview','Select a method to preview its Java code.');await refreshCatalog(true)}catch(e){err(e)}}));
$('reloadMethods').addEventListener('click',()=>withSpin('reloadMethods',()=>refreshCatalog(true)).catch(err));
$('lobSelect').addEventListener('change',async()=>{currentLob=$('lobSelect').value;populateSuiteOptions();$('methodSearch').value='';clearMethodSelection();await refreshMethods();});
$('suiteSelect').addEventListener('change',async()=>{currentSuite=$('suiteSelect').value;$('methodSearch').value='';clearMethodSelection();await refreshMethods();});
$('discoverSpecBtn').addEventListener('click',()=>withSpin('discoverSpecBtn',discoverSpecChoices).catch(err));

function renderDiscoveryDiagnostic(d){
  lastDiscoveryDiagnostic=d||null;
  const el=$('discoveryDiagnostic');if(!d){el.style.display='none';el.textContent='';return;}
  el.style.display='block';
  const lines=[`Playwright registry: ${d.status||'UNKNOWN'}`,`Project: ${d.cwd||''}`,`Environment: ${d.environment||''}`,
    `Selected config: ${d.activeConfig||'NONE (no config registered tests)'}`,'',
    'Configuration attempts:'];
  for(const a of d.attempts||[]){
    lines.push(` • ${a.config}: ${a.registered} registered (exit ${a.exitCode}) via ${a.runner||'unknown runner'}`);
    if(a.runnerExecutable)lines.push(`   CLI: ${a.runnerExecutable}`);
    for(const msg of (a.outputTail||[]).filter(x=>/no tests|error|configure|failed|testdir|testmatch/i.test(x)).slice(0,2))lines.push('   '+msg);
  }
  if(d.configHints?.length){
    lines.push('', 'Configuration source hints (non-executing):');
    for(const h of d.configHints){
      lines.push(` • ${h.config}: testDir=${h.testDir||'dynamic/default'}, testMatch=${h.testMatch||'dynamic/default'}, testIgnore=${h.testIgnore||'dynamic/default'}${h.dynamicEnvironment?' [environment-dependent]':''}`);
    }
  }
  if(d.runnerIsolation){lines.push('',`Isolated Playwright registry probe: ${d.runnerIsolation.status} (exit ${d.runnerIsolation.exitCode??'unknown'})`,d.runnerIsolation.note||'');if(d.runnerIsolation.status==='FAIL')lines.push(d.runnerIsolation.outputTail||'');}
  if(d.registryDiagnosis)lines.push('',`Diagnosis: ${d.registryDiagnosis.code}`,d.registryDiagnosis.message);
  if(d.specCount!==undefined)lines.push('',`Source spec files found: ${d.specCount}`);
  if(d.relatedSpecs?.length){lines.push('Related source specs:');for(const x of d.relatedSpecs)lines.push(` • ${x.file}${x.skipDeclared?' — test.skip detected':''}`)}
  if(d.nextAction)lines.push('',`Next action: ${d.nextAction}`);
  el.textContent=lines.join('\n');
}
async function diagnosePlaywright(){
  const id=$('manualId').value.trim()||selected;
  if(!id)throw new Error('Select a Java method first.');
  text('specChoiceStatus','Checking Playwright project configuration and registered tests…');
  const d=await request('/api/playwright-diagnostics?id='+encodeURIComponent(id));
  renderDiscoveryDiagnostic(d);
  text('specChoiceStatus',d.status==='REGISTERED'?`Playwright registration OK with ${d.activeConfig}. Now discover runnable tests.`:
    `No registered tests across ${(d.attempts||[]).length} configuration(s). Review the diagnostic panel below; no browser was launched.`);
}
$('discoveryDiagnoseBtn').addEventListener('click',()=>withSpin('discoveryDiagnoseBtn',diagnosePlaywright).catch(err));
$('downloadDiscoveryBtn').addEventListener('click',()=>withSpin('downloadDiscoveryBtn',async()=>{
  if(!lastDiscoveryDiagnostic) await diagnosePlaywright();
  if(!lastDiscoveryDiagnostic) throw new Error('No Playwright diagnostic available to download.');
  const contents=JSON.stringify(lastDiscoveryDiagnostic,null,2);
  const url=URL.createObjectURL(new Blob([contents],{type:'application/json'}));
  const a=document.createElement('a');a.href=url;a.download='igero-playwright-discovery-diagnostics.json';
  document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
}).catch(err));

$('repairRegistryBtn').addEventListener('click',async()=>{
  const id=$('manualId').value.trim()||selected;
  if(!id){err(new Error('Select a Java method before requesting a runner repair.'));return;}
  // A real Copilot call may consume account AI credits. Require one deliberate user action.
  if(!confirm('Run one Copilot repair of the EXISTING Playwright registry? This may use AI credits and change target project files; Java/Excel remain read-only.'))return;
  try {
    $('repairRegistryBtn').dataset.longBusy='1';spin($('repairRegistryBtn'),true);
    $('repairRegistryBtn').disabled=true;
    text('specChoiceStatus','Checking runner isolation and repairing the active project registry once...');
    const result=await request('/api/repair-playwright-registry',{methodId:id});
    renderDiscoveryDiagnostic(result.diagnostics);
    text('specChoiceStatus',`Real Playwright registry recovered: ${result.registered} registered tests. Select Discover runnable tests.`);
  }catch(e){err(e);await diagnosePlaywright().catch(()=>{});}
  finally{$('repairRegistryBtn').disabled=false;stopSpin($('repairRegistryBtn'));}
});
let timer; $('methodSearch').addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(refreshMethods,220)});
// Method selection is intentionally read-only: only the active LOB/suite list can select a test.
$('extractBtn').addEventListener('click',()=>start('extract'));
$('migrateBtn').addEventListener('click',()=>start('migrate'));
$('allBtn').addEventListener('click',()=>start('all'));
$('functionalBtn').addEventListener('click',()=>start('functional'));
$('stopBtn').addEventListener('click',()=>withSpin('stopBtn',async()=>{try{await request('/api/cancel',{});renderJob(await request('/api/job'))}catch(e){err(e)}}));
$('tabJson').addEventListener('click',()=>{selectedTab='json';displayGenerated()});
$('tabPrompt').addEventListener('click',()=>{selectedTab='prompt';displayGenerated()});
$('tabSpec').addEventListener('click',()=>{selectedTab='spec';displayGenerated()});
$('refreshOutput').addEventListener('click',()=>withSpin('refreshOutput',refreshOutputs).catch(err));
$('downloadFunctionalBtn').addEventListener('click',()=>{const result=liveJob?.methodId===($('manualId').value.trim()||selected)?liveJob.functional:cachedOutput.functional;
  if(!result)return;const blob=new Blob([JSON.stringify(result,null,2)],{type:'application/json'});
  const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download='functional-tc-results.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
let previousLogLength=0; const source=new EventSource('/api/events');
source.addEventListener('status',e=>{const job=JSON.parse(e.data);renderJob(job)});
source.addEventListener('log',e=>{addLog(JSON.parse(e.data))});
source.onerror=()=>{text('jobSummary','Live connection interrupted; reconnecting…')};
init().catch(err);
