// Pure classification of actual Playwright JSON reporter outcomes.
// Does not change a test, skip, runner, or QA execution behavior.
export function classifyFunctionalVerdict(counts={},exitCode=1){
  const total=Number(counts.total)||0;
  const passed=Number(counts.passed)||0, failed=Number(counts.failed)||0;
  const skipped=Number(counts.skipped)||0, other=Number(counts.other)||0;
  if(total===0)return 'NO_TEST_RESULTS';
  if(failed>0||other>0||Number(counts.interrupted)>0)return 'FUNCTIONAL_FAILED';
  if(skipped===total)return 'SKIPPED_RUNTIME';
  if(skipped>0)return 'PARTIALLY_SKIPPED';
  if(exitCode===0&&passed===total)return 'PLAYWRIGHT_PASS_PARITY_UNVERIFIED';
  return 'FUNCTIONAL_FAILED';
}
export function runtimeSkipReason(tests=[]){
  const annotations=tests.flatMap(t=>(t.annotations||[]))
    .filter(a=>['skip','fixme'].includes(String(a.type||'').toLowerCase()))
    .map(a=>[a.type,a.description].filter(Boolean).join(': '));
  return annotations.length?`Playwright reported skip/fixme annotation: ${annotations.slice(0,5).join(' | ')}`:
    'Playwright registered the test but skipped it. The reporter did not provide a reason; inspect test.skip/test.fixme, runtime conditions and fixtures. No mandatory assertions were verified.';
}
