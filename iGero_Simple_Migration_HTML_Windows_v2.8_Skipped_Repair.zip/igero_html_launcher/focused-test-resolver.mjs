// iGero: pure, side-effect-free Playwright test discovery helpers.
// Java method identifiers are not necessarily Playwright test titles.
const COMMON = new Set(['ace','home','test','tests','page','lob','content','validation','validate','validations','and','the','of','on','to','for','in','spec','ts','java','method','acehome','data','with','when','from','section']);
export function tokens(value) {
  return [...new Set(String(value).replace(/([a-z\d])([A-Z])/g, '$1 $2').replace(/([A-Z])([A-Z][a-z])/g, '$1 $2').split(/[^a-z\d]+/i).map(x=>x.toLowerCase()).filter(x=>x.length>=2 && !COMMON.has(x)))];
}
export function parsePlaywrightList(output) {
  const found=[];
  for(const raw of String(output||'').split(/\r?\n/)) {
    // Actual Playwright list reporter: [project] › file.spec.ts:line:column › full test title
    const line=raw.replace(/\x1b\[[\d;]*m/g,'');
    // Playwright without named projects omits the leading "[project] ›".
    // Both formats are valid registered tests; do not misclassify as an empty registry.
    const m=line.match(/^\s*(?:\[([^\]]+)\]\s*›\s*)?(.+?\.(?:spec|test)\.[cm]?[jt]sx?):(\d+):(\d+)\s*›\s*(.*?)\s*$/);
    if(!m)continue;
    found.push({project:m[1]||'',listingFile:m[2].replace(/\\/g,'/'),line:Number(m[3]),column:Number(m[4]),title:m[5]});
  }
  return found;
}
export function methodRelevance(sel, relativePath, title, sourceMentionsMethod=false) {
  const wanted=tokens(sel.name);
  const found=tokens(relativePath+' '+title);
  const overlap=wanted.filter(x=>found.includes(x));
  const titleWords=tokens(title);
  const titleOverlap=wanted.filter(x=>titleWords.includes(x));
  return {
    // Strong evidence: a descriptive title and a matching filename (not merely a source comment).
    score:titleOverlap.length*4+overlap.length*2+(sourceMentionsMethod?2:0)+(String(title).includes(sel.name)?20:0),
    evidence:overlap,sourceMentionsMethod,
    eligible:Boolean(title.includes(sel.name) || (overlap.length>=2 && (titleOverlap.length>=1 || sourceMentionsMethod)))
  };
}
// A single Playwright test can be listed once per browser project. Collapse
// only those project variants; distinct files/titles remain distinct tests.
// For a headed Chrome run, the exact desktop Chromium variant is authoritative.
export function canonicalFocusedTests(entries) {
  const groups=new Map();
  for(const entry of entries.filter(x=>x.runnable && x.eligible)) {
    const key=[entry.relativePath,entry.line,entry.title].join('|');
    if(!groups.has(key))groups.set(key,[]);
    groups.get(key).push(entry);
  }
  const result=[];
  for(const group of groups.values()) {
    const desktop=group.filter(x=>/^(chromium|chrome|desktop chrome|google chrome)$/i.test(x.project.trim()));
    if(desktop.length===1)result.push(desktop[0]);
    else if(group.length===1)result.push(group[0]);
    else if(group.every(x=>x.project==='' || x.project===group[0].project))result.push(group[0]);
    else result.push(...group); // Never guess when no unique Chrome target exists.
  }
  return result;
}
export function chooseFocusedTest(entries, methodId, previousManifest=null, explicit=null, opts={}) {
  const valid=entries.filter(x=>x.runnable && x.eligible);
  if(explicit) {
    const chosen=valid.find(x=>x.relativePath===explicit.relativePath && x.title===explicit.title && x.line===Number(explicit.line) && x.project===explicit.project);
    if(!chosen)throw new Error('Selected test is not registered for the selected Java method. Run Discover runnable tests and select a current entry.');
    return chosen;
  }
  const pool=canonicalFocusedTests(valid);
  if(previousManifest?.methodId===methodId){
    const chosen=pool.find(x=>x.specPath===previousManifest.specPath && x.title===previousManifest.testTitle && x.project===previousManifest.project);
    if(chosen)return chosen;
  }
  if(pool.length===1)return pool[0];
  if(pool.length===0)throw new Error('NO_MAPPED_EXECUTABLE_TEST: Playwright registered no confidently mapped test for the Java method. Select a discovered registered test or implement a dedicated test; no browser was launched.');

  // Only a unique, registered test from a file modified in THIS operation may
  // break a true source-file ambiguity. A prior/untouched match is not evidence.
  const touched=new Set(opts.touchedSpecs||[]);
  const current=pool.filter(x=>touched.has(x.specPath));
  if(current.length===1)return current[0];
  if(current.length>1)throw new Error(`AMBIGUOUS_TEST_MAPPING (${pool.length} distinct tests; ${valid.length} browser-project registrations): Copilot changed multiple registered specs. Select one exact title in the dashboard before functional execution.`);

  const [className,methodName]=String(methodId).split('#');
  // An exact method-specific test title is stronger than token similarity.
  // Never use generic shared suite titles or source comments as proof.
  const exactTitle=pool.filter(x=>String(x.title).includes(methodName));
  if(exactTitle.length===1)return exactTitle[0];
  // An exact source-class+method filename is an acceptable target only if unique.
  const fullName=(className+'.'+methodName).toLowerCase();
  const exactFile=pool.filter(x=>String(x.relativePath).toLowerCase().includes(fullName));
  if(exactFile.length===1)return exactFile[0];

  throw new Error(`AMBIGUOUS_TEST_MAPPING (${pool.length} distinct tests; ${valid.length} browser-project registrations): select the exact Playwright-registered test in the dashboard and click Run Functional TC Check. No browser was launched.`);
}
