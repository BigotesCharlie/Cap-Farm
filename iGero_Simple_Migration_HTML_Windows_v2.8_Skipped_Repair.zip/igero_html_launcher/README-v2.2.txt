iGERO SIMPLE MIGRATION v2.2 — REGISTRY PREFLIGHT & CONTROLLED REPAIR
===================================================================

WHAT THE SCREENSHOTS PROVED
--------------------------
- iGero generated contract.json, prompt.md and a .spec.ts file.
- The target project contained 491 candidate .spec.ts files on disk.
- Playwright --list returned 0 registered tests in three configurations.
- Playwright did not open a browser. This is NOT a TC functional failure.
- A .spec.ts file on disk is NOT proof that Playwright can collect it.
- A test.skip scenario cannot be counted as a functional PASS.

IMPORTANT: We do NOT have the actual corporate Playwright checkout here.
The specific cause of its zero-test registry (testDir/testMatch/testIgnore,
project filter, nested root, or another config constraint) must be resolved
on the user's Windows machine. Do not claim it is repaired from simulation.

NEW IN v2.2
-----------
1. A real-project Playwright registry preflight runs BEFORE a new migration
   invokes Copilot. If the existing project registers ZERO tests, extraction
   and TypeScript generation are not started in Run full migration mode.
   This avoids spending hundreds of credits on a broken test runner.
2. The 'Diagnose Playwright config' button now performs an isolated, no-browser
   Playwright registry probe using a temporary dummy test and its own config.
   The probe is removed after the check. No user test is executed.
   It separates 'Playwright CLI itself cannot register tests' from 'the
   existing project configuration excludes all tests'.
3. 'Repair Playwright Registry' triggers ONE EXPLICIT, bounded Copilot repair
   to the actual target project configuration ONLY if the isolated runner
   is healthy and the original project still registers zero tests. The repair
   is verified with a new real-project --list call.
4. Source Java and Excel remain read-only by policy and checks. Existing
   TypeScript tests and verified assertions are preserved; no fake PASS.
5. A Playwright runtime PASS with independent Java parity still unverified
   remains PARTIAL rather than claiming a fully certified Java migration.
6. All labels and runtime messages remain in English. LOB/Suite dropdowns,
   auto AI credits and existing HTML controls remain unchanged.

HOW TO USE
----------
1. CLOSE every old iGero server process; otherwise the browser will still
   connect to the older version running at port 8766.
2. Back up your current launcher and Playwright workspace.
3. Extract this ZIP and replace the existing igero_html_launcher files.
   Keep config.local.json from your old installation (not included in ZIP).
4. Start Start-iGero-HTML.cmd and refresh with Ctrl+F5.
5. Select Home > the relevant Java TestNG class > the selected Java method.
6. Click 'Diagnose Playwright config'. Read the new 'Isolated Playwright
   registry probe' line:
   - PASS + 0 project tests means runner works, project config excludes tests.
   - FAIL means fix Playwright CLI/package resolution first.
7. If the probe PASSes while the real project lists 0, click
   'Repair Playwright Registry' ONCE. This triggers a Copilot AI call and may
   modify target project files (not Java/Excel). It does not launch Chrome.
8. If the repair reports registered tests, click 'Discover runnable tests'.
   To certify a SAFE, source-implemented selected method, execute the focused
   Functional TC Check in visible Chrome, as permitted by QA policy.
9. If the spec contains test.skip, resolve its genuine mandatory Java source
   dependencies first; never remove skip or assert true just to fake PASS.
10. Do NOT use this functional runner for Bind, payments, bank, purchase,
    email or policy-binding tests without separately approved business actions.

NO ASSUMPTION OF SUCCESS
------------------------
The bundled regressions run with mocked projects and fake tools. They do NOT
connect to Farmers MA11, consume GitHub AI credits or verify the user's real
repository. The actual baseline/config fix is complete only when the real
Playwright `npx playwright test --list` registers the tests.

REGRESSION COMMANDS (from the launcher directory)
-------------------------------------------------
node --test regression/*.test.mjs
python regression/integration_regression.py
python regression/discovery_global_regression.py
python regression/config_fallback_and_skip.py
python regression/auto_registration_repair.py
python regression/runner_preflight_and_repair.py
