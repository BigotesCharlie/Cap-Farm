iGero Simple Migration v2.4 — RESTORED MIGRATION + FILE STATUS + BUTTON SPINNERS
==============================================================================

Based on v2.3 (white/pink/blue vertical layout), preserving all existing HTML
control IDs, LOB/suite selection, Copilot CLI workflow and Functional TC Check.
The interface remains fully in English.

WHAT WAS BROKEN IN v2.2/v2.3
----------------------------
"Run full migration" incorrectly required an existing Playwright test to be
registered before the very first new TypeScript spec could be created.
Thus, projects reporting zero registered tests were blocked before generating
JSON or invoking Copilot. This was a launcher flow regression, independent
of whether the selected Java method's source artifacts were valid.

FIXES
-----
1. Migration generation is no longer gated by pre-existing Playwright tests.
   The application checks paths and prerequisites, generates JSON/prompt/spec,
   then performs Playwright discovery to validate the resulting spec.
   Discovery can still be BLOCKED, but already-generated artifacts are preserved.
2. Generated Files now shows a green check or red cross immediately beside
   contract.json, prompt.md, spec.ts according to real server-side file
   existence and minimal identity/content checks. This is NOT assertion parity
   certification and is NOT a Functional PASS.
3. Every button shows a small adjacent spinner during click handling. Long
   operations (including full migration) retain the spinner until completion;
   ordinary button clicks show short immediate feedback.
4. All prior navigation, pages, project paths, environment gates, safety rules
   and the automatic AI-credit behavior remain intact.
5. Fix the footer version number to reflect the installed package.

IMPORTANT LIMITATION
--------------------
The original underlying Playwright project still needs at least one genuinely
registered runnable test before a real Functional TC Check can complete.
This release restores the file-generation path and avoids misreporting source
artifacts as missing. It DOES NOT claim that the user's local Playwright runner
or their Farmers QA app is now fixed. A spec with test.skip remains SKIPPED.

INSTALL / UPDATE
----------------
1. Stop ALL previous iGero servers and close the previous CMD window.
2. Extract this archive; overwrite the old launcher files.
3. KEEP your private config.local.json if present (not included here).
4. Double-click Start-iGero-HTML.cmd, then reload with Ctrl+F5.
5. Pick a Line of Business, suite and method.
6. Run "1 · Generate JSON + Prompt" or "Run full migration".
7. Verify the green/red icons beside all three artifact tabs.
8. Use "Diagnose Playwright config" if the registry still reports 0 tests.
   Do not run sensitive Bind/payment/purchase tests without authorization.

QA / REGRESSION
---------------
node --check server.mjs
node --check app.js
node --test regression/*.test.mjs
python regression/v24_artifacts_and_migration.py
python regression/v24_browser_ui.py (requires local Python Playwright + Chromium)

All isolated tests use mocked CLI or stubbed UI endpoints. They do NOT use
Copilot AI credits, Java/Excel originals, Farmers, or any real bank/payment.
