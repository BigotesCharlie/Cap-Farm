iGero Simple Migration v2.8 — SKIPPED Functional Test Repair
===========================================================

BASELINE: v2.7 preserved. The existing JSON/Prompt/TypeScript generation,
LOB/Suite filters, SKIPPED SCENARIOS, targeted Playwright discovery, Chromium
selection, automatic AI credits, vertical white/pink/blue UI, file-status ticks,
spinners, live logs and expandable checks are unchanged.

BUG FIX:
- A genuine Playwright result of 1 SKIPPED, 0 FAILED was displayed as
  "Functional TC Check FAILED". It now reports SKIPPED_RUNTIME, preserving the
  original JSON reporter and any skip/fixme annotation descriptions.
- A registered spec with a static test.skip is reported as
  SKIPPED_IMPLEMENTATION rather than a false assertion failure when checked
  through the Functional TC Check. No Chrome launches for this static skip.
- A real failing assertion remains FUNCTIONAL_FAILED; a Playwright PASS still
  remains PLAYWRIGHT_PASS_PARITY_UNVERIFIED until Java contract coverage is
  independently validated.

NEW OPTIONAL ACTION: "Repair skipped TC" (Functional TC Check panel).
- Enabled ONLY for source-nondisabled scenarios with an actual stored
  SKIPPED_RUNTIME / PARTIALLY_SKIPPED / SKIPPED_IMPLEMENTATION outcome.
- Requires an explicit click. Calls GitHub Copilot CLI once, using the original
  read-only Java source, contract.json, prompt.md and exact skipped spec.
- Copilot is instructed to inspect source TestNG enablement, data/state rules,
  fixtures and mandatory dependencies; it must only repair an unjustified skip
  in that SPEC and must NOT remove legitimate skips or bypass validations.
- Saves a copy of the original spec under the existing migration artifact
  folder's repair-backups/, checks Java/Excel fingerprints, detects unrelated
  spec edits, and performs the existing TypeScript typecheck.
- NEVER launches a browser during the repair action. After an eligible repair
  finishes, click "Run Functional TC Check" to obtain a new runtime result.
- Preserves the separate guard against bank, payment, email, purchase, Bind,
  and policy-binding operations; no automatic side-effect authorization.
- Does NOT promise that a missing Java dependency or genuine application block
  can be repaired without source-supported implementation work.

INSTALL:
1. Stop the existing iGero server.
2. Back up the current launcher folder and keep your config.local.json.
3. Unzip this package, replacing only launcher files. No config.local.json is
   shipped, and no Java/Excel or target test code is shipped or overwritten.
4. Start Start-iGero-HTML.cmd, refresh the browser (Ctrl+F5).
5. For an existing skipped test, select the Java method and click Run Functional
   TC Check. If the result is SKIPPED_RUNTIME, use "Repair skipped TC" if
   appropriate; then run Functional TC Check again.

VALIDATION:
- node --check server.mjs and app.js: PASS.
- node --test regression/*.test.mjs: 53/53 PASS.
- integration_regression.py: PASS using fake Playwright CLI / reporter.
- v28_skipped_integration.py: PASS with 1 SKIPPED, 0 FAILED in a fake reporter.
- v26_source_skip_api.py: PASS for Java @Test(enabled=false) virtual suite.
- No real Farmers MA11 browser test or corporate Copilot modification executed
  in this environment. The optional focused repair action needs validation on
  the Windows checkout with its actual source dependencies.

IMPORTANT:
A JSON contract, prompt or spec file existing is not Functional PASS.
A SKIPPED Playwright run is neither assertion failure nor Functional PASS.
An enabled Java method is not proof that all Excel/state/dependency gates are
satisfied. Never remove legitimate source skips just to turn a badge green.
