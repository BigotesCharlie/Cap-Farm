import test from 'node:test';
import assert from 'node:assert/strict';
import {classifyLob,buildLobCatalog,filterMethods} from '../lob-catalog.mjs';
const rows=[
  {id:'AceHomeNameAndDobPageTest#testName',className:'AceHomeNameAndDobPageTest',relativePath:'src/test/java/com/farmers/ffq/acehome/AceHomeNameAndDobPageTest.java'},
  {id:'AceHomeNameAndDobPageTest#testDOB',className:'AceHomeNameAndDobPageTest',relativePath:'src/test/java/com/farmers/ffq/acehome/AceHomeNameAndDobPageTest.java'},
  {id:'AceHomeAddressPageTest#testAddress',className:'AceHomeAddressPageTest',relativePath:'src/test/java/com/farmers/ffq/acehome/AceHomeAddressPageTest.java'},
  {id:'AutoQuoteTest#testAuto',className:'AutoQuoteTest',relativePath:'src/test/java/com/farmers/ffq/auto/AutoQuoteTest.java'},
  {id:'AceCondoDetailsTest#testCondo',className:'AceCondoDetailsTest',relativePath:'src/test/java/com/farmers/ffq/acecondo/AceCondoDetailsTest.java'},
  {id:'AceRentersContactPageTest#testRenters',className:'AceRentersContactPageTest',relativePath:'src/test/java/com/farmers/ffq/acerenters/AceRentersContactPageTest.java'},
  {id:'AceAutoHomeBundleTests#testBundle',className:'AceAutoHomeBundleTests',relativePath:'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java'},
].map(x=>({...x,...{lob:classifyLob(x.relativePath).id,lobLabel:classifyLob(x.relativePath).label},suite:x.relativePath}));
test('LOB is derived from Java source package, not method/class keywords',()=>{
  assert.equal(classifyLob(rows[6].relativePath).id,'bundle');
  assert.equal(classifyLob(rows[3].relativePath).label,'Auto');
  assert.equal(classifyLob(rows[4].relativePath).label,'Condo');
  assert.equal(classifyLob(rows[5].relativePath).label,'Renters');
  assert.equal(classifyLob('src/test/java/com/farmers/ffq/home/OtherHomeTest.java').label,'Home');
});
test('Catalog groups one Java class as one suite and counts methods correctly',()=>{
  const catalog=buildLobCatalog(rows);
  assert.equal(catalog[0].id,'home');
  const home=catalog.find(x=>x.id==='home');
  assert.equal(home.count,3);
  assert.equal(home.suites.length,2);
  assert.equal(home.suites.find(x=>x.label==='AceHomeNameAndDobPageTest').count,2);
});
test('Filtering by LOB and exact suite excludes other HOME classes',()=>{
  const suite=rows[0].suite;
  assert.equal(filterMethods(rows,{lob:'home',suite}).length,2);
  assert.equal(filterMethods(rows,{lob:'home',suite,q:'testDOB'}).length,1);
  assert.equal(filterMethods(rows,{lob:'auto',suite}).length,0);
});
test('Only LOBs present in Java methods are returned',()=>{
  assert.equal(buildLobCatalog(rows).some(x=>x.id==='life'),false);
});
test('Unknown packages are Other rather than assumed HOME',()=>{
  assert.equal(classifyLob('src/test/java/com/other/SomeHomeHelpersTest.java').id,'other');
});

test('Java TestNG explicitly disabled methods are recognized without treating normal tests as skipped',async()=>{
  const {sourceSkipReason}=await import('../lob-catalog.mjs');
  assert.equal(sourceSkipReason('@Test(enabled = false) public void testDisabled()'), '@Test(enabled=false)');
  assert.equal(sourceSkipReason('@Test(groups={"smoke"}, enabled=false)\npublic void disabled()'), '@Test(enabled=false)');
  assert.equal(sourceSkipReason('@Test(enabled=true) public void enabled()'), '');
  assert.equal(sourceSkipReason('@Test(dataProvider="foo") public void enabled()'), '');
  assert.equal(sourceSkipReason('@Ignore\n@Test public void ignored()'), '@Ignore/@Disabled');
});
test('disabled Java tests appear exclusively under the virtual SKIPPED SCENARIOS suite of their LOB',async()=>{
  const {SKIPPED_SUITE}=await import('../lob-catalog.mjs');
  const disabled={...rows[0],id:'AceHomeNameAndDobPageTest#disabled',skipped:true,skipReason:'@Test(enabled=false)'};
  const input=[...rows,disabled];
  const home=buildLobCatalog(input).find(x=>x.id==='home');
  assert.equal(home.count,4);
  const special=home.suites.find(x=>x.id===SKIPPED_SUITE);
  assert.ok(special,'virtual disabled suite must be present');
  assert.equal(special.label,'SKIPPED SCENARIOS');
  assert.equal(special.count,1);
  assert.equal(filterMethods(input,{lob:'home',suite:SKIPPED_SUITE}).map(x=>x.id).join(''),disabled.id);
  assert.equal(filterMethods(input,{lob:'home',suite:rows[0].suite}).length,2);
  assert.equal(filterMethods(input,{lob:'auto',suite:SKIPPED_SUITE}).length,0);
  assert.ok(!home.suites.some(x=>x.label==='SKIPPED SCENARIOS'&&x.count>1));
});
