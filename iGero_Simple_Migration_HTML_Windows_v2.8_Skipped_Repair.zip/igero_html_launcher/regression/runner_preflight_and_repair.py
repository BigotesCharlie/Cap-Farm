"""Compatibility entrypoint for the v2.4 regression.
The v2.2 expectation (block new migrations before generating a spec when the
Playwright registry is empty) was a bug and is intentionally superseded.
"""
import runpy
from pathlib import Path
runpy.run_path(str(Path(__file__).with_name('v24_artifacts_and_migration.py')),run_name='__main__')
