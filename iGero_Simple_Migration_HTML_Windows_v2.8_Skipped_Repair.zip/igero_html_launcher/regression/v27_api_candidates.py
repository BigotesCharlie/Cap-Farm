"""Regression using the real Node server and a simulated Playwright list CLI; no QA browser/Copilot."""
import os, tempfile, subprocess, pathlib, json, time, urllib.request, urllib.parse, shutil
base=pathlib.Path(__file__).resolve().parents[1]
root=pathlib.Path(tempfile.mkdtemp(prefix='igero_v27_api_'))
java=root/'java';pw=root/'pw';bin=root/'bin';launcher=root/'launcher'
java_src=java/'src/test/java/com/farmers/ffq/acehome/AceHomePayInFullPageTest.java'
java_src.parent.mkdir(parents=True)
java_src.write_text('public class AceHomePayInFullPageTest { @Test public void testValidateContentOfPayInFullPageOnLandingAceHome() {} }')
(pw/'tests/acehome').mkdir(parents=True)
method='testValidateContentOfPayInFullPageOnLandingAceHome'; cls='AceHomePayInFullPageTest'
for name in [f'{cls}.{method}.spec.ts','PayInFullContentValidation.spec.ts','legacy/AceHomePayInFullPageTest.spec.ts']:
 f=pw/'tests/acehome'/name;f.parent.mkdir(parents=True,exist_ok=True)
 f.write_text(f"import {{test}} from '@playwright/test'; const legacyId='{cls}#{method}'; test('{method} content',async()=>{{}});")
(pw/'node_modules/@playwright/test').mkdir(parents=True)
(pw/'node_modules/@playwright/test/package.json').write_text('{}')
bin.mkdir();launcher.mkdir()
listing='Listing tests:\n'
for f in sorted((pw/'tests/acehome').rglob('*.spec.ts')):
 relative=f.relative_to(pw).as_posix()
 for project in ['chromium','firefox','webkit','edge','mobile-chrome','mobile-safari']:
  listing+=f'  [{project}] › {relative}:1:1 › {method} content\n'
listing+='Total: 18 tests in 3 files\n'
(bin/'npx').write_text('#!/usr/bin/env python3\nimport sys\nif "--list" in sys.argv:\n print('+repr(listing)+')\n sys.exit(0)\nsys.exit(1)\n')
(bin/'npx').chmod(0o755)
for name in ('server.mjs','app.js','index.html','playwright-launcher.mjs','focused-test-resolver.mjs','lob-catalog.mjs','registry-isolation.mjs','skip-result-classifier.mjs'):
 shutil.copy2(base/name,launcher/name)
env=os.environ.copy();env['PATH']=str(bin)+os.pathsep+env['PATH'];env['IGERO_PANEL_PORT']='18897'
proc=subprocess.Popen(['node','server.mjs'],cwd=launcher,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT)
def api(url,data=None):
 q=urllib.request.Request('http://127.0.0.1:18897'+url,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(q,timeout=12) as r:return json.load(r)
try:
 for _ in range(100):
  try:api('/api/job');break
  except:time.sleep(.1)
 api('/api/config',{'javaRoot':str(java),'playwrightRoot':str(pw),'testEnv':'MA11','autoTypecheck':True,'autoFunctionalCheck':True})
 result=api('/api/spec-candidates?id='+urllib.parse.quote(cls+'#'+method))
 assert result['globallyListed']==18,result
 assert result['rawRegistrations']==18,result
 assert result['registered']==3,result
 assert len(result['entries'])==3,result
 assert all(e['project']=='chromium' for e in result['entries']),result
 print('PASS: 18 Playwright browser registrations reduced to 3 exact desktop-Chromium selections via HTTP API')
 print('PASS: unchanged Java/Excel; no Copilot call; no browser launch')
finally:
 proc.terminate()
 try:proc.wait(timeout=3)
 except:proc.kill()
 shutil.rmtree(root,ignore_errors=True)
