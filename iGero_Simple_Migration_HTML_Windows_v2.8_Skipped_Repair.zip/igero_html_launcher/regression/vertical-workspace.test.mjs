import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {dirname,join} from 'node:path';
const folder=dirname(dirname(fileURLToPath(import.meta.url)));
const html=readFileSync(join(folder,'index.html'),'utf8');
const js=readFileSync(join(folder,'app.js'),'utf8');
const idIndex=(id)=>html.indexOf(`id="${id}"`);
test('migration commands have one sticky toolbar with five original button IDs',()=>{
 const toolbar=html.match(/<nav[^>]*id="migrationActionBar"[^>]*>([\s\S]*?)<\/nav>/);
 assert.ok(toolbar,'missing sticky bar');
 for(const id of ['extractBtn','migrateBtn','allBtn','functionalBtn','stopBtn']){
  assert.match(toolbar[1],new RegExp(`id="${id}"`));
  assert.equal((html.match(new RegExp(`id="${id}"`,'g'))||[]).length,1);
  assert.match(js,new RegExp(`\\$\\('${id}'\\)`),'handler missing for '+id);
 }
 assert.match(html,/\.sticky-actions\s*\{[^}]*position:sticky/);
});
test('layout is one vertical flow with functional result before bottom checks and logs',()=>{
 const ids=['systemPanel','methodList','javaPreview','allBtn','generatedPreview','functionalPanel','migrationChecks','console'];
 for(const id of ids) assert.ok(idIndex(id)>0,'missing '+id);
 assert.ok(idIndex('functionalPanel')<idIndex('migrationChecks'));
 assert.ok(idIndex('migrationChecks')<idIndex('console'));
 assert.match(html,/\.cols,\.leftgrid,\.rightgrid\s*\{\s*display:flex!important;\s*flex-direction:column!important/);
 assert.match(html,/body\s*\{[^}]*overflow-x:clip/);
});
test('new pink/white/blue theme retains unique control IDs',()=>{
 assert.match(html,/--bg:#f3f7ff/);
 assert.match(html,/--panel:#ffffff/);
 assert.match(html,/--red:#d63379/);
 const all=[...html.matchAll(/\bid="([^"]+)"/g)].map(x=>x[1]);
 assert.equal(new Set(all).size,all.length,'duplicate HTML id');
 const jsIds=[...js.matchAll(/\$\('([\w-]+)'\)/g)].map(x=>x[1]);
 for(const id of jsIds) assert.ok(all.includes(id),'missing JS control '+id);
});
