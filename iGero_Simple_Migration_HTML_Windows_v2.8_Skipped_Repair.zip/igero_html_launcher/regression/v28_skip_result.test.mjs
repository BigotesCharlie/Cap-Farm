import test from 'node:test';
import assert from 'node:assert/strict';
import {classifyFunctionalVerdict, runtimeSkipReason} from '../skip-result-classifier.mjs';
test('sole skipped test is SKIPPED_RUNTIME, never an assertion failure',()=>{
  assert.equal(classifyFunctionalVerdict({total:1,passed:0,failed:0,skipped:1,other:0},0),'SKIPPED_RUNTIME');
});
test('a failing assertion remains FUNCTIONAL_FAILED',()=>{
  assert.equal(classifyFunctionalVerdict({total:1,passed:0,failed:1,skipped:0,other:0},1),'FUNCTIONAL_FAILED');
});
test('real success remains parity-unverified',()=>{
  assert.equal(classifyFunctionalVerdict({total:1,passed:1,failed:0,skipped:0,other:0},0),'PLAYWRIGHT_PASS_PARITY_UNVERIFIED');
});
test('zero tests is not a PASS',()=>{
  assert.equal(classifyFunctionalVerdict({total:0,passed:0,failed:0,skipped:0},0),'NO_TEST_RESULTS');
});
test('partial skip never passes',()=>{
  assert.equal(classifyFunctionalVerdict({total:2,passed:1,failed:0,skipped:1,other:0},0),'PARTIALLY_SKIPPED');
});
test('skipped plus real failure is a failure',()=>{
  assert.equal(classifyFunctionalVerdict({total:2,passed:0,failed:1,skipped:1,other:0},1),'FUNCTIONAL_FAILED');
});
test('skip annotation is surfaced',()=>{
  assert.match(runtimeSkipReason([{annotations:[{type:'skip',description:'Missing source dependency'}]}]),/Missing source dependency/);
});
test('missing reason does not invent one',()=>{
  assert.match(runtimeSkipReason([{annotations:[]}]),/did not provide a reason/);
});
