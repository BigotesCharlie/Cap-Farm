"""v2.4 browser UI test with stubbed local endpoints; no network, Copilot or QA calls."""
from pathlib import Path
from playwright.sync_api import sync_playwright
base=Path(__file__).resolve().parents[1]
html=(base/'index.html').read_text().replace('<script defer="" src="/app.js"></script>','')
js=(base/'app.js').read_text()
mock_js=r'''
window.EventSource = class { constructor(url){ this.url=url } addEventListener() {} };
window.mockHasPrompt = true;
window.fetch = async function(input,options){
 const url=String(input), json=(x)=>({ok:true,status:200,json:async()=>x});
 if(url.startsWith('/api/system'))return json({migrationReady:true,functionalReady:true,note:'Local stub',checks:{node:{status:'PASS',value:'v26'},copilot:{status:'PASS',value:'mock'},java:{status:'PASS',value:'OK'},target:{status:'PASS',value:'OK'},playwright:{status:'PASS',value:'mock'},authentication:{status:'INFO',value:'NOT VERIFIED'}}});
 if(url.startsWith('/api/config'))return json({javaRoot:'C:/java',playwrightRoot:'C:/pw',javaExists:true,targetExists:true,autoTypecheck:true,autoFunctionalCheck:true,testEnv:'MA11'});
 if(url.startsWith('/api/lob-catalog'))return json({lobs:[{id:'home',label:'Home',count:1,suites:[{id:'suite-demo',label:'AceHomePilotTest',relativePath:'src/test/java/com/farmers/ffq/acehome/AceHomePilotTest.java',count:1}]}]});
 if(url.startsWith('/api/methods'))return json({lob:'home',suite:'suite-demo',filteredTotal:1,methods:[{id:'AceHomePilotTest#testContentPilot',className:'AceHomePilotTest',relativePath:'src/test/java/com/farmers/ffq/acehome/AceHomePilotTest.java',lob:'home',suite:'suite-demo'}]});
 if(url.startsWith('/api/method-preview'))return json({javaPreview:'@Test public void testContentPilot() {}',relativePath:'src/test/java/com/farmers/ffq/acehome/AceHomePilotTest.java'});
 if(url.startsWith('/api/outputs'))return json({json:true,prompt:window.mockHasPrompt,contract:'{"className":"AceHomePilotTest"}',prompt:window.mockHasPrompt?'Implement complete spec.md':'',outputDir:'C:/pw/migration/pervez-json/..',specPath:'C:/pw/tests/AceHomePilotTest.spec.ts',specExists:true,specPreview:"test('testContentPilot',()=>{});",fileStatus:{json:{exists:true,valid:true},prompt:{exists:window.mockHasPrompt,valid:window.mockHasPrompt},spec:{exists:true,valid:true}},functional:null});
 if(url.startsWith('/api/job'))return json(null);
 return json({});
}
'''
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1280,'height':900})
 errors=[];page.on('pageerror',lambda ex:errors.append(str(ex)))
 page.set_content(html,wait_until='domcontentloaded')
 page.evaluate(mock_js)
 page.add_script_tag(content=js)
 page.wait_for_selector('#methodList .method',timeout=5000)
 page.locator('#methodList .method').first.click()
 page.wait_for_function("document.querySelector('#fileStatusJson').textContent==='✓'&&document.querySelector('#fileStatusPrompt').textContent==='✓'&&document.querySelector('#fileStatusSpec').textContent==='✓'",timeout=5000)
 print('PASS: three green artifact checkmarks for generated/valid files')
 page.evaluate('window.mockHasPrompt=false')
 page.locator('#refreshOutput').click()
 page.wait_for_function("document.querySelector('#fileStatusPrompt').textContent==='✗'",timeout=5000)
 assert page.locator('#fileStatusJson').inner_text()=='✓' and page.locator('#fileStatusSpec').inner_text()=='✓'
 print('PASS: prompt missing -> red cross, remaining files stay green')
 # click dispatch and pseudo-element are synchronous and visible next to button
 assert page.evaluate("(()=>{const b=document.getElementById('verifyBtn');b.click();return b.classList.contains('action-loading')&&b.getAttribute('aria-busy')==='true'&&getComputedStyle(b,'::after').display==='inline-block';})()")
 page.wait_for_function("!document.querySelector('#verifyBtn').classList.contains('action-loading')",timeout=5000)
 print('PASS: spinner appears at button side during click and clears after completion')
 assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+2')
 page.screenshot(path='/mnt/data/igero_v24_verified_desktop.png',full_page=True)
 page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(300)
 assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+2')
 page.screenshot(path='/mnt/data/igero_v24_verified_mobile.png',full_page=True)
 print('PASS: white/pink/blue vertical layout with no horizontal scrolling at 1280px or 390px')
 assert not errors,errors
 print('PASS: browser executes the UI without uncaught JS errors')
 browser.close()
