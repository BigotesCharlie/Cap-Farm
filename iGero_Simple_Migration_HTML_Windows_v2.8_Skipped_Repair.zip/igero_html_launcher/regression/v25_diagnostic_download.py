"""Offline Chromium validation of the diagnostic download control. No QA / Copilot."""
from pathlib import Path
from playwright.sync_api import sync_playwright
base=Path(__file__).resolve().parents[1]
html=(base/'index.html').read_text().replace('<script defer="" src="/app.js"></script>','')
js=(base/'app.js').read_text()
mock_js=r'''
window.EventSource=class {addEventListener() {}};
window.fetch=async function(input,options){
 const url=String(input), respond=x=>({ok:true,status:200,json:async()=>x});
 if(url.startsWith('/api/system'))return respond({migrationReady:true,functionalReady:true,checks:{node:{status:'PASS',value:'v26'},copilot:{status:'PASS',value:'local'},java:{status:'PASS',value:'yes'},target:{status:'PASS',value:'yes'},playwright:{status:'PASS',value:'yes'},authentication:{status:'INFO',value:'NOT VERIFIED'}}});
 if(url.startsWith('/api/config'))return respond({javaRoot:'C:/java',playwrightRoot:'C:/pw',javaExists:true,targetExists:true,autoTypecheck:true,autoFunctionalCheck:true,testEnv:'MA11'});
 if(url.startsWith('/api/lob-catalog'))return respond({lobs:[]});
 if(url.startsWith('/api/job'))return respond(null);
 if(url.startsWith('/api/playwright-diagnostics'))return respond({status:'NO_REGISTERED_TESTS',cwd:'C:/pw',environment:'MA11',activeConfig:null,attempts:[{config:'default',runner:'project-local-cli',runnerExecutable:'C:/pw/node_modules/playwright/cli.js',exitCode:1,registered:0,outputTail:['Error: No tests found.']}],runnerIsolation:{status:'FAIL',exitCode:1,outputTail:'Error: No tests found',note:'probe reported a real error'}});
 return respond({});
};
'''
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1100,'height':900},accept_downloads=True)
 errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
 page.set_content(html,wait_until='domcontentloaded')
 page.evaluate(mock_js)
 page.add_script_tag(content=js)
 page.evaluate("renderDiscoveryDiagnostic({status:'NO_REGISTERED_TESTS',cwd:'C:/pw',environment:'MA11',attempts:[{config:'default',runner:'project-local-cli',runnerExecutable:'C:/pw/node_modules/playwright/cli.js',exitCode:1,registered:0,outputTail:['Error: No tests found.']}],runnerIsolation:{status:'FAIL',outputTail:'Probe failed'}})")
 with page.expect_download() as d:
  page.locator('#downloadDiscoveryBtn').click()
 download=d.value
 assert download.suggested_filename=='igero-playwright-discovery-diagnostics.json',download.suggested_filename
 assert not errors,errors
 assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+2')
 print('PASS: diagnostics JSON downloads successfully, no browser JS errors or horizontal scrolling')
 browser.close()
