import test from 'node:test';
import assert from 'node:assert/strict';
import {chooseFocusedTest,canonicalFocusedTests} from '../focused-test-resolver.mjs';
const browsers=['chromium','firefox','webkit','edge','mobile-chrome','mobile-safari'];
const cls='AceHomePayInFullPageTest';
const method='testValidateContentOfPayInFullPageOnLandingAceHome';
const id=`${cls}#${method}`;
function fixture(specCount=3){
  return Array.from({length:specCount},(_,i)=>{
    const name=i===0?`${cls}.${method}.spec.ts`:i===1?`PayInFullContentValidation.spec.ts`:`legacy/${cls}.spec.ts`;
    return browsers.map(project=>({
      specPath:`/playwright/tests/acehome/${name}`,relativePath:`tests/acehome/${name}`,
      title:`${method} verifies Pay In Full content — variant ${i}`,line:42+i,project,
      runnable:true,eligible:true,skipDeclared:false
    }));
  }).flat();
}
test('v2.7: 12 browser registrations become two distinct Playwright cases',()=>{
  const entries=fixture(2);
  const canonical=canonicalFocusedTests(entries);
  assert.equal(entries.length,12);
  assert.equal(canonical.length,2);
  assert.ok(canonical.every(x=>x.project==='chromium'));
});
test('v2.7: 18 browser registrations become three distinct candidates',()=>{
  assert.equal(canonicalFocusedTests(fixture(3)).length,3);
});
test('v2.7: uniquely modified new spec is selected out of 12 registrations',()=>{
  const entries=fixture(2);const touched=entries[1].specPath;
  const chosen=chooseFocusedTest(entries,id,null,null,{touchedSpecs:[touched]});
  assert.equal(chosen.specPath,touched);assert.equal(chosen.project,'chromium');
});
test('v2.7: uniquely modified new spec is selected out of 18 registrations',()=>{
  const entries=fixture(3);const touched=entries[12].specPath;
  const chosen=chooseFocusedTest(entries,id,null,null,{touchedSpecs:[touched]});
  assert.equal(chosen.specPath,touched);assert.equal(chosen.project,'chromium');
});
test('v2.7: without touched specs a unique class-and-method filename resolves',()=>{
  const entries=fixture(3).map(x=>({...x,title:'Pay In Full validation'}));
  const chosen=chooseFocusedTest(entries,id);
  assert.ok(chosen.relativePath.includes(`${cls}.${method}.spec.ts`));
});
test('v2.7: manifest prevents changing the target in later validation',()=>{
  const entries=fixture(3);const pinned=entries[6];
  const manifest={methodId:id,specPath:pinned.specPath,testTitle:pinned.title,project:pinned.project};
  const chosen=chooseFocusedTest(entries,id,manifest);
  assert.equal(chosen.relativePath,pinned.relativePath);assert.equal(chosen.project,'chromium');
});
test('v2.7: multiple touched source specs remain ambiguous, do not guess',()=>{
  const entries=fixture(3);const touched=[entries[0].specPath,entries[6].specPath];
  assert.throws(()=>chooseFocusedTest(entries,id,null,null,{touchedSpecs:touched}),/AMBIGUOUS_TEST_MAPPING \(3 distinct tests; 18 browser-project registrations\)/);
});
test('v2.7: explicit manual registration chooses the precise intended test',()=>{
  const entries=fixture(3);const chosen=entries[12];
  assert.equal(chooseFocusedTest(entries,id,null,{relativePath:chosen.relativePath,line:chosen.line,title:chosen.title,project:chosen.project}),chosen);
});
test('v2.7: never select an ineligible source reference',()=>{
  const entries=fixture(3).map(x=>({...x,eligible:false}));
  assert.throws(()=>chooseFocusedTest(entries,id),/NO_MAPPED_EXECUTABLE_TEST/);
});
test('v2.7: only Chromium project variations stay, do not run all browsers',()=>{
  assert.equal(new Set(canonicalFocusedTests(fixture(3)).map(x=>x.project)).size,1);
});
