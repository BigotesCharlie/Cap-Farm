import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { resolvePlaywrightInvocation } from '../playwright-launcher.mjs';
import { buildProbeFiles } from '../registry-isolation.mjs';

test('selects the local Playwright CLI instead of npx when installed',()=>{
  const root=path.resolve('/tmp/ffq-project');
  const cli=path.join(root,'node_modules','playwright','cli.js');
  const r=resolvePlaywrightInvocation(root,['--list'],{nodeExecutable:'/node',platform:'win32',exists:f=>f===cli});
  assert.equal(r.cmd,'/node');
  assert.deepEqual(r.args,[cli,'test','--list']);
  assert.equal(r.origin,'project-local-cli');
});
test('selects @playwright/test CLI as second local choice',()=>{
  const root=path.resolve('/tmp/ffq-project');
  const cli=path.join(root,'node_modules','@playwright','test','cli.js');
  const r=resolvePlaywrightInvocation(root,['--list','--config','some config.ts'],{nodeExecutable:'/node',platform:'win32',exists:f=>f===cli});
  assert.deepEqual(r.args,[cli,'test','--list','--config','some config.ts']);
});
test('legacy npx fallback remains available and quotes windows args',()=>{
  const r=resolvePlaywrightInvocation('C:\\nowhere',['--list','--config','C:\\Some Folder\\playwright.config.ts'],{platform:'win32',exists:()=>false});
  assert.equal(r.origin,'npx-fallback');
  assert.match(r.args[3], /"C:\\Some Folder\\playwright.config.ts"/);
});
test('isolated registry check uses .spec.ts to match real TS tests',()=>{
  const {config,spec}=buildProbeFiles();
  assert.match(config,/\*\.spec\.ts/);
  assert.match(spec,/IGERO_REGISTRY_PROBE_ONLY/);
});
