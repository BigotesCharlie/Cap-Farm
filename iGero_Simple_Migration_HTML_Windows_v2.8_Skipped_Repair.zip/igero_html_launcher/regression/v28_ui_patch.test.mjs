import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
const root=path.dirname(new URL(import.meta.url).pathname);const base=path.dirname(root);const html=fs.readFileSync(path.join(base,'index.html'),'utf8');const app=fs.readFileSync(path.join(base,'app.js'),'utf8');const server=fs.readFileSync(path.join(base,'server.mjs'),'utf8');
test('single opt-in repair button after Functional TC Check preserving five original controls',()=>{
 assert.equal((html.match(/id="repairSkippedBtn"/g)||[]).length,1);
 for(const id of ['extractBtn','migrateBtn','allBtn','functionalBtn','stopBtn'])assert.equal((html.match(new RegExp(`id="${id}"`,'g'))||[]).length,1);
 assert.ok(html.indexOf('id="functionalPanel"')<html.indexOf('id="repairSkippedBtn"'));
});
test('skip repair must be user-triggered, not part of normal automatic migration',()=>{
 assert.match(app,/repairSkippedBtn.*addEventListener\('click'/);
 assert.match(server,/\/api\/repair-skipped-test/);
 assert.match(server,/SOURCE_TEST_SKIPPED/);
 assert.match(server,/SKIP_REPAIR_BLOCKED_SAFETY/);
 assert.match(server,/DO NOT run browser/);
});
test('original vertical UI, section ordering, spinners and artifacts remain intact',()=>{
 assert.ok(html.indexOf('id="functionalPanel"')<html.indexOf('id="migrationChecks"'));
 assert.ok(html.indexOf('id="migrationChecks"')<html.indexOf('id="console"'));
 assert.match(app,/function spin\(/);
 for(const id of ['fileStatusJson','fileStatusPrompt','fileStatusSpec'])assert.ok(html.includes(`id="${id}"`));
});
