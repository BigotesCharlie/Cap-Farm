import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {buildProbeFiles,classifyRegistryFailure,isolatePlaywrightRegistry} from '../registry-isolation.mjs';

test('probe is --list-only and registers a single dummy test',()=>{
 const p=buildProbeFiles();assert.match(p.spec,/IGERO_REGISTRY_PROBE_ONLY/);assert.match(p.config,/testDir/);
});
test('config exclusion classification when isolation succeeds',()=>{
 assert.equal(classifyRegistryFailure({baselineTotal:0,isolatedRegistered:1,sourceCount:491}).code,'PROJECT_CONFIG_EXCLUDES_TESTS');
});
test('runner not verified if isolated probe fails',()=>{
 assert.equal(classifyRegistryFailure({baselineTotal:0,isolatedRegistered:0,sourceCount:491}).code,'PLAYWRIGHT_RUNNER_NOT_VERIFIED');
});
test('isolation cleans up temporary files and marks PASS only with real listing',async()=>{
 const root=await fs.mkdtemp(path.join(os.tmpdir(),'igero-registry-'));
 try{
  const r=await isolatePlaywrightRegistry({projectRoot:root,invoke:async config=>({exitCode:0,output:'[chromium] › registry-probe.spec.cjs:2:1 › IGERO_REGISTRY_PROBE_ONLY'})});
  assert.equal(r.status,'PASS');
  const names=await fs.readdir(path.join(root,'migration','pervez-json'));
  assert.deepEqual(names,[]);
 }finally{await fs.rm(root,{recursive:true,force:true});}
});
test('exit 1 with no tests never counts as PASS',async()=>{
 const root=await fs.mkdtemp(path.join(os.tmpdir(),'igero-registry-'));
 try{
  const r=await isolatePlaywrightRegistry({projectRoot:root,invoke:async()=>({exitCode:1,output:'Error: No tests found.'})});
  assert.equal(r.status,'FAIL');
 }finally{await fs.rm(root,{recursive:true,force:true});}
});
