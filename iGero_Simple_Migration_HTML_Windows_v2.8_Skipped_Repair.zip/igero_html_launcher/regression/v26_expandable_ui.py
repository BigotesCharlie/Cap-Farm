"""Browser UI-only verification: expandable Migration Checks and frozen toolbar; no actual QA calls."""
from pathlib import Path
from playwright.sync_api import sync_playwright
base=Path(__file__).resolve().parents[1]
html=(base/'index.html').read_text().replace('<script defer="" src="/app.js"></script>','')
js=(base/'app.js').read_text()
mocks=r'''
window.EventSource=class{ addEventListener(){} };
window.fetch=async (url)=>{
 const respond=x=>({ok:true,status:200,json:async()=>x});
 if(String(url).startsWith('/api/system')) return respond({migrationReady:true,functionalReady:true,note:'Mock',checks:{node:{status:'PASS',value:'v26'},copilot:{status:'PASS',value:'mock'},java:{status:'PASS',value:'mock'},target:{status:'PASS',value:'mock'},playwright:{status:'PASS',value:'mock'},authentication:{status:'INFO',value:'NOT VERIFIED'}}});
 if(String(url).startsWith('/api/config'))return respond({javaRoot:'C:/java',playwrightRoot:'C:/pw',javaExists:true,targetExists:true,autoTypecheck:true,autoFunctionalCheck:false,testEnv:'MA11'});
 if(String(url).startsWith('/api/lob-catalog'))return respond({lobs:[{id:'home',label:'Home',count:2,suites:[{id:'suite',label:'AceHomeTest',relativePath:'AceHomeTest.java',count:1},{id:'__IGERO_SKIPPED_SCENARIOS__',label:'SKIPPED SCENARIOS',relativePath:'Disabled Java methods',count:1}]}]});
 if(String(url).startsWith('/api/methods')){
   const skip=String(url).includes('__IGERO_SKIPPED_SCENARIOS__');
   return respond({lob:'home',suite:skip?'__IGERO_SKIPPED_SCENARIOS__':'suite',filteredTotal:1,methods:[{id:skip?'AceHomeTest#testDisabled':'AceHomeTest#testEnabled',lob:'home',suite:skip?'__IGERO_SKIPPED_SCENARIOS__':'suite',skipped:skip,skipReason:skip?'@Test(enabled=false)':'',relativePath:'AceHomeTest.java'}]});
 }
 if(String(url).startsWith('/api/method-preview'))return respond({javaPreview:'@Test public void testEnabled(){}',relativePath:'AceHomeTest.java'});
 if(String(url).startsWith('/api/outputs'))return respond({json:false,prompt:false,outputDir:'C:/pw/migration',fileStatus:{json:{exists:false,valid:false},prompt:{exists:false,valid:false},spec:{exists:false,valid:false}},functional:null});
 if(String(url).startsWith('/api/job'))return respond(null);
 return respond({});
};
'''
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1280,'height':900})
    errors=[];page.on('pageerror',lambda ex: errors.append(str(ex)))
    page.set_content(html,wait_until='domcontentloaded')
    page.evaluate(mocks)
    page.add_script_tag(content=js)
    page.wait_for_selector('#methodList .method')
    assert page.locator('#functionalCheck').is_checked()
    assert page.locator('#functionalCheck').is_disabled()
    print('PASS: browser auto-run remains enabled for eligible tests even if legacy config says false')
    page.locator('#suiteSelect').select_option('__IGERO_SKIPPED_SCENARIOS__')
    page.wait_for_function("document.querySelector('#methodList').innerText.includes('SOURCE SKIPPED')")
    assert page.locator('#methodList .method').count()==1
    print('PASS: SKIPPED SCENARIOS suite displays only Java skipped methods')
    # We can use the existing UI function to render actual statuses and check expanding.
    page.evaluate("renderSteps([{name:'Locate Java method',status:'pass',note:'Source found'},{name:'Copilot: generate JSON + prompt.md',status:'running',note:'Generating'}, {name:'Validate generated contract',status:'pending'}, {name:'Discover and map registered Playwright test',status:'blocked',note:'No tests found'}, {name:'Validate TypeScript',status:'pending'}, {name:'Functional TC Check — Playwright',status:'skipped',note:'SOURCE_TEST_SKIPPED'}, {name:'Save results',status:'pass',note:'Artifacts saved'}])")
    details=page.locator('#checklist details.checkrow')
    assert details.count()==7
    details.nth(0).locator('summary').click()
    assert details.nth(0).get_attribute('open') is not None
    assert 'Expected:' in details.nth(0).inner_text() and 'Observed:' in details.nth(0).inner_text()
    assert 'Source found' in details.nth(0).inner_text()
    # Expanded state should survive live rerender.
    page.evaluate("renderSteps([{name:'Locate Java method',status:'pass',note:'Source still found'}, {name:'Copilot: generate JSON + prompt.md',status:'pass',note:'Complete'}])")
    assert page.locator('#checklist details.checkrow').first.get_attribute('open') is not None
    assert 'Source still found' in page.locator('#checklist details.checkrow').first.inner_text()
    assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+2')
    page.screenshot(path='/mnt/data/iGero_v26_check_details_desktop.png',full_page=True)
    page.set_viewport_size({'width':390,'height':844})
    page.wait_for_timeout(150)
    assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+2')
    page.screenshot(path='/mnt/data/iGero_v26_check_details_mobile.png',full_page=True)
    print('PASS: expandable expected/observed/status summaries, persisted open, no horizontal scroll on desktop/mobile')
    assert not errors,errors
    browser.close()
