iGERO SIMPLE MIGRATION v2.1 — PLAYWRIGHT CONFIG DIAGNOSTICS & SOURCE SKIP PROTECTION
=================================================================================

THE OBSERVED ERROR
------------------
On 2026-11-23 the screenshot showed:
  Playwright global discovery: 0 registered entries, exit 1, Error: No tests found.
The generated About You spec also contained test.skip(...).

These are TWO separate issues:
1. `No tests found` means the current Playwright configuration did not register
   test cases. Source files on disk and successful TypeScript compilation do
   NOT prove a test is registered.
2. `test.skip(...)` keeps the registered test from executing. When the original
   Java @Test is enabled, a generated unconditional skip is NOT an acceptable
   complete functional migration. Mandatory missing dependencies must be fixed.

WHAT v2.1 CHANGES
-----------------
- Discover tests under the default Playwright config FIRST.
- If zero tests are registered, inspect existing playwright.config.ts/js/... files
  (up to six alternative configs, max three folder levels) using read-only
  `npx --no-install playwright test --list --config <existing-config>` commands.
- Use the configuration that actually registers the selected method for the
  following focused `--list` and (when authorized) functional execution.
- Understand `--list` output with or without a named browser project.
- Add a 'Diagnose Playwright config' button: see which config files were
  checked, numbers of registered tests and source hints for testDir/testMatch/
  testIgnore. No Copilot credits or real browser launches are used.
- Persist detailed results at
  migration/pervez-json/<JavaClass>__<method>/discovery-diagnostics.json.
- Detect a generated `test.skip` on the selected registered test. If Java says
  enabled=true, report JAVA_ENABLED_PLAYWRIGHT_SKIPPED, not Functional PASS.
- If EVERY existing config registers zero tests, report
  PLAYWRIGHT_PROJECT_NO_TESTS with evidence. Do not pretend to repair an
  unknown project configuration or start a browser with bypassed exclusions.
- Preserve ALL the previous HTML filters, Java/Excel read-only policy, the
  simple two-prompt workflow, automatic credit mode and sensitive-operation
  safety gate. No global Playwright configuration is rewritten.

HOW TO INSTALL
--------------
1. Close the old iGero local server / console.
2. Back up your local launcher and target Playwright project.
3. Unzip this archive and replace older launcher files. Preserve
   config.local.json if present (it is not distributed in the ZIP).
4. Start Start-iGero-HTML.cmd and refresh with Ctrl+F5.
5. Select Line of Business, Test Suite and Java method.
6. Click 'Diagnose Playwright config' FIRST. Read the active config or the
   exact cause of zero test registration; the diagnostic is also saved in
   the target project's migration/pervez-json folder.
7. If a registered test is available, click 'Discover runnable tests' and
   'Run Functional TC Check' for a safe, authorized TC.
8. If a generated spec has test.skip, review source-mandatory dependencies.
   Do not remove skip solely to force a green status.

FOR THE ABOUT YOU METHOD SHOWN IN THE SCREENSHOT
-----------------------------------------------
AceHomeAboutYouPageTest#pageContentValidationAboutYouPageHomeLob:
- The generated spec appears to contain test.skip due to unresolved source
  dependencies. Discovery can be repaired separately, but functional PASS
  still needs the complete source-defined behavior and runnable assertions.
- The user's real Playwright config and spec are NOT available to this local
  package-builder; the project-specific outcome must be checked in Windows.

VALIDATION IN THIS PACKAGE
--------------------------
Run from the launcher folder:
  node --test regression/focused-test-resolver.test.mjs regression/lob-catalog.test.mjs
  python regression/integration_regression.py
  python regression/discovery_global_regression.py
  python regression/auto_registration_repair.py
  python regression/config_fallback_and_skip.py

The bundled tests use mocks and do not contact Farmers QA, execute bank/payment
operations, or spend Copilot credits. A clean local regression DOES NOT certify
that the corporate Playwright workspace will be runnable without changes.
