# Native bridge integration protocol (igero-native-v1)

This document is an implementation contract for the **existing** Playwright project, not an installed bridge. It does not authorize bypassing QA access, data eligibility or safety gates.

## Launcher input
The server creates a new `migration/igero-functional-runs/<UUID>/` directory and writes `execution-request.json` with `{protocol,contract:{identity,profile}}`. The server passes these environment variables to the project-local Playwright CLI:

- `IGERO_NATIVE_PROTOCOL=igero-native-v1`, `IGERO_RUN_ID`
- `IGERO_EXECUTION_REQUEST` (absolute path to request JSON)
- `IGERO_RUN_OUTPUT_DIR` (new per-run directory)
- `IGERO_NATIVE_EVIDENCE_FILE` (native-evidence.json)
- `IGERO_NATIVE_PLAYWRIGHT_JSON` and `PLAYWRIGHT_JSON_OUTPUT_NAME` (native-playwright.json)
- `IGERO_EXECUTION_PROFILE` (JSON), `TEST_ENV`, `HEADLESS=false`, `WORKERS=1`, `RETRIES=0`, `PWDEBUG=0`
- HOME only: `ACE_HOME_STATE_LIST=TX`, `HOME_NAVIGATION_DELAY_MS=2000` (or saved delay)

The native project must adapt the requested profile to its actual existing assertion-mode, pacing, Chrome, failure-hold, diagnostic and environment mechanisms. No new generic global variables should be invented as if already consumed by the framework. `--list` receives the profile but not a live execution request: discovery must not run the browser or create live result artifacts. Normal native runs without this opt-in remain unchanged.

## Native configuration / result bridge
Preserve all configured reporters. Add or route an actual Playwright JSON reporter in the existing configuration to `IGERO_NATIVE_PLAYWRIGHT_JSON` without a CLI reporter override. Route every native writer (custom workbook, HTML, metadata, screenshots/diagnostics) into new isolated output locations for this opt-in execution. Do not overwrite existing reports. Ensure effective Google Chrome headed configuration and real profile support. Use the existing native reporter/evidence mechanisms to write `native-evidence.json` atomically after completion. Derive facts from actual test metadata, runtime events and final assertion results; never synthesize a PASS by echoing the requested contract. The run ID is supplied by the launcher; method, spec, title, project and profile must be independently checked against actual execution. The server also reads the actual JSON reporter, verifies one exact test matching normalized path/title/project, checks status and compares exit code. The native writer must not modify that raw report to force a match.

Evidence shape (illustrative only, NOT evidence):

```json
{
  "protocol": "igero-native-v1",
  "contract": {"identity": {}, "profile": {}},
  "authoritative": false,
  "conflict": false,
  "nativeStatus": "NOT_EXECUTED",
  "browserExecuted": false,
  "completed": false,
  "navigation": "NOT_VERIFIED",
  "finalExpected": "NOT_VERIFIED",
  "requiredActionsCompleted": false,
  "exitCode": 1,
  "deferredCount": 0,
  "fullAssertionsPassed": false
}
```

Use the exact identity schema from `execution-contract.mjs` and the profile from `execution-standard.mjs`. `nativeStatus` is PASS, FAIL, SKIPPED, NOT_EXECUTED, BLOCKED or INTERRUPTED. `navigation` and `finalExpected` are PASS, FAIL or NOT_VERIFIED. `exitCode` is the expected actual CLI completion code, cross-checked against the process exit by the launcher. Do not mark `authoritative` true until actual native outcome and required metadata have been validated. A full-assertion pass requires zero deferred assertions and complete actual assertion evidence. No missing evidence is filled from requested values. An incomplete or conflicting report must remain incomplete. Store detailed sanitized evidence using the native project's existing mechanisms, not the browser/UI claim. Do not expose applicant PII.

## Declaration / preflight
Only AFTER the native adapter and profile/output isolation have been implemented and focused validation has passed, create `<projectRoot>/.igero/native-bridge.json`. It is an explicit compatibility declaration, not certification. Example shape (replace placeholder paths with actual verified integration files):

```json
{
  "protocol": "igero-native-v1",
  "standardVersion": "1.0.0",
  "nativeReporters": true,
  "isolatedOutputs": true,
  "chromeOnly": true,
  "profiles": [{"profileId": "HOME_RA11_TX", "assertionMode": "FUNCTIONAL_FLOW_MODE"}],
  "integrationFiles": ["playwright.config.ts", "<actual native adapter relative path>"]
}
```

Do not register MA11, Full Assertion or non-HOME combinations until the existing native project supports them and checks pass. The launcher refuses live execution without a compatible declaration and project-local CLI. Actual live QA certification still requires the scoped real tests in the separate prompt.
