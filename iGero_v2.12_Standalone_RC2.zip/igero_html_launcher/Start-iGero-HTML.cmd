@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
 echo Node.js was not found. Use the approved installed Node.js runtime.
 pause
 exit /b 1
)
set "IGERO_PANEL_PORT=8767"
echo Starting iGero v2.12 RC2 on 127.0.0.1:8767.
echo Do not run jobs against the same Playwright project from two iGero installations.
start "iGero v2.12 RC2" /min cmd /k "node server.mjs"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8767/"
exit /b 0
