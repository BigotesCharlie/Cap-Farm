iGero v2.12 RC2 — Unified Execution Standard
================================================
STATUS: Standalone launcher candidate, not certified against Farmers QA.
BASE: supplied complete v2.11 Functional Runtime Fix ZIP (not the newer active local installation).

START / INSTALL (Windows)
1. Extract into a NEW directory, outside the installed iGero v2.11 folder.
2. Stop active iGero jobs. Do not run two launchers against the same Playwright project.
3. Run Start-iGero-HTML.cmd. It opens http://127.0.0.1:8767/.
4. Set the actual authorized Java and Playwright project paths and Save settings.
   HOME defaults to RA11, Functional Flow, TX random eligible data, 2000 ms pacing.
5. Read NATIVE-BRIDGE.md. Use the separately delivered RC2 Copilot prompt to reconcile
   the native bridge and newer local improvements before any real QA run.
6. The Execution Standard panel reports INTEGRATION REQUIRED until the native project
   declares the compatible bridge. The declaration is not certification. Do not create
   it merely to bypass preflight. The real native reporter and isolated paths must work.
7. Use the existing Simple Migration / Functional TC Check actions. No extra recorder.

WHAT CHANGED
- Existing HTML and controls retained; new server-backed HOME profile settings and
  independent native runtime/correlation outcomes. Save settings persists preferences.
- Exact focused discovery receives the execution profile and explicit runtime flags.
- Migration prompts inherit Execution Standard 1.0.0.
- Live execution requires the native bridge; no --reporter=json override. Native reporters
  must produce an isolated actual Playwright report and separate authoritative evidence.
- Run IDs and exact test identities are correlated; missing/mismatched results never PASS.
- Candidate summaries use functional-v212-summary.json; prior v2.11 summaries are not replaced.
- Local config starts empty; no secrets or project data included. Existing project directories
  are never automatically copied or replaced by this package.

IMPORTANT COMPATIBILITY LIMITATIONS
The supplied ZIP does not contain the latest TypeScript framework or later local edits to
server.mjs/launcher, including any Live Grid functionality added since that archive.
The new standalone shell is based on the archive, not a copy of the running installation.
Compare/merge current local changes with RC2 before using it against the working project.
The existing Playwright helpers (HomeNavigationPacing, FailureHold, pool/trampoline logic,
assertion modes, data provider, diagnostics) must be preserved in the real native project.
This app does not implement or replace those TypeScript components. Non-HOME adoption is
not certified; only declared compatible profiles may execute. Do not force TX outside HOME.
No new live QA or browser tests were run here; no Windows execution was performed.

VALIDATION (local Linux, Node 22.16.0)
- 82 JavaScript tests passed (69 prior tests, one updated for the new reporter protocol,
  plus 13 new tests). See VALIDATION.txt for results.
- One mocked CLI/HTTP integration passed: new HTML served, profile resolved, exact discovery,
  correlated mock PASS, missing-bridge block, source skip preserved, old skip repair.
- No actual Chrome, Farmers, Java execution, or Copilot CLI used for these tests.
- Older Python integration scripts are retained as historical v2.11 fixtures. Their old
  reporter override / summary paths are superseded; they are not claimed RC2-compatible.

ROLLBACK
Stop the RC2 server by closing its own command window. Do not stop unrelated processes.
Reopen your original v2.11 installation. It was not overwritten. Restore native project
files only from the timestamped backup created by Copilot after reviewing the diff.
Never run an unreviewed destructive restore. Keep all prior evidence and workbooks.
