import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {functionalRuntimeEnvironment} from '../playwright-launcher.mjs';

const dirname=path.dirname(fileURLToPath(import.meta.url));
const server=fs.readFileSync(path.join(dirname,'../server.mjs'),'utf8');

test('focused runtime supplies all four exact strings expected by source-enabled FFQ skip guards',()=>{
  const env=functionalRuntimeEnvironment('MA11');
  assert.deepEqual(env,{TEST_ENV:'MA11',HEADLESS:'false',WORKERS:'1',RETRIES:'0'});
  assert.equal(Object.isFrozen(env),true);
});
test('focused runtime uses the configured lane without altering source state eligibility',()=>{
  const env=functionalRuntimeEnvironment('QA-OTHER');
  assert.equal(env.TEST_ENV,'QA-OTHER');
  assert.equal(env.HEADLESS,'false');
  assert.throws(()=>functionalRuntimeEnvironment(''));
});
test('server passes runtime flags to both focused listing and real headed runner',()=>{
  assert.match(server,/const runtimeEnv=executionEnvironment\(profile\)/);
  assert.match(server,/spawnAndLog\(listCmd\.cmd,listCmd\.args,\{cwd:config\.playwrightRoot,env:runtimeEnv\}/);
  assert.match(server,/env:\{\.\.\.runtimeEnv,\.\.\.run.env\}/);
  assert.doesNotMatch(server,/--reporter=json/);
  assert.match(server,/'--headed','--workers=1','--retries=0'/);
});
test('no blanket Java-enabled skips are introduced by the migration prompt',()=>{
  assert.match(server,/If Java enables it, do NOT add an unconditional test\.skip\/test\.fixme/);
  assert.match(server,/If Java explicitly disables this method, preserve test\.skip/);
});
test('skip repair recognizes the previous missing environment flags as a launcher defect',()=>{
  assert.match(server,/const oldLauncherGate = \/runtime requires\/i/);
  assert.match(server,/repairKind:'RUNTIME_CONFIGURATION'/);
});
