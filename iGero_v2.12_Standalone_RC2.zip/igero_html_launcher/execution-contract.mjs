// iGero v2.12 candidate adapter contract. The existing Execution Standard is authoritative.
// No file IO, process spawning, or browser actions in this module.
export const ADAPTER_VERSION = '2.12.0-rc.1';
export const CONTRACT_VERSION = '1.0.0';
const text = (v, name) => { if (typeof v !== 'string' || !v.trim() || v !== v.trim() || /[\x00-\x1f]/.test(v)) throw new Error(`Invalid ${name}`); return v; };
const oneOf = (v, choices, name) => { if (!choices.includes(v)) throw new Error(`Unsupported ${name}`); return v; };
const bool = (v, name) => { if (typeof v !== 'boolean') throw new Error(`Invalid ${name}`); return v; };
const integer = (v,min,max,name) => { if (!Number.isInteger(v)||v<min||v>max) throw new Error(`Invalid ${name}`); return v; };
export function normalizeSpecPath(v) {
  const p=text(v,'specPath').replaceAll('\\','/');
  if (/^(?:\/|[a-z]:)/i.test(p)||p.split('/').some(x=>!x||x==='.'||x==='..')||/[?#:]/.test(p)) throw new Error('Expected normalized project-relative spec path');
  return p;
}
// A profile is an ADAPTED view of an existing server-resolved profile, not a new preference store.
export function normalizeProfile(p) {
  if (!p || typeof p !== 'object') throw new Error('Profile required');
  const lob=text(p.lob,'lob');
  const stateList=Array.isArray(p.states)?p.states.map(v=>text(v,'state')):null;
  if (!stateList || new Set(stateList).size!==stateList.length || stateList.some(s=>!/^[A-Z]{2}$/.test(s))) throw new Error('Invalid states');
  if (lob==='HOME' && !stateList.length) throw new Error('HOME eligibility must be resolved');
  const profile={standardVersion:oneOf(p.standardVersion,[CONTRACT_VERSION],'standardVersion'),profileId:text(p.profileId,'profileId'),lob,
    environment:oneOf(p.environment,['RA11','MA11'],'environment'),states:stateList,
    dataSource:text(p.dataSource,'dataSource'),delayMs:integer(p.delayMs,2000,60000,'delayMs'),
    assertionMode:oneOf(p.assertionMode,['FUNCTIONAL_FLOW_MODE','FULL_ASSERTION_MODE'],'assertionMode'),
    project:text(p.project,'project'),channel:oneOf(p.channel,['chrome'],'channel'),headed:oneOf(p.headed,[true],'headed'),
    workers:oneOf(p.workers,[1],'workers'),retries:oneOf(p.retries,[0],'retries'),
    codegen:oneOf(p.codegen,[false],'codegen'),inspector:oneOf(p.inspector,[false],'inspector'),
    failureHold:bool(p.failureHold,'failureHold'),capabilities:{}};
  for(const k of ['copyDOM','sentinel','autoDebugging','recovery','nativeReporters','pageReadiness']) profile.capabilities[k]=bool(p.capabilities?.[k],k);
  if (profile.profileId==='HOME_RA11_TX' && (lob!=='HOME'||profile.environment!=='RA11'||stateList.length!==1||stateList[0]!=='TX'||profile.project!=='chromium')) throw new Error('HOME_RA11_TX mismatch');
  return profile;
}
// Server must additionally validate availability and eligibility against actual project settings.
export function normalizeIdentity(x) {
  if(!x||typeof x!=='object') throw new Error('Identity required');
  return {runId:text(x.runId,'runId'),methodId:text(x.methodId,'methodId'),specPath:normalizeSpecPath(x.specPath),testTitle:text(x.testTitle,'testTitle'),project:text(x.project,'project')};
}
export function makeContract(identity, profile) {
  const i=normalizeIdentity(identity), p=normalizeProfile(profile);
  if(i.project!==p.project) throw new Error('Project mismatch');
  return {identity:i,profile:p};
}
export function sameContract(expected, actual) {
  try {return JSON.stringify(makeContract(expected.identity,expected.profile))===JSON.stringify(makeContract(actual.identity,actual.profile));} catch {return false;}
}
// Input must be adapted from authoritative native artifacts; NEVER derive these fields from a UI claim.
// This is a strict presentation/correlation guard, not an authoritative reporter.
export function classifyRuntime(expected, evidence) {
  const base={correlation:'INCOMPLETE',native:'NOT_VERIFIED',navigation:'NOT_VERIFIED',finalExpected:'NOT_VERIFIED',flow:'NOT_VERIFIED',fullAssertion:'NOT_VERIFIED'};
  if (!evidence) return base;
  if (!sameContract(expected,evidence.contract)) return {...base,correlation:'MISMATCH'};
  const native=evidence.nativeStatus;
  if (!['PASS','FAIL','SKIPPED','NOT_EXECUTED','BLOCKED','INTERRUPTED'].includes(native)) return base;
  if (evidence.authoritative!==true || evidence.conflict===true) return base;
  if (native==='SKIPPED'||native==='NOT_EXECUTED'||native==='BLOCKED'||native==='INTERRUPTED') return {...base,correlation:'VERIFIED',native};
  if(evidence.browserExecuted!==true || evidence.completed!==true) return base;
  const navigation=['PASS','FAIL'].includes(evidence.navigation)?evidence.navigation:'NOT_VERIFIED';
  const finalExpected=['PASS','FAIL'].includes(evidence.finalExpected)?evidence.finalExpected:'NOT_VERIFIED';
  const result={...base,correlation:'VERIFIED',native,navigation,finalExpected};
  if(native==='FAIL'||navigation==='FAIL'||finalExpected==='FAIL') return {...result,flow:'FLOW_FAIL',fullAssertion:expected.profile.assertionMode==='FULL_ASSERTION_MODE'?'FAIL':'NOT_VERIFIED'};
  if(evidence.exitCode!==0||navigation!=='PASS'||finalExpected!=='PASS'||evidence.requiredActionsCompleted!==true) return {...result,correlation:'INCOMPLETE'};
  if(expected.profile.assertionMode==='FULL_ASSERTION_MODE') {
    if(evidence.fullAssertionsPassed!==true||evidence.deferredCount!==0) return {...result,correlation:'INCOMPLETE'};
    return {...result,flow:'FLOW_PASS',fullAssertion:'FULL_ASSERTION_PASS'};
  }
  if(!Number.isInteger(evidence.deferredCount)||evidence.deferredCount<0) return {...result,correlation:'INCOMPLETE'};
  return {...result,flow:'FLOW_PASS'};
}
