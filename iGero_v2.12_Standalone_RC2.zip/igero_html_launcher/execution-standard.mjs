import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import {makeContract, classifyRuntime} from './execution-contract.mjs';
export const BRIDGE_PROTOCOL='igero-native-v1';
export function resolveExecutionProfile(config,lob='home') {
 const home=lob.toLowerCase()==='home';
 const environment=home?(config.homeEnvironment??'RA11'):(config.testEnv??'MA11');
 const assertionMode=home?(config.homeAssertionMode??'FUNCTIONAL_FLOW_MODE'):'FULL_ASSERTION_MODE';
 const delayMs=home?(config.homeDelayMs??2000):2000;
 if(!['RA11','MA11'].includes(environment)||!['FUNCTIONAL_FLOW_MODE','FULL_ASSERTION_MODE'].includes(assertionMode)||!Number.isInteger(delayMs)||delayMs<2000||delayMs>60000)throw new Error('Invalid execution profile');
 return {standardVersion:'1.0.0',profileId:home?`HOME_${environment}_TX`:`${lob.toUpperCase()}_NATIVE_${environment}`,lob:lob.toUpperCase(),environment,states:home?['TX']:[],dataSource:home?'Native Excel (random eligible rows)':'Native scenario data provider',delayMs,assertionMode,project:'chromium',channel:'chrome',headed:true,workers:1,retries:0,codegen:false,inspector:false,failureHold:true,capabilities:{copyDOM:true,sentinel:true,autoDebugging:true,recovery:true,nativeReporters:true,pageReadiness:true}};
}
export function executionEnvironment(profile){
 return {TEST_ENV:profile.environment,HEADLESS:'false',WORKERS:'1',RETRIES:'0',PWDEBUG:'0',IGERO_EXECUTION_PROFILE:JSON.stringify(profile),...(profile.lob==='HOME'?{ACE_HOME_STATE_LIST:profile.states.join(','),HOME_NAVIGATION_DELAY_MS:String(profile.delayMs)}:{})};
}
// An explicit declaration by the native integration owner is a prerequisite, not proof of live certification.
export function bridgeReadiness(root,profile){
 try{
  if(typeof root!=='string'||!root||!path.isAbsolute(root))throw Error('Select an absolute Playwright project root');
  const m=JSON.parse(fs.readFileSync(path.join(root,'.igero','native-bridge.json'),'utf8'));
  if(m.protocol!==BRIDGE_PROTOCOL||m.standardVersion!==profile.standardVersion||m.nativeReporters!==true||m.isolatedOutputs!==true||m.chromeOnly!==true||!Array.isArray(m.profiles)||!m.profiles.some(p=>p.profileId===profile.profileId&&p.assertionMode===profile.assertionMode))throw Error('Native bridge does not declare support for this profile and mode');
  if(!Array.isArray(m.integrationFiles)||!m.integrationFiles.length||!m.integrationFiles.every(f=>typeof f==='string'&&!path.isAbsolute(f)&&!f.includes('..')&&fs.statSync(path.join(root,f)).isFile()))throw Error('Native bridge integration files missing');
  return {ready:true,reason:'Native bridge declaration found; actual runtime evidence still required'};
 }catch(e){return {ready:false,reason:e.code==='ENOENT'?'Native bridge not integrated (.igero/native-bridge.json)':e.message};}
}
export async function prepareNativeRun(root,runId,methodId,target,profile){
 if(!/^[a-f0-9-]{36}$/i.test(runId))throw Error('Invalid run ID');
 const contract=makeContract({runId,methodId,specPath:target.relativePath,testTitle:target.title,project:target.project},profile);
 const base=path.join(root,'migration','igero-functional-runs');await fsp.mkdir(base,{recursive:true});
 const realRoot=await fsp.realpath(root),realBase=await fsp.realpath(base);
 const rel=path.relative(realRoot,realBase);if(rel.startsWith('..')||path.isAbsolute(rel))throw Error('Output path escapes project');
 const directory=path.join(realBase,runId);await fsp.mkdir(directory); // fail on reuse
 const requestFile=path.join(directory,'execution-request.json');
 const resultFile=path.join(directory,'native-evidence.json');
 const reportFile=path.join(directory,'native-playwright.json');
 await fsp.writeFile(requestFile,JSON.stringify({protocol:BRIDGE_PROTOCOL,contract},null,2),{flag:'wx'});
 return {directory,projectRoot:realRoot,contract,resultFile,reportFile,env:{IGERO_NATIVE_PROTOCOL:BRIDGE_PROTOCOL,IGERO_RUN_ID:runId,IGERO_EXECUTION_REQUEST:requestFile,IGERO_RUN_OUTPUT_DIR:directory,IGERO_NATIVE_EVIDENCE_FILE:resultFile,IGERO_NATIVE_PLAYWRIGHT_JSON:reportFile,PLAYWRIGHT_JSON_OUTPUT_NAME:reportFile}};
}
// Match the actual configured Playwright JSON reporter against the focused test, not a filename alone.
export function inspectNativeReport(report,identity,projectRoot){
 function normalizedFile(value){
  const v=String(value||'').replaceAll('\\','/');
  if(!projectRoot||!report?.config?.rootDir)return v;
  const absolute=path.resolve(report.config.rootDir,v);const relative=path.relative(projectRoot,absolute).replaceAll('\\','/');
  return relative;
 }
 const records=[];
 function walk(suite,parents=[],file=''){
  const suiteFile=suite.file||file;
  // Playwright top-level file suite is not part of the registered describe/test title.
  const names=suite.title && suite.title!==suiteFile && !/\.spec\.[cm]?[jt]sx?$/.test(suite.title)?[...parents,suite.title]:parents;
  for(const spec of suite.specs||[])for(const t of spec.tests||[]){
   const last=t.results?.at(-1);const specPath=normalizedFile(spec.file||suiteFile);
   const title=[...names,spec.title].join(' › ');
   let status='NOT_VERIFIED';
   if(t.status==='expected'&&t.expectedStatus==='passed'&&last?.status==='passed')status='PASS';
   else if(t.status==='skipped'&&(!last||last.status==='skipped'))status='SKIPPED';
   else if(last?.status==='interrupted')status='INTERRUPTED';
   else if(last&&['failed','timedOut','passed'].includes(last.status))status='FAIL';
   records.push({specPath,title,project:t.projectName,status,duration:last?.duration||0});
  }
  for(const child of suite.suites||[])walk(child,names,suiteFile);
 }
 for(const suite of report?.suites||[])walk(suite);
 if(records.length!==1)return null;
 const r=records[0];return r.specPath===identity.specPath&&r.title===identity.testTitle&&r.project===identity.project?r:null;
}
async function safeReadJson(file){try{const st=await fsp.lstat(file);if(st.isFile()&&!st.isSymbolicLink()&&st.size<20_000_000)return JSON.parse(await fsp.readFile(file,'utf8'));}catch{}return null;}
export async function readNativeResult(run,exitCode){
 let evidence=await safeReadJson(run.resultFile);
 const raw=inspectNativeReport(await safeReadJson(run.reportFile),run.contract.identity,run.projectRoot);
 if(evidence && ['PASS','FAIL','SKIPPED','INTERRUPTED'].includes(evidence.nativeStatus) && raw?.status!==evidence.nativeStatus)evidence={...evidence,conflict:true};
 // Never fill in missing native identity or native status from the requested contract.
 if(evidence?.exitCode!==exitCode || evidence?.protocol!==BRIDGE_PROTOCOL) evidence=null;
 const outcome=classifyRuntime(run.contract,evidence);
 let verdict='NATIVE_REPORT_INCOMPLETE';
 if(outcome.correlation==='VERIFIED'){
  if(outcome.fullAssertion==='FULL_ASSERTION_PASS')verdict='FULL_ASSERTION_PASS';
  else if(outcome.flow==='FLOW_PASS')verdict='FLOW_PASS';
  else if(outcome.flow==='FLOW_FAIL')verdict='FUNCTIONAL_FAILED';
  else if(outcome.native==='SKIPPED')verdict='SKIPPED_RUNTIME';
  else if(['BLOCKED','NOT_EXECUTED','INTERRUPTED'].includes(outcome.native))verdict=outcome.native;
 }
 const verified=outcome.correlation==='VERIFIED';
 const counts={total:verified&&['PASS','FAIL','SKIPPED'].includes(outcome.native)?1:0,passed:verified&&outcome.native==='PASS'?1:0,failed:verified&&outcome.native==='FAIL'?1:0,skipped:verified&&outcome.native==='SKIPPED'?1:0,other:0};
 return {methodId:run.contract.identity.methodId,runId:run.contract.identity.runId,verdict,counts,tests:raw?[{title:raw.title,project:raw.project,status:raw.status==='PASS'?'expected':raw.status==='SKIPPED'?'skipped':'unexpected',expectedStatus:'passed',duration:raw.duration,retries:0}]:[],exitCode,executionProfile:run.contract.profile,rawPlaywrightStatus:raw?.status||'NOT_VERIFIED',outcome,reason:verified?'Native evidence matched this execution; Java runtime parity not independently certified.':'Native evidence missing, conflicting, or not correlated. No functional PASS claimed.',javaRuntimeParity:'NOT_VERIFIED',reportPath:run.resultFile,executedAt:new Date().toISOString()};
}
export function migrationStandard(profile){return `EXECUTION STANDARD 1.0.0 — selected profile ${JSON.stringify(profile)}. Reuse native fixtures, flows, providers, reporters and shared forward-navigation pacing (${profile.delayMs} ms before click, readiness before and after, actual next-page readiness). No global slowMo, duplicate waits, Codegen, Inspector or PWDEBUG. Preserve source eligibility and random native data. In FUNCTIONAL_FLOW_MODE defer intermediate legacy business assertions only; preserve the original final Expected Result and operational checks. Full Assertion Mode retains all assertions. Preserve CopyDOM, Sentinel, evidence-based Recovery and bounded Failure Hold. Never infer duplicate-submit safety from missing network observations. Preserve Java and Excel read-only. Native runtime evidence must use the exact server-provided execution contract and isolated outputs; do not replace native reporters or claim PASS from discovery.`;}
