/*
 * Copyright (C) 2007-2010 Júlio Vilmar Gesser.
 * Copyright (C) 2011, 2013-2026 The JavaParser Team.
 *
 * This file is part of JavaParser.
 *
 * JavaParser can be used either under the terms of
 * a) the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 * b) the terms of the Apache License
 *
 * You should have received a copy of both licenses in LICENCE.LGPL and
 * LICENCE.APACHE. Please refer to those files for details.
 *
 * JavaParser is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 */

package com.github.javaparser.ast.validator;

import static com.github.javaparser.ParseStart.*;
import static com.github.javaparser.ParserConfiguration.LanguageLevel.JAVA_25;
import static com.github.javaparser.Providers.provider;
import static com.github.javaparser.utils.TestUtils.assertNoProblems;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ParserConfiguration;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import org.junit.jupiter.api.Test;

/**
 * Test for Java 25 language level support.
 *
 * @see <a href="https://openjdk.org/projects/jdk/25/">https://openjdk.org/projects/jdk/25/</a>
 */
class Java25ValidatorTest {

    private final JavaParser javaParser = new JavaParser(new ParserConfiguration().setLanguageLevel(JAVA_25));

    @Test
    void moduleImportAllowed() {
        ParseResult<ImportDeclaration> result =
                javaParser.parse(IMPORT_DECLARATION, provider("import module java.base;"));
        assertNoProblems(result);
    }

    @Test
    void explicitConstructorInvocationAfterFirstStatementAllowed() {
        String code = "class Foo {\n" + "    public Foo() {\n"
                + "        int x = 2;\n"
                + "        super();\n"
                + "    }\n"
                + "}";

        ParseResult<CompilationUnit> result = javaParser.parse(COMPILATION_UNIT, provider(code));
        assertNoProblems(result);
    }
}
