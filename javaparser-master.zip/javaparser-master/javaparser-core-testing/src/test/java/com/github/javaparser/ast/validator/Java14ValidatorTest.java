/*
 * Copyright (C) 2007-2010 Júlio Vilmar Gesser.
 * Copyright (C) 2011, 2013-2026 The JavaParser Team.
 *
 * This file is part of JavaParser.
 *
 * JavaParser can be used either under the terms of
 * a) the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 * b) the terms of the Apache License
 *
 * You should have received a copy of both licenses in LICENCE.LGPL and
 * LICENCE.APACHE. Please refer to those files for details.
 *
 * JavaParser is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 */

package com.github.javaparser.ast.validator;

import static com.github.javaparser.ParseStart.COMPILATION_UNIT;
import static com.github.javaparser.ParseStart.EXPRESSION;
import static com.github.javaparser.ParseStart.STATEMENT;
import static com.github.javaparser.ParserConfiguration.LanguageLevel.JAVA_14;
import static com.github.javaparser.Providers.provider;
import static com.github.javaparser.utils.TestUtils.assertNoProblems;
import static com.github.javaparser.utils.TestUtils.assertProblems;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ParserConfiguration;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.utils.TestUtils;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class Java14ValidatorTest {

    private final JavaParser javaParser = new JavaParser(new ParserConfiguration().setLanguageLevel(JAVA_14));

    // TODO: Confirm FORBIDDEN - pattern matching instanceof

    // TODO: Confirm PERMITTED - text blocks permitted

    @Nested
    class SwitchExpr {
        @Test
        void switchExprAllowed() {
            ParseResult<Expression> result =
                    javaParser.parse(EXPRESSION, provider("switch(x){case 3 -> System.out.println(0);}"));
            assertNoProblems(result);
        }

        @Test
        void noSwitchDefaultCaseAllowed() {
            ParseResult<Expression> result =
                    javaParser.parse(EXPRESSION, provider("switch(x){case null, default -> System.out.println(0);}"));
            assertProblems(
                    result,
                    "(line 1,col 11) Switch case null, default not supported. Pay attention that this feature is supported starting from 'JAVA_21' language level. If you need that feature the language level must be configured in the configuration before parsing the source files.");
        }

        @Test
        void noSwitchPatternAllowed() {
            ParseResult<Expression> result =
                    javaParser.parse(EXPRESSION, provider("switch(x){case String s -> System.out.println(0);}"));
            assertProblems(
                    result,
                    "(line 1,col 11) Switch patterns not supported. Pay attention that this feature is supported starting from 'JAVA_21' language level. If you need that feature the language level must be configured in the configuration before parsing the source files.");
        }

        @Test
        void switchExprMustHaveResultExpressions() {
            ParseResult<Expression> result = javaParser.parse(
                    EXPRESSION,
                    provider(
                            "switch(x){ case 1 -> throw new RuntimeException(); default -> throw new IllegalArgumentException(); }"));
            assertProblems(result, "(line 1,col 1) Switch expression does not have any result expressions.");
        }

        @Test
        void switchExprWithAtLeastOneResultExpressionAllowed() {
            ParseResult<Expression> result = javaParser.parse(
                    EXPRESSION, provider("switch(x){ case 1 -> throw new RuntimeException(); default -> 42; }"));
            assertNoProblems(result);
        }

        /**
         * Switch statements (not expressions) with all throwing cases are valid.
         * The "must have result expressions" rule only applies to switch expressions.
         */
        @Test
        void switchStmtWithAllThrowsAllowed() {
            ParseResult<Statement> result = javaParser.parse(
                    STATEMENT,
                    provider(
                            "switch(x){ case 1 -> throw new RuntimeException(); default -> throw new IllegalArgumentException(); }"));
            assertNoProblems(result);
        }

        /**
         * Classic colon-style switch statement with all throwing cases is valid.
         */
        @Test
        void switchStmtColonStyleWithAllThrowsAllowed() {
            ParseResult<Statement> result = javaParser.parse(
                    STATEMENT,
                    provider(
                            "switch(x){ case 1: throw new RuntimeException(); default: throw new IllegalArgumentException(); }"));
            assertNoProblems(result);
        }
    }
    /**
     * Records are available within Java 14 (preview), Java 15 (2nd preview), and Java 16 (release).
     * The introduction of records means that they are no longer able to be used as identifiers.
     */
    @Nested
    class Record {

        @Nested
        class RecordAsIdentifierPermitted {
            @Test
            void recordUsedAsClassName() {
                String s = "public class record {}";
                ParseResult<CompilationUnit> result = javaParser.parse(COMPILATION_UNIT, provider(s));
                TestUtils.assertNoProblems(result);
            }

            @Test
            void recordUsedAsFieldName() {
                String s = "class X { int record; }";
                ParseResult<CompilationUnit> result = javaParser.parse(COMPILATION_UNIT, provider(s));
                TestUtils.assertNoProblems(result);
            }
        }

        @Nested
        class RecordDeclarationForbidden {
            @Test
            void recordDeclaration() {
                String s = "record X() { }";
                ParseResult<CompilationUnit> result = javaParser.parse(COMPILATION_UNIT, provider(s));
                assertProblems(
                        result,
                        "(line 1,col 1) Record Declarations are not supported. Pay attention that this feature is supported starting from 'JAVA_14' language level. If you need that feature the language level must be configured in the configuration before parsing the source files.");
            }
        }
    }
}
