/*
 * Copyright (C) 2007-2010 Júlio Vilmar Gesser.
 * Copyright (C) 2011, 2013-2026 The JavaParser Team.
 *
 * This file is part of JavaParser.
 *
 * JavaParser can be used either under the terms of
 * a) the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 * b) the terms of the Apache License
 *
 * You should have received a copy of both licenses in LICENCE.LGPL and
 * LICENCE.APACHE. Please refer to those files for details.
 *
 * JavaParser is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 */

package com.github.javaparser.ast.observer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.github.javaparser.JavaParserAdapter;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.FieldDeclaration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import org.junit.jupiter.api.Test;

class PropagatingAstObserverTest {

    private final JavaParserAdapter parser = StaticJavaParser.newParserAdapter();

    @Test
    void verifyPropagation() {
        String code = "class A {  }";
        CompilationUnit cu = parser.parse(code);
        List<String> changes = new ArrayList<>();
        AstObserver observer = new PropagatingAstObserver() {
            @Override
            public void concretePropertyChange(
                    Node observedNode, ObservableProperty property, Object oldValue, Object newValue) {
                changes.add(String.format(
                        "%s.%s changed from %s to %s",
                        observedNode.getClass().getSimpleName(),
                        property.name().toLowerCase(Locale.ROOT),
                        oldValue,
                        newValue));
            }
        };
        cu.registerForSubtree(observer);

        assertEquals(Arrays.asList(), changes);

        FieldDeclaration fieldDeclaration = cu.getClassByName("A").get().addField("String", "foo");
        assertEquals(Arrays.asList(), changes);
        assertTrue(fieldDeclaration.isRegistered(observer));

        cu.getClassByName("A")
                .get()
                .getFieldByName("foo")
                .get()
                .getVariables()
                .get(0)
                .setName("Bar");
        assertEquals(Arrays.asList("VariableDeclarator.name changed from foo to Bar"), changes);
    }
}
