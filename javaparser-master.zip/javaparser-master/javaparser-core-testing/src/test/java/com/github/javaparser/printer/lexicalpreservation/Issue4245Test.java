/*
 * Copyright (C) 2013-2026 The JavaParser Team.
 *
 * This file is part of JavaParser.
 *
 * JavaParser can be used either under the terms of
 * a) the GNU Lesser General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 * b) the terms of the Apache License
 *
 * You should have received a copy of both licenses in LICENCE.LGPL and
 * LICENCE.APACHE. Please refer to those files for details.
 *
 * JavaParser is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 */

package com.github.javaparser.printer.lexicalpreservation;

import static com.github.javaparser.utils.TestUtils.assertEqualsStringIgnoringEol;

import com.github.javaparser.ParserConfiguration.LanguageLevel;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import org.junit.jupiter.api.Test;

class Issue4245Test extends AbstractLexicalPreservingTest {

    @Test
    public void test() {

        parser.getParserConfiguration().setLanguageLevel(LanguageLevel.JAVA_17);
        considerCode("public sealed interface IUpdatePortCommand permits UpdateScheduleCommand, UpdateStateCommand {}");

        ClassOrInterfaceDeclaration classOrInterface =
                cu.findFirst(ClassOrInterfaceDeclaration.class).get();
        classOrInterface.setModifiers();

        String expected = "interface IUpdatePortCommand permits UpdateScheduleCommand, UpdateStateCommand {}";

        assertEqualsStringIgnoringEol(expected, LexicalPreservingPrinter.print(cu));
    }
}
