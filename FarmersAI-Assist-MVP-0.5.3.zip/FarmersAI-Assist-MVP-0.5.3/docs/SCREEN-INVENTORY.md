# FarmersAI Assist — Screen Inventory (MVP 0.3)

FarmersAI Assist currently contains 9 WebApp screens.

1. Dashboard — Primary navigation and selected Rally context.
2. Rally Analysis — Read-only requirement and Acceptance Criteria analysis.
3. Test Case Proposals — Candidate test cases generated from the selected US.
4. Test Case Editor — Editable Rally-ready test case, steps and Expected Result images.
5. Task Proposals — Proposed QA activities for the selected US.
6. Rally Publish Review — Human approval gate before publishing approved objects to Rally.
7. Automation Workspace — Maps approved Test Cases to the existing Java + Playwright project.
8. Copilot Code Generation — Reserved orchestration screen for GitHub Copilot generation.
9. Execution & Traceability — US → Rally TC → FarmersAI ID → Java test → PASS/FAIL traceability.

Only the Dashboard appears in the left sidebar. Future workflow screens are intentionally reached from Dashboard cards/actions so the sidebar stays minimal.


## MVP 0.4 navigation behavior

- Screen 1 (Dashboard) does not display a Dashboard button.
- Screens 2–9 display the Dashboard button.
- Screens 2–9 include functional Previous and Next arrow controls.
- Previous on Screen 2 returns to Screen 1.
- Next is disabled on Screen 9.
- Dashboard navigation on Screens 2–9 opens a branded confirmation modal.
- Cancel closes the modal and preserves the current screen.
- Accept discards the demonstrative unsaved UI state and returns to Screen 1.


## MVP 0.4.1 sidebar correction

The sidebar policy is now enforced consistently:
- Screen 1 (Dashboard): no menu option is displayed in the sidebar.
- Screens 2–9: Dashboard is the ONLY sidebar navigation option.
- No Settings, Test Case Proposals, Task Proposals, Automation Workspace, Reports, User Management, Integrations, Audit Log, Help, or any other workflow menu items are permitted in the sidebar.
- Workflow navigation remains controlled by the Previous/Next arrows and Dashboard confirmation behavior.
