# FarmersAI Assist Roadmap

## Phase 0 — Foundation
- Java 17
- Spring Boot
- Playwright Java dependency
- IntelliJ project
- Scanner launcher
- Web UI
- Mock scanner

## Phase 1 — Rally Read-Only
- Authentication
- Scan sprint
- User Stories
- Dynamic/custom fields
- Tasks
- Test Cases
- Attachments
- Relationships
- Pagination
- Error handling

## Phase 2 — Intelligence
- NEW / CHANGED / UNCHANGED / REMOVED
- Requirement extraction
- Risk scoring
- Coverage analysis
- Dependency analysis
- Ambiguity detection

## Phase 3 — QA Proposal Engine
- Proposed Tasks
- Proposed Test Cases
- Preconditions
- Validation Input
- Steps
- Expected Results
- Postconditions
- Automation candidate flag
- Priority and risk

## Phase 4 — Review UI
- Edit proposals
- Add/remove steps
- Add images to Expected Results
- Approve/reject
- Audit history

## Phase 5 — Rally Publish
- Publish approved Tasks
- Publish approved Test Cases
- Attachment upload
- Traceability
- Duplicate prevention

## Phase 6 — MCP / Copilot
- farmers_get_story
- farmers_scan_sprint
- farmers_get_analysis
- farmers_get_proposed_tests
- farmers_get_tasks
- farmers_get_coverage
