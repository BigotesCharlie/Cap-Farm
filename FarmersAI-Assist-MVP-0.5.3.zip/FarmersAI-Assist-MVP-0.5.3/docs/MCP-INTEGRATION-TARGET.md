# MCP Integration Target

Next phase replaces the mock hierarchy with Rally MCP-backed calls.

```text
FarmersAI Assist WebApp
        |
        v
FarmersAI Backend API
        |
        v
Rally MCP Client
        |
        v
Rally MCP Server
        |
        v
Rally WSAPI
```

Target hierarchy:

`Project → Sprint / Iteration → Feature → User Story → Tasks / Test Cases`

Planned read tools: list projects, sprints, features, user stories, tasks, test cases and attachments. Rally write operations remain disabled until a later human-approval phase.
