$ErrorActionPreference = "Stop"
Write-Host "Starting FarmersAI Assist..."
mvn spring-boot:run
