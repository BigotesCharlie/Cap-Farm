$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($env:RALLY_CLIENT_ID)) {
    Write-Host "RALLY_CLIENT_ID is not set." -ForegroundColor Red
    exit 1
}
if ([string]::IsNullOrWhiteSpace($env:RALLY_CLIENT_SECRET)) {
    Write-Host "RALLY_CLIENT_SECRET is not set." -ForegroundColor Red
    exit 1
}

$env:RALLY_REDIRECT_URI = "http://localhost:8080/oauth/rally/callback"
Write-Host "Starting FarmersAI Assist with Rally OAuth..." -ForegroundColor Cyan
mvn spring-boot:run
