$ErrorActionPreference = "Stop"

Write-Host "FarmersAI Assist - Mock Sprint Scanner"
Write-Host ""

$project = Read-Host "Project [SWAT]"
if ([string]::IsNullOrWhiteSpace($project)) { $project = "SWAT" }

$sprint = Read-Host "Sprint"
if ([string]::IsNullOrWhiteSpace($sprint)) {
    throw "Sprint is required."
}

mvn exec:java `
  "-Dexec.mainClass=com.farmers.aiassist.scanner.SprintScannerLauncher" `
  "-Dexec.args=--project=$project --sprint=`"$sprint`" --mock=true"
