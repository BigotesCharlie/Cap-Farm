
(() => {
  const screens = [
    "/",
    "/rally-analysis",
    "/test-case-proposals",
    "/test-case-editor",
    "/task-proposals",
    "/rally-publish",
    "/automation-workspace",
    "/copilot-generation",
    "/execution-traceability"
  ];

  const currentPath = window.location.pathname.replace(/\/+$/, "") || "/";
  const index = screens.indexOf(currentPath);

  window.faiGoBack = () => {
    if (index > 1) window.location.href = screens[index - 1];
    else if (index === 1) window.location.href = screens[0];
  };

  window.faiGoForward = () => {
    if (index >= 1 && index < screens.length - 1) window.location.href = screens[index + 1];
  };

  window.faiOpenDashboardConfirm = () => {
    const modal = document.getElementById("dashboardConfirm");
    if (modal) {
      modal.classList.add("open");
      modal.setAttribute("aria-hidden", "false");
      document.getElementById("dashboardCancel")?.focus();
    }
  };

  window.faiCloseDashboardConfirm = () => {
    const modal = document.getElementById("dashboardConfirm");
    if (modal) {
      modal.classList.remove("open");
      modal.setAttribute("aria-hidden", "true");
    }
  };

  window.faiAcceptDashboard = () => {
    // Demonstrative behavior: intentionally discard unsaved UI state and return to Screen 1.
    window.location.href = "/";
  };

  document.addEventListener("keydown", e => {
    const modal = document.getElementById("dashboardConfirm");
    if (e.key === "Escape" && modal?.classList.contains("open")) window.faiCloseDashboardConfirm();
  });

  document.getElementById("dashboardConfirm")?.addEventListener("click", e => {
    if (e.target.id === "dashboardConfirm") window.faiCloseDashboardConfirm();
  });
})();
