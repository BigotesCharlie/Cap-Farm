package com.farmers.aiassist.web;

import com.farmers.aiassist.config.RallyOAuthProperties;
import com.farmers.aiassist.rally.oauth.RallyOAuthService;
import com.farmers.aiassist.rally.oauth.RallyOAuthSession;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.view.RedirectView;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

@Controller
public class RallyOAuthController {
    private final RallyOAuthProperties properties;
    private final RallyOAuthService oauthService;
    private final RallyOAuthSession oauthSession;

    public RallyOAuthController(RallyOAuthProperties properties,
                                RallyOAuthService oauthService,
                                RallyOAuthSession oauthSession) {
        this.properties = properties;
        this.oauthService = oauthService;
        this.oauthSession = oauthSession;
    }

    @GetMapping("/oauth/rally/connect")
    public RedirectView connect(HttpSession session) {
        String state = oauthService.newState();
        oauthSession.setState(session, state);
        return new RedirectView(oauthService.createAuthorizationUrl(state));
    }

    @GetMapping("/oauth/rally/callback")
    public RedirectView callback(
            @RequestParam(required = false) String code,
            @RequestParam(required = false) String state,
            @RequestParam(required = false) String error,
            @RequestParam(name = "error_description", required = false) String errorDescription,
            HttpSession session) {

        if (error != null && !error.isBlank()) {
            return new RedirectView("/?rallyOAuthError=" + q(errorDescription == null ? error : errorDescription));
        }

        String expected = oauthSession.getState(session);
        if (expected == null || state == null || !expected.equals(state)) {
            oauthSession.clearState(session);
            return new RedirectView("/?rallyOAuthError=OAuth%20state%20validation%20failed");
        }

        if (code == null || code.isBlank()) {
            oauthSession.clearState(session);
            return new RedirectView("/?rallyOAuthError=Authorization%20code%20missing");
        }

        try {
            RallyOAuthService.TokenResponse token = oauthService.exchangeAuthorizationCode(code);
            oauthSession.storeToken(session, token.accessToken(), token.expiresInSeconds());
            oauthSession.clearState(session);
            return new RedirectView("/?rallyConnected=true");
        } catch (Exception e) {
            oauthSession.clearState(session);
            return new RedirectView("/?rallyOAuthError=" + q(e.getMessage()));
        }
    }

    @GetMapping("/oauth/rally/disconnect")
    public RedirectView disconnect(HttpSession session) {
        oauthSession.disconnect(session);
        return new RedirectView("/?rallyDisconnected=true");
    }

    @GetMapping("/api/rally/oauth/status")
    @ResponseBody
    public ResponseEntity<Map<String,Object>> status(HttpSession session) {
        Map<String,Object> map = new LinkedHashMap<>();
        map.put("configured", properties.isConfigured());
        map.put("connected", oauthSession.isConnected(session));
        map.put("mode", "READ_ONLY");
        if (oauthSession.getExpiresAt(session) != null) {
            map.put("expiresAt", oauthSession.getExpiresAt(session).toString());
        }
        return ResponseEntity.ok(map);
    }

    private String q(String value) {
        return URLEncoder.encode(value == null ? "Unknown OAuth error" : value, StandardCharsets.UTF_8);
    }
}
