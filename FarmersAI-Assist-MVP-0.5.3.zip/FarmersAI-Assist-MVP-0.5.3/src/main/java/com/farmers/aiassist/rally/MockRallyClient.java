package com.farmers.aiassist.rally;

import com.farmers.aiassist.model.UserStorySnapshot;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.List;

@Component
public class MockRallyClient implements RallyClient {

    @Override
    public List<UserStorySnapshot> findUserStoriesBySprint(String project, String sprint) {
        UserStorySnapshot us = new UserStorySnapshot();
        us.setObjectId("851671612555");
        us.setFormattedId("US1209714");
        us.setName("FFQ - Migrate Selenium automation scripts to Playwright using the existing test automation framework for Auto LOB");
        us.setDescription("As a QA Automation Engineer, I want to convert existing Selenium-based automation scripts into Playwright scripts.");
        us.setNotes("");
        us.setAcceptanceCriteria("");
        us.setOwner("Carlos Garcia");
        us.setProject(project);
        us.setScheduleState("In-Progress");
        us.setFlowState("In-Progress - Dev");
        us.setPlanEstimate(5.0);
        us.setIteration(sprint);
        us.setRelease("PI 2026.4.2");
        us.setBlocked(false);
        us.setCreationDate("2026-07-06T00:00:00.000Z");
        us.setRawFields(new LinkedHashMap<>());
        return List.of(us);
    }
}
