package com.farmers.aiassist.rally.oauth;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;

import java.time.Instant;

@Component
public class RallyOAuthSession {
    private static final String ACCESS_TOKEN = "farmersai.rally.accessToken";
    private static final String EXPIRES_AT = "farmersai.rally.expiresAt";
    private static final String STATE = "farmersai.rally.oauthState";

    public void setState(HttpSession session, String state) { session.setAttribute(STATE, state); }
    public String getState(HttpSession session) {
        Object v = session.getAttribute(STATE);
        return v == null ? null : v.toString();
    }
    public void clearState(HttpSession session) { session.removeAttribute(STATE); }

    public void storeToken(HttpSession session, String accessToken, Long expiresInSeconds) {
        session.setAttribute(ACCESS_TOKEN, accessToken);
        if (expiresInSeconds != null && expiresInSeconds > 0) {
            session.setAttribute(EXPIRES_AT, Instant.now().plusSeconds(expiresInSeconds));
        } else {
            session.removeAttribute(EXPIRES_AT);
        }
    }

    public String getAccessToken(HttpSession session) {
        Object v = session.getAttribute(ACCESS_TOKEN);
        return v == null ? null : v.toString();
    }

    public Instant getExpiresAt(HttpSession session) {
        Object v = session.getAttribute(EXPIRES_AT);
        return v instanceof Instant i ? i : null;
    }

    public boolean isConnected(HttpSession session) {
        String token = getAccessToken(session);
        if (token == null || token.isBlank()) return false;
        Instant exp = getExpiresAt(session);
        return exp == null || Instant.now().isBefore(exp.minusSeconds(30));
    }

    public void disconnect(HttpSession session) {
        session.removeAttribute(ACCESS_TOKEN);
        session.removeAttribute(EXPIRES_AT);
        session.removeAttribute(STATE);
    }
}
