package com.farmers.aiassist.web;

import com.farmers.aiassist.model.SprintScanResult;
import com.farmers.aiassist.service.SprintScannerService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/scans")
public class SprintScanController {

    private final SprintScannerService scannerService;

    public SprintScanController(SprintScannerService scannerService) {
        this.scannerService = scannerService;
    }

    @PostMapping("/sprint")
    public ResponseEntity<?> scanSprint(@RequestBody SprintScanRequest request) {
        try {
            SprintScanResult result = scannerService.scan(
                    request.project(),
                    request.sprint(),
                    request.mock());
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                    Map.of("error", e.getMessage()));
        }
    }

    public record SprintScanRequest(
            String project,
            String sprint,
            Boolean mock) {
    }
}
