package com.farmers.aiassist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class FarmersAiAssistApplication {

    public static void main(String[] args) {
        SpringApplication.run(FarmersAiAssistApplication.class, args);
    }
}
