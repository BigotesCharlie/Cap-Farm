package com.farmers.aiassist.rally;

import com.farmers.aiassist.model.UserStorySnapshot;

import java.util.List;

public interface RallyClient {
    List<UserStorySnapshot> findUserStoriesBySprint(String project, String sprint);
}
