package com.farmers.aiassist.rally.oauth;

import com.farmers.aiassist.config.RallyProperties;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Service;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class RallyOAuthWsapiService {

    private static final String PROJECT_ROOT_NAME = "Marketing";

    private static final String STORY_FETCH =
            "ObjectID,FormattedID,Name,Description,Notes,AcceptanceCriteria,Owner,Project,"
                    + "ScheduleState,FlowState,PlanEstimate,Parent,Feature,Release,Iteration,"
                    + "CreationDate,LastUpdateDate,Blocked,Tags,Tasks,TestCases,Attachments";

    private final RallyProperties properties;
    private final RallyOAuthSession oauthSession;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;

    public RallyOAuthWsapiService(
            RallyProperties properties,
            RallyOAuthSession oauthSession,
            ObjectMapper objectMapper) {

        this.properties = properties;
        this.oauthSession = oauthSession;
        this.objectMapper = objectMapper;
        this.httpClient = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .build();
    }

    public JsonNode getProjects(HttpSession session) {
        JsonNode allProjects = query(
                session,
                "project",
                null,
                "ObjectID,Name,State,Parent",
                "Name");

        JsonNode results = allProjects.path("QueryResult").path("Results");
        var filtered = objectMapper.createArrayNode();

        if (!results.isArray()) {
            return allProjects;
        }

        Map<Long, JsonNode> byId = new LinkedHashMap<>();
        for (JsonNode project : results) {
            long objectId = project.path("ObjectID").asLong(0);
            if (objectId > 0) {
                byId.put(objectId, project);
            }
        }

        for (JsonNode project : results) {
            if (isUnderProjectRoot(project, byId, PROJECT_ROOT_NAME)) {
                filtered.add(project);
            }
        }

        var response = objectMapper.createObjectNode();
        var queryResult = objectMapper.createObjectNode();
        queryResult.put("_rallyAPIMajor", "2");
        queryResult.put("_rallyAPIMinor", "0");
        queryResult.put("TotalResultCount", filtered.size());
        queryResult.put("StartIndex", 1);
        queryResult.put("PageSize", filtered.size());
        queryResult.set("Results", filtered);
        response.set("QueryResult", queryResult);
        return response;
    }

    private boolean isUnderProjectRoot(
            JsonNode project,
            Map<Long, JsonNode> byId,
            String rootName) {

        if (project == null || rootName == null || rootName.isBlank()) {
            return false;
        }

        if (rootName.equalsIgnoreCase(project.path("Name").asText(""))) {
            return false;
        }

        Set<Long> visited = new LinkedHashSet<>();
        JsonNode current = project;

        while (current != null) {
            JsonNode parent = current.path("Parent");
            if (parent.isMissingNode() || parent.isNull()) {
                return false;
            }

            String parentName = parent.path("_refObjectName").asText("");
            if (rootName.equalsIgnoreCase(parentName)) {
                return true;
            }

            long parentId = objectIdFromRef(parent.path("_ref").asText(""));
            if (parentId <= 0 || !visited.add(parentId)) {
                return false;
            }

            current = byId.get(parentId);
        }

        return false;
    }

    private long objectIdFromRef(String ref) {
        if (ref == null || ref.isBlank()) {
            return 0;
        }
        int slash = ref.lastIndexOf('/');
        if (slash < 0 || slash + 1 >= ref.length()) {
            return 0;
        }
        String tail = ref.substring(slash + 1);
        int query = tail.indexOf('?');
        if (query >= 0) {
            tail = tail.substring(0, query);
        }
        try {
            return Long.parseLong(tail);
        } catch (NumberFormatException ignored) {
            return 0;
        }
    }

    public JsonNode getIterations(HttpSession session, String project) {
        String query = "(Project.Name = \"" + escape(project) + "\")";
        return query(
                session,
                "iteration",
                query,
                "ObjectID,Name,StartDate,EndDate,State,Project",
                "StartDate DESC");
    }

    /**
     * Rally Features are portfolio items and do not directly belong to an Iteration.
     * To honor Dashboard dependency Project -> Iteration -> Feature, this method:
     *  1. Finds User Stories in the selected Project + Iteration.
     *  2. Collects their unique Feature references.
     *  3. Resolves those references to full Feature records.
     */
    public List<Map<String, Object>> getFeaturesForIteration(
            HttpSession session,
            String project,
            String iteration) {

        String query = "((Project.Name = \"" + escape(project) + "\") "
                + "AND (Iteration.Name = \"" + escape(iteration) + "\"))";

        JsonNode stories = query(
                session,
                "hierarchicalrequirement",
                query,
                "ObjectID,FormattedID,Feature",
                "FormattedID");

        JsonNode results = stories.path("QueryResult").path("Results");
        Set<String> refs = new LinkedHashSet<>();

        if (results.isArray()) {
            for (JsonNode story : results) {
                JsonNode feature = story.path("Feature");
                String ref = feature.path("_ref").asText("");
                if (!ref.isBlank()) {
                    refs.add(ref);
                }
            }
        }

        List<Map<String, Object>> features = new ArrayList<>();
        for (String ref : refs) {
            JsonNode featureResponse = getByRef(
                    session,
                    ref,
                    "ObjectID,FormattedID,Name,State,Project");
            JsonNode feature = firstObjectNode(featureResponse);
            if (feature != null) {
                Map<String, Object> item = new LinkedHashMap<>();
                item.put("objectId", feature.path("ObjectID").asLong());
                item.put("formattedId", feature.path("FormattedID").asText(""));
                item.put("name", feature.path("Name").asText(""));
                item.put("ref", feature.path("_ref").asText(ref));
                features.add(item);
            }
        }

        return features;
    }

    public JsonNode getUserStories(
            HttpSession session,
            String project,
            String iteration,
            Long featureObjectId) {

        StringBuilder query = new StringBuilder();
        query.append("((Project.Name = \"")
                .append(escape(project))
                .append("\") AND (Iteration.Name = \"")
                .append(escape(iteration))
                .append("\"))");

        if (featureObjectId != null) {
            query.insert(0, "(");
            query.append(" AND (Feature.ObjectID = ")
                    .append(featureObjectId)
                    .append("))");
        }

        return query(
                session,
                "hierarchicalrequirement",
                query.toString(),
                STORY_FETCH,
                "FormattedID");
    }

    public JsonNode getUserStory(HttpSession session, String formattedId) {
        String query = "(FormattedID = \"" + escape(formattedId) + "\")";
        return query(
                session,
                "hierarchicalrequirement",
                query,
                STORY_FETCH,
                "FormattedID");
    }

    private JsonNode query(
            HttpSession session,
            String type,
            String query,
            String fetch,
            String order) {

        String token = requireToken(session);

        try {
            StringBuilder url = new StringBuilder()
                    .append(properties.getBaseUrl())
                    .append("/slm/webservice/v2.0/")
                    .append(type)
                    .append("?pagesize=")
                    .append("project".equals(type) ? 2000 : Math.max(properties.getPageSize(), 200));

            if (query != null && !query.isBlank()) {
                url.append("&query=").append(enc(query));
            }
            if (fetch != null && !fetch.isBlank()) {
                url.append("&fetch=").append(enc(fetch));
            }
            if (order != null && !order.isBlank()) {
                url.append("&order=").append(enc(order));
            }

            HttpResponse<String> response = sendGet(token, url.toString());

            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IllegalStateException(
                        "Rally WSAPI returned HTTP " + response.statusCode());
            }

            return objectMapper.readTree(response.body());

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Rally request interrupted.", e);
        } catch (Exception e) {
            if (e instanceof IllegalStateException ise) {
                throw ise;
            }
            throw new IllegalStateException(
                    "Rally WSAPI request failed: " + e.getMessage(),
                    e);
        }
    }

    private JsonNode getByRef(
            HttpSession session,
            String ref,
            String fetch) {

        String token = requireToken(session);
        try {
            String separator = ref.contains("?") ? "&" : "?";
            String url = ref + separator + "fetch=" + enc(fetch);
            HttpResponse<String> response = sendGet(token, url);

            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IllegalStateException(
                        "Rally Feature lookup returned HTTP "
                                + response.statusCode());
            }

            return objectMapper.readTree(response.body());

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Rally request interrupted.", e);
        } catch (Exception e) {
            if (e instanceof IllegalStateException ise) {
                throw ise;
            }
            throw new IllegalStateException(
                    "Unable to resolve Rally Feature: " + e.getMessage(),
                    e);
        }
    }

    private JsonNode firstObjectNode(JsonNode response) {
        if (response == null) {
            return null;
        }

        // A direct Rally object response generally contains a property such as
        // PortfolioItem/Feature. Return the first object value that contains ObjectID.
        if (response.has("ObjectID")) {
            return response;
        }

        var fields = response.properties();
        for (Map.Entry<String, JsonNode> entry : fields) {
            JsonNode node = entry.getValue();
            if (node != null && node.isObject() && node.has("ObjectID")) {
                return node;
            }
        }

        return null;
    }

    private HttpResponse<String> sendGet(String token, String url)
            throws Exception {

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Accept", "application/json")
                .header("ZSESSIONID", token)
                .GET()
                .build();

        return httpClient.send(
                request,
                HttpResponse.BodyHandlers.ofString());
    }

    private String requireToken(HttpSession session) {
        String token = oauthSession.getAccessToken(session);
        if (token == null || token.isBlank()) {
            throw new IllegalStateException(
                    "Rally is not connected for this FarmersAI Assist session.");
        }
        return token;
    }

    private String enc(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8);
    }

    private String escape(String value) {
        return value == null
                ? ""
                : value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
