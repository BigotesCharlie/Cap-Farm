package com.farmers.aiassist.web;

import com.farmers.aiassist.rally.oauth.RallyOAuthWsapiService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tools.jackson.databind.JsonNode;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/rally")
public class RallyReadOnlyController {

    private final RallyOAuthWsapiService wsapiService;

    public RallyReadOnlyController(
            RallyOAuthWsapiService wsapiService) {
        this.wsapiService = wsapiService;
    }

    @GetMapping("/projects")
    public ResponseEntity<JsonNode> projects(HttpSession session) {
        return ResponseEntity.ok(wsapiService.getProjects(session));
    }

    @GetMapping("/iterations")
    public ResponseEntity<JsonNode> iterations(
            @RequestParam String project,
            HttpSession session) {

        return ResponseEntity.ok(
                wsapiService.getIterations(session, project));
    }

    @GetMapping("/features")
    public ResponseEntity<List<Map<String, Object>>> features(
            @RequestParam String project,
            @RequestParam String iteration,
            HttpSession session) {

        return ResponseEntity.ok(
                wsapiService.getFeaturesForIteration(
                        session,
                        project,
                        iteration));
    }

    @GetMapping("/user-stories")
    public ResponseEntity<JsonNode> userStories(
            @RequestParam String project,
            @RequestParam String iteration,
            @RequestParam(required = false) Long featureObjectId,
            HttpSession session) {

        return ResponseEntity.ok(
                wsapiService.getUserStories(
                        session,
                        project,
                        iteration,
                        featureObjectId));
    }

    @GetMapping("/user-story/{formattedId}")
    public ResponseEntity<JsonNode> userStory(
            @PathVariable String formattedId,
            HttpSession session) {

        return ResponseEntity.ok(
                wsapiService.getUserStory(session, formattedId));
    }
}
