/**
 * iGero - safe Playwright registry isolation checks.
 * Creates ONLY short-lived files under migration/pervez-json/.igero-diagnostic-*.
 * All invocations use --list: NO browser, QA request or business action.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

export function buildProbeFiles() {
  return {
    config: `const { defineConfig } = require('@playwright/test');\nmodule.exports = defineConfig({ testDir: __dirname, testMatch: '**/*.spec.cjs', projects: [{ name:'chromium' }] });\n`,
    spec: `const { test, expect } = require('@playwright/test');\ntest('IGERO_REGISTRY_PROBE_ONLY', async () => { expect(true).toBeTruthy(); });\n`,
  };
}
export function classifyRegistryFailure({baselineTotal,isolatedRegistered,sourceCount}) {
  if(baselineTotal>0) return {code:'REGISTERED', message:'Active Playwright project registers tests.'};
  if(isolatedRegistered>0) return {code:'PROJECT_CONFIG_EXCLUDES_TESTS', message:`Playwright CLI can register a test in isolation but the active project registers 0 tests (${sourceCount} source specs detected). Inspect effective testDir, testMatch, testIgnore and project-level grep.`};
  return {code:'PLAYWRIGHT_RUNNER_NOT_VERIFIED', message:'The isolated Playwright registry probe also failed. Check the local CLI, package resolution and runner output before editing any tests.'};
}
export async function isolatePlaywrightRegistry({projectRoot, invoke}) {
  const directory=path.join(projectRoot,'migration','pervez-json',`.igero-diagnostic-${crypto.randomBytes(6).toString('hex')}`);
  const {config,spec}=buildProbeFiles();
  try {
    await fs.mkdir(directory,{recursive:true});
    await fs.writeFile(path.join(directory,'playwright.config.cjs'),config,'utf8');
    await fs.writeFile(path.join(directory,'registry-probe.spec.cjs'),spec,'utf8');
    const response=await invoke(path.join(directory,'playwright.config.cjs'));
    return {status:response.exitCode===0 && /IGERO_REGISTRY_PROBE_ONLY/.test(response.output)?'PASS':'FAIL',
      exitCode:response.exitCode, outputTail:String(response.output||'').split(/\r?\n/).slice(-12).join('\n').slice(0,1500),
      note:'Temporary probe was registered via --list only. It was not executed. Files were removed after the check.'};
  } catch(e){return {status:'FAIL',exitCode:null,outputTail:String(e.message).slice(0,500),note:'Isolated registry probe could not complete.'};}
  finally{await fs.rm(directory,{recursive:true,force:true}).catch(()=>{});}
}
