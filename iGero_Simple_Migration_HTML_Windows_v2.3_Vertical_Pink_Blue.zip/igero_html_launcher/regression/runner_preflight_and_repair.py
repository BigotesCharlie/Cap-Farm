"""v2.2 regression: zero-test registry blocks BEFORE Copilot credits; explicit repair restores.
All tools are fake; no browser, AI credit or business-side effects.
"""
import json,os,pathlib,shutil,subprocess,tempfile,time,urllib.request,urllib.error,urllib.parse
source=pathlib.Path(__file__).resolve().parents[1]
root=pathlib.Path(tempfile.mkdtemp(prefix='igero_v22_preflight_'))
proc=None
try:
 java=root/'java';pw=root/'pw';bins=root/'bin';launcher=root/'launcher'
 javafile=java/'src/test/java/com/farmers/ffq/acehome/AceHomeSimpleTest.java'
 javafile.parent.mkdir(parents=True);javafile.write_text('public class AceHomeSimpleTest { @Test public void testContentValidationHomeLob() {} }')
 spec=pw/'tests/acehome/AceHomeSimpleTest.spec.ts';spec.parent.mkdir(parents=True)
 spec.write_text("import {test,expect} from '@playwright/test';\ntest('testContentValidationHomeLob',async()=>{expect(1).toBe(1)});\n")
 (pw/'node_modules/@playwright/test').mkdir(parents=True);(pw/'node_modules/@playwright/test/package.json').write_text('{}')
 (pw/'node_modules/.bin').mkdir(parents=True);(pw/'node_modules/.bin/playwright').touch()
 artifacts=pw/'migration/pervez-json/AceHomeSimpleTest__testContentValidationHomeLob';artifacts.mkdir(parents=True)
 (artifacts/'contract.json').write_text(json.dumps({'className':'AceHomeSimpleTest','methodName':'testContentValidationHomeLob','steps':[],'assertions':[{'id':'A01'}]}))
 (artifacts/'prompt.md').write_text('Preserve the original Java source and implement all mandatory assertions in Playwright.')
 marker=root/'registry-repaired';calls=root/'copilot-calls';bins.mkdir();launcher.mkdir()
 (bins/'npx').write_text('''#!/usr/bin/env python3
import sys,os,pathlib
args=sys.argv[1:]
if '--list' in args:
  config=args[args.index('--config')+1] if '--config' in args else ''
  if '.igero-diagnostic-' in config:
    print('[chromium] › registry-probe.spec.cjs:2:1 › IGERO_REGISTRY_PROBE_ONLY');sys.exit(0)
  if pathlib.Path(os.environ['MOCK_REGISTRY_MARKER']).exists():
    print('[chromium] › tests/acehome/AceHomeSimpleTest.spec.ts:2:1 › testContentValidationHomeLob');sys.exit(0)
  print('Error: No tests found.');sys.exit(1)
if 'tsc' in args:sys.exit(0)
print('No browser execution should be attempted');sys.exit(3)
''')
 (bins/'pwsh').write_text('''#!/usr/bin/env python3
import os,pathlib
p=pathlib.Path(os.environ['MOCK_COPILOT_COUNT'])
p.write_text(p.read_text()+"1" if p.exists() else "1")
pathlib.Path(os.environ['MOCK_REGISTRY_MARKER']).write_text('ready')
print('MOCK: registry repaired; no actual Copilot/QA call')
''')
 (bins/'copilot').write_text('#!/bin/sh\necho MockCopilot\nexit 0\n')
 (bins/'npm').write_text('#!/bin/sh\nexit 0\n')
 for x in bins.iterdir():x.chmod(0o755)
 for filename in ('server.mjs','registry-isolation.mjs','focused-test-resolver.mjs','lob-catalog.mjs','index.html','app.js','invoke-copilot.ps1'):
  shutil.copy2(source/filename,launcher/filename)
 env=os.environ.copy();env.update({'PATH':str(bins)+os.pathsep+env['PATH'],'IGERO_PANEL_PORT':'18874','MOCK_REGISTRY_MARKER':str(marker),'MOCK_COPILOT_COUNT':str(calls)})
 proc=subprocess.Popen(['node','server.mjs'],cwd=launcher,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
 def api(uri,data=None):
  req=urllib.request.Request('http://127.0.0.1:18874'+uri,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(req,timeout=30) as r:return json.load(r)
 for _ in range(80):
  try:api('/api/job');break
  except Exception:time.sleep(.1)
 api('/api/config',{'javaRoot':str(java),'playwrightRoot':str(pw),'autoTypecheck':True,'autoFunctionalCheck':True,'testEnv':'MA11'})
 methodid='AceHomeSimpleTest#testContentValidationHomeLob'
 diag=api('/api/playwright-diagnostics?id='+urllib.parse.quote(methodid))
 assert diag['status']=='NO_REGISTERED_TESTS',diag
 assert diag['runnerIsolation']['status']=='PASS',diag
 assert diag['registryDiagnosis']['code']=='PROJECT_CONFIG_EXCLUDES_TESTS',diag
 assert not list((pw/'migration/pervez-json').glob('.igero-diagnostic-*'))
 print('PASS: runner can register isolated test; root project config excludes all tests; temp files removed')
 api('/api/start',{'methodId':methodid,'mode':'all'})
 for _ in range(80):
  state=api('/api/job')
  if state['status']!='running':break
  time.sleep(.1)
 assert state['status']=='blocked',state
 assert 'PLAYWRIGHT_REGISTRY_PREFLIGHT_FAILED' in state['error'],state
 assert not calls.exists(),'Copilot unexpectedly invoked despite empty registry'
 print('PASS: full migration stops before calling Copilot; source contract untouched')
 result=api('/api/repair-playwright-registry',{'methodId':methodid})
 assert result['registered']==1,result
 assert calls.read_text()=='1',calls.read_text()
 print('PASS: explicit repair invoked one mocked Copilot call and restored project test registration')
 recovered=api('/api/spec-candidates?id='+urllib.parse.quote(methodid))
 assert recovered['registered']==1,recovered
 print('PASS: after repair, selected Java method maps to one executable Playwright spec')
finally:
 if proc:
  proc.terminate()
  try:proc.wait(timeout=3)
  except Exception:proc.kill()
 shutil.rmtree(root,ignore_errors=True)
