import test from 'node:test';
import assert from 'node:assert/strict';
import {classifyLob,buildLobCatalog,filterMethods} from '../lob-catalog.mjs';
const rows=[
  {id:'AceHomeNameAndDobPageTest#testName',className:'AceHomeNameAndDobPageTest',relativePath:'src/test/java/com/farmers/ffq/acehome/AceHomeNameAndDobPageTest.java'},
  {id:'AceHomeNameAndDobPageTest#testDOB',className:'AceHomeNameAndDobPageTest',relativePath:'src/test/java/com/farmers/ffq/acehome/AceHomeNameAndDobPageTest.java'},
  {id:'AceHomeAddressPageTest#testAddress',className:'AceHomeAddressPageTest',relativePath:'src/test/java/com/farmers/ffq/acehome/AceHomeAddressPageTest.java'},
  {id:'AutoQuoteTest#testAuto',className:'AutoQuoteTest',relativePath:'src/test/java/com/farmers/ffq/auto/AutoQuoteTest.java'},
  {id:'AceCondoDetailsTest#testCondo',className:'AceCondoDetailsTest',relativePath:'src/test/java/com/farmers/ffq/acecondo/AceCondoDetailsTest.java'},
  {id:'AceRentersContactPageTest#testRenters',className:'AceRentersContactPageTest',relativePath:'src/test/java/com/farmers/ffq/acerenters/AceRentersContactPageTest.java'},
  {id:'AceAutoHomeBundleTests#testBundle',className:'AceAutoHomeBundleTests',relativePath:'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java'},
].map(x=>({...x,...{lob:classifyLob(x.relativePath).id,lobLabel:classifyLob(x.relativePath).label},suite:x.relativePath}));
test('LOB is derived from Java source package, not method/class keywords',()=>{
  assert.equal(classifyLob(rows[6].relativePath).id,'bundle');
  assert.equal(classifyLob(rows[3].relativePath).label,'Auto');
  assert.equal(classifyLob(rows[4].relativePath).label,'Condo');
  assert.equal(classifyLob(rows[5].relativePath).label,'Renters');
  assert.equal(classifyLob('src/test/java/com/farmers/ffq/home/OtherHomeTest.java').label,'Home');
});
test('Catalog groups one Java class as one suite and counts methods correctly',()=>{
  const catalog=buildLobCatalog(rows);
  assert.equal(catalog[0].id,'home');
  const home=catalog.find(x=>x.id==='home');
  assert.equal(home.count,3);
  assert.equal(home.suites.length,2);
  assert.equal(home.suites.find(x=>x.label==='AceHomeNameAndDobPageTest').count,2);
});
test('Filtering by LOB and exact suite excludes other HOME classes',()=>{
  const suite=rows[0].suite;
  assert.equal(filterMethods(rows,{lob:'home',suite}).length,2);
  assert.equal(filterMethods(rows,{lob:'home',suite,q:'testDOB'}).length,1);
  assert.equal(filterMethods(rows,{lob:'auto',suite}).length,0);
});
test('Only LOBs present in Java methods are returned',()=>{
  assert.equal(buildLobCatalog(rows).some(x=>x.id==='life'),false);
});
test('Unknown packages are Other rather than assumed HOME',()=>{
  assert.equal(classifyLob('src/test/java/com/other/SomeHomeHelpersTest.java').id,'other');
});
