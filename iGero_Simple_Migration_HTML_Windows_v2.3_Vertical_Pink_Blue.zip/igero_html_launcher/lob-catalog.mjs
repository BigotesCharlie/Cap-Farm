// Pure helpers for grouping actual Java @Test methods. LOB comes from
// the source-package directory, not a keyword in a method or class name.
const DEFINITIONS = [
  {id:'home', label:'Home', dirs:['acehome','home']},
  {id:'auto', label:'Auto', dirs:['aceauto','auto']},
  {id:'condo', label:'Condo', dirs:['acecondo']},
  {id:'renters', label:'Renters', dirs:['acerenters','acerenter','renters']},
  {id:'mobile-home', label:'Mobile Home', dirs:['acemobilehome','mobilehome']},
  {id:'life', label:'Life', dirs:['acelife']},
  {id:'bundle', label:'Bundle', dirs:['acebundle']},
  {id:'business', label:'Business', dirs:['acebusiness']},
  {id:'specialty-dwelling', label:'Specialty Dwelling', dirs:['specialtydwelling']},
];
export function classifyLob(relativePath){
  const segments=String(relativePath).replaceAll('\\','/').toLowerCase().split('/');
  const match=DEFINITIONS.find(entry=>entry.dirs.some(dir=>segments.includes(dir)));
  return match?{id:match.id,label:match.label}:{id:'other',label:'Other'};
}
export function buildLobCatalog(methods){
  const byLob=new Map();
  for(const m of methods){
    const lobId=m.lob||classifyLob(m.relativePath).id;
    const label=m.lobLabel||classifyLob(m.relativePath).label;
    const suiteId=m.suite||m.relativePath;
    if(!byLob.has(lobId))byLob.set(lobId,{id:lobId,label,count:0,suites:[],_suites:new Map()});
    const lob=byLob.get(lobId);lob.count++;
    if(!lob._suites.has(suiteId)){
      const suite={id:suiteId,label:m.className,relativePath:m.relativePath,count:0};
      lob._suites.set(suiteId,suite);lob.suites.push(suite);
    }
    lob._suites.get(suiteId).count++;
  }
  const order=DEFINITIONS.map(x=>x.id);
  return [...byLob.values()].map(({_suites,...lob})=>({
    ...lob,suites:lob.suites.sort((a,b)=>a.label.localeCompare(b.label))
  })).sort((a,b)=>{
    const ai=order.indexOf(a.id),bi=order.indexOf(b.id);
    return (ai<0?999:ai)-(bi<0?999:bi)||a.label.localeCompare(b.label);
  });
}
export function filterMethods(methods,{lob='',suite='',q=''}={}){
  const term=String(q).toLowerCase().trim();
  return methods.filter(m=>(!lob||m.lob===lob)&&(!suite||m.suite===suite)&&
    (!term||m.id.toLowerCase().includes(term))).sort((a,b)=>a.id.localeCompare(b.id));
}
