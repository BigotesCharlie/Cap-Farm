@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
 echo Node.js no esta disponible. Instala Node.js y vuelve a intentarlo.
 pause
 exit /b 1
)
start "iGero Simple Migration" /min cmd /k "node server.mjs"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8766/"
echo iGero iniciado. Si quieres cerrarlo, cierra la ventana del servidor.
exit /b 0
