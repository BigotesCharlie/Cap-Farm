param(
  [Parameter(Mandatory=$true)][string]$PromptFile,
  [Parameter(Mandatory=$true)][string]$TargetRoot,
  [Parameter(Mandatory=$true)][string]$SourceRoot,
  [int]$Credits=5
)
$ErrorActionPreference='Stop'
if (!(Test-Path -LiteralPath $PromptFile -PathType Leaf)) { throw "Prompt file not found" }
if (!(Test-Path -LiteralPath $TargetRoot -PathType Container)) { throw "Target project not found" }
if (!(Test-Path -LiteralPath $SourceRoot -PathType Container)) { throw "Java source project not found" }
if (!(Get-Command copilot -ErrorAction SilentlyContinue)) {
 Write-Error "GitHub Copilot CLI not installed or not available on PATH. Check 'copilot --version'."
 exit 21
}
$prompt=Get-Content -LiteralPath $PromptFile -Raw -Encoding UTF8
Push-Location -LiteralPath $TargetRoot
try {
  # --add-dir limits additional project access to the selected Java checkout.
  # --allow-all-tools is optional tool permission, not access to arbitrary paths/URLs.
  # Corporate policy may restrict this flag. Java read-only is an agent instruction,
  # with a post-execution change detector (not an OS-enforced filesystem boundary).
  & copilot -p $prompt --add-dir=$SourceRoot --allow-all-tools --no-ask-user --max-autopilot-continues=7 --max-ai-credits=$Credits
  $rc=$LASTEXITCODE
  if ($null -eq $rc) { $rc=1 }
  exit $rc
} finally { Pop-Location }
