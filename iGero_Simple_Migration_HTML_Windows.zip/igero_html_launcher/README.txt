iGERO SIMPLE MIGRATION — PANEL HTML LOCAL (PILOTO)
=================================================

Inspirado en el HTML 'Conversor Java Selenium a Playwright' proporcionado por el usuario.
No reemplaza tu proyecto ni modifica el Java deliberadamente.

1. Copia esta carpeta a Windows (puede estar junto al proyecto Playwright).
2. Comprueba node --version y copilot --version desde la terminal de Windows.
3. Haz doble clic en Start-iGero-HTML.cmd.
4. Abre http://127.0.0.1:8766/ si no abre automaticamente.
5. Verifica rutas de origen y destino, ajustalas si fuera necesario y guarda.
6. Selecciona un metodo Java TestNG HOME.
7. Pulsa 'Ejecutar ambos pasos' o individualmente '1. JSON + Prompt' y '2. Migrar a TS'.
8. Observa la checklist LIVE y la salida de Copilot.

RUTAS PRECARGADAS
Origen Java: D:\Users\CARLOS.GARCIA19\Master\ffq-test-master
Destino:     D:\Users\CARLOS.GARCIA19\PW-TS-MM\FFQ-Playwright-TS-master

ARCHIVOS PRODUCIDOS (DENTRO DEL DESTINO)
migration/pervez-json/<Clase>__<Metodo>/contract.json
migration/pervez-json/<Clase>__<Metodo>/prompt.md
migration/pervez-json/<Clase>__<Metodo>/01-extract-instructions.txt
migration/pervez-json/<Clase>__<Metodo>/02-migrate-instructions.txt
La spec TypeScript se genera en tests/acehome segun instrucciones y convención real.

REGLAS IMPORTANTES
- GitHub Copilot CLI es un prerequisito. El HTML no puede ejecutar comandos locales por si solo.
- Java y Excel deben permanecer sin cambios. Se solicita read-only y se detectan cambios tras cada ejecucion;
  esta comprobacion NO es un bloqueo de permisos de Windows. Usa respaldo Git o filesystem read-only si lo necesitas.
- No se ejecuta Chrome ni operaciones de pago, correo, bank o bind automaticamente.
- El panel muestra compilacion offline si la opcion esta habilitada. NO certifica Functional PASS.
- El credit cap de Copilot es suave y no sustituye limites de organizacion/plan.
- Se inicia en 127.0.0.1 (no publicarlo en red).
- La interfaz y el backend no se han ejecutado en tu computadora corporativa;
  este paquete solo fue probado localmente con pruebas de endpoints sin Copilot real.
- Conservar un backup del workspace; Copilot con permisos puede modificar archivos en la carpeta destino.

Dependencias: Node.js y GitHub Copilot CLI (no usa npm install ni frameworks extra).
