package com.farmers.aiassist.web;

import com.farmers.aiassist.rally.oauth.RallyOAuthWsapiService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rally")
public class RallyReadOnlyController {
    private final RallyOAuthWsapiService wsapiService;

    public RallyReadOnlyController(RallyOAuthWsapiService wsapiService) {
        this.wsapiService = wsapiService;
    }

    @GetMapping(value = "/user-story/{formattedId}", produces = "application/json")
    public ResponseEntity<String> userStory(@PathVariable String formattedId, HttpSession session) {
        return ResponseEntity.ok(wsapiService.getUserStory(session, formattedId));
    }
}
