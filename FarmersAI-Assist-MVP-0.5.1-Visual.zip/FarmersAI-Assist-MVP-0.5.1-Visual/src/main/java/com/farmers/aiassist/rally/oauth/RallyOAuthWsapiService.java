package com.farmers.aiassist.rally.oauth;

import com.farmers.aiassist.config.RallyProperties;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;

@Service
public class RallyOAuthWsapiService {
    private final RallyProperties properties;
    private final RallyOAuthSession oauthSession;
    private final HttpClient httpClient;

    public RallyOAuthWsapiService(RallyProperties properties, RallyOAuthSession oauthSession) {
        this.properties = properties;
        this.oauthSession = oauthSession;
        this.httpClient = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .build();
    }

    public String getUserStory(HttpSession session, String formattedId) {
        String token = oauthSession.getAccessToken(session);
        if (token == null || token.isBlank()) {
            throw new IllegalStateException("Rally is not connected.");
        }

        try {
            String query = "(FormattedID = \"" + formattedId.replace("\"", "\\\"") + "\")";
            String fetch = "ObjectID,FormattedID,Name,Description,AcceptanceCriteria,Owner,Project,"
                    + "ScheduleState,FlowState,PlanEstimate,Parent,Feature,Release,Iteration,"
                    + "CreationDate,LastUpdateDate,Blocked,Tags";

            String url = properties.getBaseUrl()
                    + "/slm/webservice/v2.0/hierarchicalrequirement"
                    + "?query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&fetch=" + URLEncoder.encode(fetch, StandardCharsets.UTF_8)
                    + "&pagesize=20";

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Accept", "application/json")
                    .header("ZSESSIONID", token)
                    .GET()
                    .build();

            HttpResponse<String> response =
                    httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IllegalStateException("Rally WSAPI returned HTTP " + response.statusCode());
            }
            return response.body();

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Rally request interrupted.", e);
        } catch (Exception e) {
            if (e instanceof IllegalStateException ise) throw ise;
            throw new IllegalStateException("Rally WSAPI request failed: " + e.getMessage(), e);
        }
    }
}
