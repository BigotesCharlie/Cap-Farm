# iGero JSON-first HOME migration policy (proposal)

## Objective
Use the established Live Grid/orchestrator to migrate one simple, enabled PURE HOME Selenium Java @Test method at a time: read-only source contract -> versioned JSON -> Copilot authoring -> targeted Playwright TS -> authorized visible Chrome validation -> evidence-backed status. The JSON is a static source contract, not proof of Java runtime behavior.

## Additive guards (do not overwrite current IGR-* rules)
- JSONM-001 SOURCE_READ_ONLY: Java/JavaParser/Excel read-only.
- JSONM-002 PURE_HOME_QUICK_WINS_FIRST: simple, source-enabled HOME only; do not auto-enable @Skip or excluded TX.
- JSONM-003 COMPLETE_STATIC_CONTRACT: track all test assertions and relevant helpers with line references; unknowns block full implementation.
- JSONM-004 CONTRACT_SCHEMA_PROVENANCE: validate schema, method identity, fingerprint, source version and evidence labels before generating code.
- JSONM-005 EXCEL_ONLY_DATA: existing authorized workbook and providers are the sole source of Playwright input; no Faker, hardcoding or forced rows.
- JSONM-006 REUSE_TARGET_ARCHITECTURE: reuse existing fixtures, Page Objects, navigation and reporter.
- JSONM-007 AUTHORING_AVAILABILITY: headless coding only via approved and tested authoring integration; otherwise manual handoff.
- JSONM-008 SAFE_QA_EXECUTION: QA preflight and source-defined bounded stop before any email, bank, payment or bind operation.
- JSONM-009 TRUE_FUNCTIONAL_PASS: only actual browser execution + all applicable assertions + focused regressions yields functional PASS; Java parity separate.
- JSONM-010 ACCURATE_DASHBOARD: historical/offline/synthetic/current results and certified counts remain distinct.
- JSONM-011 IDEMPOTENT_QUEUE: one job per source fingerprint, one worker, persisted state across restarts, bounded retries.
- JSONM-012 USER_STOP_AND_BUDGET: respect Stop/Pause, daily model budget and approvals, no infinite automatic cycles.
- JSONM-013 EVIDENCE_PRIVACY: store only safe metadata and redacted artifacts; never invent discarded artifacts.
- JSONM-014 NONREGRESSION: protect existing J03 and prior Quick Win results; no broad formatting or workspace resets.

## Authoritative statuses
DISCOVERED, CONTRACT_EXTRACTING, CONTRACT_READY, AWAITING_AUTHORING_WORKER, TS_IMPLEMENTING, TS_IMPLEMENTED, TYPECHECK_PASS, QA_PREFLIGHT_BLOCKED, QA_EXECUTING, PLAYWRIGHT_FUNCTIONAL_PASS, BLOCKED_DATA, BLOCKED_SOURCE, BLOCKED_SAFETY, BLOCKED_RUNTIME, FAILED_FUNCTIONAL, DEFERRED, PAUSED, STOPPED.

`FULL_PARITY_CERTIFIED` requires comparable independently observed Java runtime evidence and is **not** inferred from a source JSON.

## 24/7 distinction
A long-lived local Node service can maintain the queue and dashboard while Windows stays on and configured startup/recovery is approved. Unattended TypeScript authoring requires an approved programmatic Copilot CLI (or equivalent), noninteractive credentials and limited permissions. Without it use AWAITING_AUTHORING_WORKER and never claim full unattended migration. Do not install as a service or enable automatic QA execution without the applicable enterprise/user approvals.
