# iGero JSON handoff starter package (not integrated code)

These files are a **proposed additive scaffold** and have NOT been merged into or executed against your local FFQ-Playwright-TS-master checkout. Do not blindly overwrite existing .github files, iGero rules, tests or workflows.

1. Open FFQ-Playwright-TS-master in VS Code. Inspect existing .github/custom instructions and tools/igero policy registry for collisions; merge without losing current 18 rules.
2. Copy or selectively merge `.github/instructions/igero-json-migration.instructions.md`, the four `.github/skills/*/SKILL.md`, the JSON schema and policy documentation.
3. Have Copilot **first** implement an adapter around the existing iGero queue/API: exact Java source method -> source-verified contract JSON -> validated authoring work item -> real generated spec -> approved Chrome test -> Live Grid status.
4. Install/enable a supported headless authoring interface only if IT and account policy permit. Official Copilot CLI supports programmatic `-p`, but installation, authentication, cost and path/tool restrictions must be verified; never use blanket allow-all.
5. Test schema rejection, unknown mandatory helper, missing Excel source, disabled Java method, unauthorized side effect, duplicate job, crash recovery, Stop persistence, false PASS rejection, privacy and a single genuine simple HOME QA case.
6. Set up Windows startup/recovery only after the local worker passes its tests and the machine's IT policy permits it. Keep service bound to loopback; user Stop must persist.
7. In the dashboard, show current counts (from the user's latest screenshot) as a historical **baseline**, not a newly executed claim: 134 HOME, 107 enabled, 27 deferred, 9 selected Quick Wins, 7 implemented, 7 Chrome attempts, 2 functional PASS reported, 7 blocked, 0 parity verified, 0 certified. Re-evaluate actual workspace state before deployment.
