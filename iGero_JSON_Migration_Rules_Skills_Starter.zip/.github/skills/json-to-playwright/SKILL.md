---
name: json-to-playwright
description: Implement a validated Java-source JSON contract as one complete Playwright TypeScript HOME test, reusing existing fixtures, Page Objects and Excel providers.
---
# Migration JSON to TypeScript
1. Validate schema, source identity, enabled/TX eligibility, hashes and assertion coverage before writing code.
2. Find existing specs, fixtures, Pages, mappers and navigation; extend them narrowly. No duplicated framework, J03 regressions or unrelated E2E refactors.
3. Preserve source-defined actions, conditionals, locators' intent, waits and every applicable assertion. Unknown mandatory behavior is a BLOCKED contract, not license to invent.
4. Use existing workbook/worksheet/provider mappings and random eligible selection. No Faker, hardcoded applicant data or external identity override.
5. Add a minimal dedicated `.spec.ts` or update an existing equivalent. Record source method ID and contract hash in safe metadata.
6. Run TypeScript and focused checks. Never count code generation or offline checks as Chrome PASS.
7. Submit real execution to the approved iGero QA lane only when safety and environment preflight pass.
