---
name: java-contract-export
description: Extract one exact enabled Selenium Java TestNG HOME method and its relevant dependencies to a validated, source-traceable migration JSON contract. Use before any Playwright implementation.
---
# Java method to JSON source contract
1. Find the exact Java class and @Test method, confirm enabled status and its actual state eligibility. Read, never edit, Java and Excel sources.
2. Trace the method's DataProvider, invoked navigation helpers, Page Objects, locators, conditionals, waits and each original assertion. Include file+method+line and mark unresolved dynamic references.
3. Keep the transitive call expansion bounded to the selected method; exclude unrelated tests and E2E flow beyond source-defined acceptance.
4. Record workbook/sheet/field mapping names and any approved derivations, but never raw applicant PII. Preserve Java vs authorized Excel identity-source differences.
5. Emit a versioned `.migration.json` only under the Playwright workspace's approved contract inbox, validate against `tools/igero/contracts/migration.schema.json`, and compute source fingerprint/hashes.
6. Mark extraction as SOURCE_VERIFIED. Never label code reading as Java runtime execution.
7. Stop on unresolved mandatory assertions; report them exactly. Do not fill gaps with guesses.
