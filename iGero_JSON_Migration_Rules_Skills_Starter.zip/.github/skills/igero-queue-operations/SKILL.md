---
name: igero-queue-operations
description: Operate the persistent local iGero migration queue safely: Start/Pause/Resume/Stop, recover after restart, avoid duplicate jobs and report truthful progress and agent cost.
---
# Local iGero queue operations
1. Reuse the existing iGero service, event log and Live Grid on 127.0.0.1:8765. Do not build a second dashboard.
2. Confirm jobs are idempotent by canonical Java method and source fingerprint; keep one active worker. Repair stale ACTIVE_CASE vs IDLE inconsistencies without erasing history.
3. Accept only schema-validated JSON contracts; process SOURCE_EXTRACTED -> JSON_VALIDATED -> TS_IMPLEMENTED -> TYPECHECK_PASS -> QA_PREFLIGHT_PASS -> CHROME_RUN -> FUNCTIONAL_PASS/BLOCKED.
4. Preserve human Stop/Pause across service restart; do not automatically resume a user-stopped run. Stop must cancel owned child jobs without killing unrelated processes.
5. Authoring worker requires an explicitly installed and approved headless tool. If absent, pause at AWAITING_AUTHORING_WORKER and allow human Copilot export/import; never claim unattended coding.
6. Record request counts, model usage where available, bounded retries and a configurable daily cap. Block model calls on budget exhaustion.
7. Run application QA only with separately authorized execution gates; 24/7 local process health is not permission to run external operations.
8. Show separately functional PASS, Java parity, source contracts exported, actual Chrome runs and historical results.
