---
name: home-runtime-validate
description: Execute and certify a simple migrated HOME Playwright test in visible MA11 QA Chrome, with source assertion coverage, PII-safe evidence and no financial operations.
---
# Runtime validation skill
1. Verify current QA authorization and existing iGero gates, exact test selector, MA11 `/quote/`, source state eligibility, Excel data contract, one worker, zero retries.
2. Prove the test stops at its original simple UI acceptance point and cannot reach email, bank, purchase or policy-binding operations.
3. Execute the actual target test in visible Chrome only after preflight. Capture execution ID, selected Excel row reference, first failure, application page and assertions.
4. Sanitize evidence with existing infrastructure; never leave raw applicant PII in normal report directories.
5. Classify FUNCTIONAL_PASS only if all applicable original assertions execute and pass. Track Java parity separately; never claim FULL_PARITY_CERTIFIED from JSON alone.
6. On failure identify and repair only a confirmed automation defect, then run focused regressions; no unlimited retries, arbitrary sleeps, forced rows or assertion weakening.
