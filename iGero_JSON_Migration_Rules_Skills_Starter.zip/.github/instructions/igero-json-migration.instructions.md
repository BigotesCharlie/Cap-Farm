---
applyTo: "tools/igero/**,tests/acehome/**,src/**/acehome/**,**/*.migration.json"
---
# iGero HOME JSON Migration - required workspace rules
- Prioritize simple, enabled PURE HOME methods with short, source-verifiable UI assertions. Defer E2E, AUTO, BUNDLE, CONDO and other products.
- Preserve the existing 18 iGero rules. This is an additive workflow, not a replacement for security or policy gates.
- Java Selenium repository and JavaParser reference are READ-ONLY. Never modify original Java sources, Java DataProviders or Excel workbooks.
- Export one Java method's complete source contract to a versioned JSON file **in the Playwright workspace**, validate schema and provenance, and preserve unknown or unresolved behavior explicitly. Never invent a step or assertion.
- Every selected HOME input comes from the existing Excel-backed provider. Preserve ordinary eligible-row selection; do not hardcode or force applicant rows.
- Reuse existing HOME fixtures, navigation helpers, Page Objects, validators and evidence tooling. No framework reimplementation.
- JSON source extraction is SOURCE_VERIFIED, not JAVA_RUNTIME_OBSERVED; a Playwright offline PASS is not Chrome functional PASS.
- Confirm exact Java @Test enabled status and source-defined state eligibility before selecting a TC.
- Never perform email sends, bank account changes, payment confirmation or policy binding without separate explicit authorization and a verified safe execution boundary.
- Preserve execution IDs, source hashes, selected Excel row reference (not PII), assertion provenance and the last successful stage.
- Do not run unrelated synthetic fixtures to claim real Farmers QA progress.
- Respect user Stop/Pause, independent task BLOCKED states, bounded retries, credit budgets and strictly scoped code edits.
