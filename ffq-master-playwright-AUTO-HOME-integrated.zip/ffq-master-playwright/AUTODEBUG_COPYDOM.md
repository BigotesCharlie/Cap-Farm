# Suite-wide CopyDOM + AutoDebug

This project applies the resiliency layer centrally through the Playwright runtime; individual AUTO/HOME tests do not need to duplicate recovery code.

## What is automatic

- CopyDOM snapshot at test start/end, main-frame navigation, relevant UI transitions and any intercepted locator failure.
- Unique execution folder per TestNG test invocation/thread.
- State detection for AUTO, HOME, Inconvenience, Knockout, Try Again and Unknown.
- On a failed locator interaction while a blocker is detected: Try Again -> browser Back -> Reload -> restart FastQuote entry, up to 2 recovery cycles by default.
- The failed locator operation is retried once only when recovery actually leaves the blocker state.
- Existing Playwright screenshot and trace behavior remains intact.
- Parallel DataProviders remain thread-isolated.

## Artifacts

`build/artifacts/dom/<Class.test>/<execution-id>/`

Each checkpoint produces:

- `NNN-<checkpoint>.html` - CopyDOM
- `NNN-<checkpoint>.txt` - URL/title/detected state
- `debug-summary.txt` - result, number of snapshots, recovery attempts, last state and URL

Existing failure screenshots continue under `build/artifacts/screenshots/` and traces under `build/artifacts/traces/` when enabled.

## Controls

Configure through JVM property, `ffq.*` property, environment variable, or untracked `ffq-local.properties`:

```properties
autoDebug=true
autoDebug.maxRecovery=2
autoDebug.backOnBlocker=true
autoDebug.reloadOnBlocker=true
autoDebug.restartOnBlocker=true
```

Set `autoDebug=false` only when intentionally debugging without the resiliency layer.

## Design safety

Recovery is not triggered merely because a test reaches an Inconvenience/Knockout page. It is invoked only after an interaction failure. This prevents tests that intentionally validate negative/blocker pages from being redirected before their assertions run.
