#!/usr/bin/env python3
from pathlib import Path
import json, re, sys

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {
    'test': 'https://ffqautouiqa.farmers.com/fastquote/',
    'regression': 'https://ffqautouiuat.farmers.com/fastquote/',
}

def fail(message):
    print('FAIL:', message)
    sys.exit(1)

config = json.loads((ROOT / 'properties.json').read_text(encoding='utf-8'))
for env, expected in EXPECTED.items():
    section = config.get('environment', {}).get(env, {})
    if section.get('uri') != expected:
        fail(f'{env}.uri expected {expected}, found {section.get("uri")}')
    if section.get('farmers_com_url') != expected:
        fail(f'{env}.farmers_com_url must route to FastQuote, found {section.get("farmers_com_url")}')

landing = (ROOT / 'src/main/java/com/farmers/ffq/common/pages/LandingPage.java').read_text(encoding='utf-8')
if 'getEnvironmentProperty("farmers_com_url")' in landing:
    fail('LandingPage still reads farmers_com_url')
if 'addAuthCookieIfConfigured();' not in landing:
    fail('optional cookie setup is missing')
if 'assertNotRedirectedToCssTv();' not in landing:
    fail('CSSTV redirect guard is missing')

prop = (ROOT / 'src/main/java/com/farmers/framework/Property.java').read_text(encoding='utf-8')
for required in EXPECTED.values():
    if required not in prop:
        fail(f'Property.java is missing protected route {required}')
if 'ffq-local.properties' not in prop:
    fail('ffq-local.properties loading is missing')

example = ROOT / 'ffq-local.properties.example'
if not example.exists():
    fail('ffq-local.properties.example is missing')

runtime_hardcoded = []
for path in (ROOT / 'src').rglob('*.java'):
    text = path.read_text(encoding='utf-8', errors='ignore')
    if path.name != 'Property.java':
        # Ignore documentation comments only; executable environment URLs must be resolved through Property.
        code = re.sub(r'/\*.*?\*/|//.*', '', text, flags=re.S)
        if 'https://ffqautouiuat.farmers.com' in code or 'https://ffqautouiqa.farmers.com' in code:
            runtime_hardcoded.append(str(path.relative_to(ROOT)))
if runtime_hardcoded:
    fail('hardcoded QA/UAT runtime URLs found: ' + ', '.join(runtime_hardcoded))

# Verify every concrete class containing @Test is covered by the Playwright lifecycle.
java_files = list((ROOT / 'src').rglob('*.java'))
classes = {}
for path in java_files:
    text = path.read_text(encoding='utf-8', errors='ignore')
    package_match = re.search(r'\bpackage\s+([\w.]+)\s*;', text)
    class_match = re.search(r'\bpublic\s+(?:abstract\s+)?class\s+(\w+)(?:\s+extends\s+([\w.]+))?', text)
    if not package_match or not class_match:
        continue
    package = package_match.group(1)
    name = class_match.group(1)
    parent = class_match.group(2)
    imports = {m.group(1).split('.')[-1]: m.group(1) for m in re.finditer(r'\bimport\s+([\w.]+)\s*;', text)}
    if parent and '.' not in parent:
        parent = imports.get(parent, package + '.' + parent)
    fqn = package + '.' + name
    classes[fqn] = {'parent': parent, 'has_test': bool(re.search(r'@Test\b', text)), 'path': path}

def lifecycle_covered(fqn):
    visited = set()
    while fqn and fqn not in visited:
        visited.add(fqn)
        if fqn == 'com.farmers.framework.AutomationFramework':
            return True
        info = classes.get(fqn)
        if not info:
            return fqn.endswith('.AutomationFramework')
        fqn = info['parent']
    return False

missing = [str(info['path'].relative_to(ROOT)) for fqn, info in classes.items() if info['has_test'] and not lifecycle_covered(fqn)]
if missing:
    fail('test classes without Playwright lifecycle: ' + ', '.join(missing))

print('PASS: QA/UAT FastQuote routing, optional cookie handling, local configuration, and lifecycle coverage verified.')
