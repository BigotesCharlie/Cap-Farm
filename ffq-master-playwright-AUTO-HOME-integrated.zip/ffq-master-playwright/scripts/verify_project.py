#!/usr/bin/env python3
"""Offline structural validation for the extracted FFQ Home/Auto project.

This script intentionally uses only the Python standard library so it can run
before Gradle dependencies or Playwright browser binaries are available.
"""
from __future__ import annotations

from pathlib import Path
import csv
import hashlib
import json
import os
import re
import stat
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_TESTS = 2373
EXPECTED_DESCRIPTIONS = 2373
EXPECTED_TARGET_TEST_FILES = 134
EXPECTED_MAIN_FILES = 275
EXPECTED_TEST_FILES_WITH_SUPPORT = 136
EXPECTED_PROJECT_NAME = 'ffq-master-playwright'

REQUIRED_FILES = [
    'build.gradle',
    'settings.gradle',
    'gradle.properties',
    'gradlew',
    'gradlew.bat',
    'gradle/wrapper/gradle-wrapper.jar',
    'gradle/wrapper/gradle-wrapper.properties',
    'properties.json',
    'productionProperties.json',
    'src/test/resources/META-INF/services/org.testng.ITestNGListener',
]

ESSENTIAL_RESOURCES = [
    'src/test/resources/HomeTestData.xlsx',
    'src/test/resources/AceHomeTestData.xlsx',
    'src/test/resources/AutoTestData.xlsx',
    'src/test/resources/OneUIAutoTestData.xlsx',
    'src/test/resources/AutoDefaultCoveragesData.xlsx',
    'src/test/resources/FFQHomeWebServices.xml',
    'src/test/resources/adb_aes_test.key',
    'src/test/resources/tg_aes_test.key',
]

ALLOWED_TEST_PREFIXES = (
    'src/test/java/com/farmers/ffq/home/',
    'src/test/java/com/farmers/ffq/auto/',
)
ALLOWED_TEST_FILES = {
    'src/test/java/com/farmers/ffq/BaseTest.java',
    'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
    'src/test/java/com/farmers/ffq/acebundle/AceBundleTestHelper.java',
}

FORBIDDEN = [
    'org.openqa.selenium',
    'selenium-java',
    'WebDriverManager',
    'WebDriverWait',
    'ExpectedConditions',
    'Thread.sleep(',
    'WebElement',
    '@FindBy',
    '@FindAll',
]

IMPORT_DEPENDENCY_PREFIXES = {
    'com.microsoft.playwright': 'com.microsoft.playwright:playwright',
    'org.testng': 'org.testng:testng',
    'com.fasterxml.jackson.databind': 'com.fasterxml.jackson.core:jackson-databind',
    'com.fasterxml.jackson.core': 'com.fasterxml.jackson.core:jackson-databind',
    'com.fasterxml.jackson.annotation': 'com.fasterxml.jackson.core:jackson-databind',
    'com.fasterxml.jackson.dataformat.xml': 'com.fasterxml.jackson.dataformat:jackson-dataformat-xml',
    'org.json': 'org.json:json',
    'org.apache.commons.lang3': 'org.apache.commons:commons-lang3',
    'org.apache.commons.lang': 'commons-lang:commons-lang',
    'org.apache.commons.math3': 'org.apache.commons:commons-math3',
    'org.apache.http': 'org.apache.httpcomponents:httpclient',
    'org.apache.poi': 'org.apache.poi:poi / poi-ooxml',
    'net.datafaker': 'net.datafaker:datafaker',
    'org.awaitility': 'org.awaitility:awaitility',
    'okhttp3': 'com.squareup.okhttp3:okhttp',
    'org.joda.time': 'joda-time:joda-time',
    'javax.annotation': 'javax.annotation:javax.annotation-api',
    'nl.flotsam.xeger': 'com.github.krraghavan:xeger',
    'com.manybrain.mailinator': 'com.manybrain:mailinator-client',
    'org.jetbrains.annotations': 'org.jetbrains:annotations',
    'lombok': 'org.projectlombok:lombok',
}


def fail(message: str) -> None:
    print(f'FAIL: {message}')
    raise SystemExit(1)


def rel(path: Path) -> str:
    return str(path.relative_to(ROOT)).replace('\\', '/')


def strip_comments_and_strings(text: str) -> str:
    """Replace comments/string content while preserving delimiters/newlines."""
    out: list[str] = []
    i = 0
    state = 'code'
    quote = ''
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ''
        if state == 'code':
            if ch == '/' and nxt == '/':
                out.extend('  ')
                i += 2
                state = 'line_comment'
                continue
            if ch == '/' and nxt == '*':
                out.extend('  ')
                i += 2
                state = 'block_comment'
                continue
            if ch in ('\'', '"'):
                quote = ch
                out.append(' ')
                i += 1
                state = 'string'
                continue
            out.append(ch)
            i += 1
            continue
        if state == 'line_comment':
            if ch == '\n':
                out.append('\n')
                state = 'code'
            else:
                out.append(' ')
            i += 1
            continue
        if state == 'block_comment':
            if ch == '*' and nxt == '/':
                out.extend('  ')
                i += 2
                state = 'code'
            else:
                out.append('\n' if ch == '\n' else ' ')
                i += 1
            continue
        if state == 'string':
            if ch == '\\':
                out.append(' ')
                if i + 1 < len(text):
                    out.append('\n' if text[i + 1] == '\n' else ' ')
                i += 2
                continue
            if ch == quote:
                out.append(' ')
                i += 1
                state = 'code'
            else:
                out.append('\n' if ch == '\n' else ' ')
                i += 1
            continue
    if state == 'string':
        fail('build.gradle contains an unterminated quoted string')
    if state == 'block_comment':
        fail('build.gradle contains an unterminated block comment')
    return ''.join(out)


def validate_balanced_delimiters(path: Path) -> None:
    clean = strip_comments_and_strings(path.read_text(encoding='utf-8'))
    stack: list[tuple[str, int]] = []
    pairs = {')': '(', ']': '[', '}': '{'}
    for index, ch in enumerate(clean):
        if ch in '([{':
            stack.append((ch, index))
        elif ch in ')]}':
            if not stack or stack[-1][0] != pairs[ch]:
                fail(f'{rel(path)} has an unmatched {ch}')
            stack.pop()
    if stack:
        fail(f'{rel(path)} has an unmatched {stack[-1][0]}')


def declared_types(java_files: list[Path]) -> set[str]:
    result: set[str] = set()
    for path in java_files:
        text = path.read_text(encoding='utf-8', errors='ignore')
        package_match = re.search(r'^\s*package\s+([\w.]+)\s*;', text, re.MULTILINE)
        package_name = package_match.group(1) if package_match else ''
        for match in re.finditer(r'\b(?:class|interface|enum|record|@interface)\s+(\w+)', text):
            result.add(f'{package_name}.{match.group(1)}'.strip('.'))
    return result


def internal_import_exists(import_name: str, types: set[str]) -> bool:
    if import_name in types:
        return True
    candidate = import_name
    while '.' in candidate:
        candidate = candidate.rsplit('.', 1)[0]
        if candidate in types:  # Nested class import.
            return True
    return False


for required in REQUIRED_FILES + ESSENTIAL_RESOURCES:
    if not (ROOT / required).is_file():
        fail(f'missing required file: {required}')

settings_text = (ROOT / 'settings.gradle').read_text(encoding='utf-8')
if f"rootProject.name = '{EXPECTED_PROJECT_NAME}'" not in settings_text:
    fail(f'unexpected Gradle project name; expected {EXPECTED_PROJECT_NAME}')

# JSON and XML integrity.
for json_name in ('properties.json', 'productionProperties.json'):
    with (ROOT / json_name).open(encoding='utf-8') as handle:
        json.load(handle)
ET.parse(ROOT / 'src/test/resources/FFQHomeWebServices.xml')

# XLSX files are ZIP containers; test every member CRC.
for resource in ESSENTIAL_RESOURCES:
    path = ROOT / resource
    if path.suffix.lower() == '.xlsx':
        with zipfile.ZipFile(path) as workbook:
            bad_member = workbook.testzip()
            if bad_member:
                fail(f'corrupt XLSX member {bad_member} in {resource}')

java_files = sorted((ROOT / 'src').rglob('*.java'))
main_files = sorted((ROOT / 'src/main/java').rglob('*.java'))
test_files = sorted((ROOT / 'src/test/java').rglob('*.java'))
if len(main_files) != EXPECTED_MAIN_FILES:
    fail(f'expected {EXPECTED_MAIN_FILES} main Java files, found {len(main_files)}')
if len(test_files) != EXPECTED_TEST_FILES_WITH_SUPPORT:
    fail(f'expected {EXPECTED_TEST_FILES_WITH_SUPPORT} test Java files, found {len(test_files)}')

# Strict test-source scope and prohibited-runtime scan.
for path in test_files:
    relative = rel(path)
    if relative not in ALLOWED_TEST_FILES and not relative.startswith(ALLOWED_TEST_PREFIXES):
        fail(f'out-of-scope test source: {relative}')
for path in java_files:
    text = path.read_text(encoding='utf-8', errors='ignore')
    for token in FORBIDDEN:
        if token in text:
            fail(f'prohibited token {token!r} found in {rel(path)}')

# Test and description counts.
target_test_files = [
    path for path in test_files
    if rel(path).startswith(ALLOWED_TEST_PREFIXES)
    or rel(path).endswith('AceAutoHomeBundleTests.java')
]
if len(target_test_files) != EXPECTED_TARGET_TEST_FILES:
    fail(f'expected {EXPECTED_TARGET_TEST_FILES} target test files, found {len(target_test_files)}')
target_text = '\n'.join(path.read_text(encoding='utf-8', errors='ignore') for path in target_test_files)
test_count = len(re.findall(r'@Test\b', target_text))
description_count = target_text.count('// Test description:')
if test_count != EXPECTED_TESTS:
    fail(f'expected {EXPECTED_TESTS} @Test annotations, found {test_count}')
if description_count != EXPECTED_DESCRIPTIONS:
    fail(f'expected {EXPECTED_DESCRIPTIONS} test descriptions, found {description_count}')

# Resource hashes against the extraction manifest.
hash_manifest = ROOT / 'extraction-reports/RESOURCE_SHA256.csv'
with hash_manifest.open(newline='', encoding='utf-8') as handle:
    rows = list(csv.DictReader(handle))
if len(rows) != len(ESSENTIAL_RESOURCES):
    fail(f'expected {len(ESSENTIAL_RESOURCES)} resource hash rows, found {len(rows)}')
for row in rows:
    path = ROOT / row['resource']
    if not path.is_file():
        fail(f'missing hashed resource: {row["resource"]}')
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != row['originalSha256']:
        fail(f'resource changed: {row["resource"]}')

# Every explicit internal type import must resolve to retained source.
types = declared_types(java_files)
for path in java_files:
    text = path.read_text(encoding='utf-8', errors='ignore')
    for match in re.finditer(r'^\s*import\s+(?!static\s+)([\w.]+)(\.\*)?\s*;', text, re.MULTILINE):
        import_name, wildcard = match.group(1), match.group(2)
        if not import_name.startswith('com.farmers.'):
            continue
        if wildcard:
            if not any(name.startswith(import_name + '.') for name in types):
                fail(f'unresolved internal wildcard import {import_name}.* in {rel(path)}')
        elif not internal_import_exists(import_name, types):
            fail(f'unresolved internal import {import_name} in {rel(path)}')

# Every third-party import must be represented by a declared dependency family.
uncovered_imports: set[str] = set()
for path in java_files:
    text = path.read_text(encoding='utf-8', errors='ignore')
    for match in re.finditer(r'^\s*import\s+(?:static\s+)?([\w.]+)', text, re.MULTILINE):
        import_name = match.group(1)
        if import_name.startswith(('java.', 'javax.', 'com.farmers.', 'org.w3c.dom.')):
            continue
        if not any(import_name == prefix or import_name.startswith(prefix + '.') for prefix in IMPORT_DEPENDENCY_PREFIXES):
            uncovered_imports.add(import_name)
if uncovered_imports:
    fail('third-party imports without a dependency mapping: ' + ', '.join(sorted(uncovered_imports)))

# TestNG ServiceLoader entries must resolve to retained source classes.
listener_file = ROOT / 'src/test/resources/META-INF/services/org.testng.ITestNGListener'
listener_names = [line.strip() for line in listener_file.read_text(encoding='utf-8').splitlines()
                  if line.strip() and not line.lstrip().startswith('#')]
if len(listener_names) != len(set(listener_names)):
    fail('duplicate TestNG listener entries found')
for listener in listener_names:
    if listener not in types:
        fail(f'TestNG listener source missing: {listener}')

# Build script structure and regression checks.
build_file = ROOT / 'build.gradle'
build_text = build_file.read_text(encoding='utf-8')
validate_balanced_delimiters(build_file)
required_build_snippets = [
    "playwrightVersion = '1.61.0'",
    "implementation \"com.microsoft.playwright:playwright:${playwrightVersion}\"",
    "implementation 'javax.annotation:javax.annotation-api:1.3.2'",
    "useTestNG",
    "testClassesDirs = sourceSets.test.output.classesDirs",
    "classpath = sourceSets.test.runtimeClasspath",
    "tasks.register('homeTest', Test)",
    "tasks.register('autoTest', Test)",
    "tasks.register('autoHomeBundleTest', Test)",
    "tasks.register('verifyPlaywrightOnly')",
    "tasks.register('validateBuild')",
    "check.dependsOn verifyPlaywrightOnly",
    f"archiveBaseName = '{EXPECTED_PROJECT_NAME}'",
]
for snippet in required_build_snippets:
    if snippet not in build_text:
        fail(f'build.gradle is missing required configuration: {snippet}')
if "GradleException('Non-Playwright remnants found:\n" in build_text:
    fail('the previous malformed GradleException block is still present')

wrapper_properties = (ROOT / 'gradle/wrapper/gradle-wrapper.properties').read_text(encoding='utf-8')
if 'distributionUrl=https\\://services.gradle.org/distributions/gradle-8.2.1-bin.zip' not in wrapper_properties:
    fail('unexpected Gradle wrapper distribution')

if os.name != 'nt':
    mode = (ROOT / 'gradlew').stat().st_mode
    if not (mode & stat.S_IXUSR):
        fail('gradlew is not executable')

result = {
    'status': 'PASS',
    'projectName': EXPECTED_PROJECT_NAME,
    'mainJavaFiles': len(main_files),
    'testJavaFilesIncludingSupport': len(test_files),
    'targetTestFiles': len(target_test_files),
    'testMethods': test_count,
    'testDescriptions': description_count,
    'essentialResources': len(ESSENTIAL_RESOURCES),
    'testNgListeners': listener_names,
    'gradleWrapper': '8.2.1',
    'javaToolchain': 17,
}
(ROOT / 'extraction-reports/OFFLINE_VALIDATION_RESULTS.json').write_text(
    json.dumps(result, indent=2) + '\n', encoding='utf-8'
)
print(
    'PASS: offline project validation completed; '
    f'{test_count} tests, {description_count} descriptions, '
    f'{len(main_files) + len(test_files)} Java files, '
    f'{len(ESSENTIAL_RESOURCES)} immutable resources.'
)
