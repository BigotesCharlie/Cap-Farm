#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib, re, sys

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_TESTS = 2373
ALLOWED_TEST_PREFIXES = (
    'src/test/java/com/farmers/ffq/home/',
    'src/test/java/com/farmers/ffq/auto/',
)
ALLOWED_TEST_FILES = {
    'src/test/java/com/farmers/ffq/BaseTest.java',
    'src/test/java/com/farmers/ffq/acebundle/AceAutoHomeBundleTests.java',
    'src/test/java/com/farmers/ffq/acebundle/AceBundleTestHelper.java',
}
FORBIDDEN = [
    'org.openqa.selenium', 'selenium-java', 'WebDriverManager', 'WebDriverWait',
    'ExpectedConditions', 'Thread.sleep(', 'WebElement', '@FindBy', '@FindAll',
]

def fail(message):
    print('FAIL:', message)
    sys.exit(1)

java_files = list((ROOT / 'src').rglob('*.java'))
for path in java_files:
    text = path.read_text(encoding='utf-8', errors='ignore')
    for token in FORBIDDEN:
        if token in text:
            fail(f'{token} found in {path.relative_to(ROOT)}')

test_sources = [p for p in (ROOT / 'src/test/java').rglob('*.java')]
for path in test_sources:
    rel = str(path.relative_to(ROOT)).replace('\\', '/')
    if rel not in ALLOWED_TEST_FILES and not rel.startswith(ALLOWED_TEST_PREFIXES):
        fail(f'out-of-scope test source: {rel}')

target_text = ''
for path in test_sources:
    rel = str(path.relative_to(ROOT)).replace('\\', '/')
    if rel.startswith(ALLOWED_TEST_PREFIXES) or rel.endswith('AceAutoHomeBundleTests.java'):
        target_text += path.read_text(encoding='utf-8', errors='ignore') + '\n'

tests = len(re.findall(r'@Test\b', target_text))
descriptions = target_text.count('// Test description:')
if tests != EXPECTED_TESTS:
    fail(f'expected {EXPECTED_TESTS} @Test annotations, found {tests}')
if descriptions != EXPECTED_TESTS:
    fail(f'expected {EXPECTED_TESTS} descriptions, found {descriptions}')

with (ROOT / 'extraction-reports/RESOURCE_SHA256.csv').open(newline='', encoding='utf-8') as fh:
    for row in csv.DictReader(fh):
        path = ROOT / row['resource']
        if not path.exists():
            fail(f'missing resource: {row["resource"]}')
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != row['originalSha256']:
            fail(f'resource changed: {row["resource"]}')

print(f'PASS: {tests} tests, {descriptions} descriptions, scope and resource hashes verified.')
