package com.farmers.ffq.auto.defaultcoverage;

import static com.farmers.ffq.utils.GlobalVariables.*;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.framework.annotation.Skip;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

public class DefaultCoverageValuesTests_CT extends DefaultCoverageBaseTest {
    //Placeholder class as state is currently monetized
    //If the coverage amount is 25kto50k it will get landed on BW
    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "CT_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 25 K50 K NO UMBRELLA.

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "CT_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 25 K50 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_25K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=No", "CT_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 25 K65 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_25K65K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=Yes", "CT_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 25 K65 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "CT_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 30 K60 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "CT_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 30 K60 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_30K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=No", "CT_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 30 K65 K NO UMBRELLA.

    //@Skip
   @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_30K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=Yes", "CT_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 30 K65 K UMBRELLA.

   // @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "CT_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 35 K70 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "CT_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 35 K70 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_35K80K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=No", "CT_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 35 K80 K NO UMBRELLA.

   // @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_35K80K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=Yes", "CT_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 35 K80 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "CT_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 50 K100 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "CT_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 50 K100 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "CT_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 100 K200 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "CT_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 100 K200 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "CT_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 100 K300 K NO UMBRELLA.

   // @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "CT_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 100 K300 K UMBRELLA.


    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_150K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=No", "CT_150K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 150 K300 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_150K300K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=Yes", "CT_150K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 150 K300 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "CT_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 250 K500 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "CT_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 250 K500 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "CT_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 300 K300 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "CT_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 300 K300 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "CT_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 500 K500 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "CT_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 500 K500 K UMBRELLA.

   // @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_500K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "CT_500K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 500 K1000 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_500K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "CT_500K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 500 K1000 K UMBRELLA.

   // @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_1000K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "CT_1000K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 1000 K1000 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_1000K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "CT_1000K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 1000 K1000 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_35K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=No", "CT_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 35 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_35K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=Yes", "CT_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 35 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_45K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=No", "CT_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 45 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_45K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=Yes", "CT_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 45 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "CT_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 50 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "CT_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 50 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=No", "CT_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 60 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=Yes", "CT_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 60 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "CT_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 75 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_75K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "CT_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 75 K UMBRELLA.

   // @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_85K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=No", "CT_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 85 K NO UMBRELLA.

   // @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_85K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=Yes", "CT_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 85 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "CT_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 100 K NO UMBRELLA.

   // @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "CT_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 100 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "CT_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 200 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "CT_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 200 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "CT_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 300 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "CT_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 300 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "CT_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 500 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "CT_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 500 K UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "CT_1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 1000 K NO UMBRELLA.

    //@Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CT)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CT_1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "CT_1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CT 1000 K UMBRELLA.

}
