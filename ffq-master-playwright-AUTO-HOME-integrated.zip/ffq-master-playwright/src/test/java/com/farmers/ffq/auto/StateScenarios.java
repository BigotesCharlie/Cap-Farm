package com.farmers.ffq.auto;

import com.farmers.framework.AutomationFramework;
import com.farmers.ffq.auto.pages.ContinueWithBristolWestPage;
import com.farmers.ffq.auto.pages.InterstitialBundlePage;
import com.farmers.ffq.auto.pages.NameAndDobPage;
import com.farmers.ffq.auto.pages.legacy.YourInfoPageAuto;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.common.pages.LegacyNonOfferingPage;
import com.farmers.ffq.dataproviders.SqlDataProviders;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.datatransferobjects.State;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;

import org.testng.SkipException;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Arrays;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class StateScenarios extends AutomationFramework {

	@Test(dataProvider = SqlDataProviders.STATES_DATA_PROVIDER_NAME, dataProviderClass = SqlDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AS, NH, TT})}, groups = {REGRESSION, STATE_SCENARIOS})
	public void validateStateForAuto(State state) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		String applicantStateCode = state.getStateCode();
		String environmentURI = Property.getUri();
		new LandingPage().enterLandingPageDataAndContinue(LOB_AUTO, state.getZipCode());
		if (applicantStateCode.equals(CA)) {
			fsa.assertTrue(LegacyNonOfferingPage.page().url().contains("interstitial"), "Interstitial page displayed for " + state.getStateName());
		} else if (SqlDataProviders.getListOfLegacyAutoStates().contains(applicantStateCode)) {
			fsa.assertTrue(new YourInfoPageAuto().validatePageTitle(), "Your Information page reached for " + state.getStateName());
		} else if (SqlDataProviders.getListOfAceAutoStates(environmentURI).contains(applicantStateCode) || Arrays.asList(NJ, RI).contains(applicantStateCode)) {
			if (new NameAndDobPage().quickIsOnNameAndDobPage() || new InterstitialBundlePage().isOnInterstitialBundlePage() || new ContinueWithBristolWestPage().isOnGetAQuoteFromBristolWestPage()) {
				fsa.assertTrue(true, "Ace auto reached for " + state.getStateName());
			} else if (new KnockoutInconveniencePage().isOnInconveniencePage()) {
				fsa.assertTrue(true, "Ace auto quote knocked out for " + state.getStateName());
			}
		} else {
			validateUninsuredState(state, fsa);
		}
		fsa.assertAll();
	}
	// Test description: Validates the Auto behavior for Validate State For Auto.

	@Test(dataProvider = SqlDataProviders.ALL_BVT_AUTO_APPLICANTS_DATA_PROVIDER, attributes = {@CustomAttribute(name = MONETIZED_STATES)}, dataProviderClass = SqlDataProviders.class, groups = {REGRESSION, STATE_SCENARIOS})
	public void validateStateForAutoUsingAOR(SqlApplicant applicant) throws Exception {
		String environmentURI = Property.getUri();
		String applicantStateCode = applicant.getStateCode();
		if (SqlDataProviders.getListOfLegacyAutoMonetizedStates(environmentURI).contains(applicantStateCode) || SqlDataProviders.getListOfLegacyAutoStates().contains(applicantStateCode)) {
			FarmersSoftAssert fsa = new FarmersSoftAssert();
			new LandingPage().enterLandingPageDataAndContinue(LOB_AUTO, applicant.getZipCode());
			YourInfoPageAuto yip = new YourInfoPageAuto();
			fsa.assertTrue(yip.validatePageTitle(), "Your Information page reached for " + applicantStateCode);
			fsa.assertAll();
		} else {
			throw new SkipException("Legacy auto not available for " + applicant.getStateName() + ", skipping test.");
		}
	}
	// Test description: Validates the Auto behavior for Validate State For Auto Using AOR.

	private void validateUninsuredState(State state, FarmersSoftAssert fsa) throws Exception {
		LegacyNonOfferingPage legacyNonOfferingPage = new LegacyNonOfferingPage();
		String currentUrl = LegacyNonOfferingPage.page().url();
		switch (state.getStateCode()) {
			case AK: case DE:
				break;
			case GA: case NY:
				fsa.assertTrue(legacyNonOfferingPage.quotingUnavailableTextExists(), "Unable to provide quote page displayed for " + state.getStateName());
				break;
			case HI:
				fsa.assertTrue(currentUrl.contains("groupselect"), "Farmers GroupSelect Quote page displayed for " + state.getStateName());
				break;
			case ME: case VT: case WV:
				fsa.assertTrue(currentUrl.contains("quote-and-buy-farmers"), "CustomerEngage quote and buy page displayed for " + state.getStateName());
				break;
			case NC:
				fsa.assertTrue(currentUrl.contains("fgia"), "Continue with Farmers General Insurance Agency page displayed for " + state.getStateName());
				break;
			case VA:
				fsa.assertEquals(new KnockoutInconveniencePage().getPageTitle(), "Thank you for your interest in Farmers Insurance\u00ae", "Ace knockout for " + state.getStateName());
				break;
			default:
				fsa.assertTrue(legacyNonOfferingPage.isNonOfferingTextExist(), state.getStateName() + " quotes should be forwarded to non-offering page.");
				break;
		}
	}
}
