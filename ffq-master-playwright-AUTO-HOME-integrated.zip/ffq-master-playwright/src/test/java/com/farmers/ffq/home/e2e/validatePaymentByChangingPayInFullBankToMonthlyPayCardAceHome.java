package com.farmers.ffq.home.e2e;

import com.farmers.framework.AutomationFramework;
import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.farmers.ffq.homevideoflow.flow.HomeVideoFlow;
import org.testng.annotations.Test;

/** Functional HOME video/payment E2E imported from ffq-homeHP-e2e and hosted by the master Playwright lifecycle. */
public class validatePaymentByChangingPayInFullBankToMonthlyPayCardAceHome extends AutomationFramework {

    // Test description: HOME payment-change/video flow imported from ffq-homeHP-e2e.
    @Test(groups = {"HOME_E2E"}, description = "HOME payment change E2E reproduced from the validated video flow")
    public void reproduceVideoFlowE2E() {
        page().setViewportSize(1440, 1000);
        VideoScenarioData data = VideoScenarioData.fromVideo(HomeE2EEnvironment.startUrl());
        new HomeVideoFlow(page(), data).run();
    }
}
