package com.farmers.ffq.auto.e2e;

import com.farmers.framework.playwright.AutoDebugManager;
import com.farmers.framework.playwright.PlaywrightArtifacts;
import com.farmers.framework.playwright.PlaywrightSession;
import com.farmers.framework.report.Log;

import java.util.Locale;

/**
 * Bind One UI COPY-DOM diagnostics.
 *
 * AutoDebugManager stores Page.content() through the central CopyDOM layer. This class then
 * classifies that rendered DOM using contracts already present in the AUTO and
 * Bind One UI page objects. It is intentionally evidence-oriented: it never
 * manufactures a pass and it never hides the Page Object assertion that failed.
 */
public final class AutoBindE2EDiagnostics {

    private AutoBindE2EDiagnostics() {
    }

    public static AutoBindPageState checkpoint(String label) {
        try {
            AutoDebugManager.checkpoint(label, true);
            String html = PlaywrightSession.page().content();
            AutoBindPageState state = detectState(html);
            Log.info("AUTOBIND COPY-DOM checkpoint=" + label + " state=" + state);
            return state;
        } catch (Exception error) {
            Log.warn("AUTOBIND COPY-DOM checkpoint failed for " + label + ": " + error.getMessage());
            return AutoBindPageState.UNKNOWN;
        }
    }

    public static void captureFailure(String label, Throwable cause) {
        try {
            AutoDebugManager.checkpoint("failure-current-page-" + label, true);
            AutoBindPageState state = detectState(PlaywrightSession.page().content());
            try {
                PlaywrightArtifacts.screenshot("failure-current-page", true, "autobind");
            } catch (RuntimeException screenshotError) {
                Log.warn("AUTOBIND diagnostic screenshot failed: " + screenshotError.getMessage());
            }
            Log.warn("AUTOBIND failure checkpoint=" + label
                    + " state=" + state
                    + " cause=" + safeMessage(cause));
        } catch (Exception artifactError) {
            Log.warn("AUTOBIND failure evidence could not be captured: " + artifactError.getMessage());
        }
    }

    static AutoBindPageState detectState(String renderedHtml) {
        String html = renderedHtml == null ? "" : renderedHtml.toLowerCase(Locale.ROOT);

        // Terminal/interruption states first so generic page text cannot mask them.
        if (containsAny(html,
                "payment successful",
                "thank you for joining us as a policyholder",
                "welcome to farmers")) {
            return AutoBindPageState.PURCHASE_SUCCESS;
        }
        if (containsAny(html, "sign electronically", "cta-sign")) {
            return AutoBindPageState.ESIGN;
        }
        if (containsAny(html, "inconvenience__", "we're sorry, we can't finish your quote", "try again")) {
            return AutoBindPageState.INCONVENIENCE;
        }
        if (containsAny(html, "knock-out_", "knockout__", "your quote requires special attention")) {
            return AutoBindPageState.KNOCKOUT;
        }
        if (containsAny(html,
                "<app-knockout-lead-form",
                "thank you for your interest in farmers",
                "unable to provide you an online quote at this time")) {
            return AutoBindPageState.KNOCKOUT;
        }

        // Bind/payment states.
        if (containsAny(html,
                "<app-payment-consolidated",
                "<app-payment-overview",
                "select your preferred payment method")) {
            return AutoBindPageState.PAYMENT_SELECTION;
        }
        if (containsAny(html, "auto policy payment", "set up payment method", "paymentus manage payments")) {
            return AutoBindPageState.PAYMENT_METHOD;
        }
        if (containsAny(html,
                "additional-info-main-page",
                "just a few more things",
                "let's complete your quote",
                "review and complete auto")) {
            return AutoBindPageState.ADDITIONAL_INFO;
        }
        if (containsAny(html, "driver mismatch", "mismatched driver", "driver-mismatch")) {
            return AutoBindPageState.DRIVER_MISMATCH;
        }

        // Quote states.
        if (containsAny(html,
                "tui-quote-presentment",
                "quote-presentment-content-wrapper",
                "<app-coverage",
                "here's your quote")) {
            return AutoBindPageState.QUOTE_SUMMARY;
        }
        if (containsAny(html, "bristol west additional discounts", "additional-discounts")) {
            return AutoBindPageState.BRISTOL_WEST_ADDITIONAL_DISCOUNTS;
        }
        if (containsAny(html, "continue with bristol west", "continue-with-bristol-west")) {
            return AutoBindPageState.CONTINUE_WITH_BRISTOL_WEST;
        }

        // Quote intake states.
        if (containsAny(html, "vehicle-driver-assignment", "assign drivers", "vehicle driver assignment")) {
            return AutoBindPageState.VEHICLE_DRIVER_ASSIGNMENT;
        }
        if (containsAny(html,
                "id=\"contact-info-heading\"",
                "id='contact-info-heading'",
                "contact information")) {
            return AutoBindPageState.CONTACT_INFO;
        }
        if (containsAny(html, "who should we insure", "who-should-we-insure")) {
            return AutoBindPageState.WHO_SHOULD_WE_INSURE;
        }
        if (containsAny(html, "auto-manual-street__input-section", "aria-label=\"mailing address\"", "enter your address")) {
            return AutoBindPageState.ADDRESS;
        }
        if (containsAny(html,
                "personal-info_name_dob",
                "personal-info__container",
                "let's begin")) {
            return AutoBindPageState.NAME_DOB;
        }
        if (containsAny(html, "fastquote", "get a quote", "start my quote")) {
            return AutoBindPageState.LANDING;
        }
        return AutoBindPageState.UNKNOWN;
    }

    private static boolean containsAny(String html, String... contracts) {
        for (String contract : contracts) {
            if (html.contains(contract)) {
                return true;
            }
        }
        return false;
    }

    private static String safeMessage(Throwable cause) {
        if (cause == null) {
            return "<none>";
        }
        String message = cause.getMessage();
        return cause.getClass().getSimpleName() + (message == null || message.isBlank() ? "" : ": " + message);
    }
}
