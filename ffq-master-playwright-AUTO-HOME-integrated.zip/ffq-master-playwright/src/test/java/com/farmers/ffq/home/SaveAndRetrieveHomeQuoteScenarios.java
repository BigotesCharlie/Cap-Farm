package com.farmers.ffq.home;

import com.farmers.framework.AutomationFramework;
import static com.farmers.ffq.utils.GlobalVariables.CHOOSE_YOUR_COVERAGE_PAGE;
import static com.farmers.ffq.utils.GlobalVariables.EMPTY_STRING;
import static com.farmers.ffq.utils.GlobalVariables.GET_RETRIEVE_HOME;
import static com.farmers.ffq.utils.GlobalVariables.PROPERTY_PAGE_HOME;
import static com.farmers.ffq.utils.GlobalVariables.QUOTE_PAGE_HOME;
import static com.farmers.ffq.utils.GlobalVariables.REGRESSION;
import static com.farmers.ffq.utils.GlobalVariables.YOUR_INFO_PAGE_HOME;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantHome;
import com.farmers.ffq.home.pages.ChooseYourCoveragePage;
import com.farmers.ffq.home.pages.PropertyPage;
import com.farmers.ffq.home.pages.QuotePageHome;
import com.farmers.ffq.home.pages.ThankYouPage;
import com.farmers.ffq.home.pages.YourInfoPageHome;
import com.farmers.ffq.utils.FarmersSoftAssert;

public class SaveAndRetrieveHomeQuoteScenarios extends AutomationFramework {
	private static final String EXPECTING_TO_BE_IN = "Expecting to be in ";
	private static final String QUOTE_KNOCKED_OUT = "Quote knocked out before ";

	@Test(dataProvider = DataProviders.GET_RETRIEVE_QUOTE_APPLICANT_HOME, dataProviderClass = DataProviders.class, groups = {GET_RETRIEVE_HOME, REGRESSION}, priority = 1)
	public void saveAndRetrieveHomeQuotes(ApplicantHome applicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		applicant.setFirstName(LandingPage.generateString());
		applicant.setLastName(LandingPage.generateString());
		if (applicant.isAwsFlowScenario()) {
			new LandingPage(applicant);
		} else {
			new LandingPage(applicant.isChangeBrowserDimensionScenario()).enterLandingPageDataAndContinue(applicant.getLineOfBusiness(), applicant.getZipCode());
		}
		YourInfoPageHome yourInfoPageHome = new YourInfoPageHome();
		PropertyPage propertyPageHome = yourInfoPageHome.enterYourInfoAndContinue(applicant, true, fsa);
		ChooseYourCoveragePage chooseYourCoverageHome = propertyPageHome.enterPropertyInfo(applicant, fsa);
		if (chooseYourCoverageHome != null || applicant.isSaveAndRetrievePropPage()) {
			if (applicant.isSaveAndRetrieveCoveragePage()) {
				chooseYourCoverageHome.saveHomeOnCoveragePageAndFinishLater(applicant);
			} else if (!applicant.isSaveAndRetrievePropPage()) {
				QuotePageHome quotePageHome = chooseYourCoverageHome.enterChooseYourCoveragePage(applicant, fsa);
				if (applicant.isSaveAndRetrieveQuotePage()) {
					quotePageHome.saveHomeOnQuotePageAndFinishLater(applicant);
				} else {
					quotePageHome.enterQuotePage(applicant, fsa);
				}
			}
			LandingPage retrieveLandingPage = new LandingPage();
			retrieveLandingPage.clickRetrieveSavedQuoteTab();
			Object returningPage = retrieveLandingPage.enterRetrieveQuote(applicant, EMPTY_STRING);
			switch (returningPage.getClass().getSimpleName()) {
			case YOUR_INFO_PAGE_HOME:
				yourInfoPageHome = YourInfoPageHome.class.cast(returningPage);
				if (yourInfoPageHome.onYourInfoPageHome()) {
					resumeFromYourInfoPage(applicant, yourInfoPageHome, fsa);
				} else {
					Assert.fail(EXPECTING_TO_BE_IN + YOUR_INFO_PAGE_HOME);
				}
				break;
			case PROPERTY_PAGE_HOME:
				propertyPageHome = PropertyPage.class.cast(returningPage);
				if (propertyPageHome.onPropertyPage()) {
					resumeFromPropertyPage(applicant, propertyPageHome, fsa);
				} else {
					Assert.fail(EXPECTING_TO_BE_IN + PROPERTY_PAGE_HOME);
				}
				break;
			case CHOOSE_YOUR_COVERAGE_PAGE:
				chooseYourCoverageHome = ChooseYourCoveragePage.class.cast(returningPage);
				if (chooseYourCoverageHome.onChooseYourCoveragePage()) {
					resumeFromChooseYourCoveragePage(applicant, chooseYourCoverageHome, fsa);
				} else {
					Assert.fail(EXPECTING_TO_BE_IN + CHOOSE_YOUR_COVERAGE_PAGE);
				}
				break;
			case QUOTE_PAGE_HOME:
				QuotePageHome quotePageHome = QuotePageHome.class.cast(returningPage);
				if (quotePageHome.onQuotePageHome()) {
					resumeFromQuotePageHome(applicant, quotePageHome, fsa);
				} else {
					Assert.fail(EXPECTING_TO_BE_IN + QUOTE_PAGE_HOME);
				}
				break;
			default:
				throw new IllegalArgumentException("Wrong class name: " + returningPage.getClass().getSimpleName());
			}
		}
		fsa.assertAll();
	}
	// Test description: Validates the Home behavior for Save And Retrieve Home Quotes.

	private void resumeFromYourInfoPage(ApplicantHome applicant, YourInfoPageHome yourInfoPageHome, FarmersSoftAssert fsa) throws Exception {
		resumeFromPropertyPage(applicant, yourInfoPageHome.validateYourInfoPageHomeAndContinue(applicant, fsa), fsa);
	}

	private void resumeFromPropertyPage(ApplicantHome applicant, PropertyPage propertyPageHome, FarmersSoftAssert fsa) throws Exception {
		applicant.setSaveAndRetrievePropPage(false);
		if (propertyPageHome != null) {
			resumeFromChooseYourCoveragePage(applicant, propertyPageHome.validatePropertyPageHomeAndContinue(applicant, fsa), fsa);
		} else {
			Assert.fail(QUOTE_KNOCKED_OUT + PROPERTY_PAGE_HOME);
		}
	}

	private void resumeFromChooseYourCoveragePage(ApplicantHome applicant, ChooseYourCoveragePage chooseYourCoverageHome, FarmersSoftAssert fsa) throws Exception {
		if (chooseYourCoverageHome != null) {
			resumeFromQuotePageHome(applicant, chooseYourCoverageHome.enterChooseYourCoveragePage(applicant, fsa), fsa);
		} else {
			Assert.fail(QUOTE_KNOCKED_OUT + CHOOSE_YOUR_COVERAGE_PAGE);
		}
	}

	private void resumeFromQuotePageHome(ApplicantHome applicant, QuotePageHome quotePageHome, FarmersSoftAssert fsa) throws Exception {
		if (quotePageHome != null) {
			ThankYouPage thankYouPageHome = quotePageHome.enterQuotePage(applicant, fsa);
			if (thankYouPageHome != null) {
				thankYouPageHome.verifyThankYouPageContent(applicant, fsa);
			}
		} else {
			Assert.fail(QUOTE_KNOCKED_OUT + QUOTE_PAGE_HOME);
		}
	}
}
