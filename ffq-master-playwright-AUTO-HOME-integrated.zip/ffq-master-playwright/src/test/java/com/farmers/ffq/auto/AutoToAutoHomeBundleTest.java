package com.farmers.ffq.auto;


import com.microsoft.playwright.Page;
import com.farmers.ffq.BaseTest;
import com.farmers.ffq.ace.bundle.AceBundleNavigationHelper;
import com.farmers.ffq.ace.hrc.common.AceHRCPropertyTypeBasePage;
import com.farmers.ffq.acebundle.AceBundleTestHelper;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.dataproviders.AceBundleDataProviders;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AceBundleApplicant;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AutoToAutoHomeBundleTest extends BaseTest {

    private static final String AUTO_TO_MONO_LINE_OR_BUNDLE = "autoToMonoLineOrAutoHomeBundle";
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA/*AL, AR, AZ, GA, IA, ID, IL, IL, IN, KS, KY, MD, MN, MO, ND, NE, NM, OK, PA, SD, TN, TX, UT, VA, WA, WI, WY*/}),
                    @CustomAttribute(name = FILTER, values = "applicantId=1")}, groups = {FFQ_ONEUI, AUTO_TO_MONO_LINE_OR_BUNDLE})
    public void validateAutoToMonoLineAutoFromInterstitialPage(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        setOwnOrRentHomeInApplicantAsOwned(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));

        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);

        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        if(vehiclesDriversInfoPage.isOnVehiclesDriversInfoPage()) {
            testStepAssert(vehiclesDriversInfoPage.isOnVehiclesDriversInfoPage(), "Successfully navigated to consolidated vehicle driver info page");
        }else{
            HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
            testStepAssert(heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "Successfully navigated to Heres what we found page");
        }

        List<String> foundSteppers = vehiclesDriversInfoPage.getListOfSteps();
        List<String> expectedSteppers = List.of(ENTER_INFO, REVIEW_QUOTE, PURCHASE);
        testStepAssertTrue(foundSteppers.equals(expectedSteppers), "Flow landed in Bundle quote flow as expected");

        aceAutoNavigationHelper.processHeresWhatWeFoundOrVehicleDriverConsolidatedPage(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = vehiclesDriversInfoPage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        completePurchase(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Auto To Mono Line Auto From Interstitial Page.


    @Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AceBundleDataProviders.class, groups = {FFQ_ONEUI, AUTO_TO_MONO_LINE_OR_BUNDLE})
    public void validateAutoToBundleHomeFlowFromInterstitialPage(AceBundleApplicant bundleApplicant) throws Exception {
        AceBundleTestHelper aceBundleTestHelper = new AceBundleTestHelper();
        aceBundleTestHelper.applicantAdjustment(bundleApplicant);
        setOwnOrRentHomeInAceBundleApplicantAsOwned(bundleApplicant);

        AutoApplicant applicant = bundleApplicant.getAutoApplicant();
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));

        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
        AutoEnterAddressPage autoEnterAddressPage = aceAutoNavigationHelper.navigateToAutoEnterAddressPage(autoApplicant);
        autoEnterAddressPage.fillOutAddressPage(autoApplicant);
        InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
        testStepAssert(interstitialBundlePage.isOnInterstitialBundlePage(), "User is on Interstitial Bundle Page");
        interstitialBundlePage.continueWithBundle();
        interstitialBundlePage.waitForSpinnerToBeGone();

        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        if(vehiclesDriversInfoPage.isOnVehiclesDriversInfoPage()) {
            testStepAssert(vehiclesDriversInfoPage.isOnVehiclesDriversInfoPage(), "Successfully navigated to consolidated vehicle driver info page");
            vehiclesDriversInfoPage.navigateBack();
            testStepAssert(vehiclesDriversInfoPage.isOnVehiclesDriversInfoPage(), "Browser back is disabled in Interstitial flow, stayed on Vehicle driver info page");
        }else{
            HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
            testStepAssert(heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "Successfully navigated to Heres what we found page");
            heresWhatWeFoundPage.navigateBack();
            testStepAssert(heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "Browser back is disabled in Interstitial flow, stayed on heres what we found page");
        }

        List<String> foundSteppers = vehiclesDriversInfoPage.getListOfSteps();
        List<String> expectedSteppers = List.of(AUTO_INFO, PROPERTY_INFO, REVIEW_QUOTE, PURCHASE);
        testStepAssertTrue(foundSteppers.equals(expectedSteppers), "Flow landed in Bundle quote flow as expected");

        aceAutoNavigationHelper.processHeresWhatWeFoundOrVehicleDriverConsolidatedPage(applicant);

        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        AceBundleNavigationHelper aceBundleNavigationHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
        aceBundleNavigationHelper.setResumeFromPage(whoShouldWeInsurePage.getClass().getSimpleName());
        aceBundleNavigationHelper.navigateToECheckoutPage(bundleApplicant);
    }
    // Test description: Validates the Auto behavior for Validate Auto To Bundle Home Flow From Interstitial Page.

    @Test(dataProvider = AceBundleDataProviders.BUNDLE_APPLICANT_DATAPROVIDER, testName = AceBundleDataProviders.RANDOM_BUNDLE_APPLICANT,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AZ, GA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AceBundleDataProviders.class, groups = {FFQ_ONEUI, AUTO_TO_MONO_LINE_OR_BUNDLE})
    public void validateAutoHomeBundleFlowFromAutoQuoteSummaryPage(AceBundleApplicant bundleApplicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AceBundleTestHelper aceBundleTestHelper = new AceBundleTestHelper();
        aceBundleTestHelper.applicantAdjustment(bundleApplicant);
        setOwnOrRentHomeInAceBundleApplicantAsOwned(bundleApplicant);

        AutoApplicant applicant = bundleApplicant.getAutoApplicant();
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));

        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(autoApplicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        quoteSummaryAutoPage.closeQualtricsPopUp();
        quoteSummaryAutoPage.checkBundleOrContinueToAutoButtonNotDisplayed(fsa);

        quoteSummaryAutoPage.navigateBack();
        testStepAssert(contactInfoAutoPage.isOnContactInfoAutoPage(), "Successfully navigated to Contact Info Auto Page");
        contactInfoAutoPage.uncheckAllTheBundleCheckbox();
        contactInfoAutoPage.clickContinueButton();

        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        quoteSummaryAutoPage.checkBundleOrContinueToAutoButtonDisplayed(fsa);
        quoteSummaryAutoPage.clickBundleAndContinueButton();
        AceHRCPropertyTypeBasePage aceHRCPropertyTypeBasePage = new AceHRCPropertyTypeBasePage();
        testStepAssert(aceHRCPropertyTypeBasePage.isOnPropertyTypePage(), "Successfully navigated to Property Type Page");

        AceBundleNavigationHelper aceBundleNavigationHelper = new AceBundleNavigationHelper(AUTO_HOME_BUNDLE);
        aceBundleNavigationHelper.setResumeFromPage(aceHRCPropertyTypeBasePage.getClass().getSimpleName());
        aceBundleNavigationHelper.navigateToECheckoutPage(bundleApplicant);

        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Auto Home Bundle Flow From Auto Quote Summary Page.

    public void setOwnOrRentHomeInApplicantAsOwned(AutoApplicant applicant) {
        applicant.getDiscounts().forEach(i -> i.setOwnOrRentHome("Own a home"));
    }
    public void setOwnOrRentHomeInAceBundleApplicantAsOwned(AceBundleApplicant applicant) {
        applicant.getAutoApplicant().getDiscounts().forEach(i -> i.setOwnOrRentHome("Own a home"));
    }
}
