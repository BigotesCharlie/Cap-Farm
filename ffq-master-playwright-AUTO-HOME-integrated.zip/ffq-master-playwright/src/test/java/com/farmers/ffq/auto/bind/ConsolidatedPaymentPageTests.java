package com.farmers.ffq.auto.bind;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.HeresWhatWeFoundPage;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
import com.farmers.ffq.auto.pages.WhoShouldWeInsurePage;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoContinueToPaymentOneUI;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.auto.pages.bindpages.ConsolidatedPaymentPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;

import com.farmers.framework.report.Log;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.MONTHLY_AUTOPAY;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Feature for Reference: F76393
 */
public class ConsolidatedPaymentPageTests extends BaseTest {

    private final String CONSOLIDATED_TESTS = "consolidatedTest";

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA, CA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})
    public void validateAceAutoPaymentSummaryPage(AutoApplicant applicant) throws Exception {
        applicant.getVehicles().forEach(each -> each.setUseVIN(true));
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        setLastNameForHitData(applicant);
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(consolidatedPaymentPage.isOnConsolidatedPaymentPage(), "User landed on the Consolidated payment page");
        consolidatedPaymentPage.validateConsolidatedPaymentPage(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Ace Auto Payment Summary Page.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})
    public void consolidatePaymentPageValidatePayments_F76393(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        setLastNameForHitData(applicant);
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(consolidatedPaymentPage.isOnConsolidatedPaymentPage(), "User landed on the Consolidated payment page");
        consolidatedPaymentPage.validatePayments(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Consolidate Payment Page Validate Payments F76393.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, UT, TN, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})
    public void validatePremiumChangeMessageAndGoingBackToQuoteScreenPage_F76393(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        setLastNameForHitData(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        fsa.assertTrue(consolidatedPaymentPage.isOnConsolidatedPaymentPage(), "User landed on the Consolidated payment page");
        consolidatedPaymentPage.validatePremiumChangeMessage(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Premium Change Message And Going Back To Quote Screen Page F76393.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, WA}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})
    public void validateIframeContents(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        setLastNameForHitData(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        consolidatedPaymentPage.validateIframeContents(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Iframe Contents.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, WA}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})
    public void validateIframeErrorMessages(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        consolidatedPaymentPage.validateIframeErrors(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Iframe Error Messages.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, WA}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE})
    public void testIframeValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        setLastNameForHitData(applicant);
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        consolidatedPaymentPage.validateIframes(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Iframe Validation.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, KY, FL, WA}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})
    public void validatePreviouslyAddedPaymentMethodIsDeleted(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        setLastNameForHitData(applicant);
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        consolidatedPaymentPage.selectPaymentMethodFromPaymentCards(MONTHLY_AUTOPAY);
        consolidatedPaymentPage.clickCardRadioButton();
        consolidatedPaymentPage.addCardPaymentMethod(MASTER_CARD, applicant.getZipCode());
        testStepAssert(consolidatedPaymentPage.isGreenCheckIsDisplayed(), "First time card successfully added", true);
        additionalInfoContinueToPaymentOneUI.clickReviewQuoteNavigationBarStepper();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page", true);
        new QuoteSummaryAutoPage().clickOnStartCheckoutButton();
        additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();
        // add same payment method with pay in full
        consolidatedPaymentPage.selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
        consolidatedPaymentPage.clickCardRadioButton();
        consolidatedPaymentPage.addCardPaymentMethod(MASTER_CARD, applicant.getZipCode());
        testStepAssert(consolidatedPaymentPage.isGreenCheckIsDisplayed(), "Card time card successfully added second time", true);

    }
    // Test description: Validates the Auto behavior for Validate Previously Added Payment Method Is Deleted.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, WA}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})}, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})
    public void validateBackAndForthValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        setLastNameForHitData(applicant);
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);

        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        testStepAssert(consolidatedPaymentPage.isOnConsolidatedPaymentPage(), "User is on the Consolidated payment page", true);
        consolidatedPaymentPage.clickChangeYourCoverageLink();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page after clicking 'Change your coverage link' from consolidated payment page");
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage() || heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "User is vehicles drivers addition page after clicking 'enter info' navbar from quote summary page", true);
        whoShouldWeInsurePage.clickPurchaseNavigationBarStepper();
        testStepAssert(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User should be on the Additional Info page after user clicks on the 'purchase' navbar from Who SHould we insure page");
        consolidatedPaymentPage.clickContinueToPaymentButton();
        testStepAssert(consolidatedPaymentPage.isOnConsolidatedPaymentPage(), "User is on Consolidated payment page");
        consolidatedPaymentPage.clickEnterInfoNavigationBarStepper();
        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage() || heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "User is vehicles drivers addition page after clicking 'enter info' navbar from Consolidated payment page", true);

        consolidatedPaymentPage.clickReviewQuoteNavigationBarStepper();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on Quote Summary page after clicking 'Review quote' navbar from Consolidated payment page", true);

        if(quoteSummaryAutoPage.isOnBristolWest()) {
            Log.info("Test finished earlier than expected because the quote is from Bristol West and the flow is different than Farmers");
            return;
        }
        quoteSummaryAutoPage.clickPurchaseNavigationBarStepper();
        testStepAssert(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User should be on the Additional Info page after user clicks on the 'purchase ' navbar from Quote Summary page");

        consolidatedPaymentPage.clickContinueToPaymentButton();
        testStepAssert(consolidatedPaymentPage.isOnConsolidatedPaymentPage(), "User is on Consolidated payment page");
    }
    // Test description: Validates the Auto behavior for Validate Back And Forth Validation.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, CONSOLIDATED_TESTS})
    public void validatePaymentMethodChangesAndPurchase(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        setLastNameForHitData(applicant);
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        testStepAssert(consolidatedPaymentPage.isOnConsolidatedPaymentPage(), "User is on the Consolidated payment page", true);
        consolidatedPaymentPage.validatePaymentMethodChanges(fsa);
        consolidatedPaymentPage.clickCompletePurchaseButton();
        consolidatedPaymentPage.waitForSpinnerToBeGone();
        echeckout(fsa);
        fsa.assertAll("Changed payment method and purchased quote");
    }
    // Test description: Validates the Auto behavior for Validate Payment Method Changes And Purchase.

    private void setLastNameForHitData(AutoApplicant applicant) {
        if (List.of(NM, MT, MN).contains(applicant.getStateCode())) {
            applicant.setLastName("HITDATA");
        } else {
            applicant.setLastName("Brown");
        }
    }
}
