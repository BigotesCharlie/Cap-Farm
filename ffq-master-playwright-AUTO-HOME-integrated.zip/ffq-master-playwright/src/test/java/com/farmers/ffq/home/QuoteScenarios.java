package com.farmers.ffq.home;

import com.farmers.framework.AutomationFramework;

import com.microsoft.playwright.Page;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantHome;
import com.farmers.ffq.home.pages.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Quote Scenarios Page - Home.
 */
public class QuoteScenarios extends AutomationFramework {

	@Test(dataProvider = DataProviders.APPLICANT_HOME_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {GET_HOME, REGRESSION, SPOT_TESTING})
	public void getHomeQuote(ApplicantHome applicant) throws Exception {
		createHomeQuote(applicant);
	}
	// Test description: Validates the Home behavior for Get Home Quote.

	@Test(dataProvider = DataProviders.MONETIZED_STATES_LEGACY_HOME_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {GET_HOME, REGRESSION, SPOT_TESTING})
	public void legacyHomeQuoteUsingAOR(ApplicantHome applicant) throws Exception {
        if (Property.getTestProperty("remote").equalsIgnoreCase("local")) {
        	applicant.setAwsFlowScenario(true);
        	createHomeQuote(applicant);
        } else {
    		throw new SkipException("Legacy home AOR testing only available locally");
        }
	}
	// Test description: Validates the Home behavior for Legacy Home Quote Using AOR.

	public void createCrossSellHomeQuote(ApplicantHome applicant, String returnToLOB) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		YourInfoPageHome yourInfoPageHome = new YourInfoPageHome();
		PropertyPage propertyPage = yourInfoPageHome.enterCrossSellYourInfoAndContinue(applicant);
		ChooseYourCoveragePage yourCoverage = propertyPage.enterPropertyInfo(applicant, fsa);
		QuotePageHome quotePageHome = yourCoverage.enterChooseYourCoveragePage(applicant, fsa);
		if (quotePageHome == null) {
			Assert.fail("Home quote knocked out");
		} else {
			quotePageHome.clickCrossSellQuote(returnToLOB);
		}
		fsa.assertAll();
	}

	private void createHomeQuote(ApplicantHome applicant) throws Exception {
		if (!applicant.isErrorScenario()) {
			FarmersSoftAssert fsa = new FarmersSoftAssert();
			if (applicant.isAwsFlowScenario()) {
				new LandingPage(applicant);
			} else {
				new LandingPage(applicant.isChangeBrowserDimensionScenario()).enterLandingPageDataAndContinue(LOB_HOME, applicant.getZipCode());
			}
			YourInfoPageHome yourInfoPageHome = new YourInfoPageHome();
			PropertyPage propertyPage = yourInfoPageHome.enterYourInfoAndContinue(applicant, true, fsa);
			if (propertyPage != null) {
				ChooseYourCoveragePage yourCoverage = propertyPage.enterPropertyInfo(applicant, fsa);
				if (yourCoverage != null) {
					QuotePageHome quotePageHome = yourCoverage.enterChooseYourCoveragePage(applicant,  fsa);
					if (quotePageHome != null) {
						Object page = quotePageHome.enterQuotePage(applicant, fsa);
						if (page !=null) {
							switch (page.getClass().getSimpleName()) {
							case PROPERTY_PAGE_HOME:
								PropertyPage propertyPageHome = PropertyPage.class.cast(page);
								ChooseYourCoveragePage chooseYourCoveragePage = propertyPageHome.enterPropertyInfo(applicant, fsa);
								if (chooseYourCoveragePage != null) {
									QuotePageHome quotePage = chooseYourCoveragePage.enterChooseYourCoveragePage(applicant, fsa);
									ThankYouPage thankYouPage = quotePage.enterQuotePage(applicant, fsa);
									if (thankYouPage != null) {
										thankYouPage.verifyThankYouPageContent(applicant, fsa);
									}
								}
								break;
							case THANK_YOU_PAGE:
								ThankYouPage thankYouPage = ThankYouPage.class.cast(page);
								thankYouPage.verifyThankYouPageContent(applicant, fsa);
								break;
							default :
								System.out.println("Unexpected page returned: " + page.getClass().getSimpleName());
								break;
							}
						}
					}
				}
			}
			fsa.assertAll();
		}
	}
}

