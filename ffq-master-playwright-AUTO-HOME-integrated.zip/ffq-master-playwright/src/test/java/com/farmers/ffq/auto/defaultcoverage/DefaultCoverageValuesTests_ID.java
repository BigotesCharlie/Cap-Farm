package com.farmers.ffq.auto.defaultcoverage;

import static com.farmers.ffq.utils.GlobalVariables.*;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

public class DefaultCoverageValuesTests_ID extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_15K30K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=No", "ID_15K30K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 15 K30 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_15K30K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=Yes", "ID_15K30K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 15 K30 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_20K40K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=No", "ID_20K40K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 20 K40 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_20K40K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=Yes", "ID_20K40K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 20 K40 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "ID_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 25 K50 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "ID_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 25 K50 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "ID_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 30 K60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "ID_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 30 K60 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "ID_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 35 K70 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "ID_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 35 K70 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "ID_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 50 K100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "ID_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 50 K100 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "ID_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 100 K200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "ID_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 100 K200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "ID_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 100 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "ID_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 100 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "ID_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 250 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "ID_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 250 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "ID_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 300 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "ID_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 300 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "ID_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 500 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "ID_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 500 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_1M1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "ID_1M1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 1 M1 M NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_1M1M_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "ID_1M1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 1 M1 M UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "ID_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 50 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "ID_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 50 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "ID_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 75 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_75K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "ID_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 75 K UMBRELLA.
    
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "ID_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "ID_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 100 K UMBRELLA.
    
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "ID_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "ID_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 200 K UMBRELLA.
    
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "ID_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "ID_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 300 K UMBRELLA.
    
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "ID_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "ID_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 500 K UMBRELLA.
    
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "ID_1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 1 M NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = ID)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_ID_1M_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "ID_1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values ID 1 M UMBRELLA.
 }
