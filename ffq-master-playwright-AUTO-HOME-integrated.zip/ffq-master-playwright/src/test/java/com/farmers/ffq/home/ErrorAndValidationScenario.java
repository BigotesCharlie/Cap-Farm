package com.farmers.ffq.home;

import com.farmers.framework.AutomationFramework;

import com.microsoft.playwright.Page;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantHome;
import com.farmers.ffq.home.pages.*;
import com.farmers.ffq.utils.FarmersSoftAssert;

import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.PAGE_VALIDATION_HOME;
import static com.farmers.ffq.utils.GlobalVariables.REGRESSION;

/**
 * Farmers Fast Quote (FFQ) - Error and Page Validation Scenarios - Home.
 *
 *
 */

public class ErrorAndValidationScenario extends AutomationFramework {
	@Test(dataProvider = DataProviders.APPLICANT_HOME_ERROR_DATA_PROVIDER, dataProviderClass = DataProviders.class, groups = {PAGE_VALIDATION_HOME, REGRESSION })
	public void errorAndPageValidationScenario(ApplicantHome applicant) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		new LandingPage().enterLandingPageDataAndContinue(applicant.getLineOfBusiness(), applicant.getZipCode());
		YourInfoPageHome yourInfoPageHome = new YourInfoPageHome();
		yourInfoPageHome.yourInfoPageValidationHome(applicant, fsa);
		PropertyPage propertyPage = yourInfoPageHome.yourInfoPageErrorValidationHome(applicant, fsa);
		propertyPage.propertyPageValidationHome(fsa);
		ChooseYourCoveragePage chooseYourCoveragePage = propertyPage.propertyPageErrorValidationHome(applicant, fsa);
		if (chooseYourCoveragePage != null) {
			QuotePageHome quotePageHome = chooseYourCoveragePage.chooseYourCoveragePageValidationHome(applicant, fsa);
			quotePageHome.quotePageValidationHome(applicant, fsa);
			quotePageHome.quotePageErrorValidationHome(applicant, fsa);
			ThankYouPage thankYouPage = quotePageHome.enterQuotePage(applicant, fsa);
			thankYouPage.verifyThankYouPageContent(applicant, fsa);
		}
		fsa.assertAll();
	}
	// Test description: Validates the Home behavior for Error And Page Validation Scenario.
}
