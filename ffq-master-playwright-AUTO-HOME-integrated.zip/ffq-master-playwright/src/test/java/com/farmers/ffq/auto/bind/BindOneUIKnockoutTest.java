package com.farmers.ffq.auto.bind;

import com.farmers.ffq.BaseTest;

import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper.quoteFlow;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;

import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class BindOneUIKnockoutTest extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, suiteName = "lender knockout", groups = {FFQ_ONEUI, FFQ_BIND_VEHICLE_KNOCKOUT})
    public void bitMoreInfoAboutVehicleKnockOutValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.getVehicles().forEach(vehicle -> {
            vehicle.setUseVIN(false);
            vehicle.setVehicleVIN("ZFF75VFA1F0235711");
            vehicle.setOwnership("Owned");
        });

        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper(applicant.getStateCode().equals(MS)? quoteFlow.AGENT : quoteFlow.DEFAULT).navigateToAdditionalInfoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        AppStore retrieveQuoteResponseSessionStorage = additionalInfoPolicyStartDateOneUI.getSessionStorageAppStore();

        AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        if(additionalInfoVehicleSectionOneUI.vinNumberTextBoxElementList.count() > 0) {
            sendKeys(additionalInfoVehicleSectionOneUI.vinNumberTextBoxElementList.nth(0), applicant.getVehicles().get(0).getVehicleVIN());

            additionalInfoVehicleSectionOneUI.waitForSpinnerToBeGone();
            additionalInfoVehicleSectionOneUI.closeQualtricsPopUp();
            additionalInfoVehicleSectionOneUI.vinIsCorrectLink.click();
        }

        if(additionalInfoDriverSectionOneUI.driverLicenseNumberInputTextBoxes.count() > 0) {
            additionalInfoDriverSectionOneUI.enterDriverLicenseNumber(retrieveQuoteResponseSessionStorage);
            additionalInfoDriverSectionOneUI.enterMatureDriverSafetyCourseDate(retrieveQuoteResponseSessionStorage.getData().getLandingStateCode());
        }
        additionalInfoSignalEnrollmentSectionOneUI.verifySignalEnrollmentSection(retrieveQuoteResponseSessionStorage, true, fsa);
        additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();
        additionalInfoContinueToPaymentOneUI.waitForSpinnerToBeGone();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.verifyGeneralInfoOnBindKnockOut(retrieveQuoteResponseSessionStorage.getData().getAgentData(), fsa);
       // sa.assertTrue(knockoutInconveniencePage.verifyBitMoreInformationKOMessage(), "Unacceptable vehicle history Knockout");
        fsa.assertAll();
        additionalInfoContinueToPaymentOneUI.logInfoMessage(retrieveQuoteResponseSessionStorage.getData().getQuoteNumber());
        closeCurrentPage();
    }
    // Test description: Validates the Auto behavior for Bit More Info About Vehicle Knock Out Validation.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, suiteName = "lender knockout", groups = {FFQ_ONEUI, FFQ_BIND_LENDER_KNOCKOUT})
    public void otherLenderKnockOutValidation(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.getVehicles().forEach(vehicle -> {
                    vehicle.setUseVIN(true);
                    vehicle.setOwnership("Financed");
                }
        );
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper(applicant.getStateCode().equals(MS)? quoteFlow.AGENT : quoteFlow.DEFAULT).navigateToAdditionalInfoPage(applicant);
        AppStore retrieveQuoteResponseSessionStorage = additionalInfoPolicyStartDateOneUI.getSessionStorageAppStore();

        AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        additionalInfoVehicleSectionOneUI.enterOthersInLoanCompanyInputElement();

        additionalInfoDriverSectionOneUI.enterDriverLicenseNumber(retrieveQuoteResponseSessionStorage);
        additionalInfoDriverSectionOneUI.enterMatureDriverSafetyCourseDate(retrieveQuoteResponseSessionStorage.getData().getLandingStateCode());
        additionalInfoSignalEnrollmentSectionOneUI.verifySignalEnrollmentSection(retrieveQuoteResponseSessionStorage, true, fsa);

        additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();
        additionalInfoContinueToPaymentOneUI.waitForSpinnerToBeGone();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.verifyGeneralInfoOnBindKnockOut(retrieveQuoteResponseSessionStorage.getData().getAgentData(), fsa);
        fsa.assertTrue(knockoutInconveniencePage.verifyLenderKnockOutMessage(), "Unacceptable vehicle history Knockout");
        fsa.assertAll();
        additionalInfoContinueToPaymentOneUI.logInfoMessage(retrieveQuoteResponseSessionStorage.getData().getQuoteNumber());
        closeCurrentPage();
    }
    // Test description: Validates the Auto behavior for Other Lender Knock Out Validation.

}
