package com.farmers.ffq.auto;

import com.farmers.framework.AutomationFramework;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.InterstitialBundlePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class InterstitialBundlePageTests extends AutomationFramework {

	private static final String INTERSTITIAL_TEST = "Auto Interstitial";

	/**
	 * F97642
	 * Auto 717
	 * Validate whether interstitial page is displayed when user clicks on start quote for auto LOB for GA, OR states and user should able to select either Bundle or auto only.
	 * @throws Exception
	 */
    // As per the confirmation from Vlad, the GA state is unscoped from this test case, so we are validating the interstitial page for OR state only.
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
			attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {OR})}, groups = {FFQ_ONEUI, INTERSTITIAL_TEST})
	public void validateInterstitialPageIsDisplayed(AutoApplicant applicant) throws Exception {
		new AceAutoNavigationHelper().processLandingPage(applicant);
		InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
		FarmersSoftAssert softAssert = new FarmersSoftAssert();
		softAssert.assertTrue(interstitialBundlePage.isOnInterstitialBundlePage(), "User is not navigated to interstitial bundle page");
		interstitialBundlePage.validatePageContent(softAssert);
		softAssert.assertAll();
	}
	// Test description: Validates the Auto behavior for Validate Interstitial Page Is Displayed.

}
