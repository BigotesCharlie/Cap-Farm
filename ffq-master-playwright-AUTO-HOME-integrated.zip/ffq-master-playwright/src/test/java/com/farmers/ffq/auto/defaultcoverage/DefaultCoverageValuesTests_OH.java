package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;
import static com.farmers.ffq.utils.GlobalVariables.OH;

public class DefaultCoverageValuesTests_OH extends DefaultCoverageBaseTest {

     @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "OH_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 25 K50 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "OH_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 25 K50 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "OH_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 30 K60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "OH_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 30 K60 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "OH_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 35 K70 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "OH_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 35 K70 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "OH_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 50 K100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "OH_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 50 K100 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "OH_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 100 K200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "OH_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 100 K200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "OH_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 100 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "OH_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 100 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "OH_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 250 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "OH_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 250 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "OH_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 500 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "OH_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 500 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "OH_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = OH)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_OH_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "OH_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values OH 500 K UMBRELLA.
}

