package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class DefaultCoverageValuesTests_MD extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MD_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "MD_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MD 30 K60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MD_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "MD_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MD 50 K100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MD_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "MD_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MD 100 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MD_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "MD_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MD 250 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = MD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MD_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "MD_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MD 500 K500 K NO UMBRELLA.

}
