package com.farmers.ffq;

import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.auto.pages.DriverMismatchPage;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.auto.pages.bw.BwCongratulationsPage;
import com.farmers.ffq.auto.pages.bw.BwDocuSignPage;
import com.farmers.ffq.auto.pages.bw.BwPaymentSummaryPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.PaymentSelectionBasePage;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import net.datafaker.Faker;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage.MONTHLY_AUTO_PAY_BANK;
import static com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage.MONTHLY_AUTO_PAY_CARD;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.MONTHLY_DIRECT_BILL;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

import com.farmers.ffq.integration.RallyListener;
import org.testng.annotations.Listeners;

@Listeners(RallyListener.class)
public class BaseTest extends AutomationFramework {

    public void updateApplicantDataToAvoidPossibleBw(AutoApplicant applicant) {
        applicant.setIncidents(Collections.emptyList());
        applicant.setHaveAccidentOrViolations(false);
        applicant.setFinancialFiling(NO);
        applicant.getAdditionalDrivers().forEach(driver -> {
            driver.setFinancialFiling(NO);
            driver.setAnyIncident(false);
            driver.setLicenseToDriveInUSA(YES);
        });

        applicant.getVehicles().forEach(vehicle -> {
            vehicle.setVehicleUsage("Personal");
            vehicle.setParkInResidentAddress(true);
        });

    }

    protected static void randomizeApplicantPersonalData(AutoApplicant applicant) {
        Faker faker = new Faker();
        String firstName = faker.name().firstName();
        applicant.setFirstName(firstName);
        String lastName = RandomStringUtils.randomAlphabetic(1).toUpperCase() + RandomStringUtils.randomAlphabetic(6).toLowerCase();
        lastName = StringUtils.capitalize(lastName);
        applicant.setLastName(lastName);
        applicant.setPhoneNumber(faker.phoneNumber().phoneNumber().replace("[^\\d.]", ""));
        int age = applicant.getAge();
        int month = ThreadLocalRandom.current().nextInt(1, 13);
        int year = LocalDate.now().minusYears(age).getYear();
        int day = ThreadLocalRandom.current().nextInt(1, LocalDate.of(year, month, 1).lengthOfMonth() + 1);
        String formattedDate = String.format("%02d%02d%04d", month, day, year);
        applicant.setDateOfBirth(formattedDate);
        String emailId = (firstName + "_" + lastName + "@farmers.testinator.com").replace(SPACE, EMPTY_STRING);
        applicant.setEmail(emailId);

    }

    protected void bwSpecificDataSetUp(AutoApplicant applicant) throws Exception {

        if (!new AutoBasePage().isBDQFlowEnabled() && Arrays.asList(OR,NC).contains(applicant.getStateCode())) {
            applicant.setFinancialFiling(SR_22);
        }

        //applicant.setFirstAgeForeignDriverLicense(18);
        if(!applicant.getStateCode().equals(NC)) {
            applicant.setContinuosInsurancePeriod("< 6 Months");
        }

        String testScenario = applicant.getTestScenario();
        if (!testScenario.contains("BW")) {
            applicant.setTestScenario("BW -> " + testScenario);
        }

        for (Vehicle vehicle : applicant.getVehicles()) {
            vehicle.setUseVIN(true);
        }

        if (!Arrays.asList(IA, NE).contains(applicant.getStateCode())) {
            updateLastNameForBristolWest(applicant);
        }

    }

    protected static void updateLastNameForBristolWest(AutoApplicant applicant) {
        applicant.setLastName("Threeoabaa");
//        String stateCode = applicant.getStateCode();
//        if (Arrays.asList(AZ, CO, FL, GA, ID, IL, IN, MA, MD, MI, MS, MT, NE, NJ, NM, OH, OR, PA, TX, VA).contains(stateCode)) {
//            // AZ, IL, OH, OR, UT, OK, MO, AR, TX, IN- BWTESTH, BWTESTI, THREEOABAA
//            applicant.setLastName("Threeoabaa");
//        } else if (stateCode.equals(MT)) {
//            applicant.setLastName("Bwtestk");
//        } else if (Arrays.asList(PA, KS).contains(stateCode)) {
//            //PA & KS- THREEIIIAAAA, THREEIIIABAA, THREEIIINMUM
//            applicant.setLastName("Threeiiiaaaa");
//        } else if (Arrays.asList(OK, KY).contains(stateCode)) {
//            applicant.setLastName("Bwtesth");
//        } else if(stateCode.equals(WA)) {
//            applicant.setFirstName("Lienholder");
//            applicant.setLastName("Bwtesto");
//        } else if(stateCode.equals(MT)) {
//            applicant.setLastName(RandomStringUtils.randomAlphabetic(1).toUpperCase() + RandomStringUtils.randomAlphabetic(5).toLowerCase() + "mt");
//        } else {
//            applicant.setLastName("Bwtesti");
//        }
        /*
        AZ, IL, OH, OR, UT, OK, MO, AR, TX, IN- BWTESTH, BWTESTI, THREEOABAA
        WY - BWTESTD
        IA - BWTESTH
        IA - BWTESTI
        IA - BWTESTJ
        PA & KS- THREEIIIAAAA, THREEIIIABAA, THREEIIINMUM

         */
    }

    protected SqlAdditionalDriver getRandomAdditionalDriver() {
        Faker faker = new Faker();
        SqlAdditionalDriver driver = new SqlAdditionalDriver();
        driver.setFirstName(faker.name().firstName());
        driver.setLastName(faker.name().lastName());
        driver.setGender(RandomUtils.nextBoolean() ? "Male" : "Female");
        driver.setLicenseToDriveInUSA(YES);
        driver.setDateOfBirth("1209" + LocalDate.now().minusYears(25).getYear());
        driver.setCompletedDriversSafetyCourse(false);
        driver.setFinancialFiling(NO);
        driver.setRelationshipToApplicant(SON);
        return driver;
    }

    protected String getRandomLastName() {
        String lastName = new Faker().name().lastName().replaceAll("[^a-zA-Z]+", "").toLowerCase();
        lastName = StringUtils.capitalize(lastName);
        return lastName;
    }

    protected int getRandomAge(int ageToExclude) {
        int newAge = RandomUtils.nextInt(19, 55);
        //make sure new age is not as current
        while (newAge == ageToExclude) {
            newAge = RandomUtils.nextInt(19, 55);
        }
        return newAge;
    }

    protected void updatePersonalInfoForProd(AutoApplicant applicant) throws Exception {
        if (!new AutoBasePage().isProdEnvironment()) {
            return;
        }
        applicant.setFirstName(PRODUCTION_APPLICANT_FIRST_NAME);
        applicant.setLastName(PRODUCTION_APPLICANT_LAST_NAME);
        applicant.setEmail(PRODUCTION_APPLICANT_EMAIL);
    }

    public void completePurchase(String paymentPlanOption, PaymentMethods paymentMethods, boolean clickPurchaseButton, FarmersSoftAssert fsa) throws Exception {
        PaymentSelectionBasePage paymentSelectionBasePage = new PaymentSelectionBasePage();

        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        AppStore sessionStorageAppStore = paymentSelectionBasePage.getSessionStorageAppStore();

        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();

        if(bwPaymentSummaryPage.isOnBristolWest()) {
            processBwDocuSignAndPayments(getRandomPaymentMethodForBW(), clickPurchaseButton);
        } else {
            ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
            consolidatedPaymentPage.processConsolidatedPaymentPage(paymentPlanOption, paymentMethods, clickPurchaseButton);
        }
        policyPaymentBasePage.logInfoMessage(sessionStorageAppStore.getData().getQuoteNumber().trim());
        if (clickPurchaseButton) {
        	// wait is to make sure we are getting esignature files ready
        	waitForUiSettled();
        	echeckout(fsa);
        }
    }

	public void echeckout(FarmersSoftAssert fsa) throws Exception {
		EcheckoutSuccessfulPageOneUI echeckoutSuccessfulPageOneUI = new EcheckoutSuccessfulPageOneUI();
        echeckoutSuccessfulPageOneUI.waitForSpinnerToBeGone();
        if (echeckoutSuccessfulPageOneUI.isSignElectronicallyPresent()) {
            fsa.assertTrue(echeckoutSuccessfulPageOneUI.isSignElectronicallyPresent(), "Sign electronically header present");
            echeckoutSuccessfulPageOneUI.signDocuments();
        } else if (new KnockoutInconveniencePage().isOnInconveniencePage()) {
            Log.info("User landed on the inconvenience page as the bind call was not successful, OR 'Complete purchase' button was not clicked due to ADPF data please check the db logs to see the failure details", true);
        }
	}

    protected void getE2EBwBind(AutoApplicant applicant, String paymentMethod, boolean callBind, boolean isQuoteCustomized) throws Exception {
        applicant.setEmail(RandomStringUtils.randomAlphabetic(7) + applicant.getApplicantId() + "@farmers.testinator.com");
        updateLastNameForBristolWest(applicant);
        //this is for not to get adpf data
        if (applicant.getApplicantId() == 29) {
            applicant.setLastName("Threeoabaa");
            applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));
        }
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        boolean prodEnvironment = aceAutoNavigationHelper.isProdEnvironment();

        if(prodEnvironment) {
        	updatePersonalInfoForProd(applicant);
        	applicant.setLastName("Bwtesth");
        } else {
        	applicant.setTestScenario("BW->" + applicant.getTestScenario());
        }
        applicant.getDiscounts().get(0).setSignalSignup(false);
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);

        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User is on the BW quote summary page", true);
        if (isQuoteCustomized) {
            quoteSummaryAutoPage.updateLiabilityAndCustomizeForBW();
            quoteSummaryAutoPage.closeAdjustmentDialogIfPresent();
            quoteSummaryAutoPage.updateVehicleCoverageAndCustomizeForBW();
            quoteSummaryAutoPage.closeAdjustmentDialogIfPresent();
        }
        navigateFromQuotePageToBindCongratsPage(paymentMethod, callBind, quoteSummaryAutoPage, prodEnvironment);

    }

    public void navigateFromQuotePageToBindCongratsPage(String paymentMethod, boolean callBind, QuoteSummaryAutoPage quoteSummaryAutoPage, boolean prodEnvironment) throws Exception {
        navigateFromQuoteSummaryPageToPaymentSelectionPage();
        processBwDocuSignAndPayments(paymentMethod, callBind);
    }

    protected void navigateFromQuoteSummaryPageToPaymentSelectionPage() throws Exception {
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        quoteSummaryAutoPage.clickOnStartCheckoutButton();
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        testStepAssert(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User is on the additional info page", true);
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
        DriverMismatchPage driverMismatchPage = new DriverMismatchPage();
        if (driverMismatchPage.isOnDriverMismatchPage()) {
            driverMismatchPage.randomlySelectReasonForNonInclusion();
            driverMismatchPage.clickContinueButton();
            driverMismatchPage.waitForSpinnerToBeGone();
        }
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        bwPaymentSummaryPage.closeRateChangePopUpIfPresent();
        testStepAssert(autoPolicyPaymentBasePage.isOnContinueToPaymentPage() || bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User is successfully on the Payment summary page", true);
    }

    protected void getE2EBwBind(ADPFApplicant applicant, String paymentMethod, boolean callBind, boolean isQuoteCustomized) throws Exception {
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        processBwDocuSignAndPayments(paymentMethod, callBind);
    }

    protected  void processBwDocuSignAndPayments(String paymentMethod, boolean callBind) throws Exception {
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        bwPaymentSummaryPage.isOnBwPaymentSummaryPage();
        bwPaymentSummaryPage.closeRateChangePopUpIfPresent();

        if(Property.getTestProperty("environment").equalsIgnoreCase("prod")) {
            Log.info("Bind call is disabled due to PROD env");
            callBind = false;
        }

        String landingStateCode = bwPaymentSummaryPage.getSessionStorageAppStore().getData().getLandingStateCode();
        if(landingStateCode.equals(KY) && paymentMethod.equals(MONTHLY_DIRECT_BILL)) {
            paymentMethod = PAY_IN_FULL;
            Log.info("Updating the payment method from direct bill to pay in full as direct bill is not available for KY state");
        }
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        List<String> theListOfEligiblePaymentMethods = autoPolicyPaymentBasePage.getTheListOfEligiblePaymentMethods();

        if(!theListOfEligiblePaymentMethods.contains(paymentMethod)) {
            Collections.shuffle(theListOfEligiblePaymentMethods);
            Log.info("The selected payment method: " + paymentMethod + " is not available for this quote, selecting : " + theListOfEligiblePaymentMethods.get(0) + " instead");
            paymentMethod = theListOfEligiblePaymentMethods.get(0);
        }
        selectPaymentMethodFillOutDocusignAndAddPaymentMethod(paymentMethod);
        if (callBind) {
            autoPolicyPaymentBasePage.clickCompletePurchaseButton();
            BwCongratulationsPage bwCongratulationsPage = new BwCongratulationsPage();
            testStepAssert(bwCongratulationsPage.isOnBwCongratsPage(), "Congratulation page is reached", true);
            bwCongratulationsPage.registerUserForAnAccount();
        }
    }

    protected void selectPaymentMethodFillOutDocusignAndAddPaymentMethod(String paymentMethod) throws Exception {
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        bwPaymentSummaryPage.processBwPaymentSummaryPage(paymentMethod);
        BwDocuSignPage bwDocuSignPage = new BwDocuSignPage();
        bwDocuSignPage.signDocuments();
        bwPaymentSummaryPage.addBwPaymentMethod(paymentMethod);
        waitForUiSettled();
        testStep("Payment method is added", true);
    }

    protected String getRandomPaymentMethodForBW() {
        List<String> paymentMethods = new ArrayList<>(Arrays.asList(PAY_IN_FULL, MONTHLY_AUTO_PAY_BANK, MONTHLY_DIRECT_BILL, MONTHLY_AUTO_PAY_CARD));
        Collections.shuffle(paymentMethods);
        return paymentMethods.get(0);
    }

    protected String getRandomBdqFlow(String stateCode) throws Exception {
        List<String> list = new ArrayList<>(Arrays.asList(BW_MARKETING_ID_FLOW, BW_CLICK_TO_BUY_FULL_FLOW, BW_ORGANIC_FLOW, BW_CLICK_TO_BUY_LITE_FLOW));
        AutoDataProviders autoDataProviders = new AutoDataProviders();
        List<BDQFlowData> bdqData = autoDataProviders.getBdqData();
        List<String> statesWithFullUrlAvailable = bdqData.stream().filter(each -> !StringUtils.isEmpty(each.getBdqFullUrl())).map(each -> each.getStateAbb()).collect(Collectors.toList());
        if(!statesWithFullUrlAvailable.contains(stateCode)) {
            list.remove(BW_CLICK_TO_BUY_FULL_FLOW);
        }
        Collections.shuffle(list);
        String selectedBdqFlow = list.get(0);
        Log.info("Selected bdq flow is : " + selectedBdqFlow);
        return selectedBdqFlow;
    }

    protected boolean switchTestToBDQIfNeeded(AutoApplicant applicant) throws Exception {
    	boolean useBDQ = false;
        if (new AutoBasePage().isBDQFlowEnabled()) {
            updateLastNameForBristolWest(applicant);
            applicant.setTestScenario(getRandomBdqFlow(applicant.getStateCode()));
            useBDQ = true;
        }
        return useBDQ;
    }

    protected void setApplicantPriorBiConditionRandomly(AutoApplicant applicant) {
        List<String> randomCurrentlyInsuredStatus = new ArrayList<>(Arrays.asList(NEVER_INSURED, EXPIRED, NOT_REQUIRED, DEPLOYED));
        if(applicant.getStateCode().equals(WA)) {
            randomCurrentlyInsuredStatus.remove(DEPLOYED);
            randomCurrentlyInsuredStatus.remove(NOT_REQUIRED);
        }
        Collections.shuffle(randomCurrentlyInsuredStatus);
        String currentInsuranceStatus = randomCurrentlyInsuredStatus.get(0);
        applicant.setCurrentlyInsuredStatus(currentInsuranceStatus);
        if(currentInsuranceStatus.equals(EXPIRED)){
            applicant.setContinuosInsurancePeriod("< 6 Months");
        }
    }

}
