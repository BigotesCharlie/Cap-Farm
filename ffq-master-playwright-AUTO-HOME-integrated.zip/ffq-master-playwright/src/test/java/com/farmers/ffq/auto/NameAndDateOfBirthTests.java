package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.AutoEnterAddressPage;
import com.farmers.ffq.auto.pages.NameAndDobPage;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.WhoShouldWeInsurePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class NameAndDateOfBirthTests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})
    public void testErrorForMessageCharLimits(AutoApplicant applicant) throws Exception {

        NameAndDobPage nameAndDobPage = new AceAutoNavigationHelper().navigateToNameAndDobPage(applicant);

        //validate First/Last name char limit - 15 char and 20 char max respectively
        // date is incorrect because trying to stop to proceed to the next page
        nameAndDobPage.filloutApplicantFormWithValues("MoreThanFifteenChars", "MoreThanTwentyCharacters", "09/09/1600");

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(nameAndDobPage.isFirstNameCharLimitCorrect());
        fsa.assertTrue(nameAndDobPage.isLastNameCharLimitCorrect());
        fsa.assertAll();

    }
    // Test description: Validates the Auto behavior for Test Error For Message Char Limits.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})
    public void testErrorMessageNameAndDobOneUIAutoQuote(AutoApplicant applicant) throws Exception {

        NameAndDobPage nameAndDobPage = new AceAutoNavigationHelper().navigateToNameAndDobPage(applicant);

        //attempting to skip field entering
        nameAndDobPage.filloutApplicantFormWithNoInput();
        nameAndDobPage.validateErrorMessageForNoInput();

        nameAndDobPage.filloutApplicantFormWithIncorrectInput();
        nameAndDobPage.validateErrorMessageForIncorrectInput();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        // invalidate condition is age<=15 and age>=99
        fsa.assertTrue(nameAndDobPage.areInvalidDatesTriggerErrorMessage(applicant));
        fsa.assertAll();

    }
    // Test description: Validates the Auto behavior for Test Error Message Name And Dob One UIAuto Quote.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})
    public void testNewTabForEnterprisePrivacyStatement(AutoApplicant applicant) throws Exception {

        NameAndDobPage nameAndDobPage = new AceAutoNavigationHelper().navigateToNameAndDobPage(applicant);

        nameAndDobPage.clickOnPersonalInformationUseLink();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(nameAndDobPage.isPrivacyStatementTabTitleCorrect(), "Privay statement title validation");
        fsa.assertTrue(nameAndDobPage.isPrivacyStatementPageHeaderExist(), "Privacy statement page header validation");
        fsa.assertAll();

    }
    // Test description: Validates the Auto behavior for Test New Tab For Enterprise Privacy Statement.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})
    public void testNotAllowedCharactersOnDOBFields(AutoApplicant applicant) throws Exception {
        NameAndDobPage nameAndDobPage = new AceAutoNavigationHelper().navigateToNameAndDobPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(nameAndDobPage.areNotAllowedNumericCharactersNotAcceptedOnDOBField());
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Not Allowed Characters On DOBFields.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})
    public void testNotAllowedCharactersOnFirstNameAndLastNameFields(AutoApplicant applicant) throws Exception {
        NameAndDobPage nameAndDobPage = new AceAutoNavigationHelper().navigateToNameAndDobPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        fsa.assertTrue(nameAndDobPage.areNotAllowedSpecialCharactersNotAcceptedOnFirstNameField());
        fsa.assertTrue(nameAndDobPage.areNotAllowedSpecialCharactersNotAcceptedOnLastNameField());
        fsa.assertTrue(nameAndDobPage.areNotAllowedNumericCharactersNotAcceptedOnFirstNameField());
        fsa.assertTrue(nameAndDobPage.areNotAllowedNumericCharactersNotAcceptedOnLastNameField());

        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Not Allowed Characters On First Name And Last Name Fields.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})
    public void testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh(AutoApplicant applicant) throws Exception {
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();

        // navigate back to NameAndDOB page and test if input data is retained
        autoEnterAddressPage.navigateBackToPreviousPage();
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        fsa.assertTrue(nameAndDobPage.isNameAndDOBDataSaved(applicant));

        // refresh the page when user is on NameAndDob page
        nameAndDobPage.refreshPage();
        fsa.assertTrue(nameAndDobPage.isNameAndDOBDataSaved(applicant));
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Personal Info Saved And Displayed On Navigation And Refresh.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {FL})})
    public void testQuoteCreationRatingAndFieldUpdateReset(AutoApplicant applicant) throws Exception {
        new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        nameAndDobPage.clickEnterInfoNavigationBarStepper();
        nameAndDobPage.filloutApplicantFormWithValues("UpdatedName", "UpdatedLastName", "09/09/1986");

        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(autoEnterAddressPage.isAddressInputFieldEmpty());
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Quote Creation Rating And Field Update Reset.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {NJ,FL})})
    public void testPersonalInfoPageTitleAndDisclaimers(AutoApplicant applicant) throws Exception {
    	NameAndDobPage nameAndDobPage = new AceAutoNavigationHelper().navigateToNameAndDobPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        nameAndDobPage.verifyPageTitle(fsa);
        nameAndDobPage.validateDisclaimers(fsa, true);
    	fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Personal Info Page Title And Disclaimers.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, enabled = false)
    public void testNotAllowedCharactersOnDOBFields_BDQ(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(getRandomBdqFlow(applicant.getStateCode()) + "-> " + applicant.getTestScenario());
        NameAndDobPage nameAndDobPage = new AceAutoNavigationHelper().navigateToNameAndDobPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(nameAndDobPage.areNotAllowedNumericCharactersNotAcceptedOnDOBField());
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Not Allowed Characters On DOBFields BDQ.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, enabled = false)
    public void testNotAllowedCharactersOnFirstNameAndLastNameFields_BDQ(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(getRandomBdqFlow(applicant.getStateCode()) + "-> " + applicant.getTestScenario());
        NameAndDobPage nameAndDobPage = new AceAutoNavigationHelper().navigateToNameAndDobPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(nameAndDobPage.areNotAllowedSpecialCharactersNotAcceptedOnFirstNameField());
        fsa.assertTrue(nameAndDobPage.areNotAllowedSpecialCharactersNotAcceptedOnLastNameField());
        fsa.assertTrue(nameAndDobPage.areNotAllowedNumericCharactersNotAcceptedOnFirstNameField());
        fsa.assertTrue(nameAndDobPage.areNotAllowedNumericCharactersNotAcceptedOnLastNameField());

        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Not Allowed Characters On First Name And Last Name Fields BDQ.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, enabled = false)
    public void testErrorForMessageCharLimits_BDQ(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(getRandomBdqFlow(applicant.getStateCode()) + "-> " + applicant.getTestScenario());

        NameAndDobPage nameAndDobPage = new AceAutoNavigationHelper().navigateToNameAndDobPage(applicant);

        //validate First/Last name char limit - 15 char and 20 char max respectively
        // date is incorrect because trying to stop to proceed to the next page
        nameAndDobPage.filloutApplicantFormWithValues("MoreThanFifteenChars", "MoreThanTwentyCharacters", "09/09/1600");

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(nameAndDobPage.isFirstNameCharLimitCorrect());
        fsa.assertTrue(nameAndDobPage.isLastNameCharLimitCorrect());

        fsa.assertAll();

    }
    // Test description: Validates the Auto behavior for Test Error For Message Char Limits BDQ.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, enabled = false)
    public void testErrorMessageNameAndDobOneUIAutoQuote_BDQ(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(getRandomBdqFlow(applicant.getStateCode()) + "-> " + applicant.getTestScenario());

        NameAndDobPage nameAndDobPage = new AceAutoNavigationHelper().navigateToNameAndDobPage(applicant);

        //attempting to skip field entering
        nameAndDobPage.filloutApplicantFormWithNoInput();
        nameAndDobPage.validateErrorMessageForNoInput();

        nameAndDobPage.filloutApplicantFormWithIncorrectInput();
        nameAndDobPage.validateErrorMessageForIncorrectInput();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        // invalidate condition is age<=15 and age>=99
        fsa.assertTrue(nameAndDobPage.areInvalidDatesTriggerErrorMessage(applicant));
        fsa.assertAll();

    }
    // Test description: Validates the Auto behavior for Test Error Message Name And Dob One UIAuto Quote BDQ.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, enabled = false)
    public void testNewTabForEnterprisePrivacyStatement_BDQ(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(getRandomBdqFlow(applicant.getStateCode()) + "-> " + applicant.getTestScenario());

        NameAndDobPage nameAndDobPage = new AceAutoNavigationHelper().navigateToNameAndDobPage(applicant);

        nameAndDobPage.clickOnPersonalInformationUseLink();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(nameAndDobPage.isPrivacyStatementTabTitleCorrect());
        fsa.assertTrue(nameAndDobPage.isPrivacyStatementPageHeaderExist());
        fsa.assertAll();

    }
    // Test description: Validates the Auto behavior for Test New Tab For Enterprise Privacy Statement BDQ.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, enabled = false)
    public void testPersonalInfoSavedAndDisplayedOnNavigationAndRefresh_BDQ(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(getRandomBdqFlow(applicant.getStateCode()) + "-> " + applicant.getTestScenario());
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();

        // navigate back to NameAndDOB page and test if input data is retained
        autoEnterAddressPage.navigateBackToPreviousPage();
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        fsa.assertTrue(nameAndDobPage.isNameAndDOBDataSaved(applicant));

        // refresh the page when user is on NameAndDob page
        nameAndDobPage.refreshPage();
        fsa.assertTrue(nameAndDobPage.isNameAndDOBDataSaved(applicant));
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Personal Info Saved And Displayed On Navigation And Refresh BDQ.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {FL})}, enabled = false)
    public void testQuoteCreationRatingAndFieldUpdateReset_BDQ(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(getRandomBdqFlow(applicant.getStateCode()) + "-> " + applicant.getTestScenario());

        new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        nameAndDobPage.clickEnterInfoNavigationBarStepper();
        nameAndDobPage.filloutApplicantFormWithValues("UpdatedName", "UpdatedLastName", "09/09/1986");

        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(autoEnterAddressPage.isAddressInputFieldEmpty());
        autoEnterAddressPage.fillOutAddressPage(applicant);
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        fsa.assertTrue(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on the who should we insure page");
        whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
        whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
        whoShouldWeInsurePage.clickContinueButton();
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Quote Creation Rating And Field Update Reset BDQ.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {NAME_AND_DOB_ONEUI, FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")})
    public void testPrivacyPolicy(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        NameAndDobPage NameAndDobPage = aceAutoNavigationHelper.navigateToNameAndDobPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        NameAndDobPage.clickOnPrivacyPolicyLink();
        fsa.assertTrue(NameAndDobPage.isPrivacyCenterTabTitleCorrect(), "Privacy center title validation");
        fsa.assertTrue(NameAndDobPage.isPrivacyCenterPageHeaderExist(), "Privacy center header validation");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Privacy Policy.
}
