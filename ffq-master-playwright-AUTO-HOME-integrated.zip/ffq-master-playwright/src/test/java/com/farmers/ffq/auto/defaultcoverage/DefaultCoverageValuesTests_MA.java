package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class DefaultCoverageValuesTests_MA extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_20K_40K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=No", "MA_20K_40K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 20 K 40 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_25K_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "MA_25K_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 25 K 50 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_30K_60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "MA_30K_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 30 K 60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_35K_80K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=No", "MA_35K_80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 35 K 80 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_50K_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "MA_50K_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 50 K 100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_100K_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "MA_100K_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 100 K 200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_100K_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "MA_100K_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 100 K 300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_250K_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "MA_250K_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 250 K 500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_500K_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "MA_500K_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 500 K 500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_500K_1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "MA_500K_1M");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 500 K 1 M NO UMBRELLA.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_45K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=No", "MA_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 45 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "MA_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 75 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "MA_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "MA_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "MA_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = MA), @CustomAttribute(name = FILTER, values = "applicantId=13")}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_MA_1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "MA_1M");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values MA 1 M NO UMBRELLA.


}
