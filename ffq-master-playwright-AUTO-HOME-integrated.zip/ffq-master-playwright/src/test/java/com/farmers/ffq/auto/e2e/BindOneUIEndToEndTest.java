package com.farmers.ffq.auto.e2e;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.auto.pages.bw.BwCongratulationsPage;
import com.farmers.ffq.auto.pages.bw.BwDocuSignPage;
import com.farmers.ffq.auto.pages.bw.BwPaymentSummaryPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;

import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.apache.commons.lang3.RandomUtils;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class BindOneUIEndToEndTest extends BaseTest {
    private static final String BRISTOLWEST_SCENARIO_NAME = "BristolWest E2E";
    private static final String BRISTOLWEST_DIAGNOSTIC_LABEL_PREFIX = "BristolWest-E2E";

    @Test(groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void bristolWestE2EDeterministic() throws Exception {
        AutoApplicant applicant = buildBristolWestDeterministicApplicant();
        String executionId = String.valueOf(System.currentTimeMillis());
        String diagnosticLabel = BRISTOLWEST_DIAGNOSTIC_LABEL_PREFIX + "-" + executionId;
        logBristolWestExecutionHeader(executionId, applicant);
        Log.info("[BristolWest E2E][5%] Preparing deterministic Yvonne Fisher execution");
        AutoBindE2EDiagnostics.checkpoint(diagnosticLabel + "-01-landing");

        navigateToPaymentSelectionWithEvidence(applicant, diagnosticLabel);
        completeBristolWestDeterministicPurchase(applicant, diagnosticLabel);
    }
    // Test description: Validates the deterministic BristolWest Auto E2E bind flow through successful purchase.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void bindOneUIE2EdWithPifBankAccountAndServiceVirtualizationData(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));
        navigateToPaymentSelectionWithEvidence(applicant, "pif-bank-sv");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchaseWithEvidence(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true, fsa, "pif-bank-sv");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Bind One UIE2 Ed With Pif Bank Account And Service Virtualization Data.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void bindOneUIE2EdWithMonthlyAutopayBankAccountAndServiceVirtualizationData(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));
        navigateToPaymentSelectionWithEvidence(applicant, "monthly-bank-sv");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchaseWithEvidence(MONTHLY_AUTOPAY, PaymentMethods.BANK_ACCOUNT_1, true, fsa, "monthly-bank-sv");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Bind One UIE2 Ed With Monthly Autopay Bank Account And Service Virtualization Data.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void bindOneUIE2EdWithPifDebitCardAndServiceVirtualizationData(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));
        navigateToPaymentSelectionWithEvidence(applicant, "pif-debit-sv");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchaseWithEvidence(PAY_IN_FULL, PaymentMethods.VISA_DEBIT_CARD_1, true, fsa, "pif-debit-sv");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Bind One UIE2 Ed With Pif Debit Card And Service Virtualization Data.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void bindOneUIE2EdWithMonthlyAutopayDebitCardAndServiceVirtualizationData(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));
        navigateToPaymentSelectionWithEvidence(applicant, "monthly-debit-sv");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchaseWithEvidence(MONTHLY_AUTOPAY, PaymentMethods.VISA_DEBIT_CARD_1, true, fsa, "monthly-debit-sv");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Bind One UIE2 Ed With Monthly Autopay Debit Card And Service Virtualization Data.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void bindOneUIE2EdWithPifCreditCardAndServiceVirtualizationData(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));
        navigateToPaymentSelectionWithEvidence(applicant, "pif-credit-sv");
        List<PaymentMethods> availableCreditCards = Arrays.asList(PaymentMethods.VISA_CREDIT_CARD_1, PaymentMethods.AMEX_CREDIT_CARD_1, PaymentMethods.MASTERCARD_CREDIT_CARD_1);
        PaymentMethods randomPaymentMethod = availableCreditCards.get(new Random().nextInt(availableCreditCards.size()));
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchaseWithEvidence(PAY_IN_FULL, randomPaymentMethod, true, fsa, "pif-credit-sv");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Bind One UIE2 Ed With Pif Credit Card And Service Virtualization Data.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void bindOneUIE2EdWithMonthlyAutopayCreditCardAndServiceVirtualizationData(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        AutoDataProviders.updateApplicantsForBind(Arrays.asList(applicant));
        navigateToPaymentSelectionWithEvidence(applicant, "monthly-credit-sv");

        List<PaymentMethods> availableCreditCards = Arrays.asList(PaymentMethods.VISA_CREDIT_CARD_1, PaymentMethods.AMEX_CREDIT_CARD_1, PaymentMethods.MASTERCARD_CREDIT_CARD_1);
        PaymentMethods randomPaymentMethod = availableCreditCards.get(new Random().nextInt(availableCreditCards.size()));
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchaseWithEvidence(MONTHLY_AUTOPAY, randomPaymentMethod, true, fsa, "monthly-credit-sv");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Bind One UIE2 Ed With Monthly Autopay Credit Card And Service Virtualization Data.

    @Test(dataProvider = AutoDataProviders.BIND_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ACE_AUTO_E2E, FFQ_BIND_WITH_ADPFDATA_ENDTOEND})
    public void bindOneUIE2EndWithDebitCardAndAdpfData(ADPFApplicant applicant) throws Exception {
        navigateToPaymentSelectionWithEvidence(applicant, "pif-debit-adpf");
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchaseWithEvidence(PAY_IN_FULL, PaymentMethods.VISA_DEBIT_CARD_1, false, fsa, "pif-debit-adpf");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Bind One UIE2 End With Debit Card And Adpf Data.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, KY, NC, NV, UT, WA}), @CustomAttribute(name = FILTER, values = "applicantId=5")}, dataProviderClass = AutoDataProviders.class, groups = {SMOKE_ACE, FFQ_ACE_AUTO_E2E, FFQ_BIND_ENDTOEND})
    public void validateBindWithDLObtainedFromDifferentState(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.getVehicles().forEach(each -> {
            each.setParkInResidentAddress(true);
            each.setVehicleUsage("Personal");
        });
        applicant.setTestScenario(DIFFERENT_STATE_DL + applicant.getTestScenario());
        applicant.setLastName("Bailey");
        new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        AutoBindE2EDiagnostics.checkpoint("different-state-dl-additional-info");

        AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        additionalInfoVehicleSectionOneUI.fillOutVehicleSectionAlternative();
        additionalInfoVehicleSectionOneUI.closeQualtricsPopUp();
        // enter mature driver date
        additionalInfoDriverSectionOneUI.enterMatureDriverSafetyCourseDate(additionalInfoDriverSectionOneUI.getSessionStorageAppStore().getData().getLandingStateCode());

        // select a different state for dl
        List<String> stateCodes = listOfAllStates();
        stateCodes.removeIf(each -> Arrays.asList(applicant.getStateCode(), NY, NJ).contains(each));
        Collections.shuffle(stateCodes);

        additionalInfoDriverSectionOneUI.enterDriverLicenseNumber(stateCodes.get(0));
        additionalInfoDriverSectionOneUI.fillOutDriverInfoSectionForRace();
        // fill out signal section
        additionalInfoSignalEnrollmentSectionOneUI.fillOutSignalEnrollmentSection();
        additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();

        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        DriverMismatchPage driverMismatchPage = new DriverMismatchPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
            BristolWestAdditionalDiscountsPage additionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
            if (additionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
                additionalDiscountsPage.clickContinue();
            }
            QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
            if(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            	quoteSummaryAutoPage.clickOnStartCheckoutButton();
            	quoteSummaryAutoPage.waitForSpinnerToBeGone();
            }
            AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
            if (additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage()) {
            	additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
            }
        }
        if (driverMismatchPage.isOnDriverMismatchPage()) {
        	driverMismatchPage.dontIncludeAnyMismatchedDriversInQuote();
        	driverMismatchPage.clickContinueButton();
        	driverMismatchPage.waitForSpinnerToBeGone();
        }
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchaseWithEvidence(MONTHLY_AUTOPAY, PaymentMethods.BANK_ACCOUNT_1, true, fsa, "different-state-dl");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Bind With DLObtained From Different State.

    /**
     * F87642
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")},
            dataProviderClass = AutoDataProviders.class, groups = {QUOTE_SUMMARY, FFQ_ONEUI})
    public void validate_bind_disabled_when_fasttrackIndicator_false_otherwise_continue_with_bind(AutoApplicant applicant) throws Exception {
        boolean fastTrackVinProvided = RandomUtils.nextBoolean();
        String updatedTestScenario = (fastTrackVinProvided ? EMPTY_STRING : NO_FAST_TRACK) + applicant.getTestScenario();
        applicant.setTestScenario(updatedTestScenario);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
        AutoBindE2EDiagnostics.checkpoint("fasttrack-quote-summary");
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        AutoRateQuoteResponseBean autoRateQuote = new ApiHelper().getAutoRateQuote(consolidatedPaymentPage.getSessionStorageAppStore().getData().getQuoteNumber());
        AutoRateQuoteResponseBean.AutoRateQuoteResponseBean__1.RateQuoteResponse rateQuoteResponse = autoRateQuote.getAutoRateQuoteResponseBean().getRateQuoteResponses().get(0);
        boolean bindEnabled = rateQuoteResponse.getBuyEnableInd().equals("Y");
        boolean fastTrackIndicator = rateQuoteResponse.getIsFastTrackInd().equals("true");
        quoteSummaryAutoPage.clickOnStartCheckoutButton();
        if (!bindEnabled || !fastTrackIndicator) {
            ThankYouPageAce thankYouPageAce = new ThankYouPageAce();
            softAssert.assertTrue(thankYouPageAce.isOnThankYouPage(), "User should be on the thank you page with non fast track vin");
        } else {
            AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
            testStepAssert(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "Additional info page reached", true);
            additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
            AutoBindE2EDiagnostics.checkpoint("fasttrack-after-additional-info");
            testStepAssert(consolidatedPaymentPage.isOnConsolidatedPaymentPage(), "Consolidated payment page reached", true);
            completePurchaseWithEvidence(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true, softAssert, "fasttrack");
        }

    }
    // Test description: Validates the Auto behavior for Validate bind disabled when fasttrack Indicator false otherwise continue with bind.

    /**
     * F87642 Validate that [2 Vehicle + 2 Driver] FFQ (CA) - Auto - Send the odometer reading information in RC3 call to PC
     * 471, 472 , 474 [Scenario numbers covered]
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"}),@CustomAttribute(name = INCLUDED_STATES, values = {CA})},
            dataProviderClass = AutoDataProviders.class,groups = {FFQ_ONEUI})
    public void validateOdometer_Rideshare_InfoIsSentToPC_Bind_F87642(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        Vehicle vehicle1 = applicant.getVehicles().get(0);
        Vehicle vehicle2 = vehicle1.clone();
        vehicle1.setUseVIN(false);
        vehicle1.setVehicleUsage("Rideshare");
        vehicle1.setRidesharing(true);
        vehicle2.setUseVIN(true);
        vehicle2.setVehicleUsage("Personal");
        vehicle2.setRidesharing(false);
        applicant.setVehicles(Arrays.asList(vehicle1, vehicle2));
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
        AutoBindE2EDiagnostics.checkpoint("odometer-rideshare-quote-summary");

        // customize

        quoteSummaryAutoPage.updateLiabilityAndCustomize();
        quoteSummaryAutoPage.updateVehicleCoverageAndCustomize();
        quoteSummaryAutoPage.clickOnStartCheckoutButton();


        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        testStepAssert(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User should be on the additional info page");
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
        AutoBindE2EDiagnostics.checkpoint("odometer-rideshare-after-additional-info");
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
       // testStepAssert(consolidatedPaymentPage.isOnConsolidatedPaymentPage(), "User should be on the Consolidated Payment page");

        AutoQuoteVerifyServiceInitiated autoQuoteVerifyServiceInitiated = new ApiHelper().getAutoQuoteVerifyServiceInitiated(consolidatedPaymentPage.getSessionStorageAppStore().getData().getQuoteNumber());
        AutoQuoteVerifyServiceInitiated.AutoQuote.PersonalAuto personalAuto = autoQuoteVerifyServiceInitiated.getAutoQuote().get(0).getPersonalAuto();

        // validate  odometer readings are passed
        personalAuto.getVehicles().forEach(eachVeh -> {
            softAssert.assertTrue(!eachVeh.getOdometerReading().isEmpty(), "Odometer data should be provided in the verify rate response");
            softAssert.assertTrue(!eachVeh.getOdometerReadingDate().isEmpty(), "Odometer reading date should be provided in the verify rate response");
        });

        // validate rideshare and RNOG are passed
        boolean hasRideSharingDriver = personalAuto.getDrivers().stream()
                .anyMatch(driver -> "Y".equals(driver.getRideSharingIndicator()));

        softAssert.assertTrue(hasRideSharingDriver, "No driver has rideSharingIndicator set to 'Y'");

        boolean anyHasRNOGConsent = personalAuto.getDrivers().stream()
                .anyMatch(driver -> driver.getCustomerRNOGConsentInd() != null);

        softAssert.assertTrue(anyHasRNOGConsent, "No driver has a non-null customerRNOGConsentInd.");

       // completePurchase(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true, softAssert);

        softAssert.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Odometer Rideshare Info Is Sent To PC Bind F87642.

    /**
     * Targeted Bind One UI navigation wrapper. It preserves the existing navigation
     * behavior and adds COPY-DOM evidence only; it does not weaken assertions or
     * skip intermediate business logic.
     */
    private void navigateToPaymentSelectionWithEvidence(AutoApplicant applicant, String scenario) throws Exception {
        try {
            new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
            AutoBindE2EDiagnostics.checkpoint(scenario + "-payment-selection");
        } catch (Exception error) {
            AutoBindE2EDiagnostics.captureFailure(scenario + "-navigation", error);
            throw error;
        }
    }

    private void navigateToPaymentSelectionWithEvidence(ADPFApplicant applicant, String scenario) throws Exception {
        try {
            new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
            AutoBindE2EDiagnostics.checkpoint(scenario + "-payment-selection");
        } catch (Exception error) {
            AutoBindE2EDiagnostics.captureFailure(scenario + "-navigation", error);
            throw error;
        }
    }

    /**
     * Executes the existing BaseTest purchase implementation and captures the DOM
     * immediately before and after the bind/payment transition.
     */
    private void completePurchaseWithEvidence(String paymentPlanOption, PaymentMethods paymentMethod,
                                              boolean clickPurchaseButton, FarmersSoftAssert softAssert,
                                              String scenario) throws Exception {
        AutoBindE2EDiagnostics.checkpoint(scenario + "-before-complete-purchase");
        try {
            completePurchase(paymentPlanOption, paymentMethod, clickPurchaseButton, softAssert);
            AutoBindE2EDiagnostics.checkpoint(scenario + "-after-complete-purchase");
        } catch (Exception error) {
            AutoBindE2EDiagnostics.captureFailure(scenario + "-purchase", error);
            throw error;
        }
    }

    private AutoApplicant buildBristolWestDeterministicApplicant() throws Exception {
        List<AutoApplicant> candidates = AutoDataProviders.listOfAutoApplicants("bindOneUIApplicant", "stateCode=IN");
        if (candidates.isEmpty()) {
            candidates = AutoDataProviders.listOfAutoApplicants("applicant", "stateCode=IN");
        }
        testStepAssert(!candidates.isEmpty(), "At least one Indiana applicant is available for deterministic setup", true);
        AutoApplicant applicant = candidates.get(FIRST_AVAILABLE_OPTION);
        updateApplicantDataToAvoidPossibleBw(applicant);

        applicant.setTestScenario(BRISTOLWEST_SCENARIO_NAME);
        applicant.setFirstName("Yvonne");
        applicant.setLastName("Fisher");
        applicant.setGender("Female");
        applicant.setDateOfBirth("06131970");
        applicant.setAge(56);
        applicant.setResidentAddress("129 W Lake Dr");
        applicant.setCity("Nashville");
        applicant.setStateName("Indiana");
        applicant.setStateCode("IN");
        applicant.setZipCode("47448");
        applicant.setMaritalStatus("Separated");
        applicant.setOccupation("Firefighter");
        applicant.setCurrentlyInsuredStatus("Insured");
        applicant.setCurrentInsuranceCompany("AAA");
        applicant.setContinuosInsurancePeriod("60+ Months");
        applicant.setCurrentBodilyInjuryLimit("$50,000/$100,000");
        applicant.setFinancialFiling(NO);
        applicant.setEmail("autoApplicant25@yopmail.com");
        applicant.setPhoneNumber("3157915441");
        applicant.setCurrentInsuranceExpirationDate("08/27/2026");
        applicant.setDriversLicense("5768391095");
        applicant.setLicenseIssueStateName("Indiana");
        applicant.setHaveAccidentOrViolations(false);
        applicant.setIncidents(new ArrayList<>());
        applicant.setAdditionalDrivers(new ArrayList<>());

        Vehicle vehicle = applicant.getVehicles().isEmpty() ? new Vehicle() : applicant.getVehicles().get(FIRST_AVAILABLE_OPTION);
        vehicle.setUseVIN(true);
        vehicle.setVehicleYear("2016");
        vehicle.setVehicleMake("HONDA");
        vehicle.setVehicleModel("CIVIC 4D EX");
        vehicle.setVehicleVIN("19XFC2F70GE089149");
        vehicle.setVehicleType("Sedan");
        vehicle.setOwnership("Owned");
        vehicle.setVehicleUsage("Personal");
        vehicle.setParkInResidentAddress(true);
        applicant.setVehicles(Collections.singletonList(vehicle));
        return applicant;
    }

    private void completeBristolWestDeterministicPurchase(AutoApplicant applicant, String diagnosticLabel) throws Exception {
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        if (consolidatedPaymentPage.isOnConsolidatedPaymentPage()) {
            Log.info("[BristolWest E2E][70%] Checkout successfully reached");
            AutoBindE2EDiagnostics.checkpoint(diagnosticLabel + "-10-checkout");

            consolidatedPaymentPage.selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
            consolidatedPaymentPage.clickCardRadioButton();
            consolidatedPaymentPage.addCardPaymentMethod("4242424242424242", "47448");
            Log.info("[BristolWest E2E][90%] Card payment method successfully saved");
            AutoBindE2EDiagnostics.checkpoint(diagnosticLabel + "-13-payment-method");

            KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
            if (knockoutInconveniencePage.isOnInconveniencePage()) {
                Log.warn("[BristolWest E2E] Checkout inconvenience detected after payment method setup. Attempting Try again recovery.");
                AutoBindE2EDiagnostics.checkpoint(diagnosticLabel + "-13b-checkout-inconvenience");
                knockoutInconveniencePage.clickTryAgainIfPresent();
            }

            BwCongratulationsPage bwCongratulationsPage = new BwCongratulationsPage();
            if (bwCongratulationsPage.isOnBwCongratsPage()) {
                testStepAssert(true, "Purchase Success reached", true);
                Log.info("[BristolWest E2E][98%] Purchase Success reached");
                AutoBindE2EDiagnostics.checkpoint(diagnosticLabel + "-15-purchase-success");
                return;
            }

            if (consolidatedPaymentPage.isProdEnvironment()) {
                AutoBindE2EDiagnostics.checkpoint(diagnosticLabel + "-14-purchase-ready-prod-safety-block");
                Log.warn("BRISTOLWEST E2E PROD SAFETY BLOCK ACTIVE");
                return;
            }

            Log.info("[BristolWest E2E][95%] Complete Purchase ready");
            consolidatedPaymentPage.clickCompletePurchaseButton();
            testStepAssert(bwCongratulationsPage.isOnBwCongratsPage(), "Purchase Success reached", true);
            Log.info("[BristolWest E2E][98%] Purchase Success reached");
            AutoBindE2EDiagnostics.checkpoint(diagnosticLabel + "-15-purchase-success");
            return;
        }

        testStepAssert(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "Bristol West payment summary reached", true);
        bwPaymentSummaryPage.closeRateChangePopUpIfPresent();
        testStepAssert(autoPolicyPaymentBasePage.getTheListOfEligiblePaymentMethods().contains(PAY_IN_FULL),
                "Pay in full option is available", true);

        Log.info("[BristolWest E2E][70%] Checkout successfully reached");
        bwPaymentSummaryPage.processBwPaymentSummaryPage(PAY_IN_FULL);
        AutoBindE2EDiagnostics.checkpoint(diagnosticLabel + "-10-checkout");

        BwDocuSignPage bwDocuSignPage = new BwDocuSignPage();
        bwDocuSignPage.signDocuments();
        Log.info("[BristolWest E2E][78%] DocuSign completed");
        AutoBindE2EDiagnostics.checkpoint(diagnosticLabel + "-11-docusign");

        testStepAssert(bwPaymentSummaryPage.isOnAutoPolicyPaymentPage(), "Auto policy payment reached", true);
        Log.info("[BristolWest E2E][85%] Auto policy payment reached");
        bwPaymentSummaryPage.clickSetUpPaymentButton();
        bwPaymentSummaryPage.addCardPaymentMethod("4242424242424242", "47448");
        Log.info("[BristolWest E2E][90%] Card payment method successfully saved");
        AutoBindE2EDiagnostics.checkpoint(diagnosticLabel + "-13-payment-method");

        if (bwPaymentSummaryPage.isProdEnvironment()) {
            AutoBindE2EDiagnostics.checkpoint(diagnosticLabel + "-14-purchase-ready-prod-safety-block");
            Log.warn("BRISTOLWEST E2E PROD SAFETY BLOCK ACTIVE");
            return;
        }

        Log.info("[BristolWest E2E][95%] Complete Purchase ready");
        autoPolicyPaymentBasePage.clickCompletePurchaseButton();
        BwCongratulationsPage bwCongratulationsPage = new BwCongratulationsPage();
        testStepAssert(bwCongratulationsPage.isOnBwCongratsPage(), "Purchase Success reached", true);
        Log.info("[BristolWest E2E][98%] Purchase Success reached");
        AutoBindE2EDiagnostics.checkpoint(diagnosticLabel + "-15-purchase-success");
    }

    private void logBristolWestExecutionHeader(String executionId, AutoApplicant applicant) {
        String resolvedEnvironment = Property.getTestProperty("environment");
        if (resolvedEnvironment == null || resolvedEnvironment.isBlank()) {
            resolvedEnvironment = Property.getUri();
        }
        Log.info("============================================================");
        Log.info("BRISTOLWEST E2E");
        Log.info("============================================================");
        Log.info("SCENARIO: " + BRISTOLWEST_SCENARIO_NAME);
        Log.info("TEST USER: " + applicant.getFirstName() + " " + applicant.getLastName());
        Log.info("VEHICLE: 2016 HONDA CIVIC 4D EX");
        Log.info("EXECUTION TYPE: Deterministic E2E");
        Log.info("ENVIRONMENT: " + resolvedEnvironment);
        Log.info("EXECUTION ID: " + executionId);
        Log.info("PLAYWRIGHT JAVA: 100%");
        Log.info("SELENIUM: 0");
        Log.info("============================================================");
    }

}
