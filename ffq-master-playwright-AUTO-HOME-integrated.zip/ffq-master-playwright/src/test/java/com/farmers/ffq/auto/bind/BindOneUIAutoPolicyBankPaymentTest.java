package com.farmers.ffq.auto.bind;

import com.farmers.ffq.BaseTest;

import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.common.pages.PolicyBankPayment;
import com.farmers.ffq.common.pages.PolicyDebitCreditPayment;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.annotation.Skip;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.common.pages.PolicyBankPayment.NO_SERVICE_CHARGE_WHEN_USING_BANK;
import static com.farmers.ffq.common.pages.PolicyDebitCreditPayment.NO_SERVICE_CHARGE_WHEN_PAY_IN_FULL;
import static com.farmers.ffq.common.pages.PolicyPaymentBasePage.MONTHLY_AUTO_PAY_BANK_HEADER;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class BindOneUIAutoPolicyBankPaymentTest extends BaseTest {

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)
    public void monthlyPayBankIframeContentValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        AppStore sessionStorageAppStore = policyPaymentBasePage.getSessionStorageAppStore();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayBank();
        fsa.assertTrue(policyPaymentBasePage.clickSetUpPaymentButton(), "Add card side bar opened successfully");

        PolicyBankPayment policyBankPayment = new PolicyBankPayment();
        fsa.assertTrue(policyBankPayment.isAddBankHeaderCorrect(), errorMessage("Add bank label"));
        policyPaymentBasePage.switchToPaymentUsIframe();
        fsa.assertTrue(policyBankPayment.isBankAccountTypeHeaderCorrect(), errorMessage("Bank account type header"));
        fsa.assertTrue(policyBankPayment.isCheckingRadioButtonSelected(), "Checking radio button is selected");
        fsa.assertTrue(policyBankPayment.isCheckingLabelCorrect(), errorMessage("Checking label"));
        fsa.assertTrue(policyBankPayment.isSavingsRadioButtonEnabled(), "Savings radio button is displayed");
        fsa.assertTrue(policyBankPayment.isSavingsLabelCorrect(), errorMessage("Savings label"));
        fsa.assertTrue(policyBankPayment.isBusinessCheckingRadioButtonEnabled(), "Business checking radio button is displayed");
        fsa.assertTrue(policyBankPayment.isBusinessCheckingLabelCorrect(), errorMessage("Business checking label"));
        fsa.assertTrue(policyBankPayment.isAccountHolderNameLabelCorrect(), errorMessage("Account holder name"));
        fsa.assertTrue(policyBankPayment.isAccountHolderNameMatching(policyPaymentBasePage.fullNameFromCustomerData(sessionStorageAppStore.getData().getCustomerData())), "Account holder name is not matching");
        fsa.assertTrue(policyBankPayment.isBankRoutingNumberLabelCorrect(), errorMessage("Bank routing number label"));
        fsa.assertTrue(policyBankPayment.isAccountNumberLabelCorrect(), errorMessage("Account number label"));
        fsa.assertTrue(policyBankPayment.isConfirmAccountNumberLabelCorrect(), errorMessage("Confirm account number label"));
        fsa.assertTrue(policyPaymentBasePage.isAddButtonTextCorrect(), errorMessage("Add button"));
        policyBankPayment.logInfoMessage(sessionStorageAppStore.getData().getQuoteNumber());
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Monthly Pay Bank Iframe Content Validation.

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)
    public void monthlyPayBankIframeErrorValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        AppStore sessionStorageAppStore = additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore();
        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayBank();
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        fsa.assertTrue(policyPaymentBasePage.clickSetUpPaymentButton(), "Add card side bar opened successfully");

        PolicyBankPayment autoPolicyBankPayment = new PolicyBankPayment();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();

        policyPaymentBasePage.switchToPaymentUsIframe();
        autoPolicyBankPayment.clearOutAccountHolderInputField();
        policyPaymentBasePage.clickAddButton();
        fsa.assertTrue(autoPolicyBankPayment.isEnterValidAccountHolderNameErrorCorrect(), errorMessage("Enter valid account holder name error"));
        fsa.assertTrue(autoPolicyBankPayment.isEnterValidRoutingNumberErrorCorrect(), errorMessage("Enter valid routing number error"));
        fsa.assertTrue(autoPolicyBankPayment.isEnterValidBankAccountNumberErrorCorrect(), errorMessage("Enter valid account number error"));
        fsa.assertTrue(autoPolicyBankPayment.isBankAccountNumbersNotMatchingErrorCorrect(), errorMessage("Bank account numbers are not matching error"));

        autoPolicyBankPayment.enterRoutingNumber(DIGITS);
        fsa.assertTrue(autoPolicyBankPayment.isEnterValidRoutingNumberErrorCorrect(), errorMessage("Enter valid routing number error"));

        autoPolicyBankPayment.enterAccountNumber(DIGITS.substring(5));
        fsa.assertTrue(autoPolicyBankPayment.isEnterValidBankAccountNumberErrorCorrect(), errorMessage("Enter valid account number error"));

        autoPolicyBankPayment.enterConfirmAccountNumber(DIGITS.substring(4));
        fsa.assertTrue(autoPolicyBankPayment.isBankAccountNumbersNotMatchingErrorCorrect(), errorMessage("Bank account numbers are not matching error"));
        autoPolicyPaymentBasePage.logInfoMessage(sessionStorageAppStore.getData().getQuoteNumber());
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Monthly Pay Bank Iframe Error Validation.

    // Monthly - Bank Payment Validation
    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)
    public void monthlyPayBankIframeValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayBank();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        fsa.assertTrue(autoPolicyPaymentBasePage.clickSetUpPaymentButton(), "Add card side bar opened successfully");

        PolicyBankPayment policyBankPayment = new PolicyBankPayment();
        String accountNumber = RandomStringUtils.randomNumeric(10);

        // Checking payment setup validation
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        waitForUiSettled();
        fsa.assertTrue(policyBankPayment.isBOFABankNameLabelCorrect(), errorMessage("BOFA bank label"));

        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        autoPolicyPaymentBasePage.clickAddButton();
        fsa.assertTrue(policyBankPayment.isBankPaymentAccountAddedMsgCorrect(), errorMessage("Bank account added"));
        autoPolicyPaymentBasePage.isDisclaimerChargeTextCorrect(fsa, "2- No service charge when using bank transfer");
        fsa.assertTrue(policyBankPayment.isBankIconDisplayed(), "Bank icon is not displayed");
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountMonthlyPayTextCorrect(accountNumber), errorMessage("Hidden account number"));

        policyBankPayment.clickChangeLink();
        fsa.assertTrue(policyBankPayment.isChangeToPaymentMethodLabelCorrect(), errorMessage("Change to payment method"));

        autoPolicyPaymentBasePage.clickSetUpPaymentButton();

        // Payment method already added error validation
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        autoPolicyPaymentBasePage.clickAddButton();
        autoPolicyPaymentBasePage.waitForSpinnerToBeGone();
        fsa.assertTrue(autoPolicyPaymentBasePage.isPaymentMethodAlreadyAddedMsgCorrect(), errorMessage("Payment method already added"));
        autoPolicyPaymentBasePage.switchToParentWindow();
        autoPolicyPaymentBasePage.closeAddPaymentMethodContainer(true);

        // Savings payment setup
        policyBankPayment.clickChangeLink();
        autoPolicyPaymentBasePage.clickSetUpPaymentButton();
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyBankPayment.clickSavingsRadioButton();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        autoPolicyPaymentBasePage.clickAddButton();
        autoPolicyPaymentBasePage.switchToParentWindow();
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountMonthlyPayTextCorrect(accountNumber), errorMessage("Hidden account number monthly pay"));

        // Business checking payment setup
        policyBankPayment.clickChangeLink();
        autoPolicyPaymentBasePage.clickSetUpPaymentButton();
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyBankPayment.clickBusinessCheckingRadioButton();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        autoPolicyPaymentBasePage.clickAddButton();
        autoPolicyPaymentBasePage.switchToParentWindow();
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountMonthlyPayTextCorrect(accountNumber), errorMessage("Hidden account number monthly pay"));

        // validate terms and conditions
        // autoPolicyPaymentBasePage.switchToParentWindow();
        fsa.assertTrue(autoPolicyPaymentBasePage.isByClickingCompletePurchaseLabelCorrect(), errorMessage("String clicking complete purchase"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isReadAndAgreedBulletPointOneCorrect(), errorMessage("Read and agree bullet point one"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isReadAndAgreedBulletPointTwoMonthlyPayCorrect(), errorMessage("Read and agree bullet point two monthly pay"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isIfDoNotAgreeWithTermsAndConditionLabelCorrect(), errorMessage("If do not read terms and conditions label"));

        if (Property.getTestProperty("browser").equals("firefox")) {
            fsa.assertTrue(autoPolicyPaymentBasePage.validateClickableLinksPaymentPage(), "One or more links is not enabled or displayed");
        } else {
            fsa.assertTrue(autoPolicyPaymentBasePage.validateOpeningLinksInNewTab(), "Title is not matching for one or more opened tab");
        }
        autoPolicyPaymentBasePage.logInfoMessage(autoPolicyPaymentBasePage.getSessionStorageAppStore().getData().getQuoteNumber());

        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Monthly Pay Bank Iframe Validation.

    //Pay in full - Bank Payment Validation
    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)
    public void payInFullBankIframeValidation(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentPayInFull();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        fsa.assertTrue(autoPolicyPaymentBasePage.clickSetUpPaymentButton(), "Add card side bar opened successfully");

        PolicyBankPayment policyBankPayment = new PolicyBankPayment();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        String accountNumber = RandomStringUtils.randomNumeric(10);

        // Checking payment setup validation
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        waitForUiSettled();
        fsa.assertTrue(policyBankPayment.isBOFABankNameLabelCorrect(), errorMessage("BOFA bank label"));

        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        autoPolicyPaymentBasePage.clickAddButton();
        fsa.assertTrue(policyBankPayment.isBankPaymentAccountAddedMsgCorrect(), errorMessage("Bank account added"));
        autoPolicyPaymentBasePage.isDisclaimerChargeTextCorrect(fsa, NO_SERVICE_CHARGE_WHEN_PAY_IN_FULL);
        fsa.assertTrue(policyBankPayment.isBankIconDisplayed(), "Bank icon is not displayed");
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountPayInFullTextCorrect(accountNumber), errorMessage("Hidden account number pay in full"));

        policyBankPayment.clickChangeLink();

        // Payment method already added error validation
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        autoPolicyPaymentBasePage.clickAddButton();
        fsa.assertTrue(autoPolicyPaymentBasePage.isPaymentMethodAlreadyAddedMsgCorrect(), errorMessage("Payment method already added"));
        autoPolicyPaymentBasePage.switchToParentWindow();
        autoPolicyPaymentBasePage.closeAddPaymentMethodContainer(true);

        // Savings payment setup
        policyBankPayment.clickChangeLink();
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyBankPayment.clickSavingsRadioButton();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        autoPolicyPaymentBasePage.clickAddButton();
        autoPolicyPaymentBasePage.switchToParentWindow();
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountPayInFullTextCorrect(accountNumber), errorMessage("Hidden account number pay in full"));

        // Business checking payment setup
        policyBankPayment.clickChangeLink();
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyBankPayment.clickBusinessCheckingRadioButton();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        autoPolicyPaymentBasePage.clickAddButton();
        autoPolicyPaymentBasePage.switchToParentWindow();
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountPayInFullTextCorrect(accountNumber), errorMessage("Hidden account number pay in full"));

        // validate terms and conditions
        // autoPolicyPaymentBasePage.switchToParentWindow();
        fsa.assertTrue(autoPolicyPaymentBasePage.isByClickingCompletePurchaseLabelCorrect(), errorMessage("String clicking complete purchase"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isReadAndAgreedBulletPointOneCorrect(), errorMessage("Read and agree bullet point one"));
        fsa.assertTrue(policyBankPayment.isReadAndAgreedBulletPointTwoPayInFullCorrect(), errorMessage("Read and agree bullet point two pay in full"));
        fsa.assertTrue(autoPolicyPaymentBasePage.isIfDoNotAgreeWithTermsAndConditionLabelCorrect(), errorMessage("If do not read terms and conditions label"));
        // sa.assertTrue(autoPolicyPaymentBasePage.validateOpeningLinksInNewTab(),"Title is not matching for one or more opened tab");

        if (Property.getTestProperty("browser").equals("firefox")) {
            fsa.assertTrue(autoPolicyPaymentBasePage.validateClickableLinksPaymentPage(), "One or more links is not enabled or displayed");
        } else {
            fsa.assertTrue(autoPolicyPaymentBasePage.validateOpeningLinksInNewTab(), "Title is not matching for one or more opened tab");
        }

        fsa.assertTrue(policyDebitCreditPayment.isOneTimePaymentTextCorrect(), "One time payment");
        fsa.assertTrue(autoPolicyPaymentBasePage.isCompletePurchaseButtonTextMatching(), errorMessage("Complete purchase button"));
        autoPolicyPaymentBasePage.logInfoMessage(additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore().getData().getQuoteNumber());
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Pay In Full Bank Iframe Validation.

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)
    public void payInFullBankToDebitCardPaymentMethodChange(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentPayInFull();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        fsa.assertTrue(autoPolicyPaymentBasePage.clickSetUpPaymentButton(), "Add card side bar opened successfully");

        PolicyBankPayment policyBankPayment = new PolicyBankPayment();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        String accountNumber = RandomStringUtils.randomNumeric(10);

        // Checking payment setup validation
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        waitForUiSettled();
        fsa.assertTrue(policyBankPayment.isBOFABankNameLabelCorrect(), errorMessage("BOFA bank label"));

        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        autoPolicyPaymentBasePage.clickAddButton();
        autoPolicyPaymentBasePage.switchToParentWindow();
        fsa.assertTrue(policyBankPayment.isBankPaymentAccountAddedMsgCorrect(), errorMessage("Bank account added"));
        autoPolicyPaymentBasePage.isDisclaimerChargeTextCorrect(fsa, "No service charges when you pay in full.");
        fsa.assertTrue(policyBankPayment.isBankIconDisplayed(), "Bank icon is not displayed");
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountPayInFullTextCorrect(accountNumber), errorMessage("Hidden account number pay in full"));

        policyBankPayment.clickChangeLink();

        // Validate VISA debit card details and validate success messages
        autoPolicyPaymentBasePage.clickDebitCreditCardButton();
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyDebitCreditPayment.enterCardNumber(VISA_DEBIT_CARD);
        policyDebitCreditPayment.enterExpDate(EXP_DATE);
        policyDebitCreditPayment.enterCVVNumber(CVV_NUMBER);
        policyDebitCreditPayment.enterBillingZipCode(ZIP_CODE);
        autoPolicyPaymentBasePage.clickAddButton();
        policyDebitCreditPayment.waitForCompletePurchaseButtonToBeClickable();
        fsa.assertTrue(policyDebitCreditPayment.isHiddenCardNumberAndExpDatePayInfFullCorrect(VISA_DEBIT_CARD, EXP_DATE, CARD_NAME_VISA), "Hidden card number and exp date visa debit");
        fsa.assertTrue(policyDebitCreditPayment.isDebitCardAddedMsgCorrect(), errorMessage("Debit card added message"));
        fsa.assertTrue(policyDebitCreditPayment.isNoServiceChargeWhenPayInFullMsgCorrect(AUTO), errorMessage("No service charge when pay in full"));
        autoPolicyPaymentBasePage.logInfoMessage(additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore().getData().getQuoteNumber());

        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Pay In Full Bank To Debit Card Payment Method Change.

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)
    public void monthlyPayBankToCreditCardPaymentMethodChange(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        additionalInfoContinueToPaymentOneUI.clickSelectAndSetUpPaymentMonthlyPayBank();
        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        fsa.assertTrue(autoPolicyPaymentBasePage.clickSetUpPaymentButton(), "Add card side bar opened successfully");

        PolicyBankPayment policyBankPayment = new PolicyBankPayment();
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        String accountNumber = RandomStringUtils.randomNumeric(10);

        // Checking payment setup validation
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyBankPayment.enterRoutingNumber(BOFA_ROUTING_NUMBER);
        waitForUiSettled();
        fsa.assertTrue(policyBankPayment.isBOFABankNameLabelCorrect(), errorMessage("BOFA bank label"));

        policyBankPayment.enterAccountNumber(accountNumber);
        policyBankPayment.enterConfirmAccountNumber(accountNumber);
        autoPolicyPaymentBasePage.clickAddButton();
        fsa.assertTrue(policyBankPayment.isBankPaymentAccountAddedMsgCorrect(), errorMessage("Bank account added"));
        autoPolicyPaymentBasePage.isDisclaimerChargeTextCorrect(fsa, NO_SERVICE_CHARGE_WHEN_USING_BANK);
        fsa.assertTrue(policyBankPayment.isBankIconDisplayed(), "Bank icon displayed");
        fsa.assertTrue(policyBankPayment.isHiddenBankAccountMonthlyPayTextCorrect(accountNumber), errorMessage("Hidden account number"));

        policyBankPayment.clickChangeLink();
        autoPolicyPaymentBasePage.selectCardPaymentRadioButtonAlternative();
        autoPolicyPaymentBasePage.clickSetUpPaymentButtonSideSheet();
        autoPolicyPaymentBasePage.switchToPaymentUsIframe();
        policyDebitCreditPayment.enterCardNumber(DISCOVER_CARD);
        policyDebitCreditPayment.enterExpDate(EXP_DATE);
        policyDebitCreditPayment.enterCVVNumber(CVV_NUMBER);
        policyDebitCreditPayment.enterBillingZipCode(ZIP_CODE);
        autoPolicyPaymentBasePage.clickAddButton();
        policyDebitCreditPayment.waitForCompletePurchaseButtonToBeClickable();
        fsa.assertTrue(policyDebitCreditPayment.isHiddenCardNumberAndExpDateMonthlyPayCorrect(DISCOVER_CARD, EXP_DATE, CARD_NAME_DISCOVER), "Hidden card number and exp date");
        fsa.assertTrue(policyDebitCreditPayment.isCreditCardAddedMsgCorrect(), errorMessage("Credit card added message"));
        fsa.assertTrue(policyDebitCreditPayment.isFutureCreditCardServiceChargesTextMatching(), errorMessage("Future service credit card charge"));

        // add quote number and saucelabs link in the logs
        autoPolicyPaymentBasePage.logInfoMessage(additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore().getData().getQuoteNumber());
        autoPolicyPaymentBasePage.addSauceLabsLinkInLog();

    }
    // Test description: Validates the Auto behavior for Monthly Pay Bank To Credit Card Payment Method Change.

    @Skip
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {KY, NC, NV})}, groups = {FFQ_ONEUI, FFQ_BIND_BANKPAYMENT_PAGE}, enabled = false)
    public void validatePreviouslyAddedPaymentMethodIsDeleted(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        consolidatedPaymentPage.selectPaymentMethodFromPaymentCards(MONTHLY_AUTO_PAY_BANK_HEADER);
        consolidatedPaymentPage.clickCardRadioButton();
        consolidatedPaymentPage.addCardPaymentMethod(MASTER_CARD, applicant.getZipCode());
        testStepAssert(consolidatedPaymentPage.isGreenCheckIsDisplayed(), "First time card successfully added", true);
        additionalInfoContinueToPaymentOneUI.clickReviewQuoteNavigationBarStepper();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page", true);
        new QuoteSummaryAutoPage().clickOnStartCheckoutButton();
        additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();
        // add same payment method with pay in full
        consolidatedPaymentPage.selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
        consolidatedPaymentPage.clickCardRadioButton();
        consolidatedPaymentPage.addCardPaymentMethod(MASTER_CARD, applicant.getZipCode());
        testStepAssert(consolidatedPaymentPage.isGreenCheckIsDisplayed(), "Card time card successfully added", true);


    }
    // Test description: Validates the Auto behavior for Validate Previously Added Payment Method Is Deleted.

    private String errorMessage(String item) {
        return item + " text is not correct";
    }

}
