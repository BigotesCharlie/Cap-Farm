package com.farmers.ffq.auto.defaultcoverage;

import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;
import static com.farmers.ffq.utils.GlobalVariables.MO;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;

public class DefaultCoverageValuesTests_MO extends DefaultCoverageBaseTest {
    // Missouri does not display Current BI limits less than 25/50
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
		attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
	    defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "MO_25K50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO25 K50 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
		attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {
	    defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "MO_25K50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO25 K50 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO25K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=No", "MO_25K65K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO25 K65 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO25K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=Yes", "MO_25K65K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO25 K65 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "MO_30K60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO30 K60 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "MO_30K60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO30 K60 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO30K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=No", "MO_30K65K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO30 K65 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO30K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=Yes", "MO_30K65K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO30 K65 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "MO_35K70K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO35 K70 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "MO_35K70K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO35 K70 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO35K80K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=No", "MO_35K80K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO35 K80 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO35K80K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=Yes", "MO_35K80K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO35 K80 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "MO_50K100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO50 K100 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "MO_50K100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO50 K100 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "MO_100K200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO100 K200 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "MO_100K200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO100 K200 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "MO_100K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO100 K300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "MO_100K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO100 K300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO150K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=No", "MO_150K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO150 K300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO150K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=Yes", "MO_150K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO150 K300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No","MO_250K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO250 K500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "MO_250K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO250 K500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "MO_300K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO300 K300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "MO_300K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO300 K300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "MO_500K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO500 K500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "MO_500K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO500 K500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO500K1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "MO_500K1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO500 K1 M NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO500K1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "MO_500K1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO500 K1 M UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO1M1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "MO_1M1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO1 M1 M NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO1M1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "MO_1M1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO1 M1 M UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO35K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=No", "MO_35K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO35 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO35K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=Yes", "MO_35K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO35 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO45K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=No", "MO_45K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO45 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO45K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=Yes", "MO_45K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO45 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "MO_50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO50 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO50K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "MO_50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO50 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=No", "MO_60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO60 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO60K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=Yes", "MO_60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO60 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "MO_75K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO75 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO75K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "MO_75K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO75 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO85K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=No", "MO_85K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO85 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO85K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=Yes", "MO_85K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO85 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "MO_100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO100 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "MO_100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO100 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "MO_200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO200 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "MO_200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO200 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "MO_300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "MO_300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "MO_500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "MO_500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "MO_1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO1 M NO UMBRELLA.
	
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MO)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MO1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "MO_1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MO1 M UMBRELLA.

}
