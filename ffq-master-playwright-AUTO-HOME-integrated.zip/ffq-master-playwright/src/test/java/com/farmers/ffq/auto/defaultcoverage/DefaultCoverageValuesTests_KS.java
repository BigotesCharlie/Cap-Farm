package com.farmers.ffq.auto.defaultcoverage;

import static com.farmers.ffq.utils.GlobalVariables.KS;
import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;

public class DefaultCoverageValuesTests_KS extends DefaultCoverageBaseTest {
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "KS_25K50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 25 K50 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "KS_25K50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 25 K50 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "KS_30K60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 30 K60 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "KS_30K60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 30 K60 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "KS_35K70K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 35 K70 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "KS_35K70K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 35 K70 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "KS_50K100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 50 K100 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "KS_50K100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 50 K100 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "KS_100K200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 100 K200 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "KS_100K200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 100 K200 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "KS_100K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 100 K300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "KS_100K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 100 K300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No","KS_250K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 250 K500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "KS_250K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 250 K500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "KS_500K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 500 K500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "KS_500K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 500 K500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_500K1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "KS_500K1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 500 K1 M NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_500K1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "KS_500K1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 500 K1 M UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "KS_500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "KS_500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "KS_1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 1 M NO UMBRELLA.
	
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = KS)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_KS_1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "KS_1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values KS 1 M UMBRELLA.

}
