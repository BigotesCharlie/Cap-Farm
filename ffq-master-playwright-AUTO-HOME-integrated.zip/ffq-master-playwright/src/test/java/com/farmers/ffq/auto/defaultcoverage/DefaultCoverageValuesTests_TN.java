package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class DefaultCoverageValuesTests_TN extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_PIPPD_ONLY_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=PIPPD_Only&umbrella=No", "TN_PIPPD_ONLY_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN PIPPD ONLY NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_PIPPD_ONLY_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=PIPPD_Only&umbrella=Yes", "TN_PIPPD_ONLY_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN PIPPD ONLY UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_10K20K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=10/20&umbrella=No", "TN_10K20K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 10 K20 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_10K20K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=10/20&umbrella=Yes", "TN_10K20K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 10 K20 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_15K30K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=No", "TN_15K30K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 15 K30 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_15K30K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=Yes", "TN_15K30K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 15 K30 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_20K40K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=No", "TN_20K40K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 20 K40 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_20K40K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=Yes", "TN_20K40K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 20 K40 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "TN_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 25 K50 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "TN_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 25 K50 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_25K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=No", "TN_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 25 K65 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_25K65K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=Yes", "TN_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 25 K65 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "TN_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 30 K60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "TN_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 30 K60 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_30K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=No", "TN_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 30 K65 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_30K65K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=Yes", "TN_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 30 K65 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "TN_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 35 K70 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "TN_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 35 K70 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_35K80K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=No", "TN_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 35 K80 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_35K80K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=Yes", "TN_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 35 K80 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "TN_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 50 K100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "TN_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 50 K100 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "TN_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 100 K200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "TN_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 100 K200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "TN_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 100 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "TN_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 100 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "TN_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 250 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "TN_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 250 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "TN_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 300 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "TN_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 300 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "TN_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 500 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "TN_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 500 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_500K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "TN_500K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 500 K1000 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_500K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "TN_500K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 500 K1000 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_1000K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "TN_1000K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 1000 K1000 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_1000K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "TN_1000K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 1000 K1000 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_35K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=No", "TN_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 35 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_35K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=Yes", "TN_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 35 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_45K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=No", "TN_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 45 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_45K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=Yes", "TN_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 45 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "TN_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 50 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_50K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "TN_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 50 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=No", "TN_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_60K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=Yes", "TN_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 60 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "TN_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 75 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_75K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "TN_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 75 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_85K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=No", "TN_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 85 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_85K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=Yes", "TN_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 85 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "TN_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_100K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "TN_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 100 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "TN_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_200K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "TN_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "TN_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_300K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "TN_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "TN_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_500K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "TN_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "TN_1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 1000 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = TN)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_1000K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "TN_1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 1000 K UMBRELLA.

}
