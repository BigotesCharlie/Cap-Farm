package com.farmers.ffq.auto.defaultcoverage;

import static com.farmers.ffq.utils.GlobalVariables.MN;
import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;

public class DefaultCoverageValuesTests_MN extends DefaultCoverageBaseTest {
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "MN_30K60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 30 K60 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "MN_30K60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 30 K60 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "MN_35K70K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 35 K70 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "MN_35K70K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 35 K70 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "MN_50K100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 50 K100 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "MN_50K100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 50 K100 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "MN_100K200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 100 K200 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "MN_100K200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 100 K200 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "MN_100K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 100 K300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "MN_100K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 100 K300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No","MN_250K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 250 K500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "MN_250K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 250 K500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "MN_500K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 500 K500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "MN_500K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 500 K500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "MN_500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MN)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MN_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "MN_500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MN 500 K UMBRELLA.

}
