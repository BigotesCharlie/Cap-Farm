package com.farmers.ffq.auto;


import com.microsoft.playwright.Page;
import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.ADPFApplicant;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;

import com.farmers.framework.annotation.Skip;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Optional;

import static com.farmers.ffq.auto.pages.VehicleReviewPage.BUSINESS;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class VehiclesReviewTest extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, groups = {FFQ_ONEUI, VEHICLES_REVIEW_TEST})
    public void testVehicleReviewPage(AutoApplicant applicant) throws Exception {
        VehicleReviewPage vehicleReviewPage = new AceAutoNavigationHelper().navigateToVehicleReviewPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicant.getVehicles().forEach(vehicle -> {
                    if (vehicle.isRidesharing()) {
                        vehicle.setVehicleUsage(BUSINESS);
                    }
                }
        );
        fsa.assertTrue(vehicleReviewPage.validateVehicleReviewPageTitle(), "Vehicle Review Page Title");
        fsa.assertTrue(vehicleReviewPage.validateVehicleReviewPageDescription(), "Vehicle Review Page description");
        vehicleReviewPage.addVehicleDetails(applicant);
        WhoShouldWeInsurePage wswip = vehicleReviewPage.returnToWhoShouldWeInsurePage();
        if (wswip.isOnWhoShouldWeInsurePage()) {
            wswip.clickOnContinueButton();
        }
        vehicleReviewPage.validateAllVehicles(applicant, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Vehicle Review Page.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=9"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})},
    		dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLES_REVIEW_TEST})
    public void testValidateMaxOfFiveVehiclesInVehiclesReviewPage_VehiclesReviewTest(AutoApplicant applicant) throws Exception {
        VehicleReviewPage vehicleReviewPage = new AceAutoNavigationHelper().navigateToVehicleReviewPage(applicant);
        vehicleReviewPage.validateMaxFiveVehiclesDisplayed_VehicleReviewPage(applicant);
    }
    // Test description: Validates the Auto behavior for Test Validate Max Of Five Vehicles In Vehicles Review Page Vehicles Review Test.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CO,MI,OR})}, groups = {FFQ_ONEUI,VEHICLES_REVIEW_TEST})
    public void testValidateEditVehicleAndOpenSideSheetInVehiclesReviewPage_VehiclesReviewTest(AutoApplicant applicant) throws Exception {
        VehicleReviewPage vehicleReviewPage = new AceAutoNavigationHelper().navigateToVehicleReviewPage(applicant);
        vehicleReviewPage.validateSidesheetDisplayedForEachVehicles_VehicleReviewPage();
    }
    // Test description: Validates the Auto behavior for Test Validate Edit Vehicle And Open Side Sheet In Vehicles Review Page Vehicles Review Test.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})},
    		dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLES_REVIEW_TEST})
    public void testValidateYMMAndVINMaskedInVehiclesReviewPage_VehiclesReviewTest(AutoApplicant applicant) throws Exception {
        VehicleReviewPage vehicleReviewPage = new AceAutoNavigationHelper().navigateToVehicleReviewPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        vehicleReviewPage.validateYMMAndVINMaskedDisplayedForEachVehicles_VehicleReviewPage(applicant, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Validate YMMAnd VINMasked In Vehicles Review Page Vehicles Review Test.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CO,MI,OR})}, groups = {FFQ_ONEUI,VEHICLES_REVIEW_TEST})
    public void testValidateDateOfPurchaseInVehiclesReviewPage_VehiclesReviewTest(AutoApplicant applicant) throws Exception {
        VehicleReviewPage vehicleReviewPage = new AceAutoNavigationHelper().navigateToVehicleReviewPage(applicant);
        vehicleReviewPage.validateDateOfPurchase_VehicleReviewPage();

    }
    // Test description: Validates the Auto behavior for Test Validate Date Of Purchase In Vehicles Review Page Vehicles Review Test.


    @Skip // This test is no longer applicaple as commute toggle is removed from vehicle review page. This test can be removed in future when we have a clear understanding on the usage of commute toggle in auto journey.
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = CA)}, groups = {FFQ_ONEUI, ADA_SUITE, VEHICLES_REVIEW_TEST, ACE_AUTO_ADA_SUITE})
    public void validateCommuteToggle_VehiclesReviewTest(AutoApplicant applicant) throws Exception {
        VehicleReviewPage vehicleReviewPage = new AceAutoNavigationHelper().navigateToVehicleReviewPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        vehicleReviewPage.validateCommuteToggle(applicant, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Commute Toggle Vehicles Review Test.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
         attributes = @CustomAttribute(name = INCLUDED_STATES, values = {CA}), groups = {FFQ_ONEUI, VEHICLES_REVIEW_TEST})
    public void testValidateQuestionsInCommuteUnderVehiclesReviewPageForCAStateAndProceedToRate(AutoApplicant applicant) throws Exception {
        VehicleReviewPage vehicleReviewPage = new AceAutoNavigationHelper().navigateToVehicleReviewPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        if(vehicleReviewPage.isOnVehiclesReviewPage())
        {
            vehicleReviewPage.validateQuestionsInCommuteInVehicleReviewPageForCAState(applicant, fsa);
        }
        vehicleReviewPage.clickOnContinueButton();
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        driverReviewPage.isOnDriverReviewPage();
        driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
        driverReviewPage.clickContinueButton();
        driverReviewPage.proceedToQuoteSummaryPage(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is supposed to be on the quote summary page");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Validate Questions In Commute Under Vehicles Review Page For CAState And Proceed To Rate.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = VA)},
    		dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLES_REVIEW_TEST})
    public void validateNotToShowAntiTheftRecoverySystemCheckbox_VA_VehiclesReviewTest(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        VehicleReviewPage vehicleReviewPage = new AceAutoNavigationHelper().navigateToVehicleReviewPage(applicant);
        if (vehicleReviewPage.isOnVehiclesReviewPage()) {
            vehicleReviewPage.validateAntiTheftCheckbox_VehicleReviewPage(applicant, fsa);
            fsa.assertAll();
        }
    }
    // Test description: Validates the Auto behavior for Validate Not To Show Anti Theft Recovery System Checkbox VA Vehicles Review Test.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {KY, LA, MA})},
    		dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, VEHICLES_REVIEW_TEST})
    public void validateNotToShowAlternativeFuelCheckbox_VehicleReviewScreen(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        VehicleReviewPage vehicleReviewPage = new AceAutoNavigationHelper().navigateToVehicleReviewPage(applicant);
        if (vehicleReviewPage.isOnVehiclesReviewPage()){
            vehicleReviewPage.validateAlternativeFuelCheckbox_VehicleReviewPage(applicant,fsa);
        }
    }
    // Test description: Validates the Auto behavior for Validate Not To Show Alternative Fuel Checkbox Vehicle Review Screen.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
	    attributes = {@CustomAttribute(name = AutoDataProviders.TWELVE_DRIVERS_AND_VEHICLES), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void validateOnlyVehicleSelectedOnHeresIsWhatWeHaveFoundIsDisplayed(ADPFApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        heresWhatWeFoundPage.setDefinedNumberUncheckVehiclesToTrue(Math.min(applicant.getNumberOfIncompleteVehicles(), 5));
        String fullName = heresWhatWeFoundPage.getPniFullNameFromAutoAdpfApplicant(applicant);
        heresWhatWeFoundPage.addADPFApplicant(Optional.empty(), fullName, applicant.getGender(), applicant.getDateOfBirth());
        List<String> listOfSelectedVehicles = heresWhatWeFoundPage.getVehicleDescriptionForCheckedVehicles();
        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        heresWhatWeFoundPage.clickContinueButton();
        heresWhatWeFoundPage.waitForSpinnerToBeGone();
        fsa.assertTrue(vehicleReviewPage.isOnVehiclesReviewPage(), "User successfully landed on the vehicle review page");
        List<String> displayedVehiclesOnVehiclesReviewPage = vehicleReviewPage.getDescriptionsOfDisplayedVehicles();
        fsa.assertEquals(displayedVehiclesOnVehiclesReviewPage, listOfSelectedVehicles, "Displayed vehicles matches selected vehicles");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Only Vehicle Selected On Heres Is What We Have Found Is Displayed.

}
