package com.farmers.ffq.auto.defaultcoverage;

import static com.farmers.ffq.utils.GlobalVariables.AZ;
import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;

public class DefaultCoverageValuesTests_AZ extends DefaultCoverageBaseTest {
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_15K30K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=No", "AZ_15K30K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 15 K30 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_15K30K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=Yes", "AZ_15K30K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 15 K30 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_20K40K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=No", "AZ_20K40K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 20 K40 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_20K40K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=Yes", "AZ_20K40K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 20 K40 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "AZ_25K50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 25 K50 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "AZ_25K50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 25 K50 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "AZ_30K60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 30 K60 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "AZ_30K60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 30 K60 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "AZ_35K70K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 35 K70 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "AZ_35K70K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 35 K70 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "AZ_50K100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 50 K100 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "AZ_50K100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 50 K100 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "AZ_100K200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 100 K200 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "AZ_100K200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 100 K200 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "AZ_100K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 100 K300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "AZ_100K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 100 K300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No","AZ_250K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 250 K500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "AZ_250K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 250 K500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "AZ_500K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 500 K500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "AZ_500K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 500 K500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_500K1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "AZ_500K1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 500 K1 M NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_500K1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "AZ_500K1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 500 K1 M UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_1M1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "AZ_1M1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 1 M1 M NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_1M1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "AZ_1M1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 1 M1 M UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "AZ_50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 50 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_50K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "AZ_50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 50 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "AZ_75K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 75 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_75K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "AZ_75K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 75 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "AZ_100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 100 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "AZ_100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 100 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "AZ_200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 200 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "AZ_200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 200 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "AZ_300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "AZ_300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "AZ_500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "AZ_500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "AZ_1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 1 M NO UMBRELLA.
	
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AZ)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AZ_1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "AZ_1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AZ 1 M UMBRELLA.

}
