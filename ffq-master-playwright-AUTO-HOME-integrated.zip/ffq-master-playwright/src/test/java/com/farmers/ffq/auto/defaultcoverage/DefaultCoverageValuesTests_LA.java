package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;
import static com.farmers.ffq.utils.GlobalVariables.LA;

public class DefaultCoverageValuesTests_LA extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "LA_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 25 K50 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_25K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "LA_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 25 K65 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "LA_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 30 K60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "LA_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 30 K60 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "LA_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 35 K70 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "LA_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 35 K70 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "LA_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 50 K100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "LA_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 50 K100 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "LA_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 100 K200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "LA_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 100 K200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "LA_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 100 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "LA_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 100 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "LA_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 250 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "LA_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 250 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "LA_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 500 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "LA_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 500 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_500K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "LA_500K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 500 K1000 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_500K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "LA_500K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 500 K1000 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "LA_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 75 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_75K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "LA_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 75 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "LA_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_100K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "LA_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 100 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "LA_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_200K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "LA_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "LA_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = LA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_LA_500K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "LA_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values LA 500 K UMBRELLA.
}
