package com.farmers.ffq.auto;

import com.farmers.framework.AutomationFramework;
import com.farmers.ffq.auto.pages.AutoEnterAddressPage;
import com.farmers.ffq.auto.pages.OneMomentPage;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;

import org.testng.SkipException;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static com.farmers.ffq.utils.GlobalVariables.SPACE;

public class OneMomentTests extends AutomationFramework {

    /**
     * Validate on the loading screen on the submission of address page if the following updated text is present - "We're looking up your current drivers, vehicles and coverage so you can get your quote quickly."
     * Scenario Number: 430 from auto quote and bind sheet
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1")}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, ONE_MOMENT})
    public void validateOneMomentPageContent(AutoApplicant applicant) throws Exception {
        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        autoEnterAddressPage.fillOutEmailAndPhoneIfPresent(applicant.getEmail(), applicant.getPhoneNumber());
        autoEnterAddressPage.enterAddress(applicant.getResidentAddress(), true, false);
        autoEnterAddressPage.fillOutCityIfInvalid(applicant.getCity());
        autoEnterAddressPage.clickAgreeAndSubmitButton();
        OneMomentPage oneMomentPage = new OneMomentPage();
        if (oneMomentPage.isOnOneMomentPage()) {
            FarmersSoftAssert fsa = new FarmersSoftAssert();
            fsa.assertEquals(oneMomentPage.getOneMomentPageTitle(), "One moment, please", "Ome moment page title check");
            fsa.assertEquals(oneMomentPage.getOneMomentPageContent(), "We're looking up your current drivers, vehicles and coverage so you can get your quote quickly.", "One moment page content check");
            fsa.assertAll();
        }
    }
    // Test description: Validates the Auto behavior for Validate One Moment Page Content.
}
