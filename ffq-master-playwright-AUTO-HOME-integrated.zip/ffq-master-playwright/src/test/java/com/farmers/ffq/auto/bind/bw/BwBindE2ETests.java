package com.farmers.ffq.auto.bind.bw;



import com.microsoft.playwright.Page;
import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.common.pages.PaymentSelectionBasePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;

import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.testng.annotations.Test;
import org.testng.annotations.CustomAttribute;


import java.util.List;

import static com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage.MONTHLY_AUTO_PAY_BANK;
import static com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage.MONTHLY_AUTO_PAY_CARD;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.MONTHLY_DIRECT_BILL;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class BwBindE2ETests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwBindE2ETestsPayInFull_NeverHadInsurance(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        getE2EBwBind(applicant, PAY_IN_FULL, true, false);
    }
    // Test description: Validates the Auto behavior for Bw Bind E2 ETests Pay In Full Never Had Insurance.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwBindE2ETestsMonthlyAutoPayBank_NeverHadInsurance(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        getE2EBwBind(applicant, MONTHLY_AUTO_PAY_BANK, true, false);
    }
    // Test description: Validates the Auto behavior for Bw Bind E2 ETests Monthly Auto Pay Bank Never Had Insurance.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwBindE2ETestsMonthlyAutoPayCard_NeverHadInsurance(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        getE2EBwBind(applicant, MONTHLY_AUTO_PAY_CARD, true, false);
    }
    // Test description: Validates the Auto behavior for Bw Bind E2 ETests Monthly Auto Pay Card Never Had Insurance.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwBindE2ETestsMonthlyDirectBill_NeverHadInsurance(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        getE2EBwBind(applicant, MONTHLY_DIRECT_BILL, true, false);
    }
    // Test description: Validates the Auto behavior for Bw Bind E2 ETests Monthly Direct Bill Never Had Insurance.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETestsPayInFull_Expired(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(EXPIRED);
        applicant.setContinuosInsurancePeriod("< 6 Months");
        getE2EBwBind(applicant, PAY_IN_FULL, true, false);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Pay In Full Expired.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E}, enabled = true)
    public void bwE2ETestsMonthlyAutoPayBank_Expired(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(EXPIRED);
        applicant.setContinuosInsurancePeriod("< 6 Months");
        getE2EBwBind(applicant, MONTHLY_AUTO_PAY_BANK, true, false);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Monthly Auto Pay Bank Expired.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETestsMonthlyAutoPayCard_Expired(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(EXPIRED);
        applicant.setContinuosInsurancePeriod("< 6 Months");
        getE2EBwBind(applicant, MONTHLY_AUTO_PAY_CARD, true, false);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Monthly Auto Pay Card Expired.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETestsMonthlyDirectBill_Expired(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(EXPIRED);
        applicant.setContinuosInsurancePeriod("< 6 Months");
        getE2EBwBind(applicant, MONTHLY_DIRECT_BILL, true, false);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Monthly Direct Bill Expired.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETestsPayInFull_ForeignDriver(AutoApplicant applicant) throws Exception {
        applicant.setFirstAgeForeignDriverLicense(18);
        getE2EBwBind(applicant, PAY_IN_FULL, true, false);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Pay In Full Foreign Driver.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, MS, MT, ND, NE, NM, NV, OH, OK, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E}, enabled = true)
    public void bwE2ETestsMonthlyAutoPayBank_ForeignDriver(AutoApplicant applicant) throws Exception {
        applicant.setFirstAgeForeignDriverLicense(18);
        getE2EBwBind(applicant, MONTHLY_AUTO_PAY_BANK, true, false);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Monthly Auto Pay Bank Foreign Driver.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETestsMonthlyAutoPayCard_ForeignDriver(AutoApplicant applicant) throws Exception {
        applicant.setFirstAgeForeignDriverLicense(18);
        getE2EBwBind(applicant, MONTHLY_AUTO_PAY_CARD, true, false);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Monthly Auto Pay Card Foreign Driver.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AR, AZ, CO, CT, FL, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETestsMonthlyDirectBill_ForeignDriver(AutoApplicant applicant) throws Exception {
        applicant.setFirstAgeForeignDriverLicense(18);
        getE2EBwBind(applicant, MONTHLY_DIRECT_BILL, true, false);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Monthly Direct Bill Foreign Driver.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETests_QuoteCustomized_ForeignDriver(AutoApplicant applicant) throws Exception {
        applicant.setFirstAgeForeignDriverLicense(18);
        String paymentMethod = applicant.getStateCode().equals(AL) ? PAY_IN_FULL : getRandomPaymentMethodForBW();
        getE2EBwBind(applicant, paymentMethod, true, true);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Quote Customized Foreign Driver.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETests_QuoteCustomized_NeverHadInsurance(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, true);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Quote Customized Never Had Insurance.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NV, OH, OK, OR, PA, SD, TN, TX, VA, WA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETests_QuoteCustomized_Expired(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(EXPIRED);
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, true);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Quote Customized Expired.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, GA, ID, IL, MI, MO, SD, ND, NE, OR, TN, TX, UT, VA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETests_QuoteCustomized_FinancialFilingInState(AutoApplicant applicant) throws Exception {
        applicant.setFinancialFiling(SR_22);
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Quote Customized Financial Filing In State.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MI, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETests_Deployed(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(DEPLOYED);
        getE2EBwBind(applicant, MONTHLY_DIRECT_BILL, true, false);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Deployed.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETests_NotRequired(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(NOT_REQUIRED);
        getE2EBwBind(applicant, MONTHLY_DIRECT_BILL, true, false);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Not Required.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETests_MultipleVehicleDriver(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus("Never Insured");
        applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Multiple Vehicle Driver.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETests_MoreThanOneInjury(AutoApplicant applicant) throws Exception {
        applicant.getIncidents().forEach(each -> each.setAnyInjuries(true));
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage("Personal");
            each.setParkInResidentAddress(true);
        });
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests More Than One Injury.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=17"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwE2ETests_LessThan6Month(AutoApplicant applicant) throws Exception {
        bwSpecificDataSetUp(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.setContinuosInsurancePeriod("< 6 Months");
        getE2EBwBind(applicant, getRandomPaymentMethodForBW(), true, false);
    }
    // Test description: Validates the Auto behavior for Bw E2 ETests Less Than6 Month.

    /**
     * Validate Back & forth navigation between quote & bind flow add/edit/delete drivers/vehicles/coverages using BW condition  "I was not required to have insurance"
     *
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwBackAndForthTest_NotRequired(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(NOT_REQUIRED);
        getBWBackAndForthSetup(applicant);
    }
    // Test description: Validates the Auto behavior for Bw Back And Forth Test Not Required.

    /**
     * Validate Back & forth navigation between quote & bind flow add/edit/delete drivers/vehicles/coverages using BW condition  "Foreign Driver License"
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MO, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwBackAndForthTest_Foreign(AutoApplicant applicant) throws Exception {
        applicant.setFirstAgeForeignDriverLicense(18);
        getBWBackAndForthSetup(applicant);
    }
    // Test description: Validates the Auto behavior for Bw Back And Forth Test Foreign.

   /**
     * Validate Back & forth navigation between quote & bind flow add/edit/delete drivers/vehicles/coverages using BW condition  "I was in the military or deployed overseas"
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=29"}), @CustomAttribute(name = INCLUDED_STATES, values = {AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KY, LA, MA, MD, MI, MN, SD, MS, MT, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WI, WY})}, dataProviderClass = AutoDataProviders.class, groups = {BW_BIND_E2E})
    public void bwBackAndForthTest_Deployed(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(DEPLOYED);
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage("Personal");
            each.setUseVIN(true);
        });
        getBWBackAndForthSetup(applicant);
    }
    // Test description: Validates the Auto behavior for Bw Back And Forth Test Deployed.

    private void getBWBackAndForthSetup(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Threeoabaa");
        applicant.getVehicles().forEach(each -> {
            each.setVehicleUsage("Personal");
            each.setParkInResidentAddress(true);
        });
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        PaymentSelectionBasePage paymentSelectionBasePage = aceAutoNavigationHelper.navigateToPaymentSelectionPage(applicant);
        paymentSelectionBasePage.clickEnterInfoNavigationBarStepper();
        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        farmersSoftAssert.assertTrue(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is on Who Should We Insure Page after navigating back from Payment Selection Page.");

        // add/edit/delete
        if (!whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            whoShouldWeInsurePage.updateVehiclesAndDrivers(applicant);
        } else {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.updateVehiclesAndDrivers(applicant);
        }

        QuoteSummaryAutoPage quoteSummaryAutoPage = whoShouldWeInsurePage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();

        // capture the discounts listed on the quote summary page
        List<String> discountsListedOnQuoteSummaryPage = quoteSummaryAutoPage.getDisplayedDiscounts();
        quoteSummaryAutoPage.updateLiabilityAndCustomizeForBW();
        quoteSummaryAutoPage.closeAdjustmentDialogIfPresent();
        quoteSummaryAutoPage.updateVehicleCoverageAndCustomizeForBW();
        quoteSummaryAutoPage.closeAdjustmentDialogIfPresent();

        // navigate to payment page
        navigateFromQuoteSummaryPageToPaymentSelectionPage();

        // capture the discounts on the payment page
        List<String> displayedDiscountsOnThePaymentSelectionPage = paymentSelectionBasePage.getDisplayedDiscounts();

        // validate the discounts are same on both pages
        farmersSoftAssert.assertTrue(aceAutoNavigationHelper.isExpectedListIncludedInActual(discountsListedOnQuoteSummaryPage, displayedDiscountsOnThePaymentSelectionPage), "Discounts listed on Quote Summary Page and Payment Selection Page are not included after modifications.");
        Log.info("discountsListedOnQuoteSummaryPage: " + discountsListedOnQuoteSummaryPage);
        Log.info("displayedDiscountsOnThePaymentSelectionPage: " + displayedDiscountsOnThePaymentSelectionPage);
        // navigate back to quote summary page
        paymentSelectionBasePage.clickReviewQuoteNavigationBarStepper();
        farmersSoftAssert.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on Quote Summary Page after navigating back from Payment Selection Page.");

        // navigate to payment page and sign documents and add payment method to complete binding
        navigateFromQuoteSummaryPageToPaymentSelectionPage();
        processBwDocuSignAndPayments(PAY_IN_FULL, !Property.getTestProperty("environment").equals("prod"));
        farmersSoftAssert.assertAll();
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}),
            @CustomAttribute(name = EXCLUDED_STATES, values = {CA})},
            dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS_TESLA})
    public void bwBindE2ETestsPayInFull_NeverHadInsuranceTempTestForTesla(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        randomizeApplicantPersonalData(applicant);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        QuoteSummaryAutoPage quoteSummaryAutoPage = aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Successfully navigated to Quote Summary Auto Page");
        testStepAssert(quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false), "Successfully navigated to Payment Selection Page");
        softAssert.assertAll();
    }
    // Test description: Validates the Auto behavior for Bw Bind E2 ETests Pay In Full Never Had Insurance Temp Test For Tesla.
}
