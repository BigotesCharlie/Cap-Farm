package com.farmers.ffq.auto;


import com.microsoft.playwright.Page;
import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoContinueToPaymentOneUI;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoDriverSectionOneUI;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoSignalEnrollmentSectionOneUI;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoVehicleSectionOneUI;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper.quoteFlow;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.Vehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import net.datafaker.Faker;
import org.apache.commons.lang3.RandomUtils;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class KnockoutTests extends BaseTest {

    //Test Data of Existing Customer is updated in OneUIAutoTestData.xlsx from successful Bind E2E Tests of Pipeline Job.
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_TEST_CATEGORY_VALIDATION_DATA_PROVIDER, suiteName = "existing customer knockout", dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI}, enabled = true)
    public void testExistingCustomerKnockout(AutoApplicant applicant) throws Exception {
        if (!Property.getUri().contains(RA11_ENVIRONMENT)) {
            throw new SkipException("Skipping this test case as the Existing Customer data is only applicable for regression env");
        }

        AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
        autoEnterAddressPage.fillOutAddressPage(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        knockoutInconveniencePage.isOnKnockOutPage();
        fsa.assertTrue(knockoutInconveniencePage.verifyExistingCustomerKnockout(), "Existing Customer Knockout Page");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Existing Customer Knockout.

    @Test(groups = {KNOCKOUT_TESTS, FFQ_ONEUI}, enabled = false)
    public void testRestrictedZipCodeSpecialAttention() throws Exception {
        if (Property.getUri().contains(TSK1_ENVIRONMENT)) {
            new LandingPage().enterLandingPageData(LOB_AUTO, "85253");
            KnockoutLeadFormPage knockoutLeadFormPage = new KnockoutLeadFormPage();
            FarmersSoftAssert fsa = new FarmersSoftAssert();
            knockoutLeadFormPage.validatePageContent(fsa);
            fsa.assertAll();
        }
    }
    // Test description: Validates the Auto behavior for Test Restricted Zip Code Special Attention.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI}, enabled = false)
    public void testSpecialAttentionKOFromAddressPage_EG005(AutoApplicant applicant) throws Exception {
        if (Property.getUri().contains(TSK1_ENVIRONMENT)) {
            applicant.setZipCode("61615");
            applicant.setResidentAddress("373 E High Point Rd");
            AutoEnterAddressPage autoEnterAddressPage = new AceAutoNavigationHelper().navigateToAutoEnterAddressPage(applicant);
            String fullAddress = "373 E High Point Rd Peoria IL 61614";
            autoEnterAddressPage.enterAddress(fullAddress);
            KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
            Assert.assertTrue(knockoutInconveniencePage.verifySpecialAttentionKOFromAddressPage_EG005(), "Validate Zip Failure Knockout from Address Page Failed--Failure Code : EG005");
        }
    }
    // Test description: Validates the Auto behavior for Test Special Attention KOFrom Address Page EG005.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=12"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA})},
    		dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI})
    public void testSpecialAttentionKOFromDriverReviewPage_EK32_SixDriver(AutoApplicant applicant) throws Exception {
        applicant.getVehicles().forEach(vehicle -> {
            vehicle.setUseVIN(false);
            vehicle.setRidesharing(false);
            vehicle.setVehicleUsage("Personal");
        });

        applicant.setLastName(new Faker().name().lastName());
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper(quoteFlow.AGENT).navigateToDriverReviewPage(applicant);
        driverReviewPage.setMaritalRelationToSomeOneNotListed(applicant, true, false);
        driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
        driverReviewPage.enterDriverLicenseAge(applicant, "Jane" + SPACE + applicant.getLastName(), 16);
        driverReviewPage.clickContinueButton();
        if (!driverReviewPage.isSignalDiscountDisabledState(applicant.getStateCode())) {
            SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
            signalPageOneUI.processSignalPage(RandomUtils.nextBoolean());
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        contactInfoAutoPage.isOnContactInfoAutoPage();
        boolean isRealAgentAssigned = driverReviewPage.isRealAgentAssigned();
        String realAgentName = null;
        if (isRealAgentAssigned) {
            realAgentName = contactInfoAutoPage.getAssignedRealAgentName();
        }
        String quoteNumber = contactInfoAutoPage.getAceQuoteNumberInThePage();
        contactInfoAutoPage.setValuesAndContinue(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        knockoutInconveniencePage.verifySpecialAttentionKOFromDriverReviewPage_EK32(quoteNumber, realAgentName, isRealAgentAssigned, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Special Attention KOFrom Driver Review Page EK32 Six Driver.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA,NJ,FL})}, dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI})
    public void testSpecialAttentionKOFromVehiclePage_VEH007_High_End_Vehicle(AutoApplicant applicant) throws Exception {
        Log.info("Updating data to single driver with high end vehicle for KO scenario");
        applicant.setHaveAccidentOrViolations(false);
        applicant.setIncidents(Collections.emptyList());
        applicant.setMaritalStatus(SINGLE);
        applicant.getAdditionalDrivers().clear();
        Vehicle vehicle = applicant.getVehicles().get(0);
        vehicle.setUseVIN(true);
        applicant.setTestScenario(HIGH_END_VEHICLE + " : " + applicant.getTestScenario());

        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        ContactInfoAutoPage contactInfoAutoPage = aceAutoNavigationHelper.navigateToContactInfoAutoPage(applicant);
        boolean realAgentAssigned = contactInfoAutoPage.isRealAgentAssigned();
        String quoteNumber = contactInfoAutoPage.getSessionStorageAppStore().getData().getQuoteNumber();
        String realAgentName = null;
        if (realAgentAssigned) {
            realAgentName = contactInfoAutoPage.getAssignedRealAgentName();
        }
        contactInfoAutoPage.setValuesAndContinue(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        knockoutInconveniencePage.verifySpecialAttentionKOFromVehiclePage_VEH007(quoteNumber, realAgentAssigned, realAgentName, fsa);
        fsa.assertAll();

    }
    // Test description: Validates the Auto behavior for Test Special Attention KOFrom Vehicle Page VEH007 High End Vehicle.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA})}, dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI})
    public void testSpecialAttentionKOFromJAFMT_Page_VEH007_High_End_Vehicle(AutoApplicant applicant) throws Exception {
    	updateApplicantDataToAvoidPossibleBw(applicant);
    	Log.info("Updating data to single driver with high end vehicle for KO scenario");
    	applicant.getIncidents().clear(); // removing other BW possibilities
    	// updating the vehicle with high-end VIN
    	applicant.getVehicles().forEach(vehicle -> {
    		vehicle.setUseVIN(false);
    		vehicle.setOwnership("Owned");
    	});

    	new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
    	AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
    	AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
    	AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
    	AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
    	KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
    	AppStore retrieveQuoteResponseSessionStorage = additionalInfoVehicleSectionOneUI.getSessionStorageAppStore();
    	if (additionalInfoVehicleSectionOneUI.vinNumberTextBoxElementList.count() < 1) {
    		testStep("Due to adpf data we are unable to finish this job", true);
    	} else {
    		FarmersSoftAssert fsa = new FarmersSoftAssert();
    		additionalInfoVehicleSectionOneUI.enterVinNumber(additionalInfoVehicleSectionOneUI.vinNumberTextBoxElementList.nth(0), "ZHWUC1ZD0FLA03325");
    		additionalInfoDriverSectionOneUI.enterDriverLicenseNumber(retrieveQuoteResponseSessionStorage);
    		additionalInfoDriverSectionOneUI.enterMatureDriverSafetyCourseDate(retrieveQuoteResponseSessionStorage.getData().getLandingStateCode());
    		additionalInfoSignalEnrollmentSectionOneUI.verifySignalEnrollmentSection(retrieveQuoteResponseSessionStorage, true, fsa);
    		boolean isRealAgentAssigned = additionalInfoContinueToPaymentOneUI.isRealAgentAssigned();
    		String realAgentName = null;
    		if (isRealAgentAssigned) {
    			realAgentName = additionalInfoContinueToPaymentOneUI.getAssignedRealAgentName();
    		}
    		String quoteNumber = additionalInfoContinueToPaymentOneUI.getAceQuoteNumberInThePage();

    		additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();
    		additionalInfoDriverSectionOneUI.waitForSpinnerToBeGone();
    		knockoutInconveniencePage.verifySpecialAttentionKOFromVehiclePage_VEH007(quoteNumber, isRealAgentAssigned, realAgentName, fsa);
    		fsa.assertAll();
    	}
    }
    // Test description: Validates the Auto behavior for Test Special Attention KOFrom JAFMT Page VEH007 High End Vehicle.

    @Skip
    @Test(groups = {KNOCKOUT_TESTS, FFQ_ONEUI})
    public void testFarmersDoesNotOfferBusiness_EG004() throws Exception {
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        new LandingPage(knockoutInconveniencePage.isUseMobileViewEnabled()).enterLandingPageData(LOB_AUTO, "19940");
        Assert.assertTrue(knockoutInconveniencePage.validateFarmersDoesNotOfferBusinessKO_EG004(), "State TurnedOff Inconvenience Page--> Error Code: EG004");
    }
    // Test description: Validates the Auto behavior for Test Farmers Does Not Offer Business EG004.

    @Test(groups = {KNOCKOUT_TESTS, FFQ_ONEUI})
    public void validateKOforRestrictedAWSZIPCode_MI() throws Exception {
        navigate(Property.getUri() + "?Lob=Auto&Source_Indicator=AS&State_Code=MI&Agent_Code=711561&Zip_Code=48152");
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateQuoteNotAvailableKO();
    }
    // Test description: Validates the Auto behavior for Validate KOfor Restricted AWSZIPCode MI.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
    		attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, KY, MA, NM}), @CustomAttribute(name = FILTER, values = "applicantId=1")},
    		dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, KNOCKOUT_TESTS})
    public void testFinancialFilingInAnotherStateForApplicant(AutoApplicant applicant) throws Exception {
        applicant.setLastName(new Faker().name().lastName());
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        if (aceAutoNavigationHelper.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            aceAutoNavigationHelper.navigateToSignalPage(applicant);
        } else {
            DriverReviewPage driverReviewPage = aceAutoNavigationHelper.navigateToDriverReviewPage(applicant);
            applicant.setFinancialFiling(SR_22_ANOTHER_STATE);
            driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
            driverReviewPage.clickContinueButton();
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        boolean realAgentAssigned = contactInfoAutoPage.isRealAgentAssigned();

        //Signal page processed
        if (!contactInfoAutoPage.isSignalDiscountDisabledState(applicant.getStateCode())) {
            SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
            fsa.assertTrue(signalPageOneUI.isOnSignalPage(), "Did not reach the signal page");
            signalPageOneUI.processSignalPage(false);
        }
        //Contact Info Page processed
        contactInfoAutoPage.isOnContactInfoAutoPage();
        String quoteNumber = contactInfoAutoPage.getSessionStorageAppStore().getData().getQuoteNumber();
        contactInfoAutoPage.setValuesAndContinue(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        if (knockoutInconveniencePage.isOnKnockOutPage()) {
            knockoutInconveniencePage.validateFinancialFilingInAnotherState(fsa, quoteNumber, realAgentAssigned);
        } else if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
            quoteSummaryAutoPage.isOnQuoteSummaryAutoPage();
        } else {
            Log.info("User did not land on the KO page or Bw Switch page");
        }

        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Financial Filing In Another State For Applicant.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, KY, MA, NM})},
    		dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI})
    public void testFinancialFilingInAnotherStateKOForAdditionalDriver(AutoApplicant applicant) throws Exception {

        applicant.setLastName(new Faker().name().lastName());
        applicant.setFinancialFiling(SR_22_ANOTHER_STATE);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        if(aceAutoNavigationHelper.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            aceAutoNavigationHelper.navigateToSignalPage(applicant);
        } else {
            DriverReviewPage driverReviewPage = aceAutoNavigationHelper.navigateToDriverReviewPage(applicant);
            driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
            driverReviewPage.clickContinueButton();
        }

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        //Signal page processed
        if (!aceAutoNavigationHelper.isSignalDiscountDisabledState(applicant.getStateCode())) {
            new SignalPageOneUI().processSignalPage(false);
        }

        //Contact Info Page processed
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        boolean realAgentAssigned = contactInfoAutoPage.isRealAgentAssigned();
        new ContactInfoAutoPage().setValuesAndContinue(applicant);
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
            continueWithBristolWestPage.waitForSpinnerToBeGone();
        }
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            String stateCode = applicant.getStateCode();
            if (stateCode.equals(VA)) {
                vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
            } else if (Arrays.asList(CA,NC).contains(stateCode)) {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
            }
        }
        BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
        if(bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
            bristolWestAdditionalDiscountsPage.clickContinue();
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        if (quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            Log.info("Quote ended on the quote summary page instaed of the KO");
            Log.info("Please check the logs for the following quote number = " + quoteSummaryAutoPage.getAceQuoteNumberInThePage());
        } else {
            KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
            knockoutInconveniencePage.closeQualtricsPopUp();
            knockoutInconveniencePage.validateFinancialFilingInAnotherState(fsa, aceAutoNavigationHelper.getSessionStorageAppStore().getData().getQuoteNumber(), realAgentAssigned);
        }
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Financial Filing In Another State KOFor Additional Driver.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=36"}), @CustomAttribute(name = VA)},
    		dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI})
    public void validateKnockoutPageBecauseOfRideshareInVA(AutoApplicant applicant) throws Exception {
        applicant.getVehicles().forEach(each -> {
            each.setRidesharing(true);
            each.setVehicleUsage("Rideshare");
        });
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        contactInfoAutoPage.waitForSpinnerToBeGone();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        testStepAssert(knockoutInconveniencePage.isOnKnockOutPage(), "User successfully landed on the KO page");
        testStepAssert(knockoutInconveniencePage.getPageDescription(), "Please contact your Farmers agent if you'd like to continue this quote and discuss options for purchasing Rideshare and Food Delivery coverage.", "VA state Rideshare KO Page description validation");
    }
    // Test description: Validates the Auto behavior for Validate Knockout Page Because Of Rideshare In VA.

    /**
    This test checks if quote gets KO with foreign dl license selection from who should we insure page
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=32"}), @CustomAttribute(name = CA)},
            dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI})
    public void validateKO_Spouse_With_Foreign_DL_CA_State_WhoShouldWeInsurePage(AutoApplicant applicant) throws Exception {
        applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));
        applicant.getAdditionalDrivers().get(0).setOccupation(EMPTY_STRING);
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue();
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if(vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            if(applicant.getStateCode().equals(VA)) {
                vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
            } else {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
            }
        }

        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        knockoutInconveniencePage.validateFGIA_KO_Page(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate KO Spouse With Foreign DL CA State Who Should We Insure Page.

    /**
    This test checks if quote gets KO with foreign dl license selection from Driver Review Page
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = CA)},
            dataProviderClass = AutoDataProviders.class, groups = {KNOCKOUT_TESTS, FFQ_ONEUI})
    public void validateKO_Spouse_With_Foreign_DL_CA_State_DriverReviewPage(AutoApplicant applicant) throws Exception {
        applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));
        randomizeApplicantPersonalData(applicant);
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        driverReviewPage.setMaritalRelationToSomeOneNotListed(applicant, true, true);
        driverReviewPage.reviewAllDrivers(applicant, Optional.empty());
        driverReviewPage.clickContinueButton();
        if (!driverReviewPage.isSignalDiscountDisabledState(applicant.getStateCode())) {
            SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
            signalPageOneUI.processSignalPage(RandomUtils.nextBoolean());
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        contactInfoAutoPage.isOnContactInfoAutoPage();
        contactInfoAutoPage.setValuesAndContinue(applicant);
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if(vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            if(applicant.getStateCode().equals(VA)) {
                vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
            } else {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
            }
        }
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        knockoutInconveniencePage.validateFGIA_KO_Page(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate KO Spouse With Foreign DL CA State Driver Review Page.

    /**
     * validate KO for NJ Customer with NY Commute yes
     */

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {NJ}), @CustomAttribute(name = FILTER, values = "applicantId=1")},
            dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS})
    public void validateNY_Commuter_KO_For_NJ_User(AutoApplicant applicant) throws Exception {
        updateLastNameForBristolWest(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setTestScenario(getRandomBdqFlow(applicant.getStateCode()) + NEW_YORK_COMMUTER + "-> " + applicant.getTestScenario());
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        knockoutInconveniencePage.validateNYCommuterForNJCustomer();
    }
    // Test description: Validates the Auto behavior for Validate NY Commuter KO For NJ User.


    /**
     "Steps:
     a. Create a Farmers quote from AWS URL
     b. Update the URL to RA11 before redirecting to Famers.
     c. Enter a vehicle with 1FDAF56P15EB87274
     d. Navigate untill Rate screen.
     e. Quote will be knocked out
     Expected result:
     Google maps key is not displayed when auto quote is knocked out"
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {NJ, FL, CA}), @CustomAttribute(name = FILTER, values = "applicantId=1")},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateGoogleMapsIsNotDisplayedWhenKnockedOut(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(HIGH_END_VEHICLE + SPACE + applicant.getTestScenario());
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper(quoteFlow.AGENT).navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        FarmersSoftAssert farmersSoftAssert = new FarmersSoftAssert();
        knockoutInconveniencePage.validateMapIsNotPresentInAutoKO(farmersSoftAssert);
        farmersSoftAssert.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Google Maps Is Not Displayed When Knocked Out.

}
