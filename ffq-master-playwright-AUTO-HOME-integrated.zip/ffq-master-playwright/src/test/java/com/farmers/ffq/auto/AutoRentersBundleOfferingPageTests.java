package com.farmers.ffq.auto;


import com.microsoft.playwright.Page;
import com.farmers.ffq.BaseTest;
import com.farmers.ffq.ace.bundle.AceBundleFinalReviewPage;
import com.farmers.ffq.ace.bundle.AceBundleReviewQuotesPage;
import com.farmers.ffq.ace.hrc.common.AceHRCAdditionalCoveragesBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCContactInfoBasePage;
import com.farmers.ffq.ace.hrc.common.AceHRCJustAFewMoreThingsBasePage;
import com.farmers.ffq.ace.renters.AceRentersReviewQuotePage;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.auto.pages.bindpages.AutoPolicyPaymentBasePage;
import com.farmers.ffq.auto.pages.bindpages.ConsolidatedPaymentPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;
import com.farmers.framework.report.Log;
import net.datafaker.Faker;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;


public class AutoRentersBundleOfferingPageTests extends BaseTest {

    private static final String AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST = "autoRentersBundleOfferingPageTest";


    /*

    Eligibility Criteria-
Project code 'RB' should be enabled.
Zipcode should be eligible for renters' quote.
Should not select (I, or my spouse/domestic partner, own this residence) checkbox on the personal info page.
Home_behavior_code should be “AB" / "BC" (getPrefillData response).
Should not have an existing HRC policy.
Should not be a retrieved quote.
Should not be brightlined quote.
     */


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, MA, MS, NC, AK, DC, DE, FL, HI, KY, LA, ME, MT, NH, NJ, NV, NY, RI, SC, VT, WV}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST})
    public void validatePageContent_AutoRentersBundleOfferingPage(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        applicant.getDiscounts().get(0).setOwnOrRentHome("Rent a home");
        ContactInfoAutoPage contactInfoAutoPage = aceAutoNavigationHelper.navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        AutoRentersBundleOfferingPage autoRentersBundleOfferingPage = new AutoRentersBundleOfferingPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        autoRentersBundleOfferingPage.waitForSpinnerToBeGone();
        if (!autoRentersBundleOfferingPage.isOnAutoRentersBundleOfferingPage() || quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            Log.info("User is not navigated to Auto Renters Bundle Offering Page, cannot validate the page content. Stopping the test.");
            fsa.assertAll();
            return;
        }
        fsa.assertTrue(autoRentersBundleOfferingPage.isOnAutoRentersBundleOfferingPage(), "User is not navigated to Auto Renters Bundle Offering Page");
        autoRentersBundleOfferingPage.validatePageContent(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Page Content Auto Renters Bundle Offering Page.

    /**
     * Validates that we don't get navigated to Auto Renters Bundle Offering page if the user selects "Own" for "Do you or your spouse/domestic partner own or rent your home?" question on personal info page, even if the zip code is eligible for renters bundle offer. User should be able to continue with monoline auto quote flow and should land on quote summary page after submitting contact information.
     *
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, MA, MS, NC, AK, DC, DE, FL, HI, KY, LA, ME, MT, NH, NJ, NV, NY, RI, SC, VT, WV}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST})
    public void validateWeDontGetPageWithHomeOwner_AutoRentersBundleOfferingPage(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        applicant.getDiscounts().get(0).setOwnOrRentHome("Own");
        ContactInfoAutoPage contactInfoAutoPage = aceAutoNavigationHelper.navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        AutoRentersBundleOfferingPage autoRentersBundleOfferingPage = new AutoRentersBundleOfferingPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertFalse(autoRentersBundleOfferingPage.isOnAutoRentersBundleOfferingPage(), "User is NOT navigated to Auto Renters Bundle Offering Page");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate We Dont Get Page With Home Owner Auto Renters Bundle Offering Page.


    /**
     *
     * "Scenario : User Initiates an Auto monoline quote and when submitting Contact information page a New interstitial page should be displayed,
     * User selects for Bundle option and should land on Bundle Quote summary page and then Bind the quote as like normal bundle"
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, MA, MS, NC, AK, DC, DE, FL, HI, KY, LA, ME, MT, NH, NJ, NV, NY, RI, SC, VT, WV}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST})
    public void validateMonolineFlow_AutoRentersBundleOfferingPage(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        applicant.setFirstName(new Faker().name().firstName());
        applicant.setLastName("Brown");
        applicant.getDiscounts().get(0).setOwnOrRentHome("Rent a home");
        ContactInfoAutoPage contactInfoAutoPage = aceAutoNavigationHelper.navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        AutoRentersBundleOfferingPage autoRentersBundleOfferingPage = new AutoRentersBundleOfferingPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();

        if (!autoRentersBundleOfferingPage.isOnAutoRentersBundleOfferingPage() || quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            Log.info("User is not navigated to Auto Renters Bundle Offering Page, cannot continue with renters bundle flow. Stopping the test.");
            fsa.assertAll();
            return;
        }
        fsa.assertTrue(autoRentersBundleOfferingPage.isOnAutoRentersBundleOfferingPage(), "User is not navigated to Auto Renters Bundle Offering Page");
        autoRentersBundleOfferingPage.processRentersBundleOfferingPage(false);
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is not navigated to Auto Quote Review Summary Page after clicking continue without renters discount on Auto Renters Bundle Offering Page");
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        completePurchase(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Monoline Flow Auto Renters Bundle Offering Page.

    /**
     * 718 and 719 test scenarios from Auto Quote and Bind sheet
     * Scenario : User Initiates an Auto monoline quote and when submitting Contact information page a New interstitial page should be displayed,
     */

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CA, CT, MA, MS, NC, AK, DC, DE, FL, HI, KY, LA, ME, MT, NH, NJ, NV, NY, RI, SC, VT, WV}), @CustomAttribute(name = FILTER, values = {"applicantId=1"})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, AUTO_RENTERS_BUNDLE_OFFERING_PAGE_TEST})
    public void validateRentersBundleFlow_AutoRentersBundleOfferingPage(AutoApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        applicant.setFirstName(new Faker().name().firstName());
        applicant.getDiscounts().get(0).setOwnOrRentHome("Rent a home");
        ContactInfoAutoPage contactInfoAutoPage = aceAutoNavigationHelper.navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        AutoRentersBundleOfferingPage autoRentersBundleOfferingPage = new AutoRentersBundleOfferingPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        if (!autoRentersBundleOfferingPage.isOnAutoRentersBundleOfferingPage()) {
            Log.info("User is not navigated to Auto Renters Bundle Offering Page, cannot continue with renters bundle flow. Stopping the test.");
            return;
        }
        fsa.assertTrue(autoRentersBundleOfferingPage.isOnAutoRentersBundleOfferingPage(), "User is not navigated to Auto Renters Bundle Offering Page");
        autoRentersBundleOfferingPage.processRentersBundleOfferingPage(true);
        AceBundleReviewQuotesPage aceBundleReviewQuotesPage = new AceBundleReviewQuotesPage();

        // Here are your quotes! page
        fsa.assertTrue(aceBundleReviewQuotesPage.isOnBundleReviewQuotesPage(), "User is not navigated to Ace Bundle Review Quotes Page after selecting to add renters discount on Auto Renters Bundle Offering Page");
        aceBundleReviewQuotesPage.clickNextButton();

        // Auto Quote Review Summary Page
        QuoteSummaryAutoPage quoteSummaryPage = new QuoteSummaryAutoPage();
        fsa.assertTrue(quoteSummaryPage.isOnQuoteSummaryAutoPage(), "User is not navigated to Auto Quote Review Summary Page after clicking next button on Ace Bundle Review Quotes Page");
        quoteSummaryPage.clickNextToReviewPropertyCoveragePage();

        // Renters Review Quote Page
        AceRentersReviewQuotePage aceRentersReviewQuotePage = new AceRentersReviewQuotePage();
        fsa.assertTrue(aceRentersReviewQuotePage.isOnReviewQuotePageAceRenters(), "User is not navigated to HRC Review Quote Base Page after clicking next button on Auto Quote Review Summary Page");
        aceRentersReviewQuotePage.clickReviewMoreRentersCoveragesButton();

        // Renters optional coverages page
        AceHRCAdditionalCoveragesBasePage propertyOptionalCoveragesPage = new AceHRCAdditionalCoveragesBasePage();
        fsa.assertTrue(propertyOptionalCoveragesPage.isOnOptionalCoveragesPageForRenters(), "User is not navigated to Bundle Property Optional Coverages Page after clicking continue to more coverages button on HRC Review Quote Page");
        propertyOptionalCoveragesPage.clickContinueToFinalWrapupButton(true);

        // Property policy start date /Other policy details page
        AceHRCContactInfoBasePage aceHRCContactInfoBasePage = new AceHRCContactInfoBasePage();
        aceHRCContactInfoBasePage.clickContinueButton();

        // Auto policy additional info page
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AdditionalInfoPolicyStartDateOneUI();
        fsa.assertTrue(additionalInfoPolicyStartDateOneUI.isOnAdditionalInfoPage(), "User is not navigated to Auto Policy Additional Info Page after clicking continue button on Property policy start date page");
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage();
        additionalInfoPolicyStartDateOneUI.waitForSpinnerToBeGone();

        //  HRC additional info page
        AceHRCJustAFewMoreThingsBasePage aceHRCJustAFewMoreThingsBasePage = new AceHRCJustAFewMoreThingsBasePage();
        fsa.assertTrue(aceHRCJustAFewMoreThingsBasePage.isOnBundleJMFTPage(25), "User is not navigated to Bundle JMFT Page after filling out Auto Policy Additional Info Page and clicking continue button");
        aceHRCJustAFewMoreThingsBasePage.clickContinueButton();
        aceHRCJustAFewMoreThingsBasePage.waitForRC3ToBeGone();


        AceBundleFinalReviewPage aceBundleFinalReviewPage = new AceBundleFinalReviewPage();
        fsa.assertTrue(aceBundleFinalReviewPage.isOnFinalReviewPage(), "User is not navigated to Ace Bundle Final Review Page after clicking continue button on Bundle JMFT Page");
        aceBundleFinalReviewPage.clickContinueToPaymentButton();

        AutoPolicyPaymentBasePage autoPolicyPaymentBasePage = new AutoPolicyPaymentBasePage();
        fsa.assertTrue(autoPolicyPaymentBasePage.isOnContinueToPaymentPage(), "User is not navigated to Auto Policy Payment Page after clicking continue button on Ace Bundle Final Review Page");
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        fsa.assertTrue(consolidatedPaymentPage.isPageHeaderCorrect("First up: Pay for auto"), "Page header is not correct on Auto Policy Payment Page");
        consolidatedPaymentPage.processConsolidatedPaymentPage(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true);
        consolidatedPaymentPage.waitForSpinnerToBeGone();
        fsa.assertTrue(consolidatedPaymentPage.isPageHeaderCorrect("Next: Pay for property"), "Page header is not correct on Consolidated Payment Page after submitting payment for auto policy");
        consolidatedPaymentPage.processConsolidatedPaymentPage(PAY_IN_FULL, PaymentMethods.VISA_CREDIT_CARD_1, true);

        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Renters Bundle Flow Auto Renters Bundle Offering Page.

    // isOnBundleReviewQuotesPage

}
