package com.farmers.ffq.home.e2e;

import com.farmers.framework.AutomationFramework;
import com.farmers.ffq.homehappypath.config.HomeScenarioData;
import com.farmers.ffq.homehappypath.flow.HomeHappyPathFlow;
import org.testng.annotations.Test;

/** Functional HOME Happy Path imported from ffq-homeHP-e2e and hosted by the master Playwright lifecycle. */
public class HomeHappyPathE2ETest extends AutomationFramework {

    // Test description: HOME deterministic happy path imported from ffq-homeHP-e2e.
    @Test(groups = {"HOME_E2E", "SMOKE_HOME"}, description = "HOME deterministic happy path E2E")
    public void homeDomHappyPathE2E() {
        page().setViewportSize(1440, 1000);
        String startUrl = HomeE2EEnvironment.startUrl();
        HomeScenarioData scenario = HomeScenarioData.domHappyPath();
        new HomeHappyPathFlow(page(), scenario, startUrl).run(startUrl);
    }
}
