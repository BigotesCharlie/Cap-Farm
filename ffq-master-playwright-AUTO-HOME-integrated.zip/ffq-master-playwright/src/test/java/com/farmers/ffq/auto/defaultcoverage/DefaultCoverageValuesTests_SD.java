package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;
import static com.farmers.ffq.utils.GlobalVariables.SD;

public class DefaultCoverageValuesTests_SD extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "SD_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 100 K200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "SD_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 100 K200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "SD_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 100 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "SD_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 100 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "SD_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "SD_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 100 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_150K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=No", "SD_150K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 150 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_150K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=Yes", "SD_150K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 150 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_1M1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "SD_1M1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 1 M1 M NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_1M1M_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "SD_1M1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 1 M1 M UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "SD_1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 1 M NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_1M_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "SD_1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 1 M UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "SD_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "SD_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "SD_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 250 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "SD_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 250 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "SD_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 25 K50 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "SD_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 25 K50 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_25K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=No", "SD_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 25 K65 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_25K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=Yes", "SD_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 25 K65 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "SD_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 300 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "SD_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 300 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "SD_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "SD_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "SD_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 30 K60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "SD_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 30 K60 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_30K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=No", "SD_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 30 K65 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_30K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=Yes", "SD_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 30 K65 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "SD_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 35 K70 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "SD_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 35 K70 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_35K80K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=No", "SD_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 35 K80 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_35K80K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=Yes", "SD_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 35 K80 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_35K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=No", "SD_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 35 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_35K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=Yes", "SD_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 35 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_45K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=No", "SD_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 45 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_45K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=Yes", "SD_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 45 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_500K1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "SD_500K1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 500 K1 M NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_500K1M_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "SD_500K1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 500 K1 M UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "SD_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 500 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "SD_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 500 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "SD_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "SD_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "SD_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 50 K100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "SD_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 50 K100 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "SD_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 50 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "SD_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 50 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=No", "SD_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=Yes", "SD_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 60 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "SD_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 75 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_75K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "SD_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 75 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_85K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=No", "SD_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 85 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_85K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=Yes", "SD_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 85 K UMBRELLA.

}
