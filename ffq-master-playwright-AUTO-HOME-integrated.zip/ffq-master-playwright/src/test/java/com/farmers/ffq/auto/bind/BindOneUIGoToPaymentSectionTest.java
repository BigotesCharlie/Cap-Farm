package com.farmers.ffq.auto.bind;



import com.microsoft.playwright.Page;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class BindOneUIGoToPaymentSectionTest extends AutomationFramework {

    @Skip //validateAceAutoConsolidatedPaymentPage_F76393 test method covers both payment pages
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, FFQ_BIND_PAYMENT_SUMMARY_PAGE, FFQ_ACE_SMOKE}, enabled = false)
    public void bindOneUIAutoQuoteGoToPaymentSection(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();

        additionalInfoContinueToPaymentOneUI.validatePurchasePage(fsa);
        String quoteNumber = additionalInfoContinueToPaymentOneUI.getSessionStorageAppStore().getData().getQuoteNumber();
        additionalInfoContinueToPaymentOneUI.logInfoMessage(quoteNumber);
        Log.info("Ace Auto - Payment Summary Page. Quote number: " + quoteNumber, true);
        additionalInfoContinueToPaymentOneUI.addSauceLabsLinkInLog();
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Bind One UIAuto Quote Go To Payment Section.

    @Skip// The feature is moved from r11 scope
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.SERVICE_VIRTUALIZATION_APPLICANT, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {WY})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, "preferredPaymentMethod"}, enabled = false)
    public void validatePaymentPageWithPreferredPaymentPlan_F67015(AutoApplicant applicant) throws Exception {
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        additionalInfoContinueToPaymentOneUI.validatePreferredPaymentPlanChanges(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Payment Page With Preferred Payment Plan F67015.

}
