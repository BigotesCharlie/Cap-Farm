package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class DefaultCoverageValuesTests_PA extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_15K30K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=No", "PA_15K30K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 15 K30 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_15K30K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=Yes", "PA_15K30K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 15 K30 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_20K40K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=No", "PA_20K40K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 20 K40 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_20K40K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=Yes", "PA_20K40K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 20 K40 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "PA_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 25 K50 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "PA_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 25 K50 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_25K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=No", "PA_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 25 K65 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_25K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=Yes", "PA_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 25 K65 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "PA_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 30 K60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "PA_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 30 K60 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_30K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=No", "PA_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 30 K65 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_30K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=Yes", "PA_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 30 K65 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "PA_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 35 K70 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "PA_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 35 K70 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_35K80K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=No", "PA_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 35 K80 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_35K80K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=Yes", "PA_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 35 K80 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "PA_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 50 K100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "PA_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 50 K100 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "PA_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 100 K200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "PA_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 100 K200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "PA_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 100 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "PA_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 100 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_150K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=No", "PA_150K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 150 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_150K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=Yes", "PA_150K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 150 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "PA_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 250 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "PA_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 250 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "PA_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 300 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "PA_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 300 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "PA_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 500 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "PA_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 500 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_500K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "PA_500K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 500 K1000 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_500K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "PA_500K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 500 K1000 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_1000K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "PA_1000K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 1000 K1000 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_1000K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "PA_1000K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 1000 K1000 K UMBRELLA.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_35K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=No", "PA_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 35 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_35K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=Yes", "PA_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 35 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_45K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=No", "PA_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 45 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_45K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=Yes", "PA_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 45 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "PA_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 50 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "PA_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 50 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=No", "PA_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=Yes", "PA_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 60 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "PA_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 75 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_75K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "PA_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 75 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_85K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=No", "PA_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 85 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_85K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=Yes", "PA_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 85 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "PA_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "PA_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 100 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "PA_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "PA_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "PA_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "PA_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "PA_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "PA_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "PA_1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 1000 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = PA)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_PA_1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "PA_1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values PA 1000 K UMBRELLA.

}
