package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class BWDefaultCoverageValuesTests_SD extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_None_Unk(AutoApplicant applicant) throws Exception {
        //This is going to avoid BW condition based on the foreign driver's license
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        applicant.setFirstAgeForeignDriverLicense(0);
        defaultCoverageTestForBW(applicant, "coverageAmount=None/Unk&umbrella=No", "SD_None_Unk_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD None Unk.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_25K50K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=25/50&umbrella=No", "SD_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 25 K50 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_25K65K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=25/65&umbrella=No", "SD_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 25 K65 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_30K60K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=30/60&umbrella=No", "SD_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 30 K60 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_30K65K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=30/65&umbrella=No", "SD_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 30 K65 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_35K70K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=35/70&umbrella=No", "SD_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 35 K70 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_35K80K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=35/80&umbrella=No", "SD_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 35 K80 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_50K100K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=50/100&umbrella=No", "SD_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 50 K100 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_100K200K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/200&umbrella=No", "SD_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 100 K200 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_100K300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/300&umbrella=No", "SD_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 100 K300 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_150K300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=150/300&umbrella=No", "SD_150K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 150 K300 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_250K500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=250/500&umbrella=No", "SD_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 250 K500 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_300K300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=300/300&umbrella=No", "SD_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 300 K300 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_500K500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500/500&umbrella=No", "SD_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 500 K500 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_500K1000K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500/1000&umbrella=No", "SD_500K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 500 K1000 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_1000K1000K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=1000/1000&umbrella=No", "SD_1000K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 1000 K1000 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_35K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=35&umbrella=No", "SD_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 35 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_45K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=45&umbrella=No", "SD_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 45 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_50K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=50&umbrella=No", "SD_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 50 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_60K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=60&umbrella=No", "SD_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 60 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_75K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=75&umbrella=No", "SD_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 75 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_85K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=85&umbrella=No", "SD_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 85 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_100K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100&umbrella=No", "SD_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 100 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_200K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=200&umbrella=No", "SD_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 200 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=300&umbrella=No", "SD_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 300 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500&umbrella=No", "SD_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 500 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = SD)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_SD_1000K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=1000&umbrella=No", "SD_1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values SD 1000 K.
}
