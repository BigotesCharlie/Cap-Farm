package com.farmers.ffq.auto;


import com.microsoft.playwright.Page;
import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.Vehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;

import com.farmers.framework.annotation.Skip;
import com.farmers.framework.report.Log;
import org.apache.commons.lang3.RandomUtils;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class BwFarmersQuotePresentmentTests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)
    public void testBwFarmersQuotePresentmentPageContent(AutoApplicant applicant) throws Exception {
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        if (knockoutInconveniencePage.isOnInconveniencePage()) {
            testStepAssert(false, "Test failued due to user landing on the we are soory page");
        }
        if (!bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            testStep("As this flow did not land on the Bw/Farmers quote presentment page, the test is finished early", true);
            return;
        }
        bwFarmersQuotePresentmentPage.validateBwFarmersQuotePresentmentPageContent(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Bw Farmers Quote Presentment Page Content.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)
    public void testRideShareDoesNotGetQuotePresentmentPage(AutoApplicant applicant) throws Exception {
        for (Vehicle vehicle : applicant.getVehicles()) {
            vehicle.setVehicleUsage("Rideshare");
            vehicle.setRidesharing(true);
        }
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertFalse(bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage(), "User should not land on the Quote presentment page");
        fsa.assertTrue(continueWithBristolWestPage.isOnContinueWithBristolWestPage() || quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() || knockoutInconveniencePage.isOnKnockOutPage(), "User can land on either quote summary, bw switch or Ko page");
        if (knockoutInconveniencePage.isOnInconveniencePage()) {
            Log.warn("Check the logs. User got KO page: " + knockoutInconveniencePage.getSessionStorageAppStore().getData().getQuoteNumber());

        }
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Ride Share Does Not Get Quote Presentment Page.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)
    public void test500K_500K_DoesNotGetQuotePresentmentPage(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(SPECIAL_BI_LIMIT_IS_NEEDED + SPACE + applicant.getTestScenario());
        applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));
        applicant.setCurrentBodilyInjuryLimit(_500K_AND_500K);
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        if (!applicant.getStateCode().equals(CO)) {
            fsa.assertFalse(bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage(), "User should not land on the Quote presentment page");
            fsa.assertTrue(continueWithBristolWestPage.isOnContinueWithBristolWestPage() || quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() || knockoutInconveniencePage.isOnKnockOutPage(), "User can land on either quote summary, bw switch or Ko page");
            if (knockoutInconveniencePage.isOnInconveniencePage()) {
                Log.warn("Check the logs. User got KO page: " + knockoutInconveniencePage.getSessionStorageAppStore().getData().getQuoteNumber());
            }
        } else {
            fsa.assertTrue(bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage(), "User should land on the Quote presentment page for CO state");
        }

        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test500 K 500 K Does Not Get Quote Presentment Page.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)
    public void testOnceRenderedDoesNotShowQuotePresentmentPageAfterNavigationBack(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(SPECIAL_BI_LIMIT_IS_NEEDED + SPACE + applicant.getTestScenario());
        applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));

        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);

        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();

        if (!bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            Log.warn("User did not land on the Quote Presentment Page", true);
            return;
        }
        boolean isFarmersSelected = RandomUtils.nextBoolean();
        if (isFarmersSelected) {
            bwFarmersQuotePresentmentPage.continueWithFarmers();
        } else {
            bwFarmersQuotePresentmentPage.continueWithBw();
        }
        FarmersSoftAssert fsa = new FarmersSoftAssert();

        String bwOrFarmers = isFarmersSelected ? "Farmers " : "BW ";
        if (!isFarmersSelected) {
            applicant.setTestScenario("BW-> " + applicant.getTestScenario());
        }
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
        fsa.assertTrue(isFarmersSelected ? quoteSummaryAutoPage.isOnFarmers() : quoteSummaryAutoPage.isOnBristolWest(), "User is on Expected to be on the " + bwOrFarmers + "page.");
        back();
        fsa.assertFalse(bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage(), "User should not be on the Quote presentment page after navigating back after already making selection");
        forward();
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        whoShouldWeInsurePage.navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults();
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page navigating from Who Should we insure page");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Once Rendered Does Not Show Quote Presentment Page After Navigation Back.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)
    public void testRetrievedQuoteLandsOnAlreadySelectedProduct(AutoApplicant applicant) throws Exception {
        applicant.setTestScenario(SPECIAL_BI_LIMIT_IS_NEEDED + SPACE + applicant.getTestScenario());
        applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));

        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);

        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();

        if(!bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            Log.warn("User did not land on the Quote Presentment Page", true);
            testStep("Test finished early as user did not land on the Quote Presentment page");
            return;
        }

        boolean isFarmersSelected = RandomUtils.nextBoolean();
        if (isFarmersSelected) {
            bwFarmersQuotePresentmentPage.continueWithFarmers();
        } else {
            bwFarmersQuotePresentmentPage.continueWithBw();
        }
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        String bwOrFarmers = isFarmersSelected ? "Farmers " : "BW ";
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
        fsa.assertTrue(isFarmersSelected ? quoteSummaryAutoPage.isOnFarmers() : quoteSummaryAutoPage.isOnBristolWest(), "User is on Expected to be on the " + bwOrFarmers + "page.");
        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant, quoteSummaryAutoPage.getSessionStorageAppStore().getData().getQuoteNumber());
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
        fsa.assertTrue(isFarmersSelected ? quoteSummaryAutoPage.isOnFarmers() : quoteSummaryAutoPage.isOnBristolWest(), "User is on Expected to be on the " + bwOrFarmers + "page.");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Retrieved Quote Lands On Already Selected Product.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)
    public void testFarmersSelectionAndBind(AutoApplicant applicant) throws Exception {

        // #434: Validate if user is able to bind the quote successfully by selecting 'Continue with Farmers', landing on Farmers review quote screen and proceeding with bind flow.

        applicant.setTestScenario(SPECIAL_BI_LIMIT_IS_NEEDED + SPACE + applicant.getTestScenario());
        applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));
        applicant.setLastName("Brown");
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchase(PAY_IN_FULL, PaymentMethods.VISA_DEBIT_CARD_1, true, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Farmers Selection And Bind.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)
    public void testBWSelectionAndBind(AutoApplicant applicant) throws Exception {
        // #435 : Validate if user is able to bind the quote successfully by selecting 'Continue with Bristol West', landing on BW review quote screen and proceeding with bind flow.
        applicant.setTestScenario("BW" + SPECIAL_BI_LIMIT_IS_NEEDED + SPACE + applicant.getTestScenario());
        applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));
        updateLastNameForBristolWest(applicant);
        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchase(PAY_IN_FULL, PaymentMethods.VISA_DEBIT_CARD_1, true, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test BWSelection And Bind.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)
    public void testReverseBrigthlineShouldWorkTheSame(AutoApplicant applicant) throws Exception {
        // #431 :Validate if the reverse brightline flow (RC3 brightline) continues to work as expected and there is no impact to it due to implementation of Quote presentment screen.
        applicant.setTestScenario(SPECIAL_BI_LIMIT_IS_NEEDED + SPACE + "BW" + SPACE + applicant.getTestScenario());
        applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));
        updateLastNameForBristolWest(applicant);

        new AceAutoNavigationHelper().navigateToPaymentSelectionPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        completePurchase(PAY_IN_FULL, PaymentMethods.VISA_DEBIT_CARD_1, true, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Reverse Brigthline Should Work The Same.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)
    public void testFarmersPremiumAmounts(AutoApplicant applicant) throws Exception {
        // #431 :Validate if the reverse brightline flow (RC3 brightline) continues to work as expected and there is no impact to it due to implementation of Quote presentment screen.
        applicant.setTestScenario(SPECIAL_BI_LIMIT_IS_NEEDED + SPACE + applicant.getTestScenario());
        applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if (!bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            Log.info("User wasn't able to land on the Quote Presentment page. Hence stopping the test");
            testStep("Test Finished Early as User Wasn't able to land on the targeted page");
            return;
        }
        String displayedPremiumFarmersOnQuotePresentmentPage = bwFarmersQuotePresentmentPage.getDisplayedPremiumFarmers();
        bwFarmersQuotePresentmentPage.continueWithFarmers();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnFarmers(), "User should land on the farmers quote page");
        String presentedPremiumAmountOnFarmersQuotePage = quoteSummaryAutoPage.getPresentedPremiumAmount();
        Assert.assertEquals(presentedPremiumAmountOnFarmersQuotePage.replaceAll(SPACE, EMPTY_STRING).replace("/mo", EMPTY_STRING), displayedPremiumFarmersOnQuotePresentmentPage.replace(SPACE, EMPTY_STRING).replace("/mo", EMPTY_STRING), "Quote Presentmnet and Farmers premium prices are not matchin. Farmers quote premium: " + presentedPremiumAmountOnFarmersQuotePage + ". Quote presentment page farmers premium amount: " + displayedPremiumFarmersOnQuotePresentmentPage);
    }
    // Test description: Validates the Auto behavior for Test Farmers Premium Amounts.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)
    public void testBwPremiumAmounts(AutoApplicant applicant) throws Exception {
        // #431 :Validate if the reverse brightline flow (RC3 brightline) continues to work as expected and there is no impact to it due to implementation of Quote presentment screen.
        applicant.setTestScenario(SPECIAL_BI_LIMIT_IS_NEEDED + SPACE + applicant.getTestScenario());
        applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if(!bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            testStep(TEST_COMPLETED + " due to user not landing on the Quote Presentment page");
            return;
        }
        String displayedPremiumBwOnQuotePresentmentPage = bwFarmersQuotePresentmentPage.getDisplayedPremiumBW();
        bwFarmersQuotePresentmentPage.continueWithBw();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User should land on the BW quote page");
        String presentedPremiumAmountOnBwQuotePage = quoteSummaryAutoPage.getPresentedPremiumAmount();
        Assert.assertEquals(presentedPremiumAmountOnBwQuotePage.replaceAll(SPACE, EMPTY_STRING).replace("/mo", EMPTY_STRING), displayedPremiumBwOnQuotePresentmentPage.replaceAll(SPACE, EMPTY_STRING).replace("/mo", EMPTY_STRING), "Quote Presentmnet and Farmers premium prices are not matching. Bw quote page premium: " + presentedPremiumAmountOnBwQuotePage + ". Quote presentment page bw premium amount: " + displayedPremiumBwOnQuotePresentmentPage);
    }
    // Test description: Validates the Auto behavior for Test Bw Premium Amounts.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {"bwFarmersQuotePresentment", FFQ_ONEUI}, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = INCLUDED_STATES, values = {AZ, CO, IL, MI, PA, TX})}, enabled = false)
    public void testBrightlinedUserShouldNotGetQuotePresentmentPage(AutoApplicant applicant) throws Exception {
        // #431 :Validate if the reverse brightline flow (RC3 brightline) continues to work as expected and there is no impact to it due to implementation of Quote presentment screen.
        applicant.setTestScenario("BW" + SPACE + applicant.getTestScenario());
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        ContactInfoAutoPage contactInfoAutoPage = new AceAutoNavigationHelper().navigateToContactInfoAutoPage(applicant);
        contactInfoAutoPage.setValuesAndContinue(applicant);
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        testStepAssert(continueWithBristolWestPage.isOnContinueWithBristolWestPage(), "User should land on the bw switch pop up instead of Quote presentment page");
        continueWithBristolWestPage.continueWithBwPopUp();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "User should land on the bw quote page after BW Switch pop up");
    }
    // Test description: Validates the Auto behavior for Test Brightlined User Should Not Get Quote Presentment Page.
}
