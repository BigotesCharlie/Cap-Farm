package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;
import static com.farmers.ffq.utils.GlobalVariables.MI;

public class DefaultCoverageValuesTests_MI extends DefaultCoverageBaseTest {
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "MI_50K100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 50 K100 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "MI_50K100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 50 K100 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "MI_100K200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 100 K200 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "MI_100K200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 100 K200 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "MI_100K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 100 K300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "MI_100K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 100 K300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No","MI_250K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 250 K500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "MI_250K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 250 K500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "MI_300K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 300 K300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "MI_300K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 300 K300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "MI_500K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 500 K500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "MI_500K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 500 K500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_500K1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "MI_500K1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 500 K1 M NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_500K1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "MI_500K1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 500 K1 M UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_1M1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "MI_1M1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 1 M1 M NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_1M1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "MI_1M1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 1 M1 M UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "MI_75K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 75 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_75K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "MI_75K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 75 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "MI_100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 100 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "MI_100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 100 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "MI_200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 200 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "MI_200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 200 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "MI_300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "MI_300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "MI_500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "MI_500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "MI_1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 1 M NO UMBRELLA.
	
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = MI)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_MI_1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "MI_1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values MI 1 M UMBRELLA.

}
