package com.farmers.ffq.auto.defaultcoverage;

import static com.farmers.ffq.utils.GlobalVariables.AL;
import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;

import com.farmers.framework.annotation.Skip;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;

public class DefaultCoverageValuesTests_AL extends DefaultCoverageBaseTest {
    // Skipping umbrella tests as it is not in the scope

    @Skip // this goes to BW as per for Business requirement [Confirmed by Boris]
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "AL_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 25 K50 K NO UMBRELLA.

    @Skip // this goes to BW as per for Business requirement [Confirmed by Boris]
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "AL_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 25 K50 K UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_25K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=No", "AL_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 25 K65 K NO UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_25K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=Yes", "AL_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 25 K65 K UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "AL_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 30 K60 K NO UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "AL_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 30 K60 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_30K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=No", "AL_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 30 K65 K NO UMBRELLA.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_30K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=Yes", "AL_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 30 K65 K UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "AL_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 35 K70 K NO UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "AL_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 35 K70 K UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_35K80K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=No", "AL_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 35 K80 K NO UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_35K80K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=Yes", "AL_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 35 K80 K UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "AL_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 50 K100 K NO UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "AL_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 50 K100 K UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "AL_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 100 K200 K NO UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "AL_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 100 K200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "AL_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 100 K300 K NO UMBRELLA.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "AL_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 100 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_150K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=No", "AL_150K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 150 K300 K NO UMBRELLA.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_150K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=Yes", "AL_150K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 150 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "AL_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 250 K500 K NO UMBRELLA.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "AL_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 250 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "AL_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 300 K300 K NO UMBRELLA.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "AL_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 300 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "AL_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 500 K500 K NO UMBRELLA.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "AL_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 500 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_500K1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "AL_500K1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 500 K1 M NO UMBRELLA.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_500K1M_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "AL_500K1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 500 K1 M UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_1M1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "AL_1M1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 1 M1 M NO UMBRELLA.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_1M1M_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "AL_1M1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 1 M1 M UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_35K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=No", "AL_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 35 K NO UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_35K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=Yes", "AL_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 35 K UMBRELLA.
    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_45K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=No", "AL_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 45 K NO UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_45K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=Yes", "AL_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 45 K UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "AL_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 50 K NO UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "AL_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 50 K UMBRELLA.
    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=No", "AL_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 60 K NO UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=Yes", "AL_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 60 K UMBRELLA.
    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "AL_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 75 K NO UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_75K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "AL_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 75 K UMBRELLA.
    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_85K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=No", "AL_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 85 K NO UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_85K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=Yes", "AL_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 85 K UMBRELLA.
    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "AL_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 100 K NO UMBRELLA.

    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "AL_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 100 K UMBRELLA.
    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "AL_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 200 K NO UMBRELLA.


    //PASSED
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "AL_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "AL_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 300 K NO UMBRELLA.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "AL_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "AL_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 500 K NO UMBRELLA.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "AL_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "AL_1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 1 M NO UMBRELLA.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AL)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_AL_1M_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "AL_1M_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values AL 1 M UMBRELLA.


}
