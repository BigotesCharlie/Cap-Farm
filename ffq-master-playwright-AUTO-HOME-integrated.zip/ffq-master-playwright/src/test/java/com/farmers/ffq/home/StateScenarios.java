package com.farmers.ffq.home;

import com.farmers.ffq.ace.hrc.common.AceHRCPropertyTypeBasePage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.DataProviders;
import com.farmers.ffq.dataproviders.SqlDataProviders;
import com.farmers.ffq.datatransferobjects.ApplicantHome;
import com.farmers.ffq.datatransferobjects.State;
import com.farmers.ffq.common.pages.LegacyNonOfferingPage;
import com.farmers.ffq.dataproviderframework.DataProviderBase;
import com.farmers.ffq.home.pages.YourInfoPageHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.Property;

import org.testng.SkipException;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StateScenarios extends AutomationFramework {

	@Test(dataProvider = SqlDataProviders.STATES_DATA_PROVIDER_NAME, dataProviderClass = SqlDataProviders.class, groups = {GET_HOME, REGRESSION, STATE_SCENARIOS})
	public void validateStateForHome(State state) throws Exception {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		LandingPage landingPage = new LandingPage();
		String applicantStateCode = state.getStateCode();
		String environment = Property.getUri();
		if (applicantStateCode.equals(NH) && environment.contains(RA11_ENVIRONMENT)) {
			landingPage.enterLandingPageDataAndRemainInPage(LOB_HOME, state.getZipCode());
			fsa.assertTrue(landingPage.cantBeCompletedOnlineErrorMessageRedAndVisible(), state.getStateName() + " quote cannot be completed online.");
		} else {
			landingPage.enterLandingPageDataAndContinue(LOB_HOME, state.getZipCode());
			if (isDisabledState(applicantStateCode)) {
				validateUninsuredState(state, fsa);
			} else if (DataProviders.getListOfLegacyHomeStates(environment).contains(applicantStateCode)) {
				validateInsuredState(state, fsa);
			} else if (DataProviders.listOfHQMStates().contains(applicantStateCode)) {
				fsa.assertTrue(new YourInfoPageHome().isHQMInfoPage(), "HQM page found for " + applicantStateCode);
			} else if (!new KnockoutInconveniencePage().isQuoteKnockedOut()) {
				if (DataProviders.getListOfAceHCRStates(environment).contains(applicantStateCode) && !new KnockoutInconveniencePage().isQuoteKnockedOut()) {
					fsa.assertTrue(new AceHRCPropertyTypeBasePage().isOnPropertyTypePage(), "Ace Home property type reached for " + state.getStateName());
				} else if (!DataProviderBase.getListOfHCRMonetizedStates(environment).contains(applicantStateCode) && !DataProviders.getListOfLegacyHomeMonetizedStates(environment).contains(applicantStateCode)){
					validateUninsuredState(state, fsa);
				}
			}
		}
		fsa.assertAll();
	}
	// Test description: Validates the Home behavior for Validate State For Home.

	@Test(dataProvider = DataProviders.MONETIZED_STATES_LEGACY_HOME_DATA_PROVIDER, testName = DataProviders.ONE_APPLICANT_PER_STATE, dataProviderClass = DataProviders.class, groups = {GET_HOME, REGRESSION, STATE_SCENARIOS})
	public void validateStateForLegacyHomeUsingAOR(ApplicantHome applicant) throws Exception {
        if (Property.getTestProperty("remote").equalsIgnoreCase("local")) {
        	String applicantStateCode = applicant.getStateCode();
        	String environment = Property.getUri();
        	if (DataProviders.getListOfLegacyHomeStates(environment).contains(applicantStateCode) || DataProviders.getListOfLegacyHomeMonetizedStates(environment).contains(applicantStateCode)) {
        		new LandingPage(applicant);
        		YourInfoPageHome yourInfoPageHome = new YourInfoPageHome();
        		FarmersSoftAssert fsa = new FarmersSoftAssert();
        		fsa.assertTrue(applicant.getZipCode().equalsIgnoreCase(yourInfoPageHome.getZipCodeFromTextBox()), "Zip code verification");
        		fsa.assertTrue(applicant.getState().equalsIgnoreCase(yourInfoPageHome.getStateNameValueFromTextBox()), "State name verification");
        		fsa.assertAll();
        	} else {
        		throw new SkipException("Legacy home not available for " + applicant.getState() + ", skipping test.");
        	}
        } else {
    		throw new SkipException("Legacy home AOR testing only available locally");
        }
	}
	// Test description: Validates the Home behavior for Validate State For Legacy Home Using AOR.

	private void validateInsuredState(State state, FarmersSoftAssert sa) throws Exception {
		YourInfoPageHome yourInfoPageHome = new YourInfoPageHome();
		String applicantStateCode = state.getStateCode();
		if (yourInfoPageHome.onYourInfoPageHome()) {
			sa.assertTrue(state.getZipCode().equalsIgnoreCase(yourInfoPageHome.getZipCodeFromTextBox()));
			sa.assertTrue(state.getStateName().equalsIgnoreCase(yourInfoPageHome.getStateNameValueFromTextBox()));
			if (stateHasMailingAddressCheckbox(applicantStateCode) && yourInfoPageHome.isMailingCheckBoxDisplayed()) {
				sa.assertTrue(yourInfoPageHome.isMailingAddressDifferentCheckBoxDisplayed(), "Mailing Address checkbox should be visible.");
			}
			sa.assertTrue(yourInfoPageHome.isCreditCheckNotificationShown(), "Credit Check text should be visible.");
		} else {
			sa.fail("Did not reach Your Info page");
		}
	}

    private void validateUninsuredState(State state, FarmersSoftAssert fsa) throws Exception {
        LegacyNonOfferingPage legacyNonOfferingPage = new LegacyNonOfferingPage();
        switch (state.getStateCode()) {
        case AK: case CT: case NH: case MA: case MS: case NC: case NY: case SC:
        	fsa.assertTrue(LegacyNonOfferingPage.page().url().contains("/fgia"), "Continue to FGIA page displayed for " + state.getStateName());
        	break;
        case CA: case GA: case NJ: case NV:
        	fsa.assertTrue(legacyNonOfferingPage.quotingUnavailableTextExists(), "Unable to provide quote page displayed for " +  state.getStateName());
        	break;
        case LA:
        	if (Property.getUri().contains(TSK1_ENVIRONMENT) || Property.getUri().contains(PET_ENVIRONMENT)) {
            	fsa.assertTrue(new KnockoutInconveniencePage().isOnMonetizedMediaAlphaPage(), "Media alpha page displayed for " + state.getStateName());
        	} else {
        		fsa.assertEquals(new KnockoutInconveniencePage().getPageTitle(), "We aren't able to complete your quote at this time.", "We aren't able to complete your quote at this time page displayed for " +  state.getStateName());
        	}
        	break;
    	case HI:
			fsa.assertTrue(legacyNonOfferingPage.farmersInsuranceHawaiiState(), "Hawaii zip codes should be forwarded to Hawaii page.");
			break;
    	case DE: case ME: case RI: case VT: case WV:
    		fsa.assertTrue(LegacyNonOfferingPage.page().url().contains("groupselect"), "Farmers GroupSelect Quote page displayed for " + state.getStateName());
    		break;
        default:
        	fsa.assertTrue(legacyNonOfferingPage.isNonOfferingTextExist(), state.getStateName() + " quotes should be forwarded to non-offering page.");
        	break;
        }
    }

	private boolean stateHasMailingAddressCheckbox(String stateCode) {
		List<String> mailingAddresssCheckboxStates = new ArrayList<>(Arrays.asList(NJ, NY));
		return mailingAddresssCheckboxStates.contains(stateCode);
	}

	private boolean isDisabledState(String stateCode) {
		String environmentURI = Property.getUri();
		return stateCode.equals(NV) ||
				((environmentURI.contains(TSK1_ENVIRONMENT) || environmentURI.contains(PET_ENVIRONMENT)) && Arrays.asList(CT, LA, MA).contains(stateCode)) ||
				( environmentURI.contains(PET_ENVIRONMENT) && Arrays.asList(MS, NC).contains(stateCode));
	}
}

