package com.farmers.ffq.auto;

import com.farmers.framework.AutomationFramework;

import com.microsoft.playwright.Page;
import static com.farmers.ffq.utils.GlobalVariables.EXCLUDED_STATES;
import static com.farmers.ffq.utils.GlobalVariables.MOBILE_BROWSER;
import static com.farmers.ffq.utils.GlobalVariables.MOBILE_REGRESSION;
import static com.farmers.ffq.utils.GlobalVariables.NY;
import static com.farmers.ffq.utils.GlobalVariables.REGRESSION;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.SqlDataProviders;
import com.farmers.ffq.datatransferobjects.SqlApplicant;

/**
 * Farmers Fast Quote (FFQ) - Page Validation Scenarios.
 *
 *
 */

public class PageValidationScenarios extends AutomationFramework {
	@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {NY})}, dataProviderClass = SqlDataProviders.class, groups = REGRESSION)
	public void autoPageValidationTests(SqlApplicant applicant) throws Exception {
		createPageValidationQuote(applicant);
	}
	// Test description: Validates the Auto behavior for Auto Page Validation Tests.

	@Test(dataProvider = SqlDataProviders.AUTO_APPLICANT_PAGE_VALIDATION_DATA_PROVIDER, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {NY})}, dataProviderClass = SqlDataProviders.class, groups = {MOBILE_REGRESSION})
	public void mobileAutoPageValidationTests(SqlApplicant applicant) throws Exception {
		applicant.setTestCategory(MOBILE_BROWSER);
		createPageValidationQuote(applicant);
	}
	// Test description: Validates the Auto behavior for Mobile Auto Page Validation Tests.

	private void createPageValidationQuote(SqlApplicant applicant) throws Exception {
		QuoteScenarios quotes = new QuoteScenarios();
		quotes.createPartialAutoQuote(applicant);
	}
}
