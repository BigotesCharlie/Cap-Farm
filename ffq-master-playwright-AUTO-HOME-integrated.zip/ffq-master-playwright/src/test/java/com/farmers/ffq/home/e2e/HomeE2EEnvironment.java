package com.farmers.ffq.home.e2e;

import com.farmers.framework.Property;
import java.net.URI;

/** Resolves the HOME deep-link on the same QA/UAT host selected by the master properties.json. */
final class HomeE2EEnvironment {
    private HomeE2EEnvironment() {}

    static String startUrl() {
        String override = System.getProperty("homeBaseUrl");
        if (override == null || override.isBlank()) {
            override = System.getenv("FFQ_HOME_BASE_URL");
        }
        if (override != null && !override.isBlank()) {
            return override.trim();
        }
        URI base = URI.create(Property.getEnvironmentProperty("uri"));
        return base.getScheme() + "://" + base.getHost() + "/quote/home/personal-info";
    }
}
