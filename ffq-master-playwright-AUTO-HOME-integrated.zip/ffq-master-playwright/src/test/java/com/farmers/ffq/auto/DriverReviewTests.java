package com.farmers.ffq.auto;


import com.microsoft.playwright.Page;
import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bindpages.ConsolidatedPaymentPage;
import com.farmers.ffq.auto.pages.bw.BwPaymentSummaryPage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;

import com.farmers.ffq.utils.PaymentMethods;
import com.farmers.framework.report.Log;
import org.apache.commons.lang3.RandomUtils;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.auto.DriverReviewTests.AgeScenarios.OLD_AND_YOUNG;
import static com.farmers.ffq.auto.pages.VehicleReviewPage.PERSONAL;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;


public class DriverReviewTests extends BaseTest {

    private static final String END_OF_TEST = "END of test";
    private static final String GOOD_STUDENT = "Good student";

    enum AgeScenarios {ALL_UNDER_25, PNI_UNDER_25, SNI_UNDER_25, OLD_AND_YOUNG, PNI_AND_CHILD, LESS_THAN_TEN_YEARS_DRIVING}

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {CO, MI, AR, AZ, ID, IL, IN, MN, MO, NM, OH, OK, OR, TN, VA, WA})}, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void testReviewDrivers_happy_path(AutoApplicant applicant) throws Exception {
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        driverReviewPage.reviewAllDrivers(applicant, Optional.of(fsa));
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Review Drivers happy path.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=31"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CO, MI, AR, AZ, ID, IL, IN, MN, MO, NM, NJ, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void validatePageWithMarriedApplicant(AutoApplicant applicant) throws Exception {
        driversReviewPageValidation(applicant);
    }
    // Test description: Validates the Auto behavior for Validate Page With Married Applicant.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=30"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void validatePageWithTwoAdditionalDrivers(AutoApplicant applicant) throws Exception {
        driversReviewPageValidation(applicant);
    }
    // Test description: Validates the Auto behavior for Validate Page With Two Additional Drivers.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=31"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void validatePageWithThreeAdditionalDrivers(AutoApplicant applicant) throws Exception {
        driversReviewPageValidation(applicant);
    }
    // Test description: Validates the Auto behavior for Validate Page With Three Additional Drivers.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=12"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, FL})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void validatePageWithFourAdditionalDrivers(AutoApplicant applicant) throws Exception {
        driversReviewPageValidation(applicant);
    }
    // Test description: Validates the Auto behavior for Validate Page With Four Additional Drivers.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=22"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, FL})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void validatePageWithYoungApplicant(AutoApplicant applicant) throws Exception {
        driversReviewPageValidation(applicant);
    }
    // Test description: Validates the Auto behavior for Validate Page With Young Applicant.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=7"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, FL})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void validatePageWithOldApplicant(AutoApplicant applicant) throws Exception {
        driversReviewPageValidation(applicant);
    }
    // Test description: Validates the Auto behavior for Validate Page With Old Applicant.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=28"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, FL})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void validatePageWithIncidents(AutoApplicant applicant) throws Exception {
        driversReviewPageValidation(applicant);
    }
    // Test description: Validates the Auto behavior for Validate Page With Incidents.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=28"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, FL})}, groups = {FFQ_ONEUI, DRIVER_REVIEW, "occupationListValidation"})
    public void validateDisplayedOccupationList(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicant.setVehicles(updateVehiclesToOne(applicant.getVehicles()));
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        driverReviewPage.validateDisplayedOccupations(applicant, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Displayed Occupation List.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {WA, FL, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA})}, groups = {FFQ_ONEUI, DRIVER_REVIEW, "occupationListValidation"})
    public void validateOccupationCodes(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        applicant.setVehicles(updateVehiclesToOne(applicant.getVehicles()));
        driverReviewPage.validateOccupationCodes(applicant, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Occupation Codes.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {CA, LA, MA})}, groups = {FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, DRIVER_REVIEW})
    public void validateDriverLicenseAgeSection(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        applicant.setVehicles(updateVehiclesToOne(applicant.getVehicles()));
        applicant.getVehicles().forEach(each -> each.setVehicleUsage(PERSONAL));
        applicant.getVehicles().forEach(each -> each.setRidesharing(false));
        if (applicant.getStateCode().equals(CA)) {
            applicant.getAdditionalDrivers().forEach(each -> each.setLicenseToDriveInUSA(RandomUtils.nextBoolean() ? YES : NO));
        }
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        driverReviewPage.validateDriverLicenseAgeSection(applicant, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Driver License Age Section.

    /**
     * The Below scenarios are added later in the development, after the initial development of driver license number input section, to cover some of the edge cases and error message validations related to driver license number input section.
     * BW Ace Auto 198 and 199 scenarios
     * Validate that duplicate driver license error is removed when fields are updated
     * Validate that  incorrect driver license error message is shown for  particular field, other fields are not impacted
     *
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {MA}), @CustomAttribute(name = FILTER, values = "applicantId=34")},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, ADA_SUITE, ACE_AUTO_ADA_SUITE, DRIVER_REVIEW})
    public void validateDriverLicenseNumberInputSection(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        applicant.setVehicles(updateVehiclesToOne(applicant.getVehicles()));
        driverReviewPage.validateDriverLicenseNumberInputSection(applicant, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Driver License Number Input Section.

    private void driversReviewPageValidation(AutoApplicant applicant) throws Exception {
        applicant.setVehicles(updateVehiclesToOne(applicant.getVehicles()));
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        // Automatically includes names validation
        driverReviewPage.validateDriversAges(applicant, fsa);
        fsa.assertTrue(driverReviewPage.validateDriverReviewPageCTA(applicant), "CTA Error message validation");
        driverReviewPage.validateHadTheirDriverLicenseAgeCondition(fsa, applicant);
        driverReviewPage.validateEditDriverSections(applicant, fsa);
        driverReviewPage.validateValidateAccidentCheckbox(fsa);
        driverReviewPage.validateOccupationSidePanel(applicant, fsa);
        fsa.assertTrue(driverReviewPage.validateIncidentRemoval(applicant), "Driver Review Page Incident Removal");
        driverReviewPage.validateInfoBoxes(applicant, fsa);
        driverReviewPage.validateMaritalRelationRemoval(applicant, fsa);
        fsa.assertTrue(driverReviewPage.validateMaritalToSomeoneNotListed(applicant, false), "Married to Someone Not Listed Validation");
        fsa.assertTrue(driverReviewPage.validateGoingBackToADPFScreen(), "Drivers Review Page going back to ADPF page");
        fsa.assertAll();
    }

    /**
     * Validates that Good Student and Distant Student discounts are NOT removed
     * when the "Has had driver's license for less than 3 years" checkbox is unchecked.
     * <p>
     * Setup: PNI age 33, additional driver age 24 with license held for 2 years
     * (age - licenseAge = 2 < 3, triggers the license checkbox).
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"}), @CustomAttribute(name = EXCLUDED_STATES, values = {KY, NC, LA, MA, CA, AR, AZ, CO, ID, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, DRIVER_REVIEW})
    public void validateStudentDiscountsNotRemovedWhenLicenseCheckboxUnchecked(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        applicant.setVehicles(updateVehiclesToOne(applicant.getVehicles()));
        applicant = setTestDataForApplicant(applicant, AgeScenarios.PNI_AND_CHILD);
        // Set the young additional driver's license age within 3 years to trigger the license checkbox
        // Condition: age - licenseAge < 3  →  24 - 22 = 2 < 3 ✓
        SqlAdditionalDriver youngDriver = applicant.getAdditionalDrivers().get(0);
        youngDriver.setFirstAgeUnitedStatesDriverLicense(youngDriver.getAge() - 2);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        driverReviewPage.validateStudentDiscountsNotRemovedOnLicenseCheckboxUncheck(applicant, fsa);
        fsa.assertAll();
        testStep(END_OF_TEST, true);
    }
    // Test description: Validates the Auto behavior for Validate Student Discounts Not Removed When License Checkbox Unchecked.

    // DE258969: [PROD/RA11] [MA State] Good Student discount is Dropping Off
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"}), @CustomAttribute(name = EXCLUDED_STATES, values = {NJ, FL, WA, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void testGoodStudentQuestionAndDiscount(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        updateVehiclesToOne(applicant.getVehicles());
        testForGoodStudent(applicant);
        testStep(END_OF_TEST, true);
    }
    // Test description: Validates the Auto behavior for Test Good Student Question And Discount.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=10"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, WA, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void testDistantStudentQuestionAndDiscount(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        applicant.setVehicles(updateVehiclesToTwo(applicant.getVehicles()));
        updateApplicantDataToAvoidPossibleBw(applicant);
        testForDistantStudent(applicant);
        testStep(END_OF_TEST, true);
    }
    // Test description: Validates the Auto behavior for Test Distant Student Question And Discount.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=34"}), @CustomAttribute(name = EXCLUDED_STATES, values = {WA, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA, MT})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void testSharedFamilyCarQuestionAndDiscount(AutoApplicant applicant) throws Exception {
        String stateCode = applicant.getStateCode();
        updateVehiclesToOne(applicant.getVehicles());
        applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));
        boolean isSharedFamilyCarDiscountExpected = Arrays.asList(IA, IN, KS, MD, MN, NV, OH).contains(stateCode);
        testForSharedFamilyCar(applicant, isSharedFamilyCarDiscountExpected);
        testStep(END_OF_TEST, true);
    }
    // Test description: Validates the Auto behavior for Test Shared Family Car Question And Discount.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_AND_VEHICLES), @CustomAttribute(name = EXCLUDED_STATES, values = {CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})}, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void validateOrderOfDriversInDriversReviewPage_ADPFDATA(ADPFApplicant applicant) throws Exception {
        new DriverReviewPage().validateDisplayedDrivers_ADPFData(applicant);
    }
    // Test description: Validates the Auto behavior for Validate Order Of Drivers In Drivers Review Page ADPFDATA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=12"}), @CustomAttribute(name = EXCLUDED_STATES, values = {MT, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void validateOrderOfDriversInDriversReviewPage_NonADPFDATA(AutoApplicant applicant) throws Exception {
        applicant.setMaritalStatus(MARRIED);
        updateVehiclesToOne(applicant.getVehicles());
        applicant.getAdditionalDrivers().get(0).setRelationshipToApplicant(SPOUSE);
        new DriverReviewPage().validateDisplayedDrivers_NonAdpf(applicant);
    }
    // Test description: Validates the Auto behavior for Validate Order Of Drivers In Drivers Review Page Non ADPFDATA.


    /**
     * F95140[Signal Handling] F84024[Roll out]
     *
     * @param applicant
     * @throws Exception
     */

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=5"), @CustomAttribute(name = INCLUDED_STATES, values = {CA, PA, TX})}, groups = {FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, DRIVER_REVIEW})
    public void validateNon_DriverSpouseHandling(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        applicant.setLastName("Bailey");
        applicant.getDiscounts().get(0).setSignalSignup(true);
        boolean randomWillBeDriving = RandomUtils.nextBoolean();
        boolean randomForeignDl = RandomUtils.nextBoolean();
        Log.info("randomWillBeDriving : " + randomWillBeDriving);
        Log.info("\nrandomForeignDl : " + randomForeignDl);
        applicant.setVehicles(updateVehiclesToOne(applicant.getVehicles()));
        if (applicant.getStateCode().equals(CA)) {
            applicant.getAdditionalDrivers().forEach(each -> each.setLicenseToDriveInUSA(RandomUtils.nextBoolean() ? YES : NO));
            applicant.getVehicles().forEach(each -> each.setRidesharing(false));
        }
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        driverReviewPage.validateNonDriverFunctionality(applicant, fsa, randomWillBeDriving, randomForeignDl);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        if (randomWillBeDriving) {
            if (!randomForeignDl) {
                testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page", true);
                testStepAssert(quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false), "Customer on the payment summary page");
                AutoQuoteVerifyServiceInitiated autoQuoteVerifyServiceInitiated = new ApiHelper().getAutoQuoteVerifyServiceInitiated(quoteSummaryAutoPage.getSessionStorageAppStore().getData().getQuoteNumber());
                List<AutoQuoteVerifyServiceInitiated.AutoQuote.PersonalAuto.Driver> marriedDrivers = autoQuoteVerifyServiceInitiated.getAutoQuote().get(0).getPersonalAuto().getDrivers().stream().filter(each -> each.getMaritalStatus().equals("M") && !each.getRelationshipToInsured().equals("H")).collect(Collectors.toList());
                for (AutoQuoteVerifyServiceInitiated.AutoQuote.PersonalAuto.Driver marriedDriver : marriedDrivers) {
                    testStepAssert(marriedDriver.getNonDriverReason().equals("Y"), "Non driver reason for SNI should be Y");
                }
                completePurchase(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true, fsa);
            } else {
                //TODO:;
                Log.info("TODO: randomForeignDl: " + randomForeignDl + " randomWillBeDriving:  " + randomWillBeDriving);
            }
        } else {
            if (!randomForeignDl) {
                testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page", true);

                if (quoteSummaryAutoPage.isOnBristolWest()) {
                    Log.info("Test finished early due to brightline");
                    return;
                }
                quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
                AutoQuoteVerifyServiceInitiated autoQuoteVerifyServiceInitiated = new ApiHelper().getAutoQuoteVerifyServiceInitiated(quoteSummaryAutoPage.getSessionStorageAppStore().getData().getQuoteNumber());
                AutoQuoteVerifyServiceInitiated.AutoQuote.PersonalAuto.Driver sni = autoQuoteVerifyServiceInitiated.getAutoQuote().get(0).getPersonalAuto().getDrivers().stream().filter(each -> each.getMaritalStatus().equals("M") && each.getRelationshipToInsured().equals("X")).collect(Collectors.toList()).get(0);
                testStepAssert(sni.getNonDriverReason().equals("EX"), "nonDriverReason for SNI should be EX");

                // additional driver
                List<AutoQuoteVerifyServiceInitiated.AutoQuote.PersonalAuto.Driver> additionalDrivers = autoQuoteVerifyServiceInitiated.getAutoQuote().get(0).getPersonalAuto().getDrivers().stream().filter(each -> each.getRelationshipToInsured().equals("O")).collect(Collectors.toList());
                List<String> nonDriverReasonsForAdditionalDrivers = additionalDrivers.stream().map(each -> each.getNonDriverReason()).collect(Collectors.toList());
                testStepAssert(nonDriverReasonsForAdditionalDrivers.contains("EX") && nonDriverReasonsForAdditionalDrivers.contains("Y"), "nonDriverReason for additional drivers validated");

                completePurchase(PAY_IN_FULL, PaymentMethods.BANK_ACCOUNT_1, true, fsa);

            } else {
                //TODO:;
                Log.info("TODO: randomForeignDl: " + randomForeignDl + "randomWillBeDriving" + randomWillBeDriving);
            }
        }

        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Non Driver Spouse Handling.

    // will be completed when the feature is completed: F92796
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL, CT, GA, KS, KY, MA, MS, MT, ND, NV, SD, UT, WI, WY, PA}), @CustomAttribute(name = FILTER, values = "applicantId=26")}, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void validateMatureDriverFunctionalityNonStreamLine(AutoApplicant applicant) throws Exception {
        setUpDataForMatureDriverTest(applicant);

        // SV data for some reason is not working for GA state, using the adpf data for GA state to set up the applicant data for mature driver test for GA state until we have a fix for SV data for GA state
        if (applicant.getStateCode().equals(GA)) {
            applicant.setFirstName("Billyco");
            applicant.setLastName("Sweqco");
            applicant.setDateOfBirth("06011971");
            applicant.setResidentAddress("100 Courtland Cir");
            applicant.setZipCode("30127");
            applicant.setCity("Powder Springs");
        }

        FarmersSoftAssert fsa = new FarmersSoftAssert();
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper(AceAutoNavigationHelper.quoteFlow.DEFAULT).navigateToDriverReviewPage(applicant);
        String stateCode = applicant.getStateCode();

        if (isNoSnackbarState(stateCode)) {
            validateSafetyCourseWithoutSnackbar(driverReviewPage, applicant, fsa);
        } else {
            validateSafetyCourseWithDiscount(driverReviewPage, applicant, fsa, stateCode);
        }

        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Mature Driver Functionality Non Stream Line.

    /**
     * Validate "Has completed a driver safety course in the last 3 years" Check box should be present for Mature Driver. Select this check box and validate the "Mature Driver" discount
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=26"), @CustomAttribute(name = INCLUDED_STATES, values = {AL, CT, FL, GA, IA, KS, KY, LA, MA, MD, MS, MT, NC, ND, NE, NJ, NV, OH, PA, SD, TX, UT, WI, WY})}, groups = {BDQ_TESTS, DRIVER_REVIEW})
    public void validateMatureDriverDiscountBDQNonStreamLine(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        setUpApplicantForMatureDriverTestBDQ(applicant);
        String stateCode = applicant.getStateCode();
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper(AceAutoNavigationHelper.quoteFlow.BDQ).navigateToDriverReviewPage(applicant);


        // check if safety course question is expected for the applicant based on state and validate the presence of the question accordingly, then validate the mature driver discount in quote summary page based on whether the safety course checkbox is expected or not in driver review page
        // as some states require safety course for mature driver discount and some don't
        boolean isSafetyCourseExpected = driverReviewPage.isSafetyCourseExpectedStateBDQ(stateCode);

        // no need to go to quote summary page and check defensive/mature driver discount if safety course checkbox is not expected to be displayed in driver review page
        if (isSafetyCourseExpected) {
            driverReviewPage.validateSafetyCourseFunctionality(applicant, true, fsa);
            driverReviewPage.proceedToQuoteSummaryPage(applicant);
            QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
            testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page", true);
            if (stateCode.equals(PA)) {
                quoteSummaryAutoPage.validateDriverImprovementDiscountPresent(fsa);
            } else {
                quoteSummaryAutoPage.validateMatureDriverDiscountPresenceBW(fsa, applicant);
            }

            quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
            BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
            testStepAssert(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User is on the payment summary page", true);
            if (stateCode.equals(PA)) {
                quoteSummaryAutoPage.validateDriverImprovementDiscountPresent(fsa);
            } else {
                quoteSummaryAutoPage.validateMatureDriverDiscountPresenceBW(fsa, applicant);
            }
        } else {
            driverReviewPage.validateSafetyCourseCheckBoxNotPresent(fsa, driverReviewPage.getApplicantFullName(applicant));
        }
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Mature Driver Discount BDQNon Stream Line.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {AL, CT, FL, GA, IA, KS, KY, LA, MA, MD, MS, MT, ND, NE, NJ, NV, PA, SD, TX, UT, WI, WY}), @CustomAttribute(name = FILTER, values = "applicantId=26")}, groups = {BW_ACE_TESTS, DRIVER_REVIEW})
    public void validateMatureDriverDiscountAfterBrightLineNonStreamLine(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        setUpDataForMatureDriverTestBW(applicant);
        // Navigate to Quote Summary Page using default flow
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper(AceAutoNavigationHelper.quoteFlow.DEFAULT).navigateToEitherQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page", true);

        // Navigate back to Driver Review Page
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        navigateBackToDriverReviewPage(quoteSummaryAutoPage);

        // Validate Safety Course and Mature Driver Discount
        validateSafetyCourseAndDiscountOnQuoteSummaryAndPayment(driverReviewPage, applicant, fsa);

        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Mature Driver Discount After Bright Line Non Stream Line.

    private void setRandomAgeForApplicantToSafetyCourse(AutoApplicant applicant) {
        List<Integer> randomAges = getRandomAgesForState(applicant.getStateCode());
        if (!randomAges.isEmpty()) {
            int randomAge = randomAges.get(new Random().nextInt(randomAges.size()));
            applicant.setAge(randomAge);
            applicant.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(randomAge));
        }
    }

    private List<Integer> getRandomAgesForState(String stateCode) {
        switch (stateCode) {
            case KS:
            case NJ:
                return Arrays.asList(18, 25, 40, 55, 65, 85);
            case CT:
                return Arrays.asList(60, 65, 70, 85);
            case MA:
                return Arrays.asList(65, 70, 85);
            default:
                return Collections.emptyList();
        }
    }

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.FINANCIAL_RESPONSIBILITY_APPLICANT, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = INCLUDED_STATES, values = {FL})}, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void testFinancialResponsibilityCaseNumberField(AutoApplicant applicant) throws Exception {
        applicant.getVehicles().stream().forEach(vehicle -> vehicle.setUseVIN(false));
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        driverReviewPage.validateFinancialFillingCaseNumberField(applicant, fsa);
        // check that we are in the next page (policy start date)
        driverReviewPage.waitForSpinnerToBeGone();
        fsa.assertTrue(new ContactInfoAutoPage().isOnContactInfoAutoPage(), "Successfully entered case number and proceeded to next page");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Financial Responsibility Case Number Field.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANTS_FROM_A_FEW_STATES, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = FILTER, values = "applicantId=5"), @CustomAttribute(name = INCLUDED_STATES, values = {CA, TX})}, groups = {FFQ_ONEUI, ADA_SUITE, ACE_AUTO_ADA_SUITE, DRIVER_REVIEW})
    public void verifySpouseNonDriverStatusPersistsAndIsNotAutoUpdatedAfterRefresh(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        driverReviewPage.validateSpouseNonDriverStatusDoesNotResetAfterRefresh(applicant, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Verify Spouse Non Driver Status Persists And Is Not Auto Updated After Refresh.

        @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=24"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, CO, MI, AR, AZ, ID, IL, IN, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, DRIVER_REVIEW})
    public void validateErrorsForAgeLicensedInBackAndForthTest(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        randomizeApplicantPersonalData(applicant);
        applicant.setVehicles(updateVehiclesToOne(applicant.getVehicles()));
        applicant.setAge(16);
        applicant.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(applicant.getAge()));
        DriverReviewPage driverReviewPage = navigateToDriverReviewPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        driverReviewPage.validateErrorsForAgeLicensedInBackAndForth(applicant, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Errors For Age Licensed In Back And Forth Test.

    private DriverReviewPage navigateToDriverReviewPage(AutoApplicant applicant) throws Exception {
        return new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
    }


    private void testForGoodStudent(AutoApplicant applicant) throws Exception {
        applicant = setTestDataForApplicant(applicant, OLD_AND_YOUNG);
        applicant.getVehicles().forEach(vehicle -> vehicle.setVehicleUsage("Personal"));
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        boolean isDiscountSelected = RandomUtils.nextBoolean();
        driverReviewPage.validateGoodStudentOption(applicant, isDiscountSelected);
        driverReviewPage.proceedToQuoteSummaryPage(applicant);
        boolean isDiscountFound = new QuoteSummaryAutoPage().isDiscountPresentInTheSideSheet(GOOD_STUDENT);
        String expectedModifier = isDiscountSelected ? SPACE : NOT;
        String actualModifier = isDiscountFound ? SPACE : NOT;
        testStepAssert(isDiscountFound == isDiscountSelected, "Expected: Good student discount should" + expectedModifier + "be displayed in quote summary page. Actual: Good student discount is" + actualModifier + "displayed in quote summary page");
    }

    private void testForDistantStudent(AutoApplicant applicant) throws Exception {
        setTestDataForApplicant(applicant, OLD_AND_YOUNG);
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        boolean isDistantStudentSelected = RandomUtils.nextBoolean() && !Arrays.asList(KY, LA, MA, MS, NC, RI).contains(applicant.getStateCode());
        Log.info("For this test 'isDistantStudentSelected' is set to: " + isDistantStudentSelected);
        driverReviewPage.validateDistantStudentOption(applicant, isDistantStudentSelected);
        driverReviewPage.waitForSpinnerToBeGone();
        driverReviewPage.proceedToQuoteSummaryPage(applicant);
        boolean isExpectedDiscountFound = new QuoteSummaryAutoPage().isDiscountPresentInTheSideSheet("Distant student");
        String expectedModifier = isDistantStudentSelected ? SPACE : NOT;
        String actualModifier = isExpectedDiscountFound ? SPACE : NOT;
        testStepAssert(isExpectedDiscountFound == isDistantStudentSelected, "Expected:Distant student discount should" + expectedModifier + "be displayed in quote summary page. Actual:Distant student discount is" + actualModifier + "displayed in quote summary page");
    }

    private void testForSharedFamilyCar(AutoApplicant applicant, boolean optionExpected) throws Exception {
        applicant = setTestDataForApplicant(applicant, AgeScenarios.PNI_AND_CHILD);
        boolean discountSelected = optionExpected && RandomUtils.nextBoolean();
        DriverReviewPage driverReviewPage = new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        driverReviewPage.validateSharedFamilyCarOption(optionExpected, discountSelected);
        if (driverReviewPage.isAskingDriverLicenseAgeState(applicant.getStateCode())) {
            String applicantFullName = applicant.getFirstName() + SPACE + applicant.getLastName();
            driverReviewPage.enterDriverLicenseAge(applicant, applicantFullName, applicant.getFirstAgeUnitedStatesDriverLicense());
            driverReviewPage.addDriverLicenseNumber(applicant, applicantFullName);
            driverReviewPage.enterDriverLicenseAge_CA(applicantFullName, 15);
            for (SqlAdditionalDriver additionalDriver : applicant.getAdditionalDrivers()) {
                applicantFullName = additionalDriver.getFirstName() + SPACE + additionalDriver.getLastName();
                driverReviewPage.enterDriverLicenseAge(applicant, applicantFullName, applicant.getFirstAgeUnitedStatesDriverLicense());
                driverReviewPage.addDriverLicenseNumber(applicant, applicantFullName);
                driverReviewPage.enterDriverLicenseAge_CA(driverReviewPage.getDriverFullName(additionalDriver), 15);
            }
        }
        driverReviewPage.clickContinueButton();
        driverReviewPage.waitForSpinnerToBeGone();
        driverReviewPage.proceedToQuoteSummaryPage(applicant);
        boolean isExpectedDiscountFound = new QuoteSummaryAutoPage().isDiscountPresentInTheSideSheet("Shared Family Car");
        String expectedModifier = discountSelected ? SPACE : NOT;
        String actualModifier = isExpectedDiscountFound ? SPACE : NOT;
        if (applicant.getStateCode().equals(FL) || applicant.getStateCode().equals(CA))
            return; //FL will land on the BW quote page, and CA will get KO
        testStepAssert(isExpectedDiscountFound == discountSelected, "Expected: Shared family car discount should" + expectedModifier + "be displayed in quote summary page. Actual: Shared family car discount is" + actualModifier + "displayed in quote summary page");
    }

    private AutoApplicant setTestDataForApplicant(AutoApplicant applicant, AgeScenarios ageScenario) {
        randomizeApplicantPersonalData(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        int applicantAge = MAX_YOUNG_AGE;
        int additionalDriverAge = MAX_YOUNG_AGE;
        switch (ageScenario) {
            case ALL_UNDER_25:
                applicantAge--;
                additionalDriverAge--;
                break;
            case PNI_UNDER_25:
                applicantAge--;
                break;
            case SNI_UNDER_25:
                additionalDriverAge--;
                break;
            case OLD_AND_YOUNG:
                applicantAge = 33;
                additionalDriverAge--;
                break;
            case PNI_AND_CHILD:
                applicantAge = 45;
                additionalDriverAge = 20;
                break;
            case LESS_THAN_TEN_YEARS_DRIVING:
                applicantAge = 40;
                applicant.setFirstAgeUnitedStatesDriverLicense(applicantAge - 8);
                break;
        }
        applicant.setAge(applicantAge);
        applicant.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(applicant.getAge()));
        List<SqlAdditionalDriver> updatedAdditionalDrivers = new ArrayList<>();
        for (SqlAdditionalDriver additionalDriver : applicant.getAdditionalDrivers()) {
            additionalDriver.setAge(additionalDriverAge--);
            additionalDriver.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(additionalDriver.getAge()));
            updatedAdditionalDrivers.add(additionalDriver);
        }
        applicant.setAdditionalDrivers(updatedAdditionalDrivers);
        return applicant;
    }

    private List<Vehicle> updateVehiclesToOne(List<Vehicle> vehicles) {
        return new ArrayList<>(Arrays.asList(vehicles.get(0)));
    }

    private List<Vehicle> updateVehiclesToTwo(List<Vehicle> vehicles) {
        return new ArrayList<>(Arrays.asList(vehicles.get(0), vehicles.get(1)));
    }

    private void setUpDataForMatureDriverTest(AutoApplicant applicant) {
        randomizeApplicantPersonalData(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("Brown");
        applicant.setCompletedDriversSafetyCourse(true);
        setRandomAgeForApplicantToSafetyCourse(applicant);
    }

    private void setUpDataForMatureDriverTestBW(AutoApplicant applicant) {
        randomizeApplicantPersonalData(applicant);
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setLastName("BWTESTG");
        applicant.setCompletedDriversSafetyCourse(true);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        setRandomAgeForApplicantToSafetyCourse(applicant);
    }

    private void navigateBackToDriverReviewPage(QuoteSummaryAutoPage quoteSummaryAutoPage) throws Exception {
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
        testStepAssert(heresWhatWeFoundPage.isOnHeresWhatWeFoundPage() || new WhoShouldWeInsurePage().isOnWhoShouldWeInsurePage(),
                "Navigated to 'Who Should We Insure' page or 'Here is what we found' page", true);
        heresWhatWeFoundPage.clickOnContinueButton();

        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "Navigated to Vehicle Review Page", true);
        vehicleReviewPage.clickOnContinueButton();
    }

    private void validateSafetyCourseAndDiscountOnQuoteSummaryAndPayment(DriverReviewPage driverReviewPage, AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String stateCode = applicant.getStateCode();
        boolean isSafetyCourseExpected = driverReviewPage.isSafetyCourseExpectedStateBDQ(stateCode);

        if (isSafetyCourseExpected) {
            driverReviewPage.validateSafetyCourseFunctionality(applicant, true, fsa);
            driverReviewPage.proceedToQuoteSummaryPage(applicant);

            QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
            testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page", true);
            if (stateCode.equals(PA)) {
                quoteSummaryAutoPage.validateDriverImprovementDiscountPresent(fsa);
            } else {
                quoteSummaryAutoPage.validateMatureDriverDiscountPresenceBW(fsa, applicant);
            }


            quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
            BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
            testStepAssert(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User is on the Bristol West payment summary page", true);
            if (stateCode.equals(PA)) {
                quoteSummaryAutoPage.validateDriverImprovementDiscountPresent(fsa);
            } else {
                bwPaymentSummaryPage.validateMatureDriverDiscountPresenceBW(fsa, applicant);
            }
        } else {
            driverReviewPage.validateSafetyCourseCheckBoxNotPresent(fsa, driverReviewPage.getApplicantFullName(applicant));
        }
    }

    private boolean isNoSnackbarState(String stateCode) {
        return Arrays.asList(SD, WI, WY).contains(stateCode);
    }

    private void validateSafetyCourseWithoutSnackbar(DriverReviewPage driverReviewPage, AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String applicantFullName = driverReviewPage.getApplicantFullName(applicant);
        driverReviewPage.validateSafetyCourseCheckboxPresence(applicant, fsa, true, applicantFullName);
        driverReviewPage.addSafetyCourse(applicantFullName);
        driverReviewPage.validateNoSnackBarDisplayed(fsa);
    }

    private void validateSafetyCourseWithDiscount(DriverReviewPage driverReviewPage, AutoApplicant applicant, FarmersSoftAssert fsa, String stateCode) throws Exception {
        boolean isSafetyCourseExpected = driverReviewPage.isSafetyCourseExpectedState(stateCode);
        driverReviewPage.validateSafetyCourseFunctionality(applicant, isSafetyCourseExpected, fsa);
        driverReviewPage.proceedToQuoteSummaryPage(applicant);

        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the quote summary page", true);

        boolean isDefensiveDriverDiscountEnabled = driverReviewPage.isDefensiveDriverDiscountEnabledOnDriverReview(stateCode);
        if (stateCode.equals(PA)) {
            driverReviewPage.validateDriverImprovementDiscountPresent(fsa);
        } else {
            driverReviewPage.validateMatureOrDefensiveDriverDiscountPresent(fsa, isDefensiveDriverDiscountEnabled);
        }

        navigateToPaymentPageAndValidateSafetyCourseDiscount(quoteSummaryAutoPage, stateCode, fsa, isDefensiveDriverDiscountEnabled);
    }

    private void navigateToPaymentPageAndValidateSafetyCourseDiscount(QuoteSummaryAutoPage quoteSummaryAutoPage, String stateCode, FarmersSoftAssert fsa, boolean isDefensiveDriverDiscountEnabled) throws Exception {
        quoteSummaryAutoPage.navigateFromQuoteSummaryPageToPaymentPage(false);
        ConsolidatedPaymentPage consolidatedPaymentPage = new ConsolidatedPaymentPage();
        consolidatedPaymentPage.waitForSpinnerToBeGone();
        consolidatedPaymentPage.closeRateChangedModal();
        testStepAssert(consolidatedPaymentPage.isOnConsolidatedPaymentPage(), "User is on the consolidated payment page", true);
        consolidatedPaymentPage.closeRateChangedModal();
        if (stateCode.equals(PA)) {
            consolidatedPaymentPage.checkDriverImprovementDiscountOnConsolidatedPaymentPage(fsa);
        } else {
            consolidatedPaymentPage.checkDefensiveOrMatureDriverDiscountOnConsolidatedPaymentPage(fsa, isDefensiveDriverDiscountEnabled);
        }
    }

    private void setUpApplicantForMatureDriverTestBDQ(AutoApplicant applicant) {
        applicant.setTestScenario(BW_ORGANIC_FLOW + applicant.getTestScenario());
        applicant.setCompletedDriversSafetyCourse(true);
        applicant.setLastName("BWTESTG");
        setRandomAgeForApplicantToSafetyCourse(applicant);
    }
}
