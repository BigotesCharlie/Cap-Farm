package com.farmers.ffq.auto.defaultcoverage;

import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;
import static com.farmers.ffq.utils.GlobalVariables.AR;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;

public class DefaultCoverageValuesTests_AR extends DefaultCoverageBaseTest {
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_10K20K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=10/20&umbrella=No", "AR_10K20K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 10 K20 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_10K20K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=10/20&umbrella=Yes", "AR_10K20K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 10 K20 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_15K30K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=No", "AR_15K30K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 15 K30 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_15K30K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=Yes", "AR_15K30K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 15 K30 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_20K40K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=No", "AR_20K40K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 20 K40 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_20K40K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=Yes", "AR_20K40K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 20 K40 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "AR_25K50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 25 K50 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "AR_25K50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 25 K50 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_25K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=No", "AR_25K65K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 25 K65 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_25K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=Yes", "AR_25K65K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 25 K65 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "AR_30K60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 30 K60 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "AR_30K60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 30 K60 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_30K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=No", "AR_30K65K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 30 K65 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_30K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=Yes", "AR_30K65K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 30 K65 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "AR_35K70K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 35 K70 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "AR_35K70K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 35 K70 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_35K80K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=No", "AR_35K80K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 35 K80 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_35K80K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=Yes", "AR_35K80K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 35 K80 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "AR_50K100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 50 K100 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "AR_50K100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 50 K100 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "AR_100K200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 100 K200 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "AR_100K200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 100 K200 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "AR_100K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 100 K300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "AR_100K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 100 K300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No","AR_250K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 250 K500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "AR_250K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 250 K500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "AR_300K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 300 K300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "AR_300K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 300 K300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "AR_500K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 500 K500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "AR_500K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 500 K500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_500K1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "AR_500K1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 500 K1 M NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_500K1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "AR_500K1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 500 K1 M UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_1M1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "AR_1M1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 1 M1 M NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_1M1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "AR_1M1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 1 M1 M UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_35K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=No", "AR_35K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 35 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_35K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=Yes", "AR_35K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 35 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_45K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=No", "AR_45K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 45 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_45K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=Yes", "AR_45K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 45 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "AR_50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 50 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_50K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "AR_50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 50 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=No", "AR_60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 60 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_60K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=Yes", "AR_60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 60 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "AR_75K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 75 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_75K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "AR_75K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 75 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_85K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=No", "AR_85K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 85 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_85K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=Yes", "AR_85K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 85 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "AR_100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 100 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "AR_100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 100 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "AR_200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 200 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "AR_200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 200 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "AR_300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "AR_300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "AR_500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "AR_500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "AR_1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 1 M NO UMBRELLA.
	
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "AR_1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR 1 M UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_PIPPD_ONLY_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=PIPPD_Only&umbrella=No", "AR_PIPPD_ONLY_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR PIPPD ONLY NO UMBRELLA.
	
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = AR)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_AR_PIPPD_ONLY_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=PIPPD_Only&umbrella=Yes", "AR_PIPPD_ONLY_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values AR PIPPD ONLY UMBRELLA.

}
