package com.farmers.ffq.auto.defaultcoverage;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class BWDefaultCoverageValuesTests_KY extends DefaultCoverageBaseTest {


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = KY)}, dataProviderClass = AutoDataProviders.class, groups = {AUTO_COVERAGE_VALIDATION})
    public void testBWDefaultCoverageValues_TN_None_Unk(AutoApplicant applicant) throws Exception {
        //This is going to avoid BW condition based on the foreign driver's license
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        defaultCoverageTestForBW(applicant, "coverageAmount=None/Unk&umbrella=No", "KY_None_Unk_");
    }
    // Test description: Validates the Auto behavior for Test BWDefault Coverage Values TN None Unk.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_25K50K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=25/50&umbrella=No", "KY_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 25 K50 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_30K60K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=30/60&umbrella=No", "KY_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 30 K60 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_35K70K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=35/70&umbrella=No", "KY_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 35 K70 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_50K100K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=50/100&umbrella=No", "KY_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 50 K100 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_100K200K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/200&umbrella=No", "KY_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 100 K200 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_100K300K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=100/300&umbrella=No", "KY_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 100 K300 K.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_250K500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=250/500&umbrella=No", "KY_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 250 K500 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_500K500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500/500&umbrella=No", "KY_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 500 K500 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_500K1000K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500/1000&umbrella=No", "KY_500K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 500 K1000 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_60K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=60&umbrella=No", "KY_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 60 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_75K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=75&umbrella=No", "KY_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 75 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_200K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=200&umbrella=No", "KY_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 200 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_500K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=500&umbrella=No", "KY_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 500 K.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = KY)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_TN_1000K(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        bwSpecificDataSetUp(applicant);
        defaultCoverageTestForBW(applicant, "coverageAmount=1000&umbrella=No", "KY_1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values TN 1000 K.
}
