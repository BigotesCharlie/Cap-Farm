package com.farmers.ffq.acebundle;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.Collections;
import java.util.List;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.ace.bundle.AceBundleNavigationHelper;
import com.farmers.ffq.ace.bundle.AceBundleReviewQuotesPage;
import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
import com.farmers.ffq.auto.pages.VehicleDriverAssignmentPage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.AceBundleApplicant;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.report.Log;

//common setup items across all three bundle options
public class AceBundleTestHelper extends AutomationFramework {

	public void applicantAdjustment(AceBundleApplicant bundleApplicant) {
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		autoApplicant.setIncidents(Collections.emptyList());
		if (!autoApplicant.getStateCode().equals(CA)) {
			autoApplicant.setLastName("Brown");
		}
		autoApplicant.setHaveAccidentOrViolations(false);
		autoApplicant.setFinancialFiling(NO);
		autoApplicant.setOccupation(EMPTY_STRING);
		autoApplicant.setCurrentlyInsuredStatus("Insured");
		autoApplicant.setContinuosInsurancePeriod("60+ Months");
		autoApplicant.setCompletedDriversSafetyCourse(false);
		autoApplicant.getAdditionalDrivers().forEach(driver -> {
			if (!autoApplicant.getStateCode().equals(CA)) {
				driver.setLastName("Brown");
			}
			driver.setFinancialFiling(NO);
			driver.setAnyIncident(false);
			driver.setLicenseToDriveInUSA(YES);
			driver.setOccupation(EMPTY_STRING);
			driver.setCompletedDriversSafetyCourse(false);
		});
		autoApplicant.getVehicles().forEach(vehicle -> {
			vehicle.setVehicleUsage("Personal");
			vehicle.setOwnership("Owned");
			vehicle.setRidesharing(false);
			try {
				String randomVIN = new AutoBasePage().getRandomVinNumber(3, autoApplicant.getStateCode());
				if (!randomVIN.isBlank()) {
					vehicle.setUseVIN(true);
					vehicle.setVehicleVIN(randomVIN);
				}
			} catch (Exception e) {
				//Unable to fetch random VIN
				vehicle.setUseVIN(false);
				Log.info("Unable to get random VIN: " + e.getMessage());
			}
			vehicle.setParkInResidentAddress(true);
		});
		ApplicantAceHome applicantAceHome = bundleApplicant.getHrcApplicant();
		if (autoApplicant.getAge() < 35 || autoApplicant.getAge() > 65) {
			autoApplicant.setAge(40);
			autoApplicant.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(40));
			applicantAceHome.setDateOfBirth(BasePage.calculateDateOfBirthFromAge(40));
		}
		//WA knocks out if not using BW data
		if (autoApplicant.getStateCode().equals(WA)) {
			autoApplicant.setCurrentlyInsuredStatus(NEVER_INSURED);
			autoApplicant.setLastName("Threeoabaa");
		}
		bundleApplicant.setHrcApplicant(applicantAceHome);
		bundleApplicant.setAutoApplicant(autoApplicant);
	}

	protected void modifyApplicantToTriggerBWFlow(AceBundleApplicant bundleApplicant) {
		applicantAdjustment(bundleApplicant);
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		String applicantStateCode = autoApplicant.getStateCode();
		if (!applicantStateCode.equals(CA)) {
			if (applicantStateCode.equals(OR)) {
				autoApplicant.setFinancialFiling(SR_22);
			}
			autoApplicant.setCurrentlyInsuredStatus(NEVER_INSURED);
			switch (applicantStateCode) {
				case AZ: case CO: case FL: case GA: case ID: case IL: case IN: case KY: case MA:
				case MI: case MS: case NE: case NJ: case OH: case OR: case TX: case VA: case WA:
					autoApplicant.setLastName("Threeoabaa");
					break;
				case MT:
					autoApplicant.setLastName("Bwtestk");
					break;
				case MD:
					autoApplicant.setLastName("Bwcreda");
					break;
				case PA: case KS:
					autoApplicant.setLastName("Threeiiiaaaa");
					break;
				case OK:
					autoApplicant.setLastName("Bwtesth");
					break;
				default:
					autoApplicant.setLastName("Bwtesti");
					break;
			}
			bundleApplicant.setAutoApplicant(autoApplicant);
		}
	}

	protected void verifyBundleDiscountHasDroppedAutoReviewQuotePage(String droppedLobType, FarmersSoftAssert fsa) throws Exception {
		QuoteSummaryAutoPage autoQuoteSummaryPage = new QuoteSummaryAutoPage();
		fsa.assertTrue(autoQuoteSummaryPage.isOnQuoteSummaryAutoPage(), "Auto quote summary page reached");
		fsa.assertTrue(!autoQuoteSummaryPage.getDisplayedDiscounts().contains("Auto & " + droppedLobType), "Bundle discount dropped in monoline when dropping " + droppedLobType);
	}

	protected void verifyBundleDiscountHasDroppedHRCReviewQuotePage(FarmersSoftAssert fsa) throws Exception {
		String expectedBundleDiscountName = "Auto & Home";
		AceHRCBasePage aceHRCBasePage = new AceHRCBasePage();
		fsa.assertTrue(!aceHRCBasePage.getDiscounts().contains(expectedBundleDiscountName), expectedBundleDiscountName + " bundle discount has dropped");
	}

	public void setKOVINInBundleApplicant(AceBundleApplicant bundleApplicant){
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		autoApplicant.getVehicles().get(0).setUseVIN(true);
		String koVIN = "ZHWUA6ZX2NLA18047";
		autoApplicant.getVehicles().get(0).setVehicleVIN(koVIN);
		autoApplicant.getVehicles().removeIf(i -> !i.getVehicleVIN().equals(koVIN));
		bundleApplicant.setAutoApplicant(autoApplicant);
	}

	public void setVINInBundleApplicantForNonBWAuto(AceBundleApplicant bundleApplicant) throws Exception {
		if (!bundleApplicant.getAutoApplicant().getStateCode().equals(CA)) {
			AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
			autoApplicant.getVehicles().get(0).setUseVIN(true);
			String vinForNonBWAutoFlow = "1HGCM568X6A149614";
			autoApplicant.getVehicles().get(0).setVehicleVIN(vinForNonBWAutoFlow);
			autoApplicant.getVehicles().removeIf(i -> !i.getVehicleVIN().equals(vinForNonBWAutoFlow));
			bundleApplicant.setAutoApplicant(autoApplicant);
		}
	}

	public void setDataForProdValidation(AceBundleApplicant bundleApplicant){
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		autoApplicant.setFirstName(PRODUCTION_APPLICANT_FIRST_NAME);
		autoApplicant.setLastName(PRODUCTION_APPLICANT_LAST_NAME);
		autoApplicant.setEmail(PRODUCTION_APPLICANT_EMAIL);
		bundleApplicant.setAutoApplicant(autoApplicant);
	}

	protected void autoPropertyBundleToMonolineAutoAndPurchase(AceBundleApplicant bundleApplicant, String propertyType, FarmersSoftAssert fsa) throws Exception {
		String bundleType = propertyType.equals(HOME)? AUTO_HOME_BUNDLE: AUTO_RENTERS_BUNDLE;
		AceBundleReviewQuotesPage bundleQuoteSummaryPage = new AceBundleReviewQuotesPage();
		if (!bundleQuoteSummaryPage.isOnBundleReviewQuotesPage()) {
			bundleQuoteSummaryPage = new AceBundleNavigationHelper(bundleType).navigateToBundleQuoteReviewPage(bundleApplicant);
		}
		AppStore appStore = bundleQuoteSummaryPage.getSessionStorageAppStore();
		Double autoBundlePremiumMonthly = bundleQuoteSummaryPage.getMonthlyAutoBundlePremium(appStore.getAuto());
		bundleQuoteSummaryPage.selectSingleQuoteOptionInCPPopUp(AUTO);
		QuoteSummaryAutoPage autoQuoteSummaryPage = new QuoteSummaryAutoPage();
		fsa.assertTrue(autoQuoteSummaryPage.isOnQuoteSummaryAutoPage(), "Auto quote summary page reached");
		Double autoMonoLinePremiumMonthly = bundleQuoteSummaryPage.getMonthlyAutoMonoLinePremium(appStore.getAuto());
		fsa.assertTrue(autoMonoLinePremiumMonthly > autoBundlePremiumMonthly, "MonoLine premium is recalculated - Auto");
		verifyBundleDiscountHasDroppedAutoReviewQuotePage(propertyType, fsa);
		AceAutoNavigationHelper autoNavigationHelper = new AceAutoNavigationHelper();
		autoNavigationHelper.setResumeFromPage(autoQuoteSummaryPage.getClass().getSimpleName());
		autoNavigationHelper.setQuoteDetails("Monoline quote " + autoQuoteSummaryPage.getAceQuoteNumberInThePage() + SPACE + bundleApplicant.getAutoApplicant().getDetails());
		autoNavigationHelper.navigateToPaymentSelectionPage(bundleApplicant.getAutoApplicant());
		new BaseTest().completePurchase(PAY_IN_FULL, PaymentMethods.VISA_DEBIT_CARD_1, false, fsa);
	}

	protected boolean retrieveQuoteAndGoToBundleReviewPage(AceBundleApplicant bundleApplicant, AceBundleNavigationHelper navigatorHelper, AceBundleReviewQuotesPage bundleQuoteSummaryPage, FarmersSoftAssert fsa)
			throws Exception {
		boolean quoteRetrieved = navigatorHelper.retrieveAceBundleQuote(bundleApplicant, navigatorHelper.getBundleQuoteNumber());
		if (quoteRetrieved) {
			String stepperCheck = " step check";
			List<String> listOfExpectedStepsStrings = List.of(AUTO_INFO, PROPERTY_INFO, REVIEW_QUOTE, PURCHASE);
			List<String> listOfObservedStepsStrings = bundleQuoteSummaryPage.getListOfSteps();
			fsa.assertEquals(listOfObservedStepsStrings, listOfExpectedStepsStrings, "Stepper content");
			if (!listOfObservedStepsStrings.isEmpty()) {
				fsa.assertEquals(bundleQuoteSummaryPage.getStepState(AUTO_INFO), ENABLED, AUTO_INFO + stepperCheck);
				fsa.assertEquals(bundleQuoteSummaryPage.getStepState(PROPERTY_INFO), DISABLED, PROPERTY_INFO + stepperCheck);
				fsa.assertEquals(bundleQuoteSummaryPage.getStepState(REVIEW_QUOTE), DISABLED, REVIEW_QUOTE + stepperCheck);
				fsa.assertEquals(bundleQuoteSummaryPage.getStepState(PURCHASE), DISABLED, PURCHASE + stepperCheck);
			}
			//Click continue on the next two/three pages to get to the Bundle Review Quote page
			boolean needToAssignVehiclesToDrivers = true;
			for (int times=1; times<4; times++) {
				if (needToAssignVehiclesToDrivers && new VehicleDriverAssignmentPage().quickIsOnVehicleDriverAssignmentPage()) {
					needToAssignVehiclesToDrivers = !(new VehicleDriverAssignmentPage().saveAndCheckForNoErrors());
				}
				bundleQuoteSummaryPage.clickContinueButton();
				bundleQuoteSummaryPage.waitForSpinnerToBeGone();
				if (bundleQuoteSummaryPage.isOnBundleReviewQuotesPage()) {
					break;
				}
			}
		}
		return quoteRetrieved;
	}
}
