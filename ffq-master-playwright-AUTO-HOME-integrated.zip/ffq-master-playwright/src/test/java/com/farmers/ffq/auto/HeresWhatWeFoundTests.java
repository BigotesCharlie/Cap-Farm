package com.farmers.ffq.auto;


import com.microsoft.playwright.Page;
import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.HeresWhatWeFoundPage;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
import com.farmers.ffq.auto.pages.VehiclesDriversInfoPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.ADPFApplicant;
import com.farmers.framework.report.Log;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.Optional;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class HeresWhatWeFoundTests extends BaseTest {

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void testADPFPrefillDataForRandomCombination(ADPFApplicant applicant) throws Exception {
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPageUsingDefaults(applicant);
        testStep("Navigated to Quote Summary Auto Page.");
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Failed to generate a quote for combination: " + applicant.getNumberOfVehicles()+ "V/" + applicant.getNumberOfDrivers() + "D");
        testStep("Successfully validated ADPF prefill data for the selected combination.");
        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Test ADPFPrefill Data For Random Combination.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_AND_VEHICLES)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void testADPF_applicantVehicleInfoUpdate(ADPFApplicant applicant) throws Exception {
        testStep("Starting test to validate if first name, last name, and age of drivers are displayed when prefilled by ADPF.");
        testStep("Navigating to 'Here's What We Found' page using the filtered applicant.");
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        testStep("Validate if vehicle year has been updated");
        testStepAssert(heresWhatWeFoundPage.isUpdatedVehicleDisplayedCorrectly(), "Vehicle details are updated");
        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Test ADPF applicant Vehicle Info Update.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.VEHICLES_GT_1)}, groups = {ADA_SUITE, FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND, ACE_AUTO_ADA_SUITE})
    public void testAddAnotherVehicleLinkNotDisplayedWhenFiveOrMoreVehiclesSelectedOrPrefilled(ADPFApplicant applicant) throws Exception {
        testStep("Starting test to validate 'Add another vehicle' link visibility based on the number of vehicles selected or pre-filled.");
        Log.info("Applicant with " + applicant.getNumberOfVehicles() + " vehicles.");

        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        heresWhatWeFoundPage.validateADA_HeresWhatWeFoundPage();
        int vehicleCount = applicant.getNumberOfVehicles();
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        boolean isLinkDisplayed = heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode()) ? vehiclesDriversInfoPage.isAddAnotherVehicleButtonDisplayed() : heresWhatWeFoundPage.isAddAnotherVehicleLinkDisplayed();
        Log.info("Vehicle count is: " + vehicleCount);
        Log.info("'Add another vehicle' link display status: " + isLinkDisplayed);
        if (vehicleCount >= 5) {
            testStepAssert(!isLinkDisplayed, "The 'Add another vehicle' link should NOT be displayed when there are 5 or more vehicles. Vehicle count: " + vehicleCount);
        } else {
            testStepAssert(isLinkDisplayed, "The 'Add another vehicle' link should be displayed when there are fewer than 5 vehicles. Vehicle count: " + vehicleCount);
        }
        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Test Add Another Vehicle Link Not Displayed When Five Or More Vehicles Selected Or Prefilled.

    // TODO: need test data
    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_5)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void testAdditionalDriversCheckboxesUncheckedWhenMoreThanFourCompleteDrivers(ADPFApplicant applicant) throws Exception {
        testStep("Starting test for validating checkboxes when more than 4 additional complete drivers are returned.");
        testStep("Navigating to 'Here's What We Found' page with filtered applicant");
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);

        testStep("Asserting that checkboxes are not checked for any additional drivers");
        if (heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            testStepAssert(
                    vehiclesDriversInfoPage.selectedDrivers.count() == 0,
                    "Expected checkboxes not to be checked for any additional drivers, found "
                            + vehiclesDriversInfoPage.selectedDrivers.count()
                            + " checked drivers."
            );
        } else {
            testStepAssert(
                    heresWhatWeFoundPage.getNumberOfCheckedDrivers() == 0,
                    "Expected checkboxes not to be checked for any additional drivers, found "
                            + heresWhatWeFoundPage.getNumberOfCheckedDrivers()
                            + " checked drivers."
            );
        }
        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Test Additional Drivers Checkboxes Unchecked When More Than Four Complete Drivers.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.ONE_TO_FIVE_VEHICLES)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void testAllCompleteVehiclesBoxesCheckedWhen1To5VehiclesFoundInADPFCall(ADPFApplicant applicant) throws Exception {
        testStep("Starting test for validating complete vehicles boxes when 1 to 5 vehicles are found in ADPF call");
        testStep("Navigating to 'Here's What We Found' page with filtered applicant");
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);

        testStep("Asserting that all vehicles are checked");
        if (heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            testStepAssert(
                    vehiclesDriversInfoPage.uncheckedVehiclesCheckboxes.count() == 0
                            && vehiclesDriversInfoPage.selectedVehiclesCheckboxes.count() == applicant.getNumberOfVehicles(),
                    "Expected 0 unchecked vehicles and " + applicant.getNumberOfVehicles() + " checked vehicles, found "
                            + vehiclesDriversInfoPage.uncheckedVehiclesCheckboxes.count()
                            + " unchecked and "
                            + vehiclesDriversInfoPage.selectedVehiclesCheckboxes.count()
                            + " checked vehicles."
            );
        } else {
            testStepAssert(
                    heresWhatWeFoundPage.getListOfUnCheckedVehicles().isEmpty()
                            && heresWhatWeFoundPage.getListOfCheckedVehicles().size() == applicant.getNumberOfVehicles(),
                    "Expected 0 unchecked vehicles and " + applicant.getNumberOfVehicles() + " checked vehicles, found "
                            + heresWhatWeFoundPage.getListOfUnCheckedVehicles().size()
                            + " unchecked and "
                            + heresWhatWeFoundPage.getListOfCheckedVehicles().size()
                            + " checked vehicles."
            );
        }
        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Test All Complete Vehicles Boxes Checked When1 To5 Vehicles Found In ADPFCall.

    //TODO: need a test data (adpf applicant) that has complete and incomplete vehicle/driver
    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.NO_INCOMPLETE_DRIVERS_AND_VEHICLES)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void testCheckboxCheckedForPrefilledCompleteVehicleDriverInfo(ADPFApplicant applicant) throws Exception {
        testStep("Starting test to validate that the checkbox is checked by default if the prefilled vehicle/driver has all the fields updated");
        testStep("Navigating to 'Here's What We Found' page with filtered applicant");
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        testStep("Asserting that the checkboxes are checked for the applicant with complete vehicle/driver information");
        if (heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            testStepAssert(
                    vehiclesDriversInfoPage.selectedDrivers.count() == applicant.getNumberOfDrivers(),
                    "Expected " + applicant.getNumberOfDrivers() + " checkboxes to be checked for the drivers with complete information, found " + vehiclesDriversInfoPage.selectedDrivers.count()
            );
            testStepAssert(
                    vehiclesDriversInfoPage.selectedVehiclesCheckboxes.count() == applicant.getNumberOfVehicles(),
                    "Expected " + applicant.getNumberOfVehicles() + " checkboxes to be checked for the vehicles with complete information, found " + heresWhatWeFoundPage.getNumberOfCheckedVehicles()
            );
        } else {
            testStepAssert(
                    heresWhatWeFoundPage.getNumberOfCheckedDrivers() == applicant.getNumberOfDrivers(),
                    "Expected " + applicant.getNumberOfDrivers() + " checkboxes to be checked for the drivers with complete information, found " + heresWhatWeFoundPage.getNumberOfCheckedDrivers()
            );
            testStepAssert(
                    heresWhatWeFoundPage.getNumberOfCheckedVehicles() == applicant.getNumberOfVehicles(),
                    "Expected " + applicant.getNumberOfVehicles() + " checkboxes to be checked for the vehicles with complete information, found " + heresWhatWeFoundPage.getNumberOfCheckedVehicles()
            );
        }
        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Test Checkbox Checked For Prefilled Complete Vehicle Driver Info.

    //TODO: need a test data (adpf applicant) that has incomplete vehicle/driver
    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.INCOMPLETE_DRIVERS_AND_VEHICLES)},groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void testCheckboxUncheckedForIncompleteVehicleDriverInfo(ADPFApplicant applicant) throws Exception {
        testStep("Starting test to validate that the checkbox is not checked by default if the prefilled vehicles/drivers has incomplete fields");
        testStep("Navigating to 'Here's What We Found' page with filtered applicant");
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        testStep("Asserting that the checkboxes are not checked for the applicant with incomplete vehicle/driver information");
        if (heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            testStepAssertTrue(vehiclesDriversInfoPage.uncheckedDriversNames.count() == applicant.getNumberOfIncompleteDrivers(), "Expected: (" + applicant.getNumberOfIncompleteDrivers() + ") checkboxes to be unchecked for the drivers with incomplete information. Actual: (" + vehiclesDriversInfoPage.uncheckedDriversNames.count() + ") checkboxes is unchecked for the drivers with incomplete information");
            testStepAssertTrue(vehiclesDriversInfoPage.uncheckedVehiclesCheckboxes.count() == applicant.getNumberOfIncompleteVehicles(), "Expected: (" + applicant.getNumberOfIncompleteVehicles() + ") checkboxes to be unchecked for the vehicles with incomplete information. Actual: (" + vehiclesDriversInfoPage.uncheckedVehiclesCheckboxes.count() + ") checkboxes is unchecked for the vehicles with incomplete information");
        } else {
            testStepAssertTrue(heresWhatWeFoundPage.getNumberOfUncheckedDrivers() == applicant.getNumberOfIncompleteDrivers(), "Expected: (" + applicant.getNumberOfIncompleteDrivers() + ") checkboxes to be unchecked for the drivers with incomplete information. Actual: (" + heresWhatWeFoundPage.getNumberOfUncheckedDrivers() + ") checkboxes is unchecked for the drivers with incomplete information");
            testStepAssertTrue(heresWhatWeFoundPage.getNumberOfUncheckedVehicles() == applicant.getNumberOfIncompleteVehicles(), "Expected: (" + applicant.getNumberOfIncompleteVehicles() + ") checkboxes to be unchecked for the vehicles with incomplete information. Actual: (" + heresWhatWeFoundPage.getNumberOfUncheckedVehicles() + ") checkboxes is unchecked for the vehicles with incomplete information");
        }
    }
    // Test description: Validates the Auto behavior for Test Checkbox Unchecked For Incomplete Vehicle Driver Info.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_0)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void testDriverPNICheckboxStatus(ADPFApplicant applicant) throws Exception {
        testStep("Starting test to validate if Driver PNI checkbox is checked by default based on the completeness of driver information.");
        testStep("Navigating to 'Here's What We Found' page with filtered applicant");
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        testStep("Validating Driver PNI checkbox status");
        if (heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            testStepAssert(vehiclesDriversInfoPage.validatePNIDriverCheckboxStatus(), "The Driver PNI checkbox should be checked if all driver info is complete and unchecked otherwise.");
        } else {
            testStepAssert(heresWhatWeFoundPage.validateDriverPNICheckboxStatus(), "The Driver PNI checkbox should be checked if all driver info is complete and unchecked otherwise.");
        }
        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Test Driver PNICheckbox Status.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_0)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void testDriverPNIFieldsAreNonEditableAndDobIsMasked(ADPFApplicant applicant) throws Exception {
        testStep("Navigating to 'Here's What We Found' page with filtered applicant");
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);

        String dateOfBirth = applicant.getDateOfBirth();
        String dobMask = "**/**/" + dateOfBirth.substring(dateOfBirth.length() - 4);

        if (heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();

            Log.info("Click on edit button of PNI driver");
            vehiclesDriversInfoPage.clickEditButtonWithDriverFullName(vehiclesDriversInfoPage.getPniFullNameFromAutoAdpfApplicant(applicant));

            testStep("Checking if DOB is not editable");
            testStepAssert(!vehiclesDriversInfoPage.isDobEditable(), "Date of birth field should not be editable.");

            testStep("Checking if DOB is masked");
            testStepAssert(vehiclesDriversInfoPage.getDateOfBirthValue().equals(dobMask), "DOB should be masked.");
        } else {
            Log.info("Click on edit button of PNI driver");
            heresWhatWeFoundPage.clickOnEditButtonOfPNIDriver();
            testStep("Checking if DOB is not editable");
            testStepAssert(!heresWhatWeFoundPage.isDobEditable(), "Date of birth field should not be editable.");

            testStep("Checking if DOB is masked");
            testStepAssert(heresWhatWeFoundPage.getDateOfBirthValue().equals(dobMask), "DOB should be masked.");
        }
        testStep("Checking if First Name is not editable");
        testStepAssert(!heresWhatWeFoundPage.isFirstNameEditable(), "First name field should not be editable.");

        testStep("Checking if Last Name is not editable");
        testStepAssert(!heresWhatWeFoundPage.isLastNameEditable(), "Last name field should not be editable.");

        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Test Driver PNIFields Are Non Editable And Dob Is Masked.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.INCOMPLETE_DRIVERS_AND_NO_DRIVERS)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void validateIncompleteDriverIsNotChecked(ADPFApplicant applicant) throws Exception {
        testStep("Starting test to validate that 'Edit Driver' module is opened when an incomplete driver check box is checked");
        testStep("Navigating to 'Here's What We Found' page with filtered applicant");
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        if (!heresWhatWeFoundPage.getListOfUnCheckedDrivers().isEmpty()) {
        	heresWhatWeFoundPage.validateIncompleteDriverIsNotChecked(applicant);
		} else {
            testStep("No unchecked drivers were found");
		}
        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Validate Incomplete Driver Is Not Checked.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.ONE_INCOMPLETE_VEHICLE)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void validateIncompleteVehicleIsNotChecked(ADPFApplicant applicant) throws Exception {
        testStep("Navigating to 'Here's What We Found' page with filtered applicant");
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        if (heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.validateIncompleteVehicleIsNotChecked();
        } else {
            heresWhatWeFoundPage.validateIncompleteVehicleIsNotChecked();
        }
        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Validate Incomplete Vehicle Is Not Checked.

    // Excluded streamline states as similar test case added for consolidated vehicle driver page for streamline state
    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.ONE_INCOMPLETE_VEHICLE)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void validateSideSheetOpenWhenUserClicksVehicleEditButton(ADPFApplicant applicant) throws Exception {
        testStep("Navigating to 'Here's What We Found' page with filtered applicant");
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        if(!aceAutoNavigationHelper.isVehiclesDriversConsolidationImpl(applicant.getStateCode())){
            HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
            heresWhatWeFoundPage.validateVehicleEditClicksOpenSideSheet();
            testStep(TEST_COMPLETED);
        }
    }
    // Test description: Validates the Auto behavior for Validate Side Sheet Open When User Clicks Vehicle Edit Button.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.NO_INCOMPLETE_VEHICLES_AND_LT_FIVE_VEHICLES)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void validateLessThanFiveCompleteVehiclesChecked(ADPFApplicant applicant) throws Exception {
        testStep("Navigating to 'Here's What We Found' page with filtered applicant");
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        if(heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())){
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.validateLessThanFiveCompleteVehiclesAreChecked();
        }else{
            heresWhatWeFoundPage.validateLessThanFiveCompleteVehiclesAreChecked();
        }
        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Validate Less Than Five Complete Vehicles Checked.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_AND_NO_VEHICLES)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void testErrorMessageForZeroVehiclesWithDriverInfoOnClickingContinue(ADPFApplicant applicant) throws Exception {
        testStep("Starting test to validate the error message when ADPF prefills with 0 vehicles but with driver info and the user clicks 'Continue'");
        testStep("Navigating to 'Here's What We Found' page with filtered applicant");
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        String actualErrorMessage;
        String expectedErrorMessage;
        if (heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            actualErrorMessage = vehiclesDriversInfoPage.getTextFromElement(vehiclesDriversInfoPage.pageCTAErrorMessage);
            expectedErrorMessage = "Please select at least one vehicle.";
        } else {
            Log.info("Adding applicant details");
            String fullName = applicant.getFirstName() + SPACE + applicant.getLastName();
            heresWhatWeFoundPage.addADPFApplicant(Optional.empty(), fullName, applicant.getGender(), applicant.getDateOfBirth());
            Log.info("Clicking 'Continue' button");
            heresWhatWeFoundPage.clickContinueButton();
            actualErrorMessage = heresWhatWeFoundPage.getErrorMessage();
            expectedErrorMessage = "Please select at least one vehicle";
        }
        testStep("Asserting the error message when there are 0 vehicles but with driver info");
        testStepAssert(actualErrorMessage, expectedErrorMessage, "Expected:(" + expectedErrorMessage + ") error message should be displayed when continue is clicked.Actual:(" + actualErrorMessage + ") error message is displayed");
        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Test Error Message For Zero Vehicles With Driver Info On Clicking Continue.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_0)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void testFirstNameLastNameAge_PreFilledByAPDF(ADPFApplicant applicant) throws Exception {
        testStep("Starting test to validate if first name, last name, and age of drivers are displayed when prefilled by ADPF.");

        testStep("Navigating to 'Here's What We Found' page using the filtered applicant.");
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);

        testStep("Validating if first name, last name, and age of drivers are correctly displayed.");
        testStepAssert(heresWhatWeFoundPage.validateDriverFirstNameLastNameAndAgeDisplayed(applicant), "The first name, last name, and age of drivers should be displayed if prefilled by ADPF.");

        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Test First Name Last Name Age Pre Filled By APDF.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.DRIVERS_GT_5)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void testNoVehicleBoxesCheckedForSixOrMoreVehiclesInADPFResponse(ADPFApplicant applicant) throws Exception {
        testStep("Starting test to validate that no vehicle boxes are checked when six or more vehicles are found in ADPF response");
        testStep("Navigating to 'Here's What We Found' page with filtered applicant");
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);

        testStep("Asserting that all drivers are unchecked when number of drivers is 6 or more");
        if (heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            testStepAssert(
                    vehiclesDriversInfoPage.uncheckedDriversNames.count() == applicant.getNumberOfDrivers()
                            && vehiclesDriversInfoPage.selectedDrivers.count() == 0,
                    "Expected 6 or more unchecked drivers and 0 checked drivers, found "
                            + vehiclesDriversInfoPage.uncheckedDriversNames.count()
                            + " unchecked and "
                            + vehiclesDriversInfoPage.selectedDrivers.count()
                            + " checked drivers."
            );
        } else {
            testStepAssert(
                    heresWhatWeFoundPage.getListOfDrivers(UNCHECKED).size() == applicant.getNumberOfDrivers()
                            && heresWhatWeFoundPage.getListOfDrivers(CHECKED).isEmpty(),
                    "Expected 6 or more unchecked drivers and 0 checked drivers, found "
                            + heresWhatWeFoundPage.getListOfDrivers(UNCHECKED).size()
                            + " unchecked and "
                            + heresWhatWeFoundPage.getListOfDrivers(CHECKED).size()
                            + " checked drivers."
            );
        }
        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Test No Vehicle Boxes Checked For Six Or More Vehicles In ADPFResponse.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.VEHICLES_GT_1)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void testPrefilledVehicleYearMakeModelAndLastThreeVinDigits(ADPFApplicant applicant) throws Exception {
        testStep("Starting test to validate prefilled vehicle year, make, model, and last three VIN digits");
        testStep("Navigating to 'Here's What We Found' page with filtered applicant");
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);

        testStep("Asserting that VIN is properly masked for all listed ADPF vehicles");
        testStepAssert(heresWhatWeFoundPage.AreAllAdpfVehicleVinProperlyMasked(), "VINs were properly masked");

        testStep("Asserting that vehicle make, model, year, and last three VIN digits are displayed");
        testStepAssert(heresWhatWeFoundPage.areVehicleMakeModelYearAndVinDisplayed(), "Vehicle make, model, year, and last three VIN digits were not displayed");
        testStep(TEST_COMPLETED);
    }
    // Test description: Validates the Auto behavior for Test Prefilled Vehicle Year Make Model And Last Three Vin Digits.

    @Test(dataProvider = AutoDataProviders.ADPF_APPLICANT_WITH_DRIVER_VEHICLE_NUMBER_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
            attributes = {@CustomAttribute(name = AutoDataProviders.VEHICLES_AND_DRIVERS_AND_INCOMPLETE_DRIVERS)}, groups = {FFQ_ONEUI, HERE_IS_WHAT_WE_HAVE_FOUND})
    public void validateSnackbarMessages(ADPFApplicant applicant) throws Exception {
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        if(!aceAutoNavigationHelper.isVehiclesDriversConsolidationImpl(applicant.getStateCode())){
            HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
            String fullName = applicant.getFirstName() + SPACE + applicant.getLastName();
            heresWhatWeFoundPage.addADPFApplicant(Optional.empty(), fullName, applicant.getGender(), applicant.getDateOfBirth());
            heresWhatWeFoundPage.clickEditButtonWithDriverFullName(applicant.getFirstName() + SPACE + applicant.getLastName());
            heresWhatWeFoundPage.clickDriverSaveChangesButton();
            testStepAssert(heresWhatWeFoundPage.isSnackBarMessageDisplayed("Driver has been successfully edited"), "Driver edit snackbar message validated");
            heresWhatWeFoundPage.clickAddAnotherDriverButton();
            heresWhatWeFoundPage.addDriverDetails(25);
            heresWhatWeFoundPage.saveButton.click();
            testStepAssert(heresWhatWeFoundPage.isSnackBarMessageDisplayed("A driver has been added successfully to your quote"), "New driver addition snackbar message");
            heresWhatWeFoundPage.clickRandomCompleteVehicleEditButton();
            heresWhatWeFoundPage.clickVehicleSaveChangesButton();
            testStepAssert(heresWhatWeFoundPage.isSnackBarMessageDisplayed("Vehicle has been successfully edited"), "Vehicle edit snackbar message");
            heresWhatWeFoundPage.addRandomAdditionalVehicle();
            testStepAssert(heresWhatWeFoundPage.isSnackBarMessageDisplayed("A vehicle has been added successfully to your quote"), "New Vehicle add snackbar message");
            testStep(TEST_COMPLETED);
        }
    }
    // Test description: Validates the Auto behavior for Validate Snackbar Messages.

}
