package com.farmers.ffq.auto;


import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.AutoEnterAddressPage;
import com.farmers.ffq.auto.pages.NameAndDobPage;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.ADPFApplicant;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class QuoteScenariosOneUi extends BaseTest {

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {QUOTEONEUI, FFQ_ONEUI})
	public void nameAndDobOneUIAutoQuote(AutoApplicant applicant) throws Exception {
		AceAutoNavigationHelper pages = new AceAutoNavigationHelper();
		NameAndDobPage nameAndDobPage = pages.navigateToNameAndDobPage(applicant);
		nameAndDobPage.filloutApplicantForm(applicant);
	}
	// Test description: Validates the Auto behavior for Name And Dob One UIAuto Quote.

	@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, groups = FFQ_ONEUI)
	public void ratedQuoteWithADPFDataTest(ADPFApplicant applicant) throws Exception {
		QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPageUsingDefaults(applicant);
		quoteSummaryAutoPage.waitForPageTitleAppear();
		Assert.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Reached quote summary page with ADPF data");
	}
	// Test description: Validates the Auto behavior for Rated Quote With ADPFData Test.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
    		attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {CA, WA})},
    		dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, QUOTEONEUI})
	public void testValidatePremiumAccuracyInQuote_QuoteScenariosOneUi(AutoApplicant applicant) throws Exception {
		updateApplicantDataToAvoidPossibleBw(applicant);
		QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToQuoteSummaryAutoPage(applicant);
		quoteSummaryAutoPage.waitForPageTitleAppear();
		quoteSummaryAutoPage.validatePremiumAccuracyInQuoteSummaryAutoPage();
	}
	// Test description: Validates the Auto behavior for Test Validate Premium Accuracy In Quote Quote Scenarios One Ui.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, groups = {PEWC})
	public void aceAutoPEWCScreen(AutoApplicant applicant) throws Exception {
		AceAutoNavigationHelper pages = new AceAutoNavigationHelper();
		NameAndDobPage nameAndDobPage = pages.navigateToNameAndDobPage(applicant);
		nameAndDobPage.capturePEWC();
		AutoEnterAddressPage addressPage = pages.navigateToAutoEnterAddressPage(applicant);
		addressPage.capturePEWC();
	}
	// Test description: Validates the Auto behavior for Ace Auto PEWCScreen.
}
