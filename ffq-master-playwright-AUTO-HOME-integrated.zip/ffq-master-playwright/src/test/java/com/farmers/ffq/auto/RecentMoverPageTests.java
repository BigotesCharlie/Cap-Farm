package com.farmers.ffq.auto;

import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.ADPFApplicant;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.List;

import static com.farmers.ffq.dataproviders.AutoDataProviders.listOfAutoApplicants;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class RecentMoverPageTests extends BaseTest {

    //PQ :Proceed with ADPF, PA: Proceed without ADPF

    public static final String RECENT_MOVER_PAGE_VALIDATION = "RecentMoverPageValidation";

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"46"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})
    public void validateRecentMoverPage(ADPFApplicant adpfApplicant) throws Exception {
        AutoRecentMoverPage autoRecentMoverPage = new AceAutoNavigationHelper().navigateToAutoRecentMoverPage(adpfApplicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        autoRecentMoverPage.validateRecentMoverPage(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Recent Mover Page.

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"46"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})
    public void validateManualEntryPopUp(ADPFApplicant adpfApplicant) throws Exception {
        AutoRecentMoverPage autoRecentMoverPage = new AceAutoNavigationHelper().navigateToAutoRecentMoverPage(adpfApplicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        autoRecentMoverPage.validateManualEntryPopUp(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Manual Entry Pop Up.

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"46"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})
    public void validateManualEntrySection(ADPFApplicant adpfApplicant) throws Exception {
        AutoRecentMoverPage autoRecentMoverPage = new AceAutoNavigationHelper().navigateToAutoRecentMoverPage(adpfApplicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        autoRecentMoverPage.validateManualEntrySection(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Manual Entry Section.

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"46"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})
    public void validateRecentMoverZipCodeMismatch(ADPFApplicant adpfApplicant) throws Exception {
        AutoRecentMoverPage autoRecentMoverPage = new AceAutoNavigationHelper().navigateToAutoRecentMoverPage(adpfApplicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        autoRecentMoverPage.validateRecentMoverZipCodeMismatch(fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Recent Mover Zip Code Mismatch.

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"47","48"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})
    public void validateUserGetKOWithIidBehaviorCode_SC(ADPFApplicant adpfApplicant) throws Exception {
    	try {
    		new AceAutoNavigationHelper().navigateToAutoRecentMoverPage(adpfApplicant);
    	} catch (IllegalStateException ise) {
    		// expecting to not reach it
    	} finally {
    		FarmersSoftAssert fsa = new FarmersSoftAssert();
    		KnockoutInconveniencePage knockoutInconveniencePage = new KnockoutInconveniencePage();
    		fsa.assertEquals(knockoutInconveniencePage.getSessionStorageAppStore().getControlData().getIidBehaviorCode(), "SC", "Behavior code as expected");
    		knockoutInconveniencePage.validateIidBehavior_SC_KO(fsa);
    		fsa.assertAll("[SC Flow] Verify on the submit of address screen, if IID returns code as '25' with behaviour code 'SC' verify user gets knocked out.");
    	}
    }
    // Test description: Validates the Auto behavior for Validate User Get KOWith Iid Behavior Code SC.


    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"46"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})
    public void validateUserLandsOnWhoShouldWeInsurePageWithRecentMoved_Answer_No(ADPFApplicant adpfApplicant) throws Exception {
        AutoRecentMoverPage autoRecentMoverPage = new AceAutoNavigationHelper().navigateToAutoRecentMoverPage(adpfApplicant);
        testStep("#356 -> [Answer 'No'] Verify that on clicking 'No' to the question, then user is allowed to proceed to 'Vehicles/drivers review' screen to enter details manually", true);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        autoRecentMoverPage.processRecentMoverPage(adpfApplicant, false, false, false);
        getNonAdpfFlow(adpfApplicant, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate User Lands On Who Should We Insure Page With Recent Moved Answer No.

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"46"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})
    public void validateRecentMoverFlowUntilQuotePageWithGooglePrefill(ADPFApplicant adpfApplicant) throws Exception {
    	AutoRecentMoverPage autoRecentMoverPage = new AceAutoNavigationHelper().navigateToAutoRecentMoverPage(adpfApplicant);
    	FarmersSoftAssert fsa = new FarmersSoftAssert();
    	testStepAssert(autoRecentMoverPage.isOnRecentMoverPage(), "#350: [Answer 'Yes'/PQ Flow/Google pre-fill] Verify when user adds the previous address (any random address from same state or different state) by selecting from Google prefill suggestions and clicks 'Continue', then user should be able proceed successfully to the next screen with ADPF pre-filling both Vehicles and drivers. Ensure if user is able to proceed successfully and rate the quote (i.e.) Existing flow should continue without issues.", true);
    	autoRecentMoverPage.processRecentMoverPage(adpfApplicant, true, false, false);
    	if (new HeresWhatWeFoundPage().isOnHeresWhatWeFoundPage()) {
    		getAdpfFlow(adpfApplicant, fsa);
    		waitForUiSettled();
    		new LandingPage().retrieveQuoteFromLandingPage(adpfApplicant, autoRecentMoverPage.getSessionStorageAppStore().getData().getQuoteNumber());
    		fsa.assertTrue(autoRecentMoverPage.isSnackBarMessageDisplayed("Welcome back " + adpfApplicant.getFirstName()), "Welcome back message is dispaled for retrieval of rated quote");
    		fsa.assertTrue(new QuoteSummaryAutoPage().isOnQuoteSummaryAutoPage(), "User is on the quote summary page");
    	} else {
    		Log.warn("User is expected to be on the Here Is What We Found page for this test, please try later", true);
    	}
    	fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Recent Mover Flow Until Quote Page With Google Prefill.

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"46"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})
    public void validateRecentMoverFlowUntilQuotePageWithManualAddress(ADPFApplicant adpfApplicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AutoRecentMoverPage autoRecentMoverPage = new AceAutoNavigationHelper().navigateToAutoRecentMoverPage(adpfApplicant);
        testStepAssert(autoRecentMoverPage.isOnRecentMoverPage(), "#352: [Answer 'Yes'/PQ Flow/Manual entry] Verify if user is able to add previous address by clicking 'Yes, enter manually' and able to proceed. Also, validate if user adds address manually (any random address from same state or different state) and clicks 'Continue', then user should be able proceed successfully with ADPF prefilling both Vehicles and drivers. Ensure if user is able to proceed successfully and rate (i.e.) Existing flow should continue without issues.", true);
        autoRecentMoverPage.processRecentMoverPage(adpfApplicant, true, true, false);
        if (new HeresWhatWeFoundPage().isOnHeresWhatWeFoundPage()) {
        	getAdpfFlow(adpfApplicant, fsa);
        	LandingPage landingPage = new LandingPage(autoRecentMoverPage.isUseMobileViewEnabled());
        	// validate retrieval is not working with the previous zipcode
        	landingPage.retrieveQuoteFromLandingPage(adpfApplicant.getLastName(), adpfApplicant.getDateOfBirth(), autoRecentMoverPage.getSessionStorageAppStore().getData().getQuoteNumber(), "18353");
        	fsa.assertTrue(landingPage.isQuoteNotFoundPopUpPresent(), "Quote retrieval error message is displayed");
        	testStep("#362 - Validate after rating the quotes in (PQ flow), check if retrieval is not working when user uses 'Zip code' of the previous address.", true);
        } else {
        	Log.warn("User is expected to be on the Here Is What We Found page for this test, please try later", true);
            return;
        }
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Recent Mover Flow Until Quote Page With Manual Address.


    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"46"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})
    public void validateTheRecentMoverFlowWithTheSameAddress_ManualEntry(ADPFApplicant adpfApplicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AutoRecentMoverPage autoRecentMoverPage = new AceAutoNavigationHelper().navigateToAutoRecentMoverPage(adpfApplicant);
        testStepAssert(autoRecentMoverPage.isOnRecentMoverPage(), "#355: [Answer 'Yes'/PA Flow/Manual entry] Verify if user is able to add previous address by clicking 'Yes, enter manually' and able to proceed. Also, validate if user adds address manually (the same address which was added in the address screen should be used) and clicks 'Continue', then user should be able proceed successfully to the next screen without pre-filling Vehicles or drivers. Verify if user adds both vehicles/drivers manually and proceeds successfully to rate (i.e.) Existing flow should continue without issues.", true);
        autoRecentMoverPage.processRecentMoverPage(adpfApplicant, true, true, true);
        getNonAdpfFlow(adpfApplicant, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate The Recent Mover Flow With The Same Address Manual Entry.

    @Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"46"})}, groups = {FFQ_ONEUI, RECENT_MOVER_PAGE_VALIDATION})
    public void validateTheRecentMoverFlowWithTheSameAddress_Google_prefill(ADPFApplicant adpfApplicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        AutoRecentMoverPage autoRecentMoverPage = new AceAutoNavigationHelper().navigateToAutoRecentMoverPage(adpfApplicant);
        testStepAssert(autoRecentMoverPage.isOnRecentMoverPage(), "#354: [Answer 'Yes'/PA Flow/Google pre-fill] Verify when user adds the previous address (the same address which was added in the address screen should be used) by selecting from Google pre-fill suggestions and clicks 'Continue', then user should be able proceed successfully to the next screen without pre-filling Vehicles or drivers. Verify if user adds both vehicles/drivers manually and proceeds successfully to rate the quote (i.e.) Existing flow should continue without issues.", true);
        autoRecentMoverPage.processRecentMoverPage(adpfApplicant, true, false, true);
        getNonAdpfFlow(adpfApplicant, fsa);
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate The Recent Mover Flow With The Same Address Google prefill.

    private void getNonAdpfFlow(ADPFApplicant adpfApplicant, FarmersSoftAssert fsa) throws Exception {
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        fsa.assertTrue(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User landed on " + whoShouldWeInsurePage.getClass().getSimpleName());
        List<AutoApplicant> autoApplicants = listOfAutoApplicants("applicant", "stateCode=" + adpfApplicant.getStateCode());
        AutoApplicant applicant = autoApplicants.stream().filter(each -> each.getApplicantId() == 1).findFirst().get();
        applicant.setLastName(adpfApplicant.getLastName());
        applicant.setFirstName(adpfApplicant.getFirstName());
        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        back();
        fsa.assertTrue(autoEnterAddressPage.isOnEnterAddressPage(), "User is on the address page from Who should we insure page after rendering Recent Mover page");
        testStep("Verify if the the RM screen is not rendered to the user once it is submitted (i.e.) when user lands on Vehicles/drivers review page (PQ or PA flow), and on click of browser back arrow, the address screen should get displayed and RM screen should never be displayed.", true);
        autoEnterAddressPage.clickAddressPageCtaButton();
        fsa.assertTrue(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage(), "User is getting Who Should we insure page page from address page since they already submitted recent mover page");
        if(whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(adpfApplicant.getStateCode())){
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
            vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
            vehiclesDriversInfoPage.clickContinueButton();
        }else{
            whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
            whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
            whoShouldWeInsurePage.enterEmailAndPhoneNumber(applicant);
            whoShouldWeInsurePage.clickOnContinueButton();
        }

        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.setResumeFromPage(new VehicleReviewPage().getClass().getSimpleName());
        aceAutoNavigationHelper.navigateToQuoteSummaryAutoPage(applicant);
    }

    private void getAdpfFlow(ADPFApplicant adpfApplicant, FarmersSoftAssert fsa) throws Exception {
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
        testStepAssert(heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "User is on the " + heresWhatWeFoundPage.getClass().getSimpleName(), true);
        back();
        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        fsa.assertTrue(autoEnterAddressPage.isOnEnterAddressPage(), "User is on the address page from Here's what we found page after rendering Recent Mover page ( with navigation back )");
        testStep("Verify if the the RM screen is not rendered to the user once it is submitted (i.e.) when user lands on Vehicles/drivers review page (PQ or PA flow), and on click of browser back arrow, the address screen should get displayed and RM screen should never be displayed.", true);
        autoEnterAddressPage.clickAddressPageCtaButton();
        fsa.assertTrue(heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "User is getting Here's what we found page from address page since they already submitted recent mover page");
        heresWhatWeFoundPage.checkRandomIncompleteVehicleBox();
        heresWhatWeFoundPage.clickContinueButton();
        new AceAutoNavigationHelper().navigateFromVehicleReviewToQuoteSummaryPage(adpfApplicant);
    }
}
