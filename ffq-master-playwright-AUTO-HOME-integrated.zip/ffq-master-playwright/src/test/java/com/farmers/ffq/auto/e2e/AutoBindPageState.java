package com.farmers.ffq.auto.e2e;

/**
 * Semantic runtime states for Bind One UI evidence classification.
 *
 * The classifier intentionally works from the rendered DOM snapshot rather than
 * assuming click -> next page. It is diagnostic-only and does not replace the
 * page-object assertions that carry business intent.
 */
public enum AutoBindPageState {
    LANDING,
    NAME_DOB,
    ADDRESS,
    WHO_SHOULD_WE_INSURE,
    CONTACT_INFO,
    VEHICLE_DRIVER_ASSIGNMENT,
    CONTINUE_WITH_BRISTOL_WEST,
    BRISTOL_WEST_ADDITIONAL_DISCOUNTS,
    QUOTE_SUMMARY,
    DRIVER_MISMATCH,
    ADDITIONAL_INFO,
    PAYMENT_SELECTION,
    PAYMENT_METHOD,
    ESIGN,
    PURCHASE_SUCCESS,
    INCONVENIENCE,
    KNOCKOUT,
    UNKNOWN
}
