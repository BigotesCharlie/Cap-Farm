package com.farmers.ffq.auto.defaultcoverage;

import static com.farmers.ffq.utils.GlobalVariables.*;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

public class DefaultCoverageValuesTests_CO extends DefaultCoverageBaseTest {

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "CO_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 25 K50 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "CO_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 25 K50 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_25K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=No", "CO_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 25 K65 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_25K65K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=Yes", "CO_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 25 K65 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "CO_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 30 K60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "CO_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 30 K60 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_30K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=No", "CO_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 30 K65 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_30K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=Yes", "CO_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 30 K65 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "CO_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 35 K70 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "CO_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 35 K70 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_35K80K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=No", "CO_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 35 K80 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_35K80K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=Yes", "CO_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 35 K80 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "CO_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 50 K100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "CO_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 50 K100 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "CO_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 100 K200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "CO_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 100 K200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "CO_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 100 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "CO_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 100 K300 K UMBRELLA.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_150K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=No", "CO_150K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 150 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_150K300K_UMBRELLA(AutoApplicant applicant) throws Exception {

        defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=Yes", "CO_150K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 150 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "CO_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 250 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "CO_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 250 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "CO_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 300 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "CO_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 300 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "CO_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 500 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "CO_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 500 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_500K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "CO_500K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 500 K1000 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_500K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "CO_500K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 500 K1000 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_1000K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "CO_1000K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 1000 K1000 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_1000K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "CO_1000K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 1000 K1000 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_35K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=No", "CO_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 35 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_35K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=Yes", "CO_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 35 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_45K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=No", "CO_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 45 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_45K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=Yes", "CO_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 45 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "CO_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 50 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "CO_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 50 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=No", "CO_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=Yes", "CO_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 60 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "CO_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 75 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_75K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "CO_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 75 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_85K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=No", "CO_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 85 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_85K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=Yes", "CO_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 85 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "CO_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "CO_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 100 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "CO_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "CO_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "CO_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "CO_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "CO_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "CO_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "CO_1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 1000 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = CO)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_CO_1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "CO_1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values CO 1000 K UMBRELLA.
}
