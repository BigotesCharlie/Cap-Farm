package com.farmers.ffq.auto.defaultcoverage;

import static com.farmers.ffq.utils.GlobalVariables.*;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

public class DefaultCoverageValuesTests_NE extends DefaultCoverageBaseTest {

    // Goes to BW, disabling
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = false)
    public void testDefaultCoverageValues_NE_PIPPD_ONLY_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=PIPPD_Only&umbrella=No", "NE_PIPPD_Only_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE PIPPD ONLY NO UMBRELLA.

    // Goes to BW, disabling
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = false)
    public void testDefaultCoverageValues_NE_PIPPD_Only_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=PIPPD_Only&umbrella=Yes", "NE_PIPPD_Only_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE PIPPD Only UMBRELLA.

    // Goes to BW, disabling
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = false)
    public void testDefaultCoverageValues_NE_10K20K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=10/20&umbrella=No", "NE_10K20K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 10 K20 K NO UMBRELLA.

    // Goes to BW, disabling
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = false)
    public void testDefaultCoverageValues_NE_10K20K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=10/20&umbrella=Yes", "NE_10K20K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 10 K20 K UMBRELLA.

    // Goes to BW, disabling
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = false)
    public void testDefaultCoverageValues_NE_15K30K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=No", "NE_15K30K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 15 K30 K NO UMBRELLA.

    // Goes to BW, disabling
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = false)
    public void testDefaultCoverageValues_NE_15K30K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=15/30&umbrella=Yes", "NE_15K30K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 15 K30 K UMBRELLA.

    // Goes to BW, disabling
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = false)
    public void testDefaultCoverageValues_NE_20K40K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=No", "NE_20K40K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 20 K40 K NO UMBRELLA.

    // Goes to BW, disabling
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = false)
    public void testDefaultCoverageValues_NE_20K40K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=20/40&umbrella=Yes", "NE_20K40K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 20 K40 K UMBRELLA.

    // Goes to BW, disabling
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = false)
    public void testDefaultCoverageValues_NE_25K50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=No", "NE_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 25 K50 K NO UMBRELLA.

    // Goes to BW, disabling
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION}, enabled = false)
    public void testDefaultCoverageValues_NE_25K50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/50&umbrella=Yes", "NE_25K50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 25 K50 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_25K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=No", "NE_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 25 K65 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_25K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=Yes", "NE_25K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 25 K65 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "NE_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 30 K60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "NE_30K60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 30 K60 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_30K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=No", "NE_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 30 K65 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_30K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=Yes", "NE_30K65K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 30 K65 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "NE_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 35 K70 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "NE_35K70K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 35 K70 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_35K80K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=No", "NE_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 35 K80 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_35K80K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=Yes", "NE_35K80K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 35 K80 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "NE_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 50 K100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "NE_50K100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 50 K100 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "NE_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 100 K200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "NE_100K200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 100 K200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "NE_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 100 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "NE_100K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 100 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "NE_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 250 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "NE_250K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 250 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "NE_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 300 K300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "NE_300K300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 300 K300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "NE_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 500 K500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "NE_500K500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 500 K500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_500K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "NE_500K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 500 K1000 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_500K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "NE_500K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 500 K1000 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_1000K1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "NE_1000K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 1000 K1000 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_1000K1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "NE_1000K1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 1000 K1000 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_35K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=No", "NE_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 35 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_35K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=Yes", "NE_35K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 35 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_45K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=No", "NE_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 45 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_45K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=Yes", "NE_45K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 45 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "NE_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 50 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_50K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "NE_50K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 50 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=No", "NE_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 60 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_60K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=Yes", "NE_60K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 60 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "NE_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 75 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_75K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "NE_75K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 75 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_85K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=No", "NE_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 85 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_85K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=Yes", "NE_85K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 85 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "NE_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 100 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_100K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "NE_100K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 100 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "NE_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 200 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_200K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "NE_200K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 200 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "NE_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 300 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_300K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "NE_300K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 300 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "NE_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 500 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_500K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "NE_500K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 500 K UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_1000K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
        randomizeApplicantPersonalData(applicant);
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "NE_1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 1000 K NO UMBRELLA.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = NE)}, groups = {AUTO_COVERAGE_VALIDATION})
    public void testDefaultCoverageValues_NE_1000K_UMBRELLA(AutoApplicant applicant) throws Exception {
        defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "NE_1000K_");
    }
    // Test description: Validates the Auto behavior for Test Default Coverage Values NE 1000 K UMBRELLA.

}
