package com.farmers.ffq.auto;


import com.microsoft.playwright.Page;
import com.farmers.ffq.BaseTest;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.auto.pages.AceAutoNavigationHelper.quoteFlow;
import com.farmers.ffq.auto.pages.bw.BwCongratulationsPage;
import com.farmers.ffq.auto.pages.bw.BwPaymentSummaryPage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.ADPFApplicant;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;

import com.farmers.framework.report.Log;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import java.util.*;

import static com.farmers.ffq.ace.hrc.common.AceHRCNavigationHelperBasePage.DID_NOT_REACH;
import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.PAY_IN_FULL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class DriverMismatchPageTests extends BaseTest {

	@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
			attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"0", "1", "22", "42", "44"})}, groups = {FFQ_ONEUI, FFQ_DRIVER_MISMATCH})
	public void validateDriversMismatchPage(ADPFApplicant adfpApplicant) throws Exception {
		DriverMismatchPage driverMismatchPage = new AceAutoNavigationHelper().navigateToDriverMismatchPage(adfpApplicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
		fsa.assertTrue(driverMismatchPage.validateDriversMismatchPageTitle(), "Drivers Mismatch Page Title");
		fsa.assertTrue(driverMismatchPage.validateDriversMismatchPageDescription(), "Drivers Mismatch Page Description");
		fsa.assertTrue(driverMismatchPage.validateDriversMismatchPageHelp(), "Drivers Mismatch Page Help");
		fsa.assertAll();
	}
	// Test description: Validates the Auto behavior for Validate Drivers Mismatch Page.

	@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
			attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"0", "1", "22", "42", "44"})}, groups = {ADA_SUITE, FFQ_ONEUI, FFQ_DRIVER_MISMATCH, ACE_AUTO_ADA_SUITE})
	public void testUS465676CompareUnselectedDriversToDriverMismatch(ADPFApplicant adpfApplicant) throws Exception {
		AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
		HeresWhatWeFoundPage heresWhatWeFoundPage = aceAutoNavigationHelper.navigateToHeresWhatWeFoundPage(adpfApplicant);
		LinkedHashMap<String, String> mapOfUncheckedDriversFound = new LinkedHashMap<>();
		if(heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(adpfApplicant.getStateCode())){
			VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
			vehiclesDriversInfoPage.editPNIDriverIfNeededWithAdpfData(adpfApplicant);
			vehiclesDriversInfoPage.removeNonPNIApplicant(adpfApplicant);
			mapOfUncheckedDriversFound = vehiclesDriversInfoPage.getListOfUncheckedDriverNames();
			vehiclesDriversInfoPage.clickContinueButton();
		}else{
			String fullName = heresWhatWeFoundPage.getPniFullNameFromAutoAdpfApplicant(adpfApplicant);
			heresWhatWeFoundPage.addADPFApplicant(Optional.empty(), fullName, adpfApplicant.getGender(), adpfApplicant.getDateOfBirth());
			heresWhatWeFoundPage.removeNonPNIApplicants(adpfApplicant);
			mapOfUncheckedDriversFound = heresWhatWeFoundPage.getListOfDrivers(UNCHECKED);
			heresWhatWeFoundPage.clickContinueButton();
		}
		if (!mapOfUncheckedDriversFound.isEmpty()) {
			aceAutoNavigationHelper.setResumeFromPage(new VehicleReviewPage().getClass().getSimpleName());
			DriverMismatchPage driverMismatchPage = aceAutoNavigationHelper.navigateToDriverMismatchPage(adpfApplicant);
			if(driverMismatchPage.isADATestingEnabled()) {
				driverMismatchPage.validateADA_DriverMismatchPage();
				return;
			}
            if(!aceAutoNavigationHelper.isOnBristolWest()) {
                Assert.assertTrue(driverMismatchPage.validateDriversListed(mapOfUncheckedDriversFound), "Driver Mismatch Page list of drivers to match");
            }
		}
	}
	// Test description: Validates the Auto behavior for Test US465676 Compare Unselected Drivers To Driver Mismatch.

	@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
			attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"0", "1", "22", "42","44"})}, groups = {FFQ_ONEUI, FFQ_DRIVER_MISMATCH})
	public void testUS465621AddingDriverMismatchExcludedDriver(ADPFApplicant adpfApplicant) throws Exception {
		AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
		LinkedHashMap<String, String> mapOfUncheckedDriversFound = new LinkedHashMap<>();
		HeresWhatWeFoundPage heresWhatWeFoundPage = aceAutoNavigationHelper.navigateToHeresWhatWeFoundPage(adpfApplicant);
		if(heresWhatWeFoundPage.isVehiclesDriversConsolidationImpl(adpfApplicant.getStateCode())){
			VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
			vehiclesDriversInfoPage.editPNIDriverIfNeededWithAdpfData(adpfApplicant);
			vehiclesDriversInfoPage.removeNonPNIApplicant(adpfApplicant);
			mapOfUncheckedDriversFound = vehiclesDriversInfoPage.getListOfUncheckedDriverNames();
			vehiclesDriversInfoPage.clickContinueButton();
		}else{
			String fullName = heresWhatWeFoundPage.getPniFullNameFromAutoAdpfApplicant(adpfApplicant);
			heresWhatWeFoundPage.addADPFApplicant(Optional.empty(), fullName, adpfApplicant.getGender(), adpfApplicant.getDateOfBirth());
			heresWhatWeFoundPage.removeNonPNIApplicants(adpfApplicant);
			mapOfUncheckedDriversFound = heresWhatWeFoundPage.getListOfDrivers(UNCHECKED);
			heresWhatWeFoundPage.clickContinueButton();
		}

		if (!mapOfUncheckedDriversFound.isEmpty()) {
			aceAutoNavigationHelper.setResumeFromPage(new VehicleReviewPage().getClass().getSimpleName());
			DriverMismatchPage driverMismatchPage = aceAutoNavigationHelper.navigateToDriverMismatchPage(adpfApplicant);
			Assert.assertTrue(driverMismatchPage.validateDriversListed(mapOfUncheckedDriversFound), "Driver Mismatch Page list of drivers to match");
			heresWhatWeFoundPage = driverMismatchPage.returnToDriverSelectionPage();
			heresWhatWeFoundPage.addFirstExcludedDriver(adpfApplicant);
			mapOfUncheckedDriversFound = heresWhatWeFoundPage.getListOfDrivers(UNCHECKED);
			if (!mapOfUncheckedDriversFound.isEmpty()) {
				heresWhatWeFoundPage.clickContinueButton();

                if(!aceAutoNavigationHelper.isOnBristolWest()) {
                    Assert.assertTrue(driverMismatchPage.validateDriversListed(mapOfUncheckedDriversFound), "Driver Mismatch Page updated list of drivers to match");
                }
			}
		}
	}
	// Test description: Validates the Auto behavior for Test US465621 Adding Driver Mismatch Excluded Driver.

	@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
			attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"0", "1", "22", "42", "44"})}, groups = {FFQ_ONEUI, FFQ_DRIVER_MISMATCH})
	public void testUS465796DriverMismatchErrorHandling(ADPFApplicant adfpApplicant) throws Exception {
		DriverMismatchPage driverMismatchPage =  new AceAutoNavigationHelper().navigateToDriverMismatchPage(adfpApplicant);
		Assert.assertTrue(driverMismatchPage.validateDriversMismatchErrorHandling(), "Drivers Mismatch Page successful error handling");
	}
	// Test description: Validates the Auto behavior for Test US465796 Driver Mismatch Error Handling.

	@Test(dataProvider = AutoDataProviders.RANDOM_ADPF_APPLICANT_DATA_PROVIDER, dataProviderClass = AutoDataProviders.class,
			attributes = {@CustomAttribute(name = HOUSEHOLD_NUMBER, values = {"0", "1", "22", "42", "44"})}, groups = {FFQ_ONEUI, FFQ_DRIVER_MISMATCH})
	public void validateSaveAndRetrieveQuoteDriversMismatchPage(ADPFApplicant adfpApplicant) throws Exception {
		DriverMismatchPage driverMismatchPage =  new AceAutoNavigationHelper().navigateToDriverMismatchPage(adfpApplicant);
		String quoteNumber = driverMismatchPage.saveQuote(BasePage.generateEmailAddress());
		new LandingPage(driverMismatchPage.isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(adfpApplicant, quoteNumber);
        QuoteSummaryAutoPage quoteSummaryPage = new QuoteSummaryAutoPage();
        quoteSummaryPage.waitForPageTitleAppear();
        quoteSummaryPage.clickOnStartCheckoutButton();
        AdditionalInfoPolicyStartDateOneUI additionalInfoPage = new AdditionalInfoPolicyStartDateOneUI();
        if (additionalInfoPage.isOnAdditionalInfoPage()) {
        	additionalInfoPage.confirmSignalEnrollment();
        	additionalInfoPage.continueToPaymentPage();
        }
		Assert.assertTrue(driverMismatchPage.isOnDriverMismatchPage());
	}
	// Test description: Validates the Auto behavior for Validate Save And Retrieve Quote Drivers Mismatch Page.

	// WA state does not have a "Not Required" option for currently insured status, so it is excluded from the test case
	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA,FL, WA})}, groups = {BW_ACE_TESTS, FFQ_DRIVER_MISMATCH})
	public void validateDriverMismatchPageForBW_Not_Required(AutoApplicant applicant) throws Exception {
		updateLastNameForBristolWest(applicant);
		applicant.setCurrentlyInsuredStatus(NOT_REQUIRED);
		applicant.setTestScenario("BW -> " + applicant.getTestScenario());
		DriverMismatchPage driverMismatchPage = new AceAutoNavigationHelper().navigateToDriverMismatchPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
		if(driverMismatchPage.isOnDriverMismatchPage()) {
			driverMismatchPage.validateDriverMismatchPageForBW_US754967(fsa);
		}  else {
            testStep("Driver mismatch page not displayed", false, true, false);
            Log.info(DID_NOT_REACH + driverMismatchPage.getClass().getSimpleName() + ". Hence skipping the rest of the test steps.");
        }
		fsa.assertAll();
	}
	// Test description: Validates the Auto behavior for Validate Driver Mismatch Page For BW Not Required.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {IA,CA,FL,WA})}, groups = {BW_ACE_TESTS, FFQ_DRIVER_MISMATCH})
	public void validateDriverMismatchPageForBW_Deployed(AutoApplicant applicant) throws Exception {
		updateLastNameForBristolWest(applicant);
		applicant.setCurrentlyInsuredStatus(DEPLOYED);
		applicant.setTestScenario("BW -> " + applicant.getTestScenario());
		DriverMismatchPage driverMismatchPage = new AceAutoNavigationHelper().navigateToDriverMismatchPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
		if(driverMismatchPage.isOnDriverMismatchPage()) {
			driverMismatchPage.validateDriverMismatchPageForBW_US754967(fsa);
			driverMismatchPage.validateDriversListed(fsa);
		} else {
            testStep("Driver mismatch page not displayed", false, true, false);
            Log.info(DID_NOT_REACH + driverMismatchPage.getClass().getSimpleName() + ". Hence skipping the rest of the test steps.");
        }
		fsa.assertAll();
	}
	// Test description: Validates the Auto behavior for Validate Driver Mismatch Page For BW Deployed.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {CA,FL})}, groups = {BW_ACE_TESTS, FFQ_DRIVER_MISMATCH})
	public void validateDriverMismatchPageForBW_ForeignDl(AutoApplicant applicant) throws Exception {
		updateLastNameForBristolWest(applicant);
		applicant.setFirstAgeForeignDriverLicense(18);
		applicant.setTestScenario("BW -> " + applicant.getTestScenario());
		DriverMismatchPage driverMismatchPage = new AceAutoNavigationHelper().navigateToDriverMismatchPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
		if(driverMismatchPage.isOnDriverMismatchPage()) {
			driverMismatchPage.validateDriverMismatchPageForBW_US754967(fsa);
			driverMismatchPage.validateDriversListed(fsa);
		} else {
			testStep("Driver mismatch page not displayed", false, true, false);
			Log.info(DID_NOT_REACH + driverMismatchPage.getClass().getSimpleName() + ". Hence skipping the rest of the test steps.");
		}
		fsa.assertAll();
	}
	// Test description: Validates the Auto behavior for Validate Driver Mismatch Page For BW Foreign Dl.

    /**
     * BW/BDQ -> Validate upon selecting "Already added to this quote" in DCM screen and validate RC3 verify call should be success
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {NC, MT})}, dataProviderClass = AutoDataProviders.class, groups = {BDQ_TESTS, BW_ACE_TESTS})
    public void validateBindWithAlreadyAddedToThisQuote(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
		bwSpecificDataSetUp(applicant);
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        DriverMismatchPage driverMismatchPage = new AceAutoNavigationHelper(switchTestToBDQIfNeeded(applicant)? quoteFlow.BDQ: quoteFlow.DEFAULT).navigateToDriverMismatchPage(applicant);
		if(!driverMismatchPage.isOnDriverMismatchPage()) {
            Log.info("Driver Mismatch page was not reached, cannot continue with the test");
            throw new SkipException("Driver Mismatch page was not reached, cannot continue with the test");
        }
        // driverMismatchPage.validateDriverNamesAreMasked(fsa); in bw page, this is no longer implemented
		driverMismatchPage.randomlySelectReasonForNonInclusion();
        driverMismatchPage.updateOneSelectionToAlreadyIncluded();
        driverMismatchPage.clickContinueButton();
        driverMismatchPage.waitForSpinnerToBeGone();
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        if(bwPaymentSummaryPage.isOnBwPaymentSummaryPage()) {
            bwPaymentSummaryPage.closeRateChangePopUpIfPresent();
        }
        selectPaymentMethodFillOutDocusignAndAddPaymentMethod(PAY_IN_FULL);
        bwPaymentSummaryPage.clickCompletePurchaseButton();
        BwCongratulationsPage bwCongratulationsPage = new BwCongratulationsPage();
        testStepAssert(bwCongratulationsPage.isOnBwCongratsPage(), "Congratulations page is reached", true);
        bwCongratulationsPage.registerUserForAnAccount();
		fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Bind With Already Added To This Quote.

}
