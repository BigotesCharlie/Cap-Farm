package com.farmers.ffq.auto.defaultcoverage;

import static com.farmers.ffq.utils.GlobalVariables.AUTO_COVERAGE_VALIDATION;
import static com.farmers.ffq.utils.GlobalVariables.UT;

import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.AutoApplicant;

public class DefaultCoverageValuesTests_UT extends DefaultCoverageBaseTest {

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT25K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=No", "UT_25K65K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT25 K65 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT25K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=25/65&umbrella=Yes", "UT_25K65K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT25 K65 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT30K60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=No", "UT_30K60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT30 K60 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT30K60K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/60&umbrella=Yes", "UT_30K60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT30 K60 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT30K65K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=No", "UT_30K65K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT30 K65 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT30K65K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=30/65&umbrella=Yes", "UT_30K65K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT30 K65 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT35K70K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=No", "UT_35K70K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT35 K70 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT35K70K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/70&umbrella=Yes", "UT_35K70K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT35 K70 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT35K80K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=No", "UT_35K80K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT35 K80 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT35K80K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35/80&umbrella=Yes", "UT_35K80K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT35 K80 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT50K100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=No", "UT_50K100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT50 K100 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT50K100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50/100&umbrella=Yes", "UT_50K100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT50 K100 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT100K200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=No", "UT_100K200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT100 K200 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT100K200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/200&umbrella=Yes", "UT_100K200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT100 K200 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT100K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=No", "UT_100K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT100 K300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT100K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100/300&umbrella=Yes", "UT_100K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT100 K300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT150K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=No", "UT_150K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT150 K300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT150K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=150/300&umbrella=Yes", "UT_150K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT150 K300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT250K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=No", "UT_250K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT250 K500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT250K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=250/500&umbrella=Yes", "UT_250K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT250 K500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT300K300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=No", "UT_300K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT300 K300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT300K300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300/300&umbrella=Yes", "UT_300K300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT300 K300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT500K500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=No", "UT_500K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT500 K500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT500K500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/500&umbrella=Yes", "UT_500K500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT500 K500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT500K1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=No", "UT_500K1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT500 K1 M NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT500K1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500/1000&umbrella=Yes", "UT_500K1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT500 K1 M UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT1M1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=No", "UT_1M1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT1 M1 M NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT1M1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000/1000&umbrella=Yes", "UT_1M1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT1 M1 M UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT35K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=No", "UT_35K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT35 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT35K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=35&umbrella=Yes", "UT_35K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT35 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT45K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=No", "UT_45K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT45 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT45K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=45&umbrella=Yes", "UT_45K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT45 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT50K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=No", "UT_50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT50 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT50K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=50&umbrella=Yes", "UT_50K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT50 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT60K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=No", "UT_60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT60 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT60K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=60&umbrella=Yes", "UT_60K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT60 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT75K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=No", "UT_75K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT75 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT75K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=75&umbrella=Yes", "UT_75K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT75 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT85K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=No", "UT_85K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT85 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT85K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=85&umbrella=Yes", "UT_85K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT85 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT100K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=No", "UT_100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT100 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT100K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=100&umbrella=Yes", "UT_100K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT100 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT200K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=No", "UT_200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT200 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT200K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=200&umbrella=Yes", "UT_200K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT200 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT300K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=No", "UT_300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT300 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT300K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=300&umbrella=Yes", "UT_300K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT300 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT500K_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=No", "UT_500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT500 K NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT500K_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=500&umbrella=Yes", "UT_500K_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT500 K UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT1M_NO_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=No", "UT_1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT1 M NO UMBRELLA.

	@Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, dataProviderClass = AutoDataProviders.class, 
			attributes = {@CustomAttribute(name = UT)}, groups = {AUTO_COVERAGE_VALIDATION})
	public void testDefaultCoverageValues_UT1M_UMBRELLA(AutoApplicant applicant) throws Exception {
		defaultCoverageTestFor(applicant, "coverageAmount=1000&umbrella=Yes", "UT_1M_");
	}
	// Test description: Validates the Auto behavior for Test Default Coverage Values UT1 M UMBRELLA.

}
