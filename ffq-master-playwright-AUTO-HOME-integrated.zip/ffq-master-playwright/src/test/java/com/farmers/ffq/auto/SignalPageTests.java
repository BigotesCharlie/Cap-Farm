package com.farmers.ffq.auto;


import com.microsoft.playwright.Page;
import com.farmers.ffq.BaseTest;

import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bindpages.*;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;

import org.apache.commons.lang3.RandomUtils;
import org.testng.Assert;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.Test;

import static com.farmers.ffq.common.enums.AutoDiscounts.SIGNAL;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class SignalPageTests extends BaseTest {

    private final static String SIGNAL_TESTS = "aceSignal";

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA})}, groups = {FFQ_ONEUI, SIGNAL_TESTS})
    public void validateSignalPageContents(AutoApplicant applicant) throws Exception {
        SignalPageOneUI signalPage = new AceAutoNavigationHelper().navigateToSignalPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        String applicantStateCode = applicant.getStateCode();
        if(applicantStateCode.equals(OR)){
            testStep("Signal Page is not available for OR State, String default signal allocated to OR State ");
            signalPage.navigateFromSignalPageToQuoteSummaryPage(applicant);
        }
        else {
            signalPage.validateImages(fsa);
            signalPage.isSignalPageHeaderCorrect(fsa);
            signalPage.isSignalPageSubheaderCorrect(applicantStateCode, fsa);
            signalPage.isSaveTodayLabelCorrect(applicantStateCode, fsa);
            signalPage.isSaveAtRenewalLabelCorrect(applicant, fsa);
            signalPage.isSignalPageDiscalimerCorrect(applicantStateCode, fsa);
            signalPage.verifySignalPageLinks();
            fsa.assertAll();
        }
    }
    // Test description: Validates the Auto behavior for Validate Signal Page Contents.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AL, CA, FL, MT, NJ, NY, OH})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SIGNAL_TESTS})
    public void testAddSignalToQuoteTest(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        SignalPageOneUI signalPage = new AceAutoNavigationHelper().navigateToSignalPage(applicant);
        signalPage.processSignalPage(true);
        QuoteSummaryAutoPage quoteSummaryAutoPage = signalPage.navigateFromSignalPageToQuoteSummaryPage(applicant);
        ApiHelper apiHelper = new ApiHelper();
        String quoteNumber = signalPage.getSessionStorageAppStore().getData().getQuoteNumber();
        SaveSignalDiscountServiceCallRequestPayload saveSignalDiscountRequestPayload = apiHelper.getSaveSignalDiscountRequestPayload(quoteNumber);
        testStepAssert(saveSignalDiscountRequestPayload.getSaveSignalDiscountRequestBean().getSignalDiscountEnrolled(), "Y", "signalDiscountEnrolled should be 'Y'");
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote summary page reached", true);

        if (quoteSummaryAutoPage.isOnBristolWest()) {
            testStep("Test ended. Signal is not available for BW");
            return;
        }

        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        softAssert.assertTrue(quoteSummaryAutoPage.isDiscountPresentInTheSideSheet(SIGNAL.getName()), "Signal discount should be present on the discount side sheet");
        RateQuoteServiceInitiated rateQuoteServiceInitiated = apiHelper.getRateQuoteServiceInitiated(quoteNumber);
        String signalIndicatorInTheRequestBody = rateQuoteServiceInitiated.getCalculateQuotePremium().getAutoQuoteDetails().getDriverVehicleDetails().get(0).getDriver().get(0).getSignal();
        softAssert.assertEquals(signalIndicatorInTheRequestBody, "Y", "Signal Indicator should be Y in the Request body");
        softAssert.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Add Signal To Quote Test.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {AL, CA, FL, MT, NJ, NY, OH})}, groups = {FFQ_ONEUI, SIGNAL_TESTS})
    public void testDeclineSignalOffering(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        SignalPageOneUI signalPage = new AceAutoNavigationHelper().navigateToSignalPage(applicant);
        signalPage.processSignalPage(false);
        QuoteSummaryAutoPage quoteSummaryAutoPage = signalPage.navigateFromSignalPageToQuoteSummaryPage(applicant);
        FarmersSoftAssert softAssert = new FarmersSoftAssert();
        softAssert.assertTrue(!quoteSummaryAutoPage.isDiscountPresentInTheSideSheet(SIGNAL.getName()), "Signal discount should not be present on the discount side sheet");
        RateQuoteServiceInitiated rateQuoteServiceInitiated = new ApiHelper().getRateQuoteServiceInitiated(signalPage.getSessionStorageAppStore().getData().getQuoteNumber());
        String signalIndicatorInTheRequestBody = rateQuoteServiceInitiated.getCalculateQuotePremium().getAutoQuoteDetails().getDriverVehicleDetails().get(0).getDriver().get(0).getSignal();
        softAssert.assertEquals(signalIndicatorInTheRequestBody, "N", "Signal Indicator should be N in the Request body");
        softAssert.assertAll();
    }
    // Test description: Validates the Auto behavior for Test Decline Signal Offering.
    /*
        Feature: F88250
        Scenarios: S.No 536 & 537 from R9 Regression.
     */

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=6"}), @CustomAttribute(name = INCLUDED_STATES, values = {OR})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SIGNAL_TESTS})
    public void validateYouthfulDriverContentOnSignalPageAndSignalDiscountOnQuoteSummary(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        SignalPageOneUI signalPage = new AceAutoNavigationHelper().navigateToSignalPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        String applicantStateCode = applicant.getStateCode();
        signalPage.isSignalPageHeaderCorrect(fsa);
        signalPage.isSignalPageSubheaderCorrect(applicantStateCode, fsa);
        signalPage.isSaveTodayLabelCorrect(applicantStateCode, fsa);
        signalPage.isSaveAtRenewalLabelCorrect(applicant, fsa);
        signalPage.isSignalPageDiscalimerCorrect(applicantStateCode, fsa);
        boolean isSignalOptionAdded = RandomUtils.nextBoolean();
        if (isSignalOptionAdded) {
            signalPage.processSignalPage(true);
            QuoteSummaryAutoPage quoteSummaryAutoPage = signalPage.navigateFromSignalPageToQuoteSummaryPage(applicant);
            testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote summary page reached", true);
            if (quoteSummaryAutoPage.isOnBristolWest()) {
                testStep("Test ended. Signal is not available for BW");
                return;
            }
            fsa.assertTrue(quoteSummaryAutoPage.isDiscountPresentInTheSideSheet(SIGNAL.getName()), "Signal discount should be present on the discount side sheet");

        } else {
            signalPage.processSignalPage(false);
            QuoteSummaryAutoPage quoteSummaryAutoPage = signalPage.navigateFromSignalPageToQuoteSummaryPage(applicant);
            testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote summary page reached", true);
            if (quoteSummaryAutoPage.isOnBristolWest()) {
                testStep("Test ended. Signal is not available for BW");
                return;
            }
            fsa.assertFalse(quoteSummaryAutoPage.isDiscountPresentInTheSideSheet(SIGNAL.getName()), "Signal discount should not be present on the discount side sheet");

        }
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Youthful Driver Content On Signal Page And Signal Discount On Quote Summary.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SIGNAL_TESTS})
    public void validateSignalRemovedWithReverseBrightline(AutoApplicant applicant) throws Exception {
        // set signal discount to the true
        applicant.getDiscounts().get(0).setSignalSignup(true);
        //let's avoid possible bw in the quote side
        updateApplicantDataToAvoidPossibleBw(applicant);
        if (applicant.getStateCode().equals(OR)) {
            applicant.setFinancialFiling(SR_22);
        }

        applicant.setTestScenario("BW-Reverse->" + applicant.getTestScenario());
        //remove other bw conditions
        updateApplicantDataToAvoidPossibleBw(applicant);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.setRemoveQualtricsPopup(false);
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = aceAutoNavigationHelper.navigateToAdditionalInfoPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        additionalInfoPolicyStartDateOneUI.verifyAdditionalInfoHeader(fsa);
        AppStore retrieveQuoteResponseSessionStorage = aceAutoNavigationHelper.getSessionStorageAppStore();

        AdditionalInfoDriverSectionOneUI additionalInfoDriverSectionOneUI = new AdditionalInfoDriverSectionOneUI();
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        AdditionalInfoSignalEnrollmentSectionOneUI additionalInfoSignalEnrollmentSectionOneUI = new AdditionalInfoSignalEnrollmentSectionOneUI();
        AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
        additionalInfoVehicleSectionOneUI.verifyVehicleSection(retrieveQuoteResponseSessionStorage, true, fsa);
        additionalInfoDriverSectionOneUI.enterDriverLicenseNumber(retrieveQuoteResponseSessionStorage);
        additionalInfoDriverSectionOneUI.enterMatureDriverSafetyCourseDate(retrieveQuoteResponseSessionStorage.getData().getLandingStateCode());
        additionalInfoSignalEnrollmentSectionOneUI.verifySignalEnrollmentSection(retrieveQuoteResponseSessionStorage, true, fsa);
        additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            if (applicant.getStateCode().equals(VA)) {
                vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
            } else {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
            }
        }
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();

        fsa.assertTrue(continueWithBristolWestPage.isOnContinueWithBristolWestPage(), "User should land on the BW continue page for reverse brightline");
        continueWithBristolWestPage.continueWithBwPopUp();
        BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
        if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
            bristolWestAdditionalDiscountsPage.clickContinue();
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User should land on the quote summary page");
        fsa.assertTrue(quoteSummaryAutoPage.isOnBristolWest(), "User should have the BW page");
        //fsa.assertTrue(quoteSummaryAutoPage.isSnackBarMessageDisplayed("Signal is not available from Bristol West and has been removed from your quote."), "Signal is not available for BW message");
        //testStep("Signal discount not available snackbar validation");
        //quoteSummaryAutoPage.clickGotItButton();
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        navigateFromWhoShouldWeInsurePageToQuoteSummaryPageWithOrWithoutSignalPage(applicant, fsa, false);
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the Quote Summary page again :)");
    }
    // Test description: Validates the Auto behavior for Validate Signal Removed With Reverse Brightline.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {AK, CA, DC, DE, FL, HI, ME, MT, NH, NC, NJ, NY, RI, SC, VT, WV})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI})
    public void validateSignalPageIsRemovedWithBWQuote(AutoApplicant applicant) throws Exception {
        //remove other possible bw conditions
        updateApplicantDataToAvoidPossibleBw(applicant);
        bwSpecificDataSetUp(applicant);
        applicant.setLastName("Threeoabaa");
        // set signal discount to the true
        boolean signalSignup = applicant.getDiscounts().get(0).isSignalSignup();
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.setRemoveQualtricsPopup(false);
        QuoteSummaryAutoPage quoteSummaryAutoPage =  aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User should land on the quote summary page");
        fsa.assertTrue(quoteSummaryAutoPage.isOnBristolWest(), "User should have the BW page");
        if (signalSignup) {
            fsa.assertTrue(quoteSummaryAutoPage.isSnackBarMessageDisplayed("Signal is not available from Bristol West and has been removed from your quote."), "Signal is not available for BW message should be displaying");
            testStep("Signal discount not available snackbar validation");
            quoteSummaryAutoPage.clickGotItButton();
        }

        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        navigateFromWhoShouldWeInsurePageToQuoteSummaryPageWithOrWithoutSignalPage(applicant, fsa, false);
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the Quote Summary page again :)");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Signal Page Is Removed With BWQuote.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT, dataProviderClass = AutoDataProviders.class, attributes = {@CustomAttribute(name = FILTER, values = "applicantId=1"), @CustomAttribute(name = EXCLUDED_STATES, values = {AK, CA, DC, DE, FL, HI, ME, MT, NH, NJ, NY, RI, SC, VT, WA, WV})}, groups = {FFQ_ONEUI})
    public void validateSignalPageIsRemovedWhenBWQuoteIsRetrieved(AutoApplicant applicant) throws Exception {
        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        updateApplicantDataToAvoidPossibleBw(applicant);
        AceAutoNavigationHelper aceAutoNavigationHelper = new AceAutoNavigationHelper();
        aceAutoNavigationHelper.setRemoveQualtricsPopup(false);
        QuoteSummaryAutoPage quoteSummaryAutoPage =  aceAutoNavigationHelper.navigateToEitherQuoteSummaryPage(applicant);
        if(!quoteSummaryAutoPage.isOnBristolWest()) {
            return;
        }
        quoteSummaryAutoPage.closeQualtricsPopUp();
        String quoteNumber = quoteSummaryAutoPage.getAceQuoteNumberInThePage();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        new LandingPage(quoteSummaryAutoPage.isUseMobileViewEnabled(),true).retrieveQuoteFromLandingPage(applicant, quoteNumber);
        quoteSummaryAutoPage.waitForSpinnerToBeGone();
        quoteSummaryAutoPage.closeQualtricsPopUp();
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        navigateFromWhoShouldWeInsurePageToQuoteSummaryPageWithOrWithoutSignalPage(applicant, fsa, false);
        testStep("Validate Signal page has been removed for any BW retrieved quote");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Signal Page Is Removed When BWQuote Is Retrieved.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.AUTO_APPLICANT_WITH_ONE_VEHICLE, attributes = {@CustomAttribute(name = EXCLUDED_STATES, values = {FL, CA, WA})}, dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SIGNAL_TESTS})
    public void validateSignalPageFarmersBWBackAndForth(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        updateLastNameForBristolWest(applicant);
        QuoteSummaryAutoPage quoteSummaryAutoPage = new AceAutoNavigationHelper().navigateToEitherQuoteSummaryPage(applicant);
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User reached: " + quoteSummaryAutoPage.getClass().getSimpleName());
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        testStep("Validate BW page is not removed if farmers quote navigates back");
        navigateFromWhoShouldWeInsurePageToQuoteSummaryPageWithOrWithoutSignalPage(applicant, fsa, true);
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User reached: " + quoteSummaryAutoPage.getClass().getSimpleName());

        // navigate back and add BW condition
        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
        testStepAssert(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage() || heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "User reached : Drivers Vehicles Addition page");

        applicant.setCurrentlyInsuredStatus(NEVER_INSURED);
        String applicantFullName = whoShouldWeInsurePage.getPniFullNameFromAutoApplicant(applicant);
        if(whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(applicant.getStateCode())){
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            vehiclesDriversInfoPage.clickEditButtonForDriver(applicantFullName);
            vehiclesDriversInfoPage.fillOutPriorInsuranceDetails(applicant);
            vehiclesDriversInfoPage.clickSaveChangesDriverSheet();
            vehiclesDriversInfoPage. waitForSpinnerToBeGone();
            vehiclesDriversInfoPage.clickContinueButton();
        }else{
            whoShouldWeInsurePage.clickEditButtonWithDriverFullName(applicantFullName);
            whoShouldWeInsurePage.selectCurrentlyInsuredRadioButton(applicant);
            whoShouldWeInsurePage.clickOnSaveButton();
            whoShouldWeInsurePage.clickOnDoneAddingDriversButton();
            whoShouldWeInsurePage.clickContinueButton();
            VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
            vehicleReviewPage.isOnVehiclesReviewPage();
            vehicleReviewPage.clickOnContinueButton();
            DriverReviewPage driverReviewPage = new DriverReviewPage();
            driverReviewPage.isOnDriverReviewPage();
            driverReviewPage.clickContinueButton();
        }

        if (!whoShouldWeInsurePage.isSignalDiscountDisabledState(applicant.getStateCode())) {
            SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
            fsa.assertTrue(signalPageOneUI.isOnSignalPage(), "User reached : " + signalPageOneUI.getClass().getSimpleName());
            signalPageOneUI.processSignalPage(RandomUtils.nextBoolean());
        } else {
            testStep("Validate Signal page is removed");
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        fsa.assertTrue(contactInfoAutoPage.isOnContactInfoAutoPage(), "User reached: " + contactInfoAutoPage.getClass().getSimpleName());
        contactInfoAutoPage.clickContactInfoPageCTAButton();
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            if (applicant.getStateCode().equals(VA)) {
                vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
            } else {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
            }
        }
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
        }
        BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
        if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
            bristolWestAdditionalDiscountsPage.clickContinue();
        }
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User reached: " + quoteSummaryAutoPage.getClass().getSimpleName());
        fsa.assertTrue(quoteSummaryAutoPage.isOnBristolWest(), "User reached BW quote page");

        quoteSummaryAutoPage.clickEnterInfoNavigationBarStepper();
        navigateFromWhoShouldWeInsurePageToQuoteSummaryPageWithOrWithoutSignalPage(applicant, fsa, false);
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage() && quoteSummaryAutoPage.isOnBristolWest(), "Quote has reached BW Quote Summary page");
        fsa.assertAll();
    }
    // Test description: Validates the Auto behavior for Validate Signal Page Farmers BWBack And Forth.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AL, CA, FL, MT, NJ, NY, OH})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, SIGNAL_TESTS})
    public void validateSignalIsNotAvailableForBW_ForeignDL(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setFirstAgeForeignDriverLicense(18);
        SignalPageOneUI signalPage = new AceAutoNavigationHelper().navigateToSignalPage(applicant);
        signalPage.processSignalPage(true);
        QuoteSummaryAutoPage quoteSummaryAutoPage = signalPage.navigateFromSignalPageToQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote summary page reached", true);
        if (quoteSummaryAutoPage.isOnBristolWest()) {
            testStepAssert(quoteSummaryAutoPage.isSnackBarMessageDisplayed("Signal is not available from Bristol West and has been removed from your quote."), "Signal not available message should show for BW");
            return;
        }
        testStepAssert(quoteSummaryAutoPage.isDiscountPresentInTheSideSheet(SIGNAL.getName()), "Signal discount should be present on the discount side sheet");
    }
    // Test description: Validates the Auto behavior for Validate Signal Is Not Available For BW Foreign DL.


    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AL, CA, FL, MT, NJ, NY, OH})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, SIGNAL_TESTS})
    public void validateSignalIsNotAvailableForBW_Not_Required(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setCurrentlyInsuredStatus(NOT_REQUIRED);
        SignalPageOneUI signalPage = new AceAutoNavigationHelper().navigateToSignalPage(applicant);
        signalPage.processSignalPage(true);
        QuoteSummaryAutoPage quoteSummaryAutoPage = signalPage.navigateFromSignalPageToQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote summary page reached", true);
        if (quoteSummaryAutoPage.isOnBristolWest()) {
            testStepAssert(quoteSummaryAutoPage.isSnackBarMessageDisplayed("Signal is not available from Bristol West and has been removed from your quote."), "Signal not available message should show for BW");
            return;
        }
        testStepAssert(quoteSummaryAutoPage.isDiscountPresentInTheSideSheet(SIGNAL.getName()), "Signal discount should be present on the discount side sheet");
    }
    // Test description: Validates the Auto behavior for Validate Signal Is Not Available For BW Not Required.

    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=1"}), @CustomAttribute(name = EXCLUDED_STATES, values = {NC, AL, CA, FL, MT, NJ, NY, OH})},
            dataProviderClass = AutoDataProviders.class, groups = {BW_ACE_TESTS, SIGNAL_TESTS})
    public void validateSignalIsNotAvailableForBW_Deployed(AutoApplicant applicant) throws Exception {
        updateApplicantDataToAvoidPossibleBw(applicant);
        applicant.setCurrentlyInsuredStatus(DEPLOYED);
        SignalPageOneUI signalPage = new AceAutoNavigationHelper().navigateToSignalPage(applicant);
        signalPage.processSignalPage(true);
        QuoteSummaryAutoPage quoteSummaryAutoPage = signalPage.navigateFromSignalPageToQuoteSummaryPage(applicant);
        testStepAssert(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "Quote summary page reached", true);
        if (quoteSummaryAutoPage.isOnBristolWest()) {
            testStepAssert(quoteSummaryAutoPage.isSnackBarMessageDisplayed("Signal is not available from Bristol West and has been removed from your quote."), "Signal not available message should show for BW");
            return;
        }
        testStepAssert(quoteSummaryAutoPage.isDiscountPresentInTheSideSheet(SIGNAL.getName()), "Signal discount should be present on the discount side sheet");
    }
    // Test description: Validates the Auto behavior for Validate Signal Is Not Available For BW Deployed.


    /**
     * F89566 : Validate that FFQ Ace (CT) - Auto - "Signal" discount is applied at driver level to all drivers and is displayed for me on the Quote page and all other applicable FFQ screens
     * But applicable to all states
     * @param applicant
     * @throws Exception
     */
    @Test(dataProvider = AutoDataProviders.AUTO_APPLICANT_DATA_PROVIDER, testName = AutoDataProviders.RANDOM_AUTO_APPLICANT,
            attributes = {@CustomAttribute(name = FILTER, values = {"applicantId=5"}), @CustomAttribute(name = EXCLUDED_STATES, values = {AK, CA, DC, DE, FL, HI, ME, MT, NH, NJ, NY, RI, SC, VT, WV})},
            dataProviderClass = AutoDataProviders.class, groups = {FFQ_ONEUI, SIGNAL_TESTS})
    public void validateVerifyRateResponseIsSendingSignalIndicators(AutoApplicant applicant) throws Exception {
        //set signal sign up
        applicant.getVehicles().forEach(each -> each.setVehicleUsage("Personal"));
        applicant.getDiscounts().get(0).setSignalSignup(true);
        AdditionalInfoPolicyStartDateOneUI additionalInfoPolicyStartDateOneUI = new AceAutoNavigationHelper().navigateToAdditionalInfoPage(applicant);
        additionalInfoPolicyStartDateOneUI.fillOutAdditionalInfoPage(true);
        AutoQuoteVerifyServiceInitiated autoQuoteVerifyServiceInitiated = new ApiHelper().getAutoQuoteVerifyServiceInitiated(additionalInfoPolicyStartDateOneUI.getSessionStorageAppStore().getData().getQuoteNumber());
        autoQuoteVerifyServiceInitiated.getAutoQuote().get(0).getPersonalAuto().getDrivers().forEach(driver -> {
            AutoQuoteVerifyServiceInitiated.AutoQuote.PersonalAuto.Driver.Name name = driver.getName();
            Assert.assertEquals(driver.getSignal(), "Y", "Signal indicator should be 'Y' for " + name.getFirstName() + SPACE + name.getLastName());
        });
    }
    // Test description: Validates the Auto behavior for Validate Verify Rate Response Is Sending Signal Indicators.


    private void navigateFromWhoShouldWeInsurePageToQuoteSummaryPageWithOrWithoutSignalPage(AutoApplicant applicant, FarmersSoftAssert fsa, boolean signalPageExpected) throws Exception {
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        if (nameAndDobPage.isOnNameAndDobPage()) {
            nameAndDobPage.clickContinueButton();
            new AutoEnterAddressPage().clickContinueButton();
            nameAndDobPage.waitForSpinnerToBeGone();
        }
        fsa.assertTrue(whoShouldWeInsurePage.isOnWhoShouldWeInsurePage() || heresWhatWeFoundPage.isOnHeresWhatWeFoundPage(), "Enter info navbar should take the user to Vehicles-Drivers page");
        whoShouldWeInsurePage.clickContinueButton();
        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        vehicleReviewPage.isOnVehiclesReviewPage();
        vehicleReviewPage.clickOnContinueButton();
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        driverReviewPage.isOnDriverReviewPage();
        driverReviewPage.enterDriverLicenseAge(applicant, driverReviewPage.getApplicantFullName(applicant), 15);
        driverReviewPage.clickContinueButton();
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        if (signalPageExpected && !contactInfoAutoPage.isSignalDiscountDisabledState(applicant.getStateCode())) {
            SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
            fsa.assertTrue(signalPageOneUI.isOnSignalPage(), "User reached : " + signalPageOneUI.getClass().getSimpleName());
            signalPageOneUI.processSignalPage(RandomUtils.nextBoolean());
        }
        testStepAssert(contactInfoAutoPage.isOnContactInfoAutoPage(), "User reached : " + contactInfoAutoPage.getClass().getSimpleName());
        contactInfoAutoPage.fillOutPrimaryResidenceInsuranceSection(applicant.getStateCode().equals(MA));
        contactInfoAutoPage.clickContactInfoPageCTAButton();
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            if (applicant.getStateCode().equals(VA)) {
                vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
            } else {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
            }
        }
        BristolWestAdditionalDiscountsPage bwAdditionalDiscountPage = new BristolWestAdditionalDiscountsPage();
        if (bwAdditionalDiscountPage.isOnBristolWestAdditionalDiscountsPage()) {
            bwAdditionalDiscountPage.clickContinue();
        }
    }
}
