package com.farmers.framework.saucelabs;

/** Sauce Labs reporting is optional in the Playwright runtime. */
public final class SauceRest {
    private SauceRest() { }
    public static String getPublicJobLink(String sessionId) { return sessionId == null ? "" : sessionId; }
    public static String getPublicJobLink() { return ""; }
}
