package com.farmers.framework.playwright;

import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import com.microsoft.playwright.Frame;
import com.microsoft.playwright.Page;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Suite-wide resiliency coordinator: CopyDOM, page-state diagnostics and blocker recovery.
 * The implementation is thread-local so TestNG parallel DataProviders remain isolated.
 */
public final class AutoDebugManager {
    private static final ThreadLocal<DebugState> STATE = new ThreadLocal<>();
    private static final DateTimeFormatter EXECUTION_ID = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS");
    private static final Set<String> PAGE_TRANSITION_ACTIONS = Set.of(
            "click", "dblclick", "tap", "check", "uncheck", "selectOption", "press", "setChecked"
    );

    private AutoDebugManager() {
    }

    public static void startTest(String testName, Page page) {
        if (!enabled()) {
            return;
        }
        String safeName = sanitize(testName);
        String executionId = LocalDateTime.now().format(EXECUTION_ID) + "-T" + Thread.currentThread().getId();
        Path executionDir = Paths.get("build", "artifacts", "dom", safeName, executionId);
        DebugState state = new DebugState(safeName, executionId, executionDir, maxRecovery());
        STATE.set(state);
        attach(page);
        checkpoint("test-start", true);
        Log.info("AutoDebug enabled: CopyDOM=" + executionDir + " | maxRecovery=" + state.maxRecovery);
    }

    public static void attach(Page page) {
        DebugState state = STATE.get();
        if (!enabled() || state == null || page == null || page.isClosed()) {
            return;
        }
        if (!state.attachedPages.add(System.identityHashCode(page))) {
            return;
        }
        page.onFrameNavigated(frame -> onFrameNavigated(page, frame));
    }

    public static void finishTest(boolean failed) {
        DebugState state = STATE.get();
        if (state == null) {
            return;
        }
        try {
            checkpoint(failed ? "failure-current-page" : "test-end", true);
            writeSummary(state, failed);
        } finally {
            STATE.remove();
        }
    }

    public static boolean onLocatorFailure(String locatorDescription, String methodName, Throwable error) {
        DebugState state = STATE.get();
        if (!enabled() || state == null || !PlaywrightSession.hasActivePage()) {
            return false;
        }

        Page page = PlaywrightSession.page();
        PageStateDetector.PageState detected = PageStateDetector.detect(page);
        Log.warn("AutoDebug intercepted locator failure: method=" + methodName
                + " locator=" + locatorDescription + " state=" + detected
                + " error=" + concise(error));
        checkpoint("locator-failure-" + methodName + "-" + detected, true);

        if (!PageStateDetector.isBlocker(detected) || state.recoveryAttempts >= state.maxRecovery) {
            return false;
        }

        state.recoveryAttempts++;
        boolean recovered = RecoveryManager.recover(page, detected, state.recoveryAttempts);
        checkpoint(recovered ? "recovery-success" : "recovery-failed", true);
        return recovered;
    }

    public static void afterLocatorAction(String methodName) {
        if (!enabled() || !PAGE_TRANSITION_ACTIONS.contains(methodName) || STATE.get() == null
                || !PlaywrightSession.hasActivePage()) {
            return;
        }
        checkpoint("after-" + methodName, false);
    }

    public static void checkpoint(String label, boolean force) {
        DebugState state = STATE.get();
        if (!enabled() || state == null || !PlaywrightSession.hasActivePage()) {
            return;
        }

        Page page = PlaywrightSession.page();
        if (page.isClosed()) {
            return;
        }

        if (!force) {
            int currentHash = currentDomHash(page);
            String url = safeUrl(page);
            if (currentHash == state.lastDomHash && url.equals(state.lastUrl)) {
                return;
            }
        }

        int sequence = state.sequence.incrementAndGet();
        CopyDom.Snapshot snapshot = CopyDom.capture(page, state.executionDirectory, sequence, label);
        if (snapshot != null) {
            state.lastDomHash = snapshot.domHash();
            state.lastUrl = safeUrl(page);
            state.lastState = snapshot.state();
        }
    }

    private static void onFrameNavigated(Page page, Frame frame) {
        DebugState state = STATE.get();
        if (state == null || page == null || frame == null) {
            return;
        }
        try {
            if (frame == page.mainFrame()) {
                checkpoint("navigation", false);
            }
        } catch (RuntimeException ignored) {
        }
    }

    private static void writeSummary(DebugState state, boolean failed) {
        try {
            Files.createDirectories(state.executionDirectory);
            Path summary = state.executionDirectory.resolve("debug-summary.txt");
            String content = "test=" + state.testName + System.lineSeparator()
                    + "executionId=" + state.executionId + System.lineSeparator()
                    + "result=" + (failed ? "FAILED" : "PASSED") + System.lineSeparator()
                    + "copyDomSnapshots=" + state.sequence.get() + System.lineSeparator()
                    + "recoveryAttempts=" + state.recoveryAttempts + System.lineSeparator()
                    + "lastDetectedState=" + state.lastState + System.lineSeparator()
                    + "lastUrl=" + state.lastUrl + System.lineSeparator();
            Files.writeString(summary, content, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception error) {
            Log.warn("Unable to write AutoDebug summary: " + error.getMessage());
        }
    }

    private static int currentDomHash(Page page) {
        try {
            return page.content().hashCode();
        } catch (RuntimeException ignored) {
            return 0;
        }
    }

    private static boolean enabled() {
        return Boolean.parseBoolean(Property.getTestProperty("autoDebug", "true"));
    }

    private static int maxRecovery() {
        try {
            return Math.max(0, Integer.parseInt(Property.getTestProperty("autoDebug.maxRecovery", "2")));
        } catch (NumberFormatException ignored) {
            return 2;
        }
    }

    private static String safeUrl(Page page) {
        try {
            return page.url() == null ? "" : page.url();
        } catch (RuntimeException ignored) {
            return "";
        }
    }

    private static String concise(Throwable error) {
        if (error == null) {
            return "unknown";
        }
        String message = error.getMessage();
        if (message == null || message.isBlank()) {
            return error.getClass().getSimpleName();
        }
        String singleLine = message.replaceAll("\\s+", " ").trim();
        return singleLine.length() > 240 ? singleLine.substring(0, 240) : singleLine;
    }

    private static String sanitize(String value) {
        String safe = value == null || value.isBlank() ? "test" : value.replaceAll("[^a-zA-Z0-9._-]", "_");
        return safe.length() > 180 ? safe.substring(0, 180) : safe;
    }

    private static final class DebugState {
        private final String testName;
        private final String executionId;
        private final Path executionDirectory;
        private final int maxRecovery;
        private final AtomicInteger sequence = new AtomicInteger();
        private final java.util.Set<Integer> attachedPages = new java.util.HashSet<>();
        private int recoveryAttempts;
        private int lastDomHash = Integer.MIN_VALUE;
        private String lastUrl = "";
        private PageStateDetector.PageState lastState = PageStateDetector.PageState.UNKNOWN;

        private DebugState(String testName, String executionId, Path executionDirectory, int maxRecovery) {
            this.testName = testName;
            this.executionId = executionId;
            this.executionDirectory = executionDirectory;
            this.maxRecovery = maxRecovery;
        }
    }
}
