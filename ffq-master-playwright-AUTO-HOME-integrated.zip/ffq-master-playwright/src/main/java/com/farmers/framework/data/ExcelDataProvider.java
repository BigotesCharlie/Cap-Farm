package com.farmers.framework.data;

import org.apache.poi.ss.usermodel.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Reads an Excel sheet into the JSON-row shape used by the original data providers. */
public class ExcelDataProvider {
    public JSONArray getDataJson(String workbookPath, String sheetName) throws Exception {
        return getDataJson(workbookPath, sheetName, true);
    }

    public JSONArray getDataJson(String workbookPath, String sheetName, boolean includeBlankValues) throws Exception {
        try (FileInputStream input = new FileInputStream(workbookPath);
             Workbook workbook = WorkbookFactory.create(input)) {
            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                throw new IllegalArgumentException("Excel sheet not found: " + sheetName + " in " + workbookPath);
            }
            DataFormatter formatter = new DataFormatter(Locale.US);
            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
            Row header = firstNonEmptyRow(sheet);
            if (header == null) {
                return new JSONArray();
            }
            List<String> headers = new ArrayList<>();
            for (int column = 0; column < header.getLastCellNum(); column++) {
                headers.add(formatter.formatCellValue(header.getCell(column)).trim());
            }

            JSONArray result = new JSONArray();
            for (int rowIndex = header.getRowNum() + 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null || rowIsEmpty(row, formatter)) {
                    continue;
                }
                JSONObject json = new JSONObject();
                for (int column = 0; column < headers.size(); column++) {
                    String key = headers.get(column);
                    if (key.isBlank()) {
                        continue;
                    }
                    Cell cell = row.getCell(column, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                    Object value = cellValue(cell, formatter, evaluator);
                    if (includeBlankValues || (value != null && !String.valueOf(value).isBlank())) {
                        json.put(key, value == null ? JSONObject.NULL : value);
                    }
                }
                result.put(json);
            }
            return result;
        }
    }

    public JSONArray filterJsonData(String filter, JSONArray source) {
        if (filter == null || filter.isBlank() || "all".equalsIgnoreCase(filter) || "noFilter".equalsIgnoreCase(filter)) {
            return source;
        }
        String[] clauses = filter.split("\\s*(?:&&|;|,)\\s*");
        JSONArray filtered = new JSONArray();
        for (int index = 0; index < source.length(); index++) {
            JSONObject row = source.getJSONObject(index);
            boolean matches = true;
            for (String clause : clauses) {
                if (clause.isBlank()) {
                    continue;
                }
                String operator = clause.contains("!=") ? "!=" : "=";
                String[] parts = clause.split(operator.equals("!=") ? "!=" : "=", 2);
                if (parts.length != 2) {
                    continue;
                }
                String key = parts[0].trim();
                String expected = parts[1].trim();
                String actual = row.optString(key, "");
                boolean clauseMatches = expected.contains("|")
                        ? List.of(expected.split("\\|")).stream().anyMatch(actual::equalsIgnoreCase)
                        : actual.equals(expected);
                if (operator.equals("!=")) {
                    clauseMatches = !clauseMatches;
                }
                matches &= clauseMatches;
            }
            if (matches) {
                filtered.put(row);
            }
        }
        return filtered;
    }

    private static Row firstNonEmptyRow(Sheet sheet) {
        for (Row row : sheet) {
            if (row != null && row.getLastCellNum() > 0) {
                return row;
            }
        }
        return null;
    }

    private static boolean rowIsEmpty(Row row, DataFormatter formatter) {
        for (Cell cell : row) {
            if (!formatter.formatCellValue(cell).trim().isEmpty()) {
                return false;
            }
        }
        return true;
    }

    private static Object cellValue(Cell cell, DataFormatter formatter, FormulaEvaluator evaluator) {
        if (cell == null) {
            return "";
        }
        return switch (cell.getCellType()) {
            case BOOLEAN -> cell.getBooleanCellValue();
            case NUMERIC -> DateUtil.isCellDateFormatted(cell)
                    ? formatter.formatCellValue(cell)
                    : numericValue(cell.getNumericCellValue());
            case FORMULA -> evaluateFormulaCell(cell, formatter, evaluator);
            case STRING -> normalizeLiteral(cell.getStringCellValue());
            case BLANK, _NONE, ERROR -> "";
        };
    }

    private static Object evaluateFormulaCell(Cell cell, DataFormatter formatter, FormulaEvaluator evaluator) {
        CellValue evaluated = evaluator.evaluate(cell);
        if (evaluated == null) {
            return formatter.formatCellValue(cell, evaluator);
        }
        return switch (evaluated.getCellType()) {
            case BOOLEAN -> evaluated.getBooleanValue();
            case NUMERIC -> DateUtil.isCellDateFormatted(cell)
                    ? formatter.formatCellValue(cell, evaluator)
                    : numericValue(evaluated.getNumberValue());
            case STRING -> normalizeLiteral(evaluated.getStringValue());
            case BLANK, _NONE, ERROR -> formatter.formatCellValue(cell, evaluator);
            case FORMULA -> formatter.formatCellValue(cell, evaluator);
        };
    }

    private static Object numericValue(double value) {
        return value == Math.rint(value) ? (long) value : value;
    }

    private static Object normalizeLiteral(String value) {
        String trimmed = value == null ? "" : value.trim();
        if ("true".equalsIgnoreCase(trimmed)) return true;
        if ("false".equalsIgnoreCase(trimmed)) return false;
        if ("null".equalsIgnoreCase(trimmed)) return JSONObject.NULL;
        return value;
    }
}
