package com.farmers.framework.playwright;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.regex.Pattern;

/** Playwright-native wait conditions used by the migrated FFQ pages. */
public final class Conditions {
    private Conditions() { }

    public static WaitCondition<Locator> visible(Locator locator) {
        return timeout -> {
            locator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(timeout));
            return locator;
        };
    }

    public static WaitCondition<Locator> visible(String selector) {
        return visible(PlaywrightSession.resolveLocator(selector));
    }

    public static WaitCondition<Locator> clickable(Locator locator) {
        return timeout -> {
            locator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(timeout));
            waitForBoolean(() -> locator.isVisible() && locator.isEnabled(), timeout);
            return locator;
        };
    }

    public static WaitCondition<Locator> clickable(String selector) {
        return clickable(PlaywrightSession.resolveLocator(selector));
    }

    public static WaitCondition<Locator> attached(String selector) {
        return timeout -> {
            Locator locator = PlaywrightSession.resolveLocator(selector);
            locator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.ATTACHED).setTimeout(timeout));
            return locator;
        };
    }

    public static WaitCondition<Locator> attached(Locator locator) {
        return timeout -> {
            locator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.ATTACHED).setTimeout(timeout));
            return locator;
        };
    }

    public static WaitCondition<List<Locator>> allAttached(String selector) {
        return timeout -> {
            Locator locator = attached(selector).await(timeout);
            waitForBoolean(() -> locator.count() > 0, timeout);
            return locator.all();
        };
    }

    public static WaitCondition<List<Locator>> visibilityOfAllElementsLocatedBy(String selector) {
        return timeout -> {
            Locator locator = PlaywrightSession.resolveLocator(selector);
            waitForBoolean(() -> locator.count() > 0, timeout);
            for (Locator item : locator.all()) {
                visible(item).await(timeout);
            }
            return locator.all();
        };
    }

    public static WaitCondition<List<Locator>> visibilityOfAllElements(List<Locator> locators) {
        return timeout -> {
            for (Locator locator : locators) {
                visible(locator).await(timeout);
            }
            return locators;
        };
    }

    public static WaitCondition<List<Locator>> visibilityOfAllElements(Locator locator) {
        return timeout -> {
            waitForBoolean(() -> locator.count() > 0, timeout);
            List<Locator> locators = locator.all();
            for (Locator item : locators) {
                visible(item).await(timeout);
            }
            return locators;
        };
    }

    public static WaitCondition<Boolean> invisible(Locator locator) {
        return timeout -> {
            locator.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN).setTimeout(timeout));
            return true;
        };
    }

    public static WaitCondition<Boolean> invisible(String selector) {
        return invisible(PlaywrightSession.resolveLocator(selector));
    }

    public static WaitCondition<Boolean> invisibilityOfAllElements(List<Locator> locators) {
        return timeout -> {
            for (Locator locator : locators) {
                invisible(locator).await(timeout);
            }
            return true;
        };
    }

    public static WaitCondition<Boolean> invisibilityOfAllElements(Locator... locators) {
        return invisibilityOfAllElements(Arrays.asList(locators));
    }

    public static WaitCondition<Boolean> invisibilityOfElementWithText(String selector, String text) {
        return timeout -> {
            Locator locator = PlaywrightSession.resolveLocator(selector).filter(new Locator.FilterOptions().setHasText(text));
            invisible(locator).await(timeout);
            return true;
        };
    }

    public static WaitCondition<Boolean> numberOfElementsToBe(String selector, int expected) {
        return timeout -> waitForBoolean(() -> PlaywrightSession.resolveLocator(selector).count() == expected, timeout);
    }

    public static WaitCondition<Boolean> numberOfElementsToBeMoreThan(String selector, int expected) {
        return timeout -> waitForBoolean(() -> PlaywrightSession.resolveLocator(selector).count() > expected, timeout);
    }

    public static WaitCondition<Boolean> pageCount(int expected) {
        return timeout -> waitForBoolean(() -> PlaywrightSession.pages().size() == expected, timeout);
    }

    public static WaitCondition<Boolean> urlToBe(String expected) {
        return timeout -> waitForBoolean(() -> Objects.equals(PlaywrightSession.page().url(), expected), timeout);
    }

    public static WaitCondition<Boolean> urlContains(String expected) {
        return timeout -> waitForBoolean(() -> PlaywrightSession.page().url().contains(expected), timeout);
    }

    public static WaitCondition<Boolean> titleContains(String expected) {
        return timeout -> waitForBoolean(() -> PlaywrightSession.page().title().contains(expected), timeout);
    }

    public static WaitCondition<Boolean> textToBe(String selector, String expected) {
        return timeout -> waitForBoolean(() -> expected.equals(PlaywrightSession.resolveLocator(selector).innerText()), timeout);
    }

    public static WaitCondition<Boolean> textToBe(Locator locator, String expected) {
        return timeout -> waitForBoolean(() -> expected.equals(locator.innerText()), timeout);
    }

    public static WaitCondition<Boolean> textContains(String selector, String expected) {
        return timeout -> waitForBoolean(() -> PlaywrightSession.resolveLocator(selector).innerText().contains(expected), timeout);
    }

    public static WaitCondition<Boolean> textContains(Locator locator, String expected) {
        return timeout -> waitForBoolean(() -> locator.innerText().contains(expected), timeout);
    }

    public static WaitCondition<Boolean> textMatches(String selector, Pattern pattern) {
        return timeout -> waitForBoolean(() -> pattern.matcher(PlaywrightSession.resolveLocator(selector).innerText()).matches(), timeout);
    }

    public static WaitCondition<Boolean> attributeContains(Locator locator, String attribute, String expected) {
        return timeout -> waitForBoolean(() -> {
            String actual = locator.getAttribute(attribute);
            return actual != null && actual.contains(expected);
        }, timeout);
    }

    public static WaitCondition<Boolean> attributeContains(String selector, String attribute, String expected) {
        return attributeContains(PlaywrightSession.resolveLocator(selector), attribute, expected);
    }

    public static WaitCondition<Boolean> attributeToBe(Locator locator, String attribute, String expected) {
        return timeout -> waitForBoolean(() -> Objects.equals(locator.getAttribute(attribute), expected), timeout);
    }

    public static WaitCondition<Boolean> attributeToBeNotEmpty(Locator locator, String attribute) {
        return timeout -> waitForBoolean(() -> {
            String actual = locator.getAttribute(attribute);
            return actual != null && !actual.isEmpty();
        }, timeout);
    }

    @SafeVarargs
    public static WaitCondition<Boolean> or(WaitCondition<?>... conditions) {
        return timeout -> {
            RuntimeException last = null;
            double slice = Math.max(250, timeout / Math.max(1, conditions.length));
            for (WaitCondition<?> condition : conditions) {
                try {
                    condition.await(slice);
                    return true;
                } catch (RuntimeException error) {
                    last = error;
                }
            }
            if (last != null) {
                throw last;
            }
            return false;
        };
    }

    public static WaitCondition<Boolean> not(WaitCondition<?> condition) {
        return timeout -> {
            try {
                condition.await(Math.min(timeout, 1_000));
                return false;
            } catch (RuntimeException expected) {
                return true;
            }
        };
    }

    private static boolean waitForBoolean(BooleanSupplier condition, double timeout) {
        PlaywrightSession.page().waitForCondition(condition,
                new Page.WaitForConditionOptions().setTimeout(timeout));
        return true;
    }
}
