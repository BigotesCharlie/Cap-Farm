package com.farmers.framework.report;

import org.testng.Assert;

public final class Reporter {
    private Reporter() {
    }

    public static void pass(String message) { Log.info("PASS - " + message); }
    public static void pass(String message, boolean screenshot) { pass(message); }
    public static void fail(String message) { Log.error("FAIL - " + message); Assert.fail(message); }
    public static void fail(String message, boolean screenshot) { fail(message); }
}
