package com.farmers.framework.playwright;

import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.LoadState;

/**
 * Conservative blocker recovery. It is only invoked after an interaction failure;
 * normal tests are never redirected simply because a blocker page is being asserted.
 */
public final class RecoveryManager {
    private RecoveryManager() {
    }

    public static boolean recover(Page page, PageStateDetector.PageState detectedState, int attempt) {
        if (page == null || page.isClosed() || !PageStateDetector.isBlocker(detectedState)) {
            return false;
        }

        Log.warn("AutoDebug recovery attempt " + attempt + " for detected state " + detectedState
                + " at " + safeUrl(page));

        if (clickTryAgain(page)) {
            waitForUi(page);
            if (!PageStateDetector.isBlocker(PageStateDetector.detect(page))) {
                Log.info("AutoDebug recovery succeeded via Try Again");
                return true;
            }
        }

        if (Boolean.parseBoolean(Property.getTestProperty("autoDebug.backOnBlocker", "true"))) {
            try {
                Page previous = page;
                previous.goBack(new Page.GoBackOptions().setTimeout(8_000));
                waitForUi(page);
                if (!PageStateDetector.isBlocker(PageStateDetector.detect(page))) {
                    Log.info("AutoDebug recovery succeeded via browser back");
                    return true;
                }
            } catch (RuntimeException error) {
                Log.warn("AutoDebug browser-back recovery did not complete: " + error.getMessage());
            }
        }

        if (Boolean.parseBoolean(Property.getTestProperty("autoDebug.reloadOnBlocker", "true"))) {
            try {
                page.reload(new Page.ReloadOptions().setTimeout(10_000));
                waitForUi(page);
                if (!PageStateDetector.isBlocker(PageStateDetector.detect(page))) {
                    Log.info("AutoDebug recovery succeeded via reload");
                    return true;
                }
            } catch (RuntimeException error) {
                Log.warn("AutoDebug reload recovery did not complete: " + error.getMessage());
            }
        }

        if (Boolean.parseBoolean(Property.getTestProperty("autoDebug.restartOnBlocker", "true"))) {
            try {
                page.navigate(Property.getUri(), new Page.NavigateOptions().setTimeout(15_000));
                waitForUi(page);
                if (!PageStateDetector.isBlocker(PageStateDetector.detect(page))) {
                    Log.info("AutoDebug recovery restarted the FastQuote entry flow");
                    return true;
                }
            } catch (RuntimeException error) {
                Log.warn("AutoDebug FastQuote restart did not complete: " + error.getMessage());
            }
        }

        Log.warn("AutoDebug recovery exhausted for " + detectedState);
        return false;
    }

    private static boolean clickTryAgain(Page page) {
        String selector = "button:has-text('Try again'), button:has-text('Try Again'), "
                + "a:has-text('Try again'), a:has-text('Try Again'), "
                + "[data-testid*='try-again'], [data-test-id*='try-again']";
        try {
            Locator candidates = page.locator(selector);
            int count = Math.min(candidates.count(), 5);
            for (int i = 0; i < count; i++) {
                Locator candidate = candidates.nth(i);
                if (candidate.isVisible()) {
                    candidate.click(new Locator.ClickOptions().setTimeout(5_000));
                    return true;
                }
            }
        } catch (RuntimeException error) {
            Log.warn("AutoDebug Try Again action was unavailable: " + error.getMessage());
        }
        return false;
    }

    private static void waitForUi(Page page) {
        try {
            page.waitForLoadState(LoadState.DOMCONTENTLOADED,
                    new Page.WaitForLoadStateOptions().setTimeout(8_000));
        } catch (RuntimeException ignored) {
        }
        try {
            page.waitForTimeout(750);
        } catch (RuntimeException ignored) {
        }
    }

    private static String safeUrl(Page page) {
        try {
            return page.url();
        } catch (RuntimeException ignored) {
            return "<unavailable>";
        }
    }
}
