package com.farmers.framework.testng;

import com.farmers.framework.report.Log;
import org.testng.ITestListener;
import org.testng.ITestResult;

public final class TestListener implements ITestListener {
    @Override
    public void onTestSuccess(ITestResult result) {
        Log.info("PASSED - " + result.getName());
    }

    @Override
    public void onTestFailure(ITestResult result) {
        Log.error("FAILED - " + result.getName(), result.getThrowable());
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        Log.warn("SKIPPED - " + result.getName());
    }
}
