package com.farmers.framework;

import com.microsoft.playwright.TimeoutError;

import com.microsoft.playwright.PlaywrightException;

import com.microsoft.playwright.Page;

import com.microsoft.playwright.Locator;

import com.farmers.framework.playwright.*;
import com.farmers.framework.report.Log;
import com.microsoft.playwright.*;
import com.microsoft.playwright.options.BoundingBox;
import com.microsoft.playwright.options.SelectOption;
import com.microsoft.playwright.options.ViewportSize;
import com.microsoft.playwright.options.Cookie;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import com.microsoft.playwright.options.LoadState;
import com.microsoft.playwright.options.WaitUntilState;

/**
 * Playwright-native test runtime for FFQ.
 * It exposes Page, BrowserContext, Browser and Locator directly.
 */
public class AutomationFramework {
    @BeforeMethod(alwaysRun = true)
    public void startPlaywrightTest(Method method) {
        PlaywrightSession.startTest(method == null ? getClass().getSimpleName() :
                getClass().getSimpleName() + "." + method.getName());
    }

    @AfterMethod(alwaysRun = true)
    public void finishPlaywrightTest(ITestResult result) {
        boolean failed = result != null && !result.isSuccess();
        String name = result == null ? getClass().getSimpleName() :
                result.getTestClass().getRealClass().getSimpleName() + "." + result.getMethod().getMethodName();
        PlaywrightSession.endTest(failed, name);
    }

    @AfterClass(alwaysRun = true)
    public void closePlaywrightWorker() {
        PlaywrightSession.shutdownCurrentThread();
    }

    public static Page page() {
        return PlaywrightSession.page();
    }

    public static BrowserContext context() {
        return PlaywrightSession.context();
    }

    public static Browser browser() {
        return PlaywrightSession.browser();
    }

    public static Playwright playwright() {
        return PlaywrightSession.playwright();
    }

    public static boolean isMobileApplication() {
        return Boolean.parseBoolean(Property.getTestProperty("mobileApplication", "false"));
    }

    protected static Locator locator(String selector) {
        return LazyLocator.of(selector);
    }

    protected static Locator locatorAny(String... selectors) {
        return LazyLocator.any(selectors);
    }

    protected static List<Locator> locators(String selector) {
        return PlaywrightSession.resolveLocator(selector).all();
    }

    protected static List<Locator> locators(Locator parent, String selector) {
        return parent.locator(selector).all();
    }

    protected static String pwXPath(String xpath) {
        return xpath.startsWith("xpath=") ? xpath : "xpath=" + xpath;
    }

    protected static String pwCss(String css) {
        return css;
    }

    protected static String pwId(String id) {
        return "[id=" + quoteCss(id) + "]";
    }

    protected static String pwClass(String className) {
        return "." + cssEscape(className);
    }

    protected static String pwName(String name) {
        return "[name=" + quoteCss(name) + "]";
    }

    protected static String pwTag(String tag) {
        return tag;
    }

    protected static String pwLinkText(String text) {
        return "a:has-text(" + quoteCss(text) + ")";
    }

    protected static String pwPartialLinkText(String text) {
        return pwLinkText(text);
    }

    protected static PlaywrightWait waitFor(int seconds) {
        return new PlaywrightWait(Math.max(1, seconds) * 1_000d);
    }

    protected static PlaywrightWait waitFor(double seconds) {
        return new PlaywrightWait(Math.max(0.001, seconds) * 1_000d);
    }


    protected static PlaywrightWait conditionalWait(int seconds) {
        return waitFor(seconds);
    }

    protected static PlaywrightWait conditionalWait(double seconds) {
        return waitFor(seconds);
    }

    protected static PlaywrightActions actions() {
        return new PlaywrightActions(page());
    }

    protected static PlaywrightActions sendKeys(PlaywrightActions actions, CharSequence... values) {
        return actions.sendKeys(values);
    }

    protected static PlaywrightActions sendKeys(PlaywrightActions actions, Locator locator, CharSequence... values) {
        return actions.sendKeys(locator, values);
    }

    protected static PlaywrightSelect select(Locator locator) {
        return new PlaywrightSelect(locator);
    }

    protected static Locator selectedOption(Locator locator) {
        return locator.locator("option:checked").first();
    }

    protected static Page newPage() {
        Page created = context().newPage();
        PlaywrightSession.setPage(created);
        return created;
    }

    protected static void switchToParentFrame() {
        Frame frame = PlaywrightSession.frame();
        PlaywrightSession.setFrame(frame == null ? null : frame.parentFrame());
    }

    protected static void maximizeWindow() {
        setViewportSize(1920, 1080);
    }

    protected static void addCookie(Cookie cookie) {
        if (cookie != null) {
            context().addCookies(List.of(cookie));
        }
    }

    protected static Object executeScript(String script, Object... arguments) {
        if (arguments == null || arguments.length == 0) {
            String body = script == null ? "" : script.trim();
            return page().evaluate(isPlaywrightCallbackScript(body) ? body : "() => { " + body + " }");
        }
        if (arguments[0] instanceof Locator locator) {
            Object[] rest = Arrays.copyOfRange(arguments, 1, arguments.length);
            String converted = script;
            for (int i = rest.length; i >= 1; i--) {
                converted = converted.replace("arguments[" + i + "]", "args[" + (i - 1) + "]");
            }
            converted = converted.replace("arguments[0]", "element");
            String body = converted.trim();
            if (body.startsWith("return ")) {
                body = body.substring(7);
                if (body.endsWith(";")) {
                    body = body.substring(0, body.length() - 1);
                }
                return locator.evaluate("(element, args) => (" + body + ")", rest);
            }
            return locator.evaluate("(element, args) => { " + body + " }", rest);
        }
        Object argument = arguments.length == 1 ? arguments[0] : arguments;
        return page().evaluate("args => { " + script + " }", argument);
    }

    private static boolean isPlaywrightCallbackScript(String script) {
        return script.startsWith("() =>")
                || script.startsWith("()=>")
                || script.startsWith("async () =>")
                || script.startsWith("async()=>")
                || script.startsWith("function")
                || script.startsWith("async function");
    }

    protected static String pwChained(String... selectors) {
        if (selectors == null || selectors.length == 0) {
            return "";
        }
        return String.join(" >> ", selectors);
    }

    protected static void navigate(String url) {
        page().navigate(url, new Page.NavigateOptions().setWaitUntil(WaitUntilState.DOMCONTENTLOADED));
    }

    protected static void refreshPage() {
        page().reload();
    }

    protected static void back() {
        page().goBack();
    }

    protected static void forward() {
        page().goForward();
    }

    protected static List<Page> pages() {
        return PlaywrightSession.pages();
    }

    protected static Page currentPage() {
        return page();
    }

    protected static void switchToPage(Page target) {
        if (target == null || target.isClosed()) {
            throw new IllegalArgumentException("Target Playwright Page is null or closed");
        }
        PlaywrightSession.setPage(target);
        target.bringToFront();
    }

    protected static void switchToFrame(Locator frameElement) {
        ElementHandle handle = frameElement.elementHandle();
        if (handle == null || handle.contentFrame() == null) {
            throw new PlaywrightException("The supplied locator is not an attached iframe");
        }
        PlaywrightSession.setFrame(handle.contentFrame());
    }

    protected static void switchToFrame(String nameOrSelector) {
        if (nameOrSelector == null || nameOrSelector.isBlank()) {
            throw new IllegalArgumentException("Frame name or selector is required");
        }
        String escaped = nameOrSelector.replace("\\", "\\\\").replace("\"", "\\\"");
        Locator candidate = page().locator("iframe[name=\"" + escaped + "\"], iframe#" + cssEscape(nameOrSelector)).first();
        if (candidate.count() == 0 && (nameOrSelector.startsWith("//") || nameOrSelector.startsWith("css=") || nameOrSelector.startsWith("xpath="))) {
            candidate = page().locator(nameOrSelector).first();
        }
        switchToFrame(candidate);
    }

    protected static void switchToDefaultContent() {
        PlaywrightSession.setFrame(null);
    }

    protected static Locator activeElement() {
        return page().locator(":focus");
    }

    protected static void closeCurrentPage() {
        Page closing = page();
        closing.close();
        List<Page> remaining = pages();
        if (!remaining.isEmpty()) {
            PlaywrightSession.setPage(remaining.get(remaining.size() - 1));
        }
    }

    protected static void clearCookies() {
        PlaywrightSession.clearCookies();
    }

    protected static void setViewportSize(int width, int height) {
        PlaywrightSession.setViewportSize(width, height);
    }

    protected static ViewportSize viewportSize() {
        return PlaywrightSession.viewportSize();
    }

    protected static void sendKeys(Locator locator, Object... values) {
        Objects.requireNonNull(locator, "locator");
        for (Object value : values) {
            if (value == null) {
                continue;
            }
            String text = String.valueOf(value);
            if (isKeyboardKey(text)) {
                locator.press(text);
            } else {
                locator.pressSequentially(text);
            }
        }
    }

    protected static void sendKeys(Object ignored, Locator locator, Object... values) {
        sendKeys(locator, values);
    }

    protected static void clearAndType(Locator locator, String value) {
        locator.fill(value == null ? "" : value);
    }

    protected static void selectByVisibleText(Locator locator, String text) {
        locator.selectOption(new SelectOption().setLabel(text));
    }

    protected static void selectByValue(Locator locator, String value) {
        locator.selectOption(value);
    }

    protected static void selectByIndex(Locator locator, int index) {
        Locator options = locator.locator("option");
        String value = options.nth(index).getAttribute("value");
        if (value != null) {
            locator.selectOption(value);
        } else {
            locator.selectOption(new SelectOption().setIndex(index));
        }
    }

    protected static String cssValue(Locator locator, String property) {
        Object value = locator.evaluate("(element, property) => getComputedStyle(element).getPropertyValue(property)", property);
        return value == null ? "" : String.valueOf(value);
    }

    protected static String accessibleName(Locator locator) {
        Object value = locator.evaluate("element => element.getAttribute('aria-label') || element.innerText || element.textContent || ''");
        return value == null ? "" : String.valueOf(value).trim();
    }

    protected static BoundingBox boundingBox(Locator locator) {
        BoundingBox box = locator.boundingBox();
        if (box == null) {
            throw new PlaywrightException("Element has no bounding box: " + locator);
        }
        return box;
    }

    /**
     * Waits on application state rather than elapsed time. Playwright actions already
     * auto-wait; this method only covers application-level busy indicators that are
     * not directly tied to the next Locator action.
     */
    protected static void waitForUiSettled() {
        if (!PlaywrightSession.hasActivePage()) {
            return;
        }
        try {
            page().waitForLoadState(LoadState.DOMCONTENTLOADED);
            Locator busy = page().locator(
                    "[aria-busy='true'], mat-progress-spinner, app-loading-skeleton, " +
                    ".tui-spinner-center-content, #waitQuoteReady, .waitDialog");
            page().waitForCondition(
                    () -> busy.count() == 0 || busy.all().stream().noneMatch(Locator::isVisible),
                    new Page.WaitForConditionOptions().setTimeout(10_000));
        } catch (TimeoutError ignored) {
            Log.debug("Application busy indicator did not settle within the conditional wait window");
        }
    }

    public final void performADATesting(String pageName, String... tags) {
        String scope = tags == null || tags.length == 0 ? pageName : pageName + " [" + String.join(", ", tags) + "]";
        Log.info("ADA validation hook invoked for " + scope);
        captureOptionalScreenshot(PlaywrightSession.hasActivePage(), pageName + "-ada");
    }


    public static void testStep(String message) {
        Log.info(message);
    }

    public static void testStep(String message, boolean passed) {
        if (passed) {
            Log.info("PASS - " + message);
        } else {
            Log.error("FAIL - " + message);
        }
    }

    public static void testStep(String message, String details) {
        if (details == null || details.isBlank()) {
            testStep(message);
            return;
        }
        Log.info(message + " - " + details);
    }

    public static void testStep(String message, boolean passed, boolean screenshot) {
        logTestStep(message, passed);
        captureOptionalScreenshot(screenshot, "test-step");
    }

    public static void testStep(String message, String details, boolean screenshot) {
        testStep(message, details);
        captureOptionalScreenshot(screenshot, "test-step");
    }

    public static void testStep(String message, boolean passed, boolean screenshot, boolean additionalReportingFlag) {
        logTestStep(message, passed);
        captureOptionalScreenshot(screenshot || additionalReportingFlag, "test-step");
    }

    public static void testStep(String message, boolean passed, String artifactName, boolean screenshot) {
        logTestStep(message, passed);
        captureOptionalScreenshot(screenshot, artifactName);
    }

    /** Preserves legacy reporting flags without reintroducing fixed waits or browser-driver behavior. */
    public static void testStep(String message, boolean passed, boolean... reportingFlags) {
        logTestStep(message, passed);
        captureOptionalScreenshot(containsTrue(reportingFlags), "test-step");
    }

    public static void testStepAssert(boolean condition, String message, boolean screenshot) {
        if (condition) {
            Log.info("PASS - " + message);
        } else {
            Log.error("FAIL - " + message);
        }
        captureOptionalScreenshot(screenshot && !condition, "assertion");
        Assert.assertTrue(condition, message);
    }

    public static void testStepAssert(boolean condition, String message) {
        testStepAssert(condition, message, false);
    }

    public static void testStepAssert(Object actual, Object expected, String message) {
        testStepAssert(actual, expected, message, false);
    }

    public static void testStepAssert(Object actual, Object expected, String message, boolean screenshot) {
        try {
            Assert.assertEquals(actual, expected, message);
            Log.info("PASS - " + message);
        } catch (AssertionError error) {
            Log.error("FAIL - " + message);
            captureOptionalScreenshot(screenshot, "assertion");
            throw error;
        }
    }

    public static void testStepAssert(String actual, String expected, String message) throws AssertionError {
        testStepAssert((Object) actual, expected, message, false);
    }

    public static void testStepAssert(String actual, String expected, String message, boolean screenshot) throws AssertionError {
        testStepAssert((Object) actual, expected, message, screenshot);
    }

    public static void testStepAssert(boolean actual, boolean expected, String message) throws AssertionError {
        testStepAssert(Boolean.valueOf(actual), Boolean.valueOf(expected), message, false);
    }

    public static void testStepAssert(boolean actual, boolean expected, String message, boolean screenshot) throws AssertionError {
        testStepAssert(Boolean.valueOf(actual), Boolean.valueOf(expected), message, screenshot);
    }

    public static void testStepAssertTrue(boolean condition, String message) throws AssertionError {
        testStepAssert(condition, message, false);
    }

    public static void testStepAssertTrue(boolean condition, String message, boolean screenshot) throws AssertionError {
        testStepAssert(condition, message, screenshot);
    }

    public static void testStepAssertFalse(boolean condition, String message) throws AssertionError {
        testStepAssert(!condition, message, false);
    }

    public static void testStepAssertFalse(boolean condition, String message, boolean screenshot) throws AssertionError {
        testStepAssert(!condition, message, screenshot);
    }

    private static void logTestStep(String message, boolean passed) {
        if (passed) {
            Log.info("PASS - " + message);
        } else {
            Log.error("FAIL - " + message);
        }
    }

    private static void captureOptionalScreenshot(boolean screenshotRequested, String artifactName) {
        if (!screenshotRequested || !PlaywrightSession.hasActivePage()) {
            return;
        }
        try {
            PlaywrightArtifacts.screenshot(artifactName == null || artifactName.isBlank() ? "test-step" : artifactName);
        } catch (RuntimeException error) {
            Log.debug("Optional screenshot could not be captured: " + error.getMessage());
        }
    }

    private static boolean containsTrue(boolean[] flags) {
        if (flags == null) {
            return false;
        }
        for (boolean flag : flags) {
            if (flag) {
                return true;
            }
        }
        return false;
    }

    private static boolean isKeyboardKey(String value) {
        return value.matches("(?i)(Enter|Tab|Escape|Backspace|Delete|ArrowDown|ArrowUp|ArrowLeft|ArrowRight|Home|End|PageDown|PageUp|Control|Meta|Shift|Alt)(\\+.*)?");
    }

    private static String quoteCss(String value) {
        String escaped = value == null ? "" : value.replace("\\", "\\\\").replace("\"", "\\\"");
        return "\"" + escaped + "\"";
    }

    private static String cssEscape(String value) {
        return value == null ? "" : value.replaceAll("([^a-zA-Z0-9_-])", "\\\\$1");
    }
}
