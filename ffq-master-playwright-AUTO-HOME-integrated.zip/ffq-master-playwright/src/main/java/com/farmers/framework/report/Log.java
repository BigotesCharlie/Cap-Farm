package com.farmers.framework.report;

import java.time.OffsetDateTime;

public final class Log {
    private Log() {
    }

    public static void debug(String message) { write("DEBUG", message, null); }
    public static void info(String message) { write("INFO", message, null); }
    public static void info(String message, boolean screenshot) { write("INFO", message, null); }
    public static void info(String message, String artifactName) { write("INFO", message + " [artifact=" + artifactName + "]", null); }
    public static void warn(String message) { write("WARN", message, null); }
    public static void warn(String message, boolean screenshot) { write("WARN", message, null); }
    public static void warn(String message, String artifactName) { write("WARN", message + " [artifact=" + artifactName + "]", null); }
    public static void error(String message) { write("ERROR", message, null); }
    public static void error(String message, boolean screenshot) { write("ERROR", message, null); }
    public static void error(String message, Throwable error) { write("ERROR", message, error); }

    private static synchronized void write(String level, String message, Throwable error) {
        String line = "%s [%s] [%s] %s".formatted(
                OffsetDateTime.now(), level, Thread.currentThread().getName(), message == null ? "" : message);
        if ("ERROR".equals(level)) {
            System.err.println(line);
        } else {
            System.out.println(line);
        }
        if (error != null) {
            error.printStackTrace(System.err);
        }
    }
}
