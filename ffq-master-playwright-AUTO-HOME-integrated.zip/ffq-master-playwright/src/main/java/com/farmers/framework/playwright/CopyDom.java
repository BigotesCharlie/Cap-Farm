package com.farmers.framework.playwright;

import com.farmers.framework.report.Log;
import com.microsoft.playwright.Page;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Locale;

/**
 * Central Copy-DOM implementation. Every snapshot is isolated by test execution and
 * includes the HTML plus a small metadata sidecar so locator/debug analysis can be
 * performed after the browser is gone.
 */
public final class CopyDom {
    private CopyDom() {
    }

    public static Snapshot capture(Page page, Path executionDirectory, int sequence, String label) {
        if (page == null || page.isClosed() || executionDirectory == null) {
            return null;
        }

        String prefix = String.format(Locale.ROOT, "%03d-%s", sequence, sanitize(label));
        Path htmlPath = executionDirectory.resolve(prefix + ".html");
        Path metadataPath = executionDirectory.resolve(prefix + ".txt");

        try {
            Files.createDirectories(executionDirectory);
            String html = page.content();
            Files.writeString(htmlPath, html, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

            PageStateDetector.PageState state = PageStateDetector.detect(page);
            String title = safeTitle(page);
            String metadata = "label=" + label + System.lineSeparator()
                    + "state=" + state + System.lineSeparator()
                    + "url=" + safeUrl(page) + System.lineSeparator()
                    + "title=" + title + System.lineSeparator();
            Files.writeString(metadataPath, metadata, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

            return new Snapshot(htmlPath, metadataPath, state, html.hashCode());
        } catch (Exception error) {
            Log.warn("CopyDOM capture failed for '" + label + "': " + error.getMessage());
            return null;
        }
    }

    private static String safeUrl(Page page) {
        try {
            return page.url() == null ? "" : page.url();
        } catch (RuntimeException ignored) {
            return "";
        }
    }

    private static String safeTitle(Page page) {
        try {
            return page.title();
        } catch (RuntimeException ignored) {
            return "";
        }
    }

    private static String sanitize(String value) {
        String safe = value == null || value.isBlank() ? "dom" : value.replaceAll("[^a-zA-Z0-9._-]", "_");
        return safe.length() > 100 ? safe.substring(0, 100) : safe;
    }

    public record Snapshot(Path htmlPath, Path metadataPath, PageStateDetector.PageState state, int domHash) {
    }
}
