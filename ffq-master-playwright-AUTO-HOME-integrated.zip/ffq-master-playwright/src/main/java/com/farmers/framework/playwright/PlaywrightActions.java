package com.farmers.framework.playwright;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

/**
 * Small fluent Playwright keyboard/mouse adapter used while preserving the original
 * test intent. It does not implement or depend on any browser-driver API.
 */
public final class PlaywrightActions {
    private final Page page;
    private Runnable pending = () -> { };

    public PlaywrightActions(Page page) {
        this.page = page;
    }

    public PlaywrightActions sendKeys(CharSequence... keys) {
        append(() -> pressValues(null, keys));
        return this;
    }

    public PlaywrightActions sendKeys(Locator locator, CharSequence... keys) {
        append(() -> pressValues(locator, keys));
        return this;
    }

    public PlaywrightActions moveToElement(Locator locator) {
        append(locator::hover);
        return this;
    }

    public PlaywrightActions moveToElement(Locator locator, int xOffset, int yOffset) {
        append(() -> locator.hover(new Locator.HoverOptions().setPosition(xOffset, yOffset)));
        return this;
    }

    public PlaywrightActions click() {
        append(() -> { page.mouse().down(); page.mouse().up(); });
        return this;
    }

    public PlaywrightActions click(Locator locator) {
        append(locator::click);
        return this;
    }

    public PlaywrightActions keyDown(CharSequence key) {
        append(() -> page.keyboard().down(String.valueOf(key)));
        return this;
    }

    public PlaywrightActions keyUp(CharSequence key) {
        append(() -> page.keyboard().up(String.valueOf(key)));
        return this;
    }

    public PlaywrightActions build() {
        return this;
    }

    public void perform() {
        Runnable action = pending;
        pending = () -> { };
        action.run();
    }

    private void append(Runnable next) {
        Runnable previous = pending;
        pending = () -> {
            previous.run();
            next.run();
        };
    }

    private void pressValues(Locator locator, CharSequence... values) {
        for (CharSequence raw : values) {
            if (raw == null) {
                continue;
            }
            String value = raw.toString();
            if (locator == null) {
                if (isKey(value)) {
                    page.keyboard().press(value);
                } else {
                    page.keyboard().type(value);
                }
            } else if (isKey(value)) {
                locator.press(value);
            } else {
                locator.pressSequentially(value);
            }
        }
    }

    private static boolean isKey(String value) {
        return value.matches("(?i)(Enter|Tab|Escape|Backspace|Delete|ArrowDown|ArrowUp|ArrowLeft|ArrowRight|Home|End|PageDown|PageUp|Control|Meta|Shift|Alt)(\\+.*)?");
    }
}
