package com.farmers.framework.playwright;

public final class PlaywrightWait {
    private final double timeoutMillis;

    public PlaywrightWait(double timeoutMillis) {
        this.timeoutMillis = timeoutMillis;
    }

    public <T> T until(WaitCondition<T> condition) {
        return condition.await(timeoutMillis);
    }

    /** Compatibility no-op: Playwright locators re-resolve and do not go stale. */
    public PlaywrightWait ignoring(Class<? extends Throwable> ignored) {
        return this;
    }
}
