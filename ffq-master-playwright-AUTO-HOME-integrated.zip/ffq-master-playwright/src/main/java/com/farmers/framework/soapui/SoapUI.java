package com.farmers.framework.soapui;

import com.farmers.framework.report.Log;
import org.json.JSONObject;
import org.json.XML;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilderFactory;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Minimal SoapUI-project runner implemented with the JDK HTTP client. It keeps
 * the existing test-data contract while removing the legacy framework runtime.
 */
public final class SoapUI {
    private static Project project;

    private SoapUI() {
    }

    public static synchronized void setProject(String fileName) throws Exception {
        Path path = Paths.get("src", "test", "resources", fileName);
        if (!Files.exists(path)) {
            path = Paths.get(fileName);
        }
        project = new Project(path);
    }

    public static Project project() {
        if (project == null) {
            throw new IllegalStateException("SoapUI project has not been set");
        }
        return project;
    }

    public static JSONObject executeTestStep(String testCaseName, String testStepName) throws Exception {
        return project().execute(testCaseName, testStepName);
    }

    public static final class Project {
        private final Document document;
        private final ProjectProperties properties = new ProjectProperties();
        private final HttpClient client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(30))
                .build();

        private Project(Path path) throws Exception {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(false);
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            this.document = factory.newDocumentBuilder().parse(path.toFile());
        }

        public ProjectProperties properties() {
            return properties;
        }

        private JSONObject execute(String testCaseName, String testStepName) throws Exception {
            Element testCase = findByName(document.getElementsByTagName("con:testCase"), testCaseName);
            Element testStep = findByName(testCase.getElementsByTagName("con:testStep"), testStepName);
            Element requestNode = firstElement(testStep, "con:request");
            Element endpointNode = firstElement(requestNode, "con:endpoint");
            Element bodyNode = lastElement(requestNode, "con:request");
            String endpoint = endpointNode.getTextContent().trim();
            String body = replaceProperties(bodyNode.getTextContent(), properties.valuesFor(testCaseName));

            HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(endpoint))
                    .timeout(Duration.ofSeconds(90))
                    .header("Content-Type", "text/xml; charset=UTF-8")
                    .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8));

            Element wsaConfig = firstOptional(requestNode, "con:wsaConfig");
            if (wsaConfig != null && wsaConfig.hasAttribute("action")) {
                builder.header("SOAPAction", wsaConfig.getAttribute("action"));
            }

            HttpResponse<String> response = client.send(builder.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (response.statusCode() >= 400) {
                throw new IllegalStateException("SOAP request failed with HTTP " + response.statusCode() + ": " + response.body());
            }
            return XML.toJSONObject(response.body(), true);
        }

        private static Element findByName(NodeList nodes, String name) {
            for (int i = 0; i < nodes.getLength(); i++) {
                Node node = nodes.item(i);
                if (node instanceof Element element && name.equals(element.getAttribute("name"))) {
                    return element;
                }
            }
            throw new IllegalArgumentException("SoapUI node not found: " + name);
        }

        private static Element firstElement(Element parent, String tag) {
            Element element = firstOptional(parent, tag);
            if (element == null) {
                throw new IllegalArgumentException("SoapUI element not found: " + tag);
            }
            return element;
        }

        private static Element firstOptional(Element parent, String tag) {
            NodeList nodes = parent.getElementsByTagName(tag);
            return nodes.getLength() == 0 ? null : (Element) nodes.item(0);
        }

        private static Element lastElement(Element parent, String tag) {
            NodeList nodes = parent.getElementsByTagName(tag);
            if (nodes.getLength() == 0) {
                throw new IllegalArgumentException("SoapUI element not found: " + tag);
            }
            return (Element) nodes.item(nodes.getLength() - 1);
        }

        private static String replaceProperties(String body, Map<String, String> values) {
            String result = body;
            for (Map.Entry<String, String> entry : values.entrySet()) {
                result = result.replace("${#TestCase#" + entry.getKey() + "}", entry.getValue());
            }
            return result;
        }
    }

    public static final class ProjectProperties {
        private final Map<String, Map<String, String>> values = new LinkedHashMap<>();

        public void setTestCaseProperty(String testCaseName, String key, String value) {
            values.computeIfAbsent(testCaseName, ignored -> new LinkedHashMap<>()).put(key, value == null ? "" : value);
        }

        public void displayTestCaseProperties() {
            values.forEach((testCase, properties) -> Log.info("SOAP properties for " + testCase + ": " + properties.keySet()));
        }

        private Map<String, String> valuesFor(String testCaseName) {
            return values.getOrDefault(testCaseName, Map.of());
        }
    }
}
