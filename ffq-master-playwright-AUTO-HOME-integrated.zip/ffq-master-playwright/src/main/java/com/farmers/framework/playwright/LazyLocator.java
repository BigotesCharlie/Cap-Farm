package com.farmers.framework.playwright;

import com.microsoft.playwright.Page;

import com.microsoft.playwright.Locator;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;
import java.util.Arrays;

/** Creates Locator proxies that resolve against the current test Page lazily. */
public final class LazyLocator {
    private LazyLocator() {
    }

    public static Locator of(String selector) {
        return proxy(() -> PlaywrightSession.resolveLocator(selector), selector);
    }

    public static Locator any(String... selectors) {
        String description = "any(" + String.join(", ", selectors) + ")";
        return proxy(() -> PlaywrightSession.resolveAny(selectors), description);
    }

    private static Locator proxy(Resolver resolver, String description) {
        return (Locator) Proxy.newProxyInstance(
                Locator.class.getClassLoader(),
                new Class<?>[]{Locator.class},
                (proxy, method, args) -> {
                    if (method.getDeclaringClass() == Object.class) {
                        return switch (method.getName()) {
                            case "toString" -> "LazyLocator[" + description + "]";
                            case "hashCode" -> description.hashCode();
                            case "equals" -> proxy == (args == null ? null : args[0]);
                            default -> method.invoke(proxy, args);
                        };
                    }
                    try {
                        Object result = method.invoke(resolver.resolve(), args);
                        AutoDebugManager.afterLocatorAction(method.getName());
                        return result;
                    } catch (InvocationTargetException error) {
                        Throwable cause = error.getTargetException();
                        if (AutoDebugManager.onLocatorFailure(description, method.getName(), cause)) {
                            try {
                                Object result = method.invoke(resolver.resolve(), args);
                                AutoDebugManager.afterLocatorAction(method.getName());
                                return result;
                            } catch (InvocationTargetException retryError) {
                                throw retryError.getTargetException();
                            }
                        }
                        throw cause;
                    }
                });
    }

    @FunctionalInterface
    private interface Resolver {
        Locator resolve();
    }
}
