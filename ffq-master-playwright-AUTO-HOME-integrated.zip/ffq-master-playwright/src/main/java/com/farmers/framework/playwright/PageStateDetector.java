package com.farmers.framework.playwright;

import com.microsoft.playwright.Page;

import java.util.Locale;

/**
 * Lightweight, product-agnostic state detector used by the resiliency layer.
 * It deliberately relies on URL + rendered page text so it works for AUTO and HOME
 * without coupling tests to a specific Page Object.
 */
public final class PageStateDetector {
    private PageStateDetector() {
    }

    public enum PageState {
        AUTO,
        HOME,
        INCONVENIENCE,
        KNOCKOUT,
        TRY_AGAIN,
        UNKNOWN
    }

    public static PageState detect(Page page) {
        if (page == null || page.isClosed()) {
            return PageState.UNKNOWN;
        }

        String url = safeUrl(page).toLowerCase(Locale.ROOT);
        String text = safeBodyText(page).toLowerCase(Locale.ROOT);

        if (containsAny(url, "/inconvenience", "inconvenience")
                || containsAny(text, "inconvenience page", "something went wrong", "we hit a snag")) {
            return PageState.INCONVENIENCE;
        }

        if (containsAny(url, "/knockout", "knockout")
                || containsAny(text,
                "we're unable to offer",
                "we are unable to offer",
                "unable to continue your quote",
                "cannot continue your quote")) {
            return PageState.KNOCKOUT;
        }

        if (containsAny(text, "try again", "please try again")) {
            return PageState.TRY_AGAIN;
        }

        if (containsAny(url, "home", "homequote", "home-quote", "property")) {
            return PageState.HOME;
        }

        if (containsAny(url, "auto", "fastquote")) {
            return PageState.AUTO;
        }

        return PageState.UNKNOWN;
    }

    public static boolean isBlocker(PageState state) {
        return state == PageState.INCONVENIENCE
                || state == PageState.KNOCKOUT
                || state == PageState.TRY_AGAIN;
    }

    private static String safeUrl(Page page) {
        try {
            return page.url() == null ? "" : page.url();
        } catch (RuntimeException ignored) {
            return "";
        }
    }

    private static String safeBodyText(Page page) {
        try {
            return page.locator("body").innerText(new com.microsoft.playwright.Locator.InnerTextOptions().setTimeout(1_500));
        } catch (RuntimeException ignored) {
            return "";
        }
    }

    private static boolean containsAny(String value, String... tokens) {
        for (String token : tokens) {
            if (value.contains(token)) {
                return true;
            }
        }
        return false;
    }
}
