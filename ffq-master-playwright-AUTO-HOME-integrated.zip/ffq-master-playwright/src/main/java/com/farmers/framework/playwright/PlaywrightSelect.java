package com.farmers.framework.playwright;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.options.SelectOption;

import java.util.List;

/** Playwright-native adapter for the few select-element operations used by FFQ. */
public final class PlaywrightSelect {
    private final Locator select;

    public PlaywrightSelect(Locator select) {
        this.select = select;
    }

    public void selectByVisibleText(String text) {
        select.selectOption(new SelectOption().setLabel(text));
    }

    public void selectByValue(String value) {
        select.selectOption(value);
    }

    public void selectByIndex(int index) {
        Locator option = select.locator("option").nth(index);
        String value = option.getAttribute("value");
        if (value != null) {
            select.selectOption(value);
        } else {
            select.selectOption(new SelectOption().setIndex(index));
        }
    }

    public List<Locator> getOptions() {
        return select.locator("option").all();
    }

    public Locator getFirstSelectedOption() {
        return select.locator("option:checked").first();
    }
}
