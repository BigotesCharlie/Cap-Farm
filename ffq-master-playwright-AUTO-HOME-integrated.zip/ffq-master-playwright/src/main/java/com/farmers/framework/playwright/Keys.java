package com.farmers.framework.playwright;

/** Playwright keyboard key names used by the migrated tests. */
public final class Keys {
    public static final String ENTER = "Enter";
    public static final String TAB = "Tab";
    public static final String ESCAPE = "Escape";
    public static final String BACK_SPACE = "Backspace";
    public static final String DELETE = "Delete";
    public static final String ARROW_DOWN = "ArrowDown";
    public static final String ARROW_UP = "ArrowUp";
    public static final String ARROW_LEFT = "ArrowLeft";
    public static final String ARROW_RIGHT = "ArrowRight";
    public static final String DOWN = ARROW_DOWN;
    public static final String UP = ARROW_UP;
    public static final String RETURN = ENTER;
    public static final String HOME = "Home";
    public static final String END = "End";
    public static final String PAGE_DOWN = "PageDown";
    public static final String PAGE_UP = "PageUp";
    public static final String CONTROL = "Control";
    public static final String COMMAND = "Meta";
    public static final String SHIFT = "Shift";
    public static final String ALT = "Alt";

    private Keys() {
    }

    public static String chord(String... keys) {
        return String.join("+", keys);
    }
}
