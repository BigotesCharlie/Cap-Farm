package com.farmers.framework.testng;

import com.farmers.framework.annotation.Skip;
import org.testng.IMethodInstance;
import org.testng.IMethodInterceptor;
import org.testng.ITestContext;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/** Applies the legacy @Skip contract without retrying or hiding failures. */
public final class MethodInterceptor implements IMethodInterceptor {

    @Override
    public List<IMethodInstance> intercept(List<IMethodInstance> methods, ITestContext context) {
        boolean honorSkip = resolveHonorSkip();
        System.out.println("Custom @Skip honored: " + honorSkip);
        if (!honorSkip) {
            return methods;
        }
        List<IMethodInstance> selected = new ArrayList<>();
        for (IMethodInstance instance : methods) {
            Method method = instance.getMethod().getConstructorOrMethod().getMethod();
            Class<?> type = instance.getInstance().getClass();
            if (method == null || (!method.isAnnotationPresent(Skip.class) && !type.isAnnotationPresent(Skip.class))) {
                selected.add(instance);
            }
        }
        return selected;
    }

    /**
     * Resolves whether the custom @Skip annotation should be honoured for this execution.
     * Precedence: System.getProperty("ffq.skip") > System.getenv("FFQ_SKIP") > default true.
     * Passing ffq.skip=false (or FFQ_SKIP=false) temporarily overrides the skip gate.
     */
    private static boolean resolveHonorSkip() {
        String prop = System.getProperty("ffq.skip");
        if (prop != null) {
            return Boolean.parseBoolean(prop.trim().toLowerCase());
        }
        String env = System.getenv("FFQ_SKIP");
        if (env != null) {
            return Boolean.parseBoolean(env.trim().toLowerCase());
        }
        return true;
    }
}
