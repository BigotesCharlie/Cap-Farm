package com.farmers.framework.playwright;

import com.microsoft.playwright.Page;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/** Playwright evidence and viewport helpers. */
public final class PlaywrightArtifacts {
    public static final ScreenSize MOBILE = new ScreenSize(390, 844);

    private PlaywrightArtifacts() {
    }

    public static Path screenshot(String name) {
        return screenshot(name, true, "evidence");
    }

    public static Path screenshot(String name, boolean fullPage, String status) {
        String safeName = name == null || name.isBlank() ? status : name + "-" + status;
        try {
            Path path = Paths.get("build", "artifacts", "screenshots", sanitize(safeName) + ".png");
            Files.createDirectories(path.getParent());
            PlaywrightSession.page().screenshot(new Page.ScreenshotOptions().setPath(path).setFullPage(fullPage));
            return path;
        } catch (Exception error) {
            throw new IllegalStateException("Unable to take screenshot", error);
        }
    }

    private static String sanitize(String value) {
        return (value == null ? "screenshot" : value).replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    public record ScreenSize(int width, int height) { }
}
