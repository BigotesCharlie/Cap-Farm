package com.farmers.framework.playwright;

@FunctionalInterface
public interface WaitCondition<T> {
    T await(double timeoutMillis);
}
