package com.farmers.framework.testng;

import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.testng.ISuite;
import org.testng.ISuiteListener;

/** Suite reporting hook; browser ownership is closed by the test-class lifecycle. */
public final class SuiteListener implements ISuiteListener {
    @Override
    public void onStart(ISuite suite) {
        Property.validateRuntimeConfiguration();
        Log.info("SUITE START - " + suite.getName()
                + " | environment=" + Property.ENVIRONMENT
                + " | baseUrl=" + Property.getUri()
                + " | browser=" + Property.browserName());
    }

    @Override
    public void onFinish(ISuite suite) {
        Log.info("SUITE COMPLETE - " + suite.getName());
    }
}
