package com.farmers.framework;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

/** Centralized, immutable configuration reader for the Playwright framework. */
public final class Property {
    public static final int PAGELOADTIMEOUT = 60;
    public static final String LOCAL = "local";

    private static final String QA_ENVIRONMENT = "test";
    private static final String UAT_ENVIRONMENT = "regression";
    private static final Map<String, String> REQUIRED_FASTQUOTE_URLS = Map.of(
            QA_ENVIRONMENT, "https://ffqautouiqa.farmers.com/fastquote/",
            UAT_ENVIRONMENT, "https://ffqautouiuat.farmers.com/fastquote/"
    );

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final Map<String, Object> ROOT = loadConfiguration();
    private static final Properties LOCAL_PROPERTIES = loadLocalProperties();

    public static final String FILTER = getTestProperty("filter", "all");
    public static final String ENVIRONMENT = getTestProperty("environment", UAT_ENVIRONMENT);

    private Property() {
    }

    public static String getTestProperty(String key) {
        return getTestProperty(key, "");
    }

    public static String getTestProperty(String key, String defaultValue) {
        String value = System.getProperty(key);
        if (value == null) {
            value = System.getProperty("ffq." + key);
        }
        if (value == null) {
            value = System.getenv(toEnvironmentName("FFQ", key));
        }
        if (value == null || value.isBlank()) {
            value = localProperty(key);
        }
        if (value == null || value.isBlank()) {
            Object configuredValue = map("test").get(key);
            value = configuredValue == null ? defaultValue : resolveSecretReference(String.valueOf(configuredValue));
        }

        String resolved = value == null ? defaultValue : value.trim();
        return "environment".equals(key) ? normalizeEnvironment(resolved) : resolved;
    }

    public static String requireTestProperty(String key) {
        String value = "syntheticAgentCookie".equals(key)
                ? getSyntheticAgentCookie()
                : getTestProperty(key, "");
        if (value.isBlank()) {
            throw new IllegalStateException("Required FFQ property is missing: " + key
                    + ". Configure it in the untracked ffq-local.properties file, as " + key
                    + ", ffq." + key + ", or environment variable " + toEnvironmentName("FFQ", key) + ".");
        }
        return value;
    }

    public static String getEnvironmentProperty(String key) {
        String environment = getTestProperty("environment", UAT_ENVIRONMENT);

        String value = System.getProperty(key);
        if (value == null) {
            value = System.getProperty("ffq." + key);
        }
        if (value == null) {
            value = System.getenv(toEnvironmentName("FFQ", environment, key));
        }
        if (value != null && !value.isBlank()) {
            return value.trim();
        }

        Object configuredValue = nestedMap("environment", environment).get(key);
        return resolveSecretReference(configuredValue == null ? "" : String.valueOf(configuredValue)).trim();
    }

    /**
     * Returns the only supported standard entry URL for the selected QA/UAT environment.
     * QA aliases resolve to {@code test}; UAT aliases resolve to {@code regression}.
     */
    public static String getUri() {
        String environment = getTestProperty("environment", UAT_ENVIRONMENT);
        String override = firstNonBlank(System.getProperty("baseUrl"), System.getenv("FFQ_BASE_URL"));
        String configured = override.isBlank() ? getEnvironmentProperty("uri") : override;

        String required = REQUIRED_FASTQUOTE_URLS.get(environment);
        if (required != null) {
            if (!sameUrl(configured, required)) {
                throw new IllegalStateException("Invalid FastQuote URL for environment '" + environment
                        + "'. Expected " + required + " but resolved " + configured
                        + ". Remove stale baseUrl/FFQ_BASE_URL overrides and verify ffq-local.properties.");
            }
            return required;
        }

        if (configured.isBlank()) {
            throw new IllegalStateException("No FastQuote uri is configured for environment '" + environment + "'.");
        }
        rejectCssTv(configured);
        return configured;
    }

    /** Builds an environment-specific deep link on the selected FastQuote host. */
    public static String getEnvironmentUrl(String pathAndQuery) {
        URI base = URI.create(getUri());
        String suffix = pathAndQuery == null ? "" : pathAndQuery.trim();
        if (!suffix.startsWith("/")) {
            suffix = "/" + suffix;
        }
        return base.getScheme() + "://" + base.getHost() + suffix;
    }

    /** Replaces any accidental CSSTV entry with the configured FastQuote entry URL. */
    public static String ensureFastQuoteEntry(String candidate) {
        if (candidate == null || candidate.isBlank()) {
            return getUri();
        }
        if (isCssTvUrl(candidate)) {
            return getUri();
        }
        return candidate.trim();
    }

    public static boolean isCssTvUrl(String candidate) {
        if (candidate == null || candidate.isBlank()) {
            return false;
        }
        try {
            String host = URI.create(candidate.trim()).getHost();
            return host != null && host.toLowerCase(Locale.ROOT).startsWith("csstv.");
        } catch (IllegalArgumentException ignored) {
            return candidate.toLowerCase(Locale.ROOT).contains("csstv.farmers.com");
        }
    }

    /** Optional credential. Direct FastQuote navigation must not fail only because it is absent. */
    public static String getSyntheticAgentCookie() {
        String value = firstNonBlank(
                System.getProperty("syntheticAgentCookie"),
                System.getProperty("ffq.syntheticAgentCookie"),
                System.getenv("FFQ_SYNTHETICAGENTCOOKIE"),
                System.getenv("FFQ_SYNTHETIC_AGENT_COOKIE"),
                localProperty("syntheticAgentCookie"),
                configuredTestProperty("syntheticAgentCookie")
        );
        return value.trim();
    }

    public static void validateRuntimeConfiguration() {
        getUri();
    }

    public static String browserName() {
        return normalizeBrowser(getTestProperty("browser", "chromium"));
    }

    public static String getBrowser() {
        return browserName();
    }

    public static boolean isMacPlatform() {
        String configured = getTestProperty("platform", "");
        String platform = configured.isBlank() ? System.getProperty("os.name", "") : configured;
        return platform.toLowerCase(Locale.ROOT).contains("mac");
    }

    public static String getRemote() {
        return getTestProperty("remote", LOCAL);
    }

    public static String getReportProperties(String key) {
        Object value = map("report").get(key);
        return value == null ? "" : resolveSecretReference(String.valueOf(value));
    }

    public static double timeoutMillis() {
        return parseSeconds(getTestProperty("timeout", "30"), 30) * 1_000d;
    }

    public static double pageLoadTimeoutMillis() {
        return parseSeconds(
                getTestProperty("pageloadtimeout", String.valueOf(PAGELOADTIMEOUT)),
                PAGELOADTIMEOUT) * 1_000d;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> map(String key) {
        Object value = ROOT.get(key);
        return value instanceof Map<?, ?> ? (Map<String, Object>) value : Collections.emptyMap();
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> nestedMap(String first, String second) {
        Object value = map(first).get(second);
        return value instanceof Map<?, ?> ? (Map<String, Object>) value : Collections.emptyMap();
    }

    private static Map<String, Object> loadConfiguration() {
        String pathValue = System.getProperty("ffq.config", "properties.json");
        Path path = locateConfigurationFile(pathValue);
        try {
            if (path != null) {
                return MAPPER.readValue(path.toFile(), new TypeReference<>() { });
            }
            try (InputStream input = Property.class.getClassLoader().getResourceAsStream(pathValue)) {
                if (input != null) {
                    return MAPPER.readValue(input, new TypeReference<>() { });
                }
            }
        } catch (IOException error) {
            throw new IllegalStateException("Unable to load FFQ configuration from " + pathValue, error);
        }
        return Collections.emptyMap();
    }

    private static Properties loadLocalProperties() {
        Properties properties = new Properties();
        String pathValue = System.getProperty("ffq.local.config", "ffq-local.properties");
        Path path = locateConfigurationFile(pathValue);
        if (path == null) {
            return properties;
        }
        try (InputStream input = Files.newInputStream(path)) {
            properties.load(input);
            return properties;
        } catch (IOException error) {
            throw new IllegalStateException("Unable to load local FFQ configuration from " + pathValue, error);
        }
    }

    private static Path locateConfigurationFile(String pathValue) {
        Path requested = Paths.get(pathValue);
        if (requested.isAbsolute()) {
            return Files.exists(requested) ? requested : null;
        }

        Path current = Paths.get(System.getProperty("user.dir", ".")).toAbsolutePath().normalize();
        for (int level = 0; level < 6 && current != null; level++) {
            Path candidate = current.resolve(requested).normalize();
            if (Files.exists(candidate)) {
                return candidate;
            }
            current = current.getParent();
        }
        return null;
    }

    private static String localProperty(String key) {
        String value = LOCAL_PROPERTIES.getProperty(key);
        if (value == null || value.isBlank()) {
            value = LOCAL_PROPERTIES.getProperty("ffq." + key, "");
        }
        return resolveSecretReference(value == null ? "" : value.trim());
    }

    private static int parseSeconds(String value, int fallback) {
        try {
            int parsed = Integer.parseInt(value);
            return parsed <= 0 ? fallback : parsed;
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private static String normalizeBrowser(String browser) {
        String value = browser == null ? "chromium" : browser.trim().toLowerCase(Locale.ROOT);
        return switch (value) {
            case "chrome", "googlechrome" -> "chrome";
            case "edge", "msedge" -> "edge";
            case "firefox" -> "firefox";
            case "webkit", "safari" -> "webkit";
            default -> "chromium";
        };
    }

    private static String normalizeEnvironment(String environment) {
        String value = environment == null ? UAT_ENVIRONMENT : environment.trim().toLowerCase(Locale.ROOT);
        return switch (value) {
            case "qa" -> QA_ENVIRONMENT;
            case "uat" -> UAT_ENVIRONMENT;
            default -> value;
        };
    }

    private static String resolveSecretReference(String value) {
        if (value == null) {
            return "";
        }
        if (value.startsWith("${") && value.endsWith("}")) {
            String name = value.substring(2, value.length() - 1);
            return System.getenv().getOrDefault(name, "");
        }
        return value;
    }

    private static String configuredTestProperty(String key) {
        Object configuredValue = map("test").get(key);
        return configuredValue == null ? "" : resolveSecretReference(String.valueOf(configuredValue));
    }

    private static String firstNonBlank(String... values) {
        if (values == null) {
            return "";
        }
        for (String value : values) {
            if (value != null && !value.isBlank()) {
                return value.trim();
            }
        }
        return "";
    }

    private static boolean sameUrl(String first, String second) {
        return canonicalUrl(first).equalsIgnoreCase(canonicalUrl(second));
    }

    private static String canonicalUrl(String value) {
        if (value == null) {
            return "";
        }
        String normalized = value.trim();
        while (normalized.endsWith("/")) {
            normalized = normalized.substring(0, normalized.length() - 1);
        }
        return normalized;
    }

    private static void rejectCssTv(String value) {
        if (isCssTvUrl(value)) {
            throw new IllegalStateException("CSSTV is not a valid entry point for the extracted Home/Auto suites: " + value);
        }
    }

    private static String toEnvironmentName(String... parts) {
        return String.join("_", parts)
                .replaceAll("[^A-Za-z0-9]", "_")
                .toUpperCase(Locale.ROOT);
    }
}
