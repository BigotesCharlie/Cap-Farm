package com.farmers.framework.playwright;

import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import com.microsoft.playwright.*;
import com.microsoft.playwright.options.ViewportSize;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Thread-confined Playwright runtime. Playwright objects are not shared across
 * threads. A browser is reused by the current TestNG worker thread, while every
 * test method receives a new isolated BrowserContext and Page.
 */
public final class PlaywrightSession {
    private static final ThreadLocal<RuntimeState> THREAD_STATE = new ThreadLocal<>();
    private static final Map<Long, RuntimeState> ALL_STATES = new ConcurrentHashMap<>();

    private PlaywrightSession() {
    }

    public static void startTest(String testName) {
        RuntimeState state = ensureRuntime();
        closeContext(state, false, testName);

        Browser.NewContextOptions options = new Browser.NewContextOptions()
                .setIgnoreHTTPSErrors(Boolean.parseBoolean(Property.getTestProperty("ignoreHTTPSErrors", "true")))
                .setViewportSize(viewportWidth(), viewportHeight());

        if (Boolean.parseBoolean(Property.getTestProperty("video", "false"))) {
            Path videoDir = artifactPath("videos", sanitize(testName));
            createDirectories(videoDir);
            options.setRecordVideoDir(videoDir);
        }

        state.context = state.browser.newContext(options);
        state.context.setDefaultTimeout(Property.timeoutMillis());
        state.context.setDefaultNavigationTimeout(Property.pageLoadTimeoutMillis());

        if (Boolean.parseBoolean(Property.getTestProperty("trace", "false"))) {
            state.context.tracing().start(new Tracing.StartOptions()
                    .setScreenshots(true)
                    .setSnapshots(true)
                    .setSources(true));
            state.tracing = true;
        }

        state.page = state.context.newPage();
        state.frame = null;
        state.testName = testName;
        AutoDebugManager.startTest(testName, state.page);
    }

    public static void endTest(boolean failed, String testName) {
        RuntimeState state = THREAD_STATE.get();
        if (state == null) {
            return;
        }
        AutoDebugManager.finishTest(failed);
        closeContext(state, failed, testName);
    }

    public static Playwright playwright() {
        return ensureRuntime().playwright;
    }

    public static Browser browser() {
        return ensureRuntime().browser;
    }

    public static BrowserContext context() {
        RuntimeState state = requireState();
        if (state.context == null) {
            throw new IllegalStateException("No BrowserContext is active. Test lifecycle setup did not run.");
        }
        return state.context;
    }

    public static boolean hasActivePage() {
        RuntimeState state = THREAD_STATE.get();
        return state != null && state.page != null && !state.page.isClosed();
    }

    public static Page page() {
        RuntimeState state = requireState();
        if (state.page == null) {
            throw new IllegalStateException("No Page is active. Test lifecycle setup did not run.");
        }
        return state.page;
    }

    public static void setPage(Page page) {
        RuntimeState state = requireState();
        state.page = page;
        state.frame = null;
        AutoDebugManager.attach(page);
        AutoDebugManager.checkpoint("page-switch", true);
    }

    public static Frame frame() {
        return requireState().frame;
    }

    public static void setFrame(Frame frame) {
        requireState().frame = frame;
    }

    public static Locator resolveLocator(String selector) {
        Frame frame = frame();
        return frame == null ? page().locator(selector) : frame.locator(selector);
    }

    public static Locator resolveAny(String... selectors) {
        if (selectors == null || selectors.length == 0) {
            throw new IllegalArgumentException("At least one selector is required");
        }
        Locator combined = resolveLocator(selectors[0]);
        for (int i = 1; i < selectors.length; i++) {
            combined = combined.or(resolveLocator(selectors[i]));
        }
        return combined;
    }

    public static List<Page> pages() {
        return context().pages();
    }

    public static void clearCookies() {
        context().clearCookies();
    }

    public static void setViewportSize(int width, int height) {
        page().setViewportSize(width, height);
    }

    public static ViewportSize viewportSize() {
        ViewportSize size = page().viewportSize();
        return size == null ? new ViewportSize(viewportWidth(), viewportHeight()) : size;
    }
    public static void shutdownCurrentThread() {
        RuntimeState state = THREAD_STATE.get();
        if (state == null) {
            return;
        }
        closeRuntime(state);
        ALL_STATES.remove(Thread.currentThread().getId());
        THREAD_STATE.remove();
    }

    /**
     * Suite-level safety hook. Playwright objects are thread-confined, so this
     * method closes only the state owned by the calling TestNG worker.
     */
    public static void shutdownAll() {
        shutdownCurrentThread();
    }

    private static RuntimeState ensureRuntime() {
        RuntimeState state = THREAD_STATE.get();
        if (state != null && state.browser != null && state.browser.isConnected()) {
            return state;
        }

        state = new RuntimeState();
        state.playwright = Playwright.create();
        BrowserType browserType = selectBrowserType(state.playwright);
        BrowserType.LaunchOptions options = new BrowserType.LaunchOptions()
                .setHeadless(Boolean.parseBoolean(Property.getTestProperty("headless", "false")))
                .setTimeout(Property.pageLoadTimeoutMillis());

        String browserName = Property.browserName().toLowerCase();
        if (browserName.equals("chrome") || browserName.equals("googlechrome")) {
            options.setChannel("chrome");
        } else if (browserName.equals("edge") || browserName.equals("msedge")) {
            options.setChannel("msedge");
        }

        state.browser = browserType.launch(options);
        THREAD_STATE.set(state);
        ALL_STATES.put(Thread.currentThread().getId(), state);
        return state;
    }

    private static BrowserType selectBrowserType(Playwright playwright) {
        return switch (Property.browserName().toLowerCase()) {
            case "firefox" -> playwright.firefox();
            case "webkit", "safari" -> playwright.webkit();
            default -> playwright.chromium();
        };
    }

    private static RuntimeState requireState() {
        RuntimeState state = THREAD_STATE.get();
        if (state == null) {
            state = ensureRuntime();
        }
        return state;
    }

    private static void closeContext(RuntimeState state, boolean failed, String requestedName) {
        if (state.context == null) {
            return;
        }
        String name = sanitize(requestedName == null || requestedName.isBlank() ? state.testName : requestedName);
        try {
            if (failed && state.page != null && !state.page.isClosed()) {
                Path screenshot = artifactPath("screenshots", name + ".png");
                createDirectories(screenshot.getParent());
                state.page.screenshot(new Page.ScreenshotOptions()
                        .setPath(screenshot)
                        .setFullPage(true));
            }
        } catch (RuntimeException error) {
            Log.warn("Unable to capture failure screenshot: " + error.getMessage());
        }

        try {
            if (state.tracing) {
                Path trace = artifactPath("traces", name + ".zip");
                createDirectories(trace.getParent());
                state.context.tracing().stop(new Tracing.StopOptions().setPath(trace));
            }
        } catch (RuntimeException error) {
            Log.warn("Unable to save Playwright trace: " + error.getMessage());
        }

        try {
            state.context.close();
        } catch (RuntimeException error) {
            Log.warn("Unable to close BrowserContext: " + error.getMessage());
        } finally {
            state.context = null;
            state.page = null;
            state.frame = null;
            state.tracing = false;
        }
    }

    private static void closeRuntime(RuntimeState state) {
        if (state == null) {
            return;
        }
        closeContext(state, false, state.testName);
        try {
            if (state.browser != null) {
                state.browser.close();
            }
        } catch (RuntimeException ignored) {
        }
        try {
            if (state.playwright != null) {
                state.playwright.close();
            }
        } catch (RuntimeException ignored) {
        }
    }

    private static int viewportWidth() {
        if (Boolean.parseBoolean(Property.getTestProperty("useMobileView", "false"))) {
            return Integer.parseInt(Property.getTestProperty("mobileViewportWidth", "390"));
        }
        return Integer.parseInt(Property.getTestProperty("viewportWidth", "1600"));
    }

    private static int viewportHeight() {
        if (Boolean.parseBoolean(Property.getTestProperty("useMobileView", "false"))) {
            return Integer.parseInt(Property.getTestProperty("mobileViewportHeight", "844"));
        }
        return Integer.parseInt(Property.getTestProperty("viewportHeight", "1200"));
    }

    private static Path artifactPath(String type, String name) {
        return Paths.get("build", "artifacts", type, name);
    }

    private static void createDirectories(Path directory) {
        try {
            Files.createDirectories(directory);
        } catch (Exception error) {
            throw new IllegalStateException("Unable to create artifact directory " + directory, error);
        }
    }

    private static String sanitize(String value) {
        String safe = value == null ? "test" : value.replaceAll("[^a-zA-Z0-9._-]", "_");
        return safe.length() > 180 ? safe.substring(0, 180) : safe;
    }

    private static final class RuntimeState {
        private Playwright playwright;
        private Browser browser;
        private BrowserContext context;
        private Page page;
        private Frame frame;
        private boolean tracing;
        private String testName = "test";
    }
}
