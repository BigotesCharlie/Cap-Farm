package com.farmers.framework.testng;

import com.farmers.framework.report.Log;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestResult;

public final class MethodListener implements IInvokedMethodListener {
    @Override
    public void beforeInvocation(IInvokedMethod method, ITestResult result) {
        if (method.isTestMethod()) {
            Log.info("START - " + result.getTestClass().getName() + "." + result.getMethod().getMethodName());
        }
    }

    @Override
    public void afterInvocation(IInvokedMethod method, ITestResult result) {
        if (method.isTestMethod()) {
            Log.info("END - " + result.getTestClass().getName() + "." + result.getMethod().getMethodName());
        }
    }
}
