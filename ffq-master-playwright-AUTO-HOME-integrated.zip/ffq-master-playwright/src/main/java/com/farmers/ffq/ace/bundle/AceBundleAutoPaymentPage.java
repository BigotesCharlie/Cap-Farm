package com.farmers.ffq.ace.bundle;





import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;

import static com.farmers.ffq.utils.GlobalVariables.MASTER_CARD;
import static com.farmers.ffq.utils.GlobalVariables.SRC;

import java.util.List;

public class AceBundleAutoPaymentPage extends BasePage {

    //Common elements

        private Locator autoPaymentPageTitle = locator(pwXPath("//h1[contains(@class, 'payment-overview-header-text')]"));

    //Farmers Elements
        private Locator bankPreferedPaymentRadioButton = locator(pwXPath("//input[@value='bank']"));
        private Locator cardPreferedPaymentRadioButton = locator(pwXPath("//input[@value='card']"));
        private Locator completeAutoPurchaseButton = locator(pwXPath("//button[contains(@class, '-purchase-btn-bundle')]"));

    //BW Elements
        private Locator autoPaymentPageBWIcon = locator(pwXPath("//div[contains(@class, 'bristol-west-bundle-icon')]//img"));
        private Locator autoPaymentPageBWLabel = locator(pwXPath("//div[contains(@class, 'bristol-west-bundle-body')]"));
        private Locator listOfTabsForAvailablePaymentPlans = locator(pwXPath("//div[contains(@class, 'mat-tab-label')][@role='tab']"));
        private Locator selectAndSignDocumentsPayInFullButton = locator(pwXPath("//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Pay in full')]"));
        private Locator selectAndSignDocumentsMonthlyBankButton = locator(pwXPath("//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly autopay bank')]"));
        private Locator selectAndSignDocumentsMonthlyCardButton = locator(pwXPath("//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly autopay card')]"));
        private Locator selectAndSignDocumentsMonthlyDirectButton = locator(pwXPath("//div[contains(@class,'presentment-card-header')][not(ancestor::mat-tab-body)]//button[contains(@aria-label, 'Monthly direct')]"));
        private Locator activeSelectAndSignDocumentsButton = locator(pwXPath("//mat-tab-body//button"));
        private Locator bwSetupPaymentButton = locator(pwXPath("//button[contains(@class, 'tui-btn')]"));

    //ERSD Consent Dialog
        private Locator ersdDialog = locator(pwXPath("//div[@data-qa='ersd-modal-content']"));
        private Locator agreeToUseERSDCheckbox = locator(pwXPath("//input[@data-qa='ersd-agree-checkbox']"));
        private Locator ersdDialogContinueButton = locator(pwXPath("//button[@data-qa='ersd-modal-agree']"));

    //Docusign elements
        private Locator docusignDocument = locator(pwXPath("//*[contains(@class, 'signing-v3')]"));
        private Locator listOfInitialHereLocations = locator(pwXPath("//button[contains(@data-qa,'initials-tab-required') and @aria-invalid='true']"));
        private Locator listOfSignHereLocations = locator(pwXPath("//button[contains(@data-qa,'signature-tab-required') and @aria-invalid='true']"));
        private Locator adoptSignatureDialog = locator(pwXPath("//div[@data-qa='adopt-signature-modal-content']"));
        private Locator adoptAndInitialButton = locator(pwXPath("//button[@data-qa='adopt-submit']"));
        private Locator finishDocusignButton = locator(pwXPath("//button[contains(@data-qa,'action-bar-btn-finish')]"));

    public AceBundleAutoPaymentPage() throws Exception {
    }

    public boolean isOnAceBundleAutoPaymentPage() {
	return isElementDisplayed(autoPaymentPageTitle, 4);
    }

    public void verifyAceBundleAutoPaymentPageContent(FarmersSoftAssert fsa) throws Exception {
	fsa.assertTrue(getListOfSteps().isEmpty(), "Stepper is not available on auto payment page");
	fsa.assertEquals(getTextFromElement(autoPaymentPageTitle), "First up: Pay for auto", "AceBundleAutoPaymentPage title verification");
	if (isElementDisplayed(autoPaymentPageBWIcon, 1)) {
	    fsa.assertTrue(getAttributeData(autoPaymentPageBWIcon, SRC).contains("bristol-west"), "AceBundleAutoPaymentPage using BW logo");
	    fsa.assertEquals(getTextFromElement(autoPaymentPageBWLabel), "Auto policy insured and serviced by Bristol West, a Farmers company", "AceBundleAutoPaymentPage BW label verification");
	}
    }

    public void fillOutAutoPaymentPageAndContinue(AutoApplicant autoApplicant) throws Exception {
	boolean isBristolWest = isElementDisplayed(autoPaymentPageBWIcon, 1);
	if (isBristolWest) {
	    clickElement(activeSelectAndSignDocumentsButton);
	    waitElementBeVisible(ersdDialog);
	    waitAndClickElement(agreeToUseERSDCheckbox);
	    waitAndClickElement(ersdDialogContinueButton);
	    waitElementBeInvisible(ersdDialog);
	    waitElementBeVisible(docusignDocument);
	    boolean firstTime = true;
	    for (Locator initialHere : listOfInitialHereLocations.all()) {
		scrollToElement(initialHere);
		waitAndClickElement(initialHere);
		if (firstTime) {
		    waitElementBeVisible(adoptSignatureDialog);
		    waitAndClickElement(adoptAndInitialButton);
		    waitElementBeInvisible(adoptSignatureDialog);
		    firstTime = false;
		}
	    }
	    for (Locator signHere : listOfSignHereLocations.all()) {
		scrollToElement(signHere);
		waitAndClickElement(signHere);
	    }
	    // Sometimes some of the clicks fail :(
	    for (Locator initialHere : listOfInitialHereLocations.all()) {
		scrollToElement(initialHere);
		waitAndClickElement(initialHere);
	    }
	    waitAndClickElement(finishDocusignButton);
	    waitElementBeInvisible(docusignDocument);
	    waitAndClickElement(bwSetupPaymentButton);
	} else {
	    scrollAndClickOnElement(cardPreferedPaymentRadioButton);
	}
	AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
	aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
	scrollAndClickOnElement(completeAutoPurchaseButton);
	waitForSpinnerToBeGone();
	if (isElementDisplayed(completeAutoPurchaseButton, 1)) {
	    scrollAndClickOnElement(completeAutoPurchaseButton);
	    waitForSpinnerToBeGone();
	}
    }
}
