package com.farmers.ffq.common.enums;

import com.farmers.ffq.ace.hrc.common.AceHRCBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.GlobalVariables;

import lombok.Getter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter
public enum FfqBundleOptions {

    AUTO("Auto"),
    HOME("Home"),
    CONDO("Condo"),
    RENTERS("Renters"),
    LIFE("Life"),
    UMBRELLA("Umbrella"),
    MULTIPOLICY_CEA("Multi-policy Discount - CEA"),
    BUSINESS("Business"),
    RECREATIONAL("Recreational Boat/Watercraft"),
    OFF_ROAD_VEHICLE("Off-Road Vehicle"),
    MOBILE_HOME("Mobile home"),
    MOTOR_HOME("Motorhome, Travel Trailer or 5th Wheel"),
    MOTOR_CYCLE("Motorcycle");

    private String bundleLob;

    FfqBundleOptions(String bundleLob) {
        this.bundleLob = bundleLob;
    }

    public static List<String> getBundleOptions(AutoApplicant applicant, boolean isHomeowner) {
        List<String> bundleItems;
        if (isHomeowner) {
            bundleItems = new ArrayList<>(Arrays.asList(HOME.getBundleLob(), CONDO.getBundleLob(), LIFE.getBundleLob(), UMBRELLA.getBundleLob(), BUSINESS.getBundleLob(), RECREATIONAL.getBundleLob(), OFF_ROAD_VEHICLE.getBundleLob(), MOBILE_HOME.getBundleLob(), MOTOR_HOME.getBundleLob(), MOTOR_CYCLE.getBundleLob()));
        } else {
            bundleItems = new ArrayList<>(Arrays.asList(RENTERS.getBundleLob(), LIFE.getBundleLob(), UMBRELLA.getBundleLob(), BUSINESS.getBundleLob(), RECREATIONAL.getBundleLob(), OFF_ROAD_VEHICLE.getBundleLob(), MOTOR_HOME.getBundleLob(), MOTOR_CYCLE.getBundleLob()));
        }
        String stateCode = applicant.getStateCode();
        if(stateCode.equals(MA)) {
           bundleItems.removeIf(each -> Arrays.asList(BUSINESS.getBundleLob(), UMBRELLA.getBundleLob(), MOTOR_CYCLE.getBundleLob(), MOTOR_HOME.getBundleLob()).contains(each));
        }
        if(Arrays.asList(LA, KY, NC).contains(stateCode)) {
            bundleItems.removeIf(each -> Arrays.asList(BUSINESS.getBundleLob(), UMBRELLA.getBundleLob()).contains(each));
        }
        if(applicant.getAge() > 65 || applicant.getStateCode().equals(CT)) {
            bundleItems.remove(FfqBundleOptions.LIFE.getBundleLob());
        }
        return bundleItems;
    }

    public static List<String> getBundleOptionsForAceHome(ApplicantAceHome applicant, String homeLobType) throws Exception {
        List<String> bundleItems;
        String stateCode = applicant.getStateCode();
        AceHRCBasePage aceHRCBasePage = new AceHRCBasePage();
        boolean isEasternExpansionState = Arrays.asList(KY, LA, MA, MS, NC).contains(stateCode);
        boolean isHomeLOB = homeLobType.equals(FfqBundleOptions.HOME.bundleLob);
        if (homeLobType.equals(GlobalVariables.MOBILE_HOME)) {
        	if (List.of(CT, NY).contains(stateCode)) {
        		bundleItems = new ArrayList<>(Arrays.asList(AUTO.getBundleLob(), UMBRELLA.getBundleLob()));
        	} else {
        		bundleItems = new ArrayList<>(Arrays.asList(AUTO.getBundleLob(), LIFE.getBundleLob(), UMBRELLA.getBundleLob()));
        	}
        } else {
        	if (isHomeLOB && !(isEasternExpansionState || stateCode.equals(KS)) && !aceHRCBasePage.isAdditionalHomeBundleDiscountsState(stateCode)) {
        		bundleItems = new ArrayList<>(Arrays.asList(AUTO.getBundleLob(), LIFE.getBundleLob(), UMBRELLA.getBundleLob()));
        		if (stateCode.equals(CA)) {
        			bundleItems = new ArrayList<>(Arrays.asList(AUTO.getBundleLob(), UMBRELLA.getBundleLob(), MULTIPOLICY_CEA.getBundleLob()));
        		}
        	} else {
        		bundleItems = new ArrayList<>(Arrays.asList(AUTO.getBundleLob(), LIFE.getBundleLob(), UMBRELLA.getBundleLob(), BUSINESS.getBundleLob(), RECREATIONAL.getBundleLob(), OFF_ROAD_VEHICLE.getBundleLob(), MOTOR_HOME.getBundleLob()));
        	}
        	if (isEasternExpansionState) {
        		bundleItems.remove(UMBRELLA.getBundleLob());
        	}
        }
        return bundleItems;
    }


}
