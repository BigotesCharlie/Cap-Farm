package com.farmers.ffq.ace.hrc.common;



import com.farmers.framework.playwright.Keys;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import java.time.LocalDate;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCPropertyBasePage extends AceHRCBasePage {
    private static final String PAGE_TITLE = "Tell us more about your home";

        private Locator pageTitle = locator(pwXPath("//app-yearbuilt-area//h1"));

        private Locator propertyAddressLine1 = locator(pwXPath("//app-yearbuilt-area//h2"));

        private Locator propertyAddressLine2 = locator(pwXPath("//app-yearbuilt-area//div[contains(@class,'home-yearbuilt-area-address-holder')]"));

    private static final String YEAR_BUILT_XPATH = "//app-yearbuilt-area//tui-typeahead[@id='yearBuilt']";
        private Locator yearBuiltFormField = locator(pwXPath(YEAR_BUILT_XPATH + "//mat-form-field"));

        private Locator yearBuiltInput = locator(pwXPath(YEAR_BUILT_XPATH + "//input"));

        private Locator totalSqFtFormField = locator(pwXPath("//app-yearbuilt-area//input[@id='sqFeet']/ancestor::mat-form-field"));

        private Locator totalSqFtInput = locator(pwXPath("//app-yearbuilt-area//mat-form-field//input[@id='sqFeet']"));

    /**
     * Default Constructor
     */
    public AceHRCPropertyBasePage() throws Exception {
    }

    public boolean isOnHRCPropertyBasePage(boolean longWait) {
        int timeout = longWait ? Property.PAGELOADTIMEOUT : 2;
        return isElementVisible(yearBuiltInput, timeout);
    }

    public boolean isPageTitleDisplayed() {
        return getTextFromElement(pageTitle).equals(PAGE_TITLE);
    }

    public boolean isPageTitleInViewport() throws Exception {
        return isElementInViewport(pageTitle);
    }

    public String getPropertyAddress() {
        return getTextFromElement(propertyAddressLine1) + COMMA + SPACE + getTextFromElement(propertyAddressLine2);
    }

    public String getPropertyYearBuiltFieldValue() {
        return getValueFromLocator(yearBuiltInput);
    }

    public void setYearBuiltFieldValue(String yearBuilt) {
        waitAndClickElement(yearBuiltInput);
        sendKeysToElement(yearBuiltInput, yearBuilt);
    }

    public String getPropertyTotalSqFtFieldValue() {
        return getValueFromLocator(totalSqFtInput);
    }

    public void setTotalSqFtFieldValue(String totalSqFt) {
        waitAndClickElement(totalSqFtInput);
        sendKeysToElement(totalSqFtInput, totalSqFt);
    }

    public void enterPropertyPageFields(ApplicantAceHome applicant) {
        setYearBuiltFieldValue(String.valueOf(applicant.getYearBuilt()));
        setTotalSqFtFieldValue(applicant.getSquareFeet());
    }

    public void validatePageErrors(FarmersSoftAssert sa, ApplicantAceHome applicant) throws Exception {
        final String PROPERTY_ENTER_YEAR_BUILT_ERROR = "Please enter the year your house was built.";
        final String PROPERTY_ENTER_YEAR_BUILT_1600_ERROR = "Please enter a year after 1600.";
        final String PROPERTY_ENTER_YEAR_BUILT_FUTURE_ERROR = "Quotes not available for homes under construction.";
        final String PROPERTY_ENTER_SQUARE_FEET_ERROR = "Please enter valid square feet.";
        final String PROPERTY_ENTER_SQUARE_FEET_100_ERROR = "Square footage must be at least 100 square feet";
        setYearBuiltFieldValue(" " + Keys.TAB);
        setTotalSqFtFieldValue(" " + Keys.TAB);
        clickOnHiddenElement(buttonContinue);
        waitForUiSettled();
        sa.assertTrue(getPageErrors().contains(PROPERTY_ENTER_YEAR_BUILT_ERROR), "Property page - " + PROPERTY_ENTER_YEAR_BUILT_ERROR + " - error found.");
        sa.assertTrue(getPageErrors().contains(PROPERTY_ENTER_SQUARE_FEET_ERROR), "Property page - " + PROPERTY_ENTER_SQUARE_FEET_ERROR + " - error found.");
        sa.assertTrue(isAttributePresent(buttonContinue, DISABLED), "Property page - Continue button is disabled, while there are error(s) #1.");

        setYearBuiltFieldValue("1599" + Keys.TAB);
        setTotalSqFtFieldValue("99" + Keys.TAB);
        waitForUiSettled();
        sa.assertTrue(getPageErrors().contains(PROPERTY_ENTER_YEAR_BUILT_1600_ERROR), "Property page - " + PROPERTY_ENTER_YEAR_BUILT_1600_ERROR + " - error found.");
        sa.assertTrue(getPageErrors().contains(PROPERTY_ENTER_SQUARE_FEET_100_ERROR), "Property page - " + PROPERTY_ENTER_SQUARE_FEET_100_ERROR + " - error found.");
        sa.assertTrue(isAttributePresent(buttonContinue, DISABLED), "Property page - Continue button is disabled, while there are error(s) #2.");

        setYearBuiltFieldValue(String.valueOf(LocalDate.now().plusYears(1).getYear()) + Keys.TAB);
        waitForUiSettled();
        sa.assertTrue(getPageErrors().contains(PROPERTY_ENTER_YEAR_BUILT_FUTURE_ERROR), "Property page - " + PROPERTY_ENTER_YEAR_BUILT_FUTURE_ERROR + " - error found.");
        sa.assertTrue(isAttributePresent(buttonContinue, DISABLED), "Property page - Continue button is disabled, while there are error(s) #3.");
    }

    public void validatePageFormFields(FarmersSoftAssert sa) {
        final String PROPERTY_YEAR_BUILT_LABEL = "Year Built";
        final String PROPERTY_SQUARE_FEET_LABEL = "Total sq. ft.";
        sa.assertEquals(getTextFromElement(yearBuiltFormField), PROPERTY_YEAR_BUILT_LABEL, "Property page - Year built form field label.");
        sa.assertEquals(getTextFromElement(totalSqFtFormField), PROPERTY_SQUARE_FEET_LABEL, "Property page - Total sq. ft. form field label.");
    }

    public void validateADA(String lobType) throws InterruptedException {
        setYearBuiltFieldValue("2100");
        setTotalSqFtFieldValue("99");
        performADATesting(this.getClass().getSimpleName(),MARKETING_IT,lobType);
    }
}
