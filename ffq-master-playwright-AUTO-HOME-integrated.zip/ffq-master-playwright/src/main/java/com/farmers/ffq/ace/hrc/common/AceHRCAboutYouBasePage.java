package com.farmers.ffq.ace.hrc.common;


import com.farmers.framework.playwright.Keys;
import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Home.Field;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.ffqace.AceHomeSupportedOccupationByState;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import lombok.SneakyThrows;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.farmers.ffq.common.pages.FfqAceBasePage.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCAboutYouBasePage extends AceHRCBasePage {

    private static final String DATE_OF_BIRTH_IS_NOT_A_VALID_ENTRY = "Date of birth is not a valid entry.";
    private static final String INVALID_DATE_OF_BIRTH = "Invalid date of birth";
    private static final String INVALID_SPOUSE_DATE_OF_BIRTH = "Invalid spouse's date of birth";
    private static final String LOG_MESSAGE_TEMPLATE = "Entering ";
    protected static final String ABOUT_YOU_HEADER = "About you";

    private static final String GENDER_SELECTION_XPATH = "//label[@id='formField_label_gender']/..//mat-button-toggle";
        Locator genderButtons = locator(pwXPath(GENDER_SELECTION_XPATH));
        Locator genderButton = locator(pwXPath(GENDER_SELECTION_XPATH));

    private static final String SPOUSE_GENDER_SELECTION_XPATH = "//label[@id='formField_label_spouseGender']/..//mat-button-toggle";
        Locator spouseGenderButtons = locator(pwXPath(SPOUSE_GENDER_SELECTION_XPATH));

        protected Locator aboutYouHeader = locator(pwXPath("//h1[contains(text(), '" + ABOUT_YOU_HEADER + "')]"));

    protected static final String LETS_GET_TO_KNOW_EACH_OTHER = "Let's get to know each other.";
    	protected Locator letsGetToKnowEachOtherSubHeader = locator(pwXPath("//div[@id='home-about-you_name_dob-subheading']"));

    private static final String FIRST_NAME = "First name";
        protected Locator firstNameInputBox = locator(pwXPath("//input[@aria-label='" + FIRST_NAME + "']"));

        private Locator firstNameAriaLabelText = locator(pwXPath("//mat-label[contains(text(), '" + FIRST_NAME + "')]"));

    private static final String LAST_NAME = "Last name";
    	protected Locator lastNameInputBox = locator(pwXPath("//input[@aria-label='" + LAST_NAME + "']"));
        private Locator lastNameAriaLabelText = locator(pwXPath("//mat-label[contains(text(), '" + LAST_NAME + "')]"));

    private static final String DATE_OF_BIRTH_ARIA_LABEL = "Date of birth";
    private static final String ADDRESS = "address";
    private static final String CITY = "city";
    private static final String STATE = "state";
    private static final String ZIP_CODE = "ZIP code";
    private static final String DATE_OF_BIRTH_ARIA_LABEL_INPUT_BOX = "Date of birth in the format of mmddyyyy.";
        protected Locator dateOfBirthInputBox = locator(pwXPath("//input[@aria-label='" + DATE_OF_BIRTH_ARIA_LABEL_INPUT_BOX + "']"));
        private Locator dateOfBirthAriaLabelText = locator(pwXPath("//mat-label[contains(text(), '" + DATE_OF_BIRTH_ARIA_LABEL + "')]"));
        private Locator mmddyyyyHint = locator(pwXPath("//mat-hint[contains(text(), 'mm/dd/yyyy')]"));
        private Locator spouseInputFieldSection = locator(pwXPath("//div[@id='spouseDetailsDiv']//div[contains(@class,'home-about-you__input-fields')]"));

        private Locator spouseElements = locator(pwXPath("//div[@id='spouseDetailsDiv']//mat-form-field//input"));
    private static final String SPOUSE_FIRST_NAME = "Spouse's First name";
        private Locator spouseFirstNameInputBox = locator(pwXPath("//input[@aria-label=\"Spouse's First name\"]"));

    private static final String SPOUSE_LAST_NAME = "Spouse's Last name";
        private Locator spouseLastNameInputBox = locator(pwXPath("//input[@aria-label=\"Spouse's Last name\"]"));

    private static final String SPOUSE_DATE_OF_BIRTH_ARIA_LABEL = "Spouse's Date Of birth";
        private Locator spouseDateOfBirthInputBox = locator(pwXPath("//input[@aria-label=\"Spouse's Date Of birth\"]"));


        private Locator marriedOrInDomesticRelationMatCheckbox = locator(pwXPath("//div[contains(@class,'isMarried')]//mat-checkbox"));
        private Locator marriedOrInDomesticRelationCheckboxInput = locator(pwXPath("//div[contains(@class,'isMarried')]//input[@type='checkbox']"));
        private Locator marriedOrInDomesticRelationCheckBoxDescription = locator(pwXPath("//p[contains(@class, 'spouse__checkbox-description')]"));
    private static final String MARRIED_CHECKBOX_DESCRIPTION = "Check to add your spouse or partner";
    private static final String MARRIED_DOMESTIC_RELATIONSHIP_LABEL = "Married or in a domestic partnership";
        private Locator marriedOrInDomesticRelationLabel = locator(pwXPath("//span[contains(text(), '" + MARRIED_DOMESTIC_RELATIONSHIP_LABEL + "')]"));

    private static final String REQUIRED_OR_INCOMPLETE_FIELD_ERROR_MESSAGE = "One or more required fields are incomplete or incorrect. Please review.";
        private Locator requiredOrIncompleteErrorMessage = locator(pwXPath("//p[contains(text(), '" + REQUIRED_OR_INCOMPLETE_FIELD_ERROR_MESSAGE + "')]"));

    private static final String CURRENT_FORMER_EMPLOYED_PROFESSIONAL = "Current or former employed professional (optional)";
        private Locator currentFormerEmployedHeaderPersonalInfoDiv = locator(pwXPath("//div[@id='occupationDiv']//p[contains(text(), '" + CURRENT_FORMER_EMPLOYED_PROFESSIONAL + "')]"));

        private Locator currentFormerEmployedHeaderSpouseDiv = locator(pwXPath("//div[@id='spouseDetailsDiv']//p[contains(text(), '" + CURRENT_FORMER_EMPLOYED_PROFESSIONAL + "')]"));
    private static final String ELIGIBLE_ADDITIONAL_SAVINGS = "Eligible occupations can qualify for additional savings";
        private Locator eligibleOccupationSavingsPersonalInfoDiv = locator(pwXPath("//div[@id='occupationDiv']//p[contains(text(), '" + ELIGIBLE_ADDITIONAL_SAVINGS + "')]"));

        private Locator eligibleOccupationSavingsSpouseDiv = locator(pwXPath("//div[@id='spouseDetailsDiv']//p[contains(text(), '" + ELIGIBLE_ADDITIONAL_SAVINGS + "')]"));

    private static final String ELIGIBLE_OCCUPATION_BUTTON = "See eligible occupations";
        private Locator eligibleOccupationButtonPersonalInfoDiv = locator(pwXPath("//button[@id='primaryOccupation']"));

        private Locator eligibleOccupationButtonSpouseDiv = locator(pwXPath("//button[@id='spouseOccupation']"));


    private static final String ELIGIBLE_OCCUPATION_HEADER = "Eligible occupations";
        private Locator eligibleOccupationHeader = locator(pwXPath("//h1[contains(text(), '" + ELIGIBLE_OCCUPATION_HEADER + "')]"));
    private static final String OCCUPATIONS_RADIO_BUTTONS_XPATH = "//app-occupation-list//mat-radio-button";
        private Locator occupationRadioButtons = locator(pwXPath(OCCUPATIONS_RADIO_BUTTONS_XPATH));
        private Locator firstOccupationRadioButton = locator(pwXPath(OCCUPATIONS_RADIO_BUTTONS_XPATH));
        private Locator currentlyEmployedOrRetiredQuestion = locator(pwXPath("//div[contains(@class,'col occupation-retired-checkbox-col')]//p"));
    private static final String EMPLOYED_OR_RETIRED_TOGGLE_BUTTONS_XPATH = "//div[contains(@class,'col occupation-retired-checkbox-col')]//mat-button-toggle-group//mat-button-toggle//button";
        private Locator currentlyEmployedOrRetiredToggleButtons = locator(pwXPath(EMPLOYED_OR_RETIRED_TOGGLE_BUTTONS_XPATH));
        private Locator currentlyEmployedOrRetiredToggleButton = locator(pwXPath(EMPLOYED_OR_RETIRED_TOGGLE_BUTTONS_XPATH));

        private Locator currentlyEmployedOrRetiredToggleButtonLabel = locator(pwXPath("//div[contains(@class,'col occupation-retired-checkbox-col')]//mat-button-toggle-group//mat-button-toggle//button//span"));
    private static final String CONTINUE_BUTTON = "Continue";
    private static final String OCCUPATION_SUBLIST_XPATH = "//mat-radio-button[contains(@class,'radio-checked')]/following-sibling::*[1]//mat-radio-group//mat-radio-button";

        private Locator closeIcon = locator(pwXPath("//app-occupation-list//mat-icon[contains(text(), 'close')]"));

        private Locator closeButton = locator(pwXPath("//app-occupation-list//button[contains(text(), 'Close')]"));

        private Locator occupationRetiredCheckBox = locator(pwXPath("//div[contains(@class,'occupation-retired-checkbox')]//mat-checkbox"));

    private static final String RETIRED_FORMALLY_EMPLOYED_LABEL = "I am retired and a formerly employed professional";
        private Locator retiredFormerlyEmployedLabel = locator(pwXPath("//span[contains(text(), '" + RETIRED_FORMALLY_EMPLOYED_LABEL + "')]"));

        private Locator eligibleOccupationAddButton = locator(pwXPath("//button[contains(text(), 'Add')]"));

        private Locator eligibleOccupationCancelButton = locator(pwXPath("//mat-dialog-actions//button[contains(text(), 'Cancel')]"));

        private Locator removeOccupationLinkPrimaryApplicant = locator(pwXPath("//div[@id='occupationDiv']//a"));
        private Locator removeOccupationLinkSpouse = locator(pwXPath("//div[@id='spouseDetailsDiv']//a"));
    private static final String REMOVE_OCCUPATION_HEADER_IN_MODAL = "Remove occupation";
        private Locator removeOccupationHeaderInModalBox = locator(pwXPath("//app-remove-occupation//h1[contains(text(), '" + REMOVE_OCCUPATION_HEADER_IN_MODAL + "')]"));

        private Locator keepOccupationButton = locator(pwXPath("//button[contains(text(), 'Keep occupation')]"));

        private Locator removeOccupationButton = locator(pwXPath("//button[contains(text(), 'Remove')]"));
    private static final String REMOVE_OCCUPATION_QUESTION = "Are you sure you want to remove this occupation? You will lose any discount associated with it.";
        private Locator removeOccupationQuestion = locator(pwXPath("//mat-dialog-content[contains(text(), '" + REMOVE_OCCUPATION_QUESTION + "')]"));

    //home-occupation-selected-message
        private Locator homeOccupationSelectedMessagePersonalInfo = locator(pwXPath("//div[contains(@class,'home-occupation-selected-message')]"));

        private Locator homeOccupationSelectedMessageSpouseDiv = locator(pwXPath("//div[@id='spouseDetailsDiv']//div[contains(@class,'home-occupation-selected-message')]"));

        private Locator occupationPrimary = locator(pwXPath("//div[@id='occupationDiv']//div[contains(@class,'home-occupation-selected-message')]"));

        private Locator occupationSpouse = locator(pwXPath("//div[@id='spouseDetailsDiv']//div[contains(@class,'home-occupation-selected-message')]"));

    private static final String CURRENT_HOME_ADDRESS_LABEL = "My current home address";
        private Locator priorOrCurrentHomeAddressLabel = locator(pwXPath("//div[@id='priorCurrentAddress']//div//p"));

    private static final String CURRENT_ADDRESS_PLACEHOLDER_TEXT = "Current home address";
        private Locator currentAddressPlaceHolderText = locator(pwXPath("//mat-label[contains(text(), '" + CURRENT_ADDRESS_PLACEHOLDER_TEXT + "')]"));
    private static final String PRIOR_HOME_ADDRESS_LABEL = "My prior home address";

    private static final String PRIOR_ADDRESS_PLACEHOLDER_TEXT = "Prior home address";
        private Locator priorAddressPlaceHolderText = locator(pwXPath("//mat-label[contains(text(), '" + PRIOR_ADDRESS_PLACEHOLDER_TEXT + "')]"));
        private Locator priorOrCurrentAddressInputBox = locator(pwXPath("//address-autocomplete-input//input"));

        private Locator priorOrCurrentAddressCityInputBox = locator(pwXPath("//mat-form-field[@id='auto-contact-info-city__input-field']//input"));
        private Locator priorOrCurrentAddressStateSelect = locator(pwXPath("//mat-form-field[@id='state']//mat-select"));
        private Locator priorOrCurrentAddressZipInputBox = locator(pwXPath("//mat-form-field[@id='auto-contact-info-zipCode__input-field']//input"));

    //address-autocomplete-input//mat-icon
        private Locator closeIconInAddressInputBox = locator(pwXPath("//address-autocomplete-input//mat-icon"));

        private Locator unitInputBox = locator(pwXPath("//mat-form-field[@name='home-personal-info-apartment__input-field']//input"));
    private static final String UNIT_NUMBER_PLACEHOLDER_TEXT = "Unit #";
        private Locator unitNumberPlaceholderText = locator(pwXPath("//mat-label[contains(text(),'" + UNIT_NUMBER_PLACEHOLDER_TEXT + "')]"));

    private static final String CITY_PLACEHOLDER_TEXT = "City";
        private Locator cityPlaceholderText = locator(pwXPath("//mat-label[contains(text(),'" + CITY_PLACEHOLDER_TEXT + "')]"));

    private static final String STATE_PLACEHOLDER_TEXT = "State";
        private Locator statePlaceholderText = locator(pwXPath("//mat-label[contains(text(),'" + STATE_PLACEHOLDER_TEXT + "')]"));

    private static final String ZIP_PLACEHOLDER_TEXT = "ZIP";
        private Locator zipPlaceholderText = locator(pwXPath("//mat-label[contains(text(),'" + ZIP_PLACEHOLDER_TEXT + "')]"));

    private static final String OPTIONAL_UNIT_NUMBER_HINT = "Optional";
        private Locator optionalUnitNumberHint = locator(pwXPath("//mat-hint[contains(text(),'" + OPTIONAL_UNIT_NUMBER_HINT + "')]"));

    private static final String PLEASE_ENTER_STREET_NUMBER_AND_NAME = "Please enter street number and name.";
    private static final String PLEASE_PROVIDE_YOUR_CITY_ERROR = "Please enter your city.";
    private static final String PLEASE_PROVIDE_YOUR_STATE_ERROR = "Please enter your state.";
    private static final String PLEASE_PROVIDE_YOUR_ZIP_ERROR = "Please enter your ZIP code.";
    private static final String PLEASE_PROVIDE_FIVE_DIGIT_ZIP_ERROR = "Please enter a 5 digit ZIP Code.";
        private Locator pleaseEnterYourStreetNumberAndNameError = locator(pwXPath("//mat-error[contains(text(),'" + PLEASE_ENTER_STREET_NUMBER_AND_NAME + "')]"));
        private Locator pleaseProvideYourCityError = locator(pwXPath("//mat-error[contains(text(),'" + PLEASE_PROVIDE_YOUR_CITY_ERROR + "')]"));
        private Locator pleaseProvideYourStateError = locator(pwXPath("//mat-error[contains(text(),'" + PLEASE_PROVIDE_YOUR_STATE_ERROR + "')]"));
        private Locator pleaseProvideYourZipError = locator(pwXPath("//mat-error[contains(text(),'" + PLEASE_PROVIDE_YOUR_ZIP_ERROR + "')]"));
        private Locator invalidInputZipError = locator(pwXPath("//mat-error[contains(text(),'" + PLEASE_PROVIDE_FIVE_DIGIT_ZIP_ERROR + "')]"));
        private Locator invalidInputAddressError = locator(pwXPath("//address-autocomplete-input[@id='prior-address-autocomplete']//mat-error"));

    private static final String PLEASE_SELECT_ADDRESS_FROM_LIST_ERROR = "Please select an address from the list.";
        private Locator pleaseSelectAddressFromListError = locator(pwXPath("//mat-error[contains(text(),'" + PLEASE_SELECT_ADDRESS_FROM_LIST_ERROR + "')]"));
    private static final String SELECT_ADDRESS_FROM_LIST_ERROR = "Please select an address from the list.";
        private Locator selectAddressFromListError = locator(pwXPath("//mat-error[contains(text(),'" + SELECT_ADDRESS_FROM_LIST_ERROR + "')]"));
        private Locator unitNumberNotValidEntryError = locator(pwXPath("//mat-form-field[@name='home-personal-info-apartment__input-field']//mat-error[contains(text(),'" + INVALID_ENTRY + "')]"));

        private Locator continueButton = locator(pwXPath("//button[contains(text(), '" + CONTINUE_BUTTON + "')]"));

        private Locator selectedOccupation = locator(pwXPath("//div[contains(@class,'home-occupation-selected')]"));

        protected Locator emailAddressInput = locator(pwXPath("//mat-form-field//input[@id='contact-details-emailAddress-input_email']"));
        protected Locator phoneNumberInput = locator(pwXPath("//mat-form-field//input[@id='contact-details-phoneNumber-input_Field']"));

    private static final String cityStateZipErrorTemplate = "Please enter your %s.";
    private static final String addressErrorTemplate = "Please enter street number and name.";

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public AceHRCAboutYouBasePage() throws Exception {
        super();
    }

    public boolean isOnAboutYouPage(boolean longWait) {
        waitForSpinnerToBeGone();
        int timeout = longWait ? Property.PAGELOADTIMEOUT : 3;
        return isElementVisible(firstNameInputBox, timeout);
    }

    public void waitAboutYouPageToRender() {
        waitElementBeVisible(aboutYouHeader);
    }

    public void fillOutApplicantFormWithNoInput() throws Exception {
        //skipping form field entering
        clickContinueOnHRCAboutYouPage();
    }

    public boolean isAboutYouHeaderDisplayed() {
        return isExpectedTextDisplayed(aboutYouHeader, ABOUT_YOU_HEADER);
    }

    public boolean isLetsGetToKnowEachOtherDisplayed() {
        return letsGetToKnowEachOtherSubHeader.isVisible();
    }

    public boolean isFirstNameInputBoxDisplayed() {
        return firstNameInputBox.isVisible();
    }

    public boolean isLastNameInputBoxDisplayed() {
        return lastNameInputBox.isVisible();
    }

    public boolean isDateOfBirthInputBoxDisplayed() {
        return dateOfBirthInputBox.isVisible();
    }

    public boolean isMMDDYYHintDisplayed() {
        return isElementDisplayed(mmddyyyyHint, 3);
    }

    public boolean isCurrentFormerEmployedHeaderDisplayed(boolean isPrimaryApplicant) {
        if (isPrimaryApplicant) {
            return currentFormerEmployedHeaderPersonalInfoDiv.isVisible();
        } else {
            return currentFormerEmployedHeaderSpouseDiv.isVisible();
        }
    }

    public boolean isEligibleOccupationSavingsDisplayed(boolean isPrimaryApplicant) {
        if (isPrimaryApplicant) {
            return eligibleOccupationSavingsPersonalInfoDiv.isVisible();
        } else {
            return eligibleOccupationSavingsSpouseDiv.isVisible();
        }
    }

    public boolean isSpouseFirstNameInputBoxDisplayed() {
        return isElementDisplayed(spouseFirstNameInputBox, 2);
    }

    public boolean isSpouseLastNameInputBoxDisplayed() {
        return isElementDisplayed(spouseLastNameInputBox, 2);
    }

    public boolean isSpouseDateOfBirthInputBoxDisplayed() {
        return isElementDisplayed(spouseDateOfBirthInputBox, 2);
    }

    public boolean isSpouseGenderDisplayed() throws Exception {
        return isElementPresent(pwXPath(SPOUSE_GENDER_SELECTION_XPATH));
    }

    public boolean isEligibleOccupationButtonDisplayed(boolean isPrimaryApplicant) {
        if (isPrimaryApplicant) {
            return eligibleOccupationButtonPersonalInfoDiv.isVisible();
        } else {
            return eligibleOccupationButtonSpouseDiv.isVisible();
        }
    }

    private boolean arePNIGenderButtonsDisplayedCorrectly(String stateCode, String lob) throws Exception {
        return checkGenderButtons(genderButtons.all(), stateCode, lob);
    }

    public String getFirstName() {
        return getValueFromLocator(firstNameInputBox);
    }

    public boolean isFirstNameReadOnly() {
        return isAttributePresent(firstNameInputBox, DISABLED);
    }

    public String getLastName() {
        return getValueFromLocator(lastNameInputBox);
    }

    public boolean isLastNameReadOnly() {
        return isAttributePresent(lastNameInputBox, DISABLED);
    }

    public String getDateOfBirth() {
        return getValueFromLocator(dateOfBirthInputBox);
    }

    public boolean isDateOfBirthReadOnly() {
        return isAttributePresent(dateOfBirthInputBox, DISABLED);
    }

    public String getOccupation() {
        return getTextFromElement(occupationPrimary);
    }

    public String getSpouseFirstName() {
        return getValueFromLocator(spouseFirstNameInputBox);
    }

    public boolean isSpouseFirstNameReadOnly() {
        return isAttributePresent(spouseFirstNameInputBox, DISABLED);
    }

    public String getSpouseLastName() {
        return getValueFromLocator(spouseLastNameInputBox);
    }

    public boolean isSpouseLastNameReadOnly() {
        return isAttributePresent(spouseLastNameInputBox, DISABLED);
    }

    public String getSpouseDateOfBirth() {
        return getValueFromLocator(spouseDateOfBirthInputBox);
    }

    public boolean isSpouseDateOfBirthReadOnly() {
        return isAttributePresent(spouseDateOfBirthInputBox, DISABLED);
    }

    public String getSpouseOccupation() {
        return getTextFromElement(occupationSpouse);
    }

    private boolean areSpouseGenderButtonsDisplayedCorrectly(String stateCode, String lob) throws Exception {
        return checkGenderButtons(spouseGenderButtons.all(), stateCode, lob);
    }

    private boolean checkGenderButtons(List<Locator> listOfGenderButtons, String stateCode, String lob) throws Exception {
        List<String> listOfExpectedButtonLabels =new ArrayList<>(Arrays.asList(MALE, FEMALE, NONBINARY));
        List<String> listOfActualButtonLabels = new ArrayList<>();
        isElementDisplayed(pwXPath(GENDER_SELECTION_XPATH));
        listOfGenderButtons.forEach(button -> listOfActualButtonLabels.add(getTextFromElement(button)));
        if (lob.equals(HOME)) {
            if (List.of(AL, KS, KY, IA, IN, LA, MA, MD, MN, MS, MT, NC, OH, WA).contains(stateCode)) {
                listOfExpectedButtonLabels.remove(NONBINARY);
            }
        } else {
            if (!List.of(CA, OR).contains(stateCode)) {
                listOfExpectedButtonLabels.remove(NONBINARY);
            }
        }
        return areTwoListEqual(listOfActualButtonLabels, listOfExpectedButtonLabels);
    }

    public boolean isEligibleOccupationButtonTextMatching(boolean isPrimaryApplicant) {
        if (isPrimaryApplicant) {
            return isExpectedTextDisplayed(eligibleOccupationButtonPersonalInfoDiv, ELIGIBLE_OCCUPATION_BUTTON);
        } else {
            return isExpectedTextDisplayed(eligibleOccupationButtonSpouseDiv, ELIGIBLE_OCCUPATION_BUTTON);
        }
    }

    public void clickEligibleOccupationButton(boolean isPrimaryApplicant) {
        if (isPrimaryApplicant) {
            waitAndClickElement(eligibleOccupationButtonPersonalInfoDiv);
        } else {
            waitAndClickElement(eligibleOccupationButtonSpouseDiv);
        }
    }

    public boolean isEligibleOccupationHeaderDisplayed() {
        waitElementBeVisible(eligibleOccupationHeader);
        return isExpectedTextDisplayed(eligibleOccupationHeader, ELIGIBLE_OCCUPATION_HEADER);
    }

    public boolean isCloseIconAddAndCancelButtonDisplayedInOccupationSideSheet() {
        return (closeIcon.isVisible() && eligibleOccupationAddButton.isVisible() && eligibleOccupationCancelButton.isVisible());
    }

    public boolean isRetiredProfessionalCheckBoxAndLabelDisplayed() {
        return occupationRetiredCheckBox.isVisible() && retiredFormerlyEmployedLabel.isVisible();
    }

    public void clickRetiredFormerlyEmployedCheckbox() {
        waitAndClickElement(occupationRetiredCheckBox);
    }

    public void clickCloseIcon() {
        waitAndClickElement(closeIcon);
    }

    public void clickAddButton() throws Exception {
    	scrollAndClickOnElement(eligibleOccupationAddButton);
    }

    public void clickRemoveOccupationLink(boolean isPrimaryApplicant) {
    	waitForUiSettled();
    	if (isPrimaryApplicant) {
    		scrollAndClickOnElement(removeOccupationLinkPrimaryApplicant);
    	} else {
    		scrollAndClickOnElement(removeOccupationLinkSpouse);
    	}
    }

    public boolean isRemoveOccupationHeaderTextDisplayed() {
        waitElementBeVisible(removeOccupationHeaderInModalBox);
        return isExpectedTextDisplayed(removeOccupationHeaderInModalBox, REMOVE_OCCUPATION_HEADER_IN_MODAL);
    }

    public boolean isRemoveOccupationQuestionTextDisplayed() {
        return isExpectedTextDisplayed(removeOccupationQuestion, REMOVE_OCCUPATION_QUESTION);
    }

    public boolean isAddedOccupationDisplayed(boolean isPrimaryApplicant) {
        waitForUiSettled();
        if (isPrimaryApplicant) {
            return homeOccupationSelectedMessagePersonalInfo.isVisible();
        } else {
            return homeOccupationSelectedMessageSpouseDiv.isVisible();
        }
    }

    public void clickKeepOccupationButton() {
        waitAndClickElement(keepOccupationButton);
    }

    public void clickRemoveOccupationButton() throws Exception {
        waitAndClickElement(removeOccupationButton);
        conditionalWait(10).until(Conditions.invisible(snackBar));
    }

    public void clickCancelButton() {
        waitAndClickElement(eligibleOccupationCancelButton);
    }

    public void selectOccupationRadioButton(String occupation) throws Exception {
        Locator radioButtonToBeSelected;
        List<String> listOccupations = getListOfOccupationFromSideSheet();

       // Workaround to one extra space in between 21st and Century
        if (occupation.contains("Century Employees")) {
        	occupation = "Century Employees";
        }
        if (listOccupations.contains(occupation)) {
            radioButtonToBeSelected = locator(pwXPath(String.format("//mat-radio-button[contains(.,'%s')]//input", occupation)));
        } else {
            try {
                // try to find the occupation amongst the sub-occupations
                Locator we = locator(pwXPath("//mat-radio-button[contains(.,'Military')]//input"));
                scrollAndClickOnHiddenElement(we);
                listOccupations = getListOfOccupationFromSideSheet();
                radioButtonToBeSelected = locator(pwXPath(String.format("//mat-radio-button[contains(.,'%s')]//input", occupation)));
            } catch (PlaywrightException e) {
                Log.warn("Occupation: " + occupation + " was not found, going to select first available on the list");
                occupation = listOccupations.get(0).contains( "Century Employees")? "Century Employees" : listOccupations.get(0);
                radioButtonToBeSelected = locator(pwXPath(String.format("//mat-radio-button[contains(.,'%s')]//input", occupation)));
            }
        }
        scrollAndClickOnHiddenElement(radioButtonToBeSelected);
    }

    public List<String> getListOfOccupationFromSideSheet() {
        waitElementBeVisibleClickable(currentlyEmployedOrRetiredToggleButton);
        List<String> occupationList = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            occupationList = occupationRadioButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
            if (!occupationList.isEmpty()) {
                break;
            }
        }
        return occupationList;
    }

    public void isOccupationBlank(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue((selectedOccupation.count() == 0), "Applicant Occupation entered is not saved");
    }

    public void checkMilitaryPersonnelOccupationSubList(FarmersSoftAssert fsa) throws Exception {
    	selectOccupationRadioButton(MILITARY_PERSONNEL);
    	waitForElements(OCCUPATION_SUBLIST_XPATH);
    	List<Locator> militaryOccupationSubGroupLocators = locators(pwXPath(OCCUPATION_SUBLIST_XPATH));
    	List<String> actualMilitarySubOccupation = militaryOccupationSubGroupLocators.stream().map(this::getTextFromElement).collect(Collectors.toList());
    	List<String> expectedMilitaryOccupationList = Arrays.asList("Air Force", "Army", "Coast Guard", "Honorably discharged", "Marine", "Navy");
    	fsa.assertEquals(actualMilitarySubOccupation, expectedMilitaryOccupationList, "Military Personnel occupation sublist verification");
    }

    public void validateErrorMessageForNoInput(boolean isPrimaryApplicant, ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        assertErrorMessages(getListOfExpectedErrorMessagesForNoInput("Please provide your %s.", isPrimaryApplicant, applicant), getListOfActualErrorMessagesInvalidData(), fsa);
    }

    public Boolean isRequiredIncompleteFieldErrorMessageDisplayed() {
        return isExpectedTextDisplayed(requiredOrIncompleteErrorMessage, REQUIRED_OR_INCOMPLETE_FIELD_ERROR_MESSAGE);
    }

    private void assertErrorMessages(List<String> listOfExpectedErrorMessages, List<String> listOfActualErrorMessages, FarmersSoftAssert fsa) {
        waitAboutYouPageToRender();
        // Expected list is already sorted before passing to this method
        fsa.assertEquals(listOfActualErrorMessages, listOfExpectedErrorMessages, "Expected Error Messages list: " + listOfExpectedErrorMessages + " verification");
    }

    private List<String> getListOfExpectedErrorMessagesForNoInput(String errorMessageTemplate, boolean isPrimaryApplicant, ApplicantAceHome applicant) throws Exception {
        waitAboutYouPageToRender();
        String lobType = getLobTypeFromAppStore();
        boolean isCurrentPriorAddressAvailable = applicant.isNewlyOwned() && (lobType.equals(HOME) || lobType.equals(CONDO));
        List<String> listOfErrorMessages =  new ArrayList<>();
        if (isPrimaryApplicant) {
            if (isCurrentPriorAddressAvailable) {
                listOfErrorMessages = Stream.of(FIRST_NAME, LAST_NAME, DATE_OF_BIRTH_ARIA_LABEL, ADDRESS, CITY, STATE, ZIP_CODE)
                        .map(field -> {
                            if (field.equals(ADDRESS.toLowerCase())) return addressErrorTemplate;
                            if (field.equals(CITY.toLowerCase())) return String.format(cityStateZipErrorTemplate, field);
                            if (field.equals(STATE.toLowerCase())) return String.format(cityStateZipErrorTemplate, field);
                            if (field.equals(ZIP_CODE)) return String.format(cityStateZipErrorTemplate, field);
                            return String.format(errorMessageTemplate, field.toLowerCase());
                        }).collect(Collectors.toList());
            } else {
                listOfErrorMessages = Stream.of(FIRST_NAME, LAST_NAME, DATE_OF_BIRTH_ARIA_LABEL)
                        .map(String::toLowerCase)
                        .map(field -> {
                            return String.format(errorMessageTemplate, field);
                        }).collect(Collectors.toList());
            }
        } else {
            if (isCurrentPriorAddressAvailable) {
                listOfErrorMessages = Stream.of(SPOUSE_FIRST_NAME, SPOUSE_LAST_NAME, SPOUSE_DATE_OF_BIRTH_ARIA_LABEL, ADDRESS, CITY, STATE, ZIP_CODE)
                        .map(field -> {
                            if (field.equals(ADDRESS.toLowerCase())) return addressErrorTemplate;
                            if (field.equals(CITY.toLowerCase())) return String.format(cityStateZipErrorTemplate, field);
                            if (field.equals(STATE.toLowerCase())) return String.format(cityStateZipErrorTemplate, field);
                            if (field.equals(ZIP_CODE)) return String.format(cityStateZipErrorTemplate, field);
                            // Error message for date is different for invalid input so below is an itinerary operation to meet error message constructions.
                            if (field.contains(DATE_OF_BIRTH_ARIA_LABEL.toLowerCase()) && errorMessageTemplate.contains("Invalid")) {
                                return DATE_OF_BIRTH_IS_NOT_A_VALID_ENTRY;
                            }
                            return String.format(errorMessageTemplate, field.toLowerCase());
                        }).collect(Collectors.toList());
            } else {
                listOfErrorMessages = Stream.of(SPOUSE_FIRST_NAME, SPOUSE_LAST_NAME, SPOUSE_DATE_OF_BIRTH_ARIA_LABEL)
                        .map(String::toLowerCase)
                        .map(field -> {
                            // Error message for date is different for invalid input so below is an itinerary operation to meet error message constructions.
                            if (field.contains(DATE_OF_BIRTH_ARIA_LABEL.toLowerCase()) && errorMessageTemplate.contains("Invalid")) {
                                return DATE_OF_BIRTH_IS_NOT_A_VALID_ENTRY;
                            }
                            return String.format(errorMessageTemplate, field);
                        }).collect(Collectors.toList());
            }
        }
        if (!lobType.equals("mobilehome")) {
        	listOfErrorMessages.add("This is required.");
        }
        if (lobType.equals(RENTERS)) {
            listOfErrorMessages.add("Please provide your email address.");
            listOfErrorMessages.add("Please provide your phone number.");
        }
        return getSortedList(listOfErrorMessages);
    }


    private List<String> getListOfExpectedErrorMessagesInvalidData(String errorMessageTemplate, boolean isPrimaryApplicant, ApplicantAceHome applicant) throws Exception {
        String lobType = getLobTypeFromAppStore();
        boolean isCurrentPriorAddressAvailable = applicant.isNewlyOwned() && (lobType.equals(HOME.toLowerCase()) || lobType.equals(CONDO));
        List<String> listOfErrorMessages;
        if (isPrimaryApplicant) {
            if (isCurrentPriorAddressAvailable) {
                listOfErrorMessages = Stream.of(FIRST_NAME, LAST_NAME, DATE_OF_BIRTH_ARIA_LABEL, ADDRESS, CITY, STATE, ZIP_CODE)
                        .map(field -> {
                            // Error message for date is different for invalid input so below is an itinerary operation to meet error message constructions.
                            if (field.contains(DATE_OF_BIRTH_ARIA_LABEL.toLowerCase())) return INVALID_DATE_OF_BIRTH;
                            if (field.equals(ADDRESS.toLowerCase())) return addressErrorTemplate;
                            if (field.equals(CITY.toLowerCase())) return String.format(cityStateZipErrorTemplate, field);
                            if (field.equals(STATE.toLowerCase())) return String.format(cityStateZipErrorTemplate, field);
                            if (field.equals(ZIP_CODE)) return String.format(cityStateZipErrorTemplate, field);
                            return String.format(errorMessageTemplate, field.toLowerCase());
                        }).collect(Collectors.toList());
            } else {
                listOfErrorMessages = Stream.of(FIRST_NAME, LAST_NAME, DATE_OF_BIRTH_ARIA_LABEL)
                        .map(String::toLowerCase).map(field -> String.format(errorMessageTemplate, field)).collect(Collectors.toList());
            }
        } else {
            if (isCurrentPriorAddressAvailable) {
                listOfErrorMessages = Stream.of(SPOUSE_FIRST_NAME, SPOUSE_LAST_NAME, SPOUSE_DATE_OF_BIRTH_ARIA_LABEL, ADDRESS, CITY, STATE, ZIP_CODE)
                        .map(field -> {
                            // Error message for date is different for invalid input so below is an itinerary operation to meet error message constructions.
                            if (field.contains(DATE_OF_BIRTH_ARIA_LABEL.toLowerCase())) return INVALID_SPOUSE_DATE_OF_BIRTH;
                            if (field.equals(ADDRESS.toLowerCase())) return addressErrorTemplate;
                            if (field.equals(CITY.toLowerCase())) return String.format(cityStateZipErrorTemplate, field);
                            if (field.equals(STATE.toLowerCase())) return String.format(cityStateZipErrorTemplate, field);
                            if (field.equals(ZIP_CODE)) return String.format(cityStateZipErrorTemplate, field);
                            return String.format(errorMessageTemplate, field.toLowerCase());
                        }).collect(Collectors.toList());
            } else {
                listOfErrorMessages = Stream.of(SPOUSE_FIRST_NAME, SPOUSE_LAST_NAME, SPOUSE_DATE_OF_BIRTH_ARIA_LABEL)
                        .map(String::toLowerCase).map(field -> String.format(errorMessageTemplate, field)).collect(Collectors.toList());
            }
        }
        if (!lobType.equals("mobilehome")) {
        	listOfErrorMessages.add("This is required.");
        }
        if (lobType.equals(RENTERS)) {
            listOfErrorMessages.add("Please provide your email address.");
            listOfErrorMessages.add("Please provide your phone number.");
        }
        return getSortedList(listOfErrorMessages);
    }

    @SneakyThrows
    private List<String> getListOfActualErrorMessages() {
        waitAboutYouPageToRender();
        return locators(pwXPath("//mat-error")).stream()
                .map(this::getTextFromElement).sorted()
                .collect(Collectors.toList());
    }

    @SneakyThrows
    private List<String> getListOfActualErrorMessagesInvalidData() {
        return locators(pwXPath("//mat-error")).stream()
                .map(this::getTextFromElement).sorted()
                .collect(Collectors.toList());
    }

    public void fillOutApplicantFormWithIncorrectInput(boolean isPrimaryApplicant) {
        String wrongFirstNameInput = "--";
        String wrongLastNameInput = "--";
        String wrongDate = "03/24/2343";
        if (isPrimaryApplicant) {
            fillOutApplicantFormWithValues(wrongFirstNameInput, wrongLastNameInput, wrongDate);
        } else {
            fillOutSpouseApplicantFormWithValues(wrongFirstNameInput, wrongLastNameInput, wrongDate);
        }
    }

    @SneakyThrows
    public void fillOutApplicantFormWithValues(String firstName, String lastName, String dateOfBirth) {
        waitAndClickElement(firstNameInputBox);
        enterValueInField(firstName, firstNameInputBox, LOG_MESSAGE_TEMPLATE + FIRST_NAME + COLON + SPACE);
        enterValueInField(lastName, lastNameInputBox, LOG_MESSAGE_TEMPLATE + FIRST_NAME + COLON + SPACE);
        enterValueInField(dateOfBirth, dateOfBirthInputBox, LOG_MESSAGE_TEMPLATE + DATE_OF_BIRTH_ARIA_LABEL_INPUT_BOX + COLON + SPACE);
        clickContinueOnHRCAboutYouPage();
    }

    @SneakyThrows
    public void fillOutSpouseApplicantFormWithValues(String firstName, String lastName, String dateOfBirth) {
        waitElementBeVisible(spouseFirstNameInputBox);
        waitForUiSettled();
        scrollToElement(spouseFirstNameInputBox);
        scrollAndClickOnHiddenElement(spouseFirstNameInputBox);
        enterValueInField(firstName, spouseFirstNameInputBox, LOG_MESSAGE_TEMPLATE + SPOUSE_FIRST_NAME + COLON + SPACE);
        scrollToElement(spouseLastNameInputBox);
        enterValueInField(lastName, spouseLastNameInputBox, LOG_MESSAGE_TEMPLATE + SPOUSE_LAST_NAME + COLON + SPACE);
        scrollToElement(spouseDateOfBirthInputBox);
        sendKeysOneByOne(spouseDateOfBirthInputBox, dateOfBirth);
        clickContinueOnHRCAboutYouPage();
    }

    public void enterSpouseApplicantData(ApplicantAceHome applicant) {
        waitAndClickElement(spouseFirstNameInputBox);
        enterValueInField(applicant.getSpouseFirstName(), spouseFirstNameInputBox, LOG_MESSAGE_TEMPLATE + SPOUSE_FIRST_NAME + COLON + SPACE);
        waitAndClickElement(spouseLastNameInputBox);
        enterValueInField(applicant.getSpouseLastName(), spouseLastNameInputBox, LOG_MESSAGE_TEMPLATE + SPOUSE_LAST_NAME + COLON + SPACE);
        waitAndClickElement(spouseDateOfBirthInputBox);
        sendKeysOneByOne(spouseDateOfBirthInputBox, applicant.getSpouseDateOfBirth());
        setGenderSpouse(applicant);
    }

    public void validateErrorMessageForInvalidInput(boolean isPrimaryApplicant, ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        assertErrorMessages(getListOfExpectedErrorMessagesInvalidData("Invalid %s", isPrimaryApplicant, applicant), getListOfActualErrorMessagesInvalidData(), fsa);
    }

    public void clickOnMarriedOrInDomesticRelationCheckbox() throws Exception {
        waitElementBeVisibleClickable(marriedOrInDomesticRelationMatCheckbox);
        clickElement(marriedOrInDomesticRelationCheckboxInput);
    }

    public boolean isMarriedOrSpouseCheckBoxDescriptionMatching() {
        return isExpectedTextDisplayed(marriedOrInDomesticRelationCheckBoxDescription, MARRIED_CHECKBOX_DESCRIPTION);
    }

    public boolean isMarriedCheckboxReadOnly() {
        return getAttributeData(marriedOrInDomesticRelationMatCheckbox, CLASS).contains(CHECKBOX_DISABLED);
    }

    public boolean isMarriedCheckboxChecked() {
        return getAttributeData(marriedOrInDomesticRelationMatCheckbox, CLASS).contains(CHECKBOX_CHECKED);
    }

    public boolean areInvalidDatesTriggerErrorMessageForAgeLimit(ApplicantAceHome applicant, boolean isPrimaryApplicant) {
        String date = generateDateOfBirthYoungerThan15OrOlderThan99();
        AtomicBoolean flag = new AtomicBoolean(true);

        // validate if age is between 15 and 99 years.
        if (isPrimaryApplicant) {
            fillOutApplicantFormWithValues(applicant.getFirstName(), applicant.getLastName(), date);
        } else {
            fillOutSpouseApplicantFormWithValues(applicant.getFirstName(), applicant.getLastName(), date);
        }

        if (getListOfActualErrorMessages().stream().noneMatch(msg -> msg.contains(AGE_LIMIT_ERROR))) {
            flag.set(false);
            Log.error("Error message did not trigger for this date: " + date);
        }
        return flag.get();
    }

    public boolean areInvalidEntryDatesTriggerErrorMessage(ApplicantAceHome applicant, boolean isPrimaryApplicant) {
        AtomicBoolean flag = new AtomicBoolean(true);

        // validate if Date of Birth is a valid entry
        if (isPrimaryApplicant) {
            fillOutApplicantFormWithValues(applicant.getFirstName(), applicant.getLastName(), INVALID_FORMAT_DATE);
        } else {
            fillOutSpouseApplicantFormWithValues(applicant.getFirstName(), applicant.getLastName(), INVALID_FORMAT_DATE);
        }


        flag.set(true);
        if (getListOfActualErrorMessages().stream().noneMatch(msg -> msg.contains(DOB_IS_NOT_VALID_ENTRY_ERROR))) {
            flag.set(false);
            Log.error("Error message did not trigger for this date: " + INVALID_FORMAT_DATE);
        }
        return flag.get();
    }

    public boolean notAllowedSpecialCharsNotAcceptedOnFirstNameField() {
        return areNotAllowedCharactersNotAccepted(firstNameInputBox, NOT_ALLOWED_SPECIAL_CHARACTERS);
    }

    public boolean notAllowedSpecialCharsNotAcceptedOnLastNameField() {
        return areNotAllowedCharactersNotAccepted(lastNameInputBox, NOT_ALLOWED_SPECIAL_CHARACTERS);
    }

    public boolean notAllowedNumericCharsNotAcceptedOnFirstNameField() {
        return areNotAllowedCharactersNotAccepted(firstNameInputBox, NOT_ALLOWED_NUMERIC_CHARACTERS);
    }

    public boolean notAllowedNumericCharsNotAcceptedOnLastNameField() {
        return areNotAllowedCharactersNotAccepted(lastNameInputBox, NOT_ALLOWED_NUMERIC_CHARACTERS);
    }

    public boolean notAllowedSpecialCharsNotAcceptedOnSpouseFirstNameField() {
        return areNotAllowedCharactersNotAccepted(spouseElements.nth(0), NOT_ALLOWED_SPECIAL_CHARACTERS);
    }

    public boolean notAllowedSpecialCharsNotAcceptedOnSpouseLastNameField() {
        return areNotAllowedCharactersNotAccepted(spouseElements.nth(1), NOT_ALLOWED_SPECIAL_CHARACTERS);
    }

    public boolean notAllowedNumericCharsNotAcceptedOnSpouseFirstNameField() {
        return areNotAllowedCharactersNotAccepted(spouseElements.nth(0), NOT_ALLOWED_NUMERIC_CHARACTERS);
    }

    public boolean notAllowedNumericCharsNotAcceptedOnSpouseLastNameField() {
        return areNotAllowedCharactersNotAccepted(spouseElements.nth(1), NOT_ALLOWED_NUMERIC_CHARACTERS);
    }

    public boolean notAllowedSpecialCharsNotAcceptedOnDOBField() {
        scrollAndClickOnElement(dateOfBirthInputBox);
        sendKeysToElement(dateOfBirthInputBox, NOT_ALLOWED_SPECIAL_AND_ALPHABETIC_CHARACTERS);
        sendKeysToElement(dateOfBirthInputBox, Keys.TAB);
        return getAttributeData(dateOfBirthInputBox, CLASS).contains("ng-invalid");
    }

    public boolean notAllowedSpecialCharsNotAcceptedOnCityField() {
        return areNotAllowedCharactersNotAccepted(priorOrCurrentAddressCityInputBox, NOT_ALLOWED_SPECIAL_CHARACTERS);
    }

    private boolean areNotAllowedCharactersNotAccepted(Locator element, String notAllowedChars) {
        scrollAndClickOnElement(element);
        sendKeysToElement(element, notAllowedChars);
        return getValueFromLocator(element).isBlank();
    }

    public boolean isPriorCurrentHomeAddressLabelDisplayed(boolean isPriorHomeAddress) {
        if (isPriorHomeAddress) {
            return isExpectedTextDisplayed(priorOrCurrentHomeAddressLabel, PRIOR_HOME_ADDRESS_LABEL);
        } else {
            return isExpectedTextDisplayed(priorOrCurrentHomeAddressLabel, CURRENT_HOME_ADDRESS_LABEL);
        }
    }

    public boolean isPriorOrCurrentHomeAddressInputBoxDisplayed() {
        return priorOrCurrentAddressInputBox.isVisible();
    }

    public boolean isCurrentHomeAddressPlaceHolderTextDisplayed() {
        return currentAddressPlaceHolderText.isVisible();
    }

    public boolean isCloseIconInsideAddressInputBoxDisplayedAndClickable() {
        return closeIconInAddressInputBox.isVisible() && closeIconInAddressInputBox.isEnabled();
    }

    public boolean isUnitNumberInputBoxDisplayed() {
        return unitInputBox.isVisible();
    }

    public boolean isUnitNumberPlaceHolderTextDisplayed() {
        return isExpectedTextDisplayed(unitNumberPlaceholderText, UNIT_NUMBER_PLACEHOLDER_TEXT);
    }

    public boolean isUnitNumberOptionalHintDisplayed() {
        return isExpectedTextDisplayed(optionalUnitNumberHint, OPTIONAL_UNIT_NUMBER_HINT);
    }

    public boolean isPriorHomeAddressPlaceHolderTextDisplayed() {
        return priorAddressPlaceHolderText.isVisible();
    }

    public boolean isAddressRequiredErrorDisplayed() {
        return isExpectedTextDisplayed(pleaseEnterYourStreetNumberAndNameError, PLEASE_ENTER_STREET_NUMBER_AND_NAME);
    }

    public boolean isCityRequiredErrorDisplayed() {
        return isExpectedTextDisplayed(pleaseProvideYourCityError, PLEASE_PROVIDE_YOUR_CITY_ERROR);
    }

    public boolean isStateRequiredErrorDisplayed() {
        return isExpectedTextDisplayed(pleaseProvideYourStateError, PLEASE_PROVIDE_YOUR_STATE_ERROR);
    }

    public boolean isZipRequiredErrorDisplayed() {
        return isExpectedTextDisplayed(pleaseProvideYourZipError, PLEASE_PROVIDE_YOUR_ZIP_ERROR);
    }

    public boolean isInvalidAddressErrorDisplayed() {
        waitElementBeVisible(invalidInputAddressError);
        return isExpectedTextDisplayed(invalidInputAddressError, String.format("%s is not a valid entry.", getElementValue(priorOrCurrentAddressInputBox, "Current or Prior Address")));
    }

    public boolean isInvalidZipErrorDisplayed() {
        waitElementBeVisible(invalidInputZipError);
        return isExpectedTextDisplayed(invalidInputZipError, PLEASE_PROVIDE_FIVE_DIGIT_ZIP_ERROR);
    }

    public void fillOutCurrentOrPriorAddressFieldWithInValidData() throws Exception {
        waitAndClickElement(priorOrCurrentAddressInputBox);
        sendKeysOneByOne(priorOrCurrentAddressInputBox, NOT_ALLOWED_SPECIAL_CHARACTERS);
        sendKeysToElement(priorOrCurrentAddressZipInputBox, NOT_ALLOWED_SPECIAL_AND_ALPHABETIC_CHARACTERS);
    }

    public void fillOutUnitNumberWithInValidData() {
        sendKeysOneByOne(unitInputBox, "@@@");
    }

    public boolean isInvalidUnitErrorDisplayed() {
        waitElementBeVisible(unitNumberNotValidEntryError);
        String inValidUnitNumberInputValue = getAttributeData(unitInputBox, VALUE);
        return isExpectedTextDisplayed(unitNumberNotValidEntryError, inValidUnitNumberInputValue + INVALID_ENTRY);
    }

    public void fillOutPrimaryApplicantDetails(ApplicantAceHome applicantAceHome) {
        waitAndClickElement(firstNameInputBox);
        sendKeysToElement(firstNameInputBox, applicantAceHome.getFirstName());
        waitAndClickElement(lastNameInputBox);
        sendKeysToElement(lastNameInputBox, applicantAceHome.getLastName());
        waitAndClickElement(dateOfBirthInputBox);
        sendKeysToElement(dateOfBirthInputBox, applicantAceHome.getDateOfBirth());
        Log.info("Applicant date of birth: " + applicantAceHome.getDateOfBirth());
        selectGender(applicantAceHome);
    }

    public void fillOutSpouseApplicantDetails(ApplicantAceHome applicantAceHome) {
        waitAndClickElement(spouseElements.nth(0));
        sendKeysToElement(spouseElements.nth(0), applicantAceHome.getSpouseFirstName());
        waitAndClickElement(spouseElements.nth(1));
        sendKeysToElement(spouseElements.nth(1), applicantAceHome.getSpouseLastName());
        waitAndClickElement(spouseElements.nth(2));
        sendKeysToElement(spouseElements.nth(2), applicantAceHome.getSpouseDateOfBirth());
        setGenderSpouse(applicantAceHome);
    }

    public void enterCurrentAddress(ApplicantAceHome applicantAceHome) {
        enterGoogleAddress(priorOrCurrentAddressInputBox, applicantAceHome.getAddress(), applicantAceHome.getCity());
    }

    public void enterCurrentOrPriorAddressInBundle(ApplicantAceHome applicant) throws Exception {
        waitAndClickElement(priorOrCurrentAddressInputBox);
        enterGoogleAddressAceHome(priorOrCurrentAddressInputBox, null, applicant);
    }

    public String getPriorOrCurrentAddressUnit() {
        return getValueFromLocator(unitInputBox);
    }

    public String getPriorOrCurrentAddress() {
        return getValueFromLocator(priorOrCurrentAddressInputBox);
    }

    public String getPriorOrCurrentAddressCity() {
        return getValueFromLocator(priorOrCurrentAddressCityInputBox);
    }

    public String getPriorOrCurrentAddressState() {
        return getTextFromElement(priorOrCurrentAddressStateSelect);
    }

    public String getPriorOrCurrentAddressZip() {
        return getValueFromLocator(priorOrCurrentAddressZipInputBox);
    }

    public void fillOutTheDataInAboutYouPage(ApplicantAceHome applicantAceHome) throws Exception {
        waitElementBeVisibleClickable(firstNameInputBox);
        fillOutPrimaryApplicantDetails(applicantAceHome);
        clickEligibleOccupationButton(true);
        selectOccupationRadioButton(applicantAceHome.getOccupation());
        clickAddButton();
        if (applicantAceHome.getMaritalStatus().equals(MARRIED)) {
            clickOnMarriedOrInDomesticRelationCheckbox();
            fillOutSpouseApplicantDetails(applicantAceHome);
            clickEligibleOccupationButton(false);
            selectOccupationRadioButton(applicantAceHome.getOccupation());
            clickAddButton();
        }
        if (applicantAceHome.isNewlyOwned()) {
            // enter current address or prior address
            enterCurrentOrPriorAddress(applicantAceHome);
        }
        waitForPageToBeReady();
        clickContinueOnHRCAboutYouPage();
    }

    public void fillOutTheDataInAboutYouPage(ApplicantAceHome applicant, boolean clickContinue) throws Exception {
        waitForSpinnerToBeGone();
        fillOutPrimaryApplicantDetails(applicant);
        if (!applicant.getOccupation().isBlank() && !isNoEligibleOccupationState(applicant.getStateCode())) {
            clickEligibleOccupationButton(true);
            selectOccupationRadioButton(applicant.getOccupation());
            clickAddButton();
        }

        if (applicant.getMaritalStatus().equals(MARRIED)) {
            clickOnMarriedOrInDomesticRelationCheckbox();
            fillOutSpouseApplicantDetails(applicant);
            if (!applicant.getOccupation().isBlank() && !isNoEligibleOccupationState(applicant.getStateCode())) {
                clickEligibleOccupationButton(false);
                selectOccupationRadioButton(applicant.getOccupation());
                clickAddButton();
            }
        }

        if (applicant.isNewlyOwned()) {
            // enter current address or prior address
            enterCurrentOrPriorAddress(applicant);
        }
        waitForPageToBeReady();
        if (clickContinue) {
            clickContinueButton();
            if (isOnAboutYouPage(false)) {
                clickContinueButton();
            }
            List<String> errors = getPageErrors();
            if (!errors.isEmpty()) {
                throw new Exception("Could not proceed from About You page, because of the errors:\n" + errors);
            }
        }
    }

    public void fillOutPartialAboutYouPage(ApplicantAceHome applicant, String origin) throws Exception {
        waitElementBeVisibleClickable(firstNameInputBox);
        if (origin.equalsIgnoreCase("toggle")) {
            sendKeysToElement(dateOfBirthInputBox, applicant.getDateOfBirth());
        }
        selectGender(applicant);
        if (!applicant.getOccupation().isBlank() && !isNoEligibleOccupationState(applicant.getStateCode())) {
            clickEligibleOccupationButton(true);
            selectOccupationRadioButton(applicant.getOccupation());
            clickAddButton();
        }
        if (applicant.getMaritalStatus().equals(MARRIED)) {
            clickOnMarriedOrInDomesticRelationCheckbox();
            fillOutSpouseApplicantDetails(applicant);
            if (!applicant.getOccupation().isBlank() && !isNoEligibleOccupationState(applicant.getStateCode())) {
                clickEligibleOccupationButton(false);
                selectOccupationRadioButton(applicant.getOccupation());
                clickAddButton();
            }
        }
        if (applicant.isNewlyOwned()) {
            // enter current address or prior address
            enterCurrentOrPriorAddress(applicant);
        }
    }

    public void clickContinueButton() throws Exception {
        waitAndClickElement(continueButton);
        testStep("Clicked continue button on About You page.", false);
        waitForSpinnerToBeGone();
    }

    public void validateContentOfPrimaryApplicant(FarmersSoftAssert fsa, String stateCode, String lob) throws Exception {
        fsa.assertTrue(isAboutYouHeaderDisplayed(), "About you header displayed");
        fsa.assertTrue(isElementInViewport(aboutYouHeader), "About you - page title is in Viewport");
        fsa.assertTrue(isLetsGetToKnowEachOtherDisplayed(), "Let's get to know each other subheader displayed");
        fsa.assertTrue(isFirstNameInputBoxDisplayed(), "First name input box displayed");
        fsa.assertTrue(isLastNameInputBoxDisplayed(), "Last name input box displayed");
        fsa.assertTrue(isDateOfBirthInputBoxDisplayed(), "Date of birth input box displayed");
        fsa.assertTrue(isMMDDYYHintDisplayed(), "MMDDYYYY hint displayed");
        fsa.assertTrue(arePNIGenderButtonsDisplayedCorrectly(stateCode, lob), "PNI gender buttons displayed correctly");
    }

    public void validateContentForEligibleOccupationButtonAndTitle(FarmersSoftAssert fsa, boolean isPrimaryApplicant) {
        fsa.assertTrue(isCurrentFormerEmployedHeaderDisplayed(isPrimaryApplicant), "Current former employed header personalInfoDiv displayed");
        fsa.assertTrue(isEligibleOccupationSavingsDisplayed(isPrimaryApplicant), "Eligible occupation savings personalInfoDiv displayed");
        fsa.assertTrue(isEligibleOccupationButtonDisplayed(isPrimaryApplicant), "Eligible occupation button personalInfoDiv displayed");
        fsa.assertTrue(isEligibleOccupationButtonTextMatching(isPrimaryApplicant), "Eligible occupation button text personalInfoDiv matching");
    }

    public void validateContentOfEligibleOccupationSideSheet(FarmersSoftAssert fsa, String landingStateCode, boolean isPrimaryApplicant) throws Exception {
        clickEligibleOccupationButton(isPrimaryApplicant);
        fsa.assertTrue(isEligibleOccupationHeaderDisplayed(), "Eligible occupation Header personalInfoDiv displayed");

        String expectedRetiredOrEmployedQuestion = "Are you currently employed or retired?";
        fsa.assertEquals(getTextFromElement(currentlyEmployedOrRetiredQuestion), expectedRetiredOrEmployedQuestion, "Currently employed or retired question text check");
        waitForUiSettled();
        fsa.assertTrue(currentlyEmployedOrRetiredToggleButtons.count() == 2, "Currently employed or retired button size matching.");

        fsa.assertEquals(getTextFromElement(currentlyEmployedOrRetiredToggleButtonLabel.nth(0)), "Employed", "Employed button label check");
        fsa.assertEquals(getTextFromElement(currentlyEmployedOrRetiredToggleButtonLabel.nth(1)), "Retired", "Retired button label check");

        fsa.assertEquals(getSortedList(getListOfOccupationFromSideSheet()), AceHomeSupportedOccupationByState.valueOf(landingStateCode).getSupportedOccupation(), "List of occupations check");

        if (!List.of(CA, CT, GA, MI, TN, VA).contains(landingStateCode)){
            checkMilitaryPersonnelOccupationSubList(fsa);
        }
        if (!Objects.equals(TN, landingStateCode)) {
            fsa.assertTrue(isCloseIconAddAndCancelButtonDisplayedInOccupationSideSheet(), "Eligible occupation close icon, add and cancel button displayed");
        }
        closeSideSheetByEscKey(fsa);
    }

    public void selectOccupationRadioButtonAndValidateSelectedOccupation(FarmersSoftAssert fsa, String occupation) throws Exception {
        selectOccupationRadioButton(occupation);
        clickAddButton();
        fsa.assertTrue(isAddedOccupationDisplayed(true), "Occupation in personalInfo div");
    }

    public void selectPNIOccupation(FarmersSoftAssert fsa, String occupation) throws Exception {
        waitAndClickElement(eligibleOccupationButtonPersonalInfoDiv);
        selectOccupationRadioButtonAndValidateSelectedOccupation(fsa, occupation);
    }

    public void validateRemoveOccupationHeaderAndQuestion(FarmersSoftAssert fsa) {
        fsa.assertTrue(isRemoveOccupationHeaderTextDisplayed(), "Remove occupation header text check");
        fsa.assertTrue(isRemoveOccupationQuestionTextDisplayed(), "Remove occupation question text check");
    }

    public void validateContentOfSpouseApplicant(FarmersSoftAssert fsa, String stateCode, String lob) throws Exception {
        fsa.assertTrue(isSpouseFirstNameInputBoxDisplayed(), "Spouse first name input box displayed");
        fsa.assertTrue(isSpouseLastNameInputBoxDisplayed(), "Spouse last name input box displayed");
        fsa.assertTrue(isSpouseDateOfBirthInputBoxDisplayed(), "Spouse date of birth input box displayed");

        // need to validate mmddyyyy hint in spouse section once it is added by dev
        fsa.assertTrue(isMMDDYYHintDisplayed(), "MMDDYYYY hint displayed");
        fsa.assertTrue(areSpouseGenderButtonsDisplayedCorrectly(stateCode, lob), "Spouse gender buttons displayed correctly");
    }

    public void validateMarriedOrInDomesticRelationCheckBoxDescription(FarmersSoftAssert fsa) {
        fsa.assertTrue(isMarriedOrSpouseCheckBoxDescriptionMatching(), "Married or in domestic relationship checkbox description check");
    }

    public void validateErrorForNoInputInCurrentOrPriorAddressFields(FarmersSoftAssert fsa) {
        fsa.assertTrue(isAddressRequiredErrorDisplayed(), "Address required error displayed");
        fsa.assertTrue(isCityRequiredErrorDisplayed(), "City required error displayed");
        fsa.assertTrue(isStateRequiredErrorDisplayed(), "State required error displayed");
        fsa.assertTrue(isZipRequiredErrorDisplayed(), "Zip required error displayed");
    }

    public void validateErrorForInvalidInputInCurrentOrPriorAddressFields(FarmersSoftAssert fsa) {
        fsa.assertTrue(isInvalidAddressErrorDisplayed(), "Current or Prior Address invalid input error displayed");
        fsa.assertTrue(isInvalidZipErrorDisplayed(), "Current or Prior Zip code invalid input error displayed");
    }

    public void validateContentOfPriorOrCurrentAddress(FarmersSoftAssert fsa, Field field) {
        if (field.getIsNewHome().equals("Y")) {
            fsa.assertTrue(isPriorOrCurrentHomeAddressInputBoxDisplayed(), "Address input box displayed");
            fsa.assertTrue(isElementVisible(priorHomeCityInputField, 2), "City input box displayed");
            fsa.assertTrue(isElementVisible(cityPlaceholderText, 2), "City place holder text displayed");
            fsa.assertTrue(isElementVisible(priorHomeStateSelectField, 2), "State input box displayed");
            fsa.assertTrue(isElementVisible(statePlaceholderText, 2), "State place holder text displayed");
            fsa.assertTrue(isElementVisible(priorHomeZipInputField, 2), "Zip input box displayed");
            fsa.assertTrue(isElementVisible(zipPlaceholderText, 2), "Zip place holder text displayed");
            fsa.assertTrue(isUnitNumberInputBoxDisplayed(), "Unit # input box displayed");
            fsa.assertTrue(isUnitNumberPlaceHolderTextDisplayed(), "Unit # place holder text displayed");
            fsa.assertTrue(isUnitNumberOptionalHintDisplayed(), "Unit # optional hint displayed");
            fsa.assertTrue(isCloseIconInsideAddressInputBoxDisplayedAndClickable(), "Close Icon inside address input box displayed and clickable");

            if (field.getInEscrow().equals("Y")) {
                // current address validation
                fsa.assertTrue(isPriorCurrentHomeAddressLabelDisplayed(false), "Current home address label displayed");
                fsa.assertTrue(isCurrentHomeAddressPlaceHolderTextDisplayed(), "Current home address place holder text displayed");
            } else {
                // prior address validation
                fsa.assertTrue(isPriorCurrentHomeAddressLabelDisplayed(true), "Prior home address label displayed");
                fsa.assertTrue(isPriorHomeAddressPlaceHolderTextDisplayed(), "Prior home address place holder text displayed");
            }
        }
    }

    public void validateRequiredIncompleteFieldErrorMessage(FarmersSoftAssert fsa) {
        fsa.assertTrue(isRequiredIncompleteFieldErrorMessageDisplayed(), "Required or incomplete field error message displayed.");
    }

    public void validateInvalidErrorMessagesForAgeLimitAndDob(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome, boolean isPrimaryApplicant) {
        fsa.assertTrue(areInvalidDatesTriggerErrorMessageForAgeLimit(applicantAceHome, isPrimaryApplicant), "Invalid date condition - age<=15 and age>=99 error displayed.");
        fsa.assertTrue(areInvalidEntryDatesTriggerErrorMessage(applicantAceHome, isPrimaryApplicant), "Date of Birth is not a valid entry error displayed.");
    }

    public void validateCharacterLimitForFirstNameLastName(FarmersSoftAssert fsa) {
        fsa.assertEquals(getAttributeData(firstNameInputBox, VALUE).length(), 15, "Check max of 15 chars allowed in first name field");
        fsa.assertEquals(getAttributeData(lastNameInputBox, VALUE).length(), 20, "Check max of 20 chars allowed in last name field");
    }

    public void validateNotAllowedSpecialCharsInFirstLastName(FarmersSoftAssert fsa) {
        fsa.assertTrue(notAllowedSpecialCharsNotAcceptedOnFirstNameField(), "Special chars are not allowed in first name field");
        fsa.assertTrue(notAllowedSpecialCharsNotAcceptedOnLastNameField(), "Special chars are not allowed in last name field");
    }

    public void validateNotAllowedNumericInFirstLastName(FarmersSoftAssert fsa) {
        fsa.assertTrue(notAllowedNumericCharsNotAcceptedOnFirstNameField(), "Numeric chars are not allowed in first name field");
        fsa.assertTrue(notAllowedNumericCharsNotAcceptedOnLastNameField(), "Numeric chars are not allowed in last name field");
    }

    public void validateNotAllowedSpecialCharInDOB(FarmersSoftAssert fsa) {
        fsa.assertTrue(notAllowedSpecialCharsNotAcceptedOnDOBField(), "Special chars are not allowed in date of birth field");
    }

    public void validateCharLimitFirstLastNameSpouse(FarmersSoftAssert fsa) {
        fsa.assertEquals(getAttributeData(spouseFirstNameInputBox, VALUE).length(), 15, "Check 15 chars allowed in spouse first name field");
        fsa.assertEquals(getAttributeData(spouseLastNameInputBox, VALUE).length(), 20, "Check 20 chars allowed in spouse last name field");
    }

    public void validateNotAllowedSpecialCharsInFirstLastNameSpouse(FarmersSoftAssert fsa) {
        fsa.assertTrue(notAllowedSpecialCharsNotAcceptedOnSpouseFirstNameField(), "Special chars are allowed in spouse's first name field");
        fsa.assertTrue(notAllowedSpecialCharsNotAcceptedOnSpouseLastNameField(), "Special chars are allowed in spouse's last name field");
    }

    public void validateNotAllowedNumericInFirstLastNameSpouse(FarmersSoftAssert fsa) throws Exception {
        if (!isMarriedCheckboxChecked()) {
            clickOnMarriedOrInDomesticRelationCheckbox();
        }
        waitElementBeVisible(spouseFirstNameInputBox);
        fsa.assertTrue(notAllowedNumericCharsNotAcceptedOnSpouseFirstNameField(), "Numeric chars are allowed in spouse's first name field");
        fsa.assertTrue(notAllowedNumericCharsNotAcceptedOnSpouseLastNameField(), "Numeric chars are allowed in spouse's last name field");
    }

    public void validateNotAllowedSpecialCharInDOBSpouse(FarmersSoftAssert fsa) {
        fsa.assertTrue(notAllowedSpecialCharsNotAcceptedOnDOBField(), "Special chars are allowed in the spouse date of birth field");
    }

    public void validateSpouseSectionIsDisplayed(FarmersSoftAssert fsa){
        fsa.assertEquals(isElementVisible(spouseInputFieldSection, 2), false, "Spouse element is displayed even without checking spouse checkbox.");
    }

    public void validateNotAllowedSpecialCharInCity(FarmersSoftAssert fsa) {
        fsa.assertTrue(notAllowedSpecialCharsNotAcceptedOnCityField(), "Special chars are not allowed in City field");
    }

    public void validateAboutYouSelections(ApplicantAceHome applicant, boolean ratedQuote, FarmersSoftAssert fsa) throws Exception {
        if (ratedQuote) {
            fsa.assertTrue(isFirstNameReadOnly(), "About You page - First name is read-only.");
            fsa.assertTrue(isLastNameReadOnly(), "About You page - Last name is read-only.");
            fsa.assertTrue(isDateOfBirthReadOnly(), "About You page - Date of birth is ready-only.");
            fsa.assertEquals(getDateOfBirth(), "**/**/"+applicant.getDateOfBirth().split("/")[2],
                    "About You page - Partially masked Date of birth value.");
            fsa.assertTrue(isGenderReadOnly(), "About You page - Gender is ready-only.");
            fsa.assertTrue(isMarriedCheckboxReadOnly(), "Married checkbox is read-only.");
        }
        fsa.assertEquals(getFirstName().toLowerCase(), applicant.getFirstName().toLowerCase(), "About You page - First name value.");
        fsa.assertEquals(getLastName().toLowerCase(), applicant.getLastName().toLowerCase(), "About You page - Last name value.");
        fsa.assertEquals(getGenderApplicant(), applicant.getGender(), "About You page - Applicant's gender value.");
        if (!isNoEligibleOccupationState(applicant.getStateCode())) {
            fsa.assertEquals(getOccupation(), applicant.getOccupation(), "About You page - Occupation.");
        }
        if (applicant.getMaritalStatus().equals(MARRIED)) {
            fsa.assertTrue(isMarriedCheckboxChecked(), "Married checkbox is checked.");
            if (ratedQuote) {
                fsa.assertTrue(isMarriedCheckboxReadOnly(), "Married checkbox is read-only.");
                fsa.assertTrue(isSpouseFirstNameReadOnly(), "About You page - Spouse first name is read-only.");
                fsa.assertTrue(isSpouseLastNameReadOnly(), "About You page - Spouse last name is read-only.");
                fsa.assertTrue(isSpouseDateOfBirthReadOnly(), "About You page - Spouse Date of birth is ready-only.");
                fsa.assertEquals(getSpouseDateOfBirth(), "**/**/"+applicant.getSpouseDateOfBirth().split("/")[2],
                        "About You page - Partially masked spouse Date of birth value.");
                fsa.assertTrue(isSpouseGenderReadOnly(), "About You page - Spouse Gender is ready-only.");
            } else {
                fsa.assertFalse(isMarriedCheckboxReadOnly(), "Married checkbox is not read-only.");
            }
            fsa.assertEquals(getSpouseFirstName().toLowerCase(), applicant.getSpouseFirstName().toLowerCase(), "About You page - Spouse first name value.");
            fsa.assertEquals(getSpouseLastName().toLowerCase(), applicant.getSpouseLastName().toLowerCase(), "About You page - Spouse last name value.");
            fsa.assertEquals(getGenderSpouse(), applicant.getSpouseGender(), "About You page - Spouse's gender value.");
            if (!isNoEligibleOccupationState(applicant.getStateCode())) {
                fsa.assertEquals(getSpouseOccupation(), applicant.getOccupation(), "About You page - Spouse Occupation.");
            }
        } else {
            fsa.assertTrue(!isSpouseFirstNameInputBoxDisplayed(), "About you page - Spouse first name input field displayed.");
            fsa.assertTrue(!isSpouseLastNameInputBoxDisplayed(), "About you page - Spouse last name input field displayed.");
            fsa.assertTrue(!isSpouseDateOfBirthInputBoxDisplayed(), "About you page - Spouse date of birth input field displayed.");
            fsa.assertTrue(!isSpouseGenderDisplayed(), "About you page - Spouse date of birth input field displayed.");
            fsa.assertTrue(!isMarriedCheckboxChecked(), "Married checkbox is not checked.");
        }
        if (applicant.isNewlyOwned()) {
            AppStore.Home.AddlCustomerDetails customerDetails = getSessionStorageAppStore().getHome().getAddlCustomerDetails();
            String priorAddressAppStore = EMPTY_STRING;
            if (customerDetails.getPriorOrCurrentAddress() != null) {
                priorAddressAppStore = customerDetails.getPriorOrCurrentAddress().getStreet().trim() + ", " + customerDetails.getPriorOrCurrentAddress().getCity().trim() +
                        ", " + customerDetails.getPriorOrCurrentAddress().getState().trim() + ", " + customerDetails.getPriorOrCurrentAddress().getZip().trim();
            } else if (customerDetails.getAddressStoreObject() != null) {
                priorAddressAppStore = customerDetails.getAddressStoreObject().getNew_address();
                priorAddressAppStore = priorAddressAppStore.matches(".*\\s+,.*") ? priorAddressAppStore.replaceAll("\\s+,", ",") : priorAddressAppStore;
            }
            String priorCurrentAddress = getPriorOrCurrentAddress() + ", " + getPriorOrCurrentAddressCity() + ", " + getPriorOrCurrentAddressState() +
                    ", " + getPriorOrCurrentAddressZip();
            fsa.assertEquals(priorCurrentAddress, priorAddressAppStore, "About You page - Current or prior address field value.");
        }
    }

    public void selectGender(ApplicantAceHome applicantAceHome) {
        try {
            waitElementBeVisibleClickable(genderButton);
            Locator we = locator(pwXPath(GENDER_SELECTION_XPATH + "//span[contains(text(),'" + applicantAceHome.getGender() + "')]"));
            waitAndClickElement(we);
        }catch(Exception e){
            Log.error(" Element not found for applicant for gender selection");
        }
    }

    public String  getGenderApplicant() throws Exception {
        String gender = EMPTY_STRING;
        try {
            Locator genderWe = locator(pwXPath(GENDER_SELECTION_XPATH + "[contains(@class,'mat-button-toggle-checked')]"));
            gender = getTextFromElement(genderWe);
        } catch (PlaywrightException e) {
            Log.info("About You page - Gender was not selected.");
        }
        return gender;
    }

    public boolean isGenderReadOnly() throws Exception {
        boolean readOnly = true;
        for (Locator weBtn : genderButtons.all()) {
            if (!getAttributeData(weBtn, CLASS).contains(DISABLED)) {
                readOnly = false;
                break;
            }
        }
        return readOnly;
    }

    public String getGenderSpouse() throws Exception {
        String gender = EMPTY_STRING;
        try {
            Locator genderWe = locator(pwXPath(SPOUSE_GENDER_SELECTION_XPATH + "[contains(@class,'mat-button-toggle-checked')]"));
            gender = getTextFromElement(genderWe);
        } catch (PlaywrightException e) {
            Log.info("About You page - Spouse gender was not selected.");
        }
        return gender;

    }

    public void setGenderSpouse(ApplicantAceHome applicantAceHome) {
        try {
            List<Locator> we = locators(pwXPath(SPOUSE_GENDER_SELECTION_XPATH + "//span[contains(text(),'" + applicantAceHome.getSpouseGender() + "')]"));
            waitAndClickElement(we.get(0));
        } catch (Exception e) {
            Log.error(" Element not found for spouse for gender selection");

        }
    }

    public boolean isSpouseGenderReadOnly() throws Exception {
        boolean readOnly = true;
        for (Locator weBtn : spouseGenderButtons.all()) {
            if (!getAttributeData(weBtn, CLASS).contains(DISABLED)) {
                readOnly = false;
                break;
            }
        }
        return readOnly;
    }

    public void validateADA(String lobType) throws Exception {
        clickOnMarriedOrInDomesticRelationCheckbox();
        clickContinueButton();
        performADATesting(this.getClass().getSimpleName(), MARKETING_IT, lobType);
        if (isElementDisplayed(eligibleOccupationAddButton,2)) {
            clickEligibleOccupationButton(true);
            performADATesting(this.getClass().getSimpleName() + "_PrimaryOccupationsSideSheet", MARKETING_IT, lobType);
            clickCloseIcon();
        }
        clickOnMarriedOrInDomesticRelationCheckbox();
    }

    public void validateDataNotSaved(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        waitForPageToBeReady();
        fsa.assertEquals(getTextFromElement(firstNameInputBox), EMPTY_STRING, "First Name verification");
        fsa.assertEquals(getTextFromElement(lastNameInputBox), EMPTY_STRING, "Last Name verification");
        fsa.assertEquals(getTextFromElement(dateOfBirthInputBox), EMPTY_STRING, "DOB verification");
        fsa.assertEquals(getGenderApplicant(), EMPTY_STRING, "Gender not selected");
        fsa.assertEquals(getTextFromElement(emailAddressInput), EMPTY_STRING, "Email address is empty");
        fsa.assertEquals(getTextFromElement(phoneNumberInput), EMPTY_STRING, "Phone number is empty");

        if (!(selectedOccupation.count() == 0)) {
            fsa.assertEquals(getTextFromElement(selectedOccupation.nth(0)), applicant.getOccupation(), "Selected applicant's occupation is saved");
        }

        if (applicant.getMaritalStatus().equals(MARRIED) && isMarriedCheckboxChecked()) {
            fsa.assertEquals(getTextFromElement(spouseElements.nth(0)), EMPTY_STRING, "Spouse First Name verification");
            fsa.assertEquals(getTextFromElement(spouseElements.nth(1)), EMPTY_STRING, "Spouse Last Name verification");
            fsa.assertEquals(getTextFromElement(spouseElements.nth(2)), EMPTY_STRING, "Spouse DOB verification");
            fsa.assertEquals(getGenderSpouse(), EMPTY_STRING, "Spouse gender was not selected");
            if (selectedOccupation.count() > 1) {
                fsa.assertEquals(getTextFromElement(selectedOccupation.nth(1)), applicant.getOccupation(), "Selected spouse's occupation is saved");
            }
        }
    }

    public boolean isOnAboutYouPageHome(boolean longWait) {
        int timeout = longWait ? Property.PAGELOADTIMEOUT : 3;
        return isElementVisible(firstNameInputBox, timeout);
    }

    public void clickContinueOnHRCAboutYouPage() throws Exception {
        if(getLobTypeFromAppStore().equalsIgnoreCase(RENTERS)){
            clickAgreeAndSubmitButton();
        }else{
            waitAndClickElement(continueButton);
        }
    }
}
