/**
=============================================
* Author:	Zhabiz Sonee
* Create date:	02/01/2017
=============================================
*/
package com.farmers.ffq.dataproviderframework;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

class ExcelReader {

	private ExcelReader() {
		throw new IllegalStateException("Utility class");
	}

	public static <T extends DataObjectBase> List<T> read(Class<?> targetType, String fileName, String id) throws Exception {
		HSSFSheet sheet = getSheet(targetType, fileName);
		List<T> results = new ArrayList<>();
		int numberOfDataRows = sheet.getPhysicalNumberOfRows() - 1;
		for (int i = 1; i <= numberOfDataRows; i++) {
			@SuppressWarnings("unchecked")
			T result = (T) targetType.getDeclaredConstructor().newInstance();
			ensureIdSet(id, sheet, i, result);
			Field[] fields = targetType.getFields();
			for (int j = 0; j < fields.length; j++) {
				processField(fileName, sheet, i, result, fields[j]);
			}
			if (result.getId().equals(id) || id == null) {
				results.add(result);
			}
		}
		return results;
	}

	private static <T extends DataObjectBase> void processField(String fileName, HSSFSheet sheet, int i, T result, Field field) throws Exception {
		if (List.class.isAssignableFrom(field.getType())) {
			Type type = field.getGenericType();
			if (type instanceof ParameterizedType) {
				ParameterizedType parameterizedType = (ParameterizedType) type;
				Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
				String actualTypeName = actualTypeArguments[0].getTypeName();
				Class<?> fs = Class.forName(actualTypeName);
				List<DataObjectBase> additionalResults = read(fs, fileName, result.getId());
				field.set(result, additionalResults);
			}
		} else {
			Object value = deserializeType(sheet, i, field);
			field.set(result, value);
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private static Object deserializeType(HSSFSheet sheet, int i, Field field) throws ParseException{
		String fieldName = field.getName();
		String cellValue = getCellValue(sheet, i, fieldName);
		Class<?> type = field.getType();
		Object value = null;
		if (type.equals(boolean.class)) {
			value = Boolean.parseBoolean(cellValue);
		} else if (type.equals(int.class)) {
			value = Integer.parseInt(cellValue);
		} else if (type.equals(String.class)) {
			value = cellValue;
		} else if (type instanceof Class && ((Class<?>) type).isEnum()) {
			value = Enum.valueOf((Class<Enum>) field.getType(), cellValue);
		} else if (type.equals(Date.class)) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("MMddyyyy");
			value = dateFormat.parse(cellValue);
		}
		return value;
	}

	private static <T extends DataObjectBase> void ensureIdSet(String id, HSSFSheet sheet, int rowNumber, T result) {
		if (id != null) {
			result.setId(id);
		} else {
			String cellValue = getCellValue(sheet, rowNumber, "id");
			result.setId(cellValue);
		}
	}

	private static String getCellValue(HSSFSheet sheet, int rowNumber, String columnName) throws IllegalArgumentException {
		int cellNumber = getCellNumberByColumnName(sheet, columnName);
		HSSFRow row = sheet.getRow(rowNumber);
		HSSFCell cell = row.getCell(cellNumber);
		DataFormatter formatter = new DataFormatter();
		return formatter.formatCellValue(cell);
	}

	private static int getCellNumberByColumnName(HSSFSheet sheet, String columnName) throws IllegalArgumentException {
		HSSFRow row = sheet.getRow(0);
		int firstCellNumber = row.getFirstCellNum();
		int lastCellNumber = row.getLastCellNum();
		int ret = -1;
		for (int i = firstCellNumber; i < lastCellNumber; i++) {
			HSSFCell cell = row.getCell(i);
			String headerValue = cell.getStringCellValue();
			if (headerValue.equals(columnName)) {
				ret = i;
				break;
			}
		}
		if (ret == -1) {
			throw new IllegalArgumentException("Column '" + columnName + "' not found in sheet '" + sheet.getSheetName() + "'.");
		}
		return ret;
	}

	private static HSSFSheet getSheet(Class<?> targetType, String fileName) throws NoSuchFieldException, IOException {

		File file = new File(fileName);
		FileInputStream fileInputStream = new FileInputStream(file);
		HSSFWorkbook workbook = new HSSFWorkbook(fileInputStream);
		String dataObjectName = targetType.getSimpleName();
		HSSFSheet sheet = workbook.getSheet(dataObjectName);
		workbook.close();
		if (sheet == null) {
			throw new NoSuchFieldException("Sheet '" + dataObjectName + "' not found.");
		}
		return sheet;
	}
}
