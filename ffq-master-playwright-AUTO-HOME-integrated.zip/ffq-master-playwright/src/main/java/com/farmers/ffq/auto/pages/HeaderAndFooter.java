package com.farmers.ffq.auto.pages;





import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import lombok.Getter;
import org.joda.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter
public class HeaderAndFooter extends AutoBasePage {

        protected Locator famersHeaderLogo = locator(pwXPath(FARMERS_LOGO_XPATH));

        private Locator logoElementsInHeader = locator(pwXPath("//app-basic-header//img"));

        private Locator koHeaderFarmersLogo = locator(pwXPath("//app-basic-header//img[@alt='Farmers logo']"));

        private Locator listOfDesktopSteps = locator(pwXPath("//div[@class='tui-desktop-nav-stepper']//span[2]"));

        private Locator listOfMobileSteps = locator(pwXPath("//div[@class='tui-mobile-nav-stepper']//span[2]"));

    private static final String PHONE_NUMBER_GROUP_XPATH = "//div[@class='tui-contact-icons-wrapper']";
        private Locator phoneIcon = locator(pwXPath(PHONE_NUMBER_GROUP_XPATH + "//mat-icon"));

        private Locator farmersPhoneNumber = locator(pwXPath(PHONE_NUMBER_GROUP_XPATH + "//span"));

    private static final String DESKTOP_FOOTER_GROUP_XPATH = "//div[@class='tui-oneui-footer-desktop']";
        private Locator famersDesktopFooterLogo = locator(pwXPath(DESKTOP_FOOTER_GROUP_XPATH + "//img[@alt='Farmers logo']"));

        private Locator listOfDesktopFooterLinks = locator(pwXPath("//div[@class='tui-oneui-footer-links']//section[@role='list']/a"));

        private Locator desktopFooterDisclaimer = locator(pwXPath("//div[contains(@class,'footer-disclaimer-container tui')]"));

        private Locator mobileFooterDisclaimer = locator(pwXPath("//div[contains(@class,'footer-disclaimer-container-mobile')]"));

        private Locator desktopCopyright = locator(pwXPath("//div[contains(@class, 'tui-oneui-footer-copyright') and not(contains(@class, 'mobile'))]"));

        private Locator mobileCopyright = locator(pwXPath("//div[@class='tui-oneui-footer-copyright-mobile tui-link-text-3']"));

        private Locator listOfExternalLinks = locator(pwXPath("//div[@class='tui-oneui-footer-socials-and-downloads-container']/a"));

    public HeaderAndFooter() throws Exception {
        super();
    }

    public void desktopHeaderValidation() throws Exception {
        List<String> stepLabels = new ArrayList<>(Arrays.asList(ENTER_INFO, REVIEW_QUOTE, PURCHASE));
        //Validate content and location
        waitElementBeVisible(famersHeaderLogo);
        waitElementBeVisible(phoneIcon);
        waitElementBeVisible(farmersPhoneNumber);
        for (int index = 0; index < stepLabels.size(); index++) {
            String stepLabel = getTextFromElement(listOfDesktopSteps.nth(index));
            testStepAssert(stepLabel, stepLabels.get(index), "Validate navigation bar label. Expected: (" + stepLabels.get(index) + ") And Actual: (" + stepLabel + ")");
        }
        testStepAssert(getTextFromElement(farmersPhoneNumber), "1-800-206-9469", "Validate navigation bar Farmers Phone Number.Expected: (1-800-206-9469) and Actual: (" + getTextFromElement(farmersPhoneNumber) + ")");
    }

    public void desktopFooterValidation() throws Exception {
        List<String> footerLinkLabels = new ArrayList<>(Arrays.asList("Personal information use", "Digital accessibility", "Terms of use", "Privacy center",
                "Notice of information practices", "Do not sell or share my personal information"));
        //Validate content and location
        waitElementBeVisible(famersDesktopFooterLogo);
        for (int index = 0; index < footerLinkLabels.size(); index++) {
            testStepAssert(getTextFromElement(listOfDesktopFooterLinks.nth(index)), footerLinkLabels.get(index), "Validate footer label.Expected: (" + footerLinkLabels.get(index) + ") And Actual: (" + getTextFromElement(listOfDesktopFooterLinks.nth(index)) + ")");
        }
        LocalDateTime localTime = LocalDateTime.now();
        String year = String.valueOf(localTime.getYear());
        testStepAssert(getTextFromElement(desktopCopyright), String.format("Copyright \u00a9 %s Farmers Insurance Group", year), "Validate copyright footer label.Expected: (" + String.format("Copyright \u00a9 %s Farmers Insurance Group", year) + ") And Actual: (" + getTextFromElement(desktopCopyright) + ")");
        verifyListOfLinks(listOfDesktopFooterLinks.all(), getListWithFooterLinksURLsAndPageTitles());
        verifyListOfLinks(listOfExternalLinks.all(), getListWithExternalLinksURLsAndPageTitles());
    }

    public boolean isPhoneNumberCorrect(boolean quoteComplete) {
        boolean isMobileView = Arrays.asList("apple", "android").contains(Property.getTestProperty("browser"));
        String expectedPhoneNumber = "1-800-206-9469";
        if (quoteComplete) {
            if (isMobileView) {
                expectedPhoneNumber = "1-877-528-9738";
            } else {
                expectedPhoneNumber = "1-833-259-1611";
            }
        } else {
            if (isMobileView) {
                expectedPhoneNumber = "1-800-420-9008";
            }
        }
        return isExpectedTextDisplayed(farmersPhoneNumber, expectedPhoneNumber);
    }

    public boolean isPhoneNumberCorrectOnBindPages() throws Exception {
        String expectedPhoneNumber = Arrays.asList("apple", "android").contains(Property.getTestProperty("browser")) ?
                "1-888-353-3730" : "1-800-218-4309";
        if (isOnBristolWest()) {
            return true;
        }
        return isExpectedTextDisplayed(farmersPhoneNumber, expectedPhoneNumber);
    }

    @SuppressWarnings("unchecked")
    public <T extends AutoBasePage> T selectNavigationStep(String quoteStep) throws Exception {
        List<Locator> steppers = isUseMobileViewEnabled() ? listOfMobileSteps.all() : listOfDesktopSteps.all();
        switch (quoteStep) {
            case ENTER_INFO:
                waitAndClickElement(steppers.get(0));
                return (T) new WhoShouldWeInsurePage();
            case REVIEW_QUOTE:
                waitAndClickElement(steppers.get(1));
                return (T) new QuoteSummaryAutoPage();
            //undetermined as of yet where this leads to
            case PURCHASE:
                waitAndClickElement(steppers.get(2));
                return (T) null;
            default:
                throw new IllegalArgumentException(quoteStep + " does not exist");
        }
    }

    private LinkedHashMap<String, String> getListWithFooterLinksURLsAndPageTitles() {
        LinkedHashMap<String, String> urlsAndTitles = new LinkedHashMap<>();
        urlsAndTitles.put("personaluse", "Privacy Statement : Farmers Insurance");
        urlsAndTitles.put("accessibility", "Digital Accessibility | Farmers Insurance");
        urlsAndTitles.put("terms-of-use", "Terms of Use | Farmers Insurance");
        urlsAndTitles.put("privacy-center", "Privacy Center : Farmers Insurance");
        urlsAndTitles.put("information-practices", "Notice of Information Practices - General | Farmers Insurance");
        urlsAndTitles.put("donotsell", "Privacy Statement : Farmers Insurance");
        return urlsAndTitles;
    }

    private LinkedHashMap<String, String> getListWithExternalLinksURLsAndPageTitles() {
        LinkedHashMap<String, String> urlsAndTitles = new LinkedHashMap<>();
        urlsAndTitles.put("www.facebook.com/FarmersInsurance", Property.getBrowser().equals("safari") || Property.getBrowser().equals("firefox") ? "Farmers Insurance" : "Farmers Insurance | Facebook");
        urlsAndTitles.put("https://x.com/wearefarmers/", "Farmers Insurance (\u0040WeAreFarmers) / X");
        urlsAndTitles.put("www.instagram.com/thisisfarmers", "Instagram");
        urlsAndTitles.put("www.linkedin.com/company/farmers-insurance", "| LinkedIn");
        urlsAndTitles.put("apps.apple.com/us/app/farmers-insurance", "Farmers Insurance Mobile on the App Store");//Bhuvaneshwaran 3/29-removed -inc as change in url
        urlsAndTitles.put("play.google.com/store/apps/details?id=com.farmers.ifarmers", "Farmers Insurance Inc. - Apps on Google Play");
        return urlsAndTitles;
    }

    public boolean isKOFarmersHeaderLogoPresent() {
        return isElementVisible(koHeaderFarmersLogo, 5);
    }

    public boolean isBWLogoPresentInTheFooter() throws Exception {
        String bwLogoXpath = isUseMobileViewEnabled() ? "//div[@class='tui-oneui-footer-mobile']//img[@alt='Bristol West logo']" : "//div[@class='tui-oneui-footer-desktop']//img[@alt='Bristol West logo']";
        Locator bwLogoInFooter = locator(pwXPath(bwLogoXpath));
        scrollElementToMiddle(bwLogoInFooter);
        return isElementVisible(bwLogoInFooter, 1);
    }

    public boolean isFarmersLogoPresentInFooter() throws Exception {
        String bwLogoXpath = isUseMobileViewEnabled() ? "//div[@class='tui-oneui-footer-mobile']//img[@alt='Farmers logo']" : "//div[@class='tui-oneui-footer-desktop']//img[@alt='Farmers logo']";
        return isElementDisplayed(pwXPath(bwLogoXpath));
    }

    public void isHeaderPhoneNumberCorrect(String phoneNumber, FarmersSoftAssert fsa) throws Exception {
        if (isUseMobileViewEnabled()) {
            Locator phoneIcon = locator(pwXPath(PHONE_NUMBER_GROUP_XPATH + "//a"));
            fsa.assertEquals(getAttributeData(phoneIcon, HREF).replaceAll("\\D", EMPTY_STRING), phoneNumber.replaceAll("\\D", EMPTY_STRING), "Phone number is not correct");
        } else {
            Locator phoneNumberDisplayed = locator(pwXPath(PHONE_NUMBER_GROUP_XPATH + "//span"));
            fsa.assertEquals(getTextFromElement(phoneNumberDisplayed).replaceAll("\\D", EMPTY_STRING), phoneNumber.replaceAll("\\D", EMPTY_STRING), "Phone number is not correct on the header");
        }
    }

    public void validateBdqFooterAndHeader(FarmersSoftAssert fsa, String phoneNumber, BasePage page) throws Exception {
        fsa.assertTrue(isOnBristolWest(), "BW logo is displayed on" + page.getClass().getSimpleName());
        fsa.assertTrue(!isOnFarmers(), "Farmers logo is not displayed on " + page.getClass().getSimpleName());
        fsa.assertTrue(!isFarmersLogoPresentInFooter(), "Farmers logo is not displayed in the footer of" + page.getClass().getSimpleName());
        isHeaderPhoneNumberCorrect(phoneNumber, fsa);
        fsa.assertTrue(isBWLogoPresentInTheFooter(), "BW logo present in the footer of " + page.getClass().getSimpleName());
        fsa.assertTrue(isCopyRightBrandCorrectForBW(), "Copyright text verified on " + page.getClass().getSimpleName());
        fsa.assertTrue(isFooterDisclaimerCorrectForBW(), "Footer disclaimer verified on " + page.getClass().getSimpleName());
        fsa.assertTrue(!isElementPresentByXPath("//img[contains(@alt,'App Store')]"), "App Store should not be visible in the bdq flow on " + page.getClass().getSimpleName());
        fsa.assertTrue(!isElementPresentByXPath("//img[contains(@alt,'Google Play')]"), "Google play should not be visible in the bdq flow on " + page.getClass().getSimpleName());
        scrollToTopOfPage();
    }

    private boolean isCopyRightBrandCorrectForBW() {
        String expected = LocalDate.now().getYear() + SPACE + "Bristol West. All rights reserved";
        Locator copyrightElement = isUseMobileViewEnabled()? mobileCopyright : desktopCopyright;
        return isExpectedTextContainedInElement(copyrightElement, expected);
    }

    private boolean isFooterDisclaimerCorrectForBW() {
        Locator disclaimerElement = isUseMobileViewEnabled()? mobileFooterDisclaimer : desktopFooterDisclaimer;
        return isExpectedTextDisplayed(disclaimerElement, "Bristol West is a proud member of the Farmers Insurance Group of Companies, one of the nation's largest insurer groups that offers a wide variety of home, life, specialty, commercial and auto insurance products and services across the United States.");
    }

}
