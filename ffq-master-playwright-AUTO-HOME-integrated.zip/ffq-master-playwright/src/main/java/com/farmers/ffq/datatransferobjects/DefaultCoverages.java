package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DefaultCoverages {
    private String stateCode; //a
    private String coverageAmount; //b
    private String ownership; //c
    private String usedForRideshare; //d
    private String umbrella; //e
    private String bodilyInjury; //f
    private String comprehensive; //g
    private String collision; //h
    private String lossOfUse; //i
    private String medicalCoverage; //j
    private String propertyDamageLiability; //k
    private String rentalCoverage; //l
    private String roadsideAssistance; //m
    private String glassCoverage; //n
    private String uninsuredUnderinsuredMotorist; //o
    private String vehicleReplacementPlus; //p
    private String rideshareCoverage; //q
    private String accidentForgiveness; //r
    private String accidentalDeathDisablingInjury; //s
    private String decliningDeductible; //t
    private String rentalAlternative; //u
    private String umpdNoCollision; //v
    private String pip; //w
    private String medicalAndHospitalBenefits; //x
    private String deathAndDismemberment; //y
    private String incomeDisability; //z
    private String incomeLossBenefits;
    private String optionalBodilyInjury;
    private String uninsuredMotoristElection;
    private String umUimPD;
    private String towingAndLaborCosts;
    private String umUIMBIConversion;
    private String umpdWithCollision;
    private String permissiveUserLimitOfLiability;
    private String uninsuredMotoristBodilyInjury;
    private String underInsuredMotoristBodilyInjury;
    private String limitedCollision;
    private String substituteTransportation;
    private String acquisitionExpense;
    private String operationsExpense;


    //BW related columns
    private String autoLoanLease;
    private String underinsuredMotorist;
    private String uninsuredMotorist;
    private String umBodilyInjury;
    private String umUIMBodilyInjury;
    private String excessMedicalPayments;
    private String ppi; 
    private String uninsuredMotoristSelection;
}
