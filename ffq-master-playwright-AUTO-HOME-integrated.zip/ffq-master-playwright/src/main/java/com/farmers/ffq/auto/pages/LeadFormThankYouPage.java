package com.farmers.ffq.auto.pages;


import com.microsoft.playwright.Locator;
import com.farmers.ffq.utils.FarmersSoftAssert;

public class LeadFormThankYouPage extends AutoBasePage {

        private Locator pageTitle = locator(pwCss("div[class='thank-you__title']>h1"));

        private Locator pageSubtitle = locator(pwCss("div[class='tui-body thank-you__subtitle']>p"));

        private Locator quoteNumberText = locator(pwCss("div[class='thank-you__quote-number ng-star-inserted']>span[class='tui-body-bold']"));

        private Locator quoteNumberElement = locator(pwCss("div[class='thank-you__quote-number ng-star-inserted']>span[class='tui-body']"));

        private Locator needMoreHelp = locator(pwXPath("//div[contains(text(),'Need more help?')]"));

        private Locator youCanCallCustomerService = locator(pwXPath("//div[contains(text(),'You can call customer service at')]"));

        private Locator tollNumber = locator(pwXPath("//div[contains(@class,'toll-free-number')]"));

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public LeadFormThankYouPage() throws Exception {
    }

    public void validateLeadFormThankYouPageContent(FarmersSoftAssert fsa, boolean isMobile) throws Exception {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageTitle)), "Thank you for choosing Farmers Insurance\u00ae", "Thank you page title check");
        fsa.assertEquals(getTextFromElement(pageSubtitle), "Your request has been submitted.", "Thank you page subtitle check");
        fsa.assertTrue(needMoreHelp.isVisible(), "Need more help link displayed");
        fsa.assertTrue(youCanCallCustomerService.isVisible(), "Call Customer service link displayed");
        String expectedPhoneNumber = isUseMobileViewEnabled() || isMobile? "1-888-587-2121" : "1-888-422-1618";
        fsa.assertEquals(getTextFromElement(tollNumber), expectedPhoneNumber, "Displayed phone number check");

        // Ace Auto and Bind - Validate that Quote Number is removed from lead thank you page for Auto LOBValidate
        fsa.assertFalse(getTextFromElement(locator(pwTag("app-thank-you"))).contains("quote number:"), "Quote number should not be displayed in the content");

    }
}
