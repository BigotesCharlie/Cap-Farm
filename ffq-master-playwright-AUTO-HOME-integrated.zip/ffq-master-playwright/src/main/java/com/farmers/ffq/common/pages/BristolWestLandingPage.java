package com.farmers.ffq.common.pages;



import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.framework.report.Log;
public class BristolWestLandingPage extends AutoBasePage {

        private Locator pageHeader = locator(pwId("bw-main-content"));

        private Locator zipCodeInput = locator(pwXPath("//div[@class='hero-split__input-field']//input"));
        private Locator zipCodeInputMobileView = locator(pwXPath("//div[@class='hero-split__mobile-input-inner']//input"));
        private Locator startQuoteButton = locator(pwXPath("//button[@class='hero-split__button start-quote-btn']"));

        private Locator startQuoteButtonMobileView = locator(pwXPath("//button[@class='hero-split__mobile-button start-quote-btn']"));
    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public BristolWestLandingPage() throws Exception {
    }


    private boolean isOnBristolWestLandingPage() {
        return isElementVisible(pageHeader, 5);
    }

    public void launchBristolWestLandingPage(String url, String zipCode) throws Exception {
        if (isUseMobileViewEnabled()) {
            setBrowserDimensionToMobileBreakPoint();
        }

        navigate(url);
        isOnBristolWestLandingPage();
        Log.info("User is on the Landing Page for BW");
        fillOutZipCodeInputField(zipCode);
        clickStartQuoteButton();
    }

    private void fillOutZipCodeInputField(String zipCode) throws Exception {
        if(isUseMobileViewEnabled()) {
            sendKeysToElement(zipCodeInputMobileView, zipCode);
        }else{
            sendKeysToElement(zipCodeInput, zipCode);
        }
    }

    private void clickStartQuoteButton() {
        if(isUseMobileViewEnabled()) {
            clickElement(startQuoteButtonMobileView);
        }else{
            clickElement(startQuoteButton);
        }
    }
}
