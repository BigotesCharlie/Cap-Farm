package com.farmers.ffq.homevideoflow.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public final class LandingPage extends BaseHomePage {
    public LandingPage(Page page) { super(page); }
    
    public void startQuote() {
        // Select Home from the property type options (mat-list-option)
        Locator homeOption = page.locator("mat-list-option[title*='Home']");
        if (homeOption.count() == 0) {
            homeOption = page.locator("mat-list-option").filter(new Locator.FilterOptions().setHasText("Home"));
        }
        if (homeOption.count() > 0) {
            homeOption.first().click();
            page.waitForTimeout(500);
        }
        
        // Fill in ZIP code
        Locator zipInput = page.getByLabel("Zip code", new Page.GetByLabelOptions().setExact(false));
        if (zipInput.count() > 0) {
            zipInput.fill("55952");
            page.waitForTimeout(300);
        }
        
        // Click Start my Quote button
        Locator quote = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Start my Quote").setExact(false));
        if (quote.count() == 0) {
            quote = page.getByText("Start my Quote", new Page.GetByTextOptions().setExact(false));
        }
        if (quote.count() > 0) {
            quote.first().click();
        } else {
            throw new IllegalStateException("Start my Quote button not found on landing page @ " + page.url());
        }
        
        // Wait for page transition—the next meaningful state heading should appear
        page.waitForFunction(
                "() => {" +
                        "const text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();" +
                        "return text.includes('what type of property is it')" +
                        " || text.includes('address')" +
                        " || text.includes('your home quality grade')" +
                        " || text.includes('here is what we have so far')" +
                        " || text.includes('here what we have so far')" +
                        " || text.includes('additional home information')" +
                        " || text.includes('about you');" +
                        "}"
        );
    }
}
