package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@JsonIgnoreProperties
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class BusinessStore {

    private Data data;

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @lombok.Data
    public static class Data {
        private AgentData agentData;

        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @lombok.Data
        public static class AgentData {
        	private Agent agent;
        	@JsonIgnoreProperties
        	@JsonInclude(JsonInclude.Include.NON_NULL)
        	@lombok.Data
        	public static class Agent {
        		private String firstName;
        		private String lastName;
        		private Address address;
        		private Communication communication;
                private String agentId;
                private String agentImageUrl;
                private String reference;
                private String assign;

                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
        		public static class Address{
        			private String city;
        			private String state;
        			private String zip;
        			private String apartment;
        			private String street;
        			private boolean notEmptyStreetCityStateZip;
        		}
                @JsonIgnoreProperties
                @JsonInclude(JsonInclude.Include.NON_NULL)
                @lombok.Data
                public static class Communication{
                    private EmailId emailId;
                    private PhoneNumber phoneNumber;

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class PhoneNumber{
                        private String phoneNumber;
                    }

                    @JsonIgnoreProperties
                    @JsonInclude(JsonInclude.Include.NON_NULL)
                    @lombok.Data
                    public static class EmailId{
                        private String emailAddress;
                    }
                }
        	}
        }
    }

}
