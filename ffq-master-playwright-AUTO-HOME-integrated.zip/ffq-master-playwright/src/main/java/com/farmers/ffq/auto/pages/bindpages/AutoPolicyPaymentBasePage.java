package com.farmers.ffq.auto.pages.bindpages;





import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.datatransferobjects.AppStore.VerifyResponse.PaymentSchedule;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.ONE_PAY;
import static com.farmers.ffq.utils.GlobalVariables.VALUE;

public class AutoPolicyPaymentBasePage extends PolicyPaymentBasePage {
    protected static final String AUTO_POLICY_PAYMENT_HEADER = "Auto policy payment";
        protected Locator autoPolicyPaymentHeader = locator(pwXPath("//h1[contains(text(), '" + AUTO_POLICY_PAYMENT_HEADER + "')]"));

    private static final String FEES = "Fees";
        protected Locator feeSideBarHeader = locator(pwXPath("//p[contains(text(), '" + FEES + "')]"));

    public final String AUTO_MEMBERSHIP_FEE_MESSAGE = "A membership fee per vehicle is applied for new auto policies and new vehicles added to your policy. It covers the administrative costs associated with you becoming a member of the insurance exchange and the issuance of your policy.";
        protected Locator membershipFeeMessageSideBar = locator(pwXPath("//p[contains(text(), 'A membership fee per vehicle is applied ')]"));

    public static final String POLICY_POLICY_FEE_MESSAGE = "A policy fee per vehicle is applied for new auto policies and new vehicles added to your policy. This is for administrative costs associated with writing your new policy.";
        protected Locator policyFeeMessageSideBar = locator(pwXPath("//p[contains(text(), 'A policy fee per vehicle is applied for new auto')]"));

    public static final String VEHICLE_FEE_MESSAGE = "A fee per vehicle is applied for new auto policies and new vehicles added to your policy. This is for administrative costs associated with writing your new policy.";
        protected Locator vehicleFeeMessageSideBar = locator(pwXPath("//p[contains(text(), 'A fee per vehicle is applied for new auto')]"));

    private static final String SIX_MONTH_TERM_PAYMENT = "6-month term payment";
        protected Locator sixMonthTermPayment = locator(pwXPath("//span[contains(text(),'" + SIX_MONTH_TERM_PAYMENT + "')]"));

        private Locator sixTermPriceSubHeader = locator(pwXPath("//span[contains(text(), '6-month term price')]"));

        protected Locator fees = locator(pwXPath("//span[contains(text(),'" + FEES + "')]"));

    private static final String SET_UP_PAYMENT_METHOD = "Set up payment method";
        private Locator setUpPaymentMethodButton = locator(pwXPath("//button[contains(text(),'" + SET_UP_PAYMENT_METHOD + "')]"));

        private Locator addPaymentMethodContainerCloseIcon = locator(pwXPath("//mat-icon[contains(text(), 'close')]"));

        private Locator addPaymentMethodDialogContainer = locator(pwXPath("//mat-dialog-container[@aria-labelledby='addPaymentHeading']"));

    private static final String PAYMENTUS_MANAGE_PAYMENT = "Paymentus Manage Payments";
        private Locator paymentUsIframe = locator(pwXPath("//iframe[@title = '" + PAYMENTUS_MANAGE_PAYMENT + "']"));

    private static final String ADD_BUTTON = "ADD";
        private Locator addButton = locator(pwXPath("//button[text() = '" + ADD_BUTTON + "']"));

    private static final String ADD_PAYMENT_METHOD_LABEL = "Add payment method";
        private Locator addPaymentMethodLabel = locator(pwXPath("//span[text() = '" + ADD_PAYMENT_METHOD_LABEL + "']"));

    private static final String PAPERLESS_TERMS_OF_USE = "Paperless Terms of Use";
        private Locator paperlessTermsOfUseLink = locator(pwXPath("//a[contains(text(), '" + PAPERLESS_TERMS_OF_USE + "')]"));

    private static final String INFORMATION_STORAGE_AUTHORIZATION = "Information Storage Authorization";
        private Locator informationStorageAuthorizationLink = locator(pwXPath("//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]"));

    private static final String PAYMENT_AUTHORIZATION = "Payment Authorization Terms & Conditions.";
        private Locator paymentAuthorizationLink = locator(pwXPath("//a[contains(text(), '" + PAYMENT_AUTHORIZATION + "')]"));


    List<Locator> listOfLinksToClick = Arrays.asList(paperlessTermsOfUseLink, informationStorageAuthorizationLink, paymentAuthorizationLink);
    private static final String TERMS_AND_CONDITIONS_TITLE = "Terms of Use | Farmers Insurance";
    private static final String PAYMENT_AUTHORIZATION_TITLE = "Payment Authorization Terms and Conditions | Farmers Insurance";
    private static final String INFORMATION_STORAGE_AUTHORIZATION_TITLE = "Payment Card Storage Terms & Conditions | Farmers Insurance";

    private static final List<String> listOfTabTitles = Arrays.asList(TERMS_AND_CONDITIONS_TITLE, INFORMATION_STORAGE_AUTHORIZATION_TITLE, PAYMENT_AUTHORIZATION_TITLE);


    private static final String BY_CLICKING_COMPLETER_PURCHASE = "String clicking \"Complete purchase\" below:";
        private Locator byClickingCompletePurchaseLabel = locator(pwXPath("//div[contains(text(), '" + BY_CLICKING_COMPLETER_PURCHASE + "')]"));

    private static final String READ_AND_AGREED_TO_THE_BULLET_ONE = "I confirm that I have read and agree to the Paperless Terms of Use; and";
        private Locator readAndAgreedToTheBulletPointOne = locator(pwXPath("//a[contains(text(), '" + PAPERLESS_TERMS_OF_USE + "')]/parent::p"));

    public static final String IF_DO_NOT_AGREE_WITH_TERMS = "If you do not agree with the Terms and Conditions above and/or have any questions, please contact your agent or Farmers Direct Sales Center to complete this transaction. You can always change your Paperless and Automatic Payment settings for future transactions by logging in to your Farmers.com account.";
        private Locator ifDoNotAgreeWithTermsAndConditionLabel = locator(pwXPath("//p[contains(text(), 'If you do not agree with the Terms and Conditions above ')]"));

    private static final String PAYMENT_METHOD_ALREADY_ADDED_ERROR = "You have already saved this payment method. Cannot save duplicate.";
        private Locator paymentMethodAlreadyAdded = locator(pwXPath("//li[@id='profile']"));

    private static final String READ_AND_AGREED_TO_THE_BULLET_TWO_MONTHLY_PAY = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries (\"Farmers\") to initiate One-Time and Automatic Payment processes.";
        private Locator readAndAgreedToTheBulletPointTwoMonthlyPay = locator(pwXPath("//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p"));

    private static final String READ_AND_AGREED_TO_THE_BULLET_TWO = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries (\"Farmers\") to initiate:";
        private Locator readAndAgreedToTheBulletPointTwo = locator(pwXPath("//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p"));

    private static final String CARD_NUMBER_LABEL = "Card Number";
        private Locator cardNumberLabel = locator(pwXPath("//label[text() = '" + CARD_NUMBER_LABEL + "']"));

    private static final String EXPIRATION_DATE_LABEL = "Expiration Date";
        private Locator expirationDateLabel = locator(pwXPath("//label[text() = '" + EXPIRATION_DATE_LABEL + "']"));

    private static final String CARD_SECURITY_CODE_LABEL = "Card Security Code (CVV)";
        private Locator cardSecurityCodeLabel = locator(pwXPath("//label[text() = '" + CARD_SECURITY_CODE_LABEL + "']"));

    private static final String BILLING_ZIP_CODE_LABEL = "Billing ZIP Code";
        private Locator billingZipCodeLabel = locator(pwXPath("//label[text() = '" + BILLING_ZIP_CODE_LABEL + "']"));

        private Locator visaCardIconInARow = locator(pwXPath("//div[contains(@class,'methodVisa')]"));

        private Locator masterCardIconInARow = locator(pwXPath("//div[contains(@class,'methodDiscover')]"));


        private Locator discoverCardIconInARow = locator(pwXPath("//div[contains(@class,'methodDiscover')]"));

        private Locator amexCardIconInARow = locator(pwXPath("//div[contains(@class,'methodAmex')]"));

    private static final String NAME_ON_CARD_LABEL = "Name On Card";
        private Locator nameOnCardLabel = locator(pwXPath("//label[text() = '" + NAME_ON_CARD_LABEL + "']"));

        private Locator nameOnCardInPutField = locator(pwXPath("//input[@id='cardHolderField']"));

    private static final String ENTER_YOUR_NAME_ERROR = "Please enter your name exactly as it appears on your card.";
        private Locator enterYourNameOnCardError = locator(pwXPath("//span[contains(text(),'" + ENTER_YOUR_NAME_ERROR + "')]"));


    private static final String ENTER_VALID_CARD_NUMBER_ERROR = "Please enter a valid card number.";
        private Locator enterValidCardNumberError = locator(pwXPath("//span[contains(text(),'" + ENTER_VALID_CARD_NUMBER_ERROR + "')]"));

    private static final String ENTER_VALID_EXP_DATE_ERROR = "Please enter a valid expiration date MM/YY.";
        private Locator enterValidExpDateError = locator(pwXPath("//span[contains(text(),'" + ENTER_VALID_EXP_DATE_ERROR + "')]"));

    private static final String ENTER_VALID_CVV_NUMBER_ERROR = "Please enter a valid CVV.";
        private Locator enterValidCVVNumberError = locator(pwXPath("//span[contains(text(),'" + ENTER_VALID_CVV_NUMBER_ERROR + "')]"));

    private static final String ENTER_VALID_BILLING_ZIP_ERROR = "Please enter a valid CVV.";
        private Locator enterValidZipNumberError = locator(pwXPath("//span[contains(text(),'" + ENTER_VALID_BILLING_ZIP_ERROR + "')]"));


        private Locator cardSecurityCodeInputField = locator(pwXPath("//input[@id='cardCVVField']"));


        private Locator billingZipCodeInputField = locator(pwXPath("//input[@id='zipCode']"));

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public AutoPolicyPaymentBasePage() throws Exception {

    }

    public boolean isAutoPolicyPaymentHeaderCorrect() {
        return isExpectedTextDisplayed(waitElementBeVisible(autoPolicyPaymentHeader), AUTO_POLICY_PAYMENT_HEADER);
    }

    public boolean isSixMonthTermPaymentCorrect() {
        return isExpectedTextDisplayed(waitElementBeVisible(sixMonthTermPayment), SIX_MONTH_TERM_PAYMENT);
    }

    public boolean isPolicyFeesCorrect() {
        return isExpectedTextDisplayed(fees, FEES);
    }

    public boolean isMembershipFeesSideBarMsgCorrect() {
        return isExpectedTextDisplayed(membershipFeeMessageSideBar, AUTO_MEMBERSHIP_FEE_MESSAGE);
    }

    public boolean isPolicyFeesSideBarMsgCorrect() {
        return isExpectedTextDisplayed(policyFeeMessageSideBar, POLICY_POLICY_FEE_MESSAGE);
    }

    public boolean isVehicleFeesSideBarMsgCorrect() {
        return isExpectedTextDisplayed(vehicleFeeMessageSideBar, VEHICLE_FEE_MESSAGE);
    }

    @Override
    public boolean goBackToHowWouldYouLikeToPayPage() throws Exception {
        back();
        return isExpectedTextDisplayed(howWouldYouLikeToPay, HOW_WOULD_YOU_LIKE_TO_PAY);
    }

    public boolean isSixTermPriceSubHeaderDisplayed() {
        return waitElementBeVisible(sixTermPriceSubHeader).isVisible();
    }

    public boolean isSixMonthTermPriceAmountDisplayed(String payPlanDescription) throws Exception {
        PaymentSchedule payPlanSchedule = filterListOfPaymentScheduleByPayPlan(getAutoVerifyRateResponse().getPaymentSchedules(), payPlanDescription).get(0);
        String fullTermPremium = payPlanSchedule.getFullTermPremium();
        String expectedSixMonthTotalPremium;
        if (payPlanDescription.equals(ONE_PAY)) {
            Double doublePolicyFees = doublePolicyFeeAmount(getAutoVerifyRateResponse().getPolicyFee().getAmount());
            Double sixMonthTermPriceAmount = Double.parseDouble(fullTermPremium) + doublePolicyFees;
            expectedSixMonthTotalPremium = String.format("$%,.2f for 6-month term price", sixMonthTermPriceAmount);
        } else {
            expectedSixMonthTotalPremium = String.format("$%,.2f for 6-month term price", Double.parseDouble(fullTermPremium));
        }

        return getTextFromElement(sixTermPriceSubHeader).equals(expectedSixMonthTotalPremium);
    }

    public boolean isAutoPolicyPaymentPageDisplayed() throws Exception {
        waitElementBeVisible(autoPolicyPaymentHeader);
        return isExpectedTextDisplayed(autoPolicyPaymentHeader, AUTO_POLICY_PAYMENT_HEADER);
    }


    public boolean isCardNumberLabelCorrect() {
        return isExpectedTextDisplayed(cardNumberLabel, CARD_NUMBER_LABEL);
    }

    public boolean isExpirationDateCorrect() {
        return isExpectedTextDisplayed(expirationDateLabel, EXPIRATION_DATE_LABEL);
    }

    public boolean isCardSecurityCodeLabelCorrect() {
        return isExpectedTextDisplayed(cardSecurityCodeLabel, CARD_SECURITY_CODE_LABEL);
    }

    public boolean isBillingZipCodeLabelCorrect() {
        return isExpectedTextDisplayed(billingZipCodeLabel, BILLING_ZIP_CODE_LABEL);
    }

    public boolean isVisaCardIconInRowDisplayed() {
        return visaCardIconInARow.isVisible();
    }

    public boolean isMasterCardIconInRowDisplayed() {
        return masterCardIconInARow.isVisible();
    }

    public boolean isDiscoverCardIconInRowDisplayed() {
        return discoverCardIconInARow.isVisible();
    }

    public boolean isAmexCardIconInRowDisplayed() {
        return amexCardIconInARow.isVisible();
    }

    public boolean isNameOnCardLabelCorrect() {
        return isExpectedTextDisplayed(nameOnCardLabel, NAME_ON_CARD_LABEL);
    }

    protected String getValueForFullNamePaymentusFrame() {
        return getAttributeData(nameOnCardInPutField, VALUE);
    }

    public void clearOutCardHolderNameInputField() {
        nameOnCardInPutField.fill("");
    }

    public boolean isEnterYourNameErrorCorrect() {
        return isExpectedTextDisplayed(enterYourNameOnCardError, ENTER_YOUR_NAME_ERROR);
    }

    public boolean isEnterCardNumberErrorCorrect() {
        return isExpectedTextDisplayed(enterValidCardNumberError, ENTER_VALID_CARD_NUMBER_ERROR);
    }

    public boolean isEnterEXPDateNumberErrorCorrect() {
        return isExpectedTextDisplayed(enterValidExpDateError, ENTER_VALID_EXP_DATE_ERROR);
    }

    public boolean isEnterCVVNumberErrorCorrect() {
        return isExpectedTextDisplayed(enterValidCVVNumberError, ENTER_VALID_CVV_NUMBER_ERROR);
    }

    public boolean isEnterBillingZipCodeErrorCorrect() {
        return isExpectedTextDisplayed(enterValidZipNumberError, ENTER_VALID_BILLING_ZIP_ERROR);
    }

    public void enterCVVNumber(String cvvNumber) {
        sendKeysOneByOne(cardSecurityCodeInputField, cvvNumber);
    }

    public void enterBillingZipCode(String billingZipCode) {
        sendKeysOneByOne(billingZipCodeInputField, billingZipCode);
    }


    protected void enterNameOnCard(String nameOnCard) {
        sendKeysOneByOne(nameOnCardInPutField, nameOnCard);
    }

    public void validateBDQSpecificRequirements(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isDiscountSectionDisplayed(), "Discount section should be displayed on " + this.getClass().getSimpleName());
        validateValidateAndFooterForBDQ(fsa, applicant, this);
        validateAgentSectionBDQ(fsa, applicant);
    }

    public List<String> getTheListOfEligiblePaymentMethods() throws Exception {
        String breakPointAdjusterForLocator = isUseMobileViewEnabled() ? "//span[@class='mdc-tab__text-label']" : "//tui-presentment-card-header//h2";
        return locators(pwXPath(breakPointAdjusterForLocator + "| //span[@class='pov2__plan-title']")).stream()
                .map(paymentCard -> {
                    String textFromElement = getTextFromElement(paymentCard);
                    if (textFromElement == null) return "";
                    return textFromElement.replaceAll("[$0-9.]", "").strip();
                })
                .distinct()
                .collect(Collectors.toList());
    }

}
