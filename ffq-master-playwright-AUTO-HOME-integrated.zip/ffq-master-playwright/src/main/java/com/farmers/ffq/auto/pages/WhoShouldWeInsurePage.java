package com.farmers.ffq.auto.pages;







import com.farmers.framework.playwright.Keys;
import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.TimeoutError;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoVehicleSectionOneUI;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import lombok.SneakyThrows;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.farmers.ffq.utils.GlobalVariables.*;


public class WhoShouldWeInsurePage extends AutoBasePage {

    private static final String ACTUAL_LIST_OF_DRIVERS_WITH_AGES_CSS_SELECTOR = "ul>li";
    private static final String FIRST_NAME = "First name ";
    private static final String LAST_NAME = "Last name ";

    private static final String PAGE_DESCRIPTION_XPATH =
            "//div[contains(.,'Include all the vehicles and drivers you would like to insure, up to a maximum of 5.') " +
                    "or contains(.,\"We'll need some details on the vehicles and drivers you want to insure\")" +
                    "]";

    private static final String REQUIRED_FIELD_ERROR_MESSAGE = "One or more required fields is incomplete or incorrect. Please review.";
    private static final String SAVE_CHANGES = " Save Changes";
    private static final String SECTION_DESCRIPTION_XPATH = "//../p";
    public static final String VIN_HELPER_IMAGE_ONE = "//div[@title='Vin Helper Image 1']";
    public static final String VIN_HELPER_IMAGE_THREE = "//div[@title='Vin Helper Image 3']";
    public static final String VIN_HELPER_IMAGE_TWO = "//div[@title='Vin Helper Image 2']";
    private static final String XPATH_FOR_FLEX_EMAIL_ENTRY_FIELD = "//div[@id='flex-field-emailAddress_vehiclesDriversReview' and not(contains(@class, 'hidden'))]//input";
    private static final String XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_DROP_DOWN_FIELDS = "//mat-form-field[contains(.,'%s')]//mat-select";
    private static final String XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_INPUT_FIELDS = "//mat-form-field[.//mat-label[contains(text(),'%s')]]//input[not(@hidden)]";
    private static final String addDriverDialogXpath = "//app-add-driver";
    private static final String driverCheckboxXpath = "//mat-checkbox[contains(@class,'tui-disabled-checkbox-only')]//*[contains(text(),'%s')]/..//input";
    protected static final String ADPF_DRIVERS_FOUND_XPATH = "//ul[@class='auto-vehicles-drivers-review__drivers-list-section']";
    protected static final String ADPF_VEHICLES_FOUND_XPATH = "//div[@class='auto-vehicles-drivers-review__vehicles-list-section']";
    protected static final String MATCHECKBOX_XPATH = "//mat-checkbox";
    protected static final String INPUT_XPATH = "//input";
    protected static final String EDIT_BUTTON = "//div/a";
    protected static final String CHECKED_VEHICLES_XPATH = ADPF_VEHICLES_FOUND_XPATH + MATCHECKBOX_XPATH + INPUT_XPATH + "[contains(@class,'mdc-checkbox--selected')]";
    protected static final String CURRENT_INSURANCE_COMPANY = "Current insurance company";
    protected static final String PRIOR_INSURANCE_COMPANY = "Prior insurance company";
    protected static final String CURRENT_BI_LIMITS = "Current Bodily Injury (BI) limits";
    protected static final String PRIOR_BI_LIMITS = "Prior Bodily Injury (BI) limits";
    protected static final String POLICY_EXP_DATE = "Policy expiration date";
    protected static final String LENGTH_OF_CURRENT_INSURANCE = "Length of current insurance";
    protected static final String LENGTH_OF_PRIOR_INSURANCE = "Length of prior insurance";
    protected static final String MY_INSURANCE_EXPIRED = "My insurance expired";
    protected static final String CONTINUOUSLY_INSURED_QUESTION = "Have you been continuously insured for the past 6 months with any auto insurance company(s)?";

        private Locator actualLisOfDriversWithAges = locator(pwCss(ACTUAL_LIST_OF_DRIVERS_WITH_AGES_CSS_SELECTOR));

    private static final String LIST_OF_VEHICLES_ADDED_XPATH = "//label[contains(@for,'vehicle__checkbox')]";
    private static final String LIST_OF_DRIVERS_ADDED_XPATH = "//ul[@class='auto-vehicles-drivers-review__drivers-list-section']//mat-checkbox[contains(@class,'checked')]//span[@class='mat-checkbox-label']";
    private final String VEHICLE_VIN_ERROR_MESSAGE_XPATH = "//p[@class='auto-vehicles-drivers-review-vin-error-message tui-body-text-2']";

        private Locator lblDriversList = locator(pwXPath("//ul[contains(@class,'auto-vehicles-drivers-review__drivers-list-section')]/li//label[@class='mdc-label']"));

        private Locator actualListOfVehicleInfo = locator(pwCss("div.auto-vehicles-drivers-review__vehicles-list-details label.mdc-label"));

        public Locator lblVehiclesList = locator(pwXPath("//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-section')]/div//label[@class='mdc-label']"));

    private String lblVehiclesName = "//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-section')]/div[%d]//label[@class='mdc-label']";

        private Locator actualListOfVinTips = locator(pwCss("li.auto-add-vehicle-vin-tips__list-rules"));
        private Locator addAnotherVehicleButton = locator(pwXPath("//button[contains(@class,'tui-btn tui-btn-cta add-vehicle-button')]"));
        private Locator addAnotherVehicleButtonFromMainScreen = locator(pwCss(".auto-vehicles-drivers-review__multi-vehicle-add-link"));
        private Locator addAnotherVehicleButtonFromMainScreen2 = locator(pwXPath("//button[contains(.,'Add another vehicle')]"));
        private Locator addDriverCloseIcon = locator(pwId("auto-add-driver__dialog-close-icon"));
        protected Locator addVehicleDialogHeader = locator(pwCss("h2[id='addVehicleHeading']"));
        private Locator howToFindVinHeader = locator(pwClass("tui-vin-modal-header"));
        private Locator editDriverLink = locator(pwCss("div.auto-vehicles-drivers-review__drivers-list-details-section>a"));
        protected Locator ctaErrorMessageForVehicleEditSideSheet = locator(pwCss("div.auto-vehicles-drivers-review__drivers-list-details-section>a"));
        private Locator addDriverDialogHeader = locator(pwId("addDriverHeading"));
        private Locator addEditVehicleDialogHeader = locatorAny(pwCss("h2.auto-add-vehicle-heading"), pwXPath("//app-vehicle-form//h1"));
        private Locator addMoreDriverDialogHeader = locator(pwCss("h4[id='addMoreDriversHeading']"));
        private Locator addMoreVehiclesHeading = locator(pwXPath("//h4[text()='Do you have more vehicles? ']"));
        protected Locator addVehicleAndDriversButton = locator(pwId("addVehiclesDriversButton"));
        private Locator addAVehicleButton = locatorAny(pwCss("button[class='tui-btn tui-btn-primary ng-star-inserted']"), pwXPath("//*[@id='addVehicleButton' or @class='tui-btn tui-btn-primary auto-add-vehicle-submit__button']"));
        private Locator addAnotherVehicleLink = locator(pwId("multiVehicleAddLink"));
        private Locator addAnotherVehicleLinkAlternative = locator(pwId("addAnotherVehicleLink"));
        private Locator addAnotherVehicleLinkAlternative2 = locator(pwCss("button[class='tui-btn tui-btn-cta add-vehicle-button']"));
        private Locator addVehicleButton = locator(pwXPath("//button[@class='tui-btn tui-btn-primary auto-add-vehicle-submit__button'] | //button[contains(@class,'add-button')][contains(.,'Add another vehicle')]"));
        private Locator addVehicleSideDialogSubtitle = locator(pwCss("p.auto-add-vehicle-start__subtitle"));
        private Locator addVehiclesButton = locator(pwXPath("//button[text()='Add a vehicle']"));
        private Locator backToVinButton = locatorAny(pwCss("button.tui-vin-back-to-vin-button"), pwXPath("//button[@id='back-button']//mat-icon"));
        private Locator cancelAddVehicleLink = locator(pwXPath("//div[contains(@class,'auto-add-vehicle-submit')]//a"));
    private String checkBoxLabel = pwCss(".mat-checkbox-label");
        private Locator continueButton = locator(pwXPath("//button[contains(@class, 'auto-vehicles-drivers-review__continue-button')]"));
    private String lblDriversName =
            "//ul[contains(@class,'drivers-list-section')]/li[%d]//*[self::label[@class='mdc-label'] or self::div[contains(@class,'driver-name-header')]]";

    private String lblDriversAge = "//ul[contains(@class,'drivers-list-section')]/li[%d]//span[contains(@class,'age')]";
        private Locator dashboardOnTheDriverSideDriverSideDoorJamb = locatorAny(pwXPath(VIN_HELPER_IMAGE_TWO + SECTION_DESCRIPTION_XPATH), pwXPath("//div[@class='tui-vin-section tui-stacking-bottom-md'][2]//p"));
        private Locator dateOfBirthEntryField = locator(pwXPath("//mat-form-field//input[contains(@aria-label, 'Date of birth')] | //mat-form-field[contains(.,'Date of birth')]//input"));

        private Locator checkedVehicles = locator(pwCss("mat-checkbox[class='mat-checkbox auto-vehicles-drivers-review__vehicles-list-details-checkbox mat-accent mat-checkbox-checked']"));

    private String disabledCheckBoxLabel = pwXPath("//mat-checkbox[contains(@class,'mat-mdc-checkbox-disabled')]//label");
        private Locator doneAddingVehiclesButton = locator(pwCss("button.close-button"));

        private Locator addDriverButton = locator(pwId("addDriverButton"));

        protected Locator addAnotherDriverButton = locator(pwXPath("//a[contains(@id,'addAnotherDriverLink')]"));

        private Locator saveDriverCTAErrorMessage = locator(pwXPath("//p[contains(@class,'auto-add-driver__error-message')]"));

        protected Locator addAnotherDriverButtonSideSheet = locator(pwCss("button[class='tui-btn tui-btn-cta add-drivers-button']"));

        private Locator doneAddingDriversButton = locator(pwXPath("//div[contains(@class,'auto-add-more-drivers-done__button')]//button"));

        private Locator doneAddingDriversButtonAlternative = locator(pwXPath("//app-transition-sidesheet//button[text()='Done adding drivers']"));

        private Locator driverSection = locator(pwCss("div.auto-vehicles-drivers-review__drivers"));
        private Locator driverSideDoorText = locatorAny(pwXPath(VIN_HELPER_IMAGE_ONE + SECTION_DESCRIPTION_XPATH), pwXPath("//div[@class='tui-vin-section tui-stacking-bottom-md'][1]//p"));

    public final String DROP_DOWN_OPTIONS_XPATH = "//div[@role][.//mat-option]";

        public Locator dropDownOptions = locator(pwXPath(DROP_DOWN_OPTIONS_XPATH));
        private Locator errorMessageForVehicleAndDriverSelection = locatorAny(pwCss("p[class*='error-message']"), pwCss("div[class='error-message pb-4 ng-star-inserted']"));
        public Locator fieldErrorMessage = locator(pwCss("mat-error.mat-mdc-form-field-error"));
        private Locator flexEmailAddressEntryField = locator(pwXPath(XPATH_FOR_FLEX_EMAIL_ENTRY_FIELD));
        private Locator flexMobilePhoneEntryField = locator(pwXPath("//div[@id='flex-field-phoneNumber_vehiclesDriversReview']//input"));
        private Locator formFieldLabels = locator(pwXPath("//label[not(contains(@for,'flex-field'))]/mat-label"));
    private final String GENDER_SECTION_XPATH = "//mat-button-toggle-group[@aria-label='Please select your gender' or @id='formField_gender']";
        private Locator genderSelectForm = locator(pwXPath(GENDER_SECTION_XPATH));
        private Locator insuredSelectForm = locator(pwId("formField_currentlyInsured"));
        private Locator currentlyInsuredYes = locator(pwId("//div[contains(@id,'currentlyInsured')]//input[contains(@value,'Yes')]"));
        private Locator currentlyInsuredNo = locator(pwId("//div[contains(@id,'currentlyInsured')]//input[contains(@value,'NN')]"));

        private Locator keepBothButton = locator(pwCss("mat-dialog-container button.tui-btn-primary"));
        private Locator licenseSelectForm = locator(pwId("formField_licenseIssued"));
        private Locator nonAdpfPageSubTitle = locator(pwXPath("//div[@class='auto-vehicles-drivers-review__non-adpf__subheading row']//span"));
        protected Locator nonAdpfPageTitle = locator(pwXPath("//h1[contains(@class,'auto-vehicles-drivers-review__non-adpf-heading tui-h1')]"));
        private Locator notInsuredReasonDropdownField = locator(pwXPath("//mat-form-field[@id='currentlyUninsuredReason']//mat-select"));
        private Locator priorInsuranceExpiredDropdownField = locator(pwXPath("//mat-form-field[@id='priorInsuranceExpiredInfo']//mat-select"));
        private Locator quoteNumberText = locator(pwXPath("//p[text()][./span[text()='Quote number']]"));
        private Locator removeBothButton = locator(pwCss("mat-dialog-actions button.tui-btn-link"));
        private Locator requiredFieldErrorMessage = locator(pwCss("p.auto-add-vehicle-ymm__multiple-fields-missing"));
        private Locator vehicleSaveChangesButton = locator(pwXPath("//button[contains(text(),'Save changes')]"));

        private Locator driverSaveChangesButton = locator(pwXPath("//button[contains(text(),'Save changes')]"));
        private Locator saveDriverInfoButton = locator(pwXPath("//button[text()=' Save']"));
        private Locator saveQuoteLink = locator(pwXPath("//a[text()='Save quote']"));
        private Locator spouseSelectPopUpContext = locator(pwId("spouseSelectContent"));
        private Locator spouseSelectPopUpHeader = locator(pwCss("h1.spouse-select__title"));
        private Locator subNote = locator(pwCss("p.auto-add-vehicle-ymm__disclaimer-text"));
        private Locator vehicleMakeEntryField = locator(pwCss(".auto-add-vehicle-make__input input:not([disabled])"));
        private Locator vehicleMakeEntryFieldAlternate = locator(pwXPath("//div[contains(@class, 'auto-add-vehicle-make__input')]//input"));
        private Locator vehicleModelEntryField = locator(pwCss(".auto-add-vehicle-model__input input:not([disabled])"));
        private Locator vehicleModelEntryFieldAlternate = locator(pwId("//div[contains(@class, 'auto-add-vehicle-model__input')]//input"));
        private Locator vehicleSection = locator(pwCss("div.auto-vehicles-drivers-review__vehicles"));
        private Locator editVehicleLink = locator(pwCss("div.auto-vehicles-drivers-review__vehicles-list-details-section>a"));

    private final String EDIT_LINK_XPATH_FOR_VIN_PROVIDED_VEHICLES = "//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-details row') and contains(.,'VIN: •••')]//a";
        private Locator editVehicleLinksForVinVehicle = locator(pwXPath(EDIT_LINK_XPATH_FOR_VIN_PROVIDED_VEHICLES));


        private Locator vehicleVinLabel = locator(pwXPath("//*[@aria-label='VIN ending with 341']"));

        private Locator vehicleTypeDropdown = locator(pwId("auto-add-vehicle-vehicleType__input-section"));
        private Locator vehicleTypeDropdownValue = locator(pwXPath("(//span[starts-with(@class,'mat-mdc-select-min-line')])[2]"));
        private Locator vehicleVINButton = locator(pwXPath("//mat-button-toggle[@value='vin']/button"));
        public Locator vehicleVINEntryField = locator(pwXPath("//input[@id='auto-add-vehicle-vin__input-section']"));
        private Locator vehicleYMMButton = locator(pwXPath("//mat-button-toggle[@value='ymm']/button"));
        protected Locator vehicleYearDropdown = locator(pwCss(".auto-add-vehicle-year__input mat-select[aria-disabled='false']"));
        protected Locator vehicleYearDropdownAlternate = locator(pwXPath("//div[contains(@class, 'auto-add-vehicle-year__input')]//mat-select"));
        private Locator vehicleYearDropdownValue = locator(pwXPath("(//span[starts-with(@class,'mat-mdc-select-min-line')])[1]"));
        private Locator vinHelperImageOne = locator(pwXPath(VIN_HELPER_IMAGE_ONE));
        private Locator vinHelperImageThree = locator(pwXPath(VIN_HELPER_IMAGE_THREE));
        private Locator vinHelperImageTwo = locator(pwXPath(VIN_HELPER_IMAGE_TWO));
        private Locator vinHelperModalContent = locator(pwXPath("//p[@class='tui-body-text-1']"));
    // Vin Model Helper locators
        private Locator vinHelperModalHeader = locatorAny(pwCss(".tui-subtitle"), pwId("baseSidesheetHeader"));
        private Locator vinLocations = locator(pwXPath("//p[contains(@class,'tui-field-label-text auto-vin-helper__body')]"));
        private Locator vinLocationsList = locator(pwXPath("//ol//li"));
        public Locator whereCanIFindThisLink = locator(pwXPath("//a[text()=' Where can I find this?']"));
        private Locator whoShouldWeInsurePageContent = locator(pwXPath(PAGE_DESCRIPTION_XPATH));
        private Locator whoShouldWeInsureTitle = locator(pwXPath("//h1[contains(text(), 'Who should we insure?')]"));
        private Locator xButton = locator(pwXPath("//div[@class='auto-add-vehicle-heading__div row']//div[./mat-icon]"));
        private Locator txtVINUnmasked = locator(pwXPath("//mat-label[contains(normalize-space(text()),'VIN')]/ancestor::div[1]/input[1]"));

        private Locator lblVINDescription = locator(pwXPath("//div[contains(@class,'vehicle-desc')]/div"));

        public Locator saveButton = locator(pwCss("button[class='tui-btn tui-btn-primary auto-add-driver-save__button']"));

        public Locator pageCTAErrorMessage = locator(pwCss("p[class='auto-vehicles-drivers-review__error-message tui-body-text-2 ng-star-inserted']"));

        protected Locator listOfCheckedVehicles = locator(pwXPath(CHECKED_VEHICLES_XPATH));
        protected Locator listOfEditButtonsOfCheckedVehicles = locator(pwXPath(CHECKED_VEHICLES_XPATH + "//ancestor::mat-checkbox/.." + EDIT_BUTTON));

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public WhoShouldWeInsurePage() throws Exception {
    }

    @SneakyThrows
    private static Locator getEditDriverButtonForDriver(String fullName) {
        return locator(pwXPath(String.format("//li[contains(.,'%s')]//a[contains(.,'Edit')] | //app-driver-card[contains(.,'%s')]//a", fullName, fullName)));
    }

    //Vin may contain unicode chars we want to keep
    public String getVehicleVinLabelText() {
        return vehicleVinLabel.innerText().trim();
    }


    public void validateVehicleVinLabel(String vehicleVinText, FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getVehicleVinLabelText(), vehicleVinText, "Vehicle has a valid VIN");
    }

    public void clickAddDriverButton() {
        waitElementBeVisible(addDriverButton);
        clickElement(addDriverButton);
    }

    public void addADPFDriverDetails(Optional<AutoApplicant> applicantOptional, String gender, String dob) throws Exception {
        waitElementBeVisible(dateOfBirthEntryField);
        if (getAttributeData(dateOfBirthEntryField, "readonly").equals(EMPTY_STRING)) {
            enterDateOfBirth(dob);
        }
        selectGenderTabButton(gender);
        boolean isApplicantPresent = applicantOptional.isPresent();
        AutoApplicant applicant = null;
        if (isApplicantPresent) {
            applicant = applicantOptional.get();
        }
        String applicantCurrentlyInsured = isApplicantPresent && !applicant.getCurrentlyInsuredStatus().equals("Insured") ? NO : YES;
        selectUsOrCanadaLicensedRadioButton(isApplicantPresent && applicant.getFirstAgeForeignDriverLicense() == 18 ? NO : YES);
        List<Locator> currentlyInsuredSectionActive = locators(pwXPath("//div[contains(@id,'currentlyInsured') and @hidden]"));
        if (currentlyInsuredSectionActive.isEmpty() && !isElementPresent(pwXPath("//div[contains(@id,'currentlyInsured')]//mat-radio-button[contains(@class,'checked')]")) ) {
        	Locator currentlyInsuredSelection = locator(pwXPath(String.format("//div[contains(@id,'currentlyInsured')]//mat-radio-button[.//*[contains(text(),'%s')]]", applicantCurrentlyInsured)));
        	scrollAndClickOnElement(currentlyInsuredSelection);
        	int retry = 3;
        	while (!getAttributeData(currentlyInsuredSelection, CLASS).contains(MAT_MDC_RADIO_CHECKED) && retry>0) {
                clickElement(currentlyInsuredSelection);
                waitForUiSettled();
        		retry--;
        	}

        }

        if (applicantCurrentlyInsured.equals(NO) && isElementVisible(notInsuredReasonDropdownField,1)) {
            switch (applicant.getCurrentlyInsuredStatus()) {
                case NEVER_INSURED:
                    selectValueInDropDown(notInsuredReasonDropdownField, "I never had insurance");
                    break;
                case EXPIRED:
                    selectValueInDropDown(notInsuredReasonDropdownField, MY_INSURANCE_EXPIRED);
                    selectValueInDropdown("Before", priorInsuranceExpiredDropdownField, dateOfBirthEntryField);
                    if(applicant.getStateCode().equals(OR)) {
                        enterPriorInsuranceCompany(applicant.getCurrentInsuranceCompany().toUpperCase());
                        selectPriorBodilyInjuryLimits(applicant.getCurrentBodilyInjuryLimit());
                        // update length from available options
                        List<String> availableLengths = getSessionStorageAppStore().getAuto().getDropdowns().getDriver().getDropDownResponseBeans().stream().filter(each -> each.getFieldName().equals("lapseInCvgYes")).map(each -> each.getDropDownValues().get(0).getWebDesc()).collect(Collectors.toList());
                        Collections.shuffle(availableLengths);
                        String length = availableLengths.get(0);
                        selectLengthOfPriorInsurance(length);
                    }
                    selectContinuouslyInsuredForPastSixMonthsRadioButtonIfExists(applicant.getContinuosInsurancePeriod().equals("< 6 Months") ? NO : YES);
                    selectMilitaryDeploymentQuestionIfExists();
                    break;
                case NOT_REQUIRED:
                    selectValueInDropDown(notInsuredReasonDropdownField, "I was not required to have insurance");
                    break;
                case DEPLOYED:
                    selectValueInDropDown(notInsuredReasonDropdownField, "I was in the military and deployed overseas");
                    break;
                default:
                    Log.warn("Unrecognized insured status: " + applicant.getCurrentlyInsuredStatus());
                    break;
            }
        }
        if (isElementDisplayed(pwXPath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_INPUT_FIELDS, CURRENT_INSURANCE_COMPANY)))) {
            enterCurrentInsuranceCompany("AAA");
        }

        if (isElementDisplayed(pwXPath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_DROP_DOWN_FIELDS, CURRENT_BI_LIMITS)))) {
            selectCurrentBodilyInjuryLimits("$50,000/$100,000");
        }

        if (isElementDisplayed(pwXPath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_INPUT_FIELDS, POLICY_EXP_DATE)))) {
            String policyExpirationDate = LocalDate.now().plusDays(30).format(DateTimeFormatter.ofPattern(MM_DD_YYYY));
            enterPolicyExpirationDate(policyExpirationDate);
        }

        if (isElementDisplayed(pwXPath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_DROP_DOWN_FIELDS, LENGTH_OF_CURRENT_INSURANCE)))) {
            List<String> availableLengths = getSessionStorageAppStore().getAuto().getDropdowns().getDriver().getDropDownResponseBeans().stream().filter(each -> each.getFieldName().equals("lapseInCvgYes")).map(each -> each.getDropDownValues().get(0).getWebDesc()).collect(Collectors.toList());
            Collections.shuffle(availableLengths);
            String length = availableLengths.get(0);
//            if (isApplicantPresent) {
//                updateApplicantCurrentInsuranceDuration(applicant);
//                length = applicant.getContinuosInsurancePeriod();
//            }
            selectLengthOfCurrentInsurance(length);

            if (length.equals("< 6 Months")) {
                selectContinuouslyInsuredForPastSixMonthsRadioButtonIfExists(NO);
                selectMilitaryDeploymentQuestionIfExists();
            }
        }

        selectContinuouslyInsuredForPastSixMonthsRadioButtonIfExists(isApplicantPresent ? (applicant.getContinuosInsurancePeriod().equals("< 6 Months") ? NO : YES) : YES);

        if(isElementVisible(saveButton, 1)) {
            waitAndClickElement(saveButton);
        } else {
            clickOnButtonWithLabel(SAVE_CHANGES);
        }
        if (isElementVisible(doneAddingDriversButton, 1)) {
            waitAndClickElement(doneAddingVehiclesButton);
        }
    }

    public WhoShouldWeInsurePage addAllDriversWithMoreThan4AdditionalDriversWhenNonFound(AutoApplicant applicant) throws Exception {
        addAllDriversWithMoreThan4AdditionalDrivers(applicant);
        return this;
    }

    public void addDisplayedDrivers(AutoApplicant applicant) throws Exception {
        addMainDriver(applicant);
        clickOnDoneAddingDriversButton();
        longWaitForElementToBeGoneByXpath(addDriverDialogXpath);
        if (applicant.getMaritalStatus().equals(MARRIED)) {
            SqlAdditionalDriver sniDriver = applicant.getAdditionalDrivers().get(0);
            Locator sniDriverWe = locator(pwXPath(String.format(driverCheckboxXpath, sniDriver.getFirstName() +
                    SPACE + sniDriver.getLastName())));
            waitAndClickElement(sniDriverWe);
            addAdditionalSniDriver(sniDriver);
            waitAndClickElement(driverSaveChangesButton);
            waitAndClickElement(doneAddingVehiclesButton);
            longWaitForElementToBeGoneByXpath(addDriverDialogXpath);
        }
    }

    //allowing more that 4 additional driver to be inputed
    public WhoShouldWeInsurePage addDriversWhenNoneAreFound(AutoApplicant applicant) throws Exception {
        addAllDrivers(applicant);
        return this;
    }

    public WhoShouldWeInsurePage addVehicles(AutoApplicant applicant) throws Exception {
        if (!isElementVisible(addEditVehicleDialogHeader, 3)) {
            waitAndClickElement(addVehiclesButton);
        }
        addAllVehiclesInList(applicant, applicant.getStateCode());
        return this;
    }

    public WhoShouldWeInsurePage addVehiclesWhenNoneAreFound(AutoApplicant applicant) throws Exception {
        int foundVehicles = getActualListOfDisplayedVehicles().size(); // number of the vehicles that are already on the page
        List<Vehicle> vehicles = applicant.getVehicles();

        if (foundVehicles > 0 && foundVehicles < vehicles.size()) {
            for (int i = 0; i < foundVehicles; i++) {
                vehicles.remove(vehicles.size() - 1); // remove from end
            }
        }

        if(applicant.getTestScenario().contains("BW") && !(editVehicleLinksForVinVehicle.count() == 0)) {
            uncheckAllCheckedVehicleCheckboxes();
            updateVinsForVehicles(getRandomVinNumber(3));
        }

        clickOnAddVehiclesAndDriversButton();
        addAllVehiclesInList(applicant, applicant.getStateCode());

        return this;
    }

    public void addADPFApplicant(Optional<AutoApplicant> applicantOptional, String applicantFullName, String gender, String dob) throws Exception {
        List<Locator> checkboxInputForAdpfApplicants = getDriverEditCheckboxesInputButtonByFullName(applicantFullName);

        Locator editButtonForAdpfApplicant = getEditDriverButtonForDriver(applicantFullName);
        if (checkboxInputForAdpfApplicants.isEmpty()) {
            if(!isDriverSideDialogOpen()) {
                clickAddDriverButton();
                waitElementBeVisible(addDriverDialogHeader);
            }
            addADPFDriverDetails(applicantOptional, gender, dob);
        } else {
            // add PNI details if not already checked
            Locator checkboxInputForAdpfApplicant = getDriverEditCheckboxInputButtonByFullName(applicantFullName);
            if (getAttributeData(checkboxInputForAdpfApplicant, CLASS).contains(MDC_CHECKBOX_SELECTED)) {
                // if the checkbox is already selected, we can return
                return;
            }

            if(!isDriverSideDialogOpen() && !checkboxInputForAdpfApplicant.isChecked() && isCheckboxNotChecked(checkboxInputForAdpfApplicant)) {
            	if (checkboxInputForAdpfApplicant.isEnabled()) {
                    scrollAndClickOnElement(checkboxInputForAdpfApplicant);
                } else {
                    scrollAndClickOnElement(editButtonForAdpfApplicant);
                }
            }
            addADPFDriverDetails(applicantOptional, gender, dob);
        }
        waitForSpinnerToBeGone();
    }

    public void clickOnAddVehiclesAndDriversButton() throws Exception {
        if (isElementVisible(addAnotherVehicleLink, 3) || isElementVisible(addAnotherVehicleLinkAlternative, 3)) {
            clickAddAnotherVehicleButton();
        } else {
            clickOnAddVehicleAndDriversButton();
        }
    }

    public void addVehiclesWhenOthersAreFound(AutoApplicant applicant) throws Exception {
        addAllVehiclesInList(applicant, applicant.getStateCode());
    }

    public boolean areAddedListOfDriversWithAgesDisplayed(AutoApplicant applicant) throws Exception {

        // adding main driver to the Map
        Map<String, String> expectedDriversWithAges = new HashMap<>();
        Map<String, String> actualDriversWithAges = new HashMap<>();
        expectedDriversWithAges.put(getApplicantFullName(applicant), String.valueOf(applicant.getAge()));

        // adding additional drivers to the Map
        applicant.getAdditionalDrivers().forEach(additionalDriver -> expectedDriversWithAges.put(getAdditionalDriverFullName(additionalDriver), String.valueOf(additionalDriver.getAge())));
        Log.info("expected values: " + expectedDriversWithAges);

        if (isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            new VehiclesDriversInfoPage().getDriverNamesAndAgesAsList().forEach(driverNameAndAge -> {
                String[] split = driverNameAndAge.split(",");
                String name = split[0].trim();
                String age = split[1].trim();
                actualDriversWithAges.put(name, age);
                expectedDriversWithAges.remove(name, age);
            });
        } else {

            List<String> names = page()
                    .locator(pwXPath("//li[@class='auto-vehicles-drivers-review__drivers-list-details ng-star-inserted']//label"))
                    .all().stream()
                    .map(this::getTextFromElement)
                    .collect(Collectors.toList());

            List<String> ages = page()
                    .locator(pwXPath("//li[@class='auto-vehicles-drivers-review__drivers-list-details ng-star-inserted']//span"))
                    .all().stream()
                    .map(this::getTextFromElement)
                    .map(text -> text.replaceAll("\\D", "")) // keep only digits
                    .filter(text -> !text.isEmpty())          // optional: remove empty results
                    .collect(Collectors.toList());
            for (int i = 0; i < names.size(); i++) {
                actualDriversWithAges.put(names.get(i), ages.get(i));
                expectedDriversWithAges.remove(names.get(i), ages.get(i));
            }


        }

        Log.info("actual values: " + actualDriversWithAges);

//        lblDriversList.all().forEach(driverInfo -> {
//            String driverToBeInsured = getTextFromElement(driverInfo.locator(pwXPath("//ul[contains(@class,'drivers-list-section')]/li//span[@class='mat-checkbox-label']")));//lblDriversName
//            String ageOfDriverToBeInsured = getTextFromElement(driverInfo.locator(pwXPath("//ul[contains(@class,'drivers-list-section')]/li//span[contains(@class,'age')]")));//lblDriversAge
//            expectedDriversWithAges.remove(driverToBeInsured, ageOfDriverToBeInsured.substring(ageOfDriverToBeInsured.length() - 2));
//        });
        return expectedDriversWithAges.isEmpty();
    }

    public boolean areAllFirstNameLastNameAndDobFieldsEditable() throws Exception {
        // re-using existing methods and locators from HeresWhatWeFoundPage...
        return new HeresWhatWeFoundPage().areAllFirstNameLastNameAndDobFieldsEditable();
    }

    public boolean areListOfAddedVehiclesDisplayed(AutoApplicant applicant) throws Exception {
        List<String> expectedListOfVehiclesDisplayed = new ArrayList<>();
        for (Vehicle vehicleInfo : applicant.getVehicles()) {
            String vehicleMake = vehicleInfo.getVehicleMake();
            String vehicleModel = vehicleInfo.getVehicleModel();
            String vehicleYear = vehicleInfo.getVehicleYear();
            String expectedVehicleName = vehicleYear + SPACE + vehicleMake + SPACE + vehicleModel;
            ;
            if (vehicleInfo.isUseVIN()) {
                List<AppStore.Auto.AppStoreVehicle> vehicles = this.getSessionStorageAppStore().getAuto().getVehicles();
                List<AppStore.Auto.AppStoreVehicle> filteredVehicles = vehicles.stream().filter(each -> {
                            String vin = null;
                            try {
                                vin = each.getVin();
                            } catch (Exception e) {
                                Log.error(e.getMessage());
                            }
                            if (!StringUtils.isEmpty(vin)) {
                                return vin.equals(vehicleInfo.getVehicleVIN());

                            } else {
                                return false;
                            }
                        }
                ).collect(Collectors.toList());

                if (!filteredVehicles.isEmpty()) {
                    AppStore.Auto.AppStoreVehicle vehicle = filteredVehicles.get(0);
                    vehicleMake = vehicle.getMakeDesc();
                    vehicleYear = vehicle.getYear();
                    vehicleModel = vehicle.getModelDesc();
                } else {
                    vehicleMake = vehicleInfo.getVehicleMake();
                    vehicleModel = vehicleInfo.getVehicleModel();
                    vehicleYear = vehicleInfo.getVehicleYear();
                }
                vehicleModel = vehicleInfo.getVehicleModel().contains("QUATTRO") ? "QUAT" : vehicleModel;
                expectedVehicleName = vehicleYear + SPACE + vehicleMake + SPACE + vehicleModel;
            }
            expectedListOfVehiclesDisplayed.add(expectedVehicleName);

        }
        Collections.sort(expectedListOfVehiclesDisplayed);
        int intVehiclesCount = getEleCount(lblVehiclesList.all(), 5);
        List<String> actualListOfVehiclesDisplayed = new ArrayList<>();
        for (int i = 1; i <= intVehiclesCount; i++) {
            actualListOfVehiclesDisplayed.add(getTextFromElement(generateXpath(lblVehiclesName, "%d", Integer.toString(i))));
        }
        Collections.sort(actualListOfVehiclesDisplayed);
        Log.info("Actual vehicle list  : " + actualListOfVehiclesDisplayed);
        Log.info("Expected vehicle list: " + expectedListOfVehiclesDisplayed);
        return actualListOfVehiclesDisplayed.containsAll(actualListOfVehiclesDisplayed) && actualListOfVehiclesDisplayed.containsAll(actualListOfVehiclesDisplayed);
    }

    public void checkAllUnCheckedVehicleCheckboxes() throws Exception {
        List<Locator> uncheckedVehicles = locators(pwXPath("//mat-checkbox[@class='mat-mdc-checkbox auto-vehicles-drivers-review__vehicles-list-details-checkbox mat-accent']"));
        for (Locator uncheckedVehicle : uncheckedVehicles) {
            clickElement(uncheckedVehicle);
        }
    }

    @SneakyThrows
    public void clickEditButtonWithDriverFullName(String fullName) throws Exception {
        // Bristol West has a different definition for this object
        if (isElementPresent(pwXPath(String.format("//button[contains(@aria-label,'%s')]", fullName)), 5)) {
            clickElement(locator(pwXPath(String.format("//button[contains(@aria-label,'%s')]", fullName))));
        } else {
            waitAndClickElement(getEditDriverButtonForDriver(fullName));
        }
    }

    public void clickOnAddAnotherVehicleButton() {
        waitAndClickElement(addAnotherVehicleButtonFromMainScreen);
    }

    public WhoShouldWeInsurePage clickOnAddVehicleAndDriversButton() {
        scrollToElement(addVehicleAndDriversButton);
        waitElementBeVisible(addVehicleAndDriversButton);
        clickElement(addVehicleAndDriversButton);
        return this;
    }

    public WhoShouldWeInsurePage clickOnAddVehicleButtonAndWaitForSpinner() {
        clickOnAddVehicleButton();
        waitForSpinnerToBeGone();
        return this;
    }

    public WhoShouldWeInsurePage clickOnAddVehicleButton() {
        waitElementBeVisibleClickable(addAVehicleButton);
        scrollAndClickOnElement(waitElementBeVisible(addVehicleButton));
        return this;
    }

    public void clickOnBackToVinButton() {
        waitAndClickElement(backToVinButton);
    }

    public void clickOnContinueButton() {
        scrollAndClickOnElement(continueButton);
        waitForSpinnerToBeGone();
    }

    public void clickOnDoneAddingVehiclesButton() {
        scrollAndClickOnElement(waitElementBeVisible(doneAddingVehiclesButton));
        waitForSpinnerToBeGone();
    }

    @SneakyThrows
    public void clickOnDriverDialogCloseIcon() {
        waitAndClickElement(addDriverCloseIcon);
    }

    public void clickOnSaveButton() throws Exception {
        Locator element = locator(pwCss("button[class='tui-btn tui-btn-primary auto-add-driver-save__button']"));
        scrollAndClickOnElement(element);
        waitForSpinnerToBeGone();
    }

    public WhoShouldWeInsurePage clickOnVehicleAdditionCancelButton() {
        waitAndClickElement(cancelAddVehicleLink);
        return this;
    }

    public WhoShouldWeInsurePage clickOnVinButton() {
        waitAndClickElement(vehicleVINButton);
        return this;
    }

    public WhoShouldWeInsurePage clickOnWhereCanIFindThisLink() {
        waitAndClickElement(whereCanIFindThisLink);
        waitElementBeVisible(vinHelperModalHeader);
        return this;
    }

    public WhoShouldWeInsurePage clickOnYMMButton() {
        if (isVehicleYmmFormVisible()) {
            Log.info("Vehicle YMM fields are already visible; skipping explicit YMM toggle click.");
            return this;
        }
        waitAndClickElement(vehicleYMMButton);
        return this;
    }

    private boolean isVehicleYmmFormVisible() {
        return isElementVisible(vehicleYearDropdown, 2)
                || isElementVisible(vehicleYearDropdownAlternate, 2)
                || isElementVisible(vehicleMakeEntryField, 2)
                || isElementVisible(vehicleMakeEntryFieldAlternate, 2)
                || isElementVisible(vehicleModelEntryField, 2)
                || isElementVisible(vehicleTypeDropdown, 2);
    }

    public void clickFirstVehicleEditLink() {
        waitAndClickElement(editVehicleLink.nth(0));
    }

    public WhoShouldWeInsurePage updateVinsForVehicles(String vin) throws Exception {
        waitAndClickElement(editVehicleLink.nth(0));
        clickOnVinButton();
        waitElementBeVisible(vehicleVINEntryField).fill("");
        fillOutVinField(vin);
        waitForSpinnerToBeGone();
        waitAndClickElement(addVehicleButton);
        waitForUiSettled();
        while (isElementDisplayed(pwXPath("//mat-error[contains(.,'This VIN is already added for a vehicle.')]"))) {
            fillOutVinField(vin);
            waitForSpinnerToBeGone();
            waitAndClickElement(addVehicleButton);
            waitForSpinnerToBeGone();
        }
        waitForUiSettled();

        if(isElementVisible(doneAddingVehiclesButton, 1)) {
            waitAndClickElement(doneAddingVehiclesButton);
        }
        return this;
    }

    public WhoShouldWeInsurePage clickOnEditDriverLink() {
        waitAndClickElement(editDriverLink);
        return this;
    }

    public void enterEmailAndPhoneNumber(AutoApplicant applicant) {
        if (isElementPresentByXPath(XPATH_FOR_FLEX_EMAIL_ENTRY_FIELD)) {
            enterValueInField(applicant.getEmail(), flexEmailAddressEntryField, "Enter email address");
            enterValueInField(applicant.getPhoneNumber(), flexMobilePhoneEntryField, "Enter phone number");
        }

    }

    public WhoShouldWeInsurePage enterVehicleMake(Vehicle vehicleInfo) throws Exception {
        enterVehicleMake(vehicleInfo.getVehicleMake());
        return this;
    }

    public WhoShouldWeInsurePage enterVehicleMake(String vehicleMake) throws Exception {
        Locator makeEntryField = isMA61Environment() ? vehicleMakeEntryFieldAlternate : vehicleMakeEntryField;
        waitElementBeVisibleClickable(makeEntryField);
        sendKeysToElement(makeEntryField, vehicleMake);
        wait.until(Conditions.numberOfElementsToBeMoreThan(pwXPath(DROP_DOWN_OPTIONS_XPATH), 0));
        selectValueInDropDown(makeEntryField, vehicleMake);
        waitElementBeInvisible(dropDownOptions);
        waitForSpinnerToBeGone();
        Log.info("Selected vehicle make: " + vehicleMake);
        return this;
    }

    public WhoShouldWeInsurePage enterVehicleModelAndTrim(String vehicleModel) throws Exception {
        waitElementBeVisibleClickable(vehicleModelEntryField);
        try {
            selectValueInDropDown(vehicleModelEntryField, vehicleModel);
        } catch (Exception e) {
            if (vehicleModel.contains("QUATTRO")) {
                vehicleModel = vehicleModel.replace("QUATTRO", "QUAT");
                selectValueInDropDown(vehicleModelEntryField, vehicleModel);
            }
        }
        Log.info("Selected vehicle model: " + vehicleModel);
        return this;
    }

    public void fillOutVehicleYearModelMakeFields(Vehicle vehicleInfo) throws Exception {
        if (new ContactInfoAutoPage().isOnContactInfoAutoPage()) {
            Log.info("Contact information is already visible; skipping vehicle YMM entry.");
            return;
        }
        clickOnYMMButton();
        selectVehicleYear(vehicleInfo);
        enterVehicleMake(vehicleInfo);
        enterVehicleModelAndTrim(vehicleInfo);
        selectVehicleType(vehicleInfo.getVehicleType());
    }

    public WhoShouldWeInsurePage fillOutVinField(String vehicleVIN) {
        enterValueInField(vehicleVIN, waitElementBeVisible(vehicleVINEntryField), "Entering VIN: ");
        waitForSpinnerToBeGone();
        Log.info("Entering vin : " + vehicleVIN);
        if (getAttributeData(vehicleVINEntryField, CLASS).contains("ng-invalid")) {
            sendKeysToElement(vehicleVINEntryField, vehicleVIN);
        }
        waitForSpinnerToBeGone();

        return this;
    }

    public List<String> getActualListOfDisplayedVehicles() {
        return actualListOfVehicleInfo.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public String getDashboardOnTheDriverSideDriverSideDoorJambText() {
        return getTextFromElement(dashboardOnTheDriverSideDriverSideDoorJamb);
    }

    public String getDriverSideDriverSideText() {
        return getTextFromElement(driverSideDoorText);
    }

    public String getErrorMessageForVehicleAndDriverSelection() {

        return getTextFromElement(errorMessageForVehicleAndDriverSelection);
    }

    public String getKeepBothButtonText() {
        return getTextFromElement(keepBothButton);
    }

    public String getPniRemovalNotificationText() throws Exception {
        return new HeresWhatWeFoundPage().getPniDriverRemovalNotificationText();
    }

    public String getRemoveBothButtonText() {
        return getTextFromElement(removeBothButton);
    }

    public String getSniRemovalNotificationText() throws Exception {
        return new HeresWhatWeFoundPage().getSniDriverRemovalNotificationText();
    }

    public String getSpouseSelectPopUpContextText() {
        return getTextFromElement(spouseSelectPopUpContext);
    }

    public String getSpouseSelectPopUpHeaderText() {
        return getTextFromElement(spouseSelectPopUpHeader);
    }

    public String getSubTitle() {
        return getTextFromElement(waitElementBeVisible(nonAdpfPageSubTitle));
    }

    public String getTitle() {
        return getTextFromElement(waitElementBeVisible(nonAdpfPageTitle));
    }

    public String getVinHelperModalHeader() {
        return getTextFromElement(waitElementBeVisible(vinHelperModalHeader));
    }

    public List<String> getVinTipsDisplayed() {
        if(isElementVisible(howToFindVinHeader, 1)) {
            waitAndClickElement(whereCanIFindThisLink);
            waitForUiSettled();
        }
        List<String> vinTips = actualListOfVinTips.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        return new ArrayList<>(vinTips);

    }

    public boolean isDriverSectionDisplayed() {
        return isElementVisible(driverSection, 3);
    }

    public boolean isOnWhoShouldWeInsurePage() {
        return isElementVisible(nonAdpfPageTitle, 25);
    }

    public boolean isOnWhoShouldWeInsurePageShort() {
        return isElementVisible(nonAdpfPageTitle, 2);
    }

    public boolean isVehicleSectionDisplayed() {
        return isElementVisible(vehicleSection, 3);
    }

    public boolean isVinHelperImageOneVisible() {
        return isElementVisible(vinHelperImageOne, 3);
    }

    public boolean isVinHelperImageThreeVisible() {
        return isElementVisible(vinHelperImageThree, 3);
    }

    public boolean isVinHelperImageTwoVisible() {
        return isElementVisible(vinHelperImageTwo, 3);
    }

    @SneakyThrows
    public void navigateBackToPreviousPage() {
        back();
        waitUntilAngular5Ready();
    }

    public boolean quickIsOnWhoShouldWeInsurePage() {
        return isElementVisible(whoShouldWeInsureTitle, 5);
    }

    @SneakyThrows
    public static void refreshPage() {
        AutoBasePage.refreshPage();
        new WhoShouldWeInsurePage().waitUntilAngular5Ready();
    }

    public WhoShouldWeInsurePage selectUsOrCanadaLicensedRadioButton(String yesOrNo) throws Exception {
        if (yesOrNo.equals("Yes, but lives away from home")) {
            // reassigning to yes, as this is not supported in One UI
            yesOrNo = "Yes";
        }
        waitElementBeVisible(genderSelectForm);
        Locator webElement = locator(pwXPath(String.format("//div[contains(@id,'licenseIssued') or contains(@aria-label,'license issued by')]//input[contains(@value,'%s')]", yesOrNo)));
        scrollAndClickOnElement(webElement);
        Log.info("US or CA Driver License selection: " + yesOrNo);
        return this;
    }

    public void selectVehicleType(String vehicleType) throws Exception {
        waitForSpinnerToBeGone();
        String dropdownDisabled = getAttributeData(vehicleTypeDropdown, ARIA_DISABLED);
        boolean vehicleTypeIsNotFilled = getAttributeData(vehicleTypeDropdown, CLASS).contains("mat-select-empty");
        if (vehicleTypeIsNotFilled || dropdownDisabled == null || !dropdownDisabled.equals("true")) {
            selectValueInDropdown(vehicleType, vehicleTypeDropdown, addVehicleSideDialogSubtitle);
//    		selectValueInDropDown(vehicleTypeDropdown, vehicleInfo.getVehicleType());
        }
        Log.info("Selected vehicle type: " + vehicleType);
    }

    public WhoShouldWeInsurePage selectVehicleYear(Vehicle vehicleInfo) throws Exception {
        String vehicleYear = vehicleInfo.getVehicleYear();
        Locator yearDropdown = isMA61Environment() ? vehicleYearDropdownAlternate : vehicleYearDropdown;
        waitElementBeVisibleClickable(yearDropdown);
        selectValueInDropdown(vehicleYear, yearDropdown, addVehicleSideDialogSubtitle);
        waitElementBeInvisible(dropDownOptions);
        Log.info("Selected vehicle year: " + vehicleYear);
        return this;
    }

    public WhoShouldWeInsurePage selectVehicleYear(String vehicleYear) throws Exception {
        selectValueInDropdown(vehicleYear, vehicleYearDropdown, addVehicleSideDialogSubtitle);
        waitElementBeInvisible(dropDownOptions);
        return this;
    }

    public void uncheckAllCheckedDriverCheckboxes() throws Exception {
        List<Locator> checkedDrivers = locators(pwXPath("//li[contains(@class,'auto-vehicles-drivers-review__drivers-list-details ng-star-inserted')]//mat-checkbox[contains(@class,'mat-mdc-checkbox-checked')]"));
        for (Locator checkedDriver : checkedDrivers) {
            clickElement(checkedDriver);
        }
    }

    public void uncheckAllCheckedVehicleCheckboxes() throws Exception {
        List<Locator> checkedVehicles = locators(pwXPath("//mat-checkbox[@class='mat-mdc-checkbox auto-vehicles-drivers-review__vehicles-list-details-checkbox mat-accent mat-mdc-checkbox-checked']"));
        for (Locator checkedVehicle : checkedVehicles) {
            clickElement(checkedVehicle);
        }
    }

    public void uncheckRandomAdditionalDriverCheckbox() throws Exception {
        new HeresWhatWeFoundPage().uncheckRandomAdditionalDriverCheckbox();
    }

    public Vehicle updateApplicantRandomVehicleYear() throws Exception {
        Vehicle vehicleInfo = new Vehicle();

        waitElementBeVisible(vehicleYearDropdown);

        // update new year
        String existingVehicleYear = getTextFromElement(vehicleYearDropdownValue);
        int updatedVehicleYear = Integer.parseInt(existingVehicleYear);
        vehicleInfo.setVehicleYear(String.valueOf(updatedVehicleYear + 1));

        // update Vehicle Make
        String existingVehicleMake = getInputFieldValue(vehicleMakeEntryField);
        vehicleInfo.setVehicleMake(existingVehicleMake);

        // update Vehicle Model
        String existingVehicleModel = getInputFieldValue(vehicleModelEntryField);
        vehicleInfo.setVehicleModel(existingVehicleModel);

        // update Vehicle Type
        String existingVehicleType = getTextFromElement(vehicleTypeDropdownValue);
        vehicleInfo.setVehicleType(existingVehicleType);

        fillOutVehicleYearModelMakeFields(vehicleInfo);
        clickOnAddVehicleButtonAndWaitForSpinner();

        return vehicleInfo;
    }

    public void validateAddVehicleAndDriversButton() {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertEquals(getTextFromElement(addVehicleAndDriversButton), "Add vehicles and drivers");
        fsa.assertTrue(addVehicleAndDriversButton.isVisible(), "Add Vehicle and Drivers button is visible");
        clickOnAddVehicleAndDriversButton();
        fsa.assertAll();

    }

    public void validateDisplayedListOfDriversWithAges(AutoApplicant applicant) throws Exception {
//        Assert.assertTrue(areAddedListOfDriversWithAgesDisplayed(applicant), "Added drivers are displayed on the page");
        testStepAssert(areAddedListOfDriversWithAgesDisplayed(applicant), "Expected:Added drivers should be displayed on who should we insure page.Actual:Added drivers is displayed on who should we insure page");
    }

    public WhoShouldWeInsurePage validateDisplayedListOfVehicles(FarmersSoftAssert softAssert, AutoApplicant applicant) throws Exception {
//        List<String> displayedVehicleListings = actualListOfVehicleInfo.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> expectedVehicleListings = new ArrayList<>();

        for (Vehicle vehicleInfo : applicant.getVehicles()) {
            String vehicleMake = vehicleInfo.getVehicleMake();
            String vehicleModel = vehicleInfo.getVehicleModel();
            String vehicleYear = vehicleInfo.getVehicleYear();
            if (vehicleInfo.isUseVIN()) {
                AppStore.Auto.AppStoreVehicle vehicle = this.getSessionStorageAppStore().getAuto().getVehicles().stream().filter(each -> {
                    String vin = "";
                    boolean result = false;
                    try {
                        vin = each.getVin();
                        result = vin.equals(vehicleInfo.getVehicleVIN());
                    } catch (NullPointerException npe) {
                        Log.info("Vin is not provided for this vehicle");
                    }
                    return result;
                }).collect(Collectors.toList()).get(0);
                vehicleMake = vehicle.getMakeDesc();
                vehicleYear = vehicle.getYear();
                vehicleModel = vehicle.getModelDesc();
            }
            vehicleModel = vehicleInfo.getVehicleModel().contains("QUATTRO") ? "QUAT" : vehicleModel;

            String expectedVehicleName = vehicleYear + SPACE + vehicleMake + SPACE + vehicleModel;
            expectedVehicleListings.add(expectedVehicleName);
        }

        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();


        List<String> actualListOfVehiclesDisplayed = new ArrayList<>();
        if (isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            actualListOfVehiclesDisplayed = vehiclesDriversInfoPage.getDisplayedVehicles();
            Collections.sort(actualListOfVehiclesDisplayed);
            Log.info("Actual vehicle list  : " + actualListOfVehiclesDisplayed);
            Log.info("Expected vehicle list: " + expectedVehicleListings);
            softAssert.assertTrue(actualListOfVehiclesDisplayed.containsAll(expectedVehicleListings) && expectedVehicleListings.containsAll(actualListOfVehiclesDisplayed), "Expected: Vehicles (" + expectedVehicleListings + ") should be displayed in who should we insure page.Actual: Vehicles (" + actualListOfVehiclesDisplayed + ") is displayed in Who should we insure page");
        } else {
            int intVehiclesCount = getEleCount(lblVehiclesList.all(), 5);
            for (int i = 1; i <= intVehiclesCount; i++) {
                actualListOfVehiclesDisplayed.add(getTextFromElement(generateXpath(lblVehiclesName, "%d", Integer.toString(i))));
            }
        }
        testStepAssert(areTwoListEqual(actualListOfVehiclesDisplayed, expectedVehicleListings), "Expected:Vehicles (" + expectedVehicleListings + ") should be displayed in who should we insure page.Actual: Vehicles (" + actualListOfVehiclesDisplayed + ") is displayed in Who should we insure page");

        return this;
    }

    public WhoShouldWeInsurePage validateHeader() {
        waitForUiSettled();
        validateIfTextExist(addEditVehicleDialogHeader, "Header is not displayed");
        return this;
    }

    public WhoShouldWeInsurePage validateInfoText() {
        validateIfTextExist(addVehicleSideDialogSubtitle, "Info text is not displayed");
        return this;
    }

    public WhoShouldWeInsurePage validatePageContent() {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(whoShouldWeInsurePageContent.isVisible(), "Who should we insure page message is visible");
        fsa.assertAll();
        return this;
    }

    public WhoShouldWeInsurePage validatePageTitle() {
        waitElementBeVisible(whoShouldWeInsureTitle);
        return this;
    }

    public void validatePniAndSniStatus(AutoApplicant applicant) throws Exception {
        waitForUiSettled();
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        List<String> actualPniAndSniNames = locators(disabledCheckBoxLabel).stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> expectedPniAndSniNames = List.of(getApplicantFullName(applicant), getAdditionalDriverFullName(getSni(applicant)));
        fsa.assertEquals(actualPniAndSniNames, expectedPniAndSniNames, "Validate PNI and SNI status");
        fsa.assertAll();
    }

    public WhoShouldWeInsurePage validateRequiredFieldErrorMessage(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(requiredFieldErrorMessage)), REQUIRED_FIELD_ERROR_MESSAGE, "Validate required field error");
        return this;
    }

    public WhoShouldWeInsurePage validateSubNote() {
        validateIfTextExist(subNote, "Sub note is not displayed");
        return this;
    }

    public void validateVINAndYMMFormFields(FarmersSoftAssert fsa) {
        Function<List<Locator>, List<String>> function = labels -> labels.stream().map(this::getTextFromElement).collect(Collectors.toList());
        clickOnYMMButton();
        List<String> listOfActualFieldLabels = function.apply(formFieldLabels.all());
        clickOnVinButton();
        listOfActualFieldLabels.addAll(function.apply(formFieldLabels.all()));
        listOfActualFieldLabels.removeIf(String::isEmpty);
        listOfActualFieldLabels = listOfActualFieldLabels.stream().distinct().collect(Collectors.toList());
        List<String> listOfExpectedFieldLabels = Stream.of("Year", "VIN", "Search make", "Search model, trim", "Select vehicle type").collect(Collectors.toList());
        Collections.sort(listOfActualFieldLabels);
        Collections.sort(listOfExpectedFieldLabels);
        fsa.assertEquals(listOfActualFieldLabels, listOfExpectedFieldLabels, "Validate VIN and YMM form fields");
    }

    public WhoShouldWeInsurePage validateVehicleMakeFieldErrorMessage(FarmersSoftAssert fsa) {
        softAssertFormFieldErrorMessage("Please provide make.", fsa);
        return this;
    }

    public WhoShouldWeInsurePage validateVehicleModelAndTrimFieldErrorMessage(FarmersSoftAssert fsa) {
        softAssertFormFieldErrorMessage("Please provide model, trim.", fsa);
        return this;
    }

    public WhoShouldWeInsurePage validateVehicleTypeFieldErrorMessage(FarmersSoftAssert fsa) {
        softAssertFormFieldErrorMessage("Please provide vehicle type.", fsa);
        return this;
    }

    public WhoShouldWeInsurePage validateVehicleVINFieldErrorMessage(FarmersSoftAssert fsa) {
        softAssertFormFieldErrorMessage("Enter VIN or select Year, make and model.", fsa);
        return this;
    }

    public WhoShouldWeInsurePage validateVehicleYearFieldErrorMessage(FarmersSoftAssert fsa) {
        softAssertFormFieldErrorMessage("Please provide year.", fsa);
        return this;
    }

    public void validateWhereCanIFindThis() {
        validateIfTextExist(whereCanIFindThisLink, "Where can I find this link is not displayed");
    }

    public boolean doesVINFieldHaveFocus() {
        waitElementBeVisible(addVehicleDialogHeader);
        return doesElementHaveFocus(waitElementBeVisible(vehicleVINEntryField));
    }

    public boolean isVehicleAdditionSideSheetVisible() {
        return isElementVisible(addVehicleDialogHeader, 1);
    }

    public boolean doesDriverFirstNameFieldHaveFocus() throws Exception {
        waitElementBeVisible(addDriverDialogHeader);
        return doesElementHaveFocus(waitElementBeVisible(getFormInputFieldLocator(FIRST_NAME)));
    }

    public void enterAdditionalDriverData(AutoApplicant applicant, SqlAdditionalDriver driver) throws Exception {
        enterFirstName(driver.getFirstName());
        enterLastName(driver.getLastName());
        enterDateOfBirth(driver.getDateOfBirth());
        selectGenderTabButton(driver.getGender());
        selectUsOrCanadaLicensedRadioButton(driver.getLicenseToDriveInUSA());
        selectDoYouCommuteToNYIfApplicable(applicant);
    }

    private void addAdditionalSniDriver(SqlAdditionalDriver driver) throws Exception {
        selectGenderTabButton(driver.getGender());
        selectUsOrCanadaLicensedRadioButton(driver.getLicenseToDriveInUSA());
    }

    private void addAllDrivers(AutoApplicant applicant) throws Exception {
        addMainDriver(applicant);
        addAdditionalDrivers(applicant);
        clickOnDoneAddingDriversButton();
    }

    public void addMainDriver(AutoApplicant applicant) throws Exception {
        if(!isElementVisible(addDriverDialogHeader,2)) {
            AppStore.Data.CustomerData customerData = getSessionStorageAppStore().getData().getCustomerData();
            String pniFullName = customerData.getFirstName() + SPACE + customerData.getLastName();
            clickEditButtonWithDriverFullName(pniFullName);
        }
        selectGenderTabButton(applicant.getGender());
        String hasUSLicense = applicant.getFirstAgeForeignDriverLicense() == 18 ? NO : YES;
        selectUsOrCanadaLicensedRadioButton(hasUSLicense);
        selectDoYouCommuteToNYIfApplicable(applicant);
        selectCurrentlyInsuredRadioButton(applicant);
        clickOnSaveButton();
    }

    public void addAdditionalDrivers(AutoApplicant applicant) throws Exception {
        List<SqlAdditionalDriver> listOfAdditionalDrivers = applicant.getAdditionalDrivers();
        int numberOfAdditionalDrivers = Math.min(listOfAdditionalDrivers.size(), MAX_NUMBER_OF_ADDITIONALDRIVERS);
        for (int d = 0; d < numberOfAdditionalDrivers; d++) {
            SqlAdditionalDriver additionalDriver = listOfAdditionalDrivers.get(d);
            clickOnAddAnotherDriverButtonSideSheet();
            waitElementBeVisible(addDriverDialogHeader);
            enterAdditionalDriverData(applicant, additionalDriver);
            clickOnSaveButton();
        }
    }

    private void addAllDriversWithMoreThan4AdditionalDrivers(AutoApplicant applicant) throws Exception {
        addMainDriver(applicant);

        List<SqlAdditionalDriver> listOfAdditionalDrivers = applicant.getAdditionalDrivers();
        for (SqlAdditionalDriver additionalDriver : listOfAdditionalDrivers) {
            clickOnAddAnotherDriverButtonSideSheet();
            waitElementBeVisible(addDriverDialogHeader);
            enterAdditionalDriverData(applicant, additionalDriver);
            clickOnSaveButton();

            // Unchecking couple additional drivers from the list
            List<Locator> listOfCheckedDrivers = new HeresWhatWeFoundPage().getCheckedDriverNames();
            if (listOfCheckedDrivers.size() == 4) {
                waitAndClickElement(listOfCheckedDrivers.get(1));
            }
        }
        clickOnDoneAddingDriversButton();
        checkAllUncheckedDriverCheckboxes();
    }

    private void addAllVehiclesInList(AutoApplicant applicant, String stateCode) throws Exception {
        List<Vehicle> listOfVehicles = applicant.getVehicles();
        int numberOfVehicles = limitVehicleCountToMaxAllowed(stateCode, listOfVehicles.size());
        isElementPresent(pwCss("h4[id='addVehicleHeading']"), 2);
        for (int v = 0; v < numberOfVehicles; v++) {
            if (new ContactInfoAutoPage().isOnContactInfoAutoPage()) {
                Log.info("Contact information appeared while adding vehicles; stopping vehicle loop early.");
                break;
            }

            Vehicle vehicleInfo = listOfVehicles.get(v);

            if (vehicleInfo.isUseVIN()) {
                try {
                    fillOutVinField(vehicleInfo.getVehicleVIN());
                    int retry = 3;
                    while (isElementPresent(pwXPath("//mat-error")) && retry > 0) {
                        vehicleInfo.setVehicleVIN(getRandomVinNumber(3));
                        fillOutVinField(vehicleInfo.getVehicleVIN());
                        retry--;
                        if (retry == 0) {
                            Log.error("Fetching random vin from Randomvin.com was not successful");
                        }
                    }
                    String strTempVINDesc = getTextFromElement(lblVINDescription);
                    String[] arrVINDesc = strTempVINDesc.split(":");
                    String strVINDesc = arrVINDesc[1].trim();
                    vehicleInfo.setVinDescription(strVINDesc);
                    fillOutVehicleTypeIfNeeded(vehicleInfo.getVehicleType());
                } catch (Exception e) {
                    Log.debug(e.getMessage());
                    //vehicleInfo.setVehicleVIN(getRandomVinNumber(3));
                }

            } else {
                vehicleInfo.setUseVIN(false);
                fillOutVehicleYearModelMakeFields(vehicleInfo);
            }
            clickOnAddVehicleButtonAndWaitForSpinner();
            if (v != numberOfVehicles - 1) {
                clickOnAddAnotherVehicleButtonSideSheet();
            }
        }

        for (int v = 0; v < numberOfVehicles; v++) {
            Vehicle vehicleInfo = listOfVehicles.get(v);
            if (vehicleInfo.isUseVIN()) {
                List<AppStore.Auto.AppStoreVehicle> vehicles = getSessionStorageAppStore().getAuto().getVehicles();
                if(!vehicles.isEmpty()) {
                    AppStore.Auto.AppStoreVehicle appStoreVehicle = vehicles.get(v);
                    updateVehicleObjectWithNewlyAddedVehicleByVIN(appStoreVehicle, vehicleInfo);
                }
            }
        }
        if (isElementPresent(pwCss("button.close-button"), 2)) {
        	clickOnDoneAddingVehiclesButton();
        }
    }

    // update the vehicle object with newly added vehicle details from AppStore by VIN
    public void updateVehicleObjectWithNewlyAddedVehicleByVIN(AppStore.Auto.AppStoreVehicle appStoreVehicle, Vehicle vehicle) {
        vehicle.setVehicleMake(appStoreVehicle.getMakeDesc());
        vehicle.setVehicleModel(appStoreVehicle.getModelDesc());
        vehicle.setVehicleYear(appStoreVehicle.getYear());
        vehicle.setVehicleType(appStoreVehicle.getVehicleType());
    }

    public void clickOnAddAnotherVehicleButtonSideSheet() throws Exception {
    	if (isElementPresent(pwXPath("//button[contains(@class, 'tui-btn tui-btn-cta add-vehicle-button')]"), 2)) {
    		waitAndClickElement(addAnotherVehicleButton);
    	} else {
    		clickAddAnotherVehicleButton();
    	}
    }

    public void fillOutVehicleTypeIfNeeded(String vehicleType) throws Exception {
        if (getAttributeData(vehicleTypeDropdown, CLASS).contains("ng-invalid")) {
            selectVehicleType(vehicleType);
        }
    }

    private void checkAllUncheckedDriverCheckboxes() throws Exception {

        int numberOfCheckBoxes = new HeresWhatWeFoundPage().getNumberOfUncheckedDrivers();
        for (int i = 0; i < numberOfCheckBoxes; i++) {
            waitUntilAngular5Ready();
            Locator checkbox = locators(pwXPath(new HeresWhatWeFoundPage().getUnCheckedDriverNamesXpath())).get(0);
            waitAndClickElement(checkbox);
        }
    }

    public void clickAddAnotherVehicleButton() throws Exception {
        if (isElementVisible(addAnotherVehicleLink, 3)) {
            waitAndClickElement(addAnotherVehicleLink);
        } else {
            waitAndClickElement(addAnotherVehicleLinkAlternative);
        }
    }


    public void clickAddAnotherDriverButton() throws Exception {
        waitAndClickElement(addAnotherDriverButton);
    }

    protected void clickOnAddAnotherDriverButtonSideSheet() throws Exception {
        waitAndClickElement(addAnotherDriverButtonSideSheet);
    }

    private void clickOnButtonWithLabel(String label) throws Exception {
        Locator webElement = locator(pwXPath(String.format("//button[contains(text(),'%s')]", label)));
        scrollAndClickOnElement(webElement);
    }

    public void clickOnDoneAddingDriversButton() throws Exception {
        // Wait longer and check for validation errors
        if (isElementVisible(doneAddingDriversButton, 2)) {
            waitAndClickElement(doneAddingDriversButton);
        } else if (isElementVisible(doneAddingDriversButtonAlternative, 2)) {
            waitAndClickElement(doneAddingDriversButtonAlternative);
        } else {
            // Button not visible - check for form errors that may be blocking it
            try {
                Locator errorElements = locator(pwXPath("//mat-error[text()]"));
                if (errorElements.count() > 0) {
                    Log.warn("Form has validation errors preventing Done button from appearing. Scrolling up to diagnose.");
                    scrollToTopOfPage();
                    waitForSpinnerToBeGone();
                }
            } catch (Exception e) {
                Log.debug("Could not detect validation errors via DOM");
            }
            
            // Try again with extended timeout after potential fixes
            if (isElementVisible(doneAddingDriversButton, 10)) {
                waitAndClickElement(doneAddingDriversButton);
            } else if (isElementVisible(doneAddingDriversButtonAlternative, 5)) {
                waitAndClickElement(doneAddingDriversButtonAlternative);
            } else {
                Log.error("Done adding drivers button still not found after extended wait. Diagnostics: form may be invalid or in incorrect state.");
                throw new TimeoutError("Button 'Done adding drivers' not found after 15 seconds");
            }
        }
        waitForSpinnerToBeGone();
    }

    @SneakyThrows
    private void closeTheSideDialog() {
        refreshPage();
        waitElementBeInvisible(xButton);
    }

    private WhoShouldWeInsurePage enterCurrentInsuranceCompany(String currentInsuranceCompany) throws Exception {
        if (!isElementDisplayed(pwXPath("//mat-form-field[.//mat-label[contains(text(),'" + CURRENT_INSURANCE_COMPANY + "')]]//input[not(@hidden)]"))) {
            return this;
        }
        Locator currentPolicyDropdown = getFormInputFieldLocator(CURRENT_INSURANCE_COMPANY);
        String currentPolicy = currentInsuranceCompany.toUpperCase();
        enterValueInField(currentPolicy, currentPolicyDropdown, "entering driver`s current insurance company");
        if (!selectValueInDropdown(currentPolicy, currentPolicyDropdown, genderSelectForm)) {
            scrollToElement(currentPolicyDropdown);
            sendKeysToElement(currentPolicyDropdown, "OTHERS");
            waitForUiSettled();
            sendKeysToElement(currentPolicyDropdown, Keys.DOWN);
            sendKeysToElement(currentPolicyDropdown, Keys.ENTER);
        }
        return this;
    }

    private WhoShouldWeInsurePage enterDateOfBirth(String dateOfBirth) {
        enterValueInField(dateOfBirth, dateOfBirthEntryField, "Entering driver`s date of birth");
        return this;
    }

    private WhoShouldWeInsurePage enterFirstName(String firstName) throws Exception {
        Locator firstNameInputField = getFormInputFieldLocator(FIRST_NAME);
        enterValueInField(firstName, firstNameInputField, "Entering driver`s first name");
        if (getAttributeData(firstNameInputField, CLASS).contains("ng-invalid")) {
            sendKeysToElement(firstNameInputField, firstName);
        }
        return this;
    }

    private WhoShouldWeInsurePage enterLastName(String lastName) throws Exception {
        enterValueInField(lastName, getFormInputFieldLocator(LAST_NAME), "Entering driver`s last name");
        return this;
    }

    private WhoShouldWeInsurePage enterPolicyExpirationDate(String policyExpirationDate) throws Exception {

        List<Locator> policyExpirationDates = locators(pwXPath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_INPUT_FIELDS, POLICY_EXP_DATE)));

        if (policyExpirationDates.isEmpty()) {
            return this;
        }
        enterValueInField(policyExpirationDate, policyExpirationDates.get(0), "entering driver`s policy expiration date");

        Log.info("Set prior policy exp date to : " + policyExpirationDate);
        return this;
    }

    private WhoShouldWeInsurePage enterPriorInsuranceCompany(String priorInsuranceCompany) throws Exception {
        Locator priorPolicyDropdown = getFormInputFieldLocator("Prior insurance company");
        enterValueInField(priorInsuranceCompany, priorPolicyDropdown, "entering driver`s prior insurance company");
        selectValueInDropDown(priorPolicyDropdown, priorInsuranceCompany);
        return this;
    }

    private void enterVehicleModelAndTrim(Vehicle vehicleInfo) throws Exception {
        if (!isElementVisible(vehicleModelEntryField, 5)) {
            waitForSpinnerToBeGone();
            if (!isElementVisible(vehicleModelEntryField, 2)) {
                Log.warn("Vehicle model input is still disabled after make selection; retrying make selection once.");
                enterVehicleMake(vehicleInfo);
            }
        }
        enterVehicleModelAndTrim(vehicleInfo.getVehicleModel());
    }

    private String getAdditionalDriverFullName(SqlAdditionalDriver additionalDriver) {
        return String.join(" ", additionalDriver.getFirstName(), additionalDriver.getLastName());
    }

    private String getApplicantFullName(AutoApplicant applicant) {
        return String.join(" ", applicant.getFirstName(), applicant.getLastName());
    }

    private Locator getDropDownLocator(String label) throws Exception {
        return locator(pwXPath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_DROP_DOWN_FIELDS, label)));
    }

    private Locator getFormInputFieldLocator(String label) throws Exception {
        Locator webElement = locator(pwXPath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_INPUT_FIELDS, label)));
        waitElementBeVisible(webElement);
        return webElement;
    }

    private SqlAdditionalDriver getSni(AutoApplicant applicant) throws Exception {
        return new DriverReviewPage().getSni(applicant);
    }

    private void selectContinuouslyInsuredForPastSixMonthsRadioButtonIfExists(String yesOrNo) throws Exception {
        String lastSixMonthInsuredInfo = pwXPath(String.format("//div[contains(@id,'formField_lastSixMonthsInsuredInfo')]//mat-radio-group[contains(@class,'auto-add-driver-last-sixmonths-insured-info__radio-buttons')]//mat-radio-button[contains(.,'%s')]", yesOrNo));
        if (isElementDisplayed(lastSixMonthInsuredInfo)) {
            Locator webElement = locator(lastSixMonthInsuredInfo);
            waitAndClickElement(webElement);
        }
    }

    private void selectMilitaryDeploymentQuestionIfExists() throws Exception {
        String yesOrNo = RandomUtils.nextBoolean() ? "Yes" : "No";
        String militaryDeploymentQuestionByObject = pwXPath(String.format("//div[contains(@id,'militaryDeploymentInfo')]//mat-radio-button[.//span[contains(text(),'%s')]]", yesOrNo));
        if (isElementDisplayed(militaryDeploymentQuestionByObject)) {
            Locator webElement = locator(militaryDeploymentQuestionByObject);
            waitAndClickElement(webElement);
        }
    }

    public WhoShouldWeInsurePage selectCurrentBodilyInjuryLimits(String biLimit) throws Exception {
        if (!isElementDisplayed(pwXPath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_DROP_DOWN_FIELDS, CURRENT_BI_LIMITS)))) {
            return this;
        }

        Locator currentBodilyInjuryLimitDropdown = getDropDownLocator(CURRENT_BI_LIMITS);
        selectValueInDropdown(biLimit, currentBodilyInjuryLimitDropdown, genderSelectForm);
        Log.info("Set current BI limit to : " + biLimit);
        return this;
    }

    public void selectPipProtectionIfApplicable(AutoApplicant applicant) throws Exception {
        if(!applicant.getStateCode().equals(NJ)) {
            return;
        }
        Locator currentPIPLimits = getDropDownLocator("Current Principal Personal Injury Protection (PIP) limits");
        List<String> availablePipValues = getSessionStorageAppStore().getAuto().getDropdowns().getDriver().getDropDownResponseBeans().stream().filter(each -> each.getFieldName().equals("prinicipalPip")).findFirst().get().getDropDownValues().stream().map(AppStore.Auto.Dropdowns.Driver.DropDownResponseBean.DropDownValue::getWebDesc).collect(Collectors.toList());
        Collections.shuffle(availablePipValues);
        String selection = availablePipValues.get(0);
        selectValueInDropdown(selection, currentPIPLimits, genderSelectForm);
        Log.info("User selected PIP value as : " + selection);
    }

    public WhoShouldWeInsurePage selectCurrentlyInsuredRadioButton(AutoApplicant applicant) throws Exception {
        if (applicant.getStateCode().equals(CA)) {
            // CA does not ask about prior insurance
            return this;
        }
        waitElementBeVisible(insuredSelectForm);
        String hasBeenContinuallyInsuredForLastSixMonths = applicant.getContinuosInsurancePeriod().equals("< 6 Months") ? NO : YES;
        String applicantCurrentlyInsured = applicant.getCurrentlyInsuredStatus().equals("Insured") ? YES : NO;
        Locator currentlyInsuredSelection = locator(pwXPath(String.format("//div[contains(@id,'formField_currentlyInsured')]//mat-radio-button[contains(.,'%s')]//input", applicantCurrentlyInsured)));
        scrollAndClickOnElement(currentlyInsuredSelection);
        int retry = 3;
        while (!getAttributeData(currentlyInsuredSelection, CLASS).contains(RADIO_BUTTON_CHECKED) && retry>0) {
        	clickElement(currentlyInsuredSelection);
        	waitForUiSettled();
        	retry--;
        }
        if (applicantCurrentlyInsured.equals(YES)) {
            if(applicant.getStateCode().equals(NV) && !applicant.getTestScenario().contains(SPECIAL_BI_LIMIT_IS_NEEDED)) {
                applicant.setContinuosInsurancePeriod(">12 Months");
            }
            enterCurrentInsuranceCompany(applicant.getCurrentInsuranceCompany());
            updateApplicantCurrentInsuranceBiLimit(applicant);
            selectCurrentBodilyInjuryLimits(applicant.getCurrentBodilyInjuryLimit());
            selectPipProtectionIfApplicable(applicant);
            enterPolicyExpirationDate(applicant.getCurrentInsuranceExpirationDate());
            updateApplicantCurrentInsuranceDuration(applicant);
            selectLengthOfCurrentInsurance(applicant.getContinuosInsurancePeriod());
            selectContinuouslyInsuredForPastSixMonthsRadioButtonIfExists(hasBeenContinuallyInsuredForLastSixMonths);
            selectMilitaryDeploymentQuestionIfExists();
            if (applicant.getTestScenario().contains("UMB")) {
                Log.info("BI Limit set to " + applicant.getCurrentBodilyInjuryLimit() + NEWLINE, applicant.getTestScenario() + "BILimit");
            }
        } else {
            waitElementBeVisible(notInsuredReasonDropdownField);
            switch (applicant.getCurrentlyInsuredStatus()) {
                case NEVER_INSURED:
                    selectValueInDropDown(waitElementBeVisible(notInsuredReasonDropdownField), "I never had insurance");
                    break;
                case EXPIRED:
                    selectValueInDropDown(notInsuredReasonDropdownField, MY_INSURANCE_EXPIRED);
                    selectValueInDropdown("Before", priorInsuranceExpiredDropdownField, currentlyInsuredSelection);
                    if(applicant.getStateCode().equals(OR)) {
                        enterPriorInsuranceCompany(applicant.getCurrentInsuranceCompany().toUpperCase());
                        selectPriorBodilyInjuryLimits(applicant.getCurrentBodilyInjuryLimit());
                        // update length from available options
                        List<String> availableLengths = getSessionStorageAppStore().getAuto().getDropdowns().getDriver().getDropDownResponseBeans().stream().filter(each -> each.getFieldName().equals("lapseInCvgYes")).map(each -> each.getDropDownValues().get(0).getWebDesc()).collect(Collectors.toList());
                        Collections.shuffle(availableLengths);
                        String length = availableLengths.get(0);
                        selectLengthOfPriorInsurance(length);
                    }
                    selectContinuouslyInsuredForPastSixMonthsRadioButtonIfExists(hasBeenContinuallyInsuredForLastSixMonths);
                    selectMilitaryDeploymentQuestionIfExists();
                    break;
                case NOT_REQUIRED:
                    selectValueInDropDown(notInsuredReasonDropdownField, "I was not required to have insurance");
                    break;
                case DEPLOYED:
                    selectValueInDropDown(notInsuredReasonDropdownField, "I was in the military and deployed overseas");
                    break;
                default:
                    Log.warn("Unrecognized insured status: " + applicant.getCurrentlyInsuredStatus());
                    break;
            }
        }
        return this;
    }

    public void selectDoYouCommuteToNYIfApplicable(AutoApplicant applicant) throws Exception {
        if(!getSessionStorageAppStore().getData().getLandingStateCode().equals(NJ)) {
            return; // only applicable for NJ
        }
        String commutes = applicant.getTestScenario().contains(NEW_YORK_COMMUTER) ? "Yes" : "No";
        Locator commutesElement = locator(pwXPath(String.format("//div[contains(@id,'commuteToNYNJ')]//mat-radio-button[contains(.,'%s')]", commutes)));
        waitAndClickElement(commutesElement);
        Log.info("For 'Do you commute to NY?' question User selected " + commutes, true);
    }


    public void updateApplicantCurrentInsuranceBiLimit(AutoApplicant applicant) throws Exception {
        if(applicant.getTestScenario().contains(DEFAULT_COVERAGE_VALIDATION) || applicant.getTestScenario().contains(SPECIAL_BI_LIMIT_IS_NEEDED)) {
            return;
        }
        List<String> availableBiLimits = getSessionStorageAppStore().getAuto().getDropdowns().getDriver().getDropDownResponseBeans().stream().filter(each -> each.getFieldName().equals("currentPolicyLimits")).findFirst().get().getDropDownValues().stream().map(each -> each.getWebDesc()).collect(Collectors.toList());
        // removing state minimums
        availableBiLimits.remove(_10K_AND_20K);
        availableBiLimits.remove(_15K_AND_30K);
        availableBiLimits.remove(_20K_AND_40K);
        availableBiLimits.remove(_25K_AND_50K);
        availableBiLimits.remove(_30K_AND_60K);
        if(getSessionStorageAppStore().getData().getLandingStateCode().equals(CT) && applicant.getTestScenario().contains("BW")) {
            availableBiLimits.remove(_100K_AND_300K);
        }
        Collections.shuffle(availableBiLimits);
        if(availableBiLimits.isEmpty()) {
            return;
        }
        String updatedBiLImit = availableBiLimits.get(0);
        applicant.setCurrentBodilyInjuryLimit(updatedBiLImit);
        Log.info("Applicant prior bi limit is updated to : " + updatedBiLImit);
    }

    public void updateApplicantCurrentInsuranceDuration(AutoApplicant applicant) throws Exception {
        if (applicant.getContinuosInsurancePeriod().equals("< 6 Months") || applicant.getStateCode().equals(WA)) {
            return; //return if less than 6 month is desired
        }
        List<String> availableLength = getSessionStorageAppStore().getAuto().getDropdowns().getDriver().getDropDownResponseBeans().stream().filter(each -> each.getFieldName().equals("lapseInCvgYes")).findFirst().get().getDropDownValues().stream().map(AppStore.Auto.Dropdowns.Driver.DropDownResponseBean.DropDownValue::getWebDesc).collect(Collectors.toList());
        availableLength.removeIf(each -> each.contains("6 Months") || each.contains("6 - 11 Months"));
        Collections.shuffle(availableLength);
        applicant.setContinuosInsurancePeriod(availableLength.get(0));
    }

    public WhoShouldWeInsurePage selectGenderTabButton(String gender) throws Exception {
        waitElementBeVisible(genderSelectForm);
        Locator webElement = locator(pwXPath(String.format(GENDER_SECTION_XPATH + "//button[.//span[contains(text(),'%s')]]", gender.substring(0, 1))));
        scrollAndClickOnElement(webElement);
        return this;
    }

    private WhoShouldWeInsurePage selectLengthOfCurrentInsurance(String lengthOfCurrentInsurance) throws Exception {
        if (!isElementDisplayed(pwXPath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_DROP_DOWN_FIELDS, LENGTH_OF_CURRENT_INSURANCE)))) {
            return this;
        }
        Locator element = getDropDownLocator(LENGTH_OF_CURRENT_INSURANCE);
        selectValueInDropDown(element, lengthOfCurrentInsurance);
        Log.info("Set the length of the current insurance to : " + lengthOfCurrentInsurance);
        return this;
    }

    private WhoShouldWeInsurePage selectLengthOfPriorInsurance(String lengthOfPriorInsurance) throws Exception {
        Locator element = getDropDownLocator("Length of prior insurance");
        selectValueInDropDown(element, lengthOfPriorInsurance);
        return this;
    }

    private WhoShouldWeInsurePage selectPriorBodilyInjuryLimits(String biLimit) throws Exception {
        Locator webElement = getDropDownLocator("Prior Bodily Injury (BI) limits");
        selectValueInDropDown(webElement, biLimit);
        return this;
    }

    private void softAssertFormFieldErrorMessage(String expectedErrorMessage, FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(fieldErrorMessage)), expectedErrorMessage, "Verifying " + expectedErrorMessage);
    }

    private void validateIfTextExist(Locator webElement, String message) {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(webElement.isVisible(), message);
        fsa.assertAll();
    }

    public void validateValidVIN_WhoShouldWeInsurePage() throws Exception {
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        if (isElementDisplayed(addVehicleAndDriversButton, 5)) {
            clickOnAddVehicleAndDriversButton();
        }
        String[] arrayOfValidVINs = {"3GCEK23319G222136", "2G1FP32K622106243", "WAUFFAFLXCA100747", "2C4RDGCG0DR534656"};
        for (String validVIN : arrayOfValidVINs) {
            enterValueInField(validVIN, txtVINUnmasked, "Entering VIN: ");
            waitForSpinnerToBeGone();
            String errorMessage = getErrorMessagesFromAllFields();
            String logMessage = setLogMessage(errorMessage);
            testStepAssert(errorMessage.equals(EMPTY_STRING), "Expected:No error message should be displayed for valid vin (" + validVIN + "). Actual:" + logMessage + " displayed for valid vin");
            if (isElementDisplayed(additionalInfoVehicleSectionOneUI.vinIsCorrectLink, 5)) {
                clickElement(additionalInfoVehicleSectionOneUI.vinIsCorrectLink);
            }
        }

    }

    public void validateInvalidVIN_WhoShouldWeInsurePage() throws Exception {
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        String stateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        boolean isStreamLine = isVehiclesDriversConsolidationImpl(stateCode);
        if (isElementDisplayed(addVehicleAndDriversButton, 5)) {
            clickOnAddVehicleAndDriversButton();
        }
        String[] arrayOfInvalidVINs = {"3FABP4BJ7HM147392", "WP0ZZZ99ZTS392124", "3GCEI23319G222136", "3GCEQ23319G222136", "11111111111111111"};
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();

        if (!isStreamLine) {
            waitElementBeVisibleClickable(vehicleVINEntryField);
        }
        for (String invalidVIN : arrayOfInvalidVINs) {
            if (!isStreamLine) {
                enterValueInField(invalidVIN, vehicleVINEntryField, "Entering VIN: ");
                waitForSpinnerToBeGone();
                sendTab(vehicleVINEntryField);
            } else {
                vehiclesDriversInfoPage.sendKeysToVinInputField(invalidVIN);
                waitForSpinnerToBeGone();
            }
            String errorMessage = getErrorMessagesFromAllFields();
            String logMessage = setLogMessage(errorMessage);
            testStepAssert(!errorMessage.equals(EMPTY_STRING), "Expected:Error message should be displayed for invalid vin (" + invalidVIN + "). Actual:" + logMessage + " displayed for invalid vin");

            if (isElementDisplayed(additionalInfoVehicleSectionOneUI.vinIsCorrectLink, 5)) {
                waitAndClickElement(additionalInfoVehicleSectionOneUI.vinIsCorrectLink);
            }
        }
    }

    public void validateReplaceValidWithInvalidVIN_WhoShouldWeInsurePage() throws Exception {
        AdditionalInfoVehicleSectionOneUI additionalInfoVehicleSectionOneUI = new AdditionalInfoVehicleSectionOneUI();
        if (isElementDisplayed(addVehicleAndDriversButton, 5)) {
            clickOnAddVehicleAndDriversButton();
        }
        enterValueInField("5GZCZ43D13S812715", txtVINUnmasked, "Entering Valid VIN: ");
        waitForSpinnerToBeGone();
        String errorMessage = getErrorMessagesFromAllFields();
        String logMessage = setLogMessage(errorMessage);
        testStepAssert(errorMessage.equals(EMPTY_STRING), "Expected:No error message should be displayed for valid vin (5GZCZ43D13S812715). Actual:" + logMessage + " displayed for valid vin");
        if (isElementDisplayed(additionalInfoVehicleSectionOneUI.vinIsCorrectLink, 5)) {
            waitAndClickElement(additionalInfoVehicleSectionOneUI.vinIsCorrectLink);
        }
        enterValueInField("SGZCZ43D13S812715", txtVINUnmasked, "Entering Invalid VIN: ");
        waitForSpinnerToBeGone();
        waitForUiSettled();
        errorMessage = getErrorMessagesFromAllFields();
        logMessage = setLogMessage(errorMessage);
        testStepAssert(!getErrorMessagesFromAllFields().equals(""), "Expected:Error message should be displayed for replaced invalid vin (SGZCZ43D13S812715).Actual: " + logMessage + " displayed for replaced invalid vin");
        if (isElementDisplayed(additionalInfoVehicleSectionOneUI.vinIsCorrectLink, 5)) {
            waitAndClickElement(additionalInfoVehicleSectionOneUI.vinIsCorrectLink);
        }
    }

    private String setLogMessage(String errorMessage) {
    	return errorMessage.equals(EMPTY_STRING)? "No error": "Error message (" + errorMessage + ")";
    }

    public void validateCaHasNoPriorInsuranceQuestionAsked(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        testStep("Validate \"no prior insurance information is not applicable\" in the PNI details for CA State");
        addVehiclesWhenNoneAreFound(applicant);
        selectGenderTabButton(applicant.getGender());
        String hasUSLicense = applicant.getFirstAgeForeignDriverLicense() == 18 ? NO : YES;
        selectUsOrCanadaLicensedRadioButton(hasUSLicense);
        fsa.assertFalse(isElementVisible(insuredSelectForm, 2), "Prior insurance section should not be displayed for CA");
    }

    public void validateNoPriorInCurrentInsurnaceCompanyField_WhoShouldWeInsurePage(AutoApplicant applicant) throws Exception {
        addVehiclesWhenNoneAreFound(applicant);
        selectGenderTabButton(applicant.getGender());
        String hasUSLicense = applicant.getFirstAgeForeignDriverLicense() == 18 ? NO : YES;
        selectUsOrCanadaLicensedRadioButton(hasUSLicense);
        if (applicant.getStateCode().equals(CA)) {
            // CA does not ask about prior insurance
            return;
        }

        Locator webElement = null;
        waitElementBeVisible(insuredSelectForm);
        webElement = locator(pwXPath("//div[contains(@id,'currentlyInsured')]//input[contains(@value,'Yes')]"));
        scrollAndClickOnHiddenElement(webElement);
        PlaywrightWait wait = waitFor(5);
        Locator inputBox = wait.until(Conditions.attached(pwXPath("//label[contains(text(),'What is your current policy information')]/following::input[1]")));
        // Values to validate
        List<String> valuesToCheck = new ArrayList<>(Arrays.asList("NO PRIOR CARRIER", "NO PRIOR - MILITARY", "NO PRIOR - FIRST CAR", "NO PRIOR - CAR IN STORAGE", "NO PRIOR - ALL OTHER"));
        // Flag to check if all values are not present
        sendKeysToElement(inputBox, "NO");
        wait.until(Conditions.numberOfElementsToBeMoreThan(pwTag("mat-option"), 0));
        testStep("Prior insruance companies starting with No", true);
        List<String> valuesShownToUser = locators(pwXPath("//mat-option")).stream().map(this::getTextFromElement).collect(Collectors.toList());
        valuesShownToUser.forEach(each -> {
            testStepAssert(!valuesToCheck.contains(each), "Prior Insurance company list should not contain: " + each + ". Full list starting with NO: " + valuesShownToUser);
        });
    }

    public void validateADA_whoShouldWeInsurePage() throws Exception {
        if (!isADATestingEnabled()) return;

        // ada validate on the vehicle addition side sheet
        isOnWhoShouldWeInsurePage();
        waitAndClickElement(addVehicleAndDriversButton);
        waitAndClickElement(addVehicleButton);
        performADATesting(this.getClass().getSimpleName() + "_AddVehicleSideSheetVINToggle", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(whereCanIFindThisLink);
        performADATesting(this.getClass().getSimpleName() + "_AddVehicleSideSheetVinFinderHelper", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(backToVinButton);
        waitAndClickElement(vehicleYMMButton);
        performADATesting(this.getClass().getSimpleName() + "_AddVehicleSideSheetYMMToggle", MARKETING_IT, ACE_AUTO);
        // add mock vehicle to move forward with the flow
        waitAndClickElement(vehicleVINButton);
        fillOutVinField("2T1KR32E14C245975");
        waitAndClickElement(addVehicleButton);
        waitForSpinnerToBeGone();
        waitAndClickElement(doneAddingVehiclesButton);
        waitForSpinnerToBeGone();
        isElementVisible(addDriverDialogHeader, 2);
        scrollAndClickOnHiddenElement(currentlyInsuredYes);
        waitAndClickElement(driverSaveChangesButton);
        waitForPageToBeReady();
        performADATesting(this.getClass().getSimpleName() + "_AddApplicantSideSheetWithCurrentInsuranceYes", MARKETING_IT, ACE_AUTO);
        scrollAndClickOnHiddenElement(currentlyInsuredNo);
        if (isElementVisible(notInsuredReasonDropdownField, 1)) {
            selectValueInDropDown(notInsuredReasonDropdownField, MY_INSURANCE_EXPIRED);
        }
        waitAndClickElement(driverSaveChangesButton);
        waitForPageToBeReady();
        performADATesting(this.getClass().getSimpleName() + "_AddApplicantSideSheetWithCurrentInsuranceNo", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(closeIconMB);
        waitAndClickElement(checkedVehicles.nth(0));
        refreshPage();
        isOnWhoShouldWeInsurePage();
    }

    public void clickVehicleSaveChangesButton() {
        scrollAndClickOnElement(vehicleSaveChangesButton);
    }

    public void clickDriverSaveChangesButton() {
        scrollAndClickOnElement(driverSaveChangesButton);
    }

    public void addRandomAdditionalVehicle() throws Exception {
        clickAddAnotherVehicleButton();
        if (isElementVisible(addAnotherVehicleLinkAlternative2, 2)) {
            clickElement(addAnotherVehicleLinkAlternative2);
        }
        sendKeysToElement(waitElementBeVisible(vehicleVINEntryField), "1FTRF17283NB29646");
        waitForSpinnerToBeGone();
        scrollAndClickOnElement(addVehicleButton);

        if (isElementVisible(doneAddingVehiclesButton, 1)) {
            clickOnDoneAddingVehiclesButton();
        }
    }

    public void addRandomNewVehicle(String vinNumber) throws Exception {
        clickAddAnotherVehicleButton();
        if(isElementVisible(addAnotherVehicleLinkAlternative2,2)) {
            clickElement(addAnotherVehicleLinkAlternative2);
        }
        sendKeysToElement(waitElementBeVisible(vehicleVINEntryField), vinNumber);
        waitForSpinnerToBeGone();
        waitAndClickElement(addVehicleButton);
        if(isElementVisible(doneAddingVehiclesButton, 1)) {
            clickOnDoneAddingVehiclesButton();
        }
    }


    public void clickOnAddAVehicleButton() {
        scrollAndClickOnElement(addAVehicleButton);
    }

    public List<String> getNamesOfDisplayedDrivers() throws Exception {
        return locators(pwXPath("//ul[@class='auto-vehicles-drivers-review__drivers-list-section']//span[@class='mat-checkbox-label']")).stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    protected boolean isSaveDriverCtaIsPresent() {
        return isElementVisible(saveDriverCTAErrorMessage, 2);
    }

    public QuoteSummaryAutoPage navigateFromWhoShouldWeInsurePageToEitherQuoteSummaryPageUsingDefaults() throws Exception {
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        String stateCode = getStateCodeFromAppStore();
        boolean isStreamlineExpected = isVehiclesDriversConsolidationImpl(getStateCodeFromAppStore());
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        // Guard: skip vehicle/driver steps when the application already routed to Contact Info
        if (!contactInfoAutoPage.isOnContactInfoAutoPage()) {
        if (isStreamlineExpected) {
            new VehiclesDriversInfoPage().clickContinueButton();
        } else {
            clickOnContinueButton();
            VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
            testStepAssert(vehicleReviewPage.isOnVehiclesReviewPage(), "User is on the vehicle review page", true);
            vehicleReviewPage.clickContinueButton();
            testStepAssert(driverReviewPage.isOnDriverReviewPage(), "User is on the driver review page", true);

            AppStore.Auto.Driver driver = getSessionStorageAppStore().getAuto().getDrivers().get(0);
            if (driver.getMaritalStatus().equals("M")) {
                Locator maritalCheckbox = driverReviewPage.getMaritalCheckbox(driver.getFirstName() + SPACE + driver.getLastName());
                if (isCheckboxNotChecked(maritalCheckbox)) {
                    Log.error("Marital status of the driver is married but the checkbox is not checked, which is expected");
                } else {
                    Log.info("Marital status of the driver is married but the checkbox is checked, which is expected");
                }
            }
            driverReviewPage.fillOutDriverLicenseAges();
            driverReviewPage.fillOutDriverLicenseNumbers();
            driverReviewPage.fillOutOccupationAffinitySection();
            driverReviewPage.clickContinueButton();
        }
        } // end guard: skip vehicle/driver if already on Contact Info

        if (!isSignalDiscountDisabledState(stateCode) && !isBDQFlowEnabled() && !driverReviewPage.isOnBristolWest()) {
            SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
            if (signalPageOneUI.isOnSignalPage()) {
                signalPageOneUI.processSignalPage(true);
                Log.info("User has chosen to add Signal to the policy");
            } else {
                testStepAssert(contactInfoAutoPage.isOnContactInfoAutoPage(), "User is on the Signal page");
                Log.info("Signal page was skipped and user landed on Contact info page");
            }
        }

        testStepAssert(contactInfoAutoPage.isOnContactInfoAutoPage(), "User is on the Contact info page", true);
        contactInfoAutoPage.setValuesAndContinue();
        SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
        if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
            selectAQuoteToReviewPage.clickContinueMyQuote();
        }
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if (bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            bwFarmersQuotePresentmentPage.continueWithFarmers();
            waitForSpinnerToBeGone();
        }
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
            BristolWestAdditionalDiscountsPage additionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
            if (additionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
                additionalDiscountsPage.clickContinueButton();
            }
        }
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        vehicleDriverAssignmentPage.processVehiclesDriversAssignmentPageIfNeeded();

        AutoRentersBundleOfferingPage autoRentersBundleOfferingPage = new AutoRentersBundleOfferingPage();

        if (autoRentersBundleOfferingPage.isOnAutoRentersBundleOfferingPage()) {
            autoRentersBundleOfferingPage.processRentersBundleOfferingPage(false);
        }

        BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
        if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
            bristolWestAdditionalDiscountsPage.clickContinueButton();
        }
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        boolean onQuotePage = quoteSummaryAutoPage.isOnQuoteSummaryAutoPage();
        if (!onQuotePage) {
            onQuotePage = quoteSummaryAutoPage.isQuotePresentmentCardDisplayed();
        }
        testStepAssert(onQuotePage, "User is on the quote page", true);
        return quoteSummaryAutoPage;
    }

    public List<String> getDisplayedCompleteVehicles() throws Exception {
        List<String> completeVehiclesDisplayed = new ArrayList<>();
        List<Locator> listOfVehiclesAdded = locators(pwXPath(LIST_OF_VEHICLES_ADDED_XPATH));
        for (Locator vehicle : listOfVehiclesAdded) {
            String vehicleDescription = getTextFromElement(vehicle);
            completeVehiclesDisplayed.add(vehicleDescription);
        }
        return completeVehiclesDisplayed;
    }

    public List<String> getDisplayedCompleteDrivers() throws Exception {
        List<String> completeDisplayedDrivers = new ArrayList<>();
        for (Locator driver : lblDriversList.all()) {
            String driverDescription = getTextFromElement(driver);
            completeDisplayedDrivers.add(driverDescription);
        }
        return completeDisplayedDrivers;
    }

    public void excludeDriversEqualOrLessThan15() throws Exception {
        List<String> displayedCompleteDrivers = getDisplayedCompleteDrivers();
        for (String displayedDriver : displayedCompleteDrivers) {
        	//Driver names might have an apostrophe in them
            int age = getAgeOfDisplayedDriverByName(displayedDriver);
            if (age <= 15) {
                Locator radioCheckbox = locator(pwXPath(String.format(driverCheckboxXpath, displayedDriver)));
                if (isButtonSelected(radioCheckbox)) {
                    // exclude the driver whose age is less than 15
                    clickElement(radioCheckbox);
                }
            }

        }
    }

    public int getAgeOfDisplayedDriverByName(String displayedDriver) throws Exception {
        Locator ageSection = locator(pwXPath(String.format("//li[contains(@class,'drivers-list') and contains(.,\"%s\")]//span[contains(.,'Age')]", displayedDriver)));
        int age = Integer.parseInt(getTextFromElement(ageSection).replaceAll("\\D", ""));
        return age;
    }


    public void validateOrderOfBi_Limits() throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        Locator currentBodilyInjuryLimitDropdown = getDropDownLocator(CURRENT_BI_LIMITS);
        currentBodilyInjuryLimitDropdown.click();
        String HALF_FORMAT = "^\\$([\\d,]+)(\\.\\d+)?/\\$([\\d,]+)(\\.\\d+)?$";
        String SINGLE_FORMAT = "^\\$([\\d,]+)(\\.\\d+)?$";
        Pattern halfPattern = Pattern.compile(HALF_FORMAT);
        Pattern singlePattern = Pattern.compile(SINGLE_FORMAT);
        List<String> HALF_BI = new ArrayList<>();
        List<String> Single_BI = new ArrayList<>();
        List<Locator> ActualBI_Limits = locators(pwXPath("//div[@role='listbox']//span[@class='mat-option-text']"));
        for (Locator actualBILimit : ActualBI_Limits) {
            String BI_Limit = getTextFromElement(actualBILimit);
            if (halfPattern.matcher(BI_Limit).matches()) {
                BI_Limit = BI_Limit.replace("$", "").replace(",", "");
                HALF_BI.add(BI_Limit);
            } else if (singlePattern.matcher(BI_Limit).matches()) {
                BI_Limit = BI_Limit.replace("$", "").replace(",", "");
                Single_BI.add(BI_Limit);
            } else {
                Log.info(BI_Limit + "BI_Limit is not in the pattern");
            }
        }

        Log.info("Single Bi Limits: " + Single_BI);
        Log.info("Half Bi Limits: " + HALF_BI);
        for (int i = 0; i < HALF_BI.size() - 1; i++) {
            int FirstValue_FirstPart = Integer.parseInt(HALF_BI.get(i).split("/")[0]);
            int FirstValue_SecondPart = Integer.parseInt(HALF_BI.get(i).split("/")[1]);
            int NextValue_FirstPart = Integer.parseInt(HALF_BI.get(i + 1).split("/")[0]);
            int NextValue_SecondPart = Integer.parseInt(HALF_BI.get(i + 1).split("/")[1]);

            fsa.assertTrue(FirstValue_FirstPart <= NextValue_FirstPart, "HalfBI_value is not in Order");
            if(FirstValue_FirstPart == NextValue_FirstPart) {
                fsa.assertTrue(FirstValue_SecondPart < NextValue_SecondPart, "If first values are some, second value should be higher");
            }
        }
        for (int i = 0; i < Single_BI.size() - 1; i++) {
            int singleBIFirstValue = Integer.parseInt(Single_BI.get(i));
            int singleBISecondValue = Integer.parseInt(Single_BI.get(i + 1));
            fsa.assertTrue((singleBIFirstValue < singleBISecondValue), "Single BI_values are not in Order");
        }
        fsa.assertAll();
    }

    protected boolean isDriverSideDialogOpen() {
        return isElementVisible(addDriverDialogHeader, 1);
    }

    public List<Locator> getListOfCheckedVehicles() {
        return listOfCheckedVehicles.all();
    }

    public List<Locator> getDriverEditCheckboxesInputButtonByFullName(String fullName) throws Exception {
        String[] arrays = fullName.split(SPACE);
        StringBuilder capitalizedFullName = new StringBuilder();
        for (String string : arrays) {
            if(string.isEmpty()) {
                continue;
            }
            String adjusted = string.substring(0,1).toUpperCase() + string.substring(1).toLowerCase();
            capitalizedFullName.append(adjusted).append(SPACE);
        }
        String cappedFullName = capitalizedFullName.toString().strip();
        return locators(pwXPath(String.format("//mat-checkbox[contains(.,'%s')]//input | //app-driver-card[contains(.,'%s')]//mat-checkbox", cappedFullName, cappedFullName)));
    }

    public Locator getDriverEditCheckboxInputButtonByFullName(String fullName) throws Exception {
        String[] arrays = fullName.split(SPACE);
        StringBuilder capitalizedFullName = new StringBuilder();
        for (String string : arrays) {
            if(string.isEmpty()) {
                continue;
            }
            String adjusted = string.substring(0,1).toUpperCase() + string.substring(1).toLowerCase();
            capitalizedFullName.append(adjusted).append(SPACE);
        }
        String cappedFullName = capitalizedFullName.toString().strip();
        return locator(pwXPath(String.format("//mat-checkbox[contains(.,'%s')]//input | //app-driver-card[contains(.,'%s')]//mat-checkbox//input", cappedFullName, cappedFullName)));
    }


    public void updateVehiclesAndDrivers(AutoApplicant applicant) throws Exception {
    	if (!getRandomVinNumber(1).isEmpty()) {
    		// add a new vehicle
    		addRandomNewVehicle(getRandomVinNumber(3));
    		// edit an existing vehicle
    		updateVinsForVehicles(getRandomVinNumber(3));
    	}

        // update an existing driver
        SqlAdditionalDriver sqlAdditionalDriver = applicant.getAdditionalDrivers().get(applicant.getAdditionalDrivers().size() - 1);
        Locator driverEditCheckboxInputButtonByFullName = getEditDriverButtonForDriver(sqlAdditionalDriver.getFirstName() + SPACE + sqlAdditionalDriver.getLastName());
        waitAndClickElement(driverEditCheckboxInputButtonByFullName);
        selectGenderTabButton("Male");
        waitAndClickElement(saveButton);
        waitForSkeletonToBeGone();

        // add a new random driver
        clickAddAnotherDriverButton();
        enterAdditionalDriverData(applicant, getRandomAdditionalDriver());
        clickOnSaveButton();
        clickOnDoneAddingDriversButton();

    }

    public boolean isAddVehicleAndDriversButtonPresent() {
        return isElementVisible(addVehicleAndDriversButton, 2);
    }

    public boolean isAddVehiclesDriversButtonPresent() {
        try {
            wait.until(Conditions.visible(addVehicleAndDriversButton));
        } catch (TimeoutError te) {
            return false;
        }
        return isElementVisibleAndClickable(addVehicleAndDriversButton, 2);
    }

    public String getVehicleCardXpathWithVehicleDescription(String vehicleDesc) {
        return String.format("//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-details row') and contains(.,'%s')]", vehicleDesc);
    }

    public boolean isVehicleErrorMessageDisplayed(String vehicleDesc) throws Exception {
        return isElementPresent(pwXPath(getVehicleCardXpathWithVehicleDescription(vehicleDesc) + VEHICLE_VIN_ERROR_MESSAGE_XPATH), 1);
    }

    public void validateVinErrorMessage(String vehicleDesc, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(locator(pwXPath(getVehicleCardXpathWithVehicleDescription(vehicleDesc) + VEHICLE_VIN_ERROR_MESSAGE_XPATH))), "We are unable to locate details for this vehicle. Please provide the VIN and try again.", "Expected VIN error message is displayed for vehicle: " + vehicleDesc);
    }

    public void uncheckVehicleCheckbox(Vehicle vehicle) throws Exception {
        String vehicleDescriptionFromVehicle = getVehicleDescriptionFromVehicle(vehicle);
        Log.info("User is unchecking the Vehicle checkbox: " + vehicleDescriptionFromVehicle);
        String vehicleCard = getVehicleCardXpathWithVehicleDescription(vehicleDescriptionFromVehicle);
        Locator checkboxForVehicle = locator(pwXPath(vehicleCard + "//input"));
        scrollToElement(checkboxForVehicle);
        clickElement(checkboxForVehicle);
    }

    public String getVehicleDescriptionFromVehicle(Vehicle vehicle) throws Exception {
        return vehicle.getVehicleYear() + SPACE + vehicle.getVehicleMake() + SPACE + vehicle.getVehicleModel();
    }

    public void validateVinErrorAndAddValidVin(FarmersSoftAssert fsa, Vehicle vehicle) throws Exception {
        String vehicleDesc = getVehicleDescriptionFromVehicle(vehicle);
        fsa.assertTrue(isOnWhoShouldWeInsurePage(), "User is on who should we insure page with Bw rate failure with VIN");
        validateVinErrorMessage(vehicleDesc, fsa);
        fsa.assertTrue(isVehicleErrorMessageDisplayed(vehicleDesc), "We are unable to locate details for this vehicle. Please provide the VIN and try again. error message is displayed for first vehicle");

        // validate error message for CTA button
        clickContinueButton();
        // validate CTA error message
        fsa.assertEquals(getTextFromElement(pageCTAErrorMessage), "One or more fields required.", "Expected CTA error message is displayed on who should we insure page with Bw rate failure with VIN");

        String vehicleCard = getVehicleCardXpathWithVehicleDescription(vehicleDesc);

        // locate and click edit button for the vehicle
        Locator vehicleEditButton = locator(pwXPath(vehicleCard + "//a[contains(.,'Edit')]"));
        scrollToElement(vehicleEditButton);
        waitAndClickElement(vehicleEditButton);

        // update vehicle data
        String randomVin = getRandomVinNumber(3);
        vehicle.setUseVIN(true);
        vehicle.setVehicleVIN(randomVin);

        // click Vin toggle
        clickOnVinButton();
        // fill out vin field
        fillOutVinField(randomVin);
        waitForSpinnerToBeGone();
        //click add vehicle button
        clickOnAddAVehicleButton();
        waitForUiSettled();
        while (isElementDisplayed(pwXPath("//mat-error[contains(.,'This VIN is already added for a vehicle.')]"))) {
            String newRandomVin = getRandomVinNumber(3);
            vehicle.setVehicleVIN(newRandomVin);
            fillOutVinField(newRandomVin);
            waitForSpinnerToBeGone();
            waitAndClickElement(addVehicleButton);
            waitForSpinnerToBeGone();
        }
        waitForUiSettled();
        if(isElementVisible(doneAddingVehiclesButton, 1)) {
            waitAndClickElement(doneAddingVehiclesButton);
        }
    }

    public void addAnotherVehicleUsingVin(String vin) throws Exception {
        clickOnAddVehiclesAndDriversButton();
        if (isVehicleAdditionSideSheetVisible()) {
            fillOutVinField(vin);
            clickOnAddVehicleButton();
        }
    }

    public void addAnotherDriverUsingRetrievedDriverDetails(Map<String, String> driverDetails) throws Exception {
        fillOutDriverDetailsUsingRetrievedDetails(driverDetails);
        Locator element = locator(pwCss("button[class='tui-btn tui-btn-primary auto-add-driver-save__button']"));
        scrollAndClickOnElement(element);
    }

    public int getDriversCount() {
        return getEleCount(lblDriversList.all(), 3);
    }

    public void fillOutDriverDetailsUsingRetrievedDetails(Map<String, String> driverDetails) throws Exception {
        clickAddAnotherDriverButton();
        testStepAssertTrue(isDriverSideDialogOpen(), "Add driver side dialog is open");
        enterFirstName(driverDetails.get("firstName"));
        enterLastName(driverDetails.get("lastName"));
        enterDateOfBirth(driverDetails.get("dob"));
        selectGenderTabButton(driverDetails.get("gender"));
        selectUsOrCanadaLicensedRadioButton(driverDetails.get("isLicenseIssuedInUS"));
    }

    public void addVehicleDetailsWith2027YMM(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        VehiclesDriversInfoPage vehiclesDriversInfoPage=new VehiclesDriversInfoPage();
        boolean isStreamlinedState = vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());
        if (!isStreamlinedState) {
            clickOnYMMButton();
        }
        vehiclesDriversInfoPage.check2027YearDetailsUsingYMM(applicant, fsa);
        vehiclesDriversInfoPage.clickOnAddAVehicleButton();
    }
}
