package com.farmers.ffq.auto.pages.bindpages;







import com.farmers.framework.playwright.Keys;
import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Auto;
import com.farmers.ffq.datatransferobjects.AppStore.Auto.AppStoreVehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import org.apache.commons.lang3.RandomUtils;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AdditionalInfoVehicleSectionOneUI extends AutoBasePage {

    public static String VEHICLE_SECTION_XPATH = "//div[contains(.,'%s') and contains(.,'%s') and contains(.,'%s')]";
    public final static String VEHICLE_VIN_INPUT_XPATH = "//input[@formcontrolname='vin']";
    public final static String LEASE_COMPANY_INPUT_XPATH = "//span[contains(.,'Enter leasing company')]/..//input";
    public final static String FINANCE_COMPANY_INPUT_XPATH = "//span[contains(.,'Enter loan company')]/..//input";

        private Locator whenDidYouGetThisVehicleQuestion = locator(pwXPath("//p[contains(text(), 'When did you get this vehicle?')]"));

        private Locator lessThanTwoYearsButton = locator(pwXPath("//mat-button-toggle[@value='lessThanTwo']"));

        private Locator twoToFiveYearsAgoButton = locator(pwXPath("//mat-button-toggle[@value='twoToFive']"));

        private Locator aboveFiveYearsButton = locator(pwXPath("//mat-button-toggle[@value='aboveFive']"));

        Locator loanCompanyParentTextBoxElementList = locator(pwXPath("//mat-label[contains(text(),'Enter loan company')]"));


    private static final String ENTER_LOAN_COMPANY_ERROR = "Please enter loan company.";
        Locator enterLoanCompanyErrorElementList = locator(pwXPath("//mat-error[contains(text(), 'Please enter loan company.')]"));

    private static final String ENTER_VALID_LOAN_COMPANY_ERROR = "Please select a valid loan company.";
        Locator enterValidLoanCompanyErrorElementList = locator(pwXPath("//mat-error[contains(text(), 'Please select a valid loan company.')]"));

        Locator leasingCompanyParentTextBoxElementList = locator(pwXPath("//mat-label[contains(text(),'Enter leasing company')]/ancestor::mat-form-field"));


    private static final String ENTER_LEASING_COMPANY_ERROR = "Please enter leasing company.";
        Locator enterLeasingCompanyErrorElementList = locator(pwXPath("//mat-error[contains(text(), 'Please enter leasing company.')]"));

    private static final String ENTER_VALID_LEASING_COMPANY_ERROR = "Please select a valid leasing company.";
        Locator enterValidLeasingCompanyErrorElementList = locator(pwXPath("//mat-error[contains(text(), 'Please select a valid leasing company.')]"));

        public Locator vinNumberTextBoxElementList = locator(pwXPath("//input[@aria-label='Vehicle Identification Number']"));

    private static final String ENTER_VIN_NUMBER_ERROR = "Please enter the VIN.";
        Locator enterVinNumberErrorElement = locator(pwXPath("//mat-error[contains(text(), 'Please enter the VIN.')]"));


    private static final String PLEASE_ENTER_VALID_VIN = "Please enter a valid VIN.";
        Locator enterValidVinErrorElement = locator(pwXPath("//mat-error[contains(text(), 'Please enter a valid VIN.')]"));

        Locator vinIsNotFormattedCorrectly = locator(pwXPath("//mat-error[contains(text(), 'formatted correctly.')]"));

    private static final String WHY_DO_YOU_NEED_FINANCE_COMPANY_INFO = "Why do you need my finance company info?";
        Locator whyDoYouNeedMyFinanceCompanyInfo = locator(pwXPath("//p[contains(text(), 'Why do you need my finance company info?')]"));

        Locator whyDoYouNeedMyFinanceCompanyInfoMB = locator(pwXPath("//h1[contains(text(), 'Why do you need my finance company info?')]"));

    private static final String WHY_DO_YOU_NEED_FINANCE_COMPANY_INFO_EXPLANATION = "Leasing and lending companies require us to list them on your policy, so they know you have the insurance they require.";
        Locator whyDoYouNeedMyFinanceCompanyInfoExplanation = locator(pwXPath("//p[contains(text(), 'Leasing and lending companies require us to list')]"));

    private static final String WHERE_CAN_I_FIND_THE_VIN = "Where can I find the VIN?";
        Locator whereCanIFindTheVin = locator(pwXPath("//p[contains(text(),'" + WHERE_CAN_I_FIND_THE_VIN + "')]"));

    private static final String USE_THIS_GUIDE = "Use this guide";
        Locator useThisGuide = locator(pwXPath("//a[contains(text(),'" + USE_THIS_GUIDE + "')]"));

    private static final String USE_THIS_GUIDE_TEXT = "Use this guide to find your VIN (Vehicle Identification Number).";
        Locator useThisGuideText = locator(pwXPath("//a[contains(text(),'" + USE_THIS_GUIDE + "')]/parent::p"));
    private static final String HOW_TO_FIND_THE_VIN = "How to find the VIN";
        Locator howToFindVINLabel = locator(pwXPath("//p[contains(text(), '" + HOW_TO_FIND_THE_VIN + "')]"));

    private static final String USE_DRIVER_SIDE_DOOR = "Driver side door";
        Locator driverSideDoorLabel = locator(pwXPath("//p[contains(text(), '" + USE_DRIVER_SIDE_DOOR + "')]"));

    private static final String DASHBOARD_ON_DRIVER_SIDE_LABEL = "Dashboard on the driver side";
        Locator dashboardOnDriverSideDoor = locator(pwXPath("//p[contains(text(), '" + DASHBOARD_ON_DRIVER_SIDE_LABEL + "')]"));

    private static final String VIN_HELPER_IMG_1 = "Vin Helper Image 1";
        Locator vinHelperImg1 = locator(pwXPath("//div[@title = '" + VIN_HELPER_IMG_1 + "']"));

    private static final String VIN_HELPER_IMG_2 = "Vin Helper Image 2";
        Locator vinHelperImg2 = locator(pwXPath("//div[@title = '" + VIN_HELPER_IMG_2 + "']"));

    private static final String VIN_HELPER_IMG_3 = "Vin Helper Image 3";
        Locator vinHelperImg3 = locator(pwXPath("//div[@title = '" + VIN_HELPER_IMG_3 + "']"));

    private static final String BACK_TO_VIN = "Back to VIN";
        Locator backToVINButton = locator(pwXPath("//button[contains(text(), '" + BACK_TO_VIN + "')]"));

    private static final String BACK_ARROW = "chevron_left";
        Locator backArrowIconVINPopUp = locator(pwXPath("//mat-icon[contains(text(), '" + BACK_ARROW + "')]"));

    private static final String CLOSE = "Close";
        Locator closeButton = locator(pwXPath("//button[contains(text(),'" + CLOSE + "')]"));

        Locator matIconCloseButton = locator(pwXPath("//mat-icon[contains(text(),'close')]"));

        private Locator continueToPaymentButton = locator(pwXPath("//button[contains(text(), 'Continue')]"));

    private static final String CONFIRM_YOUR_VIN = "Confirm your VIN";
        Locator confirmYourVINLabel = locator(pwXPath("//span[contains(text(),'" + CONFIRM_YOUR_VIN + "')]"));

    private static final String INITIALLY_QUOTED_VEHICLE_LABEL = "The vehicle initially quoted was specified as a:";
        Locator initiallyQuotedVehicleLabel = locator(pwXPath("//span[contains(text(),'" + INITIALLY_QUOTED_VEHICLE_LABEL + "')]"));

    private static final String NEWLY_ENTERED_VEHICLE_LABEL = "However, the VIN entered";
        Locator newlyEnteredVehicleLabel = locator(pwXPath("//p[contains(text(),'" + NEWLY_ENTERED_VEHICLE_LABEL + "')]"));

    private static final String PLEASE_SELECT_LABEL = "Please select:";
        Locator pleaseSelectLabel = locator(pwXPath("//span[contains(text(),'" + PLEASE_SELECT_LABEL + "')]"));

        Locator editVINIfItIsWrong = locator(pwXPath("//li[contains(text(),'wrong, or')]"));

        Locator vINIsCorrect = locator(pwXPath("//li[contains(text(),'update your quote')]"));

    private static final String EDIT_VIN_LINK = "Edit VIN";
        Locator editVINLink = locator(pwXPath("//a[contains(text(),'" + EDIT_VIN_LINK + "')]"));

    private static final String VIN_IS_CORRECT_LINK = "VIN is correct";
        public Locator vinIsCorrectLink = locator(pwXPath("//a[contains(text(),'" + VIN_IS_CORRECT_LINK + "')]"));

        public Locator vinErrorMessage = locator(pwXPath("//div[contains(@class,'additional-info-vehicle-info-section') and contains(.,'VIN')]//mat-error"));

    private static final String ENTER_CORRECT_VIN = "Please enter the correct VIN for this vehicle.";
        Locator enterCorrectVINError = locator(pwXPath("//mat-error[contains(text(),'" + ENTER_CORRECT_VIN + "')]"));

    private static final String NINTH_DIGIT_NUM_OR_X = "The 9th digit must be a number or X only.";
        Locator ninthDigitNumberOrTextError = locator(pwXPath("//mat-error[contains(text(),'" + NINTH_DIGIT_NUM_OR_X + "')]"));

        Locator vehicleLeaseOrFinanceMobileInfoIcons = locator(pwXPath("//div[contains(@class,'additional-info-vehicle-info-section')]//div[@class='col' and contains(.,'company')]//mat-icon"));

        Locator vehicleVinMobileInfoIcons = locator(pwXPath("//div[contains(@class,'additional-info-vehicle-info-section')]//div[@class='col' and contains(.,'VIN')]//mat-icon"));

        Locator leanOrLeaseInputFields = locator(pwXPath("//mat-form-field[contains(.,'company')]//input"));

        Locator vinInputFields = locator(pwCss("input[formcontrolname='vin']"));

        Locator registeredOwnerDropDowns = locator(pwCss("mat-select[formcontrolname='registeredOwner']"));

        Locator currentOdometerFields = locator(pwXPath("//mat-form-field[contains(.,'Current odometer')]//input"));

        Locator odometerReadingDateInputFields = locator(pwXPath("//mat-form-field[contains(.,'Odometer reading date')]//input[not(contains(@class,'picker'))]"));

        Locator currentOdometerErrorMessage = locator(pwXPath("//div[contains(@class,'odometer') and contains(.,'Current odometer')]//mat-error"));

        Locator odometerDateErrorMessage = locator(pwXPath("//div[contains(@class,'odometer') and contains(.,'Odometer reading')]//mat-error"));

        Locator odometerMobileInfoIcon = locator(pwXPath("//div[contains(@class,'odometer')]//mat-icon"));

        Locator odometerInfoHeaderLabel = locator(pwXPath("//p[contains(.,'What is an odometer?')]"));

        Locator odometerInfoHeaderDescription = locator(pwXPath("//p[contains(.,'An odometer is a device')]"));

        Locator mobileInfoModalHeader = locator(pwCss("h1[class='model-caption-head']"));

        Locator mobileInfoModalDesc = locator(pwCss("p[class='model-caption-text']"));

    List<String> vinNumberList = Arrays.asList("JH4DC4450SS003654", "1C3EL55R16N152273", "JH4DB1650NS000627", "1GTFG15X891117544", "4T1BG22KXXU495725");

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public AdditionalInfoVehicleSectionOneUI() throws Exception {
    }

    public void verifyVehicleSection(AppStore retrieveQuoteResponseSessionStorage, boolean enterValuesOnly, FarmersSoftAssert fsa) throws Exception {
        removeQualtricsPopUp();
        List<Auto.AppStoreVehicle> originalVehicleList = retrieveQuoteResponseSessionStorage.getAuto().getVehicles();
        List<Auto.AppStoreVehicle> vehicleListWithShowVehicleTrue = retrieveQuoteResponseSessionStorage.getAuto().getVehicles().stream().filter(s -> s.isShowVehicle()).collect(Collectors.toList());

        if (!vehicleListWithShowVehicleTrue.isEmpty()) {
            closeQualtricsPopUp();
            waitElementBeVisible(continueToPaymentButton, 10);
            List<Auto.AppStoreVehicle> listOfLoanVehicles = getListOfLoanVehicles(originalVehicleList);
            if (!listOfLoanVehicles.isEmpty()) {
                if (enterValuesOnly) {
                    enterLoanCompanyInformation(listOfLoanVehicles);
                } else {
                    verifyLoanCompanySection(listOfLoanVehicles, fsa);
                }
            }

            List<Auto.AppStoreVehicle> listOfLeasedVehicles = getListOfLeasedVehicles(originalVehicleList);
            if (!listOfLeasedVehicles.isEmpty()) {
                if (enterValuesOnly) {
                    enterLeasingCompanyInformation(listOfLeasedVehicles);
                } else {
                    verifyLeasingCompanySection(listOfLeasedVehicles, fsa);
                }
            }

            List<Auto.AppStoreVehicle> vehicleListWithoutVinNumber = getListOfVehicleWithoutVINNumber(originalVehicleList);
            if (!vehicleListWithoutVinNumber.isEmpty()) {
                if (enterValuesOnly) {
                    enterVINNumber(vehicleListWithoutVinNumber, fsa);
                } else {
                    verifyWhereCanIFindThisVinAndUseGuide(fsa);
                    verifyVinNumberSection(vehicleListWithoutVinNumber, fsa);
                }
             }
        }

        validateOdometerSection(fsa);
    }

    private void validateOdometerSection(FarmersSoftAssert fsa) {
    	int numberOfElements = currentOdometerFields.count();
        for (int i =0; i< numberOfElements; i++){
            Locator currentOdometerInputField = currentOdometerFields.nth(0);
            Locator currentOdometerReadingDateField = odometerReadingDateInputFields.nth(0);

            validateHelpInfoSectionForOdometer(fsa);

            //Validate error messages for Odometer reading input
            String emptyReadingErrorMessage = "Current odometer reading is required.";
            String invalidReadingErrorMessage = "Odometer should be between 1 and 999,999.";

            sendKeysToElement(currentOdometerInputField, "0");
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(currentOdometerErrorMessage)), invalidReadingErrorMessage, "Invalid odomoeter value check");

            // empty odometer reading field
            clearOutFieldUsingBackSpace(currentOdometerInputField);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(currentOdometerErrorMessage)), emptyReadingErrorMessage, "No odometer value check");

            String acceptableLowerEdge = currentDate.minusDays(365).format(dateTimeFormatter);
            String formattedToday = currentDate.format(dateTimeFormatter);

            // validate date field
            String invalidDateEntryErrorMessage = String.format("Date must be between %s and %s.", acceptableLowerEdge, formattedToday);
            String emptyFieldErrorMessage = "Odometer reading date is required.";
            clearOutFieldUsingBackSpace(currentOdometerReadingDateField);

            // one day before earlier acceptable date
            sendKeysToElement(currentOdometerReadingDateField, "12/31" + currentDate.minusYears(2).getYear());
            sendKeysToElement(currentOdometerReadingDateField, Keys.TAB);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(odometerDateErrorMessage)), invalidDateEntryErrorMessage, "One day before earliest acceptable date check");


            // tomorrow invalid
            sendKeysToElement(currentOdometerReadingDateField, currentDate.plusDays(1).format(dateTimeFormatter));
            sendKeysToElement(currentOdometerReadingDateField, Keys.TAB);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(odometerDateErrorMessage)), invalidDateEntryErrorMessage, "Using tomorrow check");

            //no entry error message
            clearOutFieldUsingBackSpace(currentOdometerReadingDateField);
            sendKeysToElement(currentOdometerReadingDateField, Keys.TAB);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(odometerDateErrorMessage)), emptyFieldErrorMessage, "Empty date field check");

            sendKeysToElement(currentOdometerInputField, "10000");
            sendKeysToElement(currentOdometerReadingDateField, formattedToday);

        }
    }

    private void validateHelpInfoSectionForOdometer(FarmersSoftAssert fsa) {
        String expectedInfoHeader = "What is an odometer?";
        String expectedInfoDesc = "An odometer is a device located on a vehicle's dashboard that displays a numerical value of the total distance the vehicle has traveled.";

    	int numberOfElements = odometerInfoHeaderLabel.count();
        for (int i =0; i< numberOfElements; i++){
            if (isUseMobileViewEnabled()) {
                waitAndClickElement(odometerMobileInfoIcon.nth(i));
                fsa.assertEquals(getTextFromElement(mobileInfoModalHeader), expectedInfoHeader, "Odometer help title check for vehicle " + (i+1));
                fsa.assertEquals(getTextFromElement(mobileInfoModalDesc), expectedInfoDesc, "Odometer help content check for vehicle " + (i+1));
                waitAndClickElement(closeIconMB);
            } else {
                fsa.assertEquals(getTextFromElement(odometerInfoHeaderLabel.nth(i)), expectedInfoHeader, "Odometer help title check for vehicle " + (i+1));
                fsa.assertEquals(getTextFromElement(odometerInfoHeaderDescription.nth(i)), expectedInfoDesc, "Odometer help content check for vehicle " + (i+1));
            }
        }

    }

    public void fillOutVehicleSection_InvalidDetails() {
    	int numberOfElements = vinInputFields.count();
        for (int i =0; i< numberOfElements; i++){
            Locator vinInputField = vinInputFields.nth(i);
            scrollElementToMiddle(vinInputField);
            sendKeysToElement(vinInputField, "1111736373700");
            sendKeysToElement(vinInputField, Keys.TAB);
            waitForSpinnerToBeGone();
        }
    	numberOfElements = leanOrLeaseInputFields.count();
        for (int i =0; i< numberOfElements; i++){
            Locator leasedOrLoanInputField = leanOrLeaseInputFields.nth(i);
            scrollElementToMiddle(leasedOrLoanInputField);
            sendKeysToElement(leasedOrLoanInputField, "OOO");
            waitForUiSettled();
        }
    }

    public void fillOutVehicleSectionAlternative() throws Exception {
        fillOutVehicleSectionAlternative(Collections.emptyList());
    }

    public void fillOutVehicleSectionAlternative(List<String> preferredVins) throws Exception {
        int numberOfElements = vinInputFields.count();
        for (int i = 0; i < numberOfElements; i++) {
            Locator vinInputField = vinInputFields.nth(i);
            scrollElementToMiddle(vinInputField);
            String preferredVin = EMPTY_STRING;
            if (preferredVins != null && preferredVins.size() > i && preferredVins.get(i) != null) {
                preferredVin = preferredVins.get(i).trim();
            }
            String vinNumber = preferredVin.isEmpty() ? getRandomVinNumber(5) : preferredVin;
            if (!vinNumber.isEmpty()) {
                sendKeysToElement(vinInputField, vinNumber);
                sendKeysToElement(vinInputField, Keys.TAB);
                waitForUiSettled();
                if (preferredVin.isEmpty()) {
                    int retry = 3;
                    while (!(vinErrorMessage.count() == 0) && retry > 0) {
                        vinNumber = getRandomVinNumber(5);
                        sendKeysToElement(vinInputField, vinNumber);
                        sendKeysToElement(vinInputField, Keys.TAB);
                        retry--;
                    }
                }
                Log.info("VIN entered on Additional Info Page: " + vinNumber);
                waitForSpinnerToBeGone();
                if (isElementVisible(vinIsCorrectLink, 10)) {
                    waitAndClickElement(vinIsCorrectLink);
                    waitForSpinnerToBeGone();
                    waitElementBeInvisible(vinIsCorrectLink);
                }
            }
        }

    	numberOfElements = leanOrLeaseInputFields.count();
        for (int i =0; i< numberOfElements; i++){
            Locator leasedOrLoanInputField = leanOrLeaseInputFields.nth(i);
            scrollElementToMiddle(leasedOrLoanInputField);
            sendKeysOneByOne(leasedOrLoanInputField, "SAAB");
            List<Locator> loanOptions = locators(pwXPath("//mat-option[contains(.,'SAAB')]"));
            int tryCount = 0;
            if(loanOptions.isEmpty()) {
                leasedOrLoanInputField.fill("");
                sendKeysOneByOne(leasedOrLoanInputField, "GM");
                loanOptions = locators(pwXPath("//mat-option[contains(.,'GM')]"));
                while (loanOptions.isEmpty() && tryCount < 4 ) {
                    List<String> bcdef = Arrays.asList("B", "C", "D", "E", "F");
                    loanOptions = locators(pwXPath(String.format("//mat-option[contains(.,'%s')]", bcdef.get(tryCount))));
                    tryCount++;
                }
            }
            waitAndClickElement(loanOptions.get(new Random().nextInt(loanOptions.size())));
            waitForSpinnerToBeGone();
            waitForUiSettled();
        }

        // fill out registered owner section
    	numberOfElements = registeredOwnerDropDowns.count();
        for (int i =0; i< numberOfElements; i++){
            Locator registeredOwnerDropDown = registeredOwnerDropDowns.nth(i);
            String lastName = getSessionStorageAppStore().getData().getCustomerData().getLastName();
            selectValueInDropDown(registeredOwnerDropDown, lastName);
        }

        // fill out the when did you purchase section
        if (!(whenDidYouGetThisVehicleQuestion.count() == 0)) {
            List<Locator> toggleOptions = locators(pwXPath("//span[@class='additional-info-vehicle-purchase-date-options']/ancestor::mat-button-toggle"));
            if (!toggleOptions.isEmpty()) {
                Locator randomToggleOption = toggleOptions.get(new Random().nextInt(toggleOptions.size()));
                scrollElementToMiddle(randomToggleOption);
                clickElement(randomToggleOption);
            }
        }

        if (getSessionStorageAppStore().getData().getLandingStateCode().equals(CA)) {
        	numberOfElements = currentOdometerFields.count();
            for (int x =0; x< numberOfElements; x++){
                int randomOdometer = RandomUtils.nextInt(10_00, 200_001);
                sendKeysToElement(currentOdometerFields.nth(x), randomOdometer);
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
                String formattedDate = currentDate.minusDays(1).format(formatter);
                sendKeysToElement(odometerReadingDateInputFields.nth(x), formattedDate);
            }
        }

    }

    List<Auto.AppStoreVehicle> getListOfVehicleWithoutPurchaseDate(List<Auto.AppStoreVehicle> vehicleList) {
        List<AppStoreVehicle> listOfVehicleWithoutPurchaseDate = vehicleList.stream().filter(item -> item.getPurchaseDate() == "").collect(Collectors.toList());
        return listOfVehicleWithoutPurchaseDate;
    }

    List<AppStoreVehicle> getListOfVehicleGreaterThanThree(List<Auto.AppStoreVehicle> vehicleList) {
        int currentYear = LocalDate.now().getYear();
        List<Auto.AppStoreVehicle> listOfVehicleGreaterThanThree = vehicleList.stream().filter(item -> currentYear - Integer.parseInt(item.getYear()) > 3).collect(Collectors.toList());
        return listOfVehicleGreaterThanThree;
    }

    List<Auto.AppStoreVehicle> getListOfLeasedVehicles(List<Auto.AppStoreVehicle> originalVehicleList) {
        List<Auto.AppStoreVehicle> listOfLeasedVehicles = originalVehicleList.stream().filter(item -> item.getLnLrCompany() == null && item.getVehicleIsOn().equals("LR")).collect(Collectors.toList());
        return listOfLeasedVehicles;
    }

    List<Auto.AppStoreVehicle> getListOfLoanVehicles(List<Auto.AppStoreVehicle> originalVehicleList) {
        List<AppStoreVehicle> listOfLoanVehicles = originalVehicleList.stream().filter(item -> item.getLnLrCompany() == null && item.getVehicleIsOn().equals("LN")).collect(Collectors.toList());
        return listOfLoanVehicles;
    }

    List<Auto.AppStoreVehicle> getListOfVehicleWithoutVINNumber(List<Auto.AppStoreVehicle> originalVehicleList) {
        List<Auto.AppStoreVehicle> listOfVehicleWithoutVIN = originalVehicleList.stream().filter(item -> item.getVin().equals(EMPTY_STRING)).collect(Collectors.toList());
        return listOfVehicleWithoutVIN;
    }

    private void verifyLoanCompanySection(List<AppStoreVehicle> listOfLoanVehicles, FarmersSoftAssert fsa) throws Exception {
        for (int i = 0; i < listOfLoanVehicles.size(); i++) {
            verifyWhyDoYouNeedMyFinanceCompanyInfo(fsa);
            Locator loanInputBox = loanInputBoxLocator(i);
            scrollOffsetClickOnElement(loanInputBox);

            // just tab out of loan company input box and validate error
            sendKeys(loanInputBox, Keys.chord(Keys.TAB));
            waitElementBeVisible(enterLoanCompanyErrorElementList.nth(i));
            fsa.assertEquals(getTextFromElement(enterLoanCompanyErrorElementList.nth(i)), ENTER_LOAN_COMPANY_ERROR, "Loan Company Error check");

            // enter the random value in loan company input box and validate error
            waitAndClickElement(loanInputBox);
            sendKeysOneByOne(loanInputBox, "ABC");
            sendKeys(loanInputBox, Keys.chord(Keys.TAB));
            waitElementBeVisible(enterValidLoanCompanyErrorElementList.nth(i));
            fsa.assertEquals(getTextFromElement(enterValidLoanCompanyErrorElementList.nth(i)), ENTER_VALID_LOAN_COMPANY_ERROR, "Valid Loan Company Error check");

            // select the option from loan company name dropdown values
            scrollAndClickOnHiddenElement(loanInputBox);
            loanInputBox.fill("");
            sendKeysOneByOne(loanInputBox, "S");
            List<Locator> loanOptionsFromDropDown = loanOrLeasedDropDownOptions();
            loanOptionsFromDropDown.get(0).click();
            removeQualtricsPopUp();
        }
    }


    private void verifyLeasingCompanySection(List<Auto.AppStoreVehicle> listOfLoanVehicles, FarmersSoftAssert fsa) throws Exception {
        for (int i = 0; i < listOfLoanVehicles.size(); i++) {
            verifyWhyDoYouNeedMyFinanceCompanyInfo(fsa);
            Locator leasedInputBox = leasingInputBoxLocator(i);
            scrollOffsetClickOnElement(leasedInputBox);

            // just tab out of leasing company input box and validate error
            sendKeys(leasedInputBox, Keys.chord(Keys.TAB));
            waitElementBeVisible(enterLeasingCompanyErrorElementList.nth(i));
            fsa.assertEquals(getTextFromElement(enterLeasingCompanyErrorElementList.nth(i)), ENTER_LEASING_COMPANY_ERROR, "Enter Leasing Company Error check");

            // enter the random value in leasing company input box and validate error
            leasedInputBox.click();
            sendKeysOneByOne(leasedInputBox, "ABC");
            sendKeys(leasedInputBox, Keys.chord(Keys.TAB));
            waitElementBeVisible(enterValidLeasingCompanyErrorElementList.nth(i));
            fsa.assertEquals(getTextFromElement(enterValidLeasingCompanyErrorElementList.nth(i)), ENTER_VALID_LEASING_COMPANY_ERROR, "Valid Leased Company Error check");

            // select the option from leasing company name dropdown values
            leasedInputBox.click();
            leasedInputBox.fill("");
            sendKeysOneByOne(leasedInputBox, "S");
            List<Locator> loanOptionsFromDropDown = loanOrLeasedDropDownOptions();
            loanOptionsFromDropDown.get(0).click();
        }
    }

    private void verifyVinNumberSection(List<Auto.AppStoreVehicle> vehicleListWithoutVinNumber, FarmersSoftAssert fsa) throws Exception {
        for (int i = 0; i < vehicleListWithoutVinNumber.size(); i++) {

            //  tab out from VIN number section and validate error
            scrollOffsetClickOnElement(vinNumberTextBoxElementList.nth(i));
            waitAndClickElement(vinNumberTextBoxElementList.nth(i));
//            vinNumberTextBoxElementList.nth(i).click();
            sendKeys(vinNumberTextBoxElementList.nth(i), Keys.chord(Keys.TAB));

            fsa.assertEquals(getTextFromElement(enterVinNumberErrorElement), ENTER_VIN_NUMBER_ERROR, "Enter VIN Number Error check");

            // enter random value and validate error
            waitAndClickElement(vinNumberTextBoxElementList.nth(i));
            //vinNumberTextBoxElementList.nth(i).click();
            sendKeysOneByOne(vinNumberTextBoxElementList.nth(i), "AB");
            sendKeys(vinNumberTextBoxElementList.nth(i), Keys.chord(Keys.TAB));

            fsa.assertEquals(getTextFromElement(enterValidVinErrorElement), PLEASE_ENTER_VALID_VIN, "Enter VIN Number Error check");

//            vinNumberTextBoxElementList.nth(i).click();
            waitAndClickElement(vinNumberTextBoxElementList.nth(i));
            sendKeys(vinNumberTextBoxElementList.nth(i), Keys.chord(Keys.BACK_SPACE, Keys.BACK_SPACE));


            // enter invalid format VIN and validate the error
            sendKeysOneByOne(vinNumberTextBoxElementList.nth(i), "Ah689765ty45re4rt");
            sendKeys(vinNumberTextBoxElementList.nth(i), Keys.chord(Keys.TAB));

            fsa.assertTrue(vinIsNotFormattedCorrectly.isVisible(), "VIN is not formatted correctly message displayed");

//            fsa.assertEquals(getTextFromElement(vinIsNotFormattedCorrectly), VIN_IS_NOT_FORMATTED_CORRECTLY, "VIN is not formatted correctly message check");

            // enter the valid VIN number
            clearVinNumberInputBox(vinNumberTextBoxElementList.nth(i));

            // get the random VIN and enter in VIN number field
            String randomVinNumber = "WDBTK56F07T078334";
            sendKeysOneByOne(vinNumberTextBoxElementList.nth(i), randomVinNumber != null ? randomVinNumber : "2HNYD18222H543555");
            sendKeys(vinNumberTextBoxElementList.nth(i), Keys.chord(Keys.TAB));

            validateEditVINNumberPopUp(vehicleListWithoutVinNumber.get(i), EDIT_VIN_LINK, fsa);
            fsa.assertEquals(getTextFromElement(enterCorrectVINError), ENTER_CORRECT_VIN, "Enter Correct VIN Error Text check");

            clearVinNumberInputBox(vinNumberTextBoxElementList.nth(i));
            // randomVinNumber = getRandomVinNumber();
            sendKeysOneByOne(vinNumberTextBoxElementList.nth(i), vinNumberList.get(i));
            sendKeys(vinNumberTextBoxElementList.nth(i), Keys.chord(Keys.TAB));

            validateEditVINNumberPopUp(vehicleListWithoutVinNumber.get(i), VIN_IS_CORRECT_LINK, fsa);
            removeQualtricsPopUp();
        }
    }

    private void verifyWhyDoYouNeedMyFinanceCompanyInfo(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(whyDoYouNeedMyFinanceCompanyInfo.nth(0)), WHY_DO_YOU_NEED_FINANCE_COMPANY_INFO, "Why Do You Need My Finance Company Info Question check");
        fsa.assertEquals(getTextFromElement(whyDoYouNeedMyFinanceCompanyInfoExplanation.nth(0)), WHY_DO_YOU_NEED_FINANCE_COMPANY_INFO_EXPLANATION, "Why Do You Need My Finance Company Info Question check");

        // test the mobile break point
        if (isUseMobileViewEnabled()) {
            vehicleLeaseOrFinanceMobileInfoIcons.nth(0).click();
            fsa.assertEquals(getTextFromElement(whyDoYouNeedMyFinanceCompanyInfoMB), WHY_DO_YOU_NEED_FINANCE_COMPANY_INFO, "Why Do You Need My Finance Company Info Question check");
            fsa.assertEquals(getTextFromElement(whyDoYouNeedMyFinanceCompanyInfoExplanation.nth(1)), WHY_DO_YOU_NEED_FINANCE_COMPANY_INFO_EXPLANATION, "Why Do You Need My Finance Company Info Question in Mobile break point");
            closeIconMB.click();
        }
    }

    private void verifyWhereCanIFindThisVinAndUseGuide(FarmersSoftAssert fsa) {
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(vehicleVinMobileInfoIcons.nth(0));
        } else {
            fsa.assertTrue(getTextFromElement(whereCanIFindTheVin).equals(WHERE_CAN_I_FIND_THE_VIN), "Where can I find the VIN is not available");
            fsa.assertTrue(useThisGuide.isVisible(), "Use this guide link is not displayed");
            fsa.assertTrue(getTextFromElement(useThisGuideText).equals(USE_THIS_GUIDE_TEXT), "Use this guide text is not matching");
            waitAndClickElement(useThisGuide);
        }
        // validate content of How to find VIN pop up modal box
        fsa.assertTrue(getTextFromElement(howToFindVINLabel).equals(HOW_TO_FIND_THE_VIN), "How to find VIN label text is not matching");
        fsa.assertTrue(backArrowIconVINPopUp.isVisible(), "Back arrow icon is not displayed");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(driverSideDoorLabel)), USE_DRIVER_SIDE_DOOR, "Driver side door label text is not matching");
        fsa.assertTrue(isExpectedTextContainedInElement(waitElementBeVisible(dashboardOnDriverSideDoor), DASHBOARD_ON_DRIVER_SIDE_LABEL), "Dashboard on driver side door label text is not matching");
        fsa.assertTrue(vinHelperImg1.isVisible(), "Vin helper image 1 is not displayed");
        fsa.assertTrue(vinHelperImg2.isVisible(), "Vin helper image 2 is not displayed");
        fsa.assertTrue(vinHelperImg3.isVisible(), "Vin helper image 3 is not displayed");
        fsa.assertTrue(getTextFromElement(backToVINButton).contains(BACK_TO_VIN), "Back to VIN button text is not matching");
        waitAndClickElement(backToVINButton);
    }

    private void validateEditVINNumberPopUp(Auto.AppStoreVehicle vehicle, String buttonText, FarmersSoftAssert fsa) throws Exception {
        waitElementBeVisible(confirmYourVINLabel);
        fsa.assertTrue(getTextFromElement(confirmYourVINLabel).contains(CONFIRM_YOUR_VIN), "Confirm Your VIN Label Is Not Correct");

        fsa.assertTrue(getTextFromElement(initiallyQuotedVehicleLabel).contains(INITIALLY_QUOTED_VEHICLE_LABEL), "Initially Quoted Vehicle Label Text Is Not Matching");
        String existingVehicleDescription = vehicle.getVehicleSelected();
        String existingVehicleXpath = "//li[contains(text(),'" + existingVehicleDescription + "')]";
        Locator existingVehicleLocator = locator(pwXPath(existingVehicleXpath));
        fsa.assertTrue(existingVehicleLocator.isVisible(), "Existing Vehicle Description Is Not Matching");
        fsa.assertTrue(getTextFromElement(newlyEnteredVehicleLabel).contains(NEWLY_ENTERED_VEHICLE_LABEL), "Newly Entered Vehicle Label Text Is Not Matching");

        AppStore retrieveQuoteResponseSessionStorage = getSessionStorageAppStore();
        Auto.VinLookUpResp vinLookUpResp = retrieveQuoteResponseSessionStorage.getAuto().getVinLookUpResp();
        String newlyAddedVehicleVIN = vinLookUpResp.getVin();
        String newVehicleXpath = String.format("//li[contains(text(),'%s') and contains(text(),'%s') and contains(text(),'%s')]", vinLookUpResp.getYear(), vinLookUpResp.getModelDesc(), vinLookUpResp.getMakeDesc());
        Locator newVehicleLocator = locator(pwXPath(newVehicleXpath));
        waitElementBeVisible(newVehicleLocator);
        fsa.assertTrue(newVehicleLocator.isVisible(), "New Vehicle Description Is Not Matching");
        fsa.assertTrue(getTextFromElement(newlyEnteredVehicleLabel).contains(newlyAddedVehicleVIN), "Newly Added VIN Is Missing In The Text");

        fsa.assertTrue(getTextFromElement(pleaseSelectLabel).equals(PLEASE_SELECT_LABEL), "Please Select Label Is Not Matching");
        fsa.assertTrue(editVINIfItIsWrong.isVisible(), "Edit VIN If It Is Wrong Label Text Is Not Displayed");
        fsa.assertTrue(vINIsCorrect.isVisible(), "Vin Is Correct Label Text Is Not Displayed");
        fsa.assertTrue(getTextFromElement(editVINLink).equals(EDIT_VIN_LINK), "Edit VIN Link Text Is Not Matching");
        fsa.assertTrue(getTextFromElement(vinIsCorrectLink).equals(VIN_IS_CORRECT_LINK), "VIN Is Not Correct Link Text Is Not Matching");

        if (buttonText.equals(VIN_IS_CORRECT_LINK)) {
            waitAndClickElement(vinIsCorrectLink);
        } else {
            waitAndClickElement(editVINLink);
        }
    }

    private void clearVinNumberInputBox(Locator vinNumberInputBox) {
        while (!getAttributeData(vinNumberInputBox, VALUE).equals(EMPTY_STRING)) {
            sendKeys(vinNumberInputBox, Keys.chord(Keys.BACK_SPACE));
        }
    }

    private void enterLoanCompanyInformation(List<Auto.AppStoreVehicle> listOfLoanVehicles) throws Exception {
        for (int i = 0; i < listOfLoanVehicles.size(); i++) {
            Locator loanInputBox = loanInputBoxLocator(i);
            scrollOffsetClickOnElement(loanInputBox);
            waitForUiSettled();
            sendKeysOneByOne(loanInputBox, "S");
            List<Locator> loanOptionsFromDropDown = loanOrLeasedDropDownOptions();
            waitForUiSettled();
            waitAndClickElement(loanOptionsFromDropDown.get(0));
            removeQualtricsPopUp();
        }
    }

    private void enterLeasingCompanyInformation(List<Auto.AppStoreVehicle> listOfLeasedVehicles) throws Exception {
        for (int i = 0; i < listOfLeasedVehicles.size(); i++) {
            Locator leasingInputBox = leasingInputBoxLocator(i);
            scrollOffsetClickOnElement(leasingInputBox);
            waitForUiSettled();
            sendKeysOneByOne(leasingInputBox, "S");
            waitForUiSettled();
            List<Locator> leaseOptionsFromDropDown = loanOrLeasedDropDownOptions();
            waitAndClickElement(leaseOptionsFromDropDown.get(0));
            removeQualtricsPopUp();
        }
    }

    public void enterVINNumber(List<Auto.AppStoreVehicle> vehicleListWithoutVinNumber, FarmersSoftAssert fsa) throws Exception {
        for (int i = 0; i < vehicleListWithoutVinNumber.size(); i++) {
            Locator vinInputElement = vinNumberTextBoxElementList.nth(i);
            scrollOffsetClickOnElement(vinInputElement);
            while (getAttributeData(vinInputElement, CLASS).contains("ng-invalid")) {
                waitAndClickElement(vinInputElement);
                sendKeys(vinInputElement, getRandomVinNumber(10));
                sendKeys(vinInputElement, Keys.chord(Keys.TAB));
                waitForUiSettled();
            }
            validateEditVINNumberPopUp(vehicleListWithoutVinNumber.get(i), VIN_IS_CORRECT_LINK, fsa);
            removeQualtricsPopUp();
        }
    }

    public void enterVinNumber(Locator element, String vinNumber) {
        scrollOffsetClickOnElement(element);
        waitAndClickElement(element);
        sendKeys(element, vinNumber);
        sendKeys(element, Keys.chord(Keys.TAB));
        waitAndClickElement(vinIsCorrectLink);
        waitForSpinnerToBeGone();
    }

    private Locator loanInputBoxLocator(int index) {
        return loanCompanyParentTextBoxElementList.nth(index).locator(pwXPath("//input"));
    }

    private Locator leasingInputBoxLocator(int index) {
        return leasingCompanyParentTextBoxElementList.nth(index).locator(pwXPath("./div/div[1]/div[1]/input"));
    }

    private List<Locator> loanOrLeasedDropDownOptions() throws Exception {
    	String xpathToOptions = pwXPath("//span[@class='mat-option-text']");
    	waitForElements("//span[@class='mat-option-text']");
        return locators(xpathToOptions);
    }

    public void enterOthersInLoanCompanyInputElement() throws Exception {
        sendKeysToElement(locator(pwXPath("//mat-label[contains(text(),'Enter loan company')]/../..//input")), "Others");
    }

    public void validateADA_AdditionalInfoPageVehicleSection() {
        if (!isADATestingEnabled()) {
            return;
        }
        scrollAndClickOnElement(waitElementBeVisible(useThisGuide));
        performADATesting("AdditionalInfoPage_UseThisGuide_HelpSideSheet", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(backArrowIconVINPopUp);
        sendKeysToElement(vinNumberTextBoxElementList.nth(0), "3GCUKREC0EG426454");
        waitForSpinnerToBeGone();
        waitElementBeVisible(confirmYourVINLabel);
        performADATesting("AdditionalInfoPage_ConfirmYourVinPopUp", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(editVINLink);
        waitElementBeVisible(vinNumberTextBoxElementList.nth(0)).fill("");
    }


    public void validateInvalidVIN_AdditionalInfoPage(FarmersSoftAssert fsa) throws Exception {
        int numberOfElements = vinInputFields.count();
        for (int i = 0; i < numberOfElements; i++) {
            Locator vinInputField = vinInputFields.nth(i);
            scrollElementToMiddle(vinInputField);
            sendKeysToElement(vinInputField, "1111736373700");
            sendKeysToElement(vinInputField, Keys.TAB);
            waitForSpinnerToBeGone();
            String vinErrorMessageXpath = "//div[contains(@class,'additional-info-vehicle-info-section')]//mat-error";
            waitElementPresent(pwXPath(vinErrorMessageXpath), 2);
            List<Locator> vinErrorMessages = locators(pwXPath(vinErrorMessageXpath));

            vinErrorMessages.forEach(each -> {
                fsa.assertEquals(getTextFromElement(each), PLEASE_ENTER_VALID_VIN, "Please enter valid VIN error message check");
            });
        }
    }
}
