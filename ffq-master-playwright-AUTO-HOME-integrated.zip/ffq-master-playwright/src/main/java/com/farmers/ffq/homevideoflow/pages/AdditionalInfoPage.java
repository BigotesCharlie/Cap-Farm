package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public final class AdditionalInfoPage extends BaseHomePage {
    public AdditionalInfoPage(Page page) { super(page); }

    public void complete(VideoScenarioData d) {
        waitForBodyReady();
        waitForSpinnerToClear();

        clickRoofReplacedNo();
        ensureCheckbox("It has a swimming pool.", false);
        ensureCheckbox("It has a trampoline.", false);
        ensureCheckbox("Central fire alarm", true);
        ensureCheckbox("Central burglar alarm", true);

        Locator btn = button("Continue");
        if (btn.count() > 0) {
            btn.first().click();
        } else {
            Locator text = page.getByText("Continue", new Page.GetByTextOptions().setExact(false));
            if (text.count() > 0) {
                text.first().click(new Locator.ClickOptions().setForce(true));
            }
        }

        page.waitForFunction(
                "() => {" +
                        "const u = document.location.href.toLowerCase();" +
                        "const text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();" +
                        "return text.includes('about you')" +
                        " || text.includes('last step before your quote')" +
                        " || u.includes('about-you')" +
                        " || u.includes('contact-info')" +
                        " || u.includes('inconvenience') || u.includes('knockout')" +
                        " || text.includes(\"we're sorry, we can't finish\")" +
                        " || text.includes('try again');" +
                        "}",
                null,
                new Page.WaitForFunctionOptions().setTimeout(30_000)
        );
    }

    private void clickRoofReplacedNo() {
        Locator no = page.getByRole(AriaRole.RADIO, new Page.GetByRoleOptions().setName("No").setExact(true));
        if (no.count() > 0) {
            no.first().click(new Locator.ClickOptions().setForce(true));
            return;
        }
        Locator text = page.getByText("No", new Page.GetByTextOptions().setExact(true));
        if (text.count() > 0) {
            text.first().click(new Locator.ClickOptions().setForce(true));
        }
    }

    private void ensureCheckbox(String label, boolean expectedChecked) {
        Locator cb = page.getByLabel(label, new Page.GetByLabelOptions().setExact(true));
        if (cb.count() == 0) {
            return;
        }
        if (expectedChecked && !cb.isChecked()) {
            cb.check(new Locator.CheckOptions().setForce(true));
        }
        if (!expectedChecked && cb.isChecked()) {
            cb.uncheck(new Locator.UncheckOptions().setForce(true));
        }
    }

    private void selectQuestion(String fragment, String option) {
        Locator question = page.getByText(fragment, new Page.GetByTextOptions().setExact(false));
        if (question.count() > 0) {
            Locator block = question.first().locator("xpath=ancestor::*[self::div or self::section][1]");
            Locator opt = block.getByText(option, new Locator.GetByTextOptions().setExact(true));
            if (opt.count() > 0) { 
                try {
                    opt.last().click(); 
                    return;
                } catch (Exception e) {
                    // If element detached, try with force
                    if (e.getMessage().contains("detached")) {
                        opt.last().click(new Locator.ClickOptions().setForce(true));
                        return;
                    }
                }
            }
            // Try non-exact match if exact fails
            Locator optFuzzy = block.getByText(option, new Locator.GetByTextOptions().setExact(false));
            if (optFuzzy.count() > 0) {
                optFuzzy.last().click(new Locator.ClickOptions().setForce(true));
                return;
            }
        }
        // If question not found or option not found in block, skip it
        Locator opt = page.getByText(option, new Page.GetByTextOptions().setExact(false));
        if (opt.count() > 0) {
            try {
                opt.first().click();
            } catch (Exception e) {
                System.out.printf("[VIDEO FLOW] Question option click failed: %s '%s' - %s%n", fragment, option, e.getMessage());
            }
        } else {
            System.out.printf("[VIDEO FLOW] Question option not found: %s '%s'%n", fragment, option);
        }
    }

    private void setCheckbox(String label, boolean expected) {
        Locator box = page.getByRole(AriaRole.CHECKBOX, new Page.GetByRoleOptions().setName(label).setExact(false));
        if (box.count() == 0) box = page.getByLabel(label, new Page.GetByLabelOptions().setExact(false));
        if (box.count() == 0) return;
        Locator b = box.first();
        if (expected && !b.isChecked()) b.click(new Locator.ClickOptions().setForce(true));
        if (!expected && b.isChecked()) b.click(new Locator.ClickOptions().setForce(true));
    }
}
