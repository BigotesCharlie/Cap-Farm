package com.farmers.ffq.common.pages;






import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import org.testng.Assert;
/**
 * Farmers Fast Quote (FFQ) - Non Offering States Page - Legacy version.
 * 
 */
public class LegacyNonOfferingPage extends BasePage {
	private PlaywrightWait wait;
	
	private static final String MAIN_AREA_ID = "farmers-landing-v2";
		private Locator mainArea = locator(pwId(MAIN_AREA_ID));
	
	private static final String BOX_AREA_ID = "BoxArea";
		private Locator intro = locator(pwId(BOX_AREA_ID));

	private static final String NOT_OFFERED_HEADER_ID = "quote_unavailable_header-title";
		private Locator notOfferedHeader = locator(pwId(NOT_OFFERED_HEADER_ID));

	private static final String FARMERS_DIRECT_PAGE_ID = "root";
		private Locator farmersDirectPage = locator(pwId(FARMERS_DIRECT_PAGE_ID));

	private static final String MEDIA_ALPHA_HEADER_ID = "MediaAlphaHead";
		private Locator mediaAlphaHeader = locator(pwId(MEDIA_ALPHA_HEADER_ID));
	
	private static final String QUOTE_UNAVAILABLE_CONTENT_ID = "quote_unavailable-content";
		private Locator quotingUnavailableText = locator(pwId(QUOTE_UNAVAILABLE_CONTENT_ID));
	
	private static final String QUOTES_TEMPORARILY_UNAVAILABLE_ID = "no-auto-quote_header-title";
		private Locator quotingTemporarilyUnavailableHeader = locator(pwId(QUOTES_TEMPORARILY_UNAVAILABLE_ID));
	
	private static final String DONT_OFFER_INSURANCE = "Sorry, we don't offer insurance in your area.";

	/**
	 * Constructor.
	 * 
	 * @throws Exception 
	 */
	public LegacyNonOfferingPage() {
		wait = conditionalWait(60);
	}

	public boolean isNonOfferingTextExist() {
		if (isElementPresent(pwId(NOT_OFFERED_HEADER_ID), 5)) {
			return (getTextFromElement(notOfferedHeader).contains(DONT_OFFER_INSURANCE));
		} else if (isElementPresent(pwId(BOX_AREA_ID), 5)) {
			return getTextFromElement(intro).contains(DONT_OFFER_INSURANCE);
		} else {
			return false;
		}
	}
	
	public boolean isNewNonOfferingPage() throws Exception {
		if (isElementPresent(pwId(MAIN_AREA_ID), 5)) {
			return page().content().contains("Thanks for starting your quote online");
		} else {
			return false;
		}
	}
	
	public void verifyBristolWestNonOfferingPage() {
		waitElementBeVisible(intro);
		Assert.assertTrue(getTextFromElement(mediaAlphaHeader).contains("We're sorry - Farmers doesn't currently offer"), "BRISTOL WEST message (first line) is not visible!");
		Assert.assertTrue(getTextFromElement(mediaAlphaHeader).contains("online quoting in your area."), "BRISTOL WEST message (second line) is not visible!");
		Assert.assertTrue(getTextFromElement(mediaAlphaHeader).contains("Please call 1-800-206-9469 to complete this quote."), "BRISTOL WEST call center number is not visible!");
	}
	
	public boolean farmersInsuranceHawaiiState() throws Exception {
		wait.until(Conditions.attached(pwCss("li.slogan")));
		return page().content().contains("Farmers Hawaii");
	}
	
	public boolean quotingUnavailableTextExists() {
		if (isElementPresent(pwId(QUOTE_UNAVAILABLE_CONTENT_ID), 3)) {
			return getTextFromElement(quotingUnavailableText).contains("We're sorry, but we are unable to provide an online quote at this time.");
		} else if (isElementPresent(pwId(QUOTES_TEMPORARILY_UNAVAILABLE_ID), 3)) {
			return getTextFromElement(quotingTemporarilyUnavailableHeader).contains("Quotes Temporarily Unavailable");
		} else {
			return false;
		}
	}

	public boolean verifySouthCarolinaOfferingPage() throws Exception {
		if (isElementPresent(pwId(FARMERS_DIRECT_PAGE_ID), 5)) {
			return page().url().contains("farmersdirect");
		} else {
			return false;
		}
	}
	
}
