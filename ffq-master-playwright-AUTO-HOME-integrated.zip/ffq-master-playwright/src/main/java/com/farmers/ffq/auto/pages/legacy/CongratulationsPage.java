package com.farmers.ffq.auto.pages.legacy;


import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;

import static com.farmers.ffq.utils.GlobalVariables.SPACE;

public class CongratulationsPage extends BasePage   {

	  	  private Locator congratulationsPageTitle = locator(pwId("PolicyIntro"));

	  	  private Locator thankYouText = locator(pwId("Thanks"));

	  	  private Locator paymentConfirmationNumber = locator(pwId("ConfirmationNumber"));

	  	  private Locator importantNextSteps = locator(pwId("NextStepss"));

	  	  private Locator printButton = locator(pwXPath("//*[@id='buypolicy:printbtn']"));

	  public CongratulationsPage() throws Exception {
		super();
		waitForSpinnerToBeGone();
	}
	  
	public void verifyCongratulationsPage(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		if(isElementPresentByClass(errorMessageElement)) {
			Log.warn("Error found in quote process", true);
		} else {
			if (isElementPresentByID(thankYouText)) {
				Log.info("Verifying Congratulations page...");
				scrollToTopOfPage();
				waitElementBeVisible(congratulationsPageTitle);
				fsa.assertTrue(getTextFromElement(congratulationsPageTitle).contains("Congratulations"), "Congratulations should be visible as header of the page.");
				String thankYouTextDisplayed = getTextFromElement(thankYouText);
				fsa.assertTrue(thankYouTextDisplayed.contains("Thanks, " + applicant.getFirstName() + SPACE + applicant.getLastName()), "Applicant's first and last name displayed..");
				fsa.assertTrue(thankYouTextDisplayed.contains(applicant.getEmail()), "Applicant's email displayed.");

				String accountNumber = "XXXX-XXXX-XXXX-" + applicant.getPayment().getCardNumber().substring(15);
				fsa.assertTrue(getTextFromElement(paymentConfirmationNumber).contains(accountNumber), "Partial card number is correct.");

				String nextSteps = getTextFromElement(importantNextSteps);
				fsa.assertTrue(nextSteps.contains("Sign your Policy Documents with your Farmers agent."), "Sign your Policy Documents text should be visible.");
				fsa.assertTrue(nextSteps.contains("Print your Temporary Evidence of Insurance Card."), "Print your Temporary Evidence of Insurance Card text should be visible.");

				fsa.assertTrue(printButton.isVisible(), "Print button should be visible.");
				fsa.assertTrue(printButton.isEnabled(), "Print button should be enable.");
			} else {
				Log.warn("Never made it to Congratulations screen", true);
			}
		}
	  }

}
