package com.farmers.ffq.ace.hrc.common;


import com.microsoft.playwright.Locator;
import com.farmers.ffq.ace.renters.AceRentersReviewQuotePage;
import com.farmers.ffq.auto.pages.bindpages.ConsolidatedPaymentPage;
import com.farmers.ffq.common.pages.PolicyDebitCreditPayment;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Home.VerifyResponse;
import com.farmers.ffq.datatransferobjects.AppStore.Home.VerifyResponse.PaymentSchedule;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.Assert;

import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCNavigationHelperBasePage.DID_NOT_REACH;
import static com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCConsolidatedPaymentPage extends ConsolidatedPaymentPage {
    /**
     * Constructor.
     *
     * @throws Exception
     */

    protected final String TWELVE_MONTH_TERM_PAYMENT_TEXT = "12-month term payment";
    protected final String DUE_TODAY = "Due today";
    protected final String DUE_MONTHLY = "Due monthly";
        protected Locator feeInfoIcon = locator(pwXPath("//p[contains(text(), 'Fees')]/preceding-sibling::mat-icon[@role='img']"));
        private Locator alternateInfoIcon = locator(pwXPath("//mat-icon[contains(@class, 'info-box-icon')]"));
        private Locator linkToCoverageSubText = locator(pwXPath("//div[contains(@class, 'payment-overview-sub-para')]"));
    AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();

    public AceHRCConsolidatedPaymentPage() throws Exception {
    }

    public void validateConsolidatedPaymentPageRenters(FarmersSoftAssert fsa, String stateCode, double monthlyPremiumAmountOnReviewQuotePage, double payInFullPremiumAmountOnReviewQuotePage) throws Exception {
        fsa.assertTrue(isElementInViewport(pageHeader), "Consolidated payment page - page header is in Viewport");
        // validate sub text link to coverage only for non KS states
        if(!stateCode.equals(KS)){
            validateLinkToCoverageSubText(fsa, monthlyPremiumAmountOnReviewQuotePage, payInFullPremiumAmountOnReviewQuotePage);
        }
        validateContentOfPaymentCardRenters(PAY_IN_FULL, stateCode, fsa);
        validateContentOfPaymentCardRenters(MONTHLY_AUTOPAY, stateCode, fsa);
        comparePayInFullAndMonthlyAutopayPremiumsRenters(fsa);
        validateDiscountSectionRenters(fsa);
        validateMonthlyAutoPayPaymentSectionRenters(fsa, stateCode);
        validatePayInFullPaymentSectionRenters(fsa, stateCode);
        if(!stateCode.equals(KS)){
            validateFeeInfoSectionRenters(fsa);
        }
        validatePreferredPaymentMethodSectionHRC(PAY_IN_FULL, fsa);
        validatePreferredPaymentMethodSectionHRC(MONTHLY_AUTOPAY, fsa);
        validateConsolidatePageDisclaimersRenters(fsa);
    }

    public void verifyPremiumNotChangedOnBackAndForthFromPaymentPageToJFMTP(FarmersSoftAssert fsa, String paymentMethod) throws Exception {
        // Capture the premium amount before navigation
        String premiumAmountBeforeNavigation = getPayInFullOrMonthlyPayPremiumAmountFromTheCard(paymentMethod);

        aceHRCPaymentBasePage.navigateBack();
        AceHRCJustAFewMoreThingsBasePage aceHRCJustAFewMoreThingsBasePage = new AceHRCJustAFewMoreThingsBasePage();
        aceHRCJustAFewMoreThingsBasePage.waitForSpinnerToBeGone();
        aceHRCJustAFewMoreThingsBasePage.clickContinueButton();
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();

        Assert.assertTrue(isOnConsolidatedPaymentPage(), DID_NOT_REACH + "Consolidated payment page.");
        String premiumAmountAfterNavigation = getPayInFullOrMonthlyPayPremiumAmountFromTheCard(paymentMethod);

        // Assert that the premium amount remains unchanged
        fsa.assertEquals(premiumAmountAfterNavigation, premiumAmountBeforeNavigation, "Premium amount unchanged on back and forth navigation from payment page to JFMT page for " + paymentMethod);
       }

    public void verifyPremiumChangedOnBackAndForthFromPaymentPageToReviewQuote(FarmersSoftAssert fsa, String paymentMethod, ApplicantAceHome applicant) throws Exception {
        // Capture the premium amount before navigation
        String premiumAmountBeforeNavigation = getPayInFullOrMonthlyPayPremiumAmountFromTheCard(paymentMethod);

        aceHRCPaymentBasePage.selectStepper(REVIEW_QUOTE);
        waitForSkeletonToBeGone();
        AceRentersReviewQuotePage aceRentersReviewQuotePage = new AceRentersReviewQuotePage();
        Assert.assertTrue(aceRentersReviewQuotePage.isOnReviewQuotePageAceRenters(), DID_NOT_REACH + REVIEW_QUOTE + " page");
        Map<String, String> coveragesBeforeRetrieve = aceRentersReviewQuotePage.getExpectedCoverageAndCoverageAmountFromAppStoreRentersLob(applicant);

        aceRentersReviewQuotePage.clickOnAddEditCoverageLinkButton();
        aceRentersReviewQuotePage.editTheRentersCoveragesAndValidateContentOnMainPage(coveragesBeforeRetrieve, applicant.getStateCode());
        aceRentersReviewQuotePage.clickOnContinueButton();
        AceHRCJustAFewMoreThingsBasePage aceHRCJustAFewMoreThingsBasePage = new AceHRCJustAFewMoreThingsBasePage();
        aceHRCJustAFewMoreThingsBasePage.waitForSpinnerToBeGone();
        aceHRCJustAFewMoreThingsBasePage.clickContinueButton();
        aceHRCPaymentBasePage.waitForSpinnerToBeGone();

        Assert.assertTrue(isOnConsolidatedPaymentPage(), DID_NOT_REACH + "Consolidated payment page.");
        String premiumAmountAfterNavigation = getPayInFullOrMonthlyPayPremiumAmountFromTheCard(paymentMethod);

        // Assert that the premium amount get changed
        fsa.assertNotEquals(premiumAmountAfterNavigation, premiumAmountBeforeNavigation, "Premium amount changed on back and forth navigation from payment page to JFMT page for " + paymentMethod);
    }

    private String getPayInFullOrMonthlyPayPremiumAmountFromTheCard(String paymentMethod) throws Exception {
	new AceHRCJustAFewMoreThingsBasePage().waitForRC3ToBeGone();
	//This method selects the payment method in mobile view; keep it
	String xPathToPaymentMethod = getXPathForPaymentMethod(paymentMethod) + "//div[@class='tui-payplan']";
	if (isUseMobileViewEnabled()) {
	    xPathToPaymentMethod = "//div[@class='tui-payplan']";
	}
	return getTextFromElement(locator(pwXPath(xPathToPaymentMethod)));
    }

    private void validateContentOfPaymentCardRenters(String paymentMethod, String stateCode, FarmersSoftAssert fsa) throws Exception {
        VerifyResponse verifyResponse = aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC();
        double policyFee = getPolicyFee(verifyResponse);
        if(aceHRCPaymentBasePage.isFairPlanFeeState(stateCode)){
            policyFee = policyFee + getFeeSurchargeAmountFromAppStore(verifyResponse);
        }
        double fullTermPremiumAmount = getFullTermAmountPayInFull(verifyResponse);
        double dExpectedAmountPayInFull = fullTermPremiumAmount + policyFee;
        double monthlyPayInstallmentAmountForEFT = getFullTermAmountMonthlyEft(verifyResponse);

        String paymentCardXpath = getXPathForPaymentMethod(paymentMethod);
        Locator paymentCardHeader;
        Locator paymentCardHeaderDescription;
        Locator paymentCardDescription;
        Locator paymentCardExcludedText;
        Locator paymentCardDollarSign;
        Locator paymentCardDollarAmount;
        Locator paymentCardCentAmount;
        Locator paymentCardGreenCheck;
        Locator paymentCardSavingMessage;

        if(isUseMobileViewEnabled()){
            paymentCardHeader = locator(pwXPath(paymentCardXpath));
            paymentCardHeaderDescription = locator(pwXPath(paymentCardXpath));
            paymentCardDescription = locator(pwXPath("//div[@class='amount-section']//p"));
            paymentCardDollarSign = locator(pwXPath(PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_ONE_DOLLAR_SIGN_XPATH));
            paymentCardDollarAmount = locator(pwXPath(PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_TWO_DOLLAR_AMOUNT_XPATH));
            paymentCardCentAmount = locator(pwXPath(PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_THREE_CENT_AMOUNT_XPATH));
            paymentCardGreenCheck = locator(pwXPath(PAYMENT_CARD_GREEN_MARK_XPATH));
            paymentCardSavingMessage = locator(pwXPath(PAYMENT_CARD_SAVINGS_TEXT_XPATH));
        }else{
            paymentCardHeader = locator(pwXPath(paymentCardXpath + PAYMENT_CARD_HEADER_XPATH));
            paymentCardHeaderDescription = locator(pwXPath(paymentCardXpath + PAYMENT_CARD_SUB_HEADER_XPATH));
            paymentCardDescription = locator(pwXPath(paymentCardXpath + PAYMENT_CARD_PAYMENT_DESCRIPTION_XPATH));
            paymentCardDollarSign = locator(pwXPath(paymentCardXpath + PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_ONE_DOLLAR_SIGN_XPATH));
            paymentCardDollarAmount = locator(pwXPath(paymentCardXpath + PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_TWO_DOLLAR_AMOUNT_XPATH));
            paymentCardCentAmount = locator(pwXPath(paymentCardXpath + PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_THREE_CENT_AMOUNT_XPATH));
            refreshPage();
            paymentCardGreenCheck = locator(pwXPath(paymentCardXpath + PAYMENT_CARD_GREEN_MARK_XPATH));
            paymentCardSavingMessage = locator(pwXPath(paymentCardXpath + PAYMENT_CARD_SAVINGS_TEXT_XPATH));
        }

        boolean isOnePay = paymentMethod.equals(PAY_IN_FULL);
        fsa.assertEquals(getTextFromElement(paymentCardHeader).contains(paymentMethod), true, "Payment card header verification: " + paymentMethod);

        String bestValueOrConvenientText = isOnePay ? "Best value" : "Convenient";
        fsa.assertEquals(getTextFromElement(paymentCardHeaderDescription).contains(bestValueOrConvenientText), true, "Payment card sub header verification: " + paymentMethod);

        String oneTimePaymentOrTwelveMonthlyPayment = isOnePay ? "One-time payment" : "12 monthly payments";
        fsa.assertEquals(getTextFromElement(paymentCardDescription).contains(oneTimePaymentOrTwelveMonthlyPayment), true, "Payment card description verification: " + paymentMethod);
        // F91172, F98974/US1101544,US1104962
        if(aceHRCPaymentBasePage.isExcludedFeeState(stateCode)) {
            paymentCardExcludedText = isUseMobileViewEnabled() ? locator(pwXPath(EXCLUDE_FEES_SURCHARGE_TAXES_XPATH)) : locator(pwXPath(paymentCardXpath + EXCLUDE_FEES_SURCHARGE_TAXES_XPATH));
            fsa.assertEquals(getTextFromElement(paymentCardExcludedText), EXCLUDE_FEES_SURCHARGE_TAXES, "Excluded text verification on payment card for " + paymentMethod);
            dExpectedAmountPayInFull = fullTermPremiumAmount;
        }
        String expectedAmount = String.format("$%s", isOnePay ? getFormattedDecimal(dExpectedAmountPayInFull) : getFormattedDecimal(monthlyPayInstallmentAmountForEFT));
        String actualAmount = EMPTY_STRING + getTextFromElement(paymentCardDollarSign) + getTextFromElement(paymentCardDollarAmount) + getTextFromElement(paymentCardCentAmount);
        fsa.assertEquals(actualAmount, expectedAmount, "Displayed amount check for " + paymentMethod);

        fsa.assertTrue(paymentCardGreenCheck.isVisible(), "Green check is displayed " + paymentMethod);
        String expectedSavingMessage = isOnePay ? "Preferred payment plan savings" : "Autopay savings";
        fsa.assertEquals(getTextFromElement(paymentCardSavingMessage), expectedSavingMessage, "Saving message in the payment card for " + paymentMethod);

        testStep("Payment card content validation for : " + paymentMethod);
    }

    private void comparePayInFullAndMonthlyAutopayPremiumsRenters(FarmersSoftAssert fsa) throws Exception {
        Locator paymentCardPayInFullDollars;
        Locator paymentCardPayInFullCents;
        Locator paymentCardMonthlyAutopayDollars;
        Locator paymentCardMonthlyAutopayCents;
        String payInFullAmount;
        String monthlyAutopayAmount;
        if (isUseMobileViewEnabled()) {
            getXPathForPaymentMethod(PAY_IN_FULL);
            paymentCardPayInFullDollars = locator(pwXPath(PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_TWO_DOLLAR_AMOUNT_XPATH));
            paymentCardPayInFullCents = locator(pwXPath(PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_THREE_CENT_AMOUNT_XPATH));
            payInFullAmount = getTextFromElement(paymentCardPayInFullDollars) + getTextFromElement(paymentCardPayInFullCents);
            getXPathForPaymentMethod(MONTHLY_AUTOPAY);
            paymentCardMonthlyAutopayDollars = locator(pwXPath(PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_TWO_DOLLAR_AMOUNT_XPATH));
            paymentCardMonthlyAutopayCents = locator(pwXPath(PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_THREE_CENT_AMOUNT_XPATH));
        } else {
            String payInFullXpath = getXPathForPaymentMethod(PAY_IN_FULL);
            paymentCardPayInFullDollars = locator(pwXPath(payInFullXpath + PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_TWO_DOLLAR_AMOUNT_XPATH));
            paymentCardPayInFullCents = locator(pwXPath(payInFullXpath + PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_THREE_CENT_AMOUNT_XPATH));
            payInFullAmount = getTextFromElement(paymentCardPayInFullDollars) + getTextFromElement(paymentCardPayInFullCents);
            String monthlyAutopayXpath = getXPathForPaymentMethod(MONTHLY_AUTOPAY);
            paymentCardMonthlyAutopayDollars = locator(pwXPath(monthlyAutopayXpath + PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_TWO_DOLLAR_AMOUNT_XPATH));
            paymentCardMonthlyAutopayCents = locator(pwXPath(monthlyAutopayXpath + PAYMENT_CARD_PAYMENT_DETAILS_COLUMN_THREE_CENT_AMOUNT_XPATH));
        }
        monthlyAutopayAmount = getTextFromElement(paymentCardMonthlyAutopayDollars) + getTextFromElement(paymentCardMonthlyAutopayCents);
        double dPayInFull = Double.parseDouble(payInFullAmount.replace(COMMA,EMPTY_STRING));
        double dMonthlyAutopay = Double.parseDouble(monthlyAutopayAmount.replace(COMMA,EMPTY_STRING));
        double dDueTodayAmount = Double.parseDouble(getTextFromElement(dueTodayAmount).replaceAll("[,$]",EMPTY_STRING));

        fsa.assertTrue(dPayInFull <= Math.ceil(dMonthlyAutopay*11 + dDueTodayAmount), "Pay in full premium is less or equal to Monthly Autopay.");
    }

    private void validateDiscountSectionRenters(FarmersSoftAssert fsa) throws Exception {

        if (isUseMobileViewEnabled()) {
            fsa.assertEquals(getTextFromElement(discountTitleMobile), "Discounts included", "Discount section title validation (mobile).");
        } else {
            fsa.assertEquals(getTextFromElement(discountTitle), "Discounts included", "Discount section title validation (desktop).");
        }

        List<String> expectedDiscounts = aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC().getDiscounts().stream().map(AppStore.Home.VerifyResponse.Discount::getName).collect(Collectors.toList());

        locators(pwXPath("//div[contains(@class,'discount-item')]//mat-icon")).forEach(each -> {
            fsa.assertTrue(each.isVisible(), "Green checkbox is displayed for given discount: " + getTextFromElement(each));
        });
        fsa.assertEquals(getDiscountNames(), expectedDiscounts, "Discounts verification ");

        testStep("Validate discounts against the appstore on the " + this.getClass().getSimpleName());
    }

    private void validateMonthlyAutoPayPaymentSectionRenters(FarmersSoftAssert fsa, String stateCode) throws Exception {
        String commonMessage = "Monthly autopay payment section : ";
        selectPaymentMethodFromPaymentCards(MONTHLY_AUTOPAY);
        fsa.assertEquals(getTextFromElement(monthlyAutoPaySectionHeader), MONTHLY_AUTOPAY, commonMessage + "header validation");
        fsa.assertEquals(getTextFromElement(firstMonthlyPaymentText), "First monthly payment", commonMessage + "first monthly payment text validation");
        VerifyResponse verifyResponse = aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC();
        VerifyResponse.PaymentSchedule mtef = verifyResponse.getPaymentSchedules().stream().filter(each -> each.getPayPlanCode().equals("MTEF")).findFirst().get();

        double downPaymentMTEF = Double.parseDouble(mtef.getDownPayment().getAmount().getAmount());
        String expectedFirstMonthlyAmount = CurrencyFormat.convertStringIntoCurrencyFormat(getFormattedDecimal(downPaymentMTEF));
        fsa.assertEquals(getTextFromElement(firstMonthlyPaymentAmount), expectedFirstMonthlyAmount, commonMessage + "first monthly payment amount validation");
        double policyFee = Double.parseDouble(verifyResponse.getPolicyFee().getAmount());
        double dExpectedDueTodayAmount = downPaymentMTEF + policyFee;

        //  F86786 & F89139: PL - Home FFQ & eCheckout - TX & CO Farmers FAIR Plan Recoupment Fee
        if(aceHRCPaymentBasePage.isFairPlanFeeState(stateCode)){
            double feeSurchargeAmount = getFeeSurchargeAmountFromAppStore(verifyResponse);
            String expectedFairPlanOneTimeFeeAmount = getFormattedDecimal(feeSurchargeAmount + policyFee);
            fsa.assertEquals(getTextFromElement(monthlyPayOneTimeFeeText), FEES_LABEL, commonMessage + " fee label text validation");
            fsa.assertEquals(getTextFromElement(monthlyPayFeeAmount), CurrencyFormat.convertStringIntoCurrencyFormat(expectedFairPlanOneTimeFeeAmount), commonMessage + " fee amount validation");
            dExpectedDueTodayAmount += feeSurchargeAmount;
        } else if(aceHRCPaymentBasePage.isExcludedFeeState(stateCode)) { // F91172, F98974/US1101544,US1104962
            double feeSurchargeAmount = getTaxAmountHRC(verifyResponse, MONTHLY_EFT);
            dExpectedDueTodayAmount += feeSurchargeAmount;
            String expectedTaxesSurchargeAmount = CurrencyFormat.convertStringIntoCurrencyFormat(getFormattedDecimal(feeSurchargeAmount));
            fsa.assertEquals(getTextFromElement(monthlyPaySurchargeText), TAXES_AND_SURCHARGES_TEXT, commonMessage + " taxes and surcharge label text validation");
            fsa.assertEquals(getTextFromElement(monthlyPaySurchargeAmount), expectedTaxesSurchargeAmount, commonMessage + " taxes and surcharge amount validation");
        } else{
            //Fee section is not applicable for KS
            if(!stateCode.equals(KS)) {
                fsa.assertEquals(getTextFromElement(monthlyPayOneTimeFeeText), ONE_TIME_FEE, commonMessage + "fee label validation");
                fsa.assertEquals(getTextFromElement(monthlyPayFeeAmount), CurrencyFormat.convertStringIntoCurrencyFormat(getFormattedDecimal(policyFee)), commonMessage + "fee amount validation");
            }
        }

        String expectedDueTodayAmount = CurrencyFormat.convertStringIntoCurrencyFormat(getFormattedDecimal(dExpectedDueTodayAmount));
        fsa.assertEquals(getTextFromElement(dueTodayLabel), DUE_TODAY_LABEL, commonMessage + "due today label validation");
        fsa.assertEquals(getTextFromElement(dueTodayAmount), expectedDueTodayAmount, commonMessage + "due today amount validation");

        double totalInstallmentAmount = mtef.getInstallments().stream().mapToDouble(each -> Double.parseDouble(each.getCurrencyAmount())).sum();
        double totalTwelveTermPrice = totalInstallmentAmount + downPaymentMTEF;
        String expectedTotalText;
        // F91172, F98974/US1101544,US1104962
        if (aceHRCPaymentBasePage.isExcludedFeeState(stateCode)) {
            expectedTotalText = String.format("%s for 12-month term price (excludes taxes, fees, & surcharges)", CurrencyFormat.convertStringIntoCurrencyFormat(getFormattedDecimal(totalTwelveTermPrice)));
        } else {
            expectedTotalText = String.format("%s for 12-month term price", CurrencyFormat.convertStringIntoCurrencyFormat(getFormattedDecimal(totalTwelveTermPrice)));
        }
        fsa.assertEquals(getTextFromElement(monthlyAutoPayTotalHeader), expectedTotalText, commonMessage + "12 month term price title validation");
        testStep("Validate monthly payment section");
    }

    private void validatePayInFullPaymentSectionRenters(FarmersSoftAssert fsa, String stateCode) throws Exception {
        String commonMessage = "Pay in full payment section : ";
        VerifyResponse verifyResponse = aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC();
        VerifyResponse.PaymentSchedule pif = verifyResponse.getPaymentSchedules().stream().filter(each -> each.getPayPlan().equals("B1")).findFirst().get();
        double unformattedFullTermPremium = Double.parseDouble(pif.getFullTermPremium());
        double unformattedPolicyFeeAmount = Double.parseDouble(verifyResponse.getPolicyFee().getAmount());
        String expectedSixMonthFullTermPremium = CurrencyFormat.convertStringIntoCurrencyFormat(getFormattedDecimal(unformattedFullTermPremium));
        String expectedOneTimeFeeAmount = CurrencyFormat.convertStringIntoCurrencyFormat(getFormattedDecimal(unformattedPolicyFeeAmount));
        double dExpectedDueTodayAmount = unformattedFullTermPremium + unformattedPolicyFeeAmount;
        //make sure selecting one pay to validate one pay section
        selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
        fsa.assertEquals(getTextFromElement(payInFullPaySectionHeader), PAY_IN_FULL, commonMessage + "header text validation");
        fsa.assertEquals(getTextFromElement(payInFullSixMonthTermPriceText), TWELVE_MONTH_TERM_PAYMENT_TEXT, commonMessage + "12 month term price text");
        fsa.assertEquals(getTextFromElement(payInFullSixMonthTermPriceAmount), expectedSixMonthFullTermPremium, commonMessage + "12 month term price amount");

        // F86786 & F89139: PL - Home FFQ & eCheckout - TX & CO Farmers FAIR Plan Recoupment Fee
        if(aceHRCPaymentBasePage.isFairPlanFeeState(stateCode)){
            double feeSurchargeAmount = getFeeSurchargeAmountFromAppStore(verifyResponse);
            String expectedFairPlanOneTimeFeeAmount = getFormattedDecimal(feeSurchargeAmount + unformattedPolicyFeeAmount);
            fsa.assertEquals(getTextFromElement(payInFullOneTimeFeesText), FEES_LABEL, commonMessage + " fee label text validation");
            fsa.assertEquals(getTextFromElement(payInFullOneTimeFeesAmount), CurrencyFormat.convertStringIntoCurrencyFormat(expectedFairPlanOneTimeFeeAmount), commonMessage + " fee amount validation");
            dExpectedDueTodayAmount += feeSurchargeAmount;
        } else if(aceHRCPaymentBasePage.isExcludedFeeState(stateCode)) { // F91172, F98974/US1101544,US1104962
            double feeSurchargeAmount = getTaxAmountHRC(verifyResponse, ONE_PAY);
            dExpectedDueTodayAmount += feeSurchargeAmount;
            String expectedTaxesSurchargeAmount = CurrencyFormat.convertStringIntoCurrencyFormat(getFormattedDecimal(feeSurchargeAmount));
            fsa.assertEquals(getTextFromElement(payInFullTaxesAndSurchargeText), TAXES_AND_SURCHARGES_TEXT, commonMessage + " taxes and surcharge label text validation");
            fsa.assertEquals(getTextFromElement(payInFullTaxesAndSurchargeAmount), expectedTaxesSurchargeAmount, commonMessage + " taxes and surcharge amount validation");
        } else{
            //Fee section is not applicable for KS state
            if(!stateCode.equals(KS)) {
                fsa.assertEquals(getTextFromElement(payInFullOneTimeFeesText), ONE_TIME_FEE, commonMessage + "one time fee text validation");
                fsa.assertEquals(getTextFromElement(payInFullOneTimeFeesAmount), expectedOneTimeFeeAmount, commonMessage + " one time fee amount validation");
            }
        }
        String expectedDueTodayAmount = CurrencyFormat.convertStringIntoCurrencyFormat(getFormattedDecimal(dExpectedDueTodayAmount));
        fsa.assertEquals(getTextFromElement(payInFullDueTodayText), DUE_TODAY_LABEL, commonMessage + " due today text/label validation");
        fsa.assertEquals(getTextFromElement(payInFullDueTodayAmount), expectedDueTodayAmount, commonMessage + " due today amount validation");
        String expectedTotalText;
        // F91172, F98974/US1101544,US1104962
        if (aceHRCPaymentBasePage.isExcludedFeeState(stateCode)) {
            expectedTotalText = String.format("%s for 12-month term price (includes taxes, fees, & surcharges)", expectedDueTodayAmount);
        } else {
            expectedTotalText = String.format("%s for 12-month term price", expectedDueTodayAmount);
        }
        fsa.assertEquals(getTextFromElement(payInFullBottomPaymentDetails), expectedTotalText, commonMessage + " bottom total amount validation");

    }

    public void validateFeeInfoSectionRenters(FarmersSoftAssert fsa) throws Exception {
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();

        String commonMessage = "Fee info section : ";
        final String POLICY_FEES_DESCRIPTION = "A policy fee is applied for each new policy. No fee is applied for additional coverage.";
        final String MEMBERSHIP_FEES_DESCRIPTION = "A membership fee is applied for each new policy. No fee is applied for additional coverage.";
        final String FAIR_PLAN_RECOUPMENT_FEES_DESCRIPTION = "Includes a one-time policy fee and a recurring FAIR Plan Assessment recoupment.";
        final String EXPENSE_CONSTANT_DESCRIPTION = "A fee is applied for each new policy. No fee is applied for additional coverage.";

        String expectedFeeDescription = MEMBERSHIP_FEES_DESCRIPTION;
        String expectedInfoBoxHeader = "Fees";
        Locator expectedInfoIcon = landingStateCode.equals(MD)? alternateInfoIcon: feeInfoIcon;
        if (List.of(AL, FL, ID, IL, ID, LA, MA, MT, NC, NY).contains(landingStateCode)) {
            expectedFeeDescription = POLICY_FEES_DESCRIPTION;
        } else if (landingStateCode.equals(CO)) {
            expectedFeeDescription = MEMBERSHIP_FEES_DESCRIPTION + SPACE + FAIR_PLAN_RECOUPMENT_FEES_DESCRIPTION_CO;
        } else if (landingStateCode.equals(MD)) {
            expectedInfoBoxHeader = "Expense Constant";
            expectedFeeDescription = EXPENSE_CONSTANT_DESCRIPTION;
        } else if (landingStateCode.equals(TX)) {
            expectedFeeDescription = FAIR_PLAN_RECOUPMENT_FEES_DESCRIPTION;
        } else if (landingStateCode.equals(MN)) {
            expectedFeeDescription = MEMBERSHIP_FEES_DESCRIPTION + APPLICABLE_TAXES_APPLIED_MN;
        } else if (landingStateCode.equals(CT)) {
            expectedFeeDescription = MEMBERSHIP_FEES_DESCRIPTION + APPLICABLE_SURCHARGE_CT;
        }
        fsa.assertEquals(getTextFromElement(feeInfoBoxHeader), expectedInfoBoxHeader, commonMessage + "header validation");
        fsa.assertEquals(getTextFromElement(feeInfoBoxDescription), expectedFeeDescription, commonMessage + "description validation");
        fsa.assertTrue(expectedInfoIcon.isVisible(), commonMessage + "info icon is displayed");
    }

    private void validateConsolidatePageDisclaimersRenters(FarmersSoftAssert fsa) throws Exception {
        selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPagePayInFull(fsa, RENTERS);
        aceHRCPaymentBasePage.validateOneTimePaymentRecurringRadioButtonText(fsa, RENTERS);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphPayInFull(fsa, RENTERS);
        selectPaymentMethodFromPaymentCards(MONTHLY_AUTOPAY);
        aceHRCPaymentBasePage.validateTwoBulletPointsAtTheBottomOfThePaymentPageMonthlyAutoPay(fsa, RENTERS);
        aceHRCPaymentBasePage.validateContactAgentOrFarmersDirectSalesParagraphMonthlyAutoPay(fsa, RENTERS);
    }

    public void validatePaymentsRenters(FarmersSoftAssert fsa) throws Exception {
        AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
        selectPaymentMethodFromPaymentCards(MONTHLY_AUTOPAY);
        clickBankPaymentRadioButton();
        validateBankAccountAdditionRenters(fsa, MONTHLY_AUTOPAY);
        aceHRCPaymentBasePage.clickChangeLink();
        aceHRCPaymentBasePage.clickDebitCreditCardToggleButton();
        validateDebitCardPaymentAdditionRenters(fsa, MONTHLY_AUTOPAY);
        aceHRCPaymentBasePage.clickChangeLink();
        aceHRCPaymentBasePage.clickDebitCreditCardToggleButton();
        validateCreditCardPaymentRenters(fsa, MONTHLY_AUTOPAY, false);

        selectPaymentMethodFromPaymentCards(PAY_IN_FULL);
        clickBankPaymentRadioButton();
        validateBankAccountAdditionRenters(fsa, PAY_IN_FULL);
        aceHRCPaymentBasePage.clickChangeLink();
        aceHRCPaymentBasePage.clickDebitCreditCardToggleButton();
        validateDebitCardPaymentAdditionRenters(fsa, PAY_IN_FULL);
        aceHRCPaymentBasePage.clickChangeLink();
        aceHRCPaymentBasePage.clickDebitCreditCardToggleButton();
        validateCreditCardPaymentRenters(fsa, PAY_IN_FULL, false);
    }
    public void validateBankAccountAdditionRenters(FarmersSoftAssert fsa, String paymentMethod) throws Exception {
        String commonMessage = paymentMethod + " Bank Account Addition";

        //add bank account as payment

        String accountNumber = RandomStringUtils.randomNumeric(6);
        addCheckingAccountPaymentMethod(BOFA_ROUTING_NUMBER, accountNumber);
        waitForSpinnerToBeGone();
        scrollToElement(waitElementBeVisible(bankAccountAddedMessage, 10));
        //validations
        fsa.assertTrue(bankAccountAddedMessage.isVisible(), "Bank account is added message is displayed for " + commonMessage);
        fsa.assertTrue(paymentAddedGreenCheck.isVisible(), "Green check icon is displayed for  : " + commonMessage);
        fsa.assertTrue(addedBankIcon.isVisible(), "Bank icon should be displayed after bank payment addition : " + commonMessage);
        fsa.assertTrue(maskedAddedPaymentDetails.isVisible(), "Bank account number (masked) should be displayed after bank payment addition : " + commonMessage);
        String expectedMaskedAccountNumber = String.format("%s %s", accountNumber.substring(2, 4), accountNumber.substring(accountNumber.length() - 2));
        fsa.assertEquals(getTextFromElement(maskedAddedPaymentDetails), expectedMaskedAccountNumber, "Bank account number (masked) should be as expected for : " + commonMessage);
        fsa.assertTrue(changePaymentMethodLink.isVisible() && changePaymentMethodLink.isEnabled(), "Change should be displayed  and enabled after bank payment addition : " + commonMessage);
        String expectedServiceChargeMessage = "";
        if (paymentMethod.equals(MONTHLY_AUTOPAY)) {
           List<VerifyResponse.PaymentSchedule> paymentSchedules = getSessionStorageAppStore().getHome().getVerifyResponse().getPaymentSchedules();

            int administrativeCharge = aceHRCPaymentBasePage.getAdministrativeFeeForGivenPayPlanDescriptionHRC(paymentSchedules, MONTHLY_EFT);

            if (administrativeCharge > 0) {
                expectedServiceChargeMessage = String.format(
                        "Your payment method added a $%s service charge.", administrativeCharge);
                fsa.assertTrue(infoIcon.isVisible(), "Info icon for credit card service charge section : " + commonMessage);
                String expectedServiceChargeTitle = "Service charge";
                fsa.assertEquals(getTextFromElement(serviceChargeTitle), expectedServiceChargeTitle, "Service charge section title validation for : " + commonMessage);
                fsa.assertEquals(getTextFromElement(serviceChargeMessage), expectedServiceChargeMessage, "Service charge message validation for : " + commonMessage);
            }else{
                expectedServiceChargeMessage = "No service charges when using bank transfer.";
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(chargeDisclaimerText)), expectedServiceChargeMessage, "Service charge disclaimer text validation for " + commonMessage);

            }
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyText), DUE_MONTHLY, "Due monthly text validation for : " + commonMessage);
            String expectedDueMonthlyAmount = CurrencyFormat.convertStringIntoCurrencyFormat(aceHRCPaymentBasePage.getInstallmentAmountFarmersHRC(MONTHLY_DEBIT_CARD_DESCRIPTION));
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyAmount), expectedDueMonthlyAmount, "Due monthly amount validation for: " + commonMessage);
        }else{
            expectedServiceChargeMessage = NO_SERVICE_CHARGE_WHEN_PAYING_IN_FULL;
            fsa.assertEquals(getTextFromElement(chargeDisclaimerText), expectedServiceChargeMessage, "Service charge message validation for : " + commonMessage);
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyText), DUE_TODAY, "Due today text validation for: " + commonMessage);
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyAmount), String.format("$%,.2f", Double.parseDouble(getDueTodayAmountForOnePayRenters())), "Due today amount validation for: " + commonMessage);
        }
    }
    private String getDueTodayAmountForOnePayRenters() throws Exception {
        VerifyResponse verifyResponse = aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC();
        String stateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        VerifyResponse.PaymentSchedule onePay = verifyResponse.getPaymentSchedules().stream().filter(each -> each.getPayPlan().equals("B1")).findFirst().get();
        double polFee = Double.parseDouble(verifyResponse.getPolicyFee().getAmount());
        double fullTermPremium = Double.parseDouble(onePay.getFullTermPremium());
        double stateTax = Double.parseDouble(onePay.getStateTax() != null ? onePay.getStateTax() : "0.00");
        String dueToday = String.valueOf(polFee + fullTermPremium + stateTax);
        if(aceHRCPaymentBasePage.isFairPlanFeeState(stateCode)){
            double feeSurcharge = getFeeSurchargeAmountFromAppStore(verifyResponse);
            return String.valueOf(polFee + fullTermPremium + feeSurcharge);
        }
        return dueToday;
    }

    private String getCreditDebitCardName(String cardNumber) {
        String cardName;
        switch (cardNumber) {
            case AMERICAN_EXPRESS_CARD:
                cardName = CARD_NAME_AMEX;
                break;
            case VISA_DEBIT_CARD:
                cardName = CARD_NAME_VISA;
                break;
            case VISA_DEBIT_CARD_2:
                cardName = CARD_NAME_VISA;
                break;
            case DISCOVER_CARD:
                cardName = CARD_NAME_DISCOVER;
                break;
            case MASTER_CARD:
                cardName = CARD_NAME_MASTER;
                break;
            default:
                cardName = "";
                break;
        }
        return cardName;
    }

    public void validateDebitCardPaymentAdditionRenters(FarmersSoftAssert fsa, String paymentMethod) throws Exception {
        String commonMessage = paymentMethod + " Debit card addition";
        boolean isPayInFull = paymentMethod.equals(PAY_IN_FULL);
        String debitCardNumber = isPayInFull ? VISA_DEBIT_CARD : VISA_DEBIT_CARD_2;
        addCardPaymentMethod(debitCardNumber, getSessionStorageAppStore().getData().getLandingZipCode());
        waitForSpinnerToBeGone();

        scrollToElement(debitCardAddedMessage);
        fsa.assertEquals(getTextFromElement(debitCardAddedMessage), "Debit card added.", "Debit card added message for : " + commonMessage);
        fsa.assertTrue(isElementDisplayed(paymentAddedGreenCheck,3), "Green check is displayed for : " + commonMessage);
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        boolean addedCardIcon = policyDebitCreditPayment.waitUntilCardSymbolIsDisplayed(getCreditDebitCardName(debitCardNumber));
        fsa.assertTrue(addedCardIcon, "Payment method icon is displayed for  : " + commonMessage);
        String expectedMaskedPaymentMethod = String.format("%s | Exp %s", debitCardNumber.substring(12), EXP_DATE);
        fsa.assertEquals(getTextFromElement(maskedAddedPaymentDetails), expectedMaskedPaymentMethod, "Masked debit card details validation for: " + commonMessage);
        waitElementBeVisible(changePaymentMethodLink);
        fsa.assertTrue(changePaymentMethodLink.isVisible() && changePaymentMethodLink.isEnabled(), "Change link should be displayed and enabled for: " + commonMessage);

        if (paymentMethod.equals(MONTHLY_AUTOPAY)) {
            List<VerifyResponse.PaymentSchedule> paymentSchedules = aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC().getPaymentSchedules();
            fsa.assertTrue(infoIcon.isVisible(), "Info icon for credit card service charge section : " + commonMessage);
            String expectedServiceChargeTitle = "Service charge";
            fsa.assertEquals(getTextFromElement(serviceChargeTitle), expectedServiceChargeTitle, "Service charge section title validation for : " + commonMessage);
            int administrativeCharge = aceHRCPaymentBasePage.getAdministrativeFeeForGivenPayPlanDescriptionHRC(paymentSchedules, MONTHLY_DEBIT_CARD_DESCRIPTION);
            String expectedServiceChargeMessage = String.format("Your payment method added a $%s service charge.", administrativeCharge);
            fsa.assertEquals(getTextFromElement(serviceChargeMessage), expectedServiceChargeMessage, "Service charge message validation for : " + commonMessage);
            fsa.assertEquals(getTextFromElement(changeSuggestionLink), "You can lower your cost by changing to a bank transfer.", "Change to debit or Credit card suggestion link validation for : " + commonMessage);
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyText), DUE_MONTHLY, "Due monthly text validation for: " + commonMessage);
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyAmount), String.format("$%.2f", Double.parseDouble(aceHRCPaymentBasePage.getInstallmentAmountFarmersHRC(MONTHLY_DEBIT_CARD_DESCRIPTION))), "Due monthly amount validation for: " + commonMessage);
        } else {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(chargeDisclaimerText)), NO_SERVICE_CHARGE_WHEN_PAYING_IN_FULL, "Service charge disclaimer should be as expected for : " + commonMessage);
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyText), DUE_TODAY, "Due today text validation for: " + commonMessage);
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyAmount), String.format("$%.2f", Double.parseDouble(getDueTodayAmountForOnePayRenters())), "Due today amount validation for: " + commonMessage);
        }
    }

    public void validateCreditCardPaymentRenters(FarmersSoftAssert fsa, String paymentMethod, boolean isUsedInSamePaymentAsAutoBundle) throws Exception {
        String commonMessage = paymentMethod + " Credit Card payment addition";
        String creditCard = "";
        if(!isUsedInSamePaymentAsAutoBundle){
            creditCard = paymentMethod.equals(PAY_IN_FULL) ? AMERICAN_EXPRESS_CARD : new Random().nextBoolean() ? DISCOVER_CARD : MASTER_CARD;
            addCardPaymentMethod(creditCard, getSessionStorageAppStore().getData().getLandingZipCode());
        }else{
            creditCard = MASTER_CARD;
        }
        scrollToElement(waitElementBeVisible(creditCardAddedMessage));
        fsa.assertEquals(getTextFromElement(creditCardAddedMessage), "Credit card added.", "Credit card added message for : " + commonMessage);
        scrollToElement(creditCardAddedMessage);
        fsa.assertTrue(paymentAddedGreenCheck.isVisible(), "Green check is displayed for : " + commonMessage);
        PolicyDebitCreditPayment policyDebitCreditPayment = new PolicyDebitCreditPayment();
        boolean addedCardIcon = policyDebitCreditPayment.waitUntilCardSymbolIsDisplayed(getCreditDebitCardName(creditCard));
        fsa.assertTrue(addedCardIcon, "Payment method icon "+ getCreditDebitCardName(creditCard) +"  is displayed for  : " + commonMessage);
        //amex credit cards has 15 digits while other has 16 digits
        int startIndex = creditCard.equals(AMERICAN_EXPRESS_CARD) ? 11 : 12;
        String expectedMaskedPaymentMethod = String.format("%s | Exp %s", creditCard.substring(startIndex), EXP_DATE);
        fsa.assertEquals(getTextFromElement(maskedAddedPaymentDetails), expectedMaskedPaymentMethod, "Masked credit card details validation for: " + commonMessage);
        fsa.assertTrue(changePaymentMethodLink.isVisible() && changePaymentMethodLink.isEnabled(), "Change link should be displayed and enabled for: " + commonMessage);
        addedCardIcon = policyDebitCreditPayment.waitUntilCardSymbolIsDisplayed(getCreditDebitCardName(creditCard));
        fsa.assertTrue(addedCardIcon, "Payment method icon is displayed for  : " + commonMessage);

        if (paymentMethod.equals(MONTHLY_AUTOPAY)) {
            fsa.assertTrue(infoIcon.isVisible(), "Info icon for credit card service charge section : " + commonMessage);
            String serviceCharge = "Service charge";
            fsa.assertEquals(getTextFromElement(serviceChargeTitle), serviceCharge, "Service charge section title validation for : " + commonMessage);
            List<VerifyResponse.PaymentSchedule> paymentSchedules = getSessionStorageAppStore().getHome().getVerifyResponse().getPaymentSchedules();
            int administrativeCharge = aceHRCPaymentBasePage.getAdministrativeFeeForGivenPayPlanDescriptionHRC(paymentSchedules, MONTHLY_DEBIT_CREDIT_CARD);
            String expectedServiceChargeMessage = String.format("Your payment method added a $%s service charge.", administrativeCharge);
            fsa.assertEquals(getTextFromElement(serviceChargeMessage), expectedServiceChargeMessage, "Service charge message validation for : " + commonMessage);
        } else {
            fsa.assertEquals(getTextFromElement(chargeDisclaimerText), NO_SERVICE_CHARGE_WHEN_PAYING_IN_FULL);
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyText), DUE_TODAY, "Due today text validation for: " + commonMessage);
            fsa.assertEquals(getTextFromElement(paymentAddedDueMonthlyAmount), String.format("$%.2f", Double.parseDouble(getDueTodayAmountForOnePayRenters())), "Due today amount validation for: " + commonMessage);
        }
    }

    protected void validatePreferredPaymentMethodSectionHRC(String paymentMethod, FarmersSoftAssert fsa) throws Exception {
        selectPaymentMethodFromPaymentCards(paymentMethod);
        boolean isCAState = getSessionStorageAppStore().getData().getLandingStateCode().equals(CA);
        String commonMessage = paymentMethod + " Preferred payment method section ";
        fsa.assertEquals(getTextFromElement(paymentMethodSelectionHeader), SELECT_YOUR_PREFERRED_PAYMENT_METHOD, commonMessage + "header validation");
        fsa.assertEquals(getTextFromElement(paymentSelectionBankPaymentRadioButton), BANK_PAYMENT, commonMessage + "bank payment radio button label");
        fsa.assertEquals(getTextFromElement(paymentSelectionCardRadioButton), CARD, commonMessage + "card payment radio button label");
        List<PaymentSchedule> paymentSchedules = aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC().getPaymentSchedules();
        if (paymentMethod.equals(MONTHLY_AUTOPAY)) {
            Locator cardPaymentServiceChargeElement = isCAState ? californiaCardPaymentServiceChargesText : bankCardPaymentServiceChargesText.nth(1);
            int expectedMonthlyPayDebitCardAdministrativeFee;
            int expectedMonthlyPayCreditCardAdministrativeFee;
            String serviceCharges = "";
            if(!isCAState) {
                expectedMonthlyPayDebitCardAdministrativeFee = getAdministrativeFeeForGivenPayPlanDescriptionHRC(paymentSchedules, MONTHLY_DEBIT_CARD_DESCRIPTION);
                expectedMonthlyPayCreditCardAdministrativeFee = getAdministrativeFeeForGivenPayPlanDescriptionHRC(paymentSchedules, MONTHLY_DEBIT_CREDIT_CARD);
                if ((expectedMonthlyPayDebitCardAdministrativeFee == 0) && (expectedMonthlyPayCreditCardAdministrativeFee == 0)) {
                    serviceCharges = "$0 in service charges";
                } else {
                    serviceCharges = String.format("$%s - $%s in service charges", expectedMonthlyPayDebitCardAdministrativeFee, expectedMonthlyPayCreditCardAdministrativeFee);
                    if (expectedMonthlyPayDebitCardAdministrativeFee == expectedMonthlyPayCreditCardAdministrativeFee) {
                        serviceCharges = String.format("$%s in service charges", expectedMonthlyPayDebitCardAdministrativeFee);
                    }
                }
                fsa.assertEquals(getTextFromElement(cardPaymentServiceChargeElement), serviceCharges, commonMessage + "card payment radio button label card service charges");
            } else {
                fsa.assertTrue(isElementVisible(californiaCardPaymentRadioButton, 1),"Card radio button is disabled for monthly auto pay in CA state");
                fsa.assertEquals(getTextFromElement(californiaCardNotAvailableMonthlyPayMessage),
                        "(Not available for monthly autopay)", commonMessage + "CA Card not available message");
                fsa.assertEquals(getTextFromElement(cardPaymentServiceChargeElement), "$2 - $5 in service charges", commonMessage + "card payment radio button label bank service charges");
            }
        }
    }

    private int getAdministrativeFeeForGivenPayPlanDescriptionHRC(List<PaymentSchedule> paymentSchedules, String payPlanDescription) {
        PaymentSchedule paymentSchedule = filterListOfPaymentScheduleByPayPlanHRC(paymentSchedules, payPlanDescription).stream().findFirst().get();
        String currencyAmount = paymentSchedule.getAdministrativeCharges().getCurrencyAmount();
        return (int) Double.parseDouble(currencyAmount);
    }

    private List<PaymentSchedule> filterListOfPaymentScheduleByPayPlanHRC(List<PaymentSchedule> paymentSchedules, String payPlanDescription){
        System.out.println("Payment schedules " + paymentSchedules);
        return  paymentSchedules.stream().filter(c -> c.getPayPlanDescription().equals(payPlanDescription)).collect(Collectors.toList());
    }

    public Double getFeeSurchargeAmountFromAppStore(VerifyResponse verifyResponse){
        return Double.parseDouble(verifyResponse.getAdditionalTaxes().stream().filter(i->i.getType().equals("feeSurcharge")).collect(Collectors.toList()).get(0).getAmount());
    }

    private double getFullTermAmountPayInFull(VerifyResponse verifyResponse){
        double fullTermPremiumAmount = Double.parseDouble(verifyResponse.getPaymentSchedules().stream().filter(each -> each.getPayPlanCode().equals("B1")).findAny().get().getFullTermPremium());
        return fullTermPremiumAmount;
    }

    // F91172 - FFQ Payment Screen Enhancement for Fees and Surcharges - KY state changes
    public double getTaxAmountHRC(VerifyResponse verifyResponse, String paymentPlanDescription){
        return Double.parseDouble(verifyResponse.getPaymentSchedules().stream().filter(each -> each.getPayPlanDescription().equals(paymentPlanDescription)).findAny().get().getStateTax());
    }

    private double getFullTermAmountMonthlyEft(VerifyResponse verifyResponse){
        double monthlyPayInstallmentAmountForEFT = Double.parseDouble(verifyResponse.getPaymentSchedules().stream().filter(each -> each.getPayPlanCode().equals("MTEF")).findAny().get().getDownPayment().getAmount().getAmount());
        return monthlyPayInstallmentAmountForEFT;
    }

    private double getPolicyFee(VerifyResponse verifyResponse){
       return Double.parseDouble(verifyResponse.getPolicyFee().getAmount());
    }

    /**
    * Validates the subtext link to coverage on the payment page.
    * This method checks if the premium amounts on the Review Quote page
    * and the Payment page are consistent. If there is a difference, it validates
    * the presence of a specific message indicating the rate change.
    **/
    private void validateLinkToCoverageSubText(FarmersSoftAssert fsa, double monthlyPremiumAmountOnReviewQuotePage, double payInFullPremiumAmountOnReviewQuotePage) {
        VerifyResponse verifyResponse = aceHRCPaymentBasePage.getVerifyResponseFromAppStoreHRC();
        double monthlyPremiumAmountOnPaymentPage = getFullTermAmountMonthlyEft(verifyResponse);
        double payInFullPremiumAmountOnPaymentPage = getFullTermAmountPayInFull(verifyResponse) + getPolicyFee(verifyResponse);

        if (monthlyPremiumAmountOnReviewQuotePage != monthlyPremiumAmountOnPaymentPage ||
                payInFullPremiumAmountOnReviewQuotePage != payInFullPremiumAmountOnPaymentPage) {
            String LINK_TO_COVERAGE_SUB_TEXT_WITH_DIFFERENCE_IN_PREMIUM = "Based on third-party information and information you provided, your rate may have changed from our initial quote. " +
                    "If you'd like, you can change your coverage options.";
            fsa.assertEquals(getTextFromElement(linkToCoverageSubText), LINK_TO_COVERAGE_SUB_TEXT_WITH_DIFFERENCE_IN_PREMIUM, "Link to coverage sub text validation when there is a difference in premium between review quote page and payment page.");
        }
    }
}
