package com.farmers.ffq.home.pages;



import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.ApplicantHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;

import org.testng.Assert;

import java.time.LocalDate;
import java.util.*;

import static com.farmers.ffq.home.pages.PropertyPage.saveApplicantFinishLater;
import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Quote Page - Home.
 *
 *
 */

public class QuotePageHome extends BasePage {

	private static final String WIND_AND_HAIL_DEDUCTIBLE_ERROR_MESSAGE = "Wind & Hail deductible cannot be less than All Peril deductible";
	private static final String MORE_THAN_FIVE_YEARS = "More than 5 years";
	private static final String THREE_FIVE_YEARS = "3-5 years";

	//Roof age
	public static final String ZERO_YEAR = "0 Year";


		private Locator topContinueButton = locator(pwId("homequote:buyBtnTopHome"));

		private Locator btmContinueButton = locator(pwId("homequote:buyBtnBtmHome"));

		private Locator emailQuoteSummaryBtn = locator(pwXPath("//*[@id='titleNew']/p[3]"));

		private Locator sendEmailButton = locator(pwCss(".startQuoteBtnGreen.BtnNew"));

		private Locator allPerilLimitsDeductiblesDropDown = locator(pwId("homequote:allPerilsDed"));

		private Locator waterLimitsDeductiblesDropDown = locator(pwId("homequote:hurricaneDed"));

		private Locator limitsDeductiblesForDwellingDropDown = locator(pwId("homequote:fsphHomeCvgContainer:0:plcyCvgMenu"));

		private Locator limitsDeductiblesForExtendedReplacementCostDropDown = locator(pwId("homequote:fsphHomeCvgContainer:1:plcyCvgMenu"));

		private Locator limitsDeductiblesForSeparateStructuresDropDown = locator(pwId("homequote:fsphHomeCvgContainer:2:plcyCvgMenu"));

		private Locator limitsDeductiblesForPersonalPropertyDropDown = locator(pwId("homequote:fsphHomeCvgContainer:3:plcyCvgMenu"));

		private Locator limitsDeductiblesForHomeContentsCoverageDropDown = locator(pwId("homequote:fsphHomeCvgContainer:4:plcyCvgMenu"));

		private Locator limitsDeductiblesForLossOfUseDropDown = locator(pwId("homequote:fsphHomeCvgContainer:5:plcyCvgMenu"));

		private Locator limitsDeductiblesForBuildingOrdinanceOrLawCoverageDropDown = locator(pwId("homequote:fsphHomeCvgContainer:6:plcyCvgMenu"));

		private Locator limitsDeductiblesForScheduledRoofPaymentsDropDown = locator(pwId("homequote:fsphHomeCvgContainer:7:plcyCvgMenu"));

		private Locator limitsDeductiblesForMetalRoofDropDown = locator(pwId("homequote:fsphHomeCvgContainer:8:plcyCvgMenu"));

		private Locator limitsDeductiblesMatchingCoverageDropDown = locator(pwId("homequote:fsphHomeCvgContainer:9:plcyCvgMenu"));

		private Locator limitsDeductiblesForMetalRoofDropDown7 = locator(pwId("homequote:fsphHomeCvgContainer:7:plcyCvgMenu"));

		private Locator limitsDeductiblesForPersonalLiabilityDropDown = locator(pwId("homequote:fsphLiability:0:liabilityMenu"));

		private Locator limitsDeductiblesForMedicalPaymentsToOthersDropDown = locator(pwId("homequote:fsphLiability:1:liabilityMenu"));

		private Locator specialLimitsOnSpecificPropertyForLimitSelectionDropDown = locator(pwId("homequote:splLmtCvgMenu"));

		private Locator printQuoteSummaryButton = locator(pwXPath("//*[@id='PrintLink']"));

		private Locator startQuoteButtonSideBar = locator(pwId("accordMain:startQuote"));

		private Locator lineOfBusinessDropDownSideBar = locator(pwId("accordMain:quoteType"));

		private Locator crossSellDropDown = locator(pwId("buypolicyHome:quoteType"));

		private Locator startQuoteButton = locator(pwName("buypolicyHome:j_id240"));

		private Locator legalDisclaimerStaticText = locator(pwId("homequote:fsphFooterOne"));

		private Locator claimForgivenesStaticText = locator(pwXPath("//span[contains(@id,'homequote:featureContentThree2')]"));

		private Locator claimFreeDiscountStaticText = locator(pwXPath("//span[contains(@id,'homequote:featureContentTwo2')]"));

		private Locator premiumAmountOnBottom = locator(pwId("OabPriceBtmHome"));

		private Locator premiumAmountOnTop = locator(pwId("OabPriceTopHome"));

		private Locator personalLiabilityCoverageTextBottom = locator(pwId("homequote:personalLiabilityBtm"));

		private Locator personalLiabilityCoverageTextTop = locator(pwId("homequote:personalLiabilityTop"));

		private Locator decliningDeductibleStaticText = locator(pwId("homequote:featureContent2"));

		private Locator limitsDeductiblesForWindAndHail = locator(pwId("homequote:windAndHailDed"));

		private Locator recalculateButton = locator(pwId("homequote:recalculateBtnTopHome"));

		private Locator updateQuoteButton = locator(pwId("HomeUpdateBtn"));

		private Locator thanksYouLable = locator(pwXPath("//*[@id='HomeUpdaterr']/div[1]/h2"));

		private Locator saveFinishLaterBtn = locator(pwId("summaryBacktoQuoteCondo"));

		private Locator visitFcomBtn = locator(pwXPath("//*[@id='contButtonCA']/a"));

		private Locator insuredPropertyAddress = locator(pwXPath("//div[@id='commonCss' and @class='propertySection']"));

		private Locator discounts = locator(pwXPath("//div[@class='discountSection']//li"));

		private Locator premiumAmount = locator(pwId("OabPriceTopHome"));

		private Locator packageName = locator(pwId("homequote:PackageTypeTopHome"));

		private Locator propertyTabBtn = locator(pwXPath("//*[@id='homequote:progress:1:fsphhomequote']/span[2]"));

		private Locator coverageTabBtn = locator(pwXPath("//*[@id='homequote:progress:2:fsphhomequote']/span[2]"));

		private Locator windAndHailDedErrorMessage = locator(pwId("windAndHailDedError"));

		private Locator resetLinkTopBtn = locator(pwId("homequote:resetLinkTop"));

		private Locator yourInfoNavBarText = locator(pwXPath("//*[@id='homequote:progress:0:fsphhomequote']/span[2]"));

		private Locator propertyNavBarText = locator(pwXPath("//*[@id='homequote:progress:1:fsphhomequote']/span[2]"));

		private Locator coverageNavBarText = locator(pwXPath("//*[@id='homequote:progress:2:fsphhomequote']/span[2]"));

		private Locator quoteNavBarText = locator(pwXPath("//*[@id='homequote:progress:3:fsphhomequote']/span[2]"));

		private Locator blueNavBar = locator(pwId("pbMenuPlaceHolder"));

		private Locator farmersHeaderLogo = locator(pwId("HeaderLogo"));

		private Locator reviewYourHeaderStaticText = locator(pwXPath("//*[@id='HomeIntro']/p"));

		private Locator briefSummaryStaticText = locator(pwXPath("//*[@id='homequote:fsphFooterOne']/p/i"));

		private Locator briefSummaryStaticText2 = locator(pwXPath("//*[@id='homequote:fsphFooterTwo']/p/i"));

		private Locator footerDisclaimerStaticText = locator(pwXPath("//*[@id='mainSection']/div[5]/p[1]"));

		private Locator footerDisclaimerStaticText2 = locator(pwXPath("//*[@id='mainSection']/div[5]/p[2]"));

		private Locator digiCertImage = locator(pwXPath("//*[@id='VeriSign']/img"));

		private Locator footerPrivacyPolicyLink = locator(pwXPath("//*[@id='footUl']/li[1]/a"));

		private Locator footerTermsOfUseLink = locator(pwXPath("//*[@id='footUl']/li[2]/a"));

		private Locator footerContactUsLink = locator(pwXPath("//*[@id='footUl']/li[3]/a"));

		private Locator footerNoticeOfInformationLink = locator(pwXPath("//*[@id='footUl']/li[4]/a"));

		private Locator emailQuoteSummaryPopUp = locator(pwId("RegisterMyFarmers"));

		private Locator closewindowInsidePopUp = locator(pwId("closewindow"));

		private Locator sendEmailBtn = locator(pwXPath("//*[@id='showButtons']/div/input"));

		private Locator emailTextFieldInsidePopUp = locator(pwXPath("//*[@id='changeEmail:email']"));

		private Locator titleTextInsidePopUp = locator(pwXPath("//*[@id='ModalHdr']/h2"));

		private Locator windAndHailDedErrorMsg = locator(pwId("windAndHailDedError"));

		private Locator defaultCoverageErrorMsg = locator(pwXPath("//div[@id='23000']/p[contains(text(), 'The Premier package default coverage limits are the minimum requirement for Guaranteed Replacement Cost.')]"));

	private int oldestAgeForDiscount;
	private String roofAgeRange;
	private String state;
	private static final String ZERO_TO_SIX_PATTERN = "[0-6]\\s[A-Z][a-z]{3}s?"; //RegEx pattern : 0-6 Year(s)
	private static final String PACKAGE_MSG = " package";
	private static final String NAV_BAR_NO_MATCH_MSG = "Navigation bar item doesn't match ";
	private static final String POPUP_CONTAINS = "Pop up text contains ";
	private static final String DISCOUNT_MSG = " discount";
	private static final String CLAIM_FREE_DISCOUNT_MSG = "Claim Free Discount should be considered if you have ";
	private static final String _1000 = "$1000";
	private static final String _1K = "$1,000";
	private static final String _1250 = "$1250";
	private static final String _1500 = "$1500";
	private static final String _2000 = "$2000";
	private static final String _2K = "$2,000";
	private static final String _2500 = "$2500";
	private static final String _3000 = "$3000";
	private static final String _5000 = "$5000";
	private static final String _5K = "$5,000";
	private static final String _7500 = "$7500";
	private static final String _10000 = "$10000";
	private static final String _10K = "$10,000";
	private static final String _30K = "$30,000";
	private static final String _100K = "$100,000";
	private static final String _300K = "$300,000";
	private static final String _500K = "$500,000";
	private static final String _1M = "$1,000,000";
	private static final String _2M = "$2,000,000";

	private static final String HALF_PCT = "0.5%";
	private static final String ONE_ZERO_PCT = "1.0%";
	private static final String ONE_HALF_PCT = "1.5%";
	private static final String TWO_ZERO_PCT = "2.0%";
	private static final String THREE_ZERO_PCT = "3.0%";
	private static final String FIVE_ZERO_PCT = "5.0%";
	private static final String FIVE_PCT = "5%";
	private static final String TEN_PCT = "10%";
	private static final String FIFTEEN_PCT = "15%";
	private static final String TWENTY_PCT = "20%";
	private static final String TWENTY_FIVE_PCT = "25%";
	private static final String THIRTY_PCT = "30%";
	private static final String THIRTY_FIVE_PCT = "35%";
	private static final String FORTY_PCT = "40%";
	private static final String FORTY_FIVE_PCT = "45%";
	private static final String FIFTY_PCT = "50%";
	private static final String FIFTY_FIVE_PCT = "55%";
	private static final String SIXTY_PCT = "60%";
	private static final String SIXTY_FIVE_PCT = "65%";
	private static final String SEVENTY_PCT = "70%";
	private static final String SEVENTY_FIVE_PCT = "75%";
	private static final String EIGHTY_PCT = "80%";
	private static final String EIGHTY_FIVE_PCT = "85%";
	private static final String NINETY_PCT = "90%";
	private static final String NINETY_FIVE_PCT = "95%";
	private static final String ONE_HUNDRED_PCT = "100%";
	private static final String ONE_HUNDRED_FIVE_PCT = "105%";
	private static final String ONE_HUNDRED_TEN_PCT = "110%";
	private static final String ONE_HUNDRED_FIFTEEN_PCT = "115%";
	private static final String ONE_HUNDRED_TWENTY_PCT = "120%";
	private static final String ONE_HUNDRED_TWENTY_FIVE_PCT = "125%";
	private static final String ONE_HUNDRED_THIRTY_PCT = "130%";
	private static final String ONE_HUNDRED_THIRTY_FIVE_PCT = "135%";
	private static final String ONE_HUNDRED_FORTY_PCT = "140%";
	private static final String ONE_HUNDRED_FORTY_FIVE_PCT = "145%";
	private static final String ONE_HUNDRED_FIFTY_PCT = "150%";
	private static final String ONE_HUNDRED_FIFTY_FIVE_PCT = "155%";
	private static final String ONE_HUNDRED_SIXTY_PCT = "160%";
	private static final String ONE_HUNDRED_SIXTY_FIVE_PCT = "165%";
	private static final String ONE_HUNDRED_SEVENTY_PCT = "170%";
	private static final String ONE_HUNDRED_SEVENTY_FIVE_PCT = "175%";
	private static final String ONE_HUNDRED_EIGHTY_PCT = "180%";
	private static final String ONE_HUNDRED_EIGHTY_FIVE_PCT = "185%";
	private static final String ONE_HUNDRED_NINETY_PCT = "190%";
	private static final String ONE_HUNDRED_NINETY_FIVE_PCT = "195%";
	private static final String TWO_HUNDRED_PCT = "200%";
	private static final String _1500_WIND_AND_HAIL = "$1500 -Wind and Hail";
	private static final String _2500_WIND_AND_HAIL = "$2500 -Wind and Hail";
	private static final String ONE_PCT_WIND_AND_HAIL = "1.0% -Wind and Hail";
	private static final String TWO_PCT_WIND_AND_HAIL = "2.0% -Wind and Hail";
	private static final String THREE_PCT_WIND_AND_HAIL = "3.0% -Wind and Hail";
	private static final String FIVE_PCT_WIND_AND_HAIL = "5.0% -Wind and Hail";
	private static final String TEN_PCT_12_MON = "10%/12 months";
	private static final String TWENTY_PCT_12_MON = "20%/12 months";
	private static final String THIRTY_PCT_24_MON = "30%/24 months";
	private static final String SCHEDULED_PAYMENTS = "Scheduled Payments";
	private static final String REPLACEMENT_COST_VALUE = "Replacement Cost Value";
	private static final String STANDARD_LIMITS = "Standard Special Limits";
	private static final String ENHANCED_LIMITS = "Enhanced Special Limits";
	private static final String PREMIER_LIMITS = "Premier Special Limits";
	private static final String GUARANTEED_REPLACEMENT_COST ="Guaranteed Replacement Cost";

	// Cross sell entries
	private static final String CROSS_SELL_ENTRIES = "//div[@id='crossSellDiv']/div[@class='crossSellImagesMainDivAllign']/ul/";
	private static final String AUTO_CROSS_SELL_XPATH = "li[@id='RTAuto_en']";
	private static final String VTL_CROSS_SELL_XPATH = "li[@title='Life']";
	private static final String GBW_CROSS_SELL_XPATH = "li[@title='Graded Benefit Whole Life']";
	private static final String STL_CROSS_SELL_XPATH = "li[@title='Simple Term Life']";

		private Locator autoCrossSellQuote = locator(pwXPath(CROSS_SELL_ENTRIES + AUTO_CROSS_SELL_XPATH));
		private Locator vtlCrossSellQuote = locator(pwXPath(CROSS_SELL_ENTRIES + VTL_CROSS_SELL_XPATH));
		private Locator gbwlCrossSellQuote = locator(pwXPath(CROSS_SELL_ENTRIES + GBW_CROSS_SELL_XPATH));
		private Locator stlCrossSellQuote = locator(pwXPath(CROSS_SELL_ENTRIES + STL_CROSS_SELL_XPATH));

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public QuotePageHome(ApplicantHome applicant) throws Exception {
		super();

		state = applicant.getState();
		int maxYearBuildHomeForDiscount;

		switch (state){
		case GEORGIA:
		case NEW_JERSEY:
		case NEW_YORK:
		case WYOMING:
			maxYearBuildHomeForDiscount = 13;
			roofAgeRange = ZERO_TO_SIX_PATTERN;
			break;
		default: throw new IllegalArgumentException("Wrong state name: " + state);
		}
		oldestAgeForDiscount = LocalDate.now().minusYears(maxYearBuildHomeForDiscount).getYear();
	}


	/**
	 * Click Continue button.
	 */
	public void clickContinueButton() {
		Log.info("Clicking Continue button");
		clickElement(topContinueButton);
	}

	/**
	 * Click Recalculate button.
	 */
	private void clickRecalculateButton() {
		Log.info("Clicking Recalculate button");
		clickElement(recalculateButton);
		waitForRecalculationPopupToBeGone();
	}

	private void clickResetLinkTopButton() {
		Log.info("Clicking reset button");
		clickElement(resetLinkTopBtn);
	}

	/**
	 * Click Email Quote Summary button.
	 */
	private void clickEmailQuoteSummaryButton() {
		Log.info("Clicking Email Quote Summary button");
		clickElement(emailQuoteSummaryBtn);
		waitElementBeVisible(sendEmailButton);
		clickElement(sendEmailButton);
	}

	/**
	 * Select Limits/Deductibles for All Peril.
	 *
	 * @param limit
	 */
	public void selectAllPerilLimitsDeductibles(String limit) {
		Log.info("Selecting Limits/Deductibles for All Peril " + limit);
		waitElementBeVisible(allPerilLimitsDeductiblesDropDown);
		selectFromDropDownByValue(allPerilLimitsDeductiblesDropDown, limit);
	}

	/**
	 * Select Limits/Deductibles for All Peril.
	 *
	 * @param limit
	 */
	public void selectWindAndHailDeductibles(String limit) {
		Log.info("Selecting Limits/Deductibles for Wind And Hail " + limit);
		waitElementBeVisible(limitsDeductiblesForWindAndHail);
		selectFromDropDownByValue(limitsDeductiblesForWindAndHail, limit);
	}

	/**
	 * Select Limits/Deductibles for Water.
	 *
	 * @param limit
	 */
	public void selectWaterLimitsDeductibles(String limit) {
		Log.info("Selecting Limits/Deductibles for Water " + limit);
		selectFromDropDown(waterLimitsDeductiblesDropDown, limit);
	}

	/**
	 * Select Property Coverage Limits/Deductibles For Dwelling.
	 *
	 * @param limit
	 */
	public void selectPropertyCoverageLimitsDeductiblesForDwelling(String limit) {
		Log.info("Selecting Property Coverage Limits/Deductibles For Dwelling " + limit);
		selectFromDropDownByValue(limitsDeductiblesForDwellingDropDown, limit);
	}

	/**
	 * Select Property Coverage Limits/Deductibles For Extended Replacement Cost.
	 *
	 * @param limit
	 */
	public void selectPropertyCoverageLimitsDeductiblesForExtendedReplacementCost(String limit) {
		Log.info("Selecting Property Coverage Limits/Deductibles For Extended Replacement Cost " + limit);
		selectFromDropDownByValue(limitsDeductiblesForExtendedReplacementCostDropDown, limit);
	}

	/**
	 * Select Property Coverage Limits/Deductibles For Separate Structures.
	 *
	 * @param limit
	 */
	public void selectPropertyCoverageLimitsDeductiblesForSeparateStructures(String limit) {
		Log.info("Selecting Property Coverage Limits/Deductibles For Separate Structures " + limit);
		selectFromDropDown(limitsDeductiblesForSeparateStructuresDropDown, limit);
	}

	/**
	 * Select Property Coverage Limits/Deductibles For Personal Property.
	 *
	 * @param limit
	 */
	public void selectPropertyCoverageLimitsDeductiblesForPersonalProperty(String limit) {
		Log.info("Selecting Property Coverage Limits/Deductibles For Personal Property " + limit);
		selectFromDropDownByValue(limitsDeductiblesForPersonalPropertyDropDown, limit);
	}

	/**
	 * Select Property Coverage Limits/Deductibles For Home Contents Coverage.
	 *
	 * @param limit
	 */
	public void selectPropertyCoverageLimitsDeductiblesForHomeContentsCoverage(String limit) {
		Log.info("Selecting Property Coverage Limits/Deductibles For Home Contents Coverage " + limit);
		selectFromDropDown(limitsDeductiblesForHomeContentsCoverageDropDown, limit);
	}

	/**
	 * Select Property Coverage Limits/Deductibles For Loss of Use.
	 *
	 * @param limit
	 */
	public void selectPropertyCoverageLimitsDeductiblesForLossOfUse(String limit) {
		Log.info("Selecting Property Coverage Limits/Deductibles For Loss of Use " + limit);
		selectFromDropDownByValue(limitsDeductiblesForLossOfUseDropDown, limit);
	}

	/**
	 * Select Property Coverage Limits/Deductibles For Building Ordinance or Law Coverage.
	 *
	 * @param limit
	 */
	public void selectPropertyCoverageLimitsDeductiblesForBuildingOrdinanceOrLawCoverage(String limit) {
		Log.info("Selecting Property Coverage Limits/Deductibles For Building Ordinance or Law Coverage " + limit);
		selectFromDropDown(limitsDeductiblesForBuildingOrdinanceOrLawCoverageDropDown, limit);
	}

	/**
	 * Select Property Coverage Limits/Deductibles For Scheduled Roof Payments.
	 *
	 * @param limit
	 */
	public void selectPropertyCoverageLimitsDeductiblesForScheduledRoofPayments(String limit) {
		Log.info("Selecting Property Coverage Limits/Deductibles For Scheduled Roof Payments " + limit);
		selectFromDropDown(limitsDeductiblesForScheduledRoofPaymentsDropDown, limit);
	}

	/**
	 * Select Property Coverage Limits/Deductibles For Cosmetic Wind/Hail Damage to Metal Roof.
	 *
	 * @param limit
	 */
	public void selectPropertyCoverageLimitsDeductiblesForMetalRoof(String limit) {
		Log.info("Selecting Property Coverage Limits/Deductibles For Cosmetic Wind/Hail Damage to Metal Roof " + limit);
		selectFromDropDown(limitsDeductiblesForMetalRoofDropDown, limit);
	}

	public void selectPropertyCoverageLimitsDeductiblesMatchingCoverage(String limit) {
		Log.info("Selecting Property Coverage Limits/Deductibles For Matching Coverage " + limit);
		selectFromDropDown(limitsDeductiblesMatchingCoverageDropDown, limit);
	}

	/**
	 * Select Liability Limits/Deductibles For Personal Liability.
	 *
	 * @param limit
	 */
	public void selectLiabilityLimitsDeductiblesForPersonalLiability(String limit) {
		Log.info("Selecting Liability Limits/Deductibles For Personal Liability " + limit);
		waitElementBeVisible(limitsDeductiblesForPersonalLiabilityDropDown);
		selectFromDropDownByValue(limitsDeductiblesForPersonalLiabilityDropDown, limit);
	}

	/**
	 * Select Liability Limits/Deductibles For Medical Payments to Others.
	 *
	 * @param limit
	 */
	public void selectLiabilityLimitsDeductiblesForMedicalPaymentsToOthers(String limit) {
		Log.info("Selecting Liability Limits/Deductibles For Medical Payments to Others " + limit);
		selectFromDropDown(limitsDeductiblesForMedicalPaymentsToOthersDropDown, limit);
	}

	/**
	 * Select Special Limits On Specific Property For Limit Selection.
	 *
	 * @param limit
	 */
	public void selectSpecialLimitsOnSpecificPropertyForLimitSelection(String limit) {
		Log.info("Selecting Special Limits On Specific Property For Limit Selection " + limit);
		selectFromDropDown(specialLimitsOnSpecificPropertyForLimitSelectionDropDown, limit);
	}

	/**
	 * Click Print Quote Summary Button.
	 */
	public void clickPrintQuoteSummaryButton() {
		Log.info("Clicking Print Quote Summary Button");
		clickElement(printQuoteSummaryButton);
	}

	/**
	 * Click Start Quote Button in Side Bar.
	 */
	public void clickStartQuoteButtonSideBar() {
		Log.info("Clicking Start Quote Button in Side Bar");
		clickElement(startQuoteButtonSideBar);
	}

	/**
	 * Select Line Of Business From Drop Down in Side Bar.
	 *
	 * @param lob
	 */
	public void selectLineOfBusinessFromDropDownInSideBar(String lob) {
		Log.info("Selecting Line Of Business in Side Bar " + lob);
		selectFromDropDown(lineOfBusinessDropDownSideBar, lob);
	}

	private void verifyDefaultDropDownValues(List<Locator> dropDowns, Map<Locator, String> expValues, String selectedPackage, FarmersSoftAssert fsa) {
		for (Locator dropDown : dropDowns) {
			String firstOptions = getTextFromElement(select(dropDown).getFirstSelectedOption());
			String expValue = expValues.get(dropDown);
			fsa.assertEquals(firstOptions.trim(), expValue.trim(), dropDown + SPACE + selectedPackage + PACKAGE_MSG + " default value ");
		}
	}

	private List<Locator> getListWithQuotePageDropDownsElements(ApplicantHome applicant) {
		Log.info("Getting List with Discounts Page Drop Downs Elements");
		List<Locator> list = new ArrayList<>();
		list.add(allPerilLimitsDeductiblesDropDown);
		if (!applicant.getYourPackage().equals(PREMIER) && applicant.getState().equals(CALIFORNIA)) {
			list.add(waterLimitsDeductiblesDropDown);
		}
		list.add(limitsDeductiblesForWindAndHail);
		list.add(limitsDeductiblesForDwellingDropDown);
		list.add(limitsDeductiblesForExtendedReplacementCostDropDown);
		list.add(limitsDeductiblesForSeparateStructuresDropDown);
		list.add(limitsDeductiblesForPersonalPropertyDropDown);
		list.add(limitsDeductiblesForHomeContentsCoverageDropDown);
		list.add(limitsDeductiblesForLossOfUseDropDown);
		list.add(limitsDeductiblesForBuildingOrdinanceOrLawCoverageDropDown);
		list.add(limitsDeductiblesForScheduledRoofPaymentsDropDown);
		list.add(limitsDeductiblesMatchingCoverageDropDown);
		list.add(limitsDeductiblesForPersonalLiabilityDropDown);
		list.add(limitsDeductiblesForMedicalPaymentsToOthersDropDown);
		list.add(specialLimitsOnSpecificPropertyForLimitSelectionDropDown);
		return list;
	}

	private Map<Locator, String> getMapWithDropDownsDefaultValues(ApplicantHome applicant) throws IllegalArgumentException {
		String packageSelected = applicant.getYourPackage();
		Log.info("Returning map for package: " + packageSelected);
		switch (packageSelected) {
		case STANDARD:
			Map<Locator, String> standardMap = new HashMap<>();
			standardMap.put(allPerilLimitsDeductiblesDropDown, ONE_ZERO_PCT);
			if (applicant.getState().equals(CALIFORNIA)) {
				standardMap.put(waterLimitsDeductiblesDropDown, _1000);
			}
			standardMap.put(limitsDeductiblesForWindAndHail, _1500_WIND_AND_HAIL);
			standardMap.put(limitsDeductiblesForDwellingDropDown, ONE_HUNDRED_PCT);
			standardMap.put(limitsDeductiblesForExtendedReplacementCostDropDown, NONE);
			standardMap.put(limitsDeductiblesForSeparateStructuresDropDown, FIVE_PCT);
			standardMap.put(limitsDeductiblesForPersonalPropertyDropDown, FORTY_PCT);
			standardMap.put(limitsDeductiblesForHomeContentsCoverageDropDown, NO);
			standardMap.put(limitsDeductiblesForLossOfUseDropDown, TEN_PCT_12_MON);
			standardMap.put(limitsDeductiblesForBuildingOrdinanceOrLawCoverageDropDown, NONE);
			standardMap.put(limitsDeductiblesForScheduledRoofPaymentsDropDown, SCHEDULED_PAYMENTS);
			standardMap.put(limitsDeductiblesMatchingCoverageDropDown, NONE);
			standardMap.put(limitsDeductiblesForPersonalLiabilityDropDown, _300K);
			standardMap.put(limitsDeductiblesForMedicalPaymentsToOthersDropDown, _1K);
			standardMap.put(specialLimitsOnSpecificPropertyForLimitSelectionDropDown, STANDARD_LIMITS);
			return standardMap;
		case ENHANCED:
			Map<Locator, String> enhancedMap = new HashMap<>();
			enhancedMap.put(allPerilLimitsDeductiblesDropDown, ONE_ZERO_PCT);
			if (applicant.getState().equals(CALIFORNIA)) {
				enhancedMap.put(waterLimitsDeductiblesDropDown, _1000);
			}
			enhancedMap.put(limitsDeductiblesForWindAndHail, _1500_WIND_AND_HAIL);
			enhancedMap.put(limitsDeductiblesForDwellingDropDown, ONE_HUNDRED_PCT);
			enhancedMap.put(limitsDeductiblesForExtendedReplacementCostDropDown, TEN_PCT);
			enhancedMap.put(limitsDeductiblesForSeparateStructuresDropDown, TEN_PCT);
			enhancedMap.put(limitsDeductiblesForPersonalPropertyDropDown, FIFTY_FIVE_PCT);
			enhancedMap.put(limitsDeductiblesForHomeContentsCoverageDropDown, YES);
			enhancedMap.put(limitsDeductiblesForLossOfUseDropDown, TWENTY_PCT_12_MON);
			enhancedMap.put(limitsDeductiblesForBuildingOrdinanceOrLawCoverageDropDown, TEN_PCT);
			enhancedMap.put(limitsDeductiblesForScheduledRoofPaymentsDropDown, REPLACEMENT_COST_VALUE);
			enhancedMap.put(limitsDeductiblesMatchingCoverageDropDown, _10K);
			enhancedMap.put(limitsDeductiblesForPersonalLiabilityDropDown, _300K);
			enhancedMap.put(limitsDeductiblesForMedicalPaymentsToOthersDropDown, _1K);
			enhancedMap.put(specialLimitsOnSpecificPropertyForLimitSelectionDropDown, ENHANCED_LIMITS);
			return enhancedMap;
		case PREMIER:
			Map<Locator, String> premierMap = new HashMap<>();
			premierMap.put(allPerilLimitsDeductiblesDropDown, ONE_ZERO_PCT);
			premierMap.put(limitsDeductiblesForWindAndHail, _1500_WIND_AND_HAIL);
			premierMap.put(limitsDeductiblesForDwellingDropDown, ONE_HUNDRED_PCT);
			premierMap.put(limitsDeductiblesForExtendedReplacementCostDropDown, NONE);
			premierMap.put(limitsDeductiblesForSeparateStructuresDropDown, TEN_PCT);
			premierMap.put(limitsDeductiblesForPersonalPropertyDropDown, SEVENTY_FIVE_PCT);
			premierMap.put(limitsDeductiblesForHomeContentsCoverageDropDown, YES);
			premierMap.put(limitsDeductiblesForLossOfUseDropDown, THIRTY_PCT_24_MON);
			premierMap.put(limitsDeductiblesForBuildingOrdinanceOrLawCoverageDropDown, TEN_PCT);
			premierMap.put(limitsDeductiblesForScheduledRoofPaymentsDropDown, REPLACEMENT_COST_VALUE);
			premierMap.put(limitsDeductiblesMatchingCoverageDropDown, _30K);
			premierMap.put(limitsDeductiblesForPersonalLiabilityDropDown, _300K);
			premierMap.put(limitsDeductiblesForMedicalPaymentsToOthersDropDown, _1K);
			premierMap.put(specialLimitsOnSpecificPropertyForLimitSelectionDropDown, PREMIER_LIMITS);
			return premierMap;
		default:
			throw new IllegalArgumentException("Package " + packageSelected + " doesn't exist");
		}
	}

	private void verifyLegalDisclaimerStaticText(FarmersSoftAssert fsa) {
		fsa.assertEquals(getTextFromElement(legalDisclaimerStaticText), "1This brief summary is not a policy document. Please read the actual policy documents for your state for important details on coverages, exclusions ," +
				" limits, conditions, and terms. If there is any conflict between this summary and the policy documents, the policy doucments will control. Not all products, coverages and discounts are available in every state.",
				"Legal Disclaimer static text doesn't match");
	}

	private void verifyDecliningDeductibleStaticText(FarmersSoftAssert fsa) {
		fsa.assertEquals(getTextFromElement(decliningDeductibleStaticText), "Earn $50 toward your deductible each year.", "decliningDeductibleStaticText match");
	}

	private void verifyClaimForgivenessStaticText(FarmersSoftAssert fsa) {
		fsa.assertEquals(getTextFromElement(claimForgivenesStaticText), "If you've been claim free with Farmers for five years2, this benefit prevents your premium from increasing as a result of your next claim."
				, "Claim Forgiveness static text match");
	}

	private void verifyClaimFreeDiscountStaticText(FarmersSoftAssert fsa) {
		fsa.assertEquals(getTextFromElement(claimFreeDiscountStaticText), "Receive a 10% discount if you've been claim free with Farmers (or your previous insurance company) for three consecutive years.",
				"Claim Free Discount Static Text match");
	}

	private void verifyTopContinueButton(FarmersSoftAssert fsa) {
		fsa.assertTrue(topContinueButton.isVisible() && topContinueButton.isEnabled(),"Top Continue button displayed");
	}

	private void verifyBottomContinueButton(FarmersSoftAssert fsa) {
		fsa.assertTrue(btmContinueButton.isVisible() && btmContinueButton.isEnabled(),"Bottom Continue button displayed");
	}

	private void verifyEmailQuoteSummaryButton(FarmersSoftAssert fsa) {
		fsa.assertTrue(emailQuoteSummaryBtn.isVisible() && emailQuoteSummaryBtn.isEnabled(),"Email Quote Summary button displayed");
		clickElement(emailQuoteSummaryBtn);
		waitElementBeVisible(emailQuoteSummaryPopUp);
		fsa.assertTrue(sendEmailBtn.isVisible() && sendEmailBtn.isEnabled(), "Send email button displayed");
		fsa.assertTrue(getTextFromElement(titleTextInsidePopUp).contains("Email Quote Summary To:"), "Title text inside pop match");
		sendKeysToElement(emailTextFieldInsidePopUp, "test@test.com");
		fsa.assertTrue(getAttributeData(emailTextFieldInsidePopUp, VALUE).contains("test@test.com"), "Email text field text match ");
		clickElement(closewindowInsidePopUp);
	}

	private void verifyPrintQuoteSummaryButton(FarmersSoftAssert fsa) throws Exception {
		fsa.assertTrue(printQuoteSummaryButton.isVisible() && printQuoteSummaryButton.isEnabled(),"Print Quote Summary button displayed");
		Page baseWindow = switchToNewWindow(printQuoteSummaryButton);
		new PrintQuotePageHome().verifyPrintQuotePage();
		switchBackToBaseWindow(baseWindow);
	}

	private Map<Locator,List<String>> getMapWithQuotePageDropDownsValues(ApplicantHome applicant) {
		Log.info("Getting Map with drop downs values");
		Map<Locator, List<String>> dropDownValues = new LinkedHashMap<>();
		dropDownValues.put(allPerilLimitsDeductiblesDropDown,new ArrayList<>(Arrays.asList(_1000, _1500, _2500, _5000, _7500, _10000, HALF_PCT, ONE_ZERO_PCT, ONE_HALF_PCT, TWO_ZERO_PCT, THREE_ZERO_PCT, FIVE_ZERO_PCT)));
		if (!applicant.getYourPackage().equals(PREMIER) && applicant.getState().equals(CALIFORNIA)) {
			dropDownValues.put(waterLimitsDeductiblesDropDown, new ArrayList<>(Arrays.asList(_1000, _1250, _1500, _2000, _2500, _3000, _5000, _7500, _10000, HALF_PCT, ONE_ZERO_PCT, ONE_HALF_PCT, TWO_ZERO_PCT, THREE_ZERO_PCT, FIVE_ZERO_PCT)));
		}
		dropDownValues.put(limitsDeductiblesForWindAndHail,new ArrayList<>(Arrays.asList("Please Select", _1500_WIND_AND_HAIL, _2500_WIND_AND_HAIL, ONE_PCT_WIND_AND_HAIL, TWO_PCT_WIND_AND_HAIL, THREE_PCT_WIND_AND_HAIL, FIVE_PCT_WIND_AND_HAIL)));
		dropDownValues.put(limitsDeductiblesForDwellingDropDown,new ArrayList<>(Arrays.asList(EIGHTY_PCT, EIGHTY_FIVE_PCT, NINETY_PCT, NINETY_FIVE_PCT, ONE_HUNDRED_PCT)));
		dropDownValues.put(limitsDeductiblesForExtendedReplacementCostDropDown,new ArrayList<>(Arrays.asList(NONE, TEN_PCT, TWENTY_FIVE_PCT, FIFTY_PCT)));
		dropDownValues.put(limitsDeductiblesForSeparateStructuresDropDown,new ArrayList<>(Arrays.asList(FIVE_PCT, TEN_PCT, FIFTEEN_PCT, TWENTY_PCT, TWENTY_FIVE_PCT, THIRTY_PCT, THIRTY_FIVE_PCT, FORTY_PCT, FORTY_FIVE_PCT, FIFTY_PCT, FIFTY_FIVE_PCT,
				SIXTY_PCT, SIXTY_FIVE_PCT, SEVENTY_PCT, SEVENTY_FIVE_PCT, EIGHTY_PCT, EIGHTY_FIVE_PCT, NINETY_PCT, NINETY_FIVE_PCT, ONE_HUNDRED_PCT, ONE_HUNDRED_FIVE_PCT, ONE_HUNDRED_TEN_PCT, ONE_HUNDRED_FIFTEEN_PCT, ONE_HUNDRED_TWENTY_PCT,
				ONE_HUNDRED_TWENTY_FIVE_PCT, ONE_HUNDRED_THIRTY_PCT, ONE_HUNDRED_THIRTY_FIVE_PCT, ONE_HUNDRED_FORTY_PCT, ONE_HUNDRED_FORTY_FIVE_PCT, ONE_HUNDRED_FIFTY_PCT, ONE_HUNDRED_FIFTY_FIVE_PCT, ONE_HUNDRED_SIXTY_PCT, ONE_HUNDRED_SIXTY_FIVE_PCT,
				ONE_HUNDRED_SEVENTY_PCT, ONE_HUNDRED_SEVENTY_FIVE_PCT, ONE_HUNDRED_EIGHTY_PCT, ONE_HUNDRED_EIGHTY_FIVE_PCT, ONE_HUNDRED_NINETY_PCT, ONE_HUNDRED_NINETY_FIVE_PCT, TWO_HUNDRED_PCT)));
		dropDownValues.put(limitsDeductiblesForPersonalPropertyDropDown,new ArrayList<>(Arrays.asList(FORTY_PCT, FIFTY_FIVE_PCT, SEVENTY_FIVE_PCT, EIGHTY_PCT, EIGHTY_FIVE_PCT, NINETY_PCT, NINETY_FIVE_PCT, ONE_HUNDRED_PCT, ONE_HUNDRED_FIVE_PCT,
				ONE_HUNDRED_TEN_PCT, ONE_HUNDRED_FIFTEEN_PCT, ONE_HUNDRED_TWENTY_PCT, ONE_HUNDRED_TWENTY_FIVE_PCT, ONE_HUNDRED_THIRTY_PCT, ONE_HUNDRED_THIRTY_FIVE_PCT, ONE_HUNDRED_FORTY_PCT, ONE_HUNDRED_FORTY_FIVE_PCT, ONE_HUNDRED_FIFTY_PCT,
				ONE_HUNDRED_FIFTY_FIVE_PCT, ONE_HUNDRED_SIXTY_PCT, ONE_HUNDRED_SIXTY_FIVE_PCT, ONE_HUNDRED_SEVENTY_PCT, ONE_HUNDRED_SEVENTY_FIVE_PCT, ONE_HUNDRED_EIGHTY_PCT, ONE_HUNDRED_EIGHTY_FIVE_PCT, ONE_HUNDRED_NINETY_PCT,
				ONE_HUNDRED_NINETY_FIVE_PCT, TWO_HUNDRED_PCT)));
		dropDownValues.put(limitsDeductiblesForHomeContentsCoverageDropDown,new ArrayList<>(Arrays.asList(NO, YES)));
		dropDownValues.put(limitsDeductiblesForLossOfUseDropDown,new ArrayList<>(Arrays.asList(TEN_PCT_12_MON, TWENTY_PCT_12_MON, THIRTY_PCT_24_MON)));
		dropDownValues.put(limitsDeductiblesForBuildingOrdinanceOrLawCoverageDropDown,new ArrayList<>(Arrays.asList(NONE, TEN_PCT, TWENTY_FIVE_PCT, FIFTY_PCT)));
		dropDownValues.put(limitsDeductiblesForScheduledRoofPaymentsDropDown, new ArrayList<>(Arrays.asList(REPLACEMENT_COST_VALUE, SCHEDULED_PAYMENTS)));
		dropDownValues.put(limitsDeductiblesMatchingCoverageDropDown, new ArrayList<>(Arrays.asList(NONE, _10K, _30K)));
		dropDownValues.put(limitsDeductiblesForPersonalLiabilityDropDown,new ArrayList<>(Arrays.asList(_100K, _300K, _500K, _1M, _2M)));
		dropDownValues.put(limitsDeductiblesForMedicalPaymentsToOthersDropDown,new ArrayList<>(Arrays.asList(_1K, _2K, _5K)));
		dropDownValues.put(specialLimitsOnSpecificPropertyForLimitSelectionDropDown,new ArrayList<>(Arrays.asList(STANDARD_LIMITS, ENHANCED_LIMITS, PREMIER_LIMITS)));
		return dropDownValues;
	}

	private void verifyPremiumAmountTopAndBottomAreEqual(ApplicantHome applicant, FarmersSoftAssert fsa) {
		String packageExpected = applicant.getYourPackage();
		String premiumAmountTop = getTextFromElement(premiumAmountOnTop);
		String premiumAmountBottom = getTextFromElement(premiumAmountOnBottom);
		fsa.assertTrue(premiumAmountTop.equals(premiumAmountBottom),"Top: [" +  premiumAmountTop + "] and bottom: [" + premiumAmountBottom + "] premium amounts equal");
		if (!applicant.isBackNavFlow()) {
			fsa.assertEquals(getTextFromElement(packageName), applicant.isCustomRateScenario() ? "Custom " + packageExpected : packageExpected, "Package name match");
		}
	}

	public void quotePageValidationHome(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		waitElementBeVisible(allPerilLimitsDeductiblesDropDown);
		verifyHomeHelpLinks(getListWithHomeLOBFooterLinks(), getListWithHomeLOBFooterURLDestinationsTitle());
		closeSurveyDialog();
		List<Locator> listOfDropdowns = getListWithQuotePageDropDownsElements(applicant);
		verifyDefaultDropDownValues(listOfDropdowns, getMapWithDropDownsDefaultValues(applicant), applicant.getYourPackage(), fsa);
		closeSurveyDialog();
		verifyDropDownListValues(listOfDropdowns, getMapWithQuotePageDropDownsValues(applicant), fsa);
		closeSurveyDialog();
		verifyNavBarTitle(fsa);
		closeSurveyDialog();
		verifyEmailQuoteSummaryButton(fsa);
		closeSurveyDialog();
		verifyPrintQuoteSummaryButton(fsa);
		closeSurveyDialog();
		verifyFooterDisclaimerText(fsa);
		closeSurveyDialog();
		navigateBetweenPages(new ArrayList<>(Collections.singletonList(yourInfoNavBarText)), fsa);
		closeSurveyDialog();
		verifyClaimForgivenessStaticText(fsa);
		closeSurveyDialog();
		verifyClaimFreeDiscountStaticText(fsa);
		closeSurveyDialog();
		verifyLegalDisclaimerStaticText(fsa);
		closeSurveyDialog();
		verifyBottomContinueButton(fsa);
		closeSurveyDialog();
		verifyTopContinueButton(fsa);
		closeSurveyDialog();
		verifyPremiumAmountTopAndBottomAreEqual(applicant, fsa);
		closeSurveyDialog();
		checkAllURLsAndImages(findAllURLsAndImages());
		closeSurveyDialog();
	}

	private Map<Locator,String> getMapWithQuotePageDropDowns() {
		Map<Locator, String> map = new LinkedHashMap<>();
		map.put(limitsDeductiblesForSeparateStructuresDropDown, FIVE_PCT);
		map.put(limitsDeductiblesForPersonalPropertyDropDown, FORTY_PCT);
		map.put(limitsDeductiblesForHomeContentsCoverageDropDown, NO);
		map.put(limitsDeductiblesForLossOfUseDropDown, TEN_PCT_12_MON);
		map.put(limitsDeductiblesForBuildingOrdinanceOrLawCoverageDropDown, NONE);
		map.put(limitsDeductiblesForScheduledRoofPaymentsDropDown, SCHEDULED_PAYMENTS);
		map.put(specialLimitsOnSpecificPropertyForLimitSelectionDropDown, STANDARD_LIMITS);
		return map;
	}

	private void verifyCustomDeductiblesErrorMessages(ApplicantHome applicant, Map<Locator, String> map, FarmersSoftAssert fsa) {
		final String PREMIER_PCK_DEFAULT_COVERAGE_ERROR_MESSAGE = "The Premier package default coverage limits are the minimum requirement for Guaranteed Replacement Cost.";
		final String PREMIER_PCK_WIND_AND_HAIL_ERROR_MESSAGE = "Wind & Hail deductible cannot be less than All Peril deductible";
		if (applicant.getYourPackage().equals(PREMIER)) {
			String selectedOption = getTextFromElement(select(limitsDeductiblesForExtendedReplacementCostDropDown).getFirstSelectedOption());
			fsa.assertEquals(selectedOption, GUARANTEED_REPLACEMENT_COST, "Selected drop down value match");
			for (Map.Entry<Locator, String> entry : map.entrySet()) {
				selectFromDropDown(entry.getKey(), entry.getValue());
				clickRecalculateButton();
				fsa.assertEquals(getTextFromElement(defaultCoverageErrorMsg), PREMIER_PCK_DEFAULT_COVERAGE_ERROR_MESSAGE, "Error message match");
				clickResetLinkTopButton();
			}
			selectAllPerilLimitsDeductibles("2500");
			clickRecalculateButton();
			fsa.assertEquals(getTextFromElement(windAndHailDedErrorMsg), PREMIER_PCK_WIND_AND_HAIL_ERROR_MESSAGE, "Error message match");
			clickResetLinkTopButton();
			if (getTextFromElement(select(limitsDeductiblesForScheduledRoofPaymentsDropDown).getFirstSelectedOption()).equals(REPLACEMENT_COST_VALUE)) {
				String firstSelectedOption = getTextFromElement(select(limitsDeductiblesForExtendedReplacementCostDropDown).getFirstSelectedOption());
				fsa.assertNotEquals(firstSelectedOption, NONE, "Extended Replacement Cost first selected value match");
			}
		}
	}

	public void quotePageErrorValidationHome(ApplicantHome applicant, FarmersSoftAssert fsa) {
		verifyCustomDeductiblesErrorMessages(applicant, getMapWithQuotePageDropDowns(), fsa);
	}

	private void verifyNavBarTitle(FarmersSoftAssert fsa) {
		waitElementBeVisible(yourInfoNavBarText);
		fsa.assertEquals(getTextFromElement(yourInfoNavBarText), "YOUR INFO", NAV_BAR_NO_MATCH_MSG);
		fsa.assertEquals(getTextFromElement(propertyNavBarText), "PROPERTY", NAV_BAR_NO_MATCH_MSG);
		fsa.assertEquals(getTextFromElement(coverageNavBarText), "COVERAGE", NAV_BAR_NO_MATCH_MSG);
		fsa.assertEquals(getTextFromElement(quoteNavBarText), "QUOTE", NAV_BAR_NO_MATCH_MSG);
		fsa.assertTrue(blueNavBar.isVisible(),"Blue navigation bar displayed ");
		fsa.assertTrue(farmersHeaderLogo.isVisible(),"Header logo displayed ");
		fsa.assertTrue(digiCertImage.isVisible(),"DigiCert image logo displayed ");
		fsa.assertEquals(getTextFromElement(reviewYourHeaderStaticText), "Please review your Home policy coverage. A Farmers agent will contact you shortly at (818)938-7727", "Sub header text match ");
	}

	private void navigateBetweenPages(List<Locator> pages, FarmersSoftAssert fsa) throws Exception {
		pages.get(0).click();
		YourInfoPageHome infoPage = new YourInfoPageHome();
		waitElementBeVisible(infoPage.firstNameTextBox);
		fsa.assertTrue(infoPage.firstNameTextBox.isVisible(), "First name text box displayed in Your info page home");

		infoPage.coverageNavBarText.click();
		ChooseYourCoveragePage coveragePage = new ChooseYourCoveragePage();
		waitElementBeVisible(coveragePage.standardButton);
		fsa.assertTrue(coveragePage.standardButton.isVisible(), "Standard radio button displayed in Coverage page for Home");

		coveragePage.propertyNavBarText.click();
		PropertyPage propertyPage = new PropertyPage();
		waitElementBeVisible(propertyPage.squareFootage);
		propertyPage.selectTypeOfHeatingSystemIsBeingCurrentlyUsed("Coal");
		fsa.assertTrue(propertyPage.squareFootage.isVisible(), "Square Footage dropdown displayed in Property page for Home");

		propertyPage.quoteNavBarText.click();
		waitElementBeVisible(topContinueButton);
		fsa.assertTrue(topContinueButton.isVisible(), "Top continue button displayed in Quote page for Home");
	}

	private void verifyFooterDisclaimerText(FarmersSoftAssert fsa) {
		fsa.assertEquals(getTextFromElement(briefSummaryStaticText), BRIEF_SUMMARY_STATIC_TEXT, "Brief summary static text match ");
		fsa.assertEquals(getTextFromElement(briefSummaryStaticText2), BRIEF_SUMMARY_STATIC_TEXT2, "Brief summary static text match ");
		fsa.assertEquals(getTextFromElement(footerDisclaimerStaticText), MONTHLY_AMOUNT_TEXT, "Disclaimer static text match ");
		fsa.assertEquals(getTextFromElement(footerDisclaimerStaticText2), MONTHLY_AMOUNT_TEXT_PART2, "Disclaimer static text match ");
	}

	private void clickUpdateYourQuoteButton() {
		Log.info("Clicking update your quote button");
		waitAndClickElement(updateQuoteButton);
		waitForRecalculationPopupToBeGone();
	}

	private void clickSaveFinishLaterButton() {
		clickElement(saveFinishLaterBtn);
		clickVisitFcomButton();
	}

	private void clickVisitFcomButton() {
		waitElementBeVisible(visitFcomBtn);
		clickElement(visitFcomBtn);
	}

	private void verifyBusinessProfessionalGroupDiscount(ApplicantHome applicant, StringBuilder builder, FarmersSoftAssert fsa){
		String applicantOccupation = applicant.getOccupation();
		boolean businessProfessionalDisountExpected =  isBusinessProfessionalDiscountSpecialCase(applicant) ||
				(isBusinessProfessionalDiscountState(state) && isValidOccupation(applicantOccupation) && !isBusinessProfessionalDiscountExclusions(applicantOccupation));
		fsa.assertEquals(builder.toString().contains(BUSINESS_PROFESSIONAL_GROUP), businessProfessionalDisountExpected, BUSINESS_PROFESSIONAL_GROUP);
	}

	private boolean isBusinessProfessionalDiscountSpecialCase(ApplicantHome applicant) {
		return ( (applicant.getOccupation().equals(SMALL_BUSINESS_POLICYHOLDER) && applicant.getYourPackage().equals(PREMIER) && state.equals(CALIFORNIA)) ||
				(applicant.getOccupation().equals(RETIRED_BRISTOL_WEST) && state.equals(WYOMING)) );
	}

	private boolean isBusinessProfessionalDiscountState(String state) {
		List<String> noBusinessProfessionalDiscountStates = new ArrayList<>(Arrays.asList(GEORGIA, NEW_YORK));
		return !noBusinessProfessionalDiscountStates.contains(state);
	}

	private boolean isValidOccupation(String occupation) {
		return !(occupation.equals(OTHER) || occupation.equals(SMALL_BUSINESS_POLICYHOLDER));
	}

	private boolean isBusinessProfessionalDiscountExclusions(String occupation) {
		return occupation.equals(RETIRED_BRISTOL_WEST) && !state.equals(WYOMING) ;
	}

	private void verifyPopup(FarmersSoftAssert fsa) throws Exception {
		String pageSource = page().content();
		fsa.assertTrue(pageSource.contains(THANK_YOU_FOR_RETRIEVING_YOUR_QUOTE), POPUP_CONTAINS + THANK_YOU_FOR_RETRIEVING_YOUR_QUOTE);
		fsa.assertTrue(pageSource.contains(YOUR_QUOTE_MAY_HAVE_CHANGED), POPUP_CONTAINS + YOUR_QUOTE_MAY_HAVE_CHANGED);
	}

	private void verifyClaimFreeDiscount(ApplicantHome applicant, StringBuilder builder, FarmersSoftAssert fsa) {
		String applicantState = applicant.getState();
		String howManyPropertyLossesInLastFiveYears = applicant.getPropertyLossesInTheLastFiveYears();
		String howLongAgoSinceLastPropertyClaim = applicant.getHowLongAgoWasYourLastPropertyClaim();
		if ((howLongAgoSinceLastPropertyClaim.equals(NONE) || howLongAgoSinceLastPropertyClaim.equals(MORE_THAN_FIVE_YEARS))) {
			fsa.assertTrue(builder.toString().contains(CLAIM_FREE_DISCOUNT), CLAIM_FREE_DISCOUNT_MSG
					+ howLongAgoSinceLastPropertyClaim + " since last property loss  claim");
		} else if (howLongAgoSinceLastPropertyClaim.equals(THREE_FIVE_YEARS)) {
			fsa.assertTrue(builder.toString().contains(CLAIM_FREE_DISCOUNT), CLAIM_FREE_DISCOUNT_MSG
					+ howLongAgoSinceLastPropertyClaim + " property losses within three to five years");
		} else {
			fsa.assertFalse(builder.toString().contains(CLAIM_FREE_DISCOUNT), "Claim Free Discount should not be considered if you have "
					+ howManyPropertyLossesInLastFiveYears + " property losses in five years for " + applicantState);
		}
	}

	private void verifyPreferredPaymentPlanDiscount(StringBuilder builder, FarmersSoftAssert fsa) {
		fsa.assertTrue(builder.toString().contains(PREFERRED_PAYMENT_PLAN), PREFERRED_PAYMENT_PLAN);
	}

	private void verifyNewHomeDiscount(ApplicantHome applicant, StringBuilder builder, FarmersSoftAssert fsa) {
		int whenWasHomeBuilt = applicant.getWhenYourHomeWasOriginallyBuilt();
		boolean newHomeDiscountExpected = (whenWasHomeBuilt >= oldestAgeForDiscount);
		fsa.assertEquals(builder.toString().contains(NEW_HOME), newHomeDiscountExpected, NEW_HOME + DISCOUNT_MSG);
		if (!newHomeDiscountExpected) {
			verifyNewRoofDiscountForNewRoofOldHome(applicant, builder, fsa);
		}
	}

	private void verifyNewRoofDiscountForNewRoofOldHome(ApplicantHome applicant, StringBuilder builder, FarmersSoftAssert fsa) {
		boolean newRoofDiscountApplies = state.equals(NEW_YORK) && applicant.getHowOldIsYourRoof().matches(roofAgeRange);
		fsa.assertEquals(builder.toString().contains(NEW_ROOF), newRoofDiscountApplies , "New Roof discount for old home in " + state);
	}

	private void verifyGoodPayerDiscount(StringBuilder builder, FarmersSoftAssert fsa) {
		fsa.assertEquals(builder.toString().contains(GOOD_PAYER_DISCOUNT), state.equals(NEW_JERSEY), GOOD_PAYER_DISCOUNT);
	}

	private void verifyHomeProtectionAndLossPreventionDiscount(ApplicantHome applicant, StringBuilder builder, FarmersSoftAssert fsa) {
		fsa.assertEquals(builder.toString().contains(HOME_PROTECTION_AND_LOSS_PREVENTION_DISCOUNT), applicant.isYourHomeConnected(), HOME_PROTECTION_AND_LOSS_PREVENTION_DISCOUNT);
	}

	private void verifyPropertyAddress(ApplicantHome applicant, FarmersSoftAssert fsa) {
		String addressDisplayed = getTextFromElement(insuredPropertyAddress).toUpperCase(Locale.ENGLISH).replace(" ROAD", " RD").replace(" COURT", " CT").replace(" LANE", " LN");
		fsa.assertTrue(addressDisplayed.contains(applicant.getAddressApt().toUpperCase(Locale.ENGLISH)), addressDisplayed + " displays street address.");
		fsa.assertTrue(addressDisplayed.contains(applicant.getCity().toUpperCase(Locale.ENGLISH)), addressDisplayed + " displays city.");
	}

	private void verifyAllDiscounts(ApplicantHome applicant, FarmersSoftAssert fsa){
		StringBuilder builder = new StringBuilder();
		for (Locator discount : discounts.all()) {
			String discountText = getTextFromElement(discount);
			Log.info(discountText);
			builder.append(discountText).append(COMMA);
		}
		verifyNewHomeDiscount(applicant, builder, fsa);
		verifyPreferredPaymentPlanDiscount(builder, fsa);
		verifyBusinessProfessionalGroupDiscount(applicant,builder, fsa);
		verifyClaimFreeDiscount(applicant,builder, fsa);
		verifyHomeProtectionAndLossPreventionDiscount(applicant, builder, fsa);
		verifyGoodPayerDiscount(builder, fsa);
	}

	private String getQuoteRate() {
		if (isElementPresentByID(premiumAmount)) {
			return getTextFromElement(premiumAmount);
		} else {
			return EMPTY_STRING;
		}
	}

	private void logQuoteNumber(ApplicantHome applicant) {
		String quoteNumber = getLegacyQuoteNumber();
		writeRatedQuoteInformationToFile("Legacy Home - " + quoteNumber + SPACE + applicant.getFirstName() + SPACE + applicant.getLastName() + SPACE + applicant.getAddressApt() + SPACE + applicant.getCity() + SPACE + applicant.getStateCode() + SPACE + applicant.getZipCode() + SPACE + getQuoteRate() + NEWLINE);
	}

	@SuppressWarnings("unchecked")
	public <T extends BasePage> T enterQuotePage(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		String applicantState = applicant.getState();
		waitForLegacySpinnerToBeGone();
		if (applicant.isSaveAndRetrieveQuotePage() && findInCallStack(SAVE_AND_RETRIEVE_HOME_QUOTE)) {
			//Defect #6792
			if (!applicantState.equals(WISCONSIN)) {
				verifyPopup(fsa);
				clickUpdateYourQuoteButton();
			}
			fsa.assertEquals(applicant.getApplicantRetQuote().getQuoteNumber(), getLegacyQuoteNumber(), "Quote number doesn't match ");
		}
		if (isElementPresentByID(updateQuoteButton)) {
			clickUpdateYourQuoteButton();
		}
		if (applicant.isCustomRateScenario()) {
			selectAllPerilLimitsDeductibles(applicant.getAllPeril());
			clickRecalculateButton();
			waitElementBeVisible(windAndHailDedErrorMessage);
			fsa.assertTrue(getTextFromElement(windAndHailDedErrorMessage).contains(WIND_AND_HAIL_DEDUCTIBLE_ERROR_MESSAGE), "Wind & Hail deductible error message doesn't match");
			selectWindAndHailDeductibles(applicant.getWindAndHail());
			selectLiabilityLimitsDeductiblesForPersonalLiability(applicant.getPersonalLiability());
			clickRecalculateButton();
		} else if (applicant.isCustomRateAndResetScenario()) {
			selectPropertyCoverageLimitsDeductiblesForDwelling(applicant.getDwelling());
			selectPropertyCoverageLimitsDeductiblesForLossOfUse(applicant.getLossOfUse());
			selectPropertyCoverageLimitsDeductiblesForPersonalProperty(applicant.getPersonalProperty());
			selectPropertyCoverageLimitsDeductiblesForExtendedReplacementCost(applicant.getExtendedReplacementCost());
			clickRecalculateButton();
			clickResetLinkTopButton();
		}
		String pageSource = page().content();
		if (pageSource.contains(YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION) || pageSource.contains(WE_APOLOGIZE_FOR_THE_INCONVENIENCE)) {
			Log.warn("-- Home quote for "+ applicant + " stopped because of knockout in Quote page --");
			return null;
		} else {
			logQuoteNumber(applicant);
			verifyAllDiscounts(applicant, fsa);
			verifyPropertyAddress(applicant, fsa);
			closeSurveyDialog();
			if (applicantState.equals(KANSAS) && findInCallStack(SAVE_AND_RETRIEVE_HOME_QUOTE)) {
				selectAllPerilLimitsDeductibles("500");
				clickRecalculateButton();
			} else {
				verifyPremiumAmountTopAndBottomAreEqual(applicant, fsa);
			}
			closeSurveyDialog();
			verifyLegalDisclaimerStaticText(fsa);
			closeSurveyDialog();
			if (!applicantState.equals(CALIFORNIA) || !applicant.getYourPackage().equals(PREMIER)){
				verifyClaimForgivenessStaticText(fsa);
				closeSurveyDialog();
				verifyClaimFreeDiscountStaticText(fsa);
				closeSurveyDialog();
				if (!applicantState.equals(CALIFORNIA)) {
					verifyDecliningDeductibleStaticText(fsa);
					closeSurveyDialog();
				}
			}
			if (applicant.isSendEmail()) {
				clickEmailQuoteSummaryButton();
			}
			closeSurveyDialog();
			if (applicant.isGetRetrieveScenario()) {
				saveApplicantFinishLater(applicant, QUOTE_PAGE_HOME, getLegacyQuoteNumber());
				applicant.setGetRetrieveScenario(false);
				applicant.setSaveAndRetrieveQuotePage(true);
				return null;
			} else if (applicant.isBackNavFlow() && !applicant.isDidNavBack()) {
				applicant.setDidNavBack(true);
				clickElement(propertyTabBtn);
				return (T) new PropertyPage();
			} else {
				clickContinueButton();
				longWaitForElementToBeGoneByID("homequote:buyBtnTopHome");
				if (isElementPresentByID(topContinueButton)) {
					clickContinueButton();
				}
				return (T) new ThankYouPage();
			}
		}
	}

	public void saveHomeOnQuotePageAndFinishLater(ApplicantHome applicant) {
		waitForLegacySpinnerToBeGone();
		if (applicant.getState().equals(KANSAS)) {
			selectAllPerilLimitsDeductibles("500");
			clickRecalculateButton();
		}
		saveApplicantFinishLater(applicant, QUOTE_PAGE_HOME, getLegacyQuoteNumber());
		clickSaveFinishLaterButton();
	}

	public boolean onQuotePageHome() {
		waitForLegacySpinnerToBeGone();
		return isElementPresentByID(packageName);
	}

	public boolean hasCrossSellQuote(String quoteType) {
		switch(quoteType) {
		case LOB_AUTO :
			return isElementPresentByXPath(CROSS_SELL_ENTRIES + AUTO_CROSS_SELL_XPATH);
		case LOB_LIFE :
			return isElementPresentByXPath(CROSS_SELL_ENTRIES + VTL_CROSS_SELL_XPATH);
		default :
			Assert.fail("Unknown cross sell type: " + quoteType);
			return false;
		}
	}

	public void clickCrossSellQuote(String quoteType) {
		switch (quoteType) {
		case LOB_AUTO :
			waitAndClickElement(autoCrossSellQuote);
			break;
		case LOB_LIFE :
			waitAndClickElement(vtlCrossSellQuote);
			break;
		default :
			Assert.fail("Unknown cross sell LOB type: " + quoteType);
		}
	}

}
