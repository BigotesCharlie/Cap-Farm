package com.farmers.ffq.ace.renters;



import com.farmers.framework.playwright.Keys;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.ace.hrc.common.AceHRCAboutYouBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceRentersAboutYouPage extends AceHRCAboutYouBasePage {

        private Locator pageFooterDisclaimerEsign = locator(pwXPath("//p[contains(@class,'rentersDisclaimer')]//span"));
        private Locator pageFooterDisclaimer = locator(pwXPath("//p[contains(@class,'rentersDisclaimer')]//following::p[1]"));
        private Locator personalInfoLabel = locator(pwXPath("//app-about-you//h2[@id='contact-info-heading']"));
        private Locator emailAddressFieldLabel = locator(pwXPath("//label[@for='contact-details-emailAddress-input_email']//mat-label"));

        private Locator mobilePhoneFieldLabel = locator(pwXPath("//label[@for='contact-details-phoneNumber-input_Field']//mat-label"));
        private Locator emailAddressError = locator(pwXPath("//div[contains(@class,'email-address')]//mat-error"));
        private Locator phoneNumberError = locator(pwXPath("//div[contains(@class,'phone-number')]//mat-error"));

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public AceRentersAboutYouPage() throws Exception {
    }

    public boolean isOnAboutYouPageRenters(boolean longWait) {
        int timeout = longWait ? Property.PAGELOADTIMEOUT : 3;
        return isElementVisible(firstNameInputBox, timeout);
    }

    public void enterEmailIdAndPhoneNumber(ApplicantAceHome applicant) {
        scrollToElement(emailAddressInput);
        waitAndClickElement(emailAddressInput);
        sendKeysToElement(emailAddressInput, applicant.getEmailAddress());
        sendKeysToElement(emailAddressInput, Keys.TAB);
        waitForUiSettled();
        waitAndClickElement(phoneNumberInput);
        waitForUiSettled();
        sendKeysOneByOne(phoneNumberInput, applicant.getPhoneNumber());
        waitForUiSettled();
        sendKeysToElement(phoneNumberInput, Keys.TAB);
    }

    public void fillOutTheDataInAboutYouPageRenters(ApplicantAceHome applicantAceHome, boolean clickContinue) throws Exception {
        waitElementBeVisibleClickable(firstNameInputBox);
        fillOutPrimaryApplicantDetails(applicantAceHome);

        if (applicantAceHome.getMaritalStatus().equals(MARRIED)) {
            clickOnMarriedOrInDomesticRelationCheckbox();
            fillOutSpouseApplicantDetails(applicantAceHome);
        }
        enterEmailIdAndPhoneNumber(applicantAceHome);
        if(clickContinue) {
            clickAgreeAndSubmitButton();
            waitForSpinnerToBeGone();
        }
    }

    public void validateAboutYouSelections(ApplicantAceHome applicant, boolean ratedQuote, FarmersSoftAssert fsa) throws Exception {
        if (ratedQuote) {
            fsa.assertTrue(isFirstNameReadOnly(), "About You page - First name is read-only.");
            fsa.assertTrue(isLastNameReadOnly(), "About You page - Last name is read-only.");
            fsa.assertTrue(isDateOfBirthReadOnly(), "About You page - Date of birth is ready-only.");
            fsa.assertTrue(isGenderReadOnly(), "About You page - Gender is ready-only.");
            fsa.assertTrue(isMarriedCheckboxReadOnly(), "Married checkbox is read-only.");
            fsa.assertEquals(getDateOfBirth(), "**/**/"+applicant.getDateOfBirth().split("/")[2],
                    "About You page - Partially masked Date of birth value.");
            fsa.assertTrue(isEmailAddressReadOnly(), "About You page - Email address is read-only.");
            fsa.assertTrue(isPhoneNumberReadOnly(), "About You page - Phone number is read-only.");
        }
        fsa.assertEquals(getFirstName().toLowerCase(), applicant.getFirstName().toLowerCase(), "About You page - First name value.");
        fsa.assertEquals(getLastName().toLowerCase(), applicant.getLastName().toLowerCase(), "About You page - Last name value.");
        fsa.assertEquals(getGenderApplicant(), applicant.getGender(), "About You page - Applicant's gender value.");
        fsa.assertEquals(getEmailAddressFromInputField(), applicant.getEmailAddress(), "About You page - email address value.");
        fsa.assertEquals(getPhoneNumberFromInputField(), applicant.getPhoneNumber(), "About You page - phone number value.");

        if (applicant.getMaritalStatus().equals(MARRIED)) {
            fsa.assertTrue(isMarriedCheckboxChecked(), "Married checkbox is checked.");
            if (ratedQuote) {
                fsa.assertTrue(isMarriedCheckboxReadOnly(), "Married checkbox is read-only.");
                fsa.assertTrue(isSpouseFirstNameReadOnly(), "About You page - Spouse first name is read-only.");
                fsa.assertTrue(isSpouseLastNameReadOnly(), "About You page - Spouse last name is read-only.");
                fsa.assertTrue(isSpouseDateOfBirthReadOnly(), "About You page - Spouse Date of birth is ready-only.");
                fsa.assertTrue(isSpouseGenderReadOnly(), "About You page - Spouse Gender is ready-only.");
                fsa.assertEquals(getSpouseDateOfBirth(), "**/**/"+applicant.getSpouseDateOfBirth().split("/")[2],
                        "About You page - Partially masked spouse Date of birth value.");
            } else {
                fsa.assertTrue(!isMarriedCheckboxReadOnly(), "Married checkbox is not read-only.");
            }
            fsa.assertEquals(getSpouseFirstName().toLowerCase(), applicant.getSpouseFirstName().toLowerCase(), "About You page - Spouse first name value.");
            fsa.assertEquals(getSpouseLastName().toLowerCase(), applicant.getSpouseLastName().toLowerCase(), "About You page - Spouse last name value.");
            fsa.assertEquals(getGenderSpouse(), applicant.getSpouseGender(), "About You page - Spouse's gender value.");
        } else {
            fsa.assertTrue(!isSpouseFirstNameInputBoxDisplayed(), "About you page - Spouse first name input field is not displayed.");
            fsa.assertTrue(!isSpouseLastNameInputBoxDisplayed(), "About you page - Spouse last name input field is not displayed.");
            fsa.assertTrue(!isSpouseDateOfBirthInputBoxDisplayed(), "About you page - Spouse date of birth input field is not displayed.");
            fsa.assertTrue(!isSpouseGenderDisplayed(), "About you page - Spouse date of birth input field is not displayed.");
            fsa.assertTrue(!isMarriedCheckboxChecked(), "Married checkbox is not checked.");
        }
    }

    public void validateContentOfContactInfoRenters(FarmersSoftAssert fsa) {
        final String EXPECTED_PERSONAL_INFO_LABEL = "Contact information (required)";

        // Validate contact info fields content
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(personalInfoLabel)), EXPECTED_PERSONAL_INFO_LABEL, errorMessage(EXPECTED_PERSONAL_INFO_LABEL));
        final String EXPECTED_EMAIL_ADDRESS_FIELD_LABEL = "Email address";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(emailAddressFieldLabel)), EXPECTED_EMAIL_ADDRESS_FIELD_LABEL, errorMessage(EXPECTED_EMAIL_ADDRESS_FIELD_LABEL));

        final String EXPECTED_MOBILE_PHONE_FIELD_LABEL = "Mobile phone";
        scrollToElement(waitElementBeVisible(mobilePhoneFieldLabel));
        fsa.assertEquals(getTextFromElement(mobilePhoneFieldLabel), EXPECTED_MOBILE_PHONE_FIELD_LABEL, errorMessage(EXPECTED_MOBILE_PHONE_FIELD_LABEL));
    }

    public void validateDisclaimerOnContactInfoPage(FarmersSoftAssert fsa) {
        final String EXPECTED_DISCLAIMER_ESIGN = "String clicking \"Agree and submit\", you agree to these ESIGN terms and conditions and to receive marketing calls and texts as detailed below.";
        final String EXPECTED_DISCLAIMER_INFO = "We call and/or text consumers with information about products and services. String clicking \"Agree and submit\", " +
                "you consent to receive marketing calls and texts on behalf of Farmers\u00ae, Foremost\u00ae, Bristol West\u00ae, and Farmers Life\u00ae associated entities and their " +
                "representatives using an automated telephone dialing system, AI-generated and artificial or pre-recorded voice, even for numbers listed on national, " +
                "state, or business do-not-call registries. Consent is not a condition of purchase. Go to Farmers.com for alternative contact options. Message and data " +
                "rates may apply.";
        scrollToElement(pageFooterDisclaimerEsign);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageFooterDisclaimerEsign, 5)), EXPECTED_DISCLAIMER_ESIGN, errorMessage("Esign disclaimer"));
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageFooterDisclaimer, 5)), EXPECTED_DISCLAIMER_INFO, errorMessage("Call/Text disclaimer"));
    }
    public void validateAgreeAndSubmitButton(FarmersSoftAssert fsa){
        fsa.assertTrue(agreeAndSubmitButton.isVisible(), "Agree and submit button validation");
    }

    public void validateEmailAddressAndPhoneNumberInput(FarmersSoftAssert fsa) throws Exception {
        final String IS_NOT_VALID_ENTRY = "is not a valid entry.";

        //invalid email format
        waitAndClickElement(emailAddressInput);
        sendKeysToElement(emailAddressInput, "invalidEmail@");
        clickAway();
        final String EXPECTED_INVALID_EMAIL_ADDRESS_ERROR = "Email address entered is invalid.";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(emailAddressError)), EXPECTED_INVALID_EMAIL_ADDRESS_ERROR, "Invalid email format check");

        //invalid domain --validate email call should fail
        waitAndClickElement(emailAddressInput);
        sendKeysToElement(emailAddressInput, "invalidemail_123@yopmael.com");
        waitAndClickElement(phoneNumberInput);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(emailAddressError)), EXPECTED_INVALID_EMAIL_ADDRESS_ERROR, "Invalid email domain check");

        //invalid phone number
        String invalidPhone = "(123) 456-6796";
        sendKeysToElement(phoneNumberInput, invalidPhone);
        sendKeysOneByOne(phoneNumberInput, Keys.chord(invalidPhone, Keys.TAB));
        fsa.assertEquals(getTextFromElement(phoneNumberError), String.format("%s %s", invalidPhone, IS_NOT_VALID_ENTRY), "Invalid phone number check");
    }

    public boolean isEmailAddressReadOnly() {
        return isAttributePresent(emailAddressInput, DISABLED);
    }

    public boolean isPhoneNumberReadOnly() {
        return isAttributePresent(phoneNumberInput, DISABLED);
    }

    public String getEmailAddressFromInputField() {
        return getValueFromLocator(emailAddressInput);
    }

    public String getPhoneNumberFromInputField() {
        return getValueFromLocator(phoneNumberInput).replaceAll("[^0-9]", "");
    }

    public void capturePEWC(String filename) throws Exception {
    	scrollToBottomOfPage();
        screenCapture(emailAddressInput, filename, LARGE, false);
    }
}
