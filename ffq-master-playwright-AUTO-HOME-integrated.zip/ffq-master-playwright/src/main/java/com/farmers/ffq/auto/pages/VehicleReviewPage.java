package com.farmers.ffq.auto.pages;







import com.farmers.framework.playwright.Keys;
import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.datatransferobjects.AppStore.Auto.AppStoreVehicle;
import com.farmers.ffq.datatransferobjects.AppStore.Auto.AppStoreVehicle.GrgingAddr;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.Vehicle;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter
public class VehicleReviewPage extends AutoBasePage {

    public static final String RIDESHARE = "Rideshare";
    private static final String COMMUTE = "Commute";
    public static final String PERSONAL = "Personal";
    public static final String BUSINESS = "Business";
    private static final String CLOSE_XPATH_NODE = "']";

    String addToText = isUseMobileViewEnabled() || Property.getBrowser().equals("safari") ? " info" : EMPTY_STRING;

        private Locator vehicleReviewPageTitle = locator(pwXPath("//app-vehicles-review//h1"));

        private Locator vehicleReviewPageDescription = locator(pwXPath("//button[@id='reviseButton']/parent::div"));

        private Locator reviseVehiclesLink = locator(pwXPath("//*[contains(@class, 'auto-vehicles-review__revise-button')]"));

        private Locator continueToDriversButton = locatorAny(
                pwXPath("//app-vehicles-review//button[contains(@class,'auto-vehicles-review__continue-button')]"),
                pwXPath("//app-vehicles-review//button[@data-test-id='CONTINUE_BUTTON' or @data-test-id='CONTINUE' or normalize-space()='Continue']")
        );

        private Locator lblVIN = locator(pwXPath("//div[contains(@id,'vehicleSection')]//h2[@class='tui-h2']"));

        private Locator lblEditVehicleHeader = locatorAny(pwXPath("//h4[normalize-space(text())='Edit vehicle']"), pwXPath("//h2[normalize-space(text())='Edit vehicle']"));

        private Locator inputVINMasked = locator(pwXPath("//mat-label[contains(normalize-space(text()),'VIN')]/ancestor::div[1]/input[contains(@class,'ng-valid')]"));

        private Locator inputYearFilled = locator(pwXPath("//mat-label[contains(normalize-space(text()),'Year')]/ancestor::div[1]//span[contains(@class,'mat-select-min-line')]"));

        private Locator vinToggleOnTheSideSheet = locator(pwXPath("//button[contains(.,'VIN')]"));

        private Locator whereICanFindThisLink = locator(pwXPath("//div[contains(@class,'auto-add-vehicle-vin__disclaimer row pt-4')]//a"));

        private Locator vinHelperHeader = locator(pwCss("div[class='tui-vin-modal-header']"));

        private Locator vinHelperHeaderLabel = locator(pwXPath("//div[@class='tui-vin-modal-header']//p"));

        private Locator backToVinButton = locator(pwXPath("//button[@class='tui-btn tui-btn-primary tui-vin-back-to-vin-button']"));

        private Locator vehicleUsageMatIcon = locator(pwXPath("//mat-icon[@data-tui-tracking-id='auto-vehicles-review__vehicle-usage-info']"));

        private Locator btnClose = locator(pwXPath("//mat-icon[@role='button' and text()='close']"));

        private Locator lblFirstVehicleHeader = locator(pwXPath("//div[@id='vehicleSection0']/h2"));

        private Locator btnOpenDateOfPurchaseCalendar = locator(pwXPath("//button[@aria-label='Open calendar']"));

        private Locator alternativeFuelCheckBox = locator(pwXPath("//div//mat-checkbox[contains(@data-test-id,'ALTERNATIVE_FUEL_CHECKBOX')]"));

        private Locator antiTheftCheckBox = locator(pwXPath("//div//mat-checkbox[contains(@data-test-id,'ANTI_THEFT_CHECKBOX')]"));

        private Locator lblFirstEnabledDateOfPurchaseCalendar = locator(pwXPath("(//tbody[@class='mat-calendar-body']//button[not(contains(@class,'disabled'))]/div[contains(@class,'cell-content')])[1]"));

        private Locator vehicleSideSheetHeader = locator(pwId("addVehicleHeading"));

        private Locator sideSheetVINInputField = locator(pwId("auto-add-vehicle-vin__input-section"));

    private static final String PERSONAL_SECTION_QUESTIONS_COUNT_XPATH = "//div[contains(@id,'vehicles-review_vehicleMilesDriven')]//input";

    private static final String FOCUSED_COMMUTE_BUTTON_XPATH = "//mat-button-toggle[@value='Commute' and contains(@class,'checked')]";

        private Locator defaultGarageRadioButtons = locator(pwXPath("//mat-radio-group[@aria-labelledBy='parkingInfo_ariaLabel']//input[not(contains(@aria-label,'Other location'))]"));

        private Locator otherLocationRadioButtons = locator(pwXPath("//mat-radio-button[contains(.,'Other location')]//input"));

        private Locator editButtons = locator(pwXPath("//button[contains(@aria-label,'Edit')]"));

        private Locator personalToggles = locator(pwXPath("//mat-button-toggle[contains(.,'Personal')]//button"));

        private Locator datePickers = locator(pwXPath(VEHICLE_ACQUIRED_DATE_PICKER));

    private final String CTA_ERROR_MESSAGE_XPATH = "//p[contains(@class,'vehicles-review-fields-missing tui-small-text')]";
        private Locator pageCtaErrorMessage = locator(pwXPath(CTA_ERROR_MESSAGE_XPATH));

    private static final String USAGE_DROP_DOWN_XPATH = "//mat-form-field[contains(@id,'vehicleUsage')]//mat-select";
    private static final String BUTTON_ONE = "//mat-button-toggle[1]/button";
    private static final String USAGE_RADIO_BUTTON_ONE = "//mat-radio-button//input[@value='PLS']";
    private static final String BUTTON_TWO = "//mat-button-toggle[2]/button";
    private static final String USAGE_RADIO_BUTTON_TWO = "//mat-radio-button//input[@value='OTC']";
    private static final String BUTTON_THREE = "//mat-button-toggle[3]/button";
    private static final String SELECTED_BUTTON_XPATH = "//mat-button-toggle[contains(@class, 'mat-button-toggle-checked')]/button";
    private static final String DATE_HIDDEN_INPUT_FIELD_XPATH = "//input[@hidden]";
    private static final String DATE_INPUT_FIELD_XPATH = "//input[@matinput]";
    private static final String GROUP_LABEL_XPATH = "//*[contains(@class, 'auto-vehicles-review__question-title')]";
    public static final String VEHICLE_INFORMATION_XPATH = "//div[contains(@class, 'auto-vehicles-review__vehicle-section')]";
    public static final String VEHICLE_DESCRIPTION_XPATH = VEHICLE_INFORMATION_XPATH + "/div/*[@class='tui-h2']";
    private static final String VEHICLE_USAGE_GROUP_XPATH = "//div[@id='vehicles-review_vehicleUsage";
    private static final String VEHICLE_RIDESHARE_CHECKBOX_XPATH = "//div[contains(@class,'rideshare-business-checkbox')]//mat-checkbox//input";
    private static final String VEHICLE_OWNERSHIP_GROUP_XPATH = "//div[@id='vehicles-review_vehicleOwnership";
    private static final String VEHICLE_ACQUIRED_GROUP_XPATH = "//div[@id='vehicles-review_vehicleAcquired";
    private static final String VEHICLE_ACQUIRED_DATE_PICKER = "//button[@aria-label='Open calendar']";
    private static final String VEHICLE_PARKED_LOCATION_GROUP_XPATH = "//div[@id='vehicles-review_vehicleParkedAt";
    private static final String GARAGING_ADDRESS_ENTRY_FIELD_XPATH = "//input[contains(@aria-label,'Garaging address')]";
    private static final String GARAGING_ADDRESS_UNIT_ENTRY_FIELD_XPATH = "//input[contains(@aria-label,'Apartment number (optional)')]";
    private static final String GARAGING_ADDRESS_CITY_ENTRY_FIELD_XPATH = "//input[contains(@aria-label,'City')]";
    private static final String GARAGING_ADDRESS_STATE_ENTRY_FIELD_XPATH = "//input[contains(@aria-label,'State combo box collapsed please select')]";
    private static final String GARAGING_ADDRESS_ZIP_CODE_ENTRY_FIELD_XPATH = "//input[contains(@aria-label,'Zip code')]";
    private static final String THEFT_RECOVERY_SYSTEM_CHECKBOX_XPATH = "//mat-checkbox//span[contains(text(), 'Theft')]/../..//input";
    private static final String GENERIC_RADIO_BUTTON_ONE = "//mat-radio-button[1]//input";
    private static final String GENERIC_RADIO_BUTTON_ONE_LABEL = "//mat-radio-button[1]//label";
    private static final String GENERIC_RADIO_BUTTON_TWO = "//mat-radio-button[2]//input";
    private static final String GENERIC_RADIO_BUTTON_TWO_LABEL = "//mat-radio-button[2]//label";
    private static final String SELECTED_RADIO_BUTTON_XPATH = "//mat-radio-button[contains(@class, 'mat-radio-checked')]";

    //xpaths to help elements
    private static final String VEHICLE_USAGE_HELP_TITLE_XPATH = "//div[contains(@id,'vehicleUsageInfo')]//p[1]";
    private static final String PERSONAL_USAGE_HELP_CONTENT_XPATH = "//div[contains(@id,'vehicleUsageInfo')]//p[2]";
    private static final String BUSINESS_USAGE_HELP_CONTENT_XPATH = "//div[contains(@id,'vehicleUsageInfo')]//p[3]";
    private static final String ADDITIONAL_USAGE_HELP_CONTENT_XPATH = "//div[contains(@id,'vehicleUsageInfo')]//p[4]";
    private static final String VEHICLE_RIDESHARE_FOR_BUSINESS_HELP_CONTENT_XPATH = "//p[@class='rideshare-description']";
    private static final String VEHICLE_RIDESHARE1_FOR_BUSINESS_HELP_CONTENT_XPATH = "//div[contains(@id,'vehicleUsageInfo')]//p[5]";

    private static final String OWNERSHIP_HELP_TITLE_XPATH = "//p[contains(@aria-label,'Ownership')]";
    private static final String OWNED_HELP_CONTENT_XPATH = "//p[2]";
    private static final String LEASED_HELP_CONTENT_XPATH = "//p[3]";
    private static final String FINANCED_HELP_CONTENT_XPATH = "//p[4]";

    private static final String ACQUIRED_HELP_TITLE_XPATH = "//p[contains(@aria-label,'Acquired')]";
    private static final String ACQUIRED_HELP_CONTENT_XPATH = "//p[2]";

    private static final String PARKED_AT_HELP_TITLE_XPATH = "//p[1]";
    private static final String PARKED_AT_HELP_CONTENT_XPATH = "//p[2]";

    private static final String VEHICLE_SECTION_XPATH = "//div[@id='vehicleSection%d']";

    private static final String MASKED_OR_NO_VIN_XPATH = VEHICLE_SECTION_XPATH + "//div[@class='vin-edit-container']/span/span";
    private static final String EDIT_VEHICLE_XPATH = VEHICLE_SECTION_XPATH + "//button[.='Edit']";

    private static final String MILES_YOU_DRIVE_ONE_WAY = "Miles you drive one-way";
    private static final String MILES_YOU_DRIVE_ONE_WAY_INPUT_XPATH = "//input[contains(@aria-label,'" + MILES_YOU_DRIVE_ONE_WAY + "')]";

    private static final String HOW_OFTEN_DO_YOU_COMMUTE = "How often do you commute?";
    private static final String HOW_OFTEN_DO_YOU_COMMUTE_DROPDOWN_XPATH = "//span[contains(.,'" + HOW_OFTEN_DO_YOU_COMMUTE + "')]//preceding-sibling::mat-select";

    private static final String MILES_DRIVEN_PER_YEAR = "Miles driven per year";
    private static final String MILES_DRIVEN_PER_YEAR_INPUT_XPATH = "//input[contains(@aria-label,'" + MILES_DRIVEN_PER_YEAR + "')]";

    private static final String MILES_PER_DAY_ERROR_MESSAGE_XPATH = "//mat-form-field[@id='miles_driven__input-field']//mat-error[contains(@class,'commute')]";
    private static final String HOW_OFTEN_DO_YOU_COMMUTE_ERROR_XPATH = "//mat-form-field[@id='miles_driven_commute__input-field']//mat-error[contains(@class,'commute')]";
    private static final String MILES_DRIVEN_PER_YEAR_ERROR_XPATH = "//mat-form-field[@id='miles_driven_year__input-field']//mat-error[contains(@class,'commute')]";

    private static final String RIDESHARE_CARD_XPATH = "//div[contains(@class,'rideShareCard')]";
    private static final String RIDESHARE_CARD_BULB_ICON_XPATH = RIDESHARE_CARD_XPATH + "//mat-icon";
    private static final String RIDESHARE_CARD_TITLE = RIDESHARE_CARD_XPATH + "//p[1]";
    private static final String RIDESHARE_CARD_DESCRIPTION = RIDESHARE_CARD_XPATH + "//p[2]";

        Locator listOfVehicleDescriptions = locator(pwXPath(VEHICLE_DESCRIPTION_XPATH));

    public VehicleReviewPage() throws Exception {
    }

    public boolean isOnVehiclesReviewPage() throws Exception {
        return isElementPresent(pwXPath("//app-vehicles-review//h1"), 15);
    }

    public void clickOnContinueButton() {
        dismissVehicleDatepickerIfOpen();
        if (isOnDriverReviewSurface()) {
            Log.info("Driver review is already visible; skipping vehicle review continue click.");
            return;
        }
        try {
            if (isElementVisible(continueToDriversButton, 5)) {
                scrollAndClickOnElement(continueToDriversButton);
            } else {
                waitAndClickElement(locator(pwXPath("//app-vehicles-review//button[normalize-space()='Continue']")));
            }
            waitForSpinnerToBeGone();
        } catch (PlaywrightException clickError) {
            if (isOnDriverReviewSurface()) {
                Log.info("Vehicle review continue target detached after auto-advance to driver review; continuing.");
                waitForSpinnerToBeGone();
                return;
            }
            throw clickError;
        }
    }

    private boolean isOnDriverReviewSurface() {
        return isElementPresent(pwXPath("//app-driver-review"), 2)
                || isElementPresent(pwXPath("//app-driver-review//h1"), 2);
    }

    public boolean validateVehicleReviewPageTitle() {
        waitElementBeVisible(vehicleReviewPageTitle);
        final String vehicleReviewPageTitleText = "Your vehicles";
        return testExpectedTextContentForElement(vehicleReviewPageTitle, vehicleReviewPageTitleText);
    }

    public boolean validateVehicleReviewPageDescription() {
        waitElementBeVisible(vehicleReviewPageDescription);
        final String vehicleReviewPageDescriptionText = "Please check the information about your vehicles. Revise which vehicles to include";
        return testExpectedTextContentForElement(vehicleReviewPageDescription, vehicleReviewPageDescriptionText);
    }

    public void validateAllVehicles(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        waitElementBeVisible(vehicleReviewPageTitle);
        // For each applicant vehicle:
        int numberOfVehicles = limitVehicleCountToMaxAllowed(applicant.getStateCode(), applicant.getVehicles().size());
        waitForElements(VEHICLE_DESCRIPTION_XPATH);
        List<Locator> displayedVehicles = locators(pwXPath(VEHICLE_DESCRIPTION_XPATH));
        for (int v = 0; v < numberOfVehicles; v++) {
            Vehicle vehicleInfo = applicant.getVehicles().get(v);
            validateVehicleListing(vehicleInfo, displayedVehicles.get(v), fsa);
            validateDisplayedVehicleUsage(vehicleInfo.getVehicleUsage(), v + 1, fsa);
            validateDisplayedVehicleOwnership(vehicleInfo.getOwnership(), v + 1, fsa);
            validateDisplayedVehicleAcquiredRange(vehicleInfo, v + 1, fsa);
            String garagingAddress = vehicleInfo.isParkInResidentAddress() ? applicant.getResidentAddress() : applicant.getGaragingAddress();
            if (!List.of(CA, IA).contains(applicant.getStateCode())) {
                GrgingAddr grgingAddr = getSessionStorageAppStore().getAuto().getVehicles().get(v).getGrgingAddr();
                validateVehicleParkingLocation(vehicleInfo, garagingAddress, grgingAddr, v + 1, fsa);
            }
            if (isAntiTheftRecoverySystemEnabledState(applicant.getStateCode())) {
                fsa.assertTrue(validateTheftRecoverySystemSelected(vehicleInfo.isTheftRecoverySystem(), v + 1), "Theft recovery validation failed. Vehicle info: " + vehicleInfo);
            }
        }
        if (numberOfVehicles != displayedVehicles.size()) {
            Log.error("Vehicles found: " + displayedVehicles.size() + " Vehicles expected: " + displayedVehicles.size());
        }
    }


    public void validateVehiclesForCrossSell(AutoApplicant applicant, String browserType, FarmersSoftAssert fsa) throws Exception {
        int numberOfVehicles = limitVehicleCountToMaxAllowed(applicant.getStateCode(), applicant.getVehicles().size());
        waitForElements(VEHICLE_DESCRIPTION_XPATH);
        List<Locator> displayedVehicles = locators(pwXPath(VEHICLE_DESCRIPTION_XPATH));
        for (int v = 0; v < numberOfVehicles; v++) {
            Vehicle vehicleInfo = applicant.getVehicles().get(v);
            validateVehicleListing(vehicleInfo, displayedVehicles.get(v), fsa);
            fsa.assertEquals(getTextFromElement(locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + (v + 1) + CLOSE_XPATH_NODE + SELECTED_BUTTON_XPATH))),
                    vehicleInfo.getVehicleUsage(), "Vehicle Review page - Vehicle# " + (v + 1) + " Usage Info.");
            fsa.assertEquals(getTextFromElement(locator(pwXPath(VEHICLE_OWNERSHIP_GROUP_XPATH + (v + 1) + CLOSE_XPATH_NODE + SELECTED_BUTTON_XPATH))),
                    vehicleInfo.getOwnership(), "Vehicle Review page - Vehicle# " + (v + 1) + " Ownership Info.");
            if (isElementDisplayed(pwXPath(VEHICLE_ACQUIRED_GROUP_XPATH + (v + 1) + CLOSE_XPATH_NODE + SELECTED_BUTTON_XPATH))) {
                String lengthOfOwnership = browserType.equals(DESKTOP_BROWSER) ? "Less than 2 years ago" : "< 2 yrs ago";
                fsa.assertEquals(getTextFromElement(locator(pwXPath(VEHICLE_ACQUIRED_GROUP_XPATH + (v + 1) + CLOSE_XPATH_NODE + SELECTED_BUTTON_XPATH))),
                        lengthOfOwnership, "Vehicle Review page - Vehicle# " + (v + 1) + " Length of Ownership Info.");
            } else if (isElementDisplayed(pwXPath(VEHICLE_ACQUIRED_GROUP_XPATH + (v + 1) + CLOSE_XPATH_NODE + DATE_HIDDEN_INPUT_FIELD_XPATH))) {
                DateTimeFormatter formatterMonth = DateTimeFormatter.ofPattern("MM");
                String dateOfPurchase = LocalDate.now().format(formatterMonth) + "/" + (Integer.parseInt(vehicleInfo.getVehicleYear()) - 1);
                fsa.assertEquals(getTextFromElement(locator(pwXPath(VEHICLE_ACQUIRED_GROUP_XPATH + (v + 1) + CLOSE_XPATH_NODE + DATE_HIDDEN_INPUT_FIELD_XPATH))),
                        dateOfPurchase, "Vehicle Review page - Vehicle# " + (v + 1) + " Date Of Purchase.");
            }
            if (!applicant.getStateCode().equals(IA)) {
                String garagingAddress = browserType.equals(DESKTOP_BROWSER) ? applicant.getResidentAddress() + ", " + applicant.getCity() + ", " +
                        applicant.getStateCode() + SPACE + applicant.getZipCode() : applicant.getResidentAddress();
                fsa.assertEquals(getTextFromElement(locator(pwXPath(VEHICLE_PARKED_LOCATION_GROUP_XPATH + (v + 1) + CLOSE_XPATH_NODE + SELECTED_RADIO_BUTTON_XPATH))),
                        garagingAddress, "Vehicle Review page - Vehicle# " + (v + 1) + " Garaging Address Info.");
            }
        }
        fsa.assertEquals(displayedVehicles.size(), numberOfVehicles, "Vehicle Review page - Number of displayed vehicles.");
    }

    public void addVehicleDetails(AutoApplicant applicant) throws Exception {
        isOnVehiclesReviewPage();
        // For each applicant vehicle:
        int numberOfVehicles = limitVehicleCountToMaxAllowed(applicant.getStateCode(), applicant.getVehicles().size());
        int numberOfVehiclesNeedingDetails = listOfVehicleDescriptions.count();
        for (int vehicleNumber = 0; vehicleNumber < numberOfVehicles && vehicleNumber < numberOfVehiclesNeedingDetails; vehicleNumber++) {
            Vehicle vehicleInfo = applicant.getVehicles().get(vehicleNumber);
            waitForUiSettled();
            scrollElementToMiddle(listOfVehicleDescriptions.nth(vehicleNumber));
            setVehicleUsage(applicant, vehicleInfo.getVehicleUsage(), vehicleNumber);
            setVehicleOwnership(vehicleInfo.getOwnership(), vehicleNumber + 1);
            if (!isBDQFlowEnabled()) {
                setVehicleAcquiredRange(vehicleInfo, vehicleNumber + 1);
            }
            if (!vehicleInfo.isParkInResidentAddress() && !Arrays.asList(CA, IA).contains(applicant.getStateCode())) {
                setVehicleParkingLocation(applicant, vehicleNumber + 1);
            }
            if (isAntiTheftRecoverySystemEnabledState(applicant.getStateCode())) {
                setTheftRecoverySystemDiscount(vehicleInfo, vehicleNumber + 1);
            }
            if (applicant.getTestScenario().contains("UMB")) {
                scrollToTopOfPage();
                Log.info("Capture vehicle details" + NEWLINE, applicant.getTestScenario() + "VehicleDetails");
            }
        }
    }

    private void validateBDQSpecificRequirements() throws Exception {
        if (isBDQFlowEnabled()) {
            testStepAssert(isOnBristolWest() && !isOnFarmers(), "User should have the Bw logo not farmers");
        }
    }

    public WhoShouldWeInsurePage returnToWhoShouldWeInsurePage() throws Exception {
        clickReviseVehiclesLink();
        waitForSpinnerToBeGone();
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        whoShouldWeInsurePage.isOnWhoShouldWeInsurePage();
        return whoShouldWeInsurePage;
    }

    public void clickReviseVehiclesLink() {
        scrollAndClickOnElement(reviseVehiclesLink);
    }

    public void navigateToPreviousPage() throws Exception {
        super.navigateBackToPreviousPage();
    }

    public void setVehicleUsage(AutoApplicant applicant, String vehicleUsage, int vehicleNumber) throws Exception {
        String vehicleUsageGroupXpath = "//div[@id='vehicleSection"+ vehicleNumber +"']//div[contains(@id,'vehicles-review_vehicleUsage')]";
        Locator vehicleUsageButton = null;
        Vehicle vehicle = applicant.getVehicles().get(vehicleNumber);
        boolean usesRadioButtons = isElementPresent(pwXPath(USAGE_RADIO_BUTTON_ONE));
        boolean usesDropDown = isElementPresent(pwXPath(USAGE_DROP_DOWN_XPATH));
        Locator usageDropDown = null;
        if (usesDropDown) {
            usageDropDown = locator(pwXPath(vehicleUsageGroupXpath + USAGE_DROP_DOWN_XPATH));
        }

        switch (vehicleUsage) {
            case COMMUTE:
                if (usesDropDown) {
                    if (getTextFromElement(usageDropDown).contains(PERSONAL)) {
                        waitAndClickElement(usageDropDown);
                        sendKeysToElement(usageDropDown, Keys.UP);
                        sendKeysToElement(usageDropDown, Keys.ENTER);
                    }
                    return;
                } else {
                    String xpathToCommuteButton = usesRadioButtons ? USAGE_RADIO_BUTTON_ONE : "//button[contains(.,'" + COMMUTE + "')]";
                    vehicleUsageButton = locator(pwXPath(vehicleUsageGroupXpath + xpathToCommuteButton));
                }
                break;
            case PERSONAL:
            case RIDESHARE:
                if (usesDropDown) {
                    if (getTextFromElement(usageDropDown).contains(BUSINESS)) {
                        waitAndClickElement(usageDropDown);
                        sendKeysToElement(usageDropDown, Keys.UP);
                        sendKeysToElement(usageDropDown, Keys.ENTER);
                    }
                    return;
                } else {
                    String xpathToPersonalButton = usesRadioButtons ? USAGE_RADIO_BUTTON_ONE : "//button[contains(.,'" + PERSONAL + "')]";
                    vehicleUsageButton = locator(pwXPath(vehicleUsageGroupXpath + xpathToPersonalButton));
                }
                break;
            case BUSINESS:
                if (usesDropDown) {
                    if (getTextFromElement(usageDropDown).contains(PERSONAL)) {
                        waitAndClickElement(usageDropDown);
                        sendKeysToElement(usageDropDown, Keys.DOWN);
                        sendKeysToElement(usageDropDown, Keys.ENTER);
                    }
                    return;
                } else {
                    String xpathToBusinessButton = usesRadioButtons ? USAGE_RADIO_BUTTON_TWO : "//button[contains(.,'" + BUSINESS + "')]";
                    vehicleUsageButton = locator(pwXPath(vehicleUsageGroupXpath + xpathToBusinessButton));
                }
                break;
            case "RideshareAndBusiness":
            	// Keep ride share either under business or personal
            	if (usesDropDown) {
            		if (getTextFromElement(usageDropDown).contains(PERSONAL)) {
            			waitAndClickElement(usageDropDown);
            			sendKeysToElement(usageDropDown, Keys.DOWN);
            			sendKeysToElement(usageDropDown, Keys.ENTER);
            		}
            		return;
            	} else {
            		String xpathToBusinessToggle = usesRadioButtons ? USAGE_RADIO_BUTTON_TWO : "//button[contains(.,'" + BUSINESS + "')]";
            		vehicleUsageButton = locator(pwXPath(vehicleUsageGroupXpath + xpathToBusinessToggle));
            	}
                break;
            default:
                Assert.fail("Unknown vehicleUsage type: [" + vehicleUsage + "] for vehicle number " + (vehicleNumber+1));
        }
        if (vehicle.isRidesharing()) {
            clickOnRideShareRadioButton(vehicleNumber);
            Log.info("Ridesharing is true, so selecting rideshare for business checkbox for vehicle number : " + (vehicleNumber+1));
        }
        clickElement(vehicleUsageButton);
        Log.info("Vehicle usage is set to : " + vehicleUsage + " for vehicle number : " + (vehicleNumber+1));

    }

    public void clickOnRideShareRadioButton(int vehicleNumber) throws Exception {
        String rideShareXpath = pwXPath("//div[@id='vehicleSection" + vehicleNumber + "']//div[contains(@id,'vehicles-review_vehicleUsage')]" + VEHICLE_RIDESHARE_CHECKBOX_XPATH);
        if (!isBristolWestQuote() || isElementDisplayed(rideShareXpath)) {
            Locator rideShareCheckbox = locator(rideShareXpath);
    		if (!rideShareCheckbox.isChecked()) {
    			scrollAndClickOnElement(rideShareCheckbox);
    		}
        }
    }

    public void setVehicleOwnership(String ownership, int vehicleNumber) throws Exception {
        String vehicleOwnershipGroupXpath = VEHICLE_OWNERSHIP_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE;
        Locator vehicleOwnershipButton = null;
        switch (ownership) {
            case "Owned":
                vehicleOwnershipButton = locator(pwXPath(vehicleOwnershipGroupXpath + BUTTON_ONE));
                break;
            case "Leased":
                vehicleOwnershipButton = locator(pwXPath(vehicleOwnershipGroupXpath + BUTTON_TWO));
                break;
            case "Financed":
                vehicleOwnershipButton = locator(pwXPath(vehicleOwnershipGroupXpath + BUTTON_THREE));
                break;
            default:
                Assert.fail("Unknown vehicleOwnership type: [" + ownership + "] for vehicle number " + vehicleNumber);
        }
        scrollAndClickOnHiddenElement(vehicleOwnershipButton);
        Log.info("For Vehicle numbered " + vehicleNumber + " Ownership is set to : " + ownership);

    }

    private void setVehicleAcquiredRange(Vehicle vehicleInfo, int vehicleNumber) throws Exception {
        String vehicleAcquiredGroupXpath = VEHICLE_ACQUIRED_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE;
        if (isElementPresent(pwXPath(vehicleAcquiredGroupXpath + DATE_INPUT_FIELD_XPATH), 3)) {
            // always selecting previous years DEC as the purchase date
            Locator datePicker = locator(pwXPath(vehicleAcquiredGroupXpath + VEHICLE_ACQUIRED_DATE_PICKER));
            scrollToElement(datePicker);
            clickOnHiddenElement(waitElementBeVisible(datePicker));
            String previousYear = String.valueOf(LocalDateTime.now().getYear() - 1);
            String xpathForPreviousYear = String.format("//button[contains(@class, 'mat-calendar-body-cell') and @aria-label='%s']", previousYear);
            if (!isElementPresent(pwXPath(xpathForPreviousYear))) {
                waitAndClickElement(locator(pwCss("button[aria-label='Next 24 years']")));
            }
            clickOnHiddenElement(waitElementBeVisible(locator(pwXPath(xpathForPreviousYear))));
            Locator month = locator(pwXPath("//mat-year-view//td[contains(.,'DEC')]//button"));
            clickOnHiddenElement(waitElementBeVisible(month));
            dismissVehicleDatepickerIfOpen();

        } else {
            Locator vehicleAcquiredRangeButton = null;
            int vehicleYear = Integer.parseInt(vehicleInfo.getVehicleYear());
            int purchaseYear = getPurchaseYear(vehicleInfo, vehicleYear);
            int currentYear = LocalDateTime.now().getYear();
            int acquired = currentYear - purchaseYear;
            switch (currentYear - vehicleYear) {
                case -1:
                case 0:
                case 1:
                case 2:
                    break;
                case 3:
                case 4:
                case 5:
                    if (acquired < 2) {
                        vehicleAcquiredRangeButton = locator(pwXPath(vehicleAcquiredGroupXpath + BUTTON_ONE));
                    } else {
                        vehicleAcquiredRangeButton = locator(pwXPath(vehicleAcquiredGroupXpath + BUTTON_TWO));
                    }
                    scrollAndClickOnElement(vehicleAcquiredRangeButton);
                    break;
                default:
                    if (acquired < 2) {
                        vehicleAcquiredRangeButton = locator(pwXPath(vehicleAcquiredGroupXpath + BUTTON_ONE));
                    } else if (acquired > 5) {
                        vehicleAcquiredRangeButton = locator(pwXPath(vehicleAcquiredGroupXpath + BUTTON_THREE));
                    } else {
                        vehicleAcquiredRangeButton = locator(pwXPath(vehicleAcquiredGroupXpath + BUTTON_TWO));
                    }
                    scrollAndClickOnElement(vehicleAcquiredRangeButton);
                    break;
            }
        }
    }

    private void dismissVehicleDatepickerIfOpen() {
        Locator datepickerBackdrop = locator(pwCss("div.cdk-overlay-backdrop[class*='mat-datepicker'][class*='cdk-overlay-backdrop-showing']"));
        if (!isElementVisible(datepickerBackdrop, 1)) {
            return;
        }
        pressEscKey();
        waitElementBeInvisible(datepickerBackdrop);
    }

    private void setVehicleParkingLocation(AutoApplicant applicant, int vehicleNumber) throws Exception {
        String vehicleParkAtOtherLocationGroupXpath = VEHICLE_PARKED_LOCATION_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE;
        Locator parkAtOtherLocationButton = locator(pwXPath(vehicleParkAtOtherLocationGroupXpath + GENERIC_RADIO_BUTTON_TWO));
        scrollAndClickOnHiddenElement(parkAtOtherLocationButton);
        Locator garagingAddressEntryField = locator(pwXPath(vehicleParkAtOtherLocationGroupXpath + GARAGING_ADDRESS_ENTRY_FIELD_XPATH));
        scrollElementToMiddle(garagingAddressEntryField);
        waitAndClickElement(garagingAddressEntryField);
        if (!getTextFromElement(garagingAddressEntryField).isEmpty()) {
            sendKeysToElement(garagingAddressEntryField, Keys.ESCAPE);
        }
        enterGoogleAddressAce(garagingAddressEntryField, applicant.getGaragingAddress(), EMPTY_STRING, EMPTY_STRING);
        waitForUiSettled();

        setTownDropDown(vehicleNumber);

    }

    private void setTownDropDown(int vehicleNumber) throws Exception {
        String townSelectDropDownXpath = VEHICLE_PARKED_LOCATION_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + "//div[contains(@class,'auto-vehicles-review__town_select')]//mat-select";
        if (isElementPresent(pwXPath(townSelectDropDownXpath), 5)) {
            Locator townDropDown = locator(pwXPath(townSelectDropDownXpath));
            waitAndClickElement(townDropDown);
            List<Locator> dropDownOptions = locators(pwXPath("//mat-option"));
            waitAndClickElement(dropDownOptions.get(new Random().nextInt(dropDownOptions.size())));
            waitForUiSettled();
        }
    }

    public void setTheftRecoverySystemDiscount(Vehicle vehicleInfo, int vehicleNumber) throws Exception {
        Locator trsCheckbox = locator(pwXPath(VEHICLE_INFORMATION_XPATH + "[" + vehicleNumber + "]" + THEFT_RECOVERY_SYSTEM_CHECKBOX_XPATH));
        scrollToElement(trsCheckbox);
        setCheckboxTo(trsCheckbox, vehicleInfo.isTheftRecoverySystem());
    }

    private void validateVehicleListing(Vehicle vehicleInfo, Locator vehicleDescriptionElement, FarmersSoftAssert fsa) throws Exception {
        String vehicleMake = vehicleInfo.getVehicleMake();
        String vehicleModel = vehicleInfo.getVehicleModel();
        String vehicleYear = vehicleInfo.getVehicleYear();
        if (vehicleInfo.isUseVIN()) {
            List<AppStoreVehicle> vehicles = this.getSessionStorageAppStore().getAuto().getVehicles();
            List<AppStoreVehicle> filteredVehicles = vehicles.stream().filter(each -> {
                        String vin = null;
                        try {
                            vin = each.getVin();
                        } catch (Exception e) {
                            Log.error(e.getMessage());
                        }
                        if (!StringUtils.isEmpty(vin)) {
                            return vin.equals(vehicleInfo.getVehicleVIN());

                        } else {
                            return false;
                        }
                    }
            ).collect(Collectors.toList());
            if (!filteredVehicles.isEmpty()) {
                AppStoreVehicle vehicle = filteredVehicles.get(0);
                vehicleMake = vehicle.getMakeDesc();
                vehicleYear = vehicle.getYear();
                vehicleModel = vehicle.getModelDesc();
            }
        } else {
            vehicleMake = vehicleInfo.getVehicleMake();
            vehicleModel = vehicleInfo.getVehicleModel();
            vehicleYear = vehicleInfo.getVehicleYear();
        }
        vehicleModel = vehicleInfo.getVehicleModel().contains("QUATTRO") ? "QUAT" : vehicleModel;
        fsa.assertEquals(getTextFromElement(vehicleDescriptionElement), vehicleYear + SPACE + vehicleMake + SPACE + vehicleModel);
    }

    private void validateDisplayedVehicleUsage(String vehicleUsage, int vehicleNumber, FarmersSoftAssert fsa) throws Exception {
        if (vehicleUsage.contains(RIDESHARE)) {
            Locator rideshareForBusinessCheckbox = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + VEHICLE_RIDESHARE_CHECKBOX_XPATH));
            fsa.assertTrue(rideshareForBusinessCheckbox.isChecked(), "Rideshare checkbox is selected");
            vehicleUsage = BUSINESS;
        }
        if (isElementPresentByXPath(USAGE_RADIO_BUTTON_ONE)) {
            if (vehicleUsage.equals(PERSONAL)) {
                Locator vehiclePersonalUsageRadioButton = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + USAGE_RADIO_BUTTON_ONE));
                fsa.assertTrue(vehiclePersonalUsageRadioButton.isChecked(), "Vehicle Personal Usage is selected for the following vehicle number = " + vehicleNumber);
            } else {
                Locator vehicleBusinessUsageRadioButton = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + USAGE_RADIO_BUTTON_TWO));

                fsa.assertTrue(vehicleBusinessUsageRadioButton.isChecked(), "Vehicle Business Usage is selected for the following vehicle number = " + vehicleNumber);
            }
        } else {
            Locator vehicleUsageButton = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + SELECTED_BUTTON_XPATH));
            fsa.assertEquals(getTextFromElement(vehicleUsageButton), vehicleUsage, "Vehicle usage button text for vehicle number: " + vehicleNumber);
            //waitAndClickElement(vehicleUsageButton);
        }
        Locator usageLabel = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + GROUP_LABEL_XPATH));
        Locator usageHelpTitle = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + VEHICLE_USAGE_HELP_TITLE_XPATH));
        Locator personalUsageHelpText = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + PERSONAL_USAGE_HELP_CONTENT_XPATH));
        Locator businessUsageHelpText = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + BUSINESS_USAGE_HELP_CONTENT_XPATH));
        fsa.assertEquals(getTextFromElement(usageLabel), "Primarily used for" + addToText);
        fsa.assertEquals(getTextFromElement(usageHelpTitle), "Vehicle usage");
        fsa.assertEquals(getTextFromElement(personalUsageHelpText), "Select \"Personal\" if you commute or use the vehicle for pleasure.");
        fsa.assertEquals(getTextFromElement(businessUsageHelpText), "Select \"Business\" if you drive for work, sales, etc.");
        if (vehicleUsage.equals(RIDESHARE)) {
            Locator rideshareForBusinessUsageHelpText = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + VEHICLE_RIDESHARE_FOR_BUSINESS_HELP_CONTENT_XPATH));
            fsa.assertEquals(getTextFromElement(rideshareForBusinessUsageHelpText), "Select if you also drive for work. For example, if you're a real estate agent, you make sales calls, meet clients, etc. in addition to Ridesharing.");
        }
    }

    private void validateDisplayedVehicleOwnership(String vehicleOwnership, int vehicleNumber, FarmersSoftAssert fsa) throws Exception {
        Locator vehicleOwnershipButton = locator(pwXPath(VEHICLE_OWNERSHIP_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + SELECTED_BUTTON_XPATH));
        fsa.assertEquals(getTextFromElement(vehicleOwnershipButton), vehicleOwnership, "Vehicle ownership with the vehicle number => " + vehicleNumber);
        waitAndClickElement(vehicleOwnershipButton);
        Locator ownershipHelpTitle = locator(pwXPath(VEHICLE_OWNERSHIP_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + OWNERSHIP_HELP_TITLE_XPATH));
        Locator ownedHelpText = locator(pwXPath(VEHICLE_OWNERSHIP_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + OWNED_HELP_CONTENT_XPATH));
        Locator leasedHelpText = locator(pwXPath(VEHICLE_OWNERSHIP_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + LEASED_HELP_CONTENT_XPATH));
        Locator financedHelpText = locator(pwXPath(VEHICLE_OWNERSHIP_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + FINANCED_HELP_CONTENT_XPATH));
        Locator ownershipLabel = locator(pwXPath(VEHICLE_OWNERSHIP_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + GROUP_LABEL_XPATH));
        fsa.assertEquals(getTextFromElement(ownershipLabel), "Ownership" + addToText, "Ownership toggle/radiobutton label");
        fsa.assertEquals(getTextFromElement(ownershipHelpTitle), "Ownership", "Ownership help info title");
        fsa.assertEquals(getTextFromElement(ownedHelpText), "Owned: Select \"Owned\" if you are the owner of this car outright, without a loan or lease.");
        fsa.assertEquals(getTextFromElement(leasedHelpText), "Leased: Most finance companies require minimum coverages. That's why it's important you select the correct ownership type. Select \"Leased\" if you have a lease agreement for this car.");
        fsa.assertEquals(getTextFromElement(financedHelpText), "Financed: Most finance companies require minimum coverages. That's why it's important you select the correct ownership type. Select \"Financed\" if you are currently making loan payments on this car.");
    }

    private void validateDisplayedVehicleAcquiredRange(Vehicle vehicleInfo, int vehicleNumber, FarmersSoftAssert fsa) throws Exception {
        boolean doLabelAndHelpCheck = true;
        int currentYear = LocalDateTime.now().getYear();
        int vehicleYear = Integer.parseInt(vehicleInfo.getVehicleYear());
        int purchaseYear = getPurchaseYear(vehicleInfo, vehicleYear);
        int acquired = currentYear - purchaseYear;
        if (!isElementDisplayed(pwXPath(VEHICLE_ACQUIRED_GROUP_XPATH + (vehicleNumber) + CLOSE_XPATH_NODE + DATE_INPUT_FIELD_XPATH))) {
            List<Locator> listOfVehicleAquiredRangeButton = locators(pwXPath(VEHICLE_ACQUIRED_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + SELECTED_BUTTON_XPATH + "//span[1]"));
            if (currentYear - vehicleYear <= 2) {
                // No acquired buttons for cars 2 years old or newer.
                fsa.assertTrue(listOfVehicleAquiredRangeButton.isEmpty(), "Acquired buttons should be empty for new vehicles (2 year or newer)");
                doLabelAndHelpCheck = false;
            } else if (acquired < 2) {
                fsa.assertEquals(getTextFromElement(listOfVehicleAquiredRangeButton.get(1)), "Less than 2 years ago");
            } else if (acquired > 5) {
                fsa.assertEquals(getTextFromElement(listOfVehicleAquiredRangeButton.get(1)), "Over 5 years ago");
            } else {
                fsa.assertEquals(getTextFromElement(listOfVehicleAquiredRangeButton.get(0)), "2-5 yrs ago");
            }

        }
        if (doLabelAndHelpCheck) {
            waitAndClickElement(locator(pwXPath(VEHICLE_ACQUIRED_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE)));
            Locator acquiredLabel = locator(pwXPath(VEHICLE_ACQUIRED_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + GROUP_LABEL_XPATH));
            Locator acquiredHelpTitle = locator(pwXPath(VEHICLE_ACQUIRED_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + ACQUIRED_HELP_TITLE_XPATH));
            Locator acquiredHelpText = locator(pwXPath(VEHICLE_ACQUIRED_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + ACQUIRED_HELP_CONTENT_XPATH));
            fsa.assertTrue(Arrays.asList("When did you acquire this vehicle?" + addToText, "When did you get this vehicle?" + addToText).contains(getTextFromElement(acquiredLabel)));
            fsa.assertEquals(getTextFromElement(acquiredHelpTitle), "When did you get this vehicle");
            fsa.assertEquals(getTextFromElement(acquiredHelpText), "Knowing when you got your vehicle will help ensure that your insurance rate reflects your usage of the vehicle and not the previous owner's.");
        }
    }

    private int getPurchaseYear(Vehicle vehicleInfo, int vehicleYear) {
        String purchaseDate = StringUtils.trimToEmpty(vehicleInfo.getPurchaseDate());
        if (purchaseDate.length() >= 4) {
            String digitsOnly = purchaseDate.replaceAll("[^0-9]", EMPTY_STRING);
            if (digitsOnly.length() >= 4) {
                try {
                    return Integer.parseInt(digitsOnly.substring(digitsOnly.length() - 4));
                } catch (NumberFormatException exception) {
                    Log.warn("Unable to parse vehicle purchase year from [" + purchaseDate + "]. Falling back to vehicle year.");
                }
            }
        }
        return vehicleYear;
    }

    public void validateVehicleParkingLocation(Vehicle vehicleInfo, String parkingAddress, GrgingAddr grgingAddr, int vehicleNumber, FarmersSoftAssert fsa) throws Exception {
        if (vehicleInfo.isParkInResidentAddress()) {
            Locator vehicleParkedAtResidence = locator(pwXPath(VEHICLE_PARKED_LOCATION_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + GENERIC_RADIO_BUTTON_ONE));
            fsa.assertTrue(vehicleParkedAtResidence.isChecked(), "Vehicle parked at residence radio button is selected");
        } else {
            Locator vehicleParkedAtResidence = locator(pwXPath(VEHICLE_PARKED_LOCATION_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + GENERIC_RADIO_BUTTON_TWO));
            fsa.assertTrue(vehicleParkedAtResidence.isChecked(), "Vehicle parked at residence radio button is selected");
            fsa.assertEquals(getTextFromElement(locator(pwXPath(VEHICLE_PARKED_LOCATION_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + GENERIC_RADIO_BUTTON_TWO_LABEL))), "Other location");

            Locator garagingAddressEntryField = locator(pwXPath(VEHICLE_PARKED_LOCATION_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + GARAGING_ADDRESS_ENTRY_FIELD_XPATH));
            fsa.assertTrue(garagingAddressEntryField.getAttribute(VALUE).equals(grgingAddr.getStreet()), "Garaging address street field value matches expected parking address");

            Locator garagingAddressCityEntryField = locator(pwXPath(VEHICLE_PARKED_LOCATION_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + GARAGING_ADDRESS_CITY_ENTRY_FIELD_XPATH));
            fsa.assertTrue(garagingAddressCityEntryField.getAttribute(VALUE).equals(grgingAddr.getCity()), "Garaging address city field value matches expected parking address");

            Locator garagingAddressStateEntryField = locator(pwXPath(VEHICLE_PARKED_LOCATION_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + GARAGING_ADDRESS_STATE_ENTRY_FIELD_XPATH));
            fsa.assertTrue(garagingAddressStateEntryField.getAttribute(VALUE).equals(grgingAddr.getState()), "Garaging address state field value matches expected parking address");

            Locator garagingAddressZipCodeEntryField = locator(pwXPath(VEHICLE_PARKED_LOCATION_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + GARAGING_ADDRESS_ZIP_CODE_ENTRY_FIELD_XPATH));
            fsa.assertTrue(garagingAddressZipCodeEntryField.getAttribute(VALUE).equals(grgingAddr.getZip()), "Garaging address zip field value matches expected parking address");

            Locator garagingUnitEntryField = locator(pwXPath(VEHICLE_PARKED_LOCATION_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + GARAGING_ADDRESS_UNIT_ENTRY_FIELD_XPATH));
            fsa.assertTrue(garagingUnitEntryField.getAttribute(VALUE).equals(grgingAddr.getApartment()), "Garaging address apartment field value matches expected parking address");
        }

        Locator parkedAtLabel = locator(pwXPath(VEHICLE_PARKED_LOCATION_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + GROUP_LABEL_XPATH));
        waitAndClickElement(parkedAtLabel);
        Locator parkedAtHelpTitle = locator(pwXPath(VEHICLE_PARKED_LOCATION_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + PARKED_AT_HELP_TITLE_XPATH));
        Locator parkedAtHelpText = locator(pwXPath(VEHICLE_PARKED_LOCATION_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + PARKED_AT_HELP_CONTENT_XPATH));
        fsa.assertEquals(getTextFromElement(parkedAtLabel), "Where is the vehicle usually parked?" + addToText);
        fsa.assertEquals(getTextFromElement(parkedAtHelpTitle), "Parking location");
        fsa.assertEquals(getTextFromElement(parkedAtHelpText), "Your parking location, also known as \"garaging address\" is used to calculate your rate. If you select \"Other location\", we will need additional information.");
        Log.info("Vehicle Review Page Parked At Validation");
    }

    private boolean validateTheftRecoverySystemSelected(boolean isTheftRecoverySelected, int vehicleNumber) throws Exception {
        boolean passed = true;
        Locator trsCheckbox = locator(pwXPath(VEHICLE_INFORMATION_XPATH + "[" + vehicleNumber + "]" + THEFT_RECOVERY_SYSTEM_CHECKBOX_XPATH));
        waitForUiSettled();
        passed = (isTheftRecoverySelected == trsCheckbox.isChecked());
        if (!passed) {
            Log.error("Failed validateTheftRecoverySystemSelected for vehicle " + vehicleNumber + " should have been " + isTheftRecoverySelected);
        }
        return passed;
    }

    public void validateMaxFiveVehiclesDisplayed_VehicleReviewPage(AutoApplicant applicant) throws Exception {
        int intVehicleCount = getEleCount(lblVIN.all(), 5);
        testStepAssert(Integer.toString(intVehicleCount), Integer.toString(limitVehicleCountToMaxAllowed(applicant.getStateCode(), 5)), "Expected:Max of 5 vehicles should be displayed in vehicles review page.Actual: (" + Integer.toString(intVehicleCount) + ") vehicles displayed in vehicles review page");
    }

    public boolean isOnEditVehicleFrame_VehicleReviewPage() {
        return isElementVisible(lblEditVehicleHeader, 5);
    }

    public void validateSidesheetDisplayedForEachVehicles_VehicleReviewPage() throws Exception {
        int intVehicleCount = getEleCount(lblVIN.all(), 5);
        Log.info("No of vehicles displayed in vehicles review page: (" + intVehicleCount + ")");
        int intCntr = 0;
        for (int i = 1; i <= intVehicleCount; i++) {
            clickEditBtn_VehicleReviewPage(Integer.toString(i - 1));
            if (isOnEditVehicleFrame_VehicleReviewPage()) {
                intCntr++;
            }
            validateHowToFindSection();
            waitAndClickElement(closeIcon);
        }
        testStepAssert(Integer.toString(intCntr), Integer.toString(intVehicleCount), "Expected:Edit Vehicle sidesheet should be displayed for each vehicle when Edit is clicked.Actual:Edit Vehicle sidesheet is displayed for (" + Integer.toString(intCntr) + ") vehicles when Edit is clicked");
    }

    private void validateHowToFindSection() throws Exception {
        clickVinToggleIfNotClicked();
        scrollAndClickOnHiddenElement(waitElementBeVisible(whereICanFindThisLink));
        waitElementBeVisible(vinHelperHeader);
        testStepAssert(isElementPresent(pwXPath(WhoShouldWeInsurePage.VIN_HELPER_IMAGE_ONE), 2), "Vin user guide image one is displayed");
        testStepAssert(isElementPresent(pwXPath(WhoShouldWeInsurePage.VIN_HELPER_IMAGE_TWO), 2), "Vin user guide image two is displayed");
        testStepAssert(isElementPresent(pwXPath(WhoShouldWeInsurePage.VIN_HELPER_IMAGE_THREE), 2), "Vin user guide image three is displayed");
        testStepAssert(getTextFromElement(vinHelperHeaderLabel), "How to find the VIN", "How to find vin dialog header validation");
        waitAndClickElement(backToVinButton);
    }

    private void clickVinToggleIfNotClicked() {
    	if (isButtonNotSelected(vinToggleOnTheSideSheet)) {
    		scrollAndClickOnElement(vinToggleOnTheSideSheet);
    	}
    }

    private void validateVehicleVINMasking(AppStoreVehicle vehicleInfo, Locator maskedOrNoMasked, FarmersSoftAssert fsa) {
        boolean isUseVin = !StringUtils.isBlank(vehicleInfo.getVin());
        String lastThreeDigitsOfVin = isUseVin ? vehicleInfo.getVin().substring(14) : null;
        //using getText to keep unicode chars
        String vinDisplayedValue = maskedOrNoMasked.innerText().strip();
        String expectedMaskedVin = isUseVin? "\u2022\u2022\u2022" + lastThreeDigitsOfVin : "---";
        fsa.assertEquals(vinDisplayedValue, expectedMaskedVin, "VIN display validation.");
    }

    private void validateSideSheetVIN(AppStoreVehicle vehicleInfo, Locator sideSheetVINInputField, FarmersSoftAssert fsa) {
        boolean isUseVin = !StringUtils.isBlank(vehicleInfo.getVin());
        String lastThreeDigitsOfVin = isUseVin ? vehicleInfo.getVin().substring(14) : null;

        if (isUseVin) {
            String expectedSideSheetMaskedVin = "**************" + lastThreeDigitsOfVin;
            fsa.assertEquals(sideSheetVINInputField.getAttribute("value"), expectedSideSheetMaskedVin, "VIN masking validation failed on the side sheet.");
            fsa.assertTrue(sideSheetVINInputField.isEnabled(), "Side sheet VIN input field should be enabled.");
        }
    }

    public void validateYMMAndVINMaskedDisplayedForEachVehicles_VehicleReviewPage(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        List<AppStoreVehicle> vehicles = getSessionStorageAppStore().getAuto().getVehicles();
        int numberOfVehicles = limitVehicleCountToMaxAllowed(applicant.getStateCode(), vehicles.size());

        for (int i = 0; i < numberOfVehicles; i++) {
            AppStoreVehicle vehicleInfo = vehicles.get(i);
            Locator editButton = locator(pwXPath(String.format(EDIT_VEHICLE_XPATH, i)));
            Locator maskedOrNoMasked = locator(pwXPath(String.format(MASKED_OR_NO_VIN_XPATH, i)));

            scrollToElement(maskedOrNoMasked);
            validateVehicleVINMasking(vehicleInfo, maskedOrNoMasked, fsa);

            scrollAndClickOnHiddenElement(editButton);
            fsa.assertTrue(isElementDisplayed(vehicleSideSheetHeader, 3), "Side sheet should open when edit is clicked.");

            validateSideSheetVIN(vehicleInfo, sideSheetVINInputField, fsa);
            waitAndClickElement(closeIcon);
        }
    }

    public void clickEditBtn_VehicleReviewPage(String strVehicleNo) throws Exception {
        Locator eleEditVehiclelnk = generateXpath(EDIT_VEHICLE_XPATH, "%d", strVehicleNo);
        waitAndClickElement(eleEditVehiclelnk);
    }

    public void validateDateOfPurchase_VehicleReviewPage() throws Exception {
        String strFirstVehicleHeader = getTextFromElement(lblFirstVehicleHeader);
        String[] arrTemp = strFirstVehicleHeader.split(" ");
        String strVehicleModelYear = arrTemp[0].trim();
        if (!isElementPresent(pwXPath("//button[@aria-label='Open calendar']"), 4)) {
            return;
        }
        waitAndClickElement(btnOpenDateOfPurchaseCalendar);
        String strActualStartYear = getTextFromElement(lblFirstEnabledDateOfPurchaseCalendar).trim();
        int intExpectedStartYear = Integer.parseInt(strVehicleModelYear) - 2;
        testStepAssert(strActualStartYear, Integer.toString(intExpectedStartYear), "Expected:Date Of Purchase should be enabled from YEAR: (" + Integer.toString(intExpectedStartYear) + ") for vehicle model YEAR: (" + strVehicleModelYear + ").Actual:Date Of Purchase is enabled from YEAR:(" + strActualStartYear + ")");
    }

    public void validateCommuteToggle(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {

        // Repurposing this method for : US1004951: [Continued] FFQ Ace enhancements on the vehicle review page

        List<Vehicle> vehicles = applicant.getVehicles();

        for (int i = 1; i <= vehicles.size(); i++) {
            Locator commuteToggle = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + i + CLOSE_XPATH_NODE + BUTTON_ONE));
            Locator personalToggle = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + i + CLOSE_XPATH_NODE + BUTTON_TWO));
            Locator businessToggle = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + i + CLOSE_XPATH_NODE + BUTTON_THREE));

            //Commute toggle section validation
            fsa.assertEquals(getTextFromElement(commuteToggle), COMMUTE, "Commute toggle exists");
            fsa.assertEquals(getTextFromElement(personalToggle), PERSONAL, "Commute toggle exists");
            fsa.assertEquals(getTextFromElement(businessToggle), BUSINESS, "Commute toggle exists");
            testStep("Validate should display one more tab \"Commute\" tab for \"Vehicle usage\"", false);
            List<Locator> toggles = Arrays.asList(commuteToggle, businessToggle, personalToggle);
            Collections.shuffle(toggles);
            validateErrorMessagesForCommuteToggle(i, toggles.get(0), fsa);
            if (isADATestingEnabled()) {
                return;
            }
            waitAndClickElement(toggles.get(0));
            String milesYouDriveOneWayInputXpath = pwXPath(VEHICLE_USAGE_GROUP_XPATH + i + CLOSE_XPATH_NODE + MILES_YOU_DRIVE_ONE_WAY_INPUT_XPATH);
            String howOftenDoYouCommuteDropdownXpath = pwXPath(VEHICLE_USAGE_GROUP_XPATH + i + CLOSE_XPATH_NODE + HOW_OFTEN_DO_YOU_COMMUTE_DROPDOWN_XPATH);
            String milesDrivenPerYearXpath = pwXPath(VEHICLE_USAGE_GROUP_XPATH + i + CLOSE_XPATH_NODE + MILES_DRIVEN_PER_YEAR_INPUT_XPATH);
            fsa.assertTrue(isElementPresent(milesDrivenPerYearXpath), MILES_DRIVEN_PER_YEAR + " ---element is displayed");
            fsa.assertFalse(isElementPresent(milesYouDriveOneWayInputXpath), MILES_YOU_DRIVE_ONE_WAY + " ---element is not supposed to display");
            testStep("Validate if user select \"commute\" means should display 3 miles related questions", false);
            fsa.assertFalse(isElementPresent(howOftenDoYouCommuteDropdownXpath), HOW_OFTEN_DO_YOU_COMMUTE + " question should not be displayed");
            testStep("Validate \"Miles driven per year\" field user able to customize the filed only with numbers[max: 6 digits]", false);
            fsa.assertEquals(getAttributeData(locator(milesDrivenPerYearXpath), MAXLENGTH), "6", "Miles driver per year input field max allowed digit is 6");

        }
    }

    private void validateHelpInfoIconWithCommute(int vehicleNumber, FarmersSoftAssert fsa) throws Exception {
        String selectCommuteExpectedText = "Select \"Commute\" if you commute to/from school/work.";
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(vehicleUsageMatIcon);
            fsa.assertEquals(getTextFromElement(locator(pwXPath("//h1[@aria-label='Vehicle Usage']"))), "Used For");
            fsa.assertEquals(getTextFromElement(locator(pwXPath("//h2[@class='model-caption-sub-title'][1]"))), "Commute vehicle usage");
            fsa.assertEquals(getTextFromElement(locator(pwXPath("//h2[@class='model-caption-sub-title'][2]"))), "Personal vehicle usage");
            fsa.assertEquals(getTextFromElement(locator(pwXPath("//h2[@class='model-caption-sub-title'][3]"))), "Business vehicle usage");
            fsa.assertEquals(getTextFromElement(locator(pwXPath("//h2[@class='model-caption-sub-title'][4]"))), "Rideshare vehicle usage");
            fsa.assertEquals(getTextFromElement(locator(pwXPath("//p[@class='model-caption-text'][1]"))), selectCommuteExpectedText);
            fsa.assertEquals(getTextFromElement(locator(pwXPath("//p[@class='model-caption-text'][2]"))), "Select \"Personal\" if you commute or use the vehicle for pleasure.");
            fsa.assertEquals(getTextFromElement(locator(pwXPath("//p[@class='model-caption-text'][3]"))), "Select \"Business\" if you drive for work, sales, etc.");
            fsa.assertEquals(getTextFromElement(locator(pwXPath("//p[@class='model-caption-text'][4]"))), "Check \"Rideshare\" if you drive for Uber, Lyft, etc.");
            testStep("Validate help info section for Commute on Mobile", true);
            waitAndClickElement(btnClose);
        } else {
            Locator usageHelpTitle = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + VEHICLE_USAGE_HELP_TITLE_XPATH));
            Locator commuteHelpInfo = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + PERSONAL_USAGE_HELP_CONTENT_XPATH));
            Locator personalsUsageHelpText = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + BUSINESS_USAGE_HELP_CONTENT_XPATH));
            Locator businessUsageHelpText = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + ADDITIONAL_USAGE_HELP_CONTENT_XPATH));
            Locator ridesShare = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + VEHICLE_RIDESHARE1_FOR_BUSINESS_HELP_CONTENT_XPATH));

            fsa.assertEquals(getTextFromElement(usageHelpTitle), "Vehicle usage");
            fsa.assertEquals(getTextFromElement(commuteHelpInfo), selectCommuteExpectedText);
            fsa.assertEquals(getTextFromElement(businessUsageHelpText), "Select \"Business\" if you drive for work, sales, etc.");
            fsa.assertEquals(getTextFromElement(personalsUsageHelpText), "Select \"Personal\" if you use the vehicle for pleasure.");
            fsa.assertEquals(getTextFromElement(ridesShare), "Check \"Rideshare\" if you drive for Uber, Lyft, etc.");
            testStep("Validate help info section for Commute on Browser", false);
        }
    }

    private void validateErrorMessagesForCommuteToggle(int vehicleNumber, Locator commuteToggle, FarmersSoftAssert fsa) throws Exception {
        testStep("Validate if user enter \"0\" means should display error message \"Miles driven per year\" fields", false);
        String thisIsNotAValidEntry = "This is not a valid entry.";
        String expectedMilesDrivenPerYearErrorMessage1 = "Please enter the miles you drive per year.";
        //String expectedCommutePreferenceErrorMessage = "Please enter the number of commutes per week.";
        String expectedMilesDrivenPerYearErrorMessage2 = "Please enter valid annual mileage.";
        waitAndClickElement(commuteToggle);
        Locator milesDrivenPerYearInput = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + MILES_DRIVEN_PER_YEAR_INPUT_XPATH));
        clearOutFieldUsingBackSpace(milesDrivenPerYearInput);
        clickContinueButton();
        Locator milesDrivenPerYearError = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + MILES_DRIVEN_PER_YEAR_ERROR_XPATH));
        fsa.assertEquals(getTextFromElement(milesDrivenPerYearError), expectedMilesDrivenPerYearErrorMessage1, "Error message when miles per year is not provided");
        sendKeysToElement(milesDrivenPerYearInput, "0" + Keys.TAB);
        clickContinueButton();
        String displayedErrorMessage = getTextFromElement(waitElementBeVisible(milesDrivenPerYearError));
        List<String> expectedErrorMessages = Arrays.asList(expectedMilesDrivenPerYearErrorMessage1, expectedMilesDrivenPerYearErrorMessage2);
        fsa.assertTrue(expectedErrorMessages.contains(displayedErrorMessage), "Error message annual miles per year");
    }

    public void setGarageAddressesToDefault() throws Exception {
        int numberOfElements = defaultGarageRadioButtons.count();
        for (int i = 0; i < numberOfElements; i++) {
            scrollAndClickOnHiddenElement(defaultGarageRadioButtons.nth(i));
        }
    }

    public void setVehicleUsagesToPersonal() throws Exception {
        List<Locator> personalToggles = getPersonalToggles().all();
        for (Locator personalToggle : personalToggles) {
            scrollAndClickOnElement(personalToggle);
        }
    }

    public void validateADA_VehicleReviewPage() throws Exception {
        if (!isADATestingEnabled()) return;
        isOnVehiclesReviewPage();
        // validate edit side sheet
        for (Locator editButton : editButtons.all()) {
            waitAndClickElement(editButton);
            performADATesting(this.getClass().getSimpleName() + "_EditVehicleSideSheet", MARKETING_IT, ACE_AUTO);
            waitAndClickElement(closeIcon);
        }
        // expose other garage address fields
        for (Locator otherLocationRadioButton : otherLocationRadioButtons.all()) {
            scrollAndClickOnHiddenElement(otherLocationRadioButton);
        }
        // expose datePickers
        for (Locator datePicker : datePickers.all()) {
            waitAndClickElement(datePicker);
        }

        clickOnContinueButton();
        performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);

        // set values to default for garaging address
        for (Locator defaultGarageButton : defaultGarageRadioButtons.all()) {
            scrollAndClickOnHiddenElement(defaultGarageButton);
        }
        refreshPage();
        isOnVehiclesReviewPage();
    }

    public List<String> getDescriptionsOfDisplayedVehicles() throws Exception {
        List<Locator> displayedVehicles = locators(pwXPath(VEHICLE_DESCRIPTION_XPATH));
        return displayedVehicles.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public void clickOnRideshareCheckbox_VehicleReviewPage(int vehicleNumber) throws Exception {
        String strRideshareChk = "//div[@id='vehicles-review_vehicleUsage%d']//div[contains(@class,'rideshare-business-checkbox')]//mat-checkbox//input[@type='checkbox']";
        Locator rideShareCheckbox = generateXpath(strRideshareChk, "%d", Integer.toString(vehicleNumber));
        if (rideShareCheckbox != null) {
            scrollAndClickOnElement(rideShareCheckbox);
        }
    }


    public void validateAntiTheftCheckbox_VehicleReviewPage(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        fsa.assertFalse(isElementDisplayed(antiTheftCheckBox, 5), "Theft Recovery System checkbox is available for the selected state");
        fsa.assertFalse(isAntiTheftRecoverySystemEnabledState(applicant.getStateCode()), "Given " + applicant.getStateCode() + " state is enabled for AntiTheftRecoverySystem discount");
    }

    public void validateAlternativeFuelCheckbox_VehicleReviewPage(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        fsa.assertFalse(isElementDisplayed(alternativeFuelCheckBox, 5), "Alternative Fuel checkbox is available for the selected state");
    }

    public void validateRideShareCard(FarmersSoftAssert fsa, int vehicleNumber) throws Exception {
        wait.until(Conditions.visible(pwXPath(RIDESHARE_CARD_BULB_ICON_XPATH)));
        String lightBulbIconXpath = VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + RIDESHARE_CARD_BULB_ICON_XPATH;
        Locator rideShareCardTitle = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + RIDESHARE_CARD_TITLE));
        Locator rideShareCardDescription = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + vehicleNumber + CLOSE_XPATH_NODE + RIDESHARE_CARD_DESCRIPTION));
        fsa.assertTrue(isElementDisplayed(pwXPath(lightBulbIconXpath)));
        fsa.assertEquals(getTextFromElement(rideShareCardTitle), "Did you know?");
        fsa.assertEquals(getTextFromElement(rideShareCardDescription), "Farmers offers rideshare add-on coverage. At least one driver needs to be designated.");
    }

    public void validateBDQSpecificRule(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        //US908079: BDQ Ace - "Your Vehicles" page
        List<Locator> vehicleAcquiredGroupElements = locators(pwXPath("//div[contains(@id,'vehicles-review_vehicleAcquired')]"));
        fsa.assertTrue(vehicleAcquiredGroupElements.isEmpty(), "Vehicle acquire section should not be visible for BDQ flow");
        validateValidateAndFooterForBDQ(fsa, applicant, this);
        fsa.assertFalse(isDiscountSectionDisplayed(), "Discount section should not be displayed on " + this.getClass().getSimpleName());
        validateAgentSectionBDQ(fsa, applicant);
    }

    public boolean isVehicleEditSideSheetOpen() {
        return isElementVisible(vehicleSideSheetHeader, 1);
    }

    public void validateQuestionsInCommuteInVehicleReviewPageForCAState(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        List<Vehicle> vehicles = applicant.getVehicles();
        for (int i = 1; i <= vehicles.size(); i++) {
            Locator personalToggle = locator(pwXPath(VEHICLE_USAGE_GROUP_XPATH + i + CLOSE_XPATH_NODE + BUTTON_ONE));
            String focusedCommuteButtonXpath = pwXPath(VEHICLE_USAGE_GROUP_XPATH + i + CLOSE_XPATH_NODE + FOCUSED_COMMUTE_BUTTON_XPATH);
            String milesYouDriveOneWayInputXpath = pwXPath(VEHICLE_USAGE_GROUP_XPATH + i + CLOSE_XPATH_NODE + MILES_YOU_DRIVE_ONE_WAY_INPUT_XPATH);
            String howOftenDoYouCommuteDropdownXpath = pwXPath(VEHICLE_USAGE_GROUP_XPATH + i + CLOSE_XPATH_NODE + HOW_OFTEN_DO_YOU_COMMUTE_DROPDOWN_XPATH);
            String milesDrivenPerYearXpath = pwXPath(VEHICLE_USAGE_GROUP_XPATH + i + CLOSE_XPATH_NODE + MILES_DRIVEN_PER_YEAR_INPUT_XPATH);
            String commuteSectionQuestionsCountXpath = pwXPath(VEHICLE_USAGE_GROUP_XPATH + i + CLOSE_XPATH_NODE + PERSONAL_SECTION_QUESTIONS_COUNT_XPATH);
            waitAndClickElement(personalToggle);
            fsa.assertTrue(!isElementPresent(focusedCommuteButtonXpath), "Commute button is not supposed to be available");
            fsa.assertEquals(getEleCount(locators(commuteSectionQuestionsCountXpath), 5), 1, " Only 1 question is supposed to be available");
            fsa.assertTrue(isElementPresent(milesDrivenPerYearXpath), MILES_DRIVEN_PER_YEAR + " ---element is not displayed");
            fsa.assertEquals(getAttributeData(locator(milesDrivenPerYearXpath), "value"), "13000", MILES_DRIVEN_PER_YEAR + " --- is supposed to be 13000");
            fsa.assertTrue(!isElementPresent(milesYouDriveOneWayInputXpath), MILES_YOU_DRIVE_ONE_WAY + " ---element is not supposed to display");
            fsa.assertTrue(!isElementPresent(howOftenDoYouCommuteDropdownXpath), HOW_OFTEN_DO_YOU_COMMUTE + " question should not be displayed");
        }
    }
}
