package com.farmers.ffq.ace.hrc.common;








import com.farmers.framework.playwright.Keys;
import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.TimeoutError;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.enums.FfqBundleOptions;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Home.Field;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.SqlDiscount;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCContactInfoBasePage extends AceHRCBasePage {
    private static final String AUTO_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE = "Nice! We'll add an auto bundle discount.";
    private static final String AUTO_BUNDLE_DISCOUNT_REMOVED_MESSAGE = "Auto & Home discount has been removed.";
    private static final String LIFE_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE = "Nice! We'll add a life bundle discount.";
    private static final String LIFE_BUNDLE_DISCOUNT_REMOVED_MESSAGE = "Home & Life discount has been removed.";
    private static final String UMBRELLA_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE = "Nice! We'll add an umbrella bundle discount.";
    private static final String MULTI_POLICY_CEA_DISCOUNT_CONGRATULATIONS_MESSAGE = "Great! We've added the Multi-policy Discount - CEA.";
    private static final String MULTI_POLICY_CEA_DISCOUNT_REMOVED_MESSAGE = "Multi-policy Discount - CEA has been removed.";
    private static final String UMBRELLA_BUNDLE_DISCOUNT_REMOVED_MESSAGE = "Home & Umbrella discount has been removed.";
    private static final String BUSINESS_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE = "Congrats! We added a business bundle discount!";
    private static final String BUSINESS_BUNDLE_DISCOUNT_REMOVED_MESSAGE = "Home & Business discount has been removed.";
    private static final String WATERCRAFT_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE = "Congrats -- we added a watercraft bundle discount!";
    private static final String WATERCRAFT_BUNDLE_DISCOUNT_REMOVED_MESSAGE = "Home & Watercraft discount has been removed.";
    private static final String OFF_ROAD_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE = "How fun -- we'll add an off-road bundle discount!";
    private static final String OFF_ROAD_BUNDLE_DISCOUNT_REMOVED_MESSAGE = "Home & Off-road vehicle discount has been removed.";
    private static final String RV_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE = "Hit the road! We've added an RV bundle discount.";
    private static final String RV_BUNDLE_DISCOUNT_REMOVED_MESSAGE = "Home & RV discount has been removed.";
    private static final String EXPECTED_ESTIMATED_CLOSING_DATE_TITLE = "What is your estimated closing date?";
    private static final String EXPECTED_ESTIMATED_CLOSING_DATE_AREA_LABEL = "Estimated closing date";

    private static final String EXPECTED_POLICY_START_DATE_TITLE = "When would you like your policy to begin?";
    private static final String EXPECTED_DATE_PICKER_AREA_LABEL = "Policy start date";
    protected static final String EXPECTED_EARLY_SHOPPING_INFO_TITLE = "Early shopping discount";
    private static final String MAILING_ADDRESS = "Mailing Address";
    private static final String EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION = "If your policy start date is 7 or more days from today, " +
            "you may get an early shopping discount. You can start your policy up to 60 days in the future.";

    private static final String EXPECTED_EARLY_SHOPPER_CONGRATS_MESSAGE = "Congratulations \u2014 You may get the early shopping discount!";

    private static final String ESTIMATED_CLOSING_DATE_INFO_TITLE = "Estimated closing date";
    private static final String ESTIMATED_CLOSING_DATE_INFO_DESCRIPTION = "For now, provide an estimated date of when you expect escrow to close. We will confirm your actual close date later.";
    private static final String EXPECTED_PERSONAL_INFO_LABEL = "Contact information";
        private Locator lastStepBeforeYourPageHeader = locator(pwCss("h1[class*='tui-h1']"));

        private Locator fewMoreQuestionBeforeYourQuoteHeader = locator(pwXPath("//div[contains(@class,'contact-info-heading-note')]"));
        private Locator policyStartDateOrEstimatedClosingDateTitle = locator(pwXPath("//div[contains(@class,'tooltip-section')]//div"));

        private Locator policyStartDateOrEstimatedClosingDatePlaceHolderText = locator(pwXPath("//app-contact-info//app-date-picker//mat-label"));
        private Locator policyStartDateOrEstimatedClosingDateInputField = locator(pwXPath("//app-contact-info//app-date-picker//input[contains(@class,'text-field-autofill')]"));

        protected Locator earlyDiscountOrEstimatedClosingDateInfoTitle = locator(pwXPath("//div[@id='policyStartDateDiv']//div[@class='discount-info']//div//div"));

        protected Locator earlyDiscountOrEstimatedClosingDateInfoDescription = locator(pwXPath("//div[@id='policyStartDateDiv']//div[@class='discount-info']//div//p"));


        protected Locator earlyShoppingInfoIcon = locator(pwXPath("//div[@id='policyStartDateDiv']//mat-icon[@id='policyStartDateDiv_info']"));
        protected Locator infoModalTitle = locator(pwXPath("//app-model-info-box//h1"));
        protected Locator infoModalText = locator(pwXPath("//app-model-info-box//div/p[contains(@class,'model-caption-text')]"));
        protected Locator infoModalButtonClose = locator(pwXPath("//app-model-info-box//mat-icon[text()='close']"));


        private Locator earlyDiscountCongratulationMessage = locator(pwCss("#auto-contact-info-early-shopper-message-container>div"));

        private Locator earlyDiscountCongratulationGreenCheck = locator(pwXPath("//div[@id='policyContainerDiv']//mat-icon[@alt='Congratulations']"));


    private static final String POLICY_START_DATE_XPATH = "//input[@aria-label='params.ariaLabel']";
        private Locator policyStartOrEstimatedClosingDateDatePicker = locator(pwXPath(POLICY_START_DATE_XPATH));

    private static final String DATEPICKER_TOGGLE_ICON_XPATH = "//mat-datepicker-toggle[contains(@class,'mat-datepicker-toggle')]";
        private Locator datePickerToggleIcon = locator(pwXPath(DATEPICKER_TOGGLE_ICON_XPATH));

        private Locator policyStartOrEstimatedClosingDateInputField = locator(pwXPath("//app-date-picker//input[contains(@class,'form-field-autofill')]"));

        private Locator policyStartOrEstimatedClosingDateDateError = locator(pwXPath("//div[@id='policyStartDateDiv']//mat-error"));

        private Locator selectedDateInDatePickerPopUp = locator(pwXPath("//button[descendant::*[contains(@class,'selected')]]"));

        private Locator selectedMonthYearHeaderInDatePickerPopUp = locator(pwXPath("//div[contains(@class,'mat-calendar-header')]//button[contains(@class,'mat-calendar-period-button')]"));

        private Locator mailingAddressLabel = locator(pwXPath("//div[@id='mailingAddressDiv']//*[contains(@class,'tui-field-label-text')]"));

        protected Locator defaultMailingAddressRadioButton = locator(pwXPath("//mat-radio-button[@id='mailingAddressDiv_1']"));
        protected Locator defaultMailingAddressRadioButtonLabel = locator(pwXPath("//div[@id='mailingAddressDiv']//mat-radio-button[1]"));
        protected Locator otherMailingAddressRadioButton = locator(pwXPath("//input[@id='mailingAddressDiv_2-input']"));
        protected Locator otherMailingAddressRadioButtonLabel = locator(pwXPath("//mat-radio-button[contains(.,'Other mailing address')]"));

        private Locator mailingAddressInputLabel = locator(pwXPath("//div[@id='formField_address']//mat-label"));

        private Locator mailingAddressError = locator(pwXPath("//div[@id='formField_address']//mat-error"));

        private Locator apartmentNumberInputField = locator(pwCss("input[aria-label='Apartment number (optional)']"));

        private Locator apartmentInputLabel = locator(pwXPath("//div[@id='mailingAddressDiv_apartment']//mat-label"));

        private Locator invalidAptError = locator(pwXPath("//mat-form-field[@id='auto-contact-info-apartment__input-field']//mat-error"));
        protected Locator cityInputField = locator(pwCss("input[aria-label='City']"));

        private Locator cityInputLabel = locator(pwXPath("//div[@id='mailingAddressDiv_city']//mat-label"));

        private Locator cityError = locator(pwXPath("//div[@id='mailingAddressDiv_city']//mat-error"));

        protected Locator stateDropDown = locator(pwCss("mat-select[aria-label='State']"));

        private Locator stateDropDownLabel = locator(pwXPath("//div[@id='mailingAddressDiv_state']//mat-label"));

        private Locator stateError = locator(pwXPath("//div[@id='mailingAddressDiv_state']//mat-error/div"));

        protected Locator zipCodeInputField = locator(pwCss("input[aria-label='Zip code']"));

        private Locator zipCodeInputLabel = locator(pwXPath("//div[@id='mailingAddressDiv_zipCode']//mat-label"));

        private Locator zipCodeError = locator(pwXPath("//div[@id='mailingAddressDiv_zipCode']//mat-error/div"));
        private Locator otherMailingAddressInputField = locator(pwXPath("//address-autocomplete-input//input"));
        private Locator otherMailingAddressUnitInputField = locator(pwXPath("//div[@id='mailingAddressDiv_apartment']//input"));
        private Locator otherMailingAddressCityInputField = locator(pwXPath("//div[@id='mailingAddressDiv_city']//input"));
        private Locator otherMailingAddressStateDropdownField = locator(pwXPath("//div[@id='mailingAddressDiv_state']//mat-select"));
        private Locator otherMailingAddressZipCodeInputField = locator(pwXPath("//div[@id='mailingAddressDiv_zipCode']//input"));
        private Locator listOfAllTheStatesInOtherMailingAddressStateDropDown = locator(pwXPath("//span[@class='mat-option-text']"));

        private Locator personalInfoLabel = locator(pwXPath("//div[@id='flex-field-emailAddress_contactInfo']/p"));

        private Locator emailAddressFieldLabel = locator(pwXPath("//div[@class='email-address']//label"));

        private Locator emailAddressError = locator(pwXPath("//div[@id='flex-field-emailAddress_contactInfo']//mat-error"));

        private Locator mobilePhoneFieldLabel = locator(pwXPath("//div[@id='flex-field-phoneNumber_contactInfo']//label"));

        protected Locator phoneNumberInput = locator(pwXPath("//div[@id='flex-field-phoneNumber_contactInfo']//input"));

        private Locator phoneNumberError = locator(pwXPath("//div[@id='flex-field-phoneNumber_contactInfo']//mat-error"));

        private Locator textMeALinkCheckboxLabel = locator(pwXPath("//span[contains(.,'Text me a link')]"));

        private Locator textAuthorization = locator(pwXPath("//mat-checkbox/following-sibling::p"));

        private Locator termsConditionLink = locator(pwXPath("//p[contains(.,'terms')]/a"));

        private Locator pageErrorMessage = locator(pwXPath("//div[contains(@class,'contact-info-cta-validation')]"));

        private Locator pageFooterDisclaimer = locator(pwXPath("//p[span[@class='contactInfoDisclaimer']]"));

        private Locator linkAssociatedEntities = locator(pwLinkText("associated entities"));

        private Locator electronicSignHeader = locator(pwXPath("//h1"));

        private Locator ourCompaniesHeader = locator(pwXPath("//span[@class='h1']"));

        private Locator pageFooterDisclaimerEsign = locator(pwXPath("//p[span[@class='contactEsignDisclaimer']]"));

        private Locator linkDisclaimerEsign = locator(pwLinkText("ESIGN terms and conditions"));

        private Locator mobileDisclaimerAddition = locator(pwXPath("//p[contains(@class,'consent-disclaimer disclaimer-mobile-view-Margin')]/span[1]"));

        public Locator agreeAndSubmitButton = locator(pwXPath("//button[@id='contactInfoCTAButton' and not(@hidden)]"));

        public Locator saveQuoteButton = locator(pwCss("button[class='auto-agent-details__save-link tui-link-button']"));

        private Locator progressSavedSection = locator(pwXPath("//div[contains(@class,'save-in-progress-section')]/p"));

    private static final String EMAIL_ADDRESS_XPATH = "//div[@id='flex-field-emailAddress_contactInfo']//input";
        protected Locator emailAddressInput = locator(pwXPath(EMAIL_ADDRESS_XPATH));

        protected Locator mailingAddressInputField = locator(pwCss("input[aria-label='Mailing Address']"));

        private Locator bundleSaveHeadingNote = locator(pwClass("save-bundle-info-heading-note"));


        private Locator bundleAndSaveSection = locator(pwXPath("//app-save-bundle-sheet"));
        private Locator bundleSaveHeading = locator(pwXPath("//app-save-bundle-sheet//h2"));
    private static final String BUNDLE_CHECKBOXES_XPATH = "//*[@class='save-bundle-discount-sheet']//mat-checkbox";
        private Locator saveBundleMatCheckboxes = locator(pwXPath(BUNDLE_CHECKBOXES_XPATH));
        private Locator saveBundleCheckboxesText = locator(pwXPath(BUNDLE_CHECKBOXES_XPATH + "//following-sibling::span"));
        private Locator saveBundleMatCheckboxInputs = locator(pwXPath(BUNDLE_CHECKBOXES_XPATH + "//input"));
        private Locator autoBundleIcon = locator(pwXPath("//i[contains(@style,'rebrand-auto')]"));
        private Locator lifeBundleIcon = locator(pwXPath("//i[contains(@style,'rebrand-life')]"));
        private Locator umbrellaBundleIcon = locator(pwXPath("//i[contains(@style,'rebrand-umbrella')]"));
        private Locator multiPolicyCEAIcon = locator(pwXPath("//i[contains(@class,'tui-icon-house')]"));
        private Locator businessBundleIcon = locator(pwXPath("//i[contains(@class,'tui-icon-storefront')]"));
        private Locator boatsBundleIcon = locator(pwXPath("//i[contains(@class,'tui-icon-boat-right')]"));
        private Locator offRoadVehicleBundleIcon = locator(pwXPath("//i[contains(@class,'tui-icon-atv-right')]"));
        private Locator motorHomeBundleIcon = locator(pwXPath("//i[contains(@class,'tui-icon-rv-right')]"));

        private Locator saveBundleCongratulationMessage = locator(pwXPath("//p[contains(@class,'auto-driver-review-save-bundle-congratulations-message')]"));
        private Locator bundleAndSaveTipHeader = locator(pwXPath("//div[@id='saveBundleDiv']//div[contains(@class,'discount-info')]//div"));
        private Locator bundleAndSaveTipDescription = locator(pwXPath("//div[@id='saveBundleDiv']//div[contains(@class,'discount-info')]//p"));

        private Locator saveBundleInfoIcon = locator(pwXPath("//app-save-bundle-sheet//mat-icon"));

    private static final String ADDITIONAL_PRODUCTS_LINK_XPATH = "//div[@id='view-additional-products']//a";
        protected Locator viewAdditionProductsLink = locator(pwXPath(ADDITIONAL_PRODUCTS_LINK_XPATH));
    private static final String VIEW_ADDITIONAL_PRODUCT_LINK_TEXT = "View additional products to bundle";

    protected static final String FIRE_HYDRANT_SECTION_XPATH = "//app-contact-info//div[@id='fireHydrantdiv']";
        private Locator fireHydrantSection = locator(pwXPath(FIRE_HYDRANT_SECTION_XPATH));

        private Locator fireHydrantSectionTitle = locator(pwXPath(FIRE_HYDRANT_SECTION_XPATH + "//p"));

        private Locator fireHydrantSectionLabel = locator(pwXPath(FIRE_HYDRANT_SECTION_XPATH + "//label"));

    private static final String FIRE_HYDRANT_BUTTON_XPATH = "//app-contact-info//mat-button-toggle-group[contains(@class,'fireHydrantToggle')]";

    private static final String FIRE_HYDRANT_RADIO_BUTTON_QUESTIONS_XPATH = "//app-contact-info//div[@id='fireHydrantdiv']//p[contains(@class,'radio-group')]";
        private Locator fireHydrantQuestionsText = locator(pwXPath(FIRE_HYDRANT_RADIO_BUTTON_QUESTIONS_XPATH));

        private Locator fireHydrantQuestion1label = locator(pwXPath("//app-contact-info//div[@id='fireHydrantdiv']//div[contains(@class,'tui-radio-button-group')][1]/label"));

        private Locator fireHydrantQuestion2label = locator(pwXPath("//app-contact-info//div[@id='fireHydrantdiv']//div[contains(@class,'tui-radio-button-group')][2]/label"));

    private static final String IS_HOME_VISIBLE_QUESTION_BUTTON_XPATH = "//app-contact-info//div[@id='fireHydrantdiv']";

    private static final String IS_SECONDARY_HEATING_SOURCE_BUTTON_QUESTION_XPATH = FIRE_HYDRANT_SECTION_XPATH +
            "//mat-radio-group[@aria-label='Is there a secondary heating source installed in the home that burns wood, pellets, " +
            "coal or kerosene (excluding a fireplace)?']";

    protected static final String WILDFIRE_RISK_REDUCTION_MAT_CHECKBOX_XPATH = "//app-wildfire-selection//mat-checkbox[contains(.,'%s')]";
    protected static final String WILDFIRE_RISK_REDUCTION_TEMPLATE_XPATH = "//app-wildfire-selection//mat-checkbox[contains(.,'%s')]/label";
        Locator wildfireRiskReductionOptions = locator(pwXPath("//app-wildfire-selection//mat-checkbox"));

    protected static final String WILDFIRE_RISK_REDUCTION_XPATH = "//div[@id='wildfireDiscount']";
        protected Locator wildfireRiskReductionLabelCA = locator(pwXPath(WILDFIRE_RISK_REDUCTION_XPATH + "//label"));
        protected Locator wildfireRiskReductionSpanCA = locator(pwXPath(WILDFIRE_RISK_REDUCTION_XPATH + "//span"));
        protected Locator wildfireRiskMatButtonToggleYes = locator(pwXPath(WILDFIRE_RISK_REDUCTION_XPATH + "//mat-button-toggle[contains(.,'Yes')]"));
        protected Locator wildfireRiskMatButtonToggleNo = locator(pwXPath(WILDFIRE_RISK_REDUCTION_XPATH + "//mat-button-toggle[contains(.,'No')]"));
        protected Locator wildfireRiskButtonToggleYes = locator(pwXPath(WILDFIRE_RISK_REDUCTION_XPATH + "//mat-button-toggle[contains(.,'Yes')]//button"));
        protected Locator wildfireRiskButtonToggleNo = locator(pwXPath(WILDFIRE_RISK_REDUCTION_XPATH + "//mat-button-toggle[contains(.,'No')]//button"));
        protected Locator editWildfireRiskReduction = locator(pwXPath(WILDFIRE_RISK_REDUCTION_XPATH + "//a[text()='Edit']"));
        protected Locator wildfireRiskReductionSubtextCA = locator(pwXPath(WILDFIRE_RISK_REDUCTION_XPATH + "//div[contains(@class,'wildfire-riskreduction-subtext')]"));
        protected Locator closeWildfireSideSheet = locator(pwXPath("//app-wildfire-selection//mat-icon[text()='close']"));
        protected  Locator saveButtonWildfireRisk = locator(pwXPath("//app-wildfire-selection//button[text()='Save']"));
        protected Locator dialogNoChanges = locator(pwXPath("//mat-dialog-container[contains(.,'No selections made')]"));
        protected Locator buttonNoChangesOk = locator(pwXPath("//mat-dialog-container[contains(.,'No selections made')]//button[text()='Ok']"));

        protected Locator wildfireRiskReductionSideSheet = locator(pwXPath("//app-wildfire-selection"));
        protected Locator wildfireRiskReductionSideSheetTitle = locator(pwXPath("//app-wildfire-selection//h2"));
        protected Locator wildfireRiskReductionSideSheetDivider = locator(pwXPath("//app-wildfire-selection//mat-divider"));
        protected Locator wildfireRiskReductionSideSheetSubtitle = locator(pwXPath("//app-wildfire-selection//div[contains(@class,'tui-input-text')]/p[1]"));
        protected Locator wildfireRiskReductionSideSheetDivider1 = locator(pwXPath("//app-wildfire-selection//div[contains(@class,'tui-input-text')]/hr"));
        protected Locator wildfireRiskReductionSideSheetSubtitle2 = locator(pwXPath("//app-wildfire-selection//div[contains(@class,'tui-input-text')]/p[2]"));
        protected Locator wildfireRiskReductionSideSheetDivider2 = locator(pwXPath("//app-wildfire-selection//div//hr[contains(@class,'second-divider')]"));
        protected Locator wildfireRiskReductionSideSheetSection2Subtitle = locator(pwXPath("//app-wildfire-selection//div//hr[contains(@class,'second-divider')]/following-sibling::p"));
        protected Locator wildfireRiskReductionSideSheetCheckboxes = locator(pwXPath("//app-wildfire-selection//mat-checkbox"));
        protected Locator wildfireRiskReductionSideSheetCheckboxLabels = locator(pwXPath("//app-wildfire-selection//mat-checkbox//label//p[contains(@class,'tui-input-text')]"));


        private Locator residenceFloorSection = locator(pwXPath("//div[@id='floorResidenceContactInfo']"));
        private Locator residenceFloorSectionSubtitle = locator(pwXPath("//div[@id='floorResidenceContactInfo']//*[contains(@class,'tui-subtitle-text-1')]"));
        private Locator residenceFloorCheckbox = locator(pwXPath("//div[@id='floorResidenceContactInfo']/mat-checkbox"));
        private Locator residenceFloorInfoLabel = locator(pwXPath("//div[@id='floorResidenceContactInfo']//*[contains(@class,'label')]"));
        private Locator residenceFloorInfoDescription = locator(pwXPath("//div[@id='floorResidenceContactInfo']//*[contains(@class,'floorResidence-cont-info_checkbox-description')]"));

        private Locator contactInfoDisclaimer = locator(pwXPath("//p[contains(@class,'tui-body-text mt')]//span[@id='conactInfoDisclaimer']"));
        private Locator primaryInsuranceGroupTitle = locator(pwXPath("//p[contains(text(),'Primary named insured')]"));
        private Locator selectInsuranceGroupTitle = locator(pwXPath("//mat-card//div[contains(@class,'brand-selection')]/p[1]"));
        private Locator selectAllCheckboxLabel = locator(pwXPath("//mat-label[contains(@class,'brand-label')]"));
        private Locator farmersCheckboxLabel = locator(pwXPath("//mat-label[normalize-space()='Farmers\u00ae']"));
        private Locator BWCheckboxLabel = locator(pwXPath("//mat-label[normalize-space()='Bristol West\u00ae']"));
        private Locator farmersLifeCheckboxLabel = locator(pwXPath("//mat-label[normalize-space()='Farmers Life\u00ae']"));
        private Locator foremostCheckboxLabel = locator(pwXPath("//mat-label[normalize-space()='Foremost\u00ae']"));
        private Locator selectAllCheckboxSubLabel = locator(pwXPath("//p[normalize-space()='Choose them individually below:']"));
        private Locator farmersCheckboxSubLabel = locator(pwXPath("//mat-label[normalize-space()='Farmers\u00ae']/following-sibling::p"));
        private Locator BWCheckboxSubLabel = locator(pwXPath("//mat-label[normalize-space()='Bristol West\u00ae']/following-sibling::p"));
        private Locator farmersLifeCheckboxSubLabel = locator(pwXPath("//mat-label[normalize-space()='Farmers Life\u00ae']/following-sibling::p"));
        private Locator foremostCheckboxSubLabel = locator(pwXPath("//mat-label[normalize-space()='Foremost\u00ae']/following-sibling::p"));
        private Locator primaryInsuredName = locator(pwXPath("//div[@id='contactDetailsDiv']//div//li"));
    protected static final String BRANDS_CHECKBOXES_XPATH = "(//div[@class='brand-selection']//div/mat-checkbox)[%d]";
        protected Locator individualBrandCheckboxes = locator(pwXPath("//div[@class='brand-selection']//div/mat-checkbox"));
    protected static final String ALL_BRANDS_CHECKBOX_XPATH = "//div[@class='brand-selection']//mat-checkbox";
        protected Locator allBrandsCheckbox = locator(pwXPath(ALL_BRANDS_CHECKBOX_XPATH));
        protected Locator continueButtonBundleContactInfoPage = locator(pwXPath("//button[contains(@class, 'continue-button')]"));
    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public AceHRCContactInfoBasePage() throws Exception {
    }

    public boolean isOnContactInfoPage(boolean longWait) {
        if (longWait) {
            try {
                waitForSpinnerToBeGone();
                wait.until(Conditions.or(Conditions.visible(policyStartDateOrEstimatedClosingDateInputField),
                        Conditions.visible(tryAgainButton)));
            } catch (TimeoutError te) {
                return false;
            }
        }
        return isElementVisible(policyStartDateOrEstimatedClosingDateInputField, 3);
    }

    public void capturePEWC(String filename) throws Exception {
    	scrollToBottomOfPage();
        screenCapture(emailAddressInput, filename, LARGE, false);
    }

    public boolean isOnBundlePolicyStartDatePage() {
    	return isElementDisplayed(policyStartDateOrEstimatedClosingDateInputField, 3);
    }

    public boolean isResidenceInEscrow() throws Exception {
        String inEscrow = getSessionStorageAppStore().getHome().getAddressForm().getFields().get(0).getInEscrow();
        return  (inEscrow != null) && inEscrow.equals("Y");
    }

    public void validateErrorMessages(FarmersSoftAssert fsa, ApplicantAceHome applicant, String lobType) throws Exception {
    	// validate policy start date field error messages
    	validatePolicyStartDateErrorMessages(fsa, lobType);
    	// required field error messages validation
    	validateRequiredFieldErrorMessages(fsa, lobType);
    	// validate invalid entries
    	if (!lobType.equals(RENTERS)) {
    		validateInvalidEntriesErrorMessages(fsa);
    	}
    	if (lobType.equals(HOME)) {
    		// validate Fire hydrant section error messages
    		validateFireHydrantSectionErrorMessages(fsa, applicant);
    	}
    }

    public void validatePolicyStartDateErrorMessages(FarmersSoftAssert fsa, String lobType) {
    	if (lobType.equals(MOBILE_HOME)) {
    	    EXPECTED_POLICY_START_DATE_ERROR = "Please select your policy effective date between " + getFormattedForPolicyStartDate(today.plusDays(1)) + " and " + getFormattedForPolicyStartDate(today.plusDays(29)) + ".";
    	}
        //Today, invalid policy start date
        String formattedToday = getFormattedForPolicyStartDate(today);
        sendKeysToElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDateInputField), Keys.chord(formattedToday, Keys.TAB));
        if (isElementDisplayed(policyStartOrEstimatedClosingDateDateError, 3)) {
            fsa.assertEquals(getTextFromElement(policyStartOrEstimatedClosingDateDateError), EXPECTED_POLICY_START_DATE_ERROR, "Policy start date range error verification - today's date");
        } else {
            fsa.fail(EXPECTED_POLICY_START_DATE_ERROR + " >> error for " + formattedToday + " date was not found.");
        }

        waitForUiSettled();
        String futureDateOusideRange = getFormattedForPolicyStartDate(lobType.equals(MOBILE_HOME)? today.plusDays(30) : today.plusDays(60));
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, Keys.chord(futureDateOusideRange, Keys.TAB));
        if (isElementDisplayed(policyStartOrEstimatedClosingDateDateError, 3)) {
            fsa.assertEquals(getTextFromElement(policyStartOrEstimatedClosingDateDateError), EXPECTED_POLICY_START_DATE_ERROR, "Policy start date range error verification - future date outside of range");
        } else {
            fsa.fail(EXPECTED_POLICY_START_DATE_ERROR + " >> error for " + futureDateOusideRange + " date was not found.");
        }
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, getFormattedForPolicyStartDate(today.plusDays(1)));
    }

    public void validateRequiredFieldErrorMessages(FarmersSoftAssert fsa, String lobType) throws Exception {
        refreshPage();
        waitForPageToBeReady();
        final String PLEASE_ENTER_YOUR = "Please enter your ";

        clearOutFieldUsingBackSpace(policyStartDateOrEstimatedClosingDateInputField);
        if(!lobType.equals(RENTERS)){
            scrollAndClickOnElement(otherMailingAddressRadioButton);
        }

//        enterCommunicationConsent(AZ);
        waitAndClickElement(agreeAndSubmitButton);

        // Please provide your policy start date error validation - DE306469 only fixed in RA11
        String pleaseProvideYourPolicyStartDate = isResidenceInEscrow() ? "Please provide your estimated closing date." : "Please provide your policy start date.";
        fsa.assertEquals(getTextFromElement(policyStartOrEstimatedClosingDateDateError), pleaseProvideYourPolicyStartDate, errorMessage(pleaseProvideYourPolicyStartDate));

        if(!lobType.equals(RENTERS)){
            final String EXPECTED_EMAIL_ERROR = PLEASE_ENTER_YOUR + "email address.";
            fsa.assertEquals(getTextFromElement(emailAddressError), EXPECTED_EMAIL_ERROR, errorMessage(EXPECTED_EMAIL_ERROR));

            final String EXPECTED_PHONE_NUMBER_ERROR = PLEASE_ENTER_YOUR + "phone number.";
            fsa.assertEquals(getTextFromElement(phoneNumberError), EXPECTED_PHONE_NUMBER_ERROR, errorMessage(EXPECTED_PHONE_NUMBER_ERROR));

            final String EXPECTED_PAGE_ERROR_MESSAGE = "One or more required fields are incomplete or incorrect. Please Review.";
            fsa.assertEquals(getTextFromElement(pageErrorMessage), EXPECTED_PAGE_ERROR_MESSAGE, errorMessage(EXPECTED_PAGE_ERROR_MESSAGE));

            final String EXPECTED_MAILING_ADDRESS_ERROR = PLEASE_ENTER_YOUR + "mailing address.";
            fsa.assertEquals(getTextFromElement(mailingAddressError), EXPECTED_MAILING_ADDRESS_ERROR, errorMessage(EXPECTED_MAILING_ADDRESS_ERROR));

            final String EXPECTED_CITY_ERROR = PLEASE_ENTER_YOUR + "city.";
            fsa.assertEquals(getTextFromElement(cityError), EXPECTED_CITY_ERROR, errorMessage(EXPECTED_CITY_ERROR));

            final String EXPECTED_STATE_ERROR = PLEASE_ENTER_YOUR + "state.";
            fsa.assertEquals(getTextFromElement(stateError), EXPECTED_STATE_ERROR, errorMessage(EXPECTED_STATE_ERROR));

            final String EXPECTED_ZIPCODE_ERROR = PLEASE_ENTER_YOUR + "ZIP code.";
            fsa.assertEquals(getTextFromElement(zipCodeError), EXPECTED_ZIPCODE_ERROR, errorMessage(EXPECTED_ZIPCODE_ERROR));
        }
    }

    private void validateInvalidEntriesErrorMessages(FarmersSoftAssert fsa) throws Exception {
        refreshPage();
        waitForPageToBeReady();
        final String IS_NOT_VALID_ENTRY = "is not a valid entry.";

        //invalid email format
        String invalidEmail1 = "invalidEmail@";
        waitAndClickElement(emailAddressInput);
        sendKeysToElement(emailAddressInput, Keys.chord(invalidEmail1, Keys.TAB));
        final String EXPECTED_INVALID_EMAIL_ADDRESS_ERROR = "Email address entered is invalid.";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(emailAddressError)), EXPECTED_INVALID_EMAIL_ADDRESS_ERROR, "Invalid email format check");

        //invalid domain --validate email call should fail
        String invalidEmail2 = "invalidemail_123@yopmael.com";
        waitAndClickElement(emailAddressInput);
        sendKeysToElement(emailAddressInput, Keys.chord(invalidEmail2, Keys.TAB));
        waitAndClickElement(phoneNumberInput);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(emailAddressError)), EXPECTED_INVALID_EMAIL_ADDRESS_ERROR, "Invalid email domain check");

        //invalid phone number
        String invalidPhone = "(123) 456-6796";
        sendKeysToElement(phoneNumberInput, invalidPhone);
        sendKeysOneByOne(phoneNumberInput, Keys.chord(invalidPhone, Keys.TAB));
        fsa.assertEquals(getTextFromElement(phoneNumberError), String.format("%s %s", invalidPhone, IS_NOT_VALID_ENTRY), "Invalid phone number check");

        scrollAndClickOnElement(otherMailingAddressRadioButton);

        // invalid other mailing address entry

        String invalidMailingAddress = "123";
        sendKeysToElement(waitElementBeVisible(mailingAddressInputField), Keys.chord(invalidMailingAddress, Keys.TAB));
        //this error message takes a while to appear, give it a chance...
        waitForUiSettled();
        String browserUsed =  Property.getBrowser();
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(mailingAddressError)), List.of(FIREFOX, SAFARI).contains(browserUsed)? "Please enter your mailing address." : invalidMailingAddress + " is not a valid entry.", "Invalid address check");

        // invalid city entry
        String invalidCityName = "%";
        waitAndClickElement(cityInputField);
        sendKeysToElement(cityInputField, invalidCityName);
        sendKeysToElement(waitElementBeVisible(cityInputField), invalidCityName + Keys.ENTER);
        fsa.assertEquals(getTextFromElement(cityError), "Please enter your city.", "Invalid city check");

        //invalid zipcode entry
        String invalidZip = "1234";
        waitAndClickElement(zipCodeInputField);
        sendKeysOneByOne(zipCodeInputField, Keys.chord(invalidZip, Keys.ESCAPE, Keys.TAB));
        String expectedInvalidZipCodeMessage = "Please enter a 5 digit ZIP Code.";
        fsa.assertEquals(getTextFromElement(zipCodeError), expectedInvalidZipCodeMessage, "Invalid zipcode check");

    }

    public void validateEarlyShopperDiscount(FarmersSoftAssert fsa, String stateCode) throws Exception {
        LocalDate today = getTodayDate(); //today
        //Today, invalid policy start date
        String formattedToday = getFormattedForPolicyStartDate(today);
        sendKeysToElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDateInputField), formattedToday);
        waitAndClickElement(emailAddressInput);
        fsa.assertEquals(getTextFromElement(policyStartOrEstimatedClosingDateDateError), EXPECTED_POLICY_START_DATE_ERROR, errorMessage(EXPECTED_POLICY_START_DATE_ERROR));

        // From tomorrow, seven days later to 30 days, eligible for discounts
        LocalDate sevenDaysLater = todayPlus8Days();
        String formattedSevenDaysLater = getFormattedForPolicyStartDate(sevenDaysLater);
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, formattedSevenDaysLater);
        waitAndClickElement(emailAddressInput);

        validateEarlyShopperDiscountAndSideTextValidation(fsa, stateCode);

        // six days later (before seven days), no early shopping discount
        LocalDate sixDaysLater = todayPlus6Days();
        String formattedSixDaysLater = getFormattedForPolicyStartDate(sixDaysLater);
        waitAndClickElement(policyStartDateOrEstimatedClosingDateInputField);
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, formattedSixDaysLater);
        waitAndClickElement(emailAddressInput);
        waitForUiSettled();
        if (!isResidenceInEscrow()) {
            if (!isUseMobileViewEnabled()) {
                fsa.assertTrue(!isElementDisplayed(earlyDiscountOrEstimatedClosingDateInfoTitle, 2), "Policy start date info box should not appear");
            } else {
                fsa.assertTrue(!isElementDisplayed(earlyShoppingInfoIcon, 2), "Policy start date info icon should not appear");
            }
        }

        // From tomorrow, seven days later to 30 days, eligible for discounts
        LocalDate fiftyNineDays = todayPlus59Days();
        String formattedFiftyNineDays = getFormattedForPolicyStartDate(fiftyNineDays);
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, formattedFiftyNineDays);
        waitAndClickElement(emailAddressInput);
        validateEarlyShopperDiscountAndSideTextValidation(fsa, stateCode);

    }

    public void validateEarlyShopperDiscountAndSideTextValidation(FarmersSoftAssert fsa, String stateCode) throws Exception {
        if (stateCode.equals(CA)) {
            fsa.assertFalse(isSnackBarMessageDisplayed(EXPECTED_EARLY_SHOPPER_CONGRATS_MESSAGE), "Contact Info page - No Early shopper discount message for CA state quotes.");
        } else {
            fsa.assertTrue(isSnackBarMessageDisplayed(EXPECTED_EARLY_SHOPPER_CONGRATS_MESSAGE), "Contact Info page - " + EXPECTED_EARLY_SHOPPER_CONGRATS_MESSAGE);
        }
        if (isResidenceInEscrow()) {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoTitle)), ESTIMATED_CLOSING_DATE_INFO_TITLE, errorMessage(ESTIMATED_CLOSING_DATE_INFO_TITLE));
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoDescription)), ESTIMATED_CLOSING_DATE_INFO_DESCRIPTION, errorMessage(ESTIMATED_CLOSING_DATE_INFO_DESCRIPTION));
        } else {
            if (stateCode.equals(CA)) {
                fsa.assertFalse(isElementDisplayed(earlyDiscountOrEstimatedClosingDateInfoTitle, 2), "Policy start date info box should not display for CA state quotes");
                fsa.assertFalse(isElementDisplayed(earlyDiscountOrEstimatedClosingDateInfoDescription, 2), "Policy start date info box should not display for CA state quotes");
            } else {
                if (!isUseMobileViewEnabled()) {
                    fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoTitle)), EXPECTED_EARLY_SHOPPING_INFO_TITLE);
                    fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoDescription)), EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION);
                } else {
                    waitAndClickElement(earlyShoppingInfoIcon);
                    fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalTitle)), EXPECTED_EARLY_SHOPPING_INFO_TITLE, EXPECTED_EARLY_SHOPPING_INFO_TITLE);
                    fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalText)), EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION, EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION);
                    waitAndClickElement(infoModalButtonClose);
                }
            }
        }
    }

    public void validateBundleSaveSection(ApplicantAceHome applicant, FarmersSoftAssert fsa, String lobType) throws Exception {
        String expectedHeader = "Save more when you bundle";
        String expectedHeaderNote = "Select which eligible Farmers products you would like to bundle with:";
        String expectedBundleAndSaveTipHeader = "Bundle and save";
        String expectedBundleAndSaveDescription = "A bundle discount will be applied to your " + lobType.toLowerCase() + " quote today. " +
        		"You will have to purchase the policies you select to retain the discount. " +
                "A Farmers\u00ae representative will reach out to you to help you through the process.";
        String expectedInfoModalTitle = "How it works";

        fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleSaveHeading)), expectedHeader, "Bundle Save section header check");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleSaveHeadingNote)), expectedHeaderNote, "Bundle Save section header note check");
        if (!isUseMobileViewEnabled()) {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleAndSaveTipHeader)), expectedBundleAndSaveTipHeader, "Bundle Save tip header verification");
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleAndSaveTipDescription)), expectedBundleAndSaveDescription, "Bundle Save tip description verification");
        } else {
            waitAndClickElement(saveBundleInfoIcon);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalTitle)), expectedInfoModalTitle, "Bundle Save info modal title matching");
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalText)), expectedBundleAndSaveDescription, "Bundle Save info modal text matching");
            waitAndClickElement(infoModalButtonClose);
        }

        List<Locator> availableBundleIcons;
        List<String> expectedCongratsMessages;
        List<String> expectedDiscountsRemovedMessages;

        String stateCode = applicant.getStateCode();
        if (lobType.equals(MOBILE_HOME)) {
            if (List.of(CT, NY).contains(stateCode)) {
                availableBundleIcons = new ArrayList<>(Arrays.asList(autoBundleIcon, umbrellaBundleIcon));
                expectedCongratsMessages = new ArrayList<>(Arrays.asList(AUTO_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, UMBRELLA_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE));
                expectedDiscountsRemovedMessages = new ArrayList<>(Arrays.asList(AUTO_BUNDLE_DISCOUNT_REMOVED_MESSAGE, UMBRELLA_BUNDLE_DISCOUNT_REMOVED_MESSAGE));
            } else {
            	availableBundleIcons = new ArrayList<>(Arrays.asList(autoBundleIcon, lifeBundleIcon, umbrellaBundleIcon));
            	expectedCongratsMessages = new ArrayList<>(Arrays.asList(AUTO_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, LIFE_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, UMBRELLA_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE));
            	expectedDiscountsRemovedMessages = new ArrayList<>(Arrays.asList(AUTO_BUNDLE_DISCOUNT_REMOVED_MESSAGE, LIFE_BUNDLE_DISCOUNT_REMOVED_MESSAGE, UMBRELLA_BUNDLE_DISCOUNT_REMOVED_MESSAGE));
            }
        } else if (lobType.equals(CONDO) || lobType.equals(RENTERS) || isAdditionalHomeBundleDiscountsState(stateCode)) {
            // View additional products link validation
            if (isElementPresentByXPath(ADDITIONAL_PRODUCTS_LINK_XPATH)) {
                fsa.assertTrue(getTextFromElement(viewAdditionProductsLink).contains(VIEW_ADDITIONAL_PRODUCT_LINK_TEXT), "View additional products to bundle link text contains ["+ VIEW_ADDITIONAL_PRODUCT_LINK_TEXT+"]");
                scrollAndClickOnElement(viewAdditionProductsLink);
            }
            availableBundleIcons = new ArrayList<>(Arrays.asList(autoBundleIcon, lifeBundleIcon, businessBundleIcon, boatsBundleIcon, offRoadVehicleBundleIcon, motorHomeBundleIcon));
            expectedCongratsMessages = new ArrayList<>(Arrays.asList(AUTO_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, LIFE_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, BUSINESS_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE,
        	    WATERCRAFT_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, OFF_ROAD_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, RV_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE));
            expectedDiscountsRemovedMessages = new ArrayList<>(Arrays.asList(AUTO_BUNDLE_DISCOUNT_REMOVED_MESSAGE, LIFE_BUNDLE_DISCOUNT_REMOVED_MESSAGE, BUSINESS_BUNDLE_DISCOUNT_REMOVED_MESSAGE,
        	    WATERCRAFT_BUNDLE_DISCOUNT_REMOVED_MESSAGE, OFF_ROAD_BUNDLE_DISCOUNT_REMOVED_MESSAGE, RV_BUNDLE_DISCOUNT_REMOVED_MESSAGE));
            if (!isEasternExpansionState(stateCode)) {
                availableBundleIcons.add(umbrellaBundleIcon);
                expectedCongratsMessages.add(UMBRELLA_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE);
                expectedDiscountsRemovedMessages.add(UMBRELLA_BUNDLE_DISCOUNT_REMOVED_MESSAGE);
            }
        } else {
            if (stateCode.equals(CA)) {
            	availableBundleIcons = new ArrayList<>(Arrays.asList(autoBundleIcon, umbrellaBundleIcon, multiPolicyCEAIcon));
            	expectedCongratsMessages = new ArrayList<>(Arrays.asList(AUTO_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, UMBRELLA_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, MULTI_POLICY_CEA_DISCOUNT_CONGRATULATIONS_MESSAGE));
            	expectedDiscountsRemovedMessages = new ArrayList<>(Arrays.asList(AUTO_BUNDLE_DISCOUNT_REMOVED_MESSAGE, UMBRELLA_BUNDLE_DISCOUNT_REMOVED_MESSAGE, MULTI_POLICY_CEA_DISCOUNT_REMOVED_MESSAGE));
            } else {
            	availableBundleIcons = new ArrayList<>(Arrays.asList(autoBundleIcon, lifeBundleIcon, umbrellaBundleIcon));
            	expectedCongratsMessages = new ArrayList<>(Arrays.asList(AUTO_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, LIFE_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE, UMBRELLA_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE));
            	expectedDiscountsRemovedMessages = new ArrayList<>(Arrays.asList(AUTO_BUNDLE_DISCOUNT_REMOVED_MESSAGE, LIFE_BUNDLE_DISCOUNT_REMOVED_MESSAGE, UMBRELLA_BUNDLE_DISCOUNT_REMOVED_MESSAGE));
            }
        }

        // validate the list of the checkboxes
        List<String> expectedBundleOptions = FfqBundleOptions.getBundleOptionsForAceHome(applicant, lobType);
        if (!lobType.equals(MOBILE_HOME) && (stateCode.equals(CT) || stateCode.equals(AL))) {
            availableBundleIcons.remove(lifeBundleIcon);
            expectedBundleOptions.remove(LIFE);
            expectedCongratsMessages.remove(LIFE_BUNDLE_DISCOUNT_CONGRATULATIONS_MESSAGE);
            expectedDiscountsRemovedMessages.remove(LIFE_BUNDLE_DISCOUNT_REMOVED_MESSAGE);
        }
        List<String> actualBundleOptions = saveBundleCheckboxesText.all().stream().map(each -> getAttributeData(each, "innerText").strip()).collect(Collectors.toList());
        fsa.assertEquals(actualBundleOptions, expectedBundleOptions, "actualBundleOptions matches expectedBundleOptions");
        int bundleOptions = actualBundleOptions.size();
        int bundleIcons = availableBundleIcons.size();
        int numberOfExpectedBundleOptions = expectedBundleOptions.size();
        fsa.assertTrue(bundleOptions == bundleIcons && numberOfExpectedBundleOptions == bundleIcons,
                "availableBundleIcons: " + bundleIcons + " , actualBundleOptions: " + bundleOptions+ " and expectedBundleOptions: " + numberOfExpectedBundleOptions +
                        " match  for " + lobType + " in " + applicant.getStateCode());

        // Validate that bundle checkboxes produce a singular congratulations message
        // Mobile home snackbar behaves differently - no singular message
        if (!lobType.equals(MOBILE_HOME)) {
            List<String> foundCongratsMessages = new ArrayList<>();
            List<String> foundDiscountsRemovedMessages = new ArrayList<>();
            int i = 0;
        	for (Locator saveBundleInput : saveBundleMatCheckboxInputs.all()) {
                waitElementBeInvisible(snackBar);
        		scrollAndClickOnElement(saveBundleInput);
        		waitForUiSettled();
        		waitElementBeVisible(snackBar,3);
        		foundCongratsMessages.add(getTextFromElement(snackBar));
        		fsa.assertTrue(getAttributeData(saveBundleMatCheckboxes.nth(i), CLASS).contains(CHECKBOX_CHECKED), "Bundle checkbox: " + (i+1) + " checked");
                i++;
        	}
        	waitForUiSettled();
            i = 0;
        	for (Locator uncheckBundleInput : saveBundleMatCheckboxInputs.all()) {
                waitElementBeInvisible(snackBar);
        		scrollAndClickOnElement(uncheckBundleInput);
        		waitForUiSettled();
        		waitElementBeVisible(snackBar, 3);
        		foundDiscountsRemovedMessages.add(getTextFromElement(snackBar));
        		fsa.assertFalse(getAttributeData(saveBundleMatCheckboxes.nth(i), CLASS).contains(CHECKBOX_CHECKED), "Bundle checkbox: " + (i+1) + " unchecked");
                i++;
        	}
        	fsa.assertEquals(getSortedList(foundCongratsMessages), getSortedList(expectedCongratsMessages), "Actual and expected Congratulations messages match - " + lobType);
        	fsa.assertEquals(getSortedList(foundDiscountsRemovedMessages), getSortedList(expectedDiscountsRemovedMessages), "Actual and expected Discount messages match - " + lobType);
        }
    }


    public void enterEmailIdAndPhoneNumberInContactInfoPage(ApplicantAceHome applicant) {
    	enterEmailAddress(applicant.getEmailAddress());
        waitAndClickElement(phoneNumberInput);
        waitForUiSettled();
        sendKeysOneByOne(phoneNumberInput, applicant.getPhoneNumber());
        waitForUiSettled();
        sendKeysToElement(phoneNumberInput, Keys.TAB);
    }

    public void enterEmailAddress (String emailAddress) {
        scrollToElement(emailAddressInput);
        waitAndClickElement(emailAddressInput);
        sendKeysToElement(emailAddressInput, emailAddress);
        sendKeysToElement(emailAddressInput, Keys.TAB);
    }


    public boolean isEmailAddressReadOnly() {
        return isAttributePresent(emailAddressInput, DISABLED);
    }

    public boolean isPhoneNumberReadOnly() {
        return isAttributePresent(phoneNumberInput, DISABLED);
    }

    public void clickOnAgreeAndSubmitButton(){
        scrollAndClickOnElement(agreeAndSubmitButton);
        waitForSpinnerToBeGone();
    }

    public void fillOutBundleAndSave(ApplicantAceHome applicant, String lobType) throws Exception {
    	List<SqlDiscount> discounts = applicant.getDiscounts();
    	if (!discounts.isEmpty() && (!lobType.equals(HOME) || !isHomeToAutoBundleEligibleAndEnabled(applicant.getStateCode()))) {
    		SqlDiscount discount = discounts.get(FIRST_AVAILABLE_OPTION);
    		selectBundle(discount.isAutoInsurance(), "Auto");
    		waitForUiSettled();
    		selectBundle(discount.isLifeInsurance(), "Life");
    		waitForUiSettled();
    		selectBundle(discount.isUmbrellaInsurance(), "Umbrella");
    		waitForUiSettled();
    		selectBundle(discount.isMultiPolicyCEA(), "Multi-policy Discount - CEA");
    		waitForUiSettled();
    		if (!lobType.equals(MOBILE_HOME) && (isAdditionalHomeBundleDiscountsState(applicant.getStateCode()) || !lobType.equals(HOME))) {
    			if (isElementPresent(pwXPath(ADDITIONAL_PRODUCTS_LINK_XPATH),3)) {
    				waitAndClickElement(viewAdditionProductsLink);
    			}
    			selectBundle(discount.isBusinessInsurance(), "Business");
    			selectBundle(discount.isRecreationalBoatWatercraftInsurance(), "Recreational Boat/Watercraft");
    			selectBundle(discount.isMotorcycleInsurance(), "Off-Road Vehicle");
    			selectBundle(discount.isMotorHome(), "Motorhome, Travel Trailer or 5th Wheel");
    		}
    	}
    }

    public void validateHeaderAndSubHeaderContactInfoPage(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isElementInViewport(lastStepBeforeYourPageHeader), "Page title is in Viewport");
        // Validate header and sub header content
        String lastStepBeforeYourQuote;
        String lobFromAppStore = getLobTypeFromAppStore();
        if (lobFromAppStore.equals(RENTERS)) {
            lobFromAppStore = RENTERS;
        }
        switch (lobFromAppStore) {
		case RENTERS:
            lastStepBeforeYourQuote = "Last step before your coverage";
			break;
		case MOBILE_HOME:
            lastStepBeforeYourQuote = "Last step before coverages";
            break;
		default:
			lastStepBeforeYourQuote = "Last step before your quote";
			break;
		}
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(lastStepBeforeYourPageHeader)), lastStepBeforeYourQuote, errorMessage(lastStepBeforeYourQuote));
        final String JUST_FEW_MORE_QUESTIONS_BEFORE_YOUR_QUOTE_LABEL = "Just a few more questions before we calculate your quote on the next page.";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(fewMoreQuestionBeforeYourQuoteHeader)), JUST_FEW_MORE_QUESTIONS_BEFORE_YOUR_QUOTE_LABEL, errorMessage(JUST_FEW_MORE_QUESTIONS_BEFORE_YOUR_QUOTE_LABEL));
    }

    public void validateContentOfEstimatedClosingOrPolicyStartDate(FarmersSoftAssert fsa, String lobType) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        // Validate policy start date or estimated closing date on first load
        String policyStartDateOnInitialLoad = getValueFromLocator(policyStartDateOrEstimatedClosingDateInputField);
        LocalDate policyStartDateFromDatePicker = getFormattedDateFromStringDate(policyStartDateOnInitialLoad);

        // Validate policy start date or estimated closing date content
        fsa.assertEquals(policyStartDateOnInitialLoad, getFormattedTomorrowDate(), "Estimated closing date verification on initial load");
        if (isResidenceInEscrow(appStore)) {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDateTitle)), EXPECTED_ESTIMATED_CLOSING_DATE_TITLE, errorMessage(EXPECTED_ESTIMATED_CLOSING_DATE_TITLE));
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDatePlaceHolderText)), EXPECTED_ESTIMATED_CLOSING_DATE_AREA_LABEL, errorMessage(EXPECTED_DATE_PICKER_AREA_LABEL));
            if (isUseMobileViewEnabled()) {
                waitAndClickElement(earlyShoppingInfoIcon);
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalTitle)), ESTIMATED_CLOSING_DATE_INFO_TITLE, errorMessage(ESTIMATED_CLOSING_DATE_INFO_TITLE));
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalText)), ESTIMATED_CLOSING_DATE_INFO_DESCRIPTION, errorMessage(ESTIMATED_CLOSING_DATE_INFO_DESCRIPTION));
                waitAndClickElement(infoModalButtonClose);
            } else {
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoTitle)), ESTIMATED_CLOSING_DATE_INFO_TITLE, errorMessage(ESTIMATED_CLOSING_DATE_INFO_TITLE));
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoDescription)), ESTIMATED_CLOSING_DATE_INFO_DESCRIPTION, errorMessage(ESTIMATED_CLOSING_DATE_INFO_DESCRIPTION));
            }
        } else {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDateTitle)), EXPECTED_POLICY_START_DATE_TITLE, errorMessage(EXPECTED_POLICY_START_DATE_TITLE));
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDatePlaceHolderText)), EXPECTED_DATE_PICKER_AREA_LABEL, errorMessage(EXPECTED_DATE_PICKER_AREA_LABEL));

            policyStartDateOrEstimatedClosingDateInputField.fill("");
            sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, getFormattedDateAfter8days());

            if (!appStore.getData().getLandingStateCode().equals(CA)) {
                if (!lobType.equals(RENTERS)) {
                    if (!isUseMobileViewEnabled()) {
                        fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoTitle)), EXPECTED_EARLY_SHOPPING_INFO_TITLE, errorMessage(EXPECTED_EARLY_SHOPPING_INFO_TITLE));
                        fsa.assertEquals(getTextFromElement(waitElementBeVisible(earlyDiscountOrEstimatedClosingDateInfoDescription)), EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION, errorMessage(EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION));
                    } else {
                        waitAndClickElement(earlyShoppingInfoIcon);
                        fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalTitle)), EXPECTED_EARLY_SHOPPING_INFO_TITLE, errorMessage(EXPECTED_EARLY_SHOPPING_INFO_TITLE));
                        fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoModalText)), EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION, errorMessage(EXPECTED_EARLY_SHOPPING_INFO_DESCRIPTION));
                        waitAndClickElement(infoModalButtonClose);
                    }
                }
            }

        }

        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, getFormattedForPolicyStartDate(LocalDate.now().plusDays(7)));
        if (!lobType.equals(RENTERS) && !appStore.getData().getLandingStateCode().equals(CA)) {
            fsa.assertTrue(isSnackBarMessageDisplayed(EXPECTED_EARLY_SHOPPER_CONGRATS_MESSAGE), "Contact Info page - " + errorMessage(EXPECTED_EARLY_SHOPPER_CONGRATS_MESSAGE));
        }
        // Validate date picker pop up content
        String formattedTodayDate = getFormattedTodayDate();
        waitAndClickElement(datePickerToggleIcon);
        waitAndClickElement(selectedDateInDatePickerPopUp);
        policyStartDateOrEstimatedClosingDateInputField.fill("");
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, formattedTodayDate);
        waitAndClickElement(datePickerToggleIcon);

        if (!isEndOfTheMonthDate(formattedTodayDate)) {
            Locator formattedTodayDateLocator = locator(pwXPath("//button[*[contains(@class,'mat-calendar-body-today')]]"));
            fsa.assertTrue(isElementDisabled(formattedTodayDateLocator), "Today's date is disabled in the DatePicker popup");
            waitAndClickElement(formattedTodayDateLocator);
        }

        String formattedTomorrowDate = getFormattedTomorrowDate();
        policyStartDateOrEstimatedClosingDateInputField.fill("");
        sendKeysToElement(policyStartDateOrEstimatedClosingDateInputField, formattedTomorrowDate);
        fsa.assertEquals(datePickerToggleIcon.isVisible(), true, "DatePicker Toggle Icon Displayed");
        waitAndClickElement(datePickerToggleIcon);
        fsa.assertEquals(String.valueOf(getFormattedDateFromStringDate(getValueFromLocator(policyStartDateOrEstimatedClosingDateInputField)).getDayOfMonth()).trim(), getTextFromElement(selectedDateInDatePickerPopUp), "Policy Start Date From SqlApplicant check");
        String selectedMonthAndYear = policyStartDateFromDatePicker.getMonth() + " " + policyStartDateFromDatePicker.getYear();
        fsa.assertEquals(selectedMonthAndYear, getTextFromElement(selectedMonthYearHeaderInDatePickerPopUp), "Selected month and year verification in date picker pop up");
        waitAndClickElement(selectedDateInDatePickerPopUp);

    }

    public void validateContentOfMailingAndOtherMailingAddress(FarmersSoftAssert fsa) throws Exception {
        //validate mailing address input field content
        final String EXPECTED_MAILING_ADDRESS_LABEL = "Mailing address";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(mailingAddressLabel)), EXPECTED_MAILING_ADDRESS_LABEL, errorMessage(EXPECTED_MAILING_ADDRESS_LABEL));

        AppStore.Data.CustomerData.Address defaultMailingAddress = getSessionStorageAppStore().getData().getCustomerData().getAddress();
        fsa.assertTrue(defaultMailingAddressRadioButton.isEnabled(), "Default mailing address radio button enabled");
        String defaultMailAddressLabel = getTextFromElement(defaultMailingAddressRadioButtonLabel);
        fsa.assertTrue(defaultMailAddressLabel.contains(defaultMailingAddress.getStreet().toUpperCase(Locale.ROOT)), "Default mailing address verification");

        // Validate other mailing address content
        final String EXPECTED_OTHER_MAILING_ADDRESS_LABEL = "Other mailing address";
        clickElement(otherMailingAddressRadioButton);
        fsa.assertTrue(otherMailingAddressRadioButton.isEnabled(), "Other mailing address radio button is not enabled");
        fsa.assertEquals(getAttributeData(waitElementBeVisible(otherMailingAddressRadioButtonLabel), "innerText").strip(), EXPECTED_OTHER_MAILING_ADDRESS_LABEL, errorMessage(EXPECTED_OTHER_MAILING_ADDRESS_LABEL));

        fsa.assertEquals(getTextFromElement(waitElementBeVisible(mailingAddressInputLabel)), MAILING_ADDRESS, errorMessage(MAILING_ADDRESS));

        final String EXPECTED_APARTMENT_LABEL = "Unit #";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(apartmentInputLabel)), EXPECTED_APARTMENT_LABEL, errorMessage(EXPECTED_APARTMENT_LABEL));

        final String EXPECTED_CITY_LABEL = "City";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(cityInputLabel)), EXPECTED_CITY_LABEL, errorMessage(EXPECTED_CITY_LABEL));

        final String EXPECTED_STATE_LABEL = "State";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(stateDropDownLabel)), EXPECTED_STATE_LABEL, errorMessage(EXPECTED_STATE_LABEL));

        final String EXPECTED_ZIP_LABEL = "ZIP";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(zipCodeInputLabel)), EXPECTED_ZIP_LABEL, errorMessage(EXPECTED_ZIP_LABEL));

        final String EXPECTED_STREET_ADDRESS = "10528 Sea Palms Ave";
        final String EXPECTED_CITY = "Las Vegas";
        final String EXPECTED_STATE = "NV";
        final String EXPECTED_ZIP_CODE = "89134";
        scrollToElement(otherMailingAddressInputField);
        enterGoogleAddress(otherMailingAddressInputField, EXPECTED_STREET_ADDRESS, EXPECTED_CITY);
        waitForUiSettled();
        fsa.assertEquals(getAttributeData(otherMailingAddressInputField, VALUE), EXPECTED_STREET_ADDRESS, "Other mailing address street verification.");
        fsa.assertEquals(getAttributeData(otherMailingAddressCityInputField, VALUE), EXPECTED_CITY, "Other mailing address city verification.");
        waitAndClickElement(stateDropDownLabel);
        List<String> foundListOfStates = stateDropDownOptions.all().stream().map(this::getTextFromElement).sorted().collect(Collectors.toList());
        fsa.assertEquals(foundListOfStates, listOfAllStates(), "Other mailing address list of states verification.");
        fsa.assertEquals(getTextFromElement(otherMailingAddressStateDropdownField), EXPECTED_STATE, "Other mailing address state verification in the state drop down.");
        fsa.assertEquals(getAttributeData(otherMailingAddressZipCodeInputField, VALUE), EXPECTED_ZIP_CODE, "Other mailing address zip code verification.");
        fsa.assertEquals(getAttributeData(otherMailingAddressUnitInputField, VALUE), EMPTY_STRING, "Other mailing address unit is empty.");
        sendKeysToElement(stateDropDown,Keys.TAB);
    }

    public void validateContentOfContactInfo(FarmersSoftAssert fsa) {
        // Validate contact info fields content
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(personalInfoLabel)), EXPECTED_PERSONAL_INFO_LABEL, errorMessage(EXPECTED_PERSONAL_INFO_LABEL));
        final String EXPECTED_EMAIL_ADDRESS_FIELD_LABEL = "Email address";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(emailAddressFieldLabel)), EXPECTED_EMAIL_ADDRESS_FIELD_LABEL, errorMessage(EXPECTED_EMAIL_ADDRESS_FIELD_LABEL));

        final String EXPECTED_MOBILE_PHONE_FIELD_LABEL = "Mobile phone";
        scrollToElement(waitElementBeVisible(mobilePhoneFieldLabel));
        fsa.assertEquals(getTextFromElement(mobilePhoneFieldLabel), EXPECTED_MOBILE_PHONE_FIELD_LABEL, errorMessage(EXPECTED_MOBILE_PHONE_FIELD_LABEL));
    }

    public void validateDisclaimerOnContactInfoPage(FarmersSoftAssert fsa) {
        final String EXPECTED_ESIGN_DISCLAIMER = "String clicking \"Agree and submit\", you agree to these ESIGN terms and conditions and to receive marketing calls and texts as detailed below.";
        final String EXPECTED_CONTACT_DISCLAIMER = "We call and/or text consumers with information about products and services. " +
        	"String clicking \"Agree and submit\", you consent to receive marketing calls and texts on behalf of Farmers\u00ae, Foremost\u00ae, Bristol West\u00ae, and Farmers Life\u00ae associated entities and their " +
                "representatives using an automated telephone dialing system, AI-generated and artificial or pre-recorded voice, even for numbers listed on national, state, or business do-not-call registries. " +
        	"Consent is not a condition of purchase. Go to Farmers.com for alternative contact options. Message and data rates may apply.";
        scrollToElement(pageFooterDisclaimer);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageFooterDisclaimerEsign, 5)), EXPECTED_ESIGN_DISCLAIMER, "ESIGN disclaimer verification");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(pageFooterDisclaimer, 5)), EXPECTED_CONTACT_DISCLAIMER, "Contact disclaimer verification");
    }

    public void validateDisclaimerFooterLinks(FarmersSoftAssert fsa, String lob) throws Exception {
        String ELECTRONIC_BUSINESS_CONSENT_TITLE = "Use of Electronic Signatures, Consent to Be Provided Electronic Records, and Agreement to Do Business Electronically";
        String OUR_COMPANIES_TITLE = lob.equals(RENTERS) ? "List of Companies and State Licenses" : "Our Companies";

        Log.info(">> Going to check: ESIGN terms and conditions link.");
        clickElement(linkDisclaimerEsign);
        conditionalWait(10).until(Conditions.pageCount(2));
        List<Page> tabs = new ArrayList<>(pages());
        switchToPage(tabs.get(1));
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(electronicSignHeader, 5)).toUpperCase(), ELECTRONIC_BUSINESS_CONSENT_TITLE.toUpperCase(),
                "Contact info page - Electronic business consent title found in the newly opened tab.");
        closeCurrentPage();
        switchToPage(tabs.get(0));
        conditionalWait(10).until(Conditions.pageCount(1));
        Log.info(">> Going to check: associated entities link.");
        clickElement(linkAssociatedEntities);
        conditionalWait(10).until(Conditions.pageCount(2));
        tabs = new ArrayList<>(pages());
        switchToPage(tabs.get(1));
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(ourCompaniesHeader, 5)), OUR_COMPANIES_TITLE,
                "Contact info page - Our Companies title found in the newly opened tab.");
        closeCurrentPage();
        switchToPage(tabs.get(0));
        conditionalWait(10).until(Conditions.pageCount(1));
    }

    public void validateContentOfAgreeAndSubmit(FarmersSoftAssert fsa) {
        final String EXPECTED_CTA_TEXT = "Agree and submit";
        scrollToElement(agreeAndSubmitButton);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(agreeAndSubmitButton)), EXPECTED_CTA_TEXT, errorMessage(EXPECTED_CTA_TEXT));
    }

    public boolean getFireHydrantYesNo() throws Exception {
        boolean fireHydrant;
        if (isElementDisplayed(pwXPath(FIRE_HYDRANT_BUTTON_XPATH))) {
            String hydrant = locators(pwXPath(FIRE_HYDRANT_BUTTON_XPATH + "//mat-button-toggle")).stream()
                    .filter(i -> getAttributeData(i, CLASS).contains("mat-button-toggle-checked"))
                    .map(BasePage::getValueFromLocator).findFirst().orElse(null);
            assert hydrant != null;
            fireHydrant = hydrant.equals("Y");
        } else {
            fireHydrant = false;
        }
        return fireHydrant;
    }

    public boolean isFirehydrantYes() throws Exception {
        return isButtonSelected(locator(pwXPath(FIRE_HYDRANT_BUTTON_XPATH + "//button[.='Yes']")));
    }

    public boolean isFirehydrantNo() throws Exception {
        return isButtonSelected(locator(pwXPath(FIRE_HYDRANT_BUTTON_XPATH + "//button[.='No']")));
    }

    public void selectFirehydrant(boolean fireHydrant) throws Exception {
        String buttonXpath = fireHydrant ? "//button[.='Yes']" : "//button[.='No']";
        List<Locator> buttonListWe = locators(pwXPath(FIRE_HYDRANT_BUTTON_XPATH + buttonXpath));
        if (!buttonListWe.isEmpty()) {
            if(buttonListWe.size() == 2){
                scrollAndClickOnElement(buttonListWe.get(1));
            }else{
                scrollAndClickOnElement(buttonListWe.get(0));
            }

        } else {
            Log.warn("Fire hydrant button Yes/No: " + fireHydrant + " is not displayed.");
        }
    }

    public void selectIsHomeVisible(boolean homeVisible) throws Exception {
        String buttonXpath = homeVisible ? "//mat-radio-button[@value='Y']" : "//mat-radio-button[@value='N']";
        Locator we = locator(pwXPath(IS_HOME_VISIBLE_QUESTION_BUTTON_XPATH + buttonXpath + "//input"));
        scrollToTopOfPage();
        clickOnHiddenElement(we);
    }

    public void selectSecondaryHeatingSource(String secondaryHeatingSource) throws Exception {
        Locator we = locator(pwXPath(IS_SECONDARY_HEATING_SOURCE_BUTTON_QUESTION_XPATH +
                String.format("//mat-radio-button[@value='%s']//input", secondaryHeatingSource)));
        scrollAndClickOnElement(we);
    }

    public void validateContentOfFireHydrantSection(FarmersSoftAssert fsa, String homeLobType) throws Exception {
        final String FIRE_HYDRANT_SECTION_TITLE = "Does this apply to your home?";
        final String FIRE_HYDRANT_SECTION_LABEL = "There is a fire hydrant within 1000 ft of the property.";
        final String TWO_ADDITIONAL_QUESTIONS_TEXT = "We just need to ask you two more questions:";
        final String FIRST_QUESTION_LABEL = "Is this home visible from the main road or by neighbors?";
        final String SECOND_QUESTION_LABEL = "Is there a secondary heating source installed in the home that burns wood, " +
                "pellets, coal or kerosene (excluding a fireplace)?";
        List<String> secondQuestionTextOptions = Arrays.asList("There is, it's professionally installed", "Yes, but it's not professionally installed",
                "No, there isn't");

        if (!homeLobType.equals(RENTERS)) { // Fire hydrant question related story: US626980
            try {
                AppStore.Home.GetLocation getLocation = getSessionStorageAppStore().getHome().getLocation();
                int yearBuilt = Integer.parseInt(getSessionStorageAppStore().getHome().getPropertyForm().getFields().get(0).getYearBuilt());
                boolean fireHydrantQuestion = (getLocation.getSplitPPCInd().equalsIgnoreCase(TRUE) && getLocation.getWaterSupplyType().equals("-"))
                        || (getLocation.getPublicProtectionClassification().equals("09") && ((currentDate.getYear() - yearBuilt) < 40));
                String expected = fireHydrantQuestion ? SPACE : NOT;
                fsa.assertEquals(isElementDisplayed(pwXPath(FIRE_HYDRANT_SECTION_XPATH)) && !isElementDisplayed(pwXPath(WILDFIRE_RISK_REDUCTION_XPATH)),
                        fireHydrantQuestion, "Contact Info page - Fire hydrant section" + expected + "present based on the getLocation response from appStore.");
            } catch (Exception e) {
                Log.warn("Some appStore data is unavailable:");
                Log.warn(e.toString());
            }
        }
        if (isElementDisplayed(pwXPath(FIRE_HYDRANT_SECTION_XPATH)) && !isElementDisplayed(pwXPath(WILDFIRE_RISK_REDUCTION_XPATH))) {
            selectFirehydrant(false);
            if (homeLobType.equals(HOME)) {
                fsa.assertEquals(getTextFromElement(fireHydrantSectionTitle), FIRE_HYDRANT_SECTION_TITLE, "Contact Info page - Fire hydrant section title.");
                if (isElementDisplayed(pwXPath(FIRE_HYDRANT_RADIO_BUTTON_QUESTIONS_XPATH))) {
                    fsa.assertEquals(getTextFromElement(fireHydrantSectionLabel), FIRE_HYDRANT_SECTION_LABEL, "Contact Info page - Fire hydrant section label.");
                    fsa.assertEquals(getTextFromElement(fireHydrantQuestionsText), TWO_ADDITIONAL_QUESTIONS_TEXT, "Contact Info page - Fire hydrant section 2 additional questions text.");
                }
                fsa.assertEquals(getTextFromElement(fireHydrantQuestion1label), FIRST_QUESTION_LABEL, "Contact Info page - Fire hydrant section 1st question label.");
                fsa.assertEquals(getTextFromElement(fireHydrantQuestion2label), SECOND_QUESTION_LABEL, "Contact Info page - Fire hydrant section 2nd question label.");
                List<String> secondQuestionOptions = locators(pwXPath(IS_SECONDARY_HEATING_SOURCE_BUTTON_QUESTION_XPATH + "//mat-radio-button"))
                        .stream().map(this::getTextFromElement).map(String::strip).collect(Collectors.toList());
                fsa.assertTrue(secondQuestionTextOptions.equals(secondQuestionOptions), "Contact Info page - Secondary Heating Source Options text.");
            } else {
                fsa.assertFalse(isElementPresent(pwXPath(FIRE_HYDRANT_RADIO_BUTTON_QUESTIONS_XPATH)), "Contact Info page - No additional questions for non-Home Lobs.");
            }
            selectFirehydrant(true);
        }
    }

    public void validateFireHydrantSectionErrorMessages(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception {
        final String ERROR_MESSAGE = "This is a required field.";
        if (isElementDisplayed(pwXPath(FIRE_HYDRANT_SECTION_XPATH)) && !isElementDisplayed(pwXPath(WILDFIRE_RISK_REDUCTION_XPATH))) {
            waitAndClickElement(defaultMailingAddressRadioButton);
            enterEmailIdAndPhoneNumberInContactInfoPage(applicant);
            selectFirehydrant(false);
            waitAndClickElement(agreeAndSubmitButton); // to activate Fire hydrant is home visible message

            List<String> errors = getPageErrors();
            fsa.assertTrue((errors.contains(ERROR_MESSAGE) && errors.size() == 1), "Contact Info page - Is this home visible error.");
            selectIsHomeVisible(false);
            waitAndClickElement(agreeAndSubmitButton); // to activate Fire hydrant SHS error message

            errors = getPageErrors();
            fsa.assertTrue((errors.contains(ERROR_MESSAGE) && errors.size() == 1), "Contact Info page - Is SHS installed error.");
            selectSecondaryHeatingSource("N");
            errors = getPageErrors();
            fsa.assertTrue(errors.isEmpty(), "Contact Info page - Fire hydrant section has no errors.");
        }
    }


    public void validateContentOfWildfireRiskReductionSection(FarmersSoftAssert fsa) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        if (appStore.getData().getLandingStateCode().equals(CA)) {
            final String WILDFIRE_RISK_REDUCTION_SECTION_TITLE = "Does this apply to your home?";
            final String WILDFIRE_RISK_REDUCTION_SECTION_LABEL = "This property is eligible for wildfire risk reduction discounts. (Select \"Yes\" to review eligibility.)";
            final String WILDFIRE_RISK_REDUCTION_SECTION_SUBTEXT = "1 of 12 factors apply Edit";
            final String WILDFIRE_RISK_REDUCTION_SIDE_SHEET_TITLE = "Wildfire risk reduction";
            final String WILDFIRE_RISK_REDUCTION_SIDE_SHEET_SUBTITLE = "Please review and check the items that apply to your community and property. We may have pre-checked some items " +
                    "for you, but you can update as needed.";
            final String WILDFIRE_RISK_REDUCTION_SIDE_SHEET_SUBTITLE2 = "Do these apply to your community?";
            final String WILDFIRE_RISK_REDUCTION_SIDE_SHEET_SECTION2_SUBTITLE = "Select any wildfire mitigation measures that you have implemented on your property:";
            List<String> WILDFIRE_RISK_REDUCTION_CHECKBOXES = List.of("The property is located within a Firewise community.", "The property is located within a Fire Risk Reduction community.",
                    "Code compliance", "Windows and shutters", "Property's vents are fire-resistant", "Property's eaves are enclosed", "Class-A roof installed", "Noncombustible materials",
                    "Removal of combustible structures", "Vertical clearance", "Decking", "Clearing within 5 feet of the home");

            final String WILDFIRE_RISK_REDUCTION_SIDE_SHEET_BLOB = "Wildfire risk reduction close Please review and check the items that apply to your community and property. We may have " +
                    "pre-checked some items for you, but you can update as needed. Do these apply to your community? The property is located within a Firewise community. The property is " +
                    "located within a Fire Risk Reduction community. Select any wildfire mitigation measures that you have implemented on your property: Code compliance Property complies " +
                    "with Section 4291 of the Public Resources Code, and with any local ordinances, governing defensible space, OR Code compliance does not apply to my property Windows " +
                    "and shutters Property has multi-pane windows, or dual-pane windows, or functional shutters, which --when closed-- cover the entire window and do not have openings. " +
                    "Property's vents are fire-resistant Property's eaves are enclosed Class-A roof installed We received verification of this installation and have pre-checked this for you. " +
                    "Noncombustible materials Incorporation of only noncombustible materials into that portion of any improvements to the property on which the property is located, " +
                    "including fences and gates, within 5 feet of the home. Removal of combustible structures Removal or absence of combustible structures, including sheds and other " +
                    "outbuildings, from the area within 30 feet of the home, or from as much of the area that's under the control of the insured. Vertical clearance Property has at least 6 " +
                    "inches of noncombustible vertical clearance at the bottom of the exterior surface of the building, measured from the ground up. Decking Clearing of vegetation and debris from " +
                    "under decks, OR There is no decking Clearing within 5 feet of the home Clearing of vegetation, debris, mulch, stored combustible materials, and movable combustible objects.";


            List<String> wildfireOptions = new ArrayList<>();
            if (appStore.getHome().getContactInfo() != null) {
                wildfireOptions = appStore.getHome().getContactInfo().getWildFireOptions();
            }
            if ((wildfireOptions != null) && (!wildfireOptions.isEmpty())) {
                fsa.assertTrue(isElementDisplayed(pwXPath(WILDFIRE_RISK_REDUCTION_XPATH)), "Contact info page - Wildfire risk reduction section is displayed.");
                fsa.assertTrue(getAttributeData(wildfireRiskMatButtonToggleYes, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED), "Contact info page - Wildfire risk reduction Yes button is selected.");
                fsa.assertFalse(getAttributeData(wildfireRiskMatButtonToggleNo, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED), "Contact info page - Wildfire risk reduction No button is Not selected.");
                fsa.assertFalse(wildfireRiskButtonToggleNo.isEnabled(), "Contact info page - Wildfire risk reduction No button is disabled.");
                fsa.assertEquals(getTextFromElement(fireHydrantSectionTitle), WILDFIRE_RISK_REDUCTION_SECTION_TITLE, "Contact info page - Wildfire risk reduction section title.");
                fsa.assertEquals(getTextFromElement(wildfireRiskReductionLabelCA) + SPACE + getTextFromElement(wildfireRiskReductionSpanCA), WILDFIRE_RISK_REDUCTION_SECTION_LABEL,
                        "Contact Info page - Wildfire risk reduction section label.");
                fsa.assertEquals(getTextFromElement(wildfireRiskReductionSubtextCA), WILDFIRE_RISK_REDUCTION_SECTION_SUBTEXT,
                        "Contact Info page - Wildfire risk reduction section sub-text.");
                // validate wildfire risk reduction side sheet
                waitAndClickElement(editWildfireRiskReduction);
                conditionalWait(5).until(Conditions.clickable(closeWildfireSideSheet));
                fsa.assertEquals(getTextFromElement(wildfireRiskReductionSideSheet), WILDFIRE_RISK_REDUCTION_SIDE_SHEET_BLOB, "Contact info page - Wildfire risk reduction section text (BLOB).");
                fsa.assertEquals(getTextFromElement(wildfireRiskReductionSideSheetTitle), WILDFIRE_RISK_REDUCTION_SIDE_SHEET_TITLE, "Contact info page - Wildfire risk reduction section title.");
                fsa.assertTrue(isElementDisplayed(wildfireRiskReductionSideSheetDivider,1), "Contact info page - Wildfire risk reduction section title divider.");
                fsa.assertEquals(getTextFromElement(wildfireRiskReductionSideSheetSubtitle), WILDFIRE_RISK_REDUCTION_SIDE_SHEET_SUBTITLE, "Contact info page - Wildfire risk reduction section subtitle.");
                fsa.assertTrue(isElementDisplayed(wildfireRiskReductionSideSheetDivider1,1), "Contact info page - Wildfire risk reduction section sub-divider 1.");
                fsa.assertEquals(getTextFromElement(wildfireRiskReductionSideSheetSubtitle2), WILDFIRE_RISK_REDUCTION_SIDE_SHEET_SUBTITLE2, "Contact info page - Wildfire risk reduction section subtitle 2.");
                fsa.assertEquals(getTextFromElement(wildfireRiskReductionSideSheetSection2Subtitle), WILDFIRE_RISK_REDUCTION_SIDE_SHEET_SECTION2_SUBTITLE, "Contact info page - Wildfire risk reduction section2 subtitle.");
                fsa.assertTrue(isElementDisplayed(wildfireRiskReductionSideSheetDivider2,1), "Contact info page - Wildfire risk reduction section sub-divider 2.");
                List<String> checkboxLabels = wildfireRiskReductionSideSheetCheckboxLabels.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
                fsa.assertEquals(checkboxLabels,WILDFIRE_RISK_REDUCTION_CHECKBOXES, "Contact info page - Wildfire risk reduction checkbox titles.");
                for (Locator checkbox : wildfireRiskReductionSideSheetCheckboxes.all()) {
                    if (getAttributeData(checkbox, CLASS).contains(MAT_CHECKBOX_CHECKED)) {
                        String option = getValueFromLocator(checkbox.locator(pwXPath("descendant::input"))).strip();
                        Log.info("Selected option value: " + option);
                        fsa.assertTrue(wildfireOptions.stream().anyMatch(e -> e.equals(option)), "Contact info page - Wildfire risk reduction checked checkbox titles match to the appStore values.");
                    }
                }
                waitAndClickElement(closeWildfireSideSheet);
            } else {
                fsa.assertFalse(isElementDisplayed(pwXPath(WILDFIRE_RISK_REDUCTION_XPATH)), "Contact Info page - Wildfire risk reduction section is not displayed.");
            }
        }
    }

    public void enterPolicyStartDate(ApplicantAceHome applicant) {
        String earlyShoppingFactor = applicant.getEarlyShoppingFactor();
        if (earlyShoppingFactor.equals(TRUE)) {
            String policyStartDate = getFormattedForPolicyStartDate(getTodayDate().plusDays(7));
            sendKeysToElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDateInputField), policyStartDate);
        } else {
            if(!earlyShoppingFactor.equals(FALSE) && !earlyShoppingFactor.isBlank()){
                sendKeysToElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDateInputField), earlyShoppingFactor);
            }
        }
    }

    // Update policy start date randomly
    public void updatePolicyStartDate(ApplicantAceHome applicant) {
        Random random = new Random();
        int randomDays = random.nextInt(12) + 3; // Any random day between 3 and 12;
        String policyStartDate = getFormattedForPolicyStartDate(getTodayDate().plusDays(randomDays));
        sendKeysToElement(waitElementBeVisible(policyStartDateOrEstimatedClosingDateInputField), policyStartDate);
    }

    public String getPolicyStartDate() {
        return getValueFromLocator(policyStartDateOrEstimatedClosingDateInputField);
    }

    public void enterFireHydrantData(ApplicantAceHome applicant) throws Exception {
        if (isElementPresent(pwXPath(FIRE_HYDRANT_SECTION_XPATH))) {
            if (isElementPresent(pwXPath(FIRE_HYDRANT_BUTTON_XPATH))) {
                selectFirehydrant(applicant.isFireHydrant());
            }
            if (isElementPresent(pwXPath(IS_HOME_VISIBLE_QUESTION_BUTTON_XPATH + "//mat-radio-group"))) {
                selectIsHomeVisible(applicant.isHomeVisible());
            }
            if (isElementPresent(pwXPath(IS_SECONDARY_HEATING_SOURCE_BUTTON_QUESTION_XPATH))) {
            	String valueFromApplicant = applicant.getSecondaryHeatingSource();
            	String secondaryHeating = valueFromApplicant.isBlank()? "N": valueFromApplicant.equals(TRUE)? "P": valueFromApplicant;
                selectSecondaryHeatingSource(secondaryHeating);
            }
        }
    }

    public boolean isBundleCheckboxSelected(String name) throws Exception {
    	return isCheckboxChecked(locator(pwXPath(BUNDLE_CHECKBOXES_XPATH + "//span[text()='" + name + "']/ancestor::mat-checkbox//input")));
    }

    public String getEmailAddress() {
        return getValueFromLocator(emailAddressInput);
    }

    public String getPhoneNumber() {
        return getValueFromLocator(phoneNumberInput);
    }

    public void validateContactInfoSelections(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        // Policy start date
        String policyStartDate = applicant.getEarlyShoppingFactor().trim();
        if (policyStartDate.equals(TRUE)) {
            policyStartDate = getFormattedForPolicyStartDate(getTodayDate().plusDays(7));
        } else if (policyStartDate.isBlank() || policyStartDate.equals(FALSE)) {
            policyStartDate = getFormattedForPolicyStartDate(getTodayDate().plusDays(1));
        }
        fsa.assertEquals(getPolicyStartDate(), policyStartDate, "Contact Info page - Policy start date value.");
        // Fire hydrant question
        if (isElementDisplayed(pwXPath(FIRE_HYDRANT_SECTION_XPATH))) {
            fsa.assertEquals(getFireHydrantYesNo(), applicant.isFireHydrant(), "Contact Info page - Fire hydrant question value.");
        }
        // Discount bundles
        List<SqlDiscount> discounts = applicant.getDiscounts();
        SqlDiscount discount = discounts.stream().findFirst().orElse(null);
        assert discount != null;
        fsa.assertEquals(isBundleCheckboxSelected(AUTO), discount.isAutoInsurance(), "Contact Info page - bundle Auto insurance");
        if (!isNoLifeBundleState(applicant.getStateCode())) {
            fsa.assertEquals(isBundleCheckboxSelected(LIFE), discount.isLifeInsurance(), "Contact Info page - bundle Life insurance");
        }
        if (!isNonUmbrellaState(applicant.getStateCode())) {
            fsa.assertEquals(isBundleCheckboxSelected("Umbrella"), discount.isUmbrellaInsurance(), "Contact Info page - bundle Umbrella insurance");
        }
        if (isAdditionalHomeBundleDiscountsState(applicant.getStateCode())) {
            fsa.assertEquals(isBundleCheckboxSelected("Business"), discount.isBusinessInsurance(), "Contact Info page - bundle Business insurance");
            fsa.assertEquals(isBundleCheckboxSelected("Recreational Boat/Watercraft"), discount.isRecreationalBoatWatercraftInsurance(),
                    "Contact Info page - bundle Recreational Boat/Watercraft insurance");
            fsa.assertEquals(isBundleCheckboxSelected("Off-Road Vehicle"), discount.isMotorcycleInsurance(), "Contact Info page - bundle Off-Road Vehicle insurance");
            fsa.assertEquals(isBundleCheckboxSelected("Motorhome, Travel Trailer or 5th Wheel"), discount.isMotorHome(),
                    "Contact Info page - bundle Motorhome, Travel Trailer or 5th Wheel insurance");
        }
        // Mailing address
        AppStore.Data.CustomerData.Address address = getSessionStorageAppStore().getData().getCustomerData().getAddress();
        fsa.assertEquals(getAttributeData(defaultMailingAddressRadioButton, CLASS).contains(RADIO_BUTTON_CHECKED), true,
                "Contact Info page - Default mailing address radio-button is selected.");
        fsa.assertEquals(getTextFromElement(defaultMailingAddressRadioButtonLabel).toUpperCase(), address.getNew_address().toUpperCase(),
                "Contact Info page - Default mailing address");
        fsa.assertEquals(getAttributeData(otherMailingAddressRadioButton, CLASS).contains(RADIO_BUTTON_CHECKED), false,
                "Contact Info page - Other mailing address radio-button is selected.");
        // Contact info
        fsa.assertTrue(isEmailAddressReadOnly(), "Contact Info page - e-mail address is ready-only.");
        fsa.assertTrue(isPhoneNumberReadOnly(), "Contact Info page - phone is ready-only.");
        fsa.assertEquals(getEmailAddress(), applicant.getEmailAddress(), "Contact Info page - e-mail address.");
        fsa.assertEquals(getPhoneNumber(), getFormattedPhoneNumber(applicant.getPhoneNumber()), "Contact Info page - phone number.");

    }

    public boolean validateFloorResidenceIsLocatedOnSection(String lob) {
        boolean result;
        if (lob.equals(RENTERS)) {
            result = isElementDisplayed(residenceFloorSection, 1) &&
                    getTextFromElement(residenceFloorSectionSubtitle).equals("Does this apply to your home?") &&
                    getTextFromElement(residenceFloorInfoLabel).equals("My unit is on the third floor, or higher") &&
                    getTextFromElement(residenceFloorInfoDescription).equals("It is not located in the basement, first, or second floor");
        } else {
            result = !isElementDisplayed(residenceFloorSection, 1) &&
                    !isElementDisplayed(residenceFloorCheckbox, 1) &&
                    !isElementDisplayed(residenceFloorInfoLabel, 1) &&
                    !isElementDisplayed(residenceFloorInfoDescription,1);
        }
        return result;
    }

    public void validateADA(String lobType) throws Exception {
        clearOutFieldUsingBackSpace(policyStartDateOrEstimatedClosingDateInputField);
        if (isElementVisible(fireHydrantSection,2)) {
            selectFirehydrant(false);
            if (isElementDisplayed(pwXPath(IS_HOME_VISIBLE_QUESTION_BUTTON_XPATH+"//mat-radio-button"))) {
                selectIsHomeVisible(false);
                selectSecondaryHeatingSource("P");
            }
        }
        scrollAndClickOnElement(otherMailingAddressRadioButton);
        waitAndClickElement(agreeAndSubmitButton);
        performADATesting("AceHRCContactInfoPage",MARKETING_IT,lobType);
        refreshPage();
    }
    public boolean isResidenceInEscrow(AppStore sessionStorage) {
        Field field = sessionStorage.getHome().getAddressForm().getFields().get(0);
        return (field.getIsNewHome() != null && field.getIsNewHome().equals("Y") && field.getInEscrow().equals("Y"));
    }

    public void validatePrimaryNameInsured(ApplicantAceHome applicant, FarmersSoftAssert fsa) {
        final String PRIMARY_INSURANCE_NAME_TITLE = "Primary named insured";
        fsa.assertEquals(getTextFromElement(primaryInsuranceGroupTitle),PRIMARY_INSURANCE_NAME_TITLE, "Primary Name Insured section title verification.");
        String expectedPNI = applicant.getFirstName() +" "+ applicant.getLastName();
        fsa.assertEquals(getTextFromElement(primaryInsuredName), expectedPNI, "Primary Name Insured match.");
    }
    public void validateConsentSectionFramersInsuranceGroup(FarmersSoftAssert fsa) throws Exception {
        isElementDisplayed(contactInfoDisclaimer, 3);
        String CONSENT_TEXT = "String making the selection(s) below and clicking \"Agree and submit\", you agree to these ESIGN term and " +
                "conditions and to receive marketing calls and text messages as detailed below.";
        fsa.assertEquals(getTextFromElement(contactInfoDisclaimer), CONSENT_TEXT, "Contact info page - Consent text");
        String INSURANCE_GROUP_SECTION_TITLE = "Choose Farmers Insurance Group\u00AE brands to select the scope of your consent.";
        fsa.assertEquals(getTextFromElement(selectInsuranceGroupTitle), INSURANCE_GROUP_SECTION_TITLE, "Contact Info page - Selection of Insurance Group section title verification.");
        String expectedSelectAllCheckboxLabel = "Select all parties, or ...";
        fsa.assertEquals(getTextFromElement(selectAllCheckboxLabel), expectedSelectAllCheckboxLabel, "Select all  label verification.");
        String expectedSelectAllCheckboxSubLabel = "Choose them individually below:";
        fsa.assertEquals(getTextFromElement(selectAllCheckboxSubLabel), expectedSelectAllCheckboxSubLabel, "Select all sub label verification.");

        String expectedFarmersCheckboxLabel = "Farmers\u00AE";
        fsa.assertEquals(getTextFromElement(farmersCheckboxLabel), expectedFarmersCheckboxLabel, "Farmers label checkbox text verification.");
        String expectedFarmersCheckboxSubLabel = "Auto, property, umbrella, business, financial services, and more";
        fsa.assertEquals(getTextFromElement(farmersCheckboxSubLabel), expectedFarmersCheckboxSubLabel, "Farmers sub label checkbox text verification.");

        String expectedBWCheckboxLabel = "Bristol West\u00AE";
        fsa.assertEquals(getTextFromElement(BWCheckboxLabel), expectedBWCheckboxLabel, "BW label  verification.");
        String expectedBWCheckboxSubLabel = "Commercial and non-standard auto";
        fsa.assertEquals(getTextFromElement(BWCheckboxSubLabel), expectedBWCheckboxSubLabel, "BW sub label verification.");
        int numberOfCheckboxes = individualBrandCheckboxes.count();
        for (int i = 0; i < numberOfCheckboxes; i++) {
            checkUncheckMatCheckbox(String.format(BRANDS_CHECKBOXES_XPATH, i + 1), true);
            Log.info("Checkbox " + (i + 1) + " is now selected.", true);
            checkUncheckMatCheckbox(String.format(BRANDS_CHECKBOXES_XPATH, i + 1), false);
            Log.info("Checkbox " + (i + 1) + " is now unselected.", true);
        }
        checkUncheckMatCheckbox(ALL_BRANDS_CHECKBOX_XPATH, true);
        Log.info("Select all checkbox is now selected.", true);
        checkUncheckMatCheckbox(ALL_BRANDS_CHECKBOX_XPATH, false);
        Log.info("Select All Checkbox is now unselected.", true);

        validatePageLinksNavigationTitles(fsa);
    }

    public void verifyBundleTextChangesForHRCContactInfoPage(FarmersSoftAssert fsa, boolean isInEscrow){
        String expectedPropertyPolicyStartDateHeader = "Property policy start date";
        fsa.assertEquals(getTextFromElement(lastStepBeforeYourPageHeader), expectedPropertyPolicyStartDateHeader, expectedPropertyPolicyStartDateHeader + " header text validation");
        if( isInEscrow) {
            fsa.assertEquals(getTextFromElement(policyStartDateOrEstimatedClosingDateTitle), EXPECTED_ESTIMATED_CLOSING_DATE_TITLE, EXPECTED_ESTIMATED_CLOSING_DATE_TITLE + " header text validation");
            fsa.assertEquals(getTextFromElement(policyStartDateOrEstimatedClosingDatePlaceHolderText), EXPECTED_ESTIMATED_CLOSING_DATE_AREA_LABEL,EXPECTED_ESTIMATED_CLOSING_DATE_AREA_LABEL + " place holder text validation");
        } else {
            String expectedPolicyBeginQuestionText = "When would you like your property policy to begin?";
            fsa.assertEquals(getTextFromElement(policyStartDateOrEstimatedClosingDateTitle), expectedPolicyBeginQuestionText, expectedPolicyBeginQuestionText + " question text validation");
            fsa.assertEquals(getTextFromElement(policyStartDateOrEstimatedClosingDatePlaceHolderText), expectedPropertyPolicyStartDateHeader, expectedPropertyPolicyStartDateHeader + " place holder text validation");
        }
        fsa.assertEquals(getTextFromElement(continueButtonBundleContactInfoPage), "Continue", "Continue button text validation");
    }

    public String getPropertyPolicyStartDateOrEstimatedClosingDateValue(){
        return getElementValue(policyStartDateOrEstimatedClosingDateInputField, "HRC policy start date:").trim();
    }

}
