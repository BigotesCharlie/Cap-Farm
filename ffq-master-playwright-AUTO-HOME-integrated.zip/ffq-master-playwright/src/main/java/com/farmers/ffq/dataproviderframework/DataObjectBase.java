/**
=============================================
* Author:	Zhabiz Sonee
* Create date:	02/01/2017
=============================================
*/
package com.farmers.ffq.dataproviderframework;

public abstract class DataObjectBase {
	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
