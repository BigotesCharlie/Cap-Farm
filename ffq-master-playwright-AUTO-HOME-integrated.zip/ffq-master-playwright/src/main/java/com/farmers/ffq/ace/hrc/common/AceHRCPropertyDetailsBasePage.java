package com.farmers.ffq.ace.hrc.common;








import com.farmers.framework.playwright.Keys;
import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.TimeoutError;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.testng.Assert;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.farmers.ffq.utils.GlobalVariables.*;
public class AceHRCPropertyDetailsBasePage extends AceHRCBasePage {
    public static final String TYPE_OF_HOME = "Type of home";
    public static final String ROOF_COVER = "Roof cover";
    public static final String EXTERIOR_WALL_FINISH = "Exterior wall finish";
    public static final String NO_GARAGE = "No garage";
    public static final String GARAGE_CARPORT = "Garage / carport";
    public static final String GARAGE_STYLE = "Garage style";
    public static final String FLOORS = "Floors";
    public static final String FLOOR_COVERINGS = "floorCoverings";
    public static final String FIREPLACE = "Fireplace";
    public static final String STORIES = "Stories";
    public static final String BATHROOMS = "Bathrooms";
    public static final String BASEMENT = "Basement";
    public static final String FOUNDATION_TYPE = "Foundation type";
    public static final String FINISHED_BASEMENT = "Finished basement";
    public static final String TOTAL_SQ_FT = "Total finished sq. ft";
    public static final String YEAR_BUILT = "Year built";
    public static final String NUMBER_OF_STORIES = "numberOfStories";
    public static final String NUMBER_OF_BATHROOM = "numberOfBathroom";
    private static final String MARKET_VALUE = "Market value";
    private static final String FIRE_SPRINKLER_SYSTEM = "Fire sprinkler system";
    private static final String PAGE_TITLE = "Here's what we have so far";
    private static final String PAGE_SUBTITLE = "Please check the information below. You should edit items that are not accurate.";
    protected static final String PROPERTY_DETAILS_PAGE = "Property Details page - ";
    protected static final String ERROR_FOUND = " - error found.";

    private static final String PROPERTY_FIELD_XPATH = "//app-property-details//div[contains(.,'%s') and contains(@class,'tui-field-label')]";
    private static final String MODAL_PROPERTY_FIELD_XPATH = "//tui-subcategory-selector-modal//div[text()='%s']";
    private static final String FOLLOWING_SIBLING_DIV = "/following-sibling::div";
    private static final String FOLLOWING_SIBLING_DIV_SPAN = "/following-sibling::div/span[@aria-hidden='true']";

        private Locator pageTitle = locator(pwXPath("//app-property-details//h1"));

        private Locator pageSubTitle = locator(pwXPath("//app-property-details//div[contains(@class,'home-property-details-header')]"));

        private Locator propertyAddressLine1 = locator(pwXPath("//app-property-details//div[contains(@class,'property-details-address-holder')]/div[1]"));

        private Locator propertyAddressLine2 = locator(pwXPath("//app-property-details//div[contains(@class,'property-details-address-holder')]/div[2]"));


        private Locator editDetailsButton = locator(pwXPath("//app-property-details//button[@aria-label='Edit Home details']"));

        private Locator reviewAndEditInfoButton = locator(pwXPath("//app-property-details//button[text()='Review & edit information']"));

        private Locator editHomeDetailsModalTitle = locator(pwXPath("//tui-subcategory-selector-modal//h2"));

        protected Locator closeEditPropertyModal = locator(pwXPath("//tui-subcategory-modal//mat-icon[text()='close']"));

        private Locator closeEditHomeDetailsModal = locator(pwXPath("//tui-subcategory-selector-modal//button[contains(text(),'Close')]"));

        protected Locator editPropertyModalTitle = locator(pwXPath("//tui-subcategory-modal//h2"));

        protected Locator editPropertyModalText = locator(pwXPath("//tui-subcategory-modal//div[contains(@class,'tui-input-text')]"));

        protected Locator editPropertyModalInput = locator(pwXPath("//tui-subcategory-modal//div[contains(@class,'tui-input-text')]/following-sibling::div//input"));

        private Locator editBathroomsPropertyModalInputs = locator(pwXPath("//tui-subcategory-modal//div[contains(@class,'tui-input-text')]/following-sibling::div//input"));

        protected Locator editPropertyModalLabel = locator(pwXPath("//tui-subcategory-modal//div[contains(@class,'tui-input-text')]/following-sibling::div//label"));

        private Locator editBathroomsPropertyModalLabels = locator(pwXPath("//tui-subcategory-modal//div[contains(@class,'tui-input-text-2')]"));

        protected Locator editPropertyModalCaption = locator(pwXPath("//tui-subcategory-modal//div[contains(@class,'tui-input-text')]/following-sibling::div[contains(@class,'tui-caption')]"));

        protected Locator editPropertyModalLightBulbText = locator(pwXPath("//tui-subcategory-modal//div[contains(@class,'tui-subcategory-lightbulb-icon-container')]//div[contains(@class,'tui-caption')]"));

        private Locator editPropertyModalLowerLabel = locator(pwXPath("//tui-subcategory-modal//div[contains(@class,'tui-field-label')]"));

        private Locator editBathroomsPropertyModalSubTexts = locator(pwXPath("//tui-subcategory-modal//div[contains(@class,'textfield-subtext')]"));

        private Locator updateEditPropertyModalButton = locator(pwXPath("//tui-subcategory-modal//button[text()='Update']"));

    private static final String EDIT_MODAL_RADIO_BUTTON_XPATH = "//tui-subcategory-modal//mat-radio-button";
        private Locator radioButton = locator(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH));

        private Locator editPropertyModalSelectedRadioButton = locator(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH + "[contains(@class,'radio-checked')]"));

    private static final String EDIT_MODAL_TOGGLE_BUTTON_XPATH = "//tui-subcategory-modal//mat-button-toggle";

        private Locator editPropertyModalSelectedAtticToggleButton = locator(pwXPath(EDIT_MODAL_TOGGLE_BUTTON_XPATH + "[contains(@class,'toggle-checked')]"));

    protected static final String EDIT_MODAL_CHECKBOX_XPATH = "//tui-subcategory-modal//mat-checkbox";
        private Locator editPropertyModalCheckbox = locator(pwXPath(EDIT_MODAL_CHECKBOX_XPATH));

    protected static final String EDIT_MODAL_CHECKBOX_CHECKED_XPATH = "[contains(@class,'checkbox-checked')]";
        private Locator editPropertyModalSelectedCheckbox = locator(pwXPath(EDIT_MODAL_CHECKBOX_XPATH + EDIT_MODAL_CHECKBOX_CHECKED_XPATH));

    private final List<String> listOfPropertyDetails = Arrays.asList(STORIES, BATHROOMS, FIREPLACE, FLOORS, GARAGE_STYLE, GARAGE_CARPORT,
            EXTERIOR_WALL_FINISH, FOUNDATION_TYPE, FINISHED_BASEMENT, ROOF_COVER, TYPE_OF_HOME, MARKET_VALUE, FIRE_SPRINKLER_SYSTEM);

        private Locator editPropertyModalLabels = locator(pwXPath("//tui-subcategory-selector-modal//div[contains(@class,'tui-field-label')]"));

        private Locator seeExamples = locator(pwXPath("//mat-dialog-container//button[contains(text(),'See examples')]"));

        private Locator examplesCategorySelect = locator(pwXPath("//mat-dialog-container//mat-select"));

        private Locator examplesCategoryTitle = locator(pwXPath("//tui-subcategory-examples-modal//h2"));

        private Locator examplesCategorySelectArrow = locator(pwXPath("//mat-dialog-container//mat-select"));

    private static final String CATEGORIES_LISTBOX_XPATH = "//div[@role='listbox']";
        private Locator categoryOptions = locator(pwXPath(CATEGORIES_LISTBOX_XPATH + "/mat-option"));
        private Locator firstCategoryOption = locator(pwXPath(CATEGORIES_LISTBOX_XPATH + "/mat-option"));

    private static final String SUBCATEGORY_HEADING_XPATH = "//div[contains(@class,'subcategory-examples')]//div[text()='%s']";
        private Locator subcategoryHeading = locator(pwXPath("//div[contains(@class,'subcategory-examples')]/div/div[1]"));

        private Locator subcategoryText = locator(pwXPath("//div[contains(@class,'subcategory-examples')]/div/div[2]"));

    private static final String SUBCATEGORY_IMAGE_XPATH = "//div[contains(@class,'subcategory-examples')]/div/img[@alt='%s']";
        private Locator subcategoryImage = locator(pwXPath("//div[contains(@class,'subcategory-examples')]/div/img"));

        private Locator closeEditPropertyExamplesModal = locator(pwXPath("//tui-subcategory-examples-modal//mat-icon[text()='close']"));

        private Locator propertyUpdatedSnackbar = locator(pwXPath("//tui-subcategory-selector-modal//*[contains(@class,'mat-simple-snackbar')]"));

    /**
     * Default Constructor
     */
    public AceHRCPropertyDetailsBasePage() throws Exception {
    }

    public boolean isOnPropertyDetailsPage() {
        try {
            wait.until(Conditions.or(Conditions.clickable(editDetailsButton),
                    Conditions.clickable(reviewAndEditInfoButton)));
        } catch (PlaywrightException exception) {
            return false;
        }
        return true;
    }

    public boolean isPageTitleDisplayed() {
        return getPageTitle().equals(PAGE_TITLE);
    }

    public boolean isPageTitleInViewport() throws Exception {
        return isElementInViewport(pageTitle);
    }

    public String getPageTitle() {
        return getTextFromElement(pageTitle);
    }
    public boolean isPageSubtitleDisplayed() {
        return getPageSubtitle().equals(PAGE_SUBTITLE);
    }

    public String getPageSubtitle() {
        return getTextFromElement(pageSubTitle);
    }

    public String getPropertyDetailsAddress() {
        return getTextFromElement(propertyAddressLine1) + COMMA + SPACE + getTextFromElement(propertyAddressLine2);
    }

    public String getPropertyDetailsAddressLine1() {
        return getTextFromElement(propertyAddressLine1);
    }

    public String getPropertyDetailsAddressLine2() {
        return getTextFromElement(propertyAddressLine2);
    }

    public String getPropertyDetailsFieldValue(String field) throws Exception {
        Locator fieldWe = locator(pwXPath(String.format(PROPERTY_FIELD_XPATH, field) + FOLLOWING_SIBLING_DIV_SPAN));
        return getTextFromElement(fieldWe);
    }

    public boolean isPropertyDetailsFieldDisplayed(String field) throws Exception {
        return !locators(pwXPath(String.format(PROPERTY_FIELD_XPATH, field) + FOLLOWING_SIBLING_DIV_SPAN)).isEmpty();
    }

    public String getEditModalPropertyDetailsFieldValue(String field) throws Exception {
        Locator fieldWe = locator(pwXPath(String.format(MODAL_PROPERTY_FIELD_XPATH, field) + "/following-sibling::div/div"));
        return getTextFromElement(fieldWe);
    }

    public boolean isEditModalPropertyDetailsFieldDisplayed(String field) throws Exception {
        return !locators(pwXPath(String.format(MODAL_PROPERTY_FIELD_XPATH, field) + "/following-sibling::div/div")).isEmpty();
    }

    public void clickEditModalPropertyDetailsFieldEditButton(String field) throws Exception {
        Locator editFieldWe = locator(pwXPath(String.format(MODAL_PROPERTY_FIELD_XPATH, field) + "/following-sibling::div/mat-icon"));
        waitAndClickElement(editFieldWe);
    }

    public List<String> getListOfPropertyDetailsEditModal() {
        return editPropertyModalLabels.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public void clickEditDetailsButton() {
        try {
            conditionalWait(5).until(Conditions.clickable(editDetailsButton));
            scrollAndClickOnElement(editDetailsButton);
        } catch (Exception e) {
            waitAndClickElement(reviewAndEditInfoButton);
        }
        waitElementBeVisibleClickable(closeEditHomeDetailsModal);
    }

    public void selectEditModalRadioButtonByName(String buttonName) throws Exception {
        waitElementBeVisibleClickable(radioButton);
        Locator we = locator(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH + "[contains(.,'" + buttonName + "')]//label"));
        waitAndClickElement(we);
        Locator we2 = locator(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH + "[contains(.,'" + buttonName + "')]"));
        if (getAttributeData(we2, CLASS).contains(RADIO_BUTTON_CHECKED)) {
            waitAndClickElement(we);
        }
    }

    private boolean isAnyRadioButtonSelected() throws Exception {
        return !locators(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH + "[contains(@class,'radio-checked')]")).isEmpty();
    }

    private boolean isCheckboxSelected(String checkboxName) throws Exception {
        Locator we = locator(pwXPath(EDIT_MODAL_CHECKBOX_XPATH + "[contains(.,'" + checkboxName + "')]"));
        return getAttributeData(we, CLASS).contains(CHECKBOX_CHECKED);
    }

    public void selectEditModalCheckboxByName(String checkBoxName) throws Exception {
        List<String> checkboxes = List.of(checkBoxName.split(COMMA));
        List<String> listCheckboxes = locators(pwXPath(EDIT_MODAL_CHECKBOX_XPATH)).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        for (String checkBox : listCheckboxes) {
            Locator we = locator(pwXPath(EDIT_MODAL_CHECKBOX_XPATH + "[contains(.,'" + checkBox + "')]//label"));
            if ((checkboxes.contains(checkBox) && !isCheckboxSelected(checkBox)) ||
                    (!checkboxes.contains(checkBox) && isCheckboxSelected(checkBox))) {
                waitAndClickElement(we);
            }
        }
        List<Locator> checkedCheckboxes = locators(pwXPath(EDIT_MODAL_CHECKBOX_XPATH + EDIT_MODAL_CHECKBOX_CHECKED_XPATH));
        if (checkedCheckboxes.isEmpty()) {
            waitAndClickElement(editPropertyModalCheckbox);
        }
    }

    public void selectValueInTypeAhead(Locator fieldWe, String value) throws Exception {
        waitAndClickElement(fieldWe);
        sendKeysToElement(fieldWe, value);
        waitForElements("//mat-option");
        String matOptionXpath = pwXPath("//div//mat-option[contains(.,'" + value + "')]");
        conditionalWait(20).until(Conditions.clickable(matOptionXpath));
        Locator we = locator(matOptionXpath);
        waitAndClickElement(we);
    }

    public void enterBathrooms(String bathrooms) {
        boolean bUpdated = false;
        List<String> baths = new ArrayList<>(List.of(bathrooms.split(COMMA)));
        int numberOfBathroomsInModal = editBathroomsPropertyModalInputs.count();
        for (int i = baths.size(); i < numberOfBathroomsInModal; i ++) {
            baths.add(ZERO);
        }
        for (int i = 0; i < baths.size(); i++) {
            Locator bathWe = editBathroomsPropertyModalInputs.nth(i);
            if (!getValueFromLocator(bathWe).equals(baths.get(i))) {
                waitAndClickElement(bathWe);
                sendKeysToElement(bathWe, baths.get(i) + Keys.TAB);
                bUpdated = true;
            }
        }
        if (bUpdated) {
            clickUpdatePropertyDetail(BATHROOMS, false);
        } else {
            waitAndClickElement(closeEditPropertyModal);
        }
    }

    public void clickCloseEditModal() {
        waitAndClickElement(closeEditHomeDetailsModal);
    }

    public boolean isPropertyUpdatedSnackbarDisplayed(String message) {
        if (isElementVisible(propertyUpdatedSnackbar, 3)) {
            return getTextFromElement(propertyUpdatedSnackbar).equals(message);
        }
        return false;
    }
    public void clickUpdatePropertyDetail(String property, boolean checkSnackbar) {
    	//Update button only appears when something changed, otherwise just dismiss the modal
    	if (isElementDisplayed(updateEditPropertyModalButton, 3)) {
    		scrollAndClickOnElement(updateEditPropertyModalButton);
        	if (isElementDisplayed(updateEditPropertyModalButton, 1)) {
        		waitElementBeInvisible(updateEditPropertyModalButton);
        	}
    		if (checkSnackbar) {
    			Assert.assertTrue(isPropertyUpdatedSnackbarDisplayed(property + " updated"), "Property details page - " + property +
    					" updated side-sheet Snackbar is displayed.");
    		}
    	} else {
            scrollAndClickOnElement(closeEditPropertyModal);
    	}
    }

    public void clearInputFieldModal() {
        waitAndClickElement(editPropertyModalInput);
        clearOutFieldUsingBackSpace(editPropertyModalInput);
        sendKeysToElement(editPropertyModalInput, Keys.TAB);
        waitElementBeVisible(errorMessage, 2);
    }

    public void clickAtticButton(boolean isAttic) throws Exception {
        String attic = isAttic ? "Yes" : "No";
        Locator weAttic = locator(pwXPath(EDIT_MODAL_TOGGLE_BUTTON_XPATH + "[contains(.,'"+attic+"')]"));
        waitAndClickElement(weAttic);
    }

    public boolean getAttic() {
        return getTextFromElement(editPropertyModalSelectedAtticToggleButton).equals(YES);
    }
    public boolean isAtticAvailable() throws Exception {
        AppStore.Home.PropertyDetailsForm propertyDetailsForm = getSessionStorageAppStore().getHome().getPropertyDetailsForm();
        if (propertyDetailsForm == null) {
            return false;
        }
        String numberOfStoriesOriginalValue = propertyDetailsForm.getFields().stream().filter(i -> i.getFieldName().equals("numberOfStories")).collect(Collectors.toList()).get(0).getValues().get(0).getWebDesc();
        return numberOfStoriesOriginalValue.contains("Attic");
    }
    public String getFinishedBasement() throws Exception {
        AppStore appStore = this.getSessionStorageAppStore();
        String finishedBasement = appStore.getHome().getPropertyDetailsForm().getFieldValueByName("finishedPercentOfLowestLevel");
        int percentageOfFinishedBasement;
        if (finishedBasement != null) {
            percentageOfFinishedBasement = Integer.parseInt(finishedBasement);
            if (percentageOfFinishedBasement > 0) {
                if (percentageOfFinishedBasement <= 25) {
                    percentageOfFinishedBasement = 25;
                } else if (percentageOfFinishedBasement <= 50) {
                    percentageOfFinishedBasement = 50;
                } else if (percentageOfFinishedBasement <= 75) {
                    percentageOfFinishedBasement = 75;
                } else {
                    percentageOfFinishedBasement = 100;
                }
            }
            finishedBasement = String.valueOf(percentageOfFinishedBasement);
        }
        return finishedBasement;
    }

    public void validateEditYearBuilt(String yearBuilt, FarmersSoftAssert sa) throws Exception {
        final String YEAR_BUILT_TEXT = "If the majority of the home was stripped to the studs and remodeled, use the original year built, " +
                "and review all features for any necessary updates.";
        final String ENTER_YEAR_BUILT_ERROR = "Please enter the year your house was built.";
        final String ENTER_YEAR_BUILT_1600_ERROR = "Please enter a year after 1600.";
        final String ENTER_YEAR_BUILT_FUTURE_ERROR = "Please enter a year less than current year.";
        clickEditModalPropertyDetailsFieldEditButton(YEAR_BUILT);
        sa.assertEquals(getTextFromElement(editPropertyModalTitle), YEAR_BUILT, "Property Details Modal - Edit Year built title.");
        sa.assertEquals(getTextFromElement(editPropertyModalText), YEAR_BUILT_TEXT, "Property Details Modal - Edit Year built text.");
        String yearBuiltValue = getValueFromLocator(editPropertyModalInput);
        sa.assertEquals(yearBuiltValue, yearBuilt, "Property Details Modal - Edit Year built input value.");
        sa.assertEquals(getTextFromElement(editPropertyModalLabel), YEAR_BUILT, "Property Details Modal - Edit Year built input label.");

        if (!Property.getBrowser().equals(FIREFOX)) { // in Saucelabs these error messages are not consistent in FF browser
            waitAndClickElement(editPropertyModalInput);
            clearInputFieldModal();
            waitElementBeVisible(errorMessage, 2);
            sa.assertTrue(getPageErrors().contains(ENTER_YEAR_BUILT_ERROR), PROPERTY_DETAILS_PAGE + ENTER_YEAR_BUILT_ERROR + ERROR_FOUND);
            waitAndClickElement(editPropertyModalInput);
            sendKeysToElement(editPropertyModalInput, "1599" + Keys.TAB);
            waitElementBeVisible(errorMessage, 2);
            sa.assertTrue(getPageErrors().contains(ENTER_YEAR_BUILT_1600_ERROR), PROPERTY_DETAILS_PAGE + ENTER_YEAR_BUILT_1600_ERROR + ERROR_FOUND);
            waitAndClickElement(editPropertyModalInput);
            sendKeysToElement(editPropertyModalInput, String.valueOf(LocalDate.now().plusYears(1).getYear()) + Keys.TAB);
            waitElementBeVisible(errorMessage, 2);
            sa.assertTrue(getPageErrors().contains(ENTER_YEAR_BUILT_FUTURE_ERROR), PROPERTY_DETAILS_PAGE + ENTER_YEAR_BUILT_FUTURE_ERROR + ERROR_FOUND);
        }
        waitAndClickElement(editPropertyModalInput);
        sendKeysToElement(editPropertyModalInput, yearBuiltValue + Keys.TAB);
        waitAndClickElement(closeEditPropertyModal);
    }

    public void validateEditTotalSquareFoot(String squareFeet, FarmersSoftAssert sa) throws Exception {
        final String TOTAL_SQUARE_FOOTAGE_INPUT_LABEL = "Total finished sq. ft";
        final String TOTAL_SQUARE_FOOTAGE_TEXT = "Finished square feet includes area in attic, additions, and all living space (including closets and stairwells)" +
                " that is heated and/or cooled, has finished walls and ceilings, and has floor covering.";
        final String TOTAL_SQUARE_FOOTAGE_LOWER_TEXT = "IMPORTANT: Finished square feet does not include all garage areas, basement areas (finished and unfinished)," +
                " finished living space partially below grade (including spilt level foundations), and attached and detached structures like decks, balconies, patios, porches and carport.";
        final String ENTER_SQUARE_FEET_ERROR = "Please enter the total sq. ft of your house.";
        final String ENTER_SQUARE_FEET_100_ERROR = "Total sq. ft must be at least 100.";
        final String ENTER_SQUARE_FEET_99999_ERROR = "Total sq. ft cannot exceed 99999.";
        clickEditModalPropertyDetailsFieldEditButton(TOTAL_SQ_FT);
        sa.assertEquals(getTextFromElement(editPropertyModalTitle), TOTAL_SQ_FT, "Property Details Modal - Edit Total square footage title.");
        sa.assertEquals(getTextFromElement(editPropertyModalText), TOTAL_SQUARE_FOOTAGE_TEXT, "Property Details Modal - Edit Total square footage text.");
        String squareFeetValue = getValueFromLocator(editPropertyModalInput);
        sa.assertEquals(squareFeetValue, squareFeet, "Property Details Modal - Edit Total square footage input value.");
        sa.assertEquals(getTextFromElement(editPropertyModalLabel), TOTAL_SQUARE_FOOTAGE_INPUT_LABEL, "Property Details Modal - Edit Total square footage input label.");
        sa.assertEquals(getTextFromElement(editPropertyModalLightBulbText), TOTAL_SQUARE_FOOTAGE_LOWER_TEXT, "Property Details Modal - Edit Total square footage lower text.");

        if (!Property.getBrowser().equals(FIREFOX)) { // in Saucelabs these error messages are not consistent in FF browser
            waitAndClickElement(editPropertyModalInput);
            clearInputFieldModal();
            waitElementBeVisible(errorMessage, 2);
            sa.assertTrue(getPageErrors().contains(ENTER_SQUARE_FEET_ERROR), PROPERTY_DETAILS_PAGE + ENTER_SQUARE_FEET_ERROR + ERROR_FOUND);
            waitAndClickElement(editPropertyModalInput);
            sendKeysToElement(editPropertyModalInput, "99" + Keys.TAB);
            waitElementBeVisible(errorMessage, 2);
            sa.assertTrue(getPageErrors().contains(ENTER_SQUARE_FEET_100_ERROR), PROPERTY_DETAILS_PAGE + ENTER_SQUARE_FEET_100_ERROR + ERROR_FOUND);
            waitAndClickElement(editPropertyModalInput);
            sendKeysToElement(editPropertyModalInput, "123456" + Keys.TAB);
            waitElementBeVisible(errorMessage, 2);
            sa.assertTrue(getPageErrors().contains(ENTER_SQUARE_FEET_99999_ERROR), PROPERTY_DETAILS_PAGE + ENTER_SQUARE_FEET_99999_ERROR + ERROR_FOUND);
        }
        waitAndClickElement(editPropertyModalInput);
        sendKeysToElement(editPropertyModalInput, squareFeetValue + Keys.TAB);
        waitAndClickElement(closeEditPropertyModal);
    }

    public void validateEditNumberOfStories(String numberOfStories, FarmersSoftAssert sa) throws Exception {
        final String NUMBER_OF_STORIES = STORIES;
        final String NUMBER_OF_STORIES_TEXT = "Finished living levels in your home.";
        final String NUMBER_OF_STORIES_LOWER_TEXT = "Do you have an attic with finished livable space?";
        final List<String> STORIES_RADIO_BUTTONS = Arrays.asList("1 story", "2 stories", "3 stories", "4 stories",
                "Bi-level (Raised ranch)", "Split level");
        final List<String> ATTIC_TOGGLE_BUTTONS = Arrays.asList("Yes", "No");

        clickEditModalPropertyDetailsFieldEditButton(NUMBER_OF_STORIES);
        waitElementBeVisible(radioButton, 3);
        sa.assertEquals(getTextFromElement(editPropertyModalTitle), NUMBER_OF_STORIES, "Property Details Modal - Edit # of Stories title.");
        sa.assertEquals(getTextFromElement(editPropertyModalText), NUMBER_OF_STORIES_TEXT, "Property Details Modal - Edit # of Stories text.");
        sa.assertEquals(getTextFromElement(editPropertyModalLowerLabel), NUMBER_OF_STORIES_LOWER_TEXT, "Property Details Modal - Edit # of Stories lower text.");
        if (!numberOfStories.equals("0")) {
            sa.assertEquals(getTextFromElement(editPropertyModalSelectedRadioButton), numberOfStories, "Property Details Modal - Edit # of Stories selected value.");
        } else {
            sa.assertFalse(isElementDisplayed(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH + "[contains(@class,'radio-checked')]")),
                    "Property Details Modal - Edit # of Stories, no value is selected.");
        }
        List<String> radioButtons = locators(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH)).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        sa.assertTrue(STORIES_RADIO_BUTTONS.equals(radioButtons), "Property Details Modal - Edit # of Stories radio-buttons.");
        List<String> toggleButtons = locators(pwXPath(EDIT_MODAL_TOGGLE_BUTTON_XPATH)).stream()
                .map(this::getTextFromElement).collect(Collectors.toList());
        sa.assertTrue(ATTIC_TOGGLE_BUTTONS.equals(toggleButtons), "Property Details Modal - Edit # of Stories Attic toggle-buttons.");
        String expectedAtticValue = isAtticAvailable() ? YES : NO;
        sa.assertEquals(getTextFromElement(editPropertyModalSelectedAtticToggleButton), expectedAtticValue, "Property Details Modal - Edit # of Stories selected Attic toggle-button.");
        waitAndClickElement(closeEditPropertyModal);

    }

    public void validateEditBathrooms(String bathrooms, FarmersSoftAssert sa) throws Exception {
        final List<String> BATHROOMS_INPUT_LABELS = List.of("Full baths", "1/2 baths", "3/4 baths", "1-1/2 baths");
        final List<String> BATHROOMS_SUBTEXTS = List.of("(wash basin, toilet, and bathtub)", "(wash basin and toilet)",
                "(wash basin, toilet, and shower)", "(wash basin, toilet, bathtub, and separate shower)");
        final String BATHROOMS_TEXT = "Number of bathrooms in your home.";
        final String MAX_NUMBER_BATHROOMS_ERROR = "Total number of bathrooms cannot exceed 99.";
        clickEditModalPropertyDetailsFieldEditButton(BATHROOMS);
        sa.assertEquals(getTextFromElement(editPropertyModalTitle), BATHROOMS, "Property Details Modal - Edit Bathrooms title.");
        sa.assertEquals(getTextFromElement(editPropertyModalText), BATHROOMS_TEXT, "Property Details Modal - Edit Bathrooms text.");
        if (bathrooms.contains(COMMA)) {
            List<String> bathList = Arrays.stream(bathrooms.split(COMMA)).map(String::strip).collect(Collectors.toList());
            for (int i=0; i < bathList.size(); i++) {
                sa.assertEquals(getValueFromLocator(editBathroomsPropertyModalInputs.nth(i)), bathList.get(i),
                        "Property Details Modal - Edit Bathrooms, value of input: " + (i+1));
            }
            for (int i=bathList.size(); i < 4; i++) {
                sa.assertEquals(getValueFromLocator(editBathroomsPropertyModalInputs.nth(i)), "0",
                        "Property Details Modal - Edit Bathrooms, value of input: " + (i+1));
            }
        } else {
            sa.assertEquals(getValueFromLocator(editBathroomsPropertyModalInputs.nth(0)), bathrooms,
                    "Property Details Modal - Edit Bathrooms, full baths value.");
            for (int i=1; i < 4; i++) {
                sa.assertEquals(getValueFromLocator(editBathroomsPropertyModalInputs.nth(i)), "0",
                        "Property Details Modal - Edit Bathrooms, value of input -> " + (i+1));
            }
        }
        for (int i=0; i < BATHROOMS_INPUT_LABELS.size(); i++) {
            sa.assertEquals(getTextFromElement(editBathroomsPropertyModalLabels.nth(i)), BATHROOMS_INPUT_LABELS.get(i), "Property Details Modal - Edit Baths input label: " + i + " .");
            sa.assertEquals(getTextFromElement(editBathroomsPropertyModalSubTexts.nth(i)), BATHROOMS_SUBTEXTS.get(i), "Property Details Modal - Edit Baths input subtext: " + i + " .");
        }
        // validate number of bathrooms cannot exceed 99
        waitAndClickElement(editPropertyModalInput);
        sendKeysToElement(editPropertyModalInput, Keys.chord("100", Keys.TAB));
        waitForUiSettled();
        sa.assertTrue(getPageErrors().contains(MAX_NUMBER_BATHROOMS_ERROR), PROPERTY_DETAILS_PAGE + MAX_NUMBER_BATHROOMS_ERROR + ERROR_FOUND);
        // validate bathrooms can be set to 0
        waitAndClickElement(editPropertyModalInput);
        for (int i=0; i < 4; i++) {
            sendKeysToElement(editBathroomsPropertyModalInputs.nth(i), Keys.chord("0", Keys.TAB));
        }
        clickUpdatePropertyDetail(BATHROOMS, false);
        sa.assertEquals(getPropertyDetailsFieldValue(BATHROOMS), "0", "Property Details Modal - Bathrooms values can be set to 0.");
    }

    public void validateEditFireplace(String fireplace, FarmersSoftAssert sa) throws Exception {
        final String FIREPLACE_TEXT = "Type of fireplace in your home that you believe has the highest replacement cost.";
        final String[] FIREPLACE_RADIO_BUTTONS = {"Zero clearance fireplace", "Masonry fireplace", "Custom masonry fireplace",
                "Freestanding wood/gas burning stove fireplace", "Fireplace insert", "Beehive fireplace", "Chimney only", "Electric Fireplace", "None"};

        clickEditModalPropertyDetailsFieldEditButton(FIREPLACE);
        sa.assertEquals(getTextFromElement(editPropertyModalTitle), FIREPLACE, "Property Details Modal - Edit Fireplace title.");
        sa.assertEquals(getTextFromElement(editPropertyModalText), FIREPLACE_TEXT, "Property Details Modal - Edit Fireplace text.");
        if (fireplace != null) {
            sa.assertEquals(getTextFromElement(editPropertyModalSelectedRadioButton), fireplace, "Property Details Modal - Edit Fireplace selected value.");
        }
        Object[] radioButtons = locators(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH)).stream().map(this::getTextFromElement).toArray();
        sa.assertEquals(radioButtons, FIREPLACE_RADIO_BUTTONS, "Property Details Modal - Edit Fireplace radio-buttons.");

        waitAndClickElement(closeEditPropertyModal);
    }


    public void validateEditFloors(String floors, FarmersSoftAssert sa, String stateCode) throws Exception {
        final String FLOORS_TEXT = "All flooring materials found in your home.";
        String floorOptionVinyl = List.of(NY, NJ, MT).contains(stateCode)? "Vinyl" : "Vinyl Plank";
        final String[] FLOORS_CHECKBOXES = {"Carpet", "Hardwood", "Laminate", floorOptionVinyl, "Linoleum", "Stone & tile"};
        final String TOTAL_FLOORS_LOWER_TEXT = "For specialty or high-value flooring, please contact Farmers\u00ae representative this may impact " +
                "the estimated replacement cost of your home.";

        clickEditModalPropertyDetailsFieldEditButton(FLOORS);
        sa.assertEquals(getTextFromElement(editPropertyModalTitle), FLOORS, "Property Details Modal - Edit Floors title.");
        sa.assertEquals(getTextFromElement(editPropertyModalText), FLOORS_TEXT, "Property Details Modal - Edit Floors text.");
        Object[] checkboxes = locators(pwXPath(EDIT_MODAL_CHECKBOX_XPATH)).stream().map(this::getTextFromElement).toArray();
        sa.assertEquals(checkboxes, FLOORS_CHECKBOXES, "Property Details Modal - Edit Floors checkboxes.");

        // commenting out this line as we have open defect US910502 in backlog
        //  sa.assertEquals(getTextFromElement(editPropertyModalCaption), TOTAL_FLOORS_LOWER_TEXT, "Property Details Modal - Edit Floors lower text.");

        Object[] checkboxSelected = locators(pwXPath(EDIT_MODAL_CHECKBOX_XPATH + EDIT_MODAL_CHECKBOX_CHECKED_XPATH)).stream()
                .map(this::getTextFromElement).toArray();
        Log.info("Floors from UI: " + Arrays.toString(checkboxSelected));
        if (!floors.equals(NONE)) {
            Object[] listFloors = Stream.of(floors.split(COMMA)).map(String::strip).toArray();
            Log.info("Floors from appStore: " + Arrays.toString(listFloors));
            sa.assertEqualsNoOrder(checkboxSelected, listFloors, "Property Details Modal - Edit Floors selected values.");
        } else {
            sa.assertEquals(checkboxSelected.length, 0, "Property Details Modal - Edit Floors does not have any selected values" +
                    " (no property details in the appStore).");
        }
        waitAndClickElement(closeEditPropertyModal);
    }

    public void validateEditGarageStyle(String garageStyle, FarmersSoftAssert sa) throws Exception {
        final String GARAGE_STYLE_TEXT = "Style of garage or carport on your property that you believe has the highest replacement cost.";
        final String[] GARAGE_STYLE_RADIO_BUTTONS = {"Attached / Built-in", "Basement", "Carport", "Detached", "No garage"};

        clickEditModalPropertyDetailsFieldEditButton(GARAGE_STYLE);
        sa.assertEquals(getTextFromElement(editPropertyModalTitle), GARAGE_STYLE, "Property Details Modal - Edit Garage style title.");
        sa.assertEquals(getTextFromElement(editPropertyModalText), GARAGE_STYLE_TEXT, "Property Details Modal - Edit Garage style text.");
        if (!garageStyle.equals(NONE)) {
            sa.assertEquals(getTextFromElement(editPropertyModalSelectedRadioButton), garageStyle, "Property Details Modal - Edit Garage style selected value.");
        } else {
            sa.assertFalse(isElementDisplayed(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH + "[contains(@class,'radio-checked')]")),
                    "Property Details Modal - Edit Garage style, no value is selected.");
        }
        sa.assertEquals(locators(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH)).stream()
                .map(this::getTextFromElement).toArray(), GARAGE_STYLE_RADIO_BUTTONS, "Property Details Modal - Edit Garage style radio-buttons.");
        waitAndClickElement(closeEditPropertyModal);
    }

    public void validateEditGarageCarport(String garageCarport, FarmersSoftAssert sa) throws Exception {
        final String GARAGE_CARPORT_TEXT = "Number of vehicles your garage or carport was designed to hold.";
        final String[] GARAGE_CARPORT_RADIO_BUTTONS = {"1 car", "2 cars", "3 cars", "4 or more cars"};

        clickEditModalPropertyDetailsFieldEditButton(GARAGE_CARPORT);
        sa.assertEquals(getTextFromElement(editPropertyModalTitle), GARAGE_CARPORT, "Property Details Modal - Edit Garage / carport title.");
        sa.assertEquals(getTextFromElement(editPropertyModalText), GARAGE_CARPORT_TEXT, "Property Details Modal - Edit Garage / carport text.");
        if (Arrays.asList(GARAGE_CARPORT_RADIO_BUTTONS).contains(garageCarport)) {
            sa.assertEquals(getTextFromElement(editPropertyModalSelectedRadioButton), garageCarport, "Property Details Modal - Edit Garage/carport selected value.");
        } else {
            sa.assertFalse(isAnyRadioButtonSelected(), "Property Details Modal - No Edit Garage/carport radio-button is selected.");
        }
        Object[] radioButtons = locators(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH)).stream().map(this::getTextFromElement).toArray();
        sa.assertEquals(radioButtons, GARAGE_CARPORT_RADIO_BUTTONS, "Property Details Modal - Edit Garage / carport radio-buttons.");

        waitAndClickElement(closeEditPropertyModal);
    }

    public void validateEditExteriorWallFinish(String exteriorWallFinish, FarmersSoftAssert sa) throws Exception {
        final String EXTERIOR_WALL_FINISH_TEXT = "The material that predominately covers your exterior walls \u2014 like wood siding, " +
                "brick or stucco.";
        final String SEE_EXAMPLES_BUTTON_XPATH = "//tui-subcategory-modal//button[contains(text(),'See examples')]";
        final String[] EXTERIOR_WALL_FINISH_CATEGORY_TITLES = {"Log", "Stucco", "Veneer", "Siding", "Wood","Adobe", "Masonry"};
        final String CATEGORY_TITLES_XPATH = "//tui-subcategory-modal//div[@class='radio-category-title']";
        final String[] EXTERIOR_WALL_FINISH_RADIO_BUTTONS = {"Log", "Solid Log - Small (6\" - 8\")", "Solid Log - Large (13\" or more)",
                "Synthetic", "Traditional hard coat", "Brick", "Brick (Custom)", "Stone (Natural)", "Stone (Manufactured)", "Cut limestone",
                "Metal - copper shingle", "Steel", "Log (Siding)", "Alum. or metal", "Vinyl", "Vinyl shingles", "Hardboard/masonite",
                "Cement fiber (Clapboard)", "Cement fiber (Shingle)", "Metal - Corrugated Galvanized", "Metal - Painted Ribbed",
                "Pine (Tongue & Groove)", "Cedar (Clapboard)", "Cedar (Tongue & groove)", "Redwood (Clapboard)", "Redwood (Tongue & groove)",
                "Plywood (Vertical groove)", "Wood shingle/shake", "Wood shingle/shake (scalloped)", "Board and Batten", "Hardboard/masonite",
                "Pine (Clapboard)", "Adobe block", "Solid brick construction", "Concrete block", "Solid concrete", "Brick solid",
                "Brick solid (custom)", "Solid stone", "Concrete Block - Decorative"};

        clickEditModalPropertyDetailsFieldEditButton(EXTERIOR_WALL_FINISH);
        sa.assertEquals(getTextFromElement(editPropertyModalTitle), EXTERIOR_WALL_FINISH, "Property Details Modal - Edit Exterior wall finish title.");
        sa.assertEquals(getTextFromElement(editPropertyModalText), EXTERIOR_WALL_FINISH_TEXT, "Property Details Modal - Edit Exterior wall finish text.");
        if (!exteriorWallFinish.equals(NONE)) {
            sa.assertEquals(getTextFromElement(editPropertyModalSelectedRadioButton), exteriorWallFinish, "Property Details Modal - Edit Exterior wall finish selected value.");
        } else {
            sa.assertFalse(isElementDisplayed(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH + "[contains(@class,'radio-checked')]")),
                    "Property Details Modal - Edit Exterior wall finish, no value is selected.");
        }
        Object[] radioButtons = locators(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH)).stream().map(this::getTextFromElement).toArray();
        Log.info("Exterior wall finish radio-buttons:: " + Arrays.toString(radioButtons));
        sa.assertEquals(radioButtons, EXTERIOR_WALL_FINISH_RADIO_BUTTONS, "Property Details Modal - Edit Exterior wall finish radio-buttons.");
        sa.assertTrue(isElementDisplayed(pwXPath(SEE_EXAMPLES_BUTTON_XPATH)), "Property Details Modal - Edit Exterior wall finish, button to see examples.");
        Object[] categories = locators(pwXPath(CATEGORY_TITLES_XPATH)).stream().map(this::getTextFromElement).toArray();
        sa.assertEquals(categories, EXTERIOR_WALL_FINISH_CATEGORY_TITLES, "Property Details Modal - Edit Exterior wall finish, Category titles.");

        validateExteriorWallFinishExamples(sa);

        waitAndClickElement(closeEditPropertyModal);
    }

    private List<String> getListOfCategories() {
        waitAndClickElement(examplesCategorySelectArrow);
        waitElementBeVisibleClickable(firstCategoryOption);
        List<String> categories = categoryOptions.all().stream().map(this::getTextFromElement).map(String::strip).collect(Collectors.toList());
        Log.info("List of categories in the drop-down: " + categories);
        return categories;
    }

    private void selectCategoryByName(String category) throws Exception {
        final String OPTION_XPATH = CATEGORIES_LISTBOX_XPATH + "/mat-option[contains(.,'%s')]";
        waitAndClickElement(examplesCategorySelectArrow);
        String categoryBy = pwXPath(String.format(OPTION_XPATH, category));
        conditionalWait(5).until(Conditions.clickable(categoryBy));
        scrollAndClickOnElement(locator(categoryBy));
        conditionalWait(5).until(Conditions.invisible(pwXPath(CATEGORIES_LISTBOX_XPATH)));
    }

    private void validateExamples(String category, String exampleName, String exampleText, String exampleImageFile, FarmersSoftAssert sa) throws Exception {
        Locator weExample = locator(pwXPath(String.format(SUBCATEGORY_HEADING_XPATH, exampleName)));
        final String examplesSubcategory = "Examples subcategory: ";
        sa.assertEquals(getTextFromElement(weExample), exampleName, examplesSubcategory + category + " Synthetic heading.");

        weExample = locator(pwXPath(String.format(SUBCATEGORY_HEADING_XPATH, exampleName) + FOLLOWING_SIBLING_DIV));
        sa.assertEquals(getTextFromElement(weExample), exampleText, examplesSubcategory + category + SPACE + exampleName + " text.");

        if (!exampleName.equals("Solid concrete")) {
            String imageBy = pwXPath(String.format(SUBCATEGORY_IMAGE_XPATH, exampleName));
            weExample = locator(imageBy);
            sa.assertTrue(getAttributeData(weExample, SRC).endsWith("/images/property-details/" + exampleImageFile + ".png"),
                    examplesSubcategory + category + SPACE + exampleName + " src image file path.");
        }
    }

    public void validateExteriorWallFinishExamples(FarmersSoftAssert sa) throws Exception {
        final String EXTERIOR_WALL_FINISH_EXAMPLES_TITLE = "Exterior wall finish examples";
        final String LOG = "Log";
        final String STUCCO = "Stucco";
        final String VENEER = "Veneer";
        final String SIDING = "Siding";
        final String WOOD = "Wood";
        final String ADOBE = "Adobe";
        final String MASONRY = "Masonry";
        final List<String> EXTERIOR_WALL_FINISH_CATEGORIES = Arrays.asList(LOG, STUCCO, VENEER, SIDING, WOOD, ADOBE, MASONRY);
        final String IMAGE_FILE_PREFIX = "exterior-wall-finish-examples/";

        final String LOG_TEXT = "Solid logs, 9 inches to 12 inches in diameter, usually made of pine.";
        final String LOG_SMALL_LOG_TEXT = "Solid logs, 6 inches to 8 inches in diameter, usually made of pine.";
        final String LOG_LARGE_LOG_TEXT = "Solid logs, 13 inches or more in diameter, usually made of pine.";

        final String STUCCO_SYNTHETIC_TEXT = "Synthetic stucco is sometimes referred to as EIFS (Exterior Insulation Finish System) " +
                "and is an exterior wall material which became available in the 1960's. Synthetic stucco is made of acrylics and comes " +
                "pre-mixed by the manufacturer. It is usually applied in two coats over foam board and fiberglass mesh, which are much " +
                "thinner than traditional hard coat stucco. It can be applied over framed or masonry (block) walls. It has evolved " +
                "since around 2010 and can now be used in wetter climates as long as a water managed system is properly installed.";
        final String STUCCO_TRADITIONAL_TEXT = "Hard cement-based material applied in a multi-step process. A troweled, Portland " +
                "cement exterior, typically consisting of metal mesh (lath), a base coat (scratch coat) and a brown and/or finish coat " +
                "installed over a wood stud back-up. Stucco may be applied directly, with or without lath, to masonry substrates such as " +
                "brick, stone, concrete or hollow tile. While still used today, it was the only stucco used for homes prior to about 1960. " +
                "See Stucco - Synthetic (EIFS) for more information on stucco finishes";

        final String VENEER_BRICK_TEXT = "Layer of brick that is applied on the outside of the supporting wall structure for appearance and durability.";
        final String VENEER_BRICK_CUSTOM_TEXT = "Custom-made bricks or bricks installed in a custom pattern over the exterior supporting walls.";
        final String VENEER_STONE_NATURAL_TEXT = "Natural stone placed in a bed of grout outside the supporting wall structure which usually " +
                "requires wall ties, footings, or foundations for additional support.";
        final String VENEER_STONE_MANUFACTURED_TEXT = "Cast stone placed in a bed of grout outside the supporting wall structure " +
                "to simulate natural stone. Manufactured stone is lightweight and does not require wall ties, footings, or foundations.";
        final String VENEER_CUT_LIMESTONE_TEXT = "Cut natural limestone placed in a bed of grout outside the supporting wall structure " +
                "which usually requires wall ties, footings, or foundations for additional support.";

        final String SIDING_METAL_COPPER_TEXT = "Copper shingles are laid in an interlocking system and will come in various sizes. " +
                "Copper shingles will turn green over time as the surface oxidizes.";
        final String SIDING_STEEL_TEXT = "A durable impact resistant siding constructed of galvanized steel with PVC top coat.";
        final String SIDING_LOG_TEXT = "Laminated, rounded wood planks that attach directly to the exterior framing structure, " +
                "and give the look of a log cabin. These are usually made of pine, but can be made of any type of wood.";
        final String SIDING_ALUM_METAL_TEXT = "A lightweight metal material produced in long panels with baked-on enamel finish that can be " +
                "smooth or textured. It is installed horizontally and attached directly to the exterior framing or over block.";
        final String SIDING_VINYL_TEXT = "Strong, impact resistant polyvinyl chloride planks. It is installed horizontally and attached " +
                "directly to the exterior framing or over block.";
        final String SIDING_VINYL_SHINGLES_TEXT = "Strong impact resistant polyvinyl chloride shingles. Installed in an interlocking " +
                "fashion similar to vinyl siding.";
        String SIDING_HARDBOARD_MASONITE_TEXT = "Siding panels made of hardboard, masonite, or asbestos cement that are attached " +
                "directly to the exterior framed or block structure in an overlapping horizontal fashion. Hardboard is composed of " +
                "natural wood fibers pressed into panels. Masonite is composed of wood products and a binder pressed into panels. " +
                "Asbestos cement siding is composed of Portland cement, sand, and asbestos. Asbestos is a non-combustible mineral " +
                "fiber derived from natural hydrous magnesium silicate with high thermal and electrical resistance. Though it is " +
                "fireproof, it is brittle and commonly breaks and cracks. Because asbestos fibers are hazardous, this type of " +
                "residential siding has not been manufactured or installed since the 1970s.";
        SIDING_HARDBOARD_MASONITE_TEXT = !isSafariBrowser() ? SIDING_HARDBOARD_MASONITE_TEXT :
                SIDING_HARDBOARD_MASONITE_TEXT.replace(" Hardboard","Hardboard").replace(" Masonite","Masonite")
                        .replace(" Asbestos cement","Asbestos cement").replace(" Because","Because");;
        String SIDING_CEMENT_FIBER_CLAPBOARD_TEXT = "A cementious product installed horizontally and attached directly to the exterior " +
                "framing. Asbestos cement siding is composed of Portland cement, sand, and asbestos. Asbestos is a non-combustible mineral " +
                "fiber derived from natural hydrous magnesium silicate with high thermal and electrical resistance. Though it is fireproof, " +
                "it is brittle and commonly breaks and cracks. Because asbestos fibers are hazardous, this type of residential siding has " +
                "not been manufactured or installed since the 1970s.";
        SIDING_CEMENT_FIBER_CLAPBOARD_TEXT = !isSafariBrowser() ? SIDING_CEMENT_FIBER_CLAPBOARD_TEXT : SIDING_CEMENT_FIBER_CLAPBOARD_TEXT.replace(" Asbestos cement","Asbestos cement");
        final String SIDING_CEMENT_FIBER_SHINGLE_TEXT = "An external wall material made from a combination of wood fiber and Portland cement. " +
                "Fiber and cement wall material can be made to resemble slate, tile, or wood and is commonly installed as a shingle material.";

        final String WOOD_PINE_TONGUE_GROOVE_TEXT = "Finished or rough pine wood planks (usually 6 inches wide) that are installed horizontally " +
                "over the exterior framing. These can be tongue and groove, shiplap, or board on board overlapping styles. Most painted wood " +
                "siding is made from pine.";
        final String WOOD_CEDAR_CLAPBOARD_TEXT = "Finished or rough cedar wood planks (usually 6 inches wide) that are installed horizontally " +
                "over the exterior framing. Clapboard is characterized by overlapping board on board.";
        final String WOOD_CEDAR_TONGUE_GROOVE_TEXT = "Finished or rough cedar wood planks (usually 6 inches wide) that are installed horizontally " +
                "over the exterior framing. Tongue and groove is characterized by interlocking boards.";
        final String WOOD_REDWOOD_CLAPBOARD_TEXT = "Finished or rough redwood planks (usually 6 inches wide) that are installed horizontally " +
                "over the exterior framing. Clapboard is characterized by overlapping board on board.";
        final String WOOD_REDWOOD_TONGUE_GROOVE_TEXT = "Finished or rough redwood planks (usually 6 inches wide) that are installed horizontally " +
                "over the exterior framing. Tongue and groove is characterized by interlocking boards.\"";
        final String WOOD_PLYWOOD_TEXT = "A textured plywood siding which comes in 4' x 8' sheets with grooves cut every 6\" or 8\". It is typically " +
                "installed in full sheets with the grooves running vertically to resemble \"reverse board and batten\" siding. May also be " +
                "called \"T-111\" which stands for \"texture 111\".";
        final String WOOD_SHINGLE_SHAKE_TEXT = "Shingles are sawn to create a uniform thickness. Shakes are a rough type of wooden shingle. A shake " +
                "can be either: hand split, hand split and sawn on one side, or hand split and sawn on both sides. These are installed in horizontal, " +
                "overlapping rows.";
        final String WOOD_SHINGLE_SHAKE_SCALLOPED_TEXT = "Wood shingles or shakes with a shaped bottom edge. The shape may be rounded, triangular, " +
                "square, wavy or any other pattern.";
        final String WOOD_BOARD_BATTEN_TEXT = "1\" x 6\" or 1\" x 8\" wooden siding boards and 1\" x 2\" wooden batten applied vertically to create " +
                "a barn-like exterior finish. The batten slats cover the siding wall joints.";
        String WOOD_HARDBOARD_MASONITE_TEXT = "Siding panels made of hardboard, masonite, or asbestos cement that are attached directly " +
                "to the exterior framed or block structure in an overlapping horizontal fashion. Hardboard is composed of natural wood fibers " +
                "pressed into panels. Masonite is composed of wood products and a binder pressed into panels. Asbestos cement siding is " +
                "composed of Portland cement, sand, and asbestos. Asbestos is a non-combustible mineral fiber derived from natural hydrous " +
                "magnesium silicate with high thermal and electrical resistance. Though it is fireproof, it is brittle and commonly breaks " +
                "and cracks. Because asbestos fibers are hazardous, this type of residential siding has not been manufactured or installed " +
                "since the 1970s.";
        WOOD_HARDBOARD_MASONITE_TEXT = !isSafariBrowser() ? WOOD_HARDBOARD_MASONITE_TEXT :
                WOOD_HARDBOARD_MASONITE_TEXT.replace(" Hardboard","Hardboard").replace(" Masonite","Masonite")
                        .replace(" Asbestos cement","Asbestos cement").replace(" Because","Because");

        final String ADOBE_BLOCK_TEXT = "This is commonly found in the southwestern United States. It is a sun-dried clay that comes in various " +
                "sizes and has a rough texture. It is often covered on the interior and exterior with mud plaster, lime plaster, whitewash, or " +
                "stucco. Adobe blocks are perhaps the greenest building material and are often harvested locally.";

        final String MASONRY_SOLID_BRICK_CONSTRUCTION_TEXT = "This should be selected when brick is the supporting structure of the wall instead of " +
                "wood framing or block walls. In other words, the wall gets its strength from the brick. Solid brick may be found in older homes.";
        final String MASONRY_CONCRETE_BLOCK_TEXT = "These are pre-cast hollow rectuangular concrete masony units (CMU) of various widths and " +
                "thickness usually bonded together with mortared joints. They may or may not be reinforced with steel bars.";
        final String MASONRY_SOLID_CONCRETE_TEXT = "A concrete wall which is created by placing wall forms, usually 8\" apart, and pouring concrete " +
                "into the top. Reinforcement bar (rebar) is also usually placed in a 2' grid pattern for strength. This is the same process as used " +
                "in a concrete foundation wall for a basement or crawlspace.";
        final String MASONRY_BRICK_SOLID_TEXT = "This should be selected when brick is the supporting structure of the wall instead of wood " +
                "framing or block walls. In other words, the wall gets its strength from the brick. Solid brick may be found in older homes.";
        final String MASONRY_BRICK_SOLID_CUSTOM_TEXT = "Solid bricks composing the supporting structure of the home instead of wood framing " +
                "or block walls. Custom-made bricks or typical bricks installed in a custom pattern.";
        final String MASONRY_SOLID_STONE_TEXT = "Solid stone walls are both the exterior finish and the supporting walls of the structure and " +
                "do not include any additional supporting elements, such as wood framing or concrete block walls. Solid stone walls are " +
                "typically constructed with rubble or field stone.";

        waitAndClickElement(seeExamples);
        sa.assertEquals(getTextFromElement(examplesCategoryTitle), EXTERIOR_WALL_FINISH_EXAMPLES_TITLE, "Exterior wall finishes examples title.");
        sa.assertEquals(getListOfCategories(), EXTERIOR_WALL_FINISH_CATEGORIES, "Exterior wall finishes examples - list of categories.");
        for (String category : getListOfCategories()) {
            selectCategoryByName(category);
            switch (category) {
                case LOG:
                    validateExamples(category, "Log", LOG_TEXT, IMAGE_FILE_PREFIX + "log", sa);
                    validateExamples(category, "Solid Log - Small (6\" - 8\")", LOG_SMALL_LOG_TEXT, IMAGE_FILE_PREFIX + "solid-log-small", sa);
                    validateExamples(category, "Solid Log - Large (13\" or more)", LOG_LARGE_LOG_TEXT, IMAGE_FILE_PREFIX + "solid-log-large", sa);
                    break;
                case STUCCO:
                    validateExamples(category, "Synthetic", STUCCO_SYNTHETIC_TEXT, IMAGE_FILE_PREFIX + "stucco-synthetic", sa);
                    validateExamples(category, "Traditional hard coat", STUCCO_TRADITIONAL_TEXT, IMAGE_FILE_PREFIX + "stucco-traditional", sa);
                    break;
                case VENEER:
                    validateExamples(category, "Brick", VENEER_BRICK_TEXT, IMAGE_FILE_PREFIX + "veneer-brick", sa);
                    validateExamples(category, "Brick (Custom)", VENEER_BRICK_CUSTOM_TEXT, IMAGE_FILE_PREFIX + "veneer-brick-custom", sa);
                    validateExamples(category, "Stone (Natural)", VENEER_STONE_NATURAL_TEXT, IMAGE_FILE_PREFIX + "veneer-stone-natural", sa);
                    validateExamples(category, "Stone (Manufactured)", VENEER_STONE_MANUFACTURED_TEXT, IMAGE_FILE_PREFIX + "veneer-stone-manufactured", sa);
                    validateExamples(category, "Cut limestone", VENEER_CUT_LIMESTONE_TEXT, IMAGE_FILE_PREFIX + "veneer-cut-limestone", sa);
                    break;
                case SIDING:
                    validateExamples(category, "Metal - copper shingle", SIDING_METAL_COPPER_TEXT, IMAGE_FILE_PREFIX + "siding-metal-copper-shingle", sa);
                    validateExamples(category, "Steel", SIDING_STEEL_TEXT, IMAGE_FILE_PREFIX + "siding-steel", sa);
                    validateExamples(category, "Log (Siding)", SIDING_LOG_TEXT, IMAGE_FILE_PREFIX + "siding-log", sa);
                    validateExamples(category, "Alum. or metal", SIDING_ALUM_METAL_TEXT, IMAGE_FILE_PREFIX + "siding-alum-metal", sa);
                    validateExamples(category, "Vinyl", SIDING_VINYL_TEXT, IMAGE_FILE_PREFIX + "siding-vinyl", sa);
                    validateExamples(category, "Vinyl shingles", SIDING_VINYL_SHINGLES_TEXT, IMAGE_FILE_PREFIX + "siding-vinyl-shingle", sa);
                    validateExamples(category, "Hardboard/masonite", SIDING_HARDBOARD_MASONITE_TEXT, IMAGE_FILE_PREFIX + "wood-hardboard-masonite", sa);
                    validateExamples(category, "Cement fiber (Clapboard)", SIDING_CEMENT_FIBER_CLAPBOARD_TEXT, IMAGE_FILE_PREFIX + "siding-cement-fiber-clapboard", sa);
                    validateExamples(category, "Cement fiber (Shingle)", SIDING_CEMENT_FIBER_SHINGLE_TEXT, IMAGE_FILE_PREFIX + "siding-cement-fiber-shingle", sa);
                    break;
                case WOOD:
                    validateExamples(category, "Pine (Tongue & Groove)", WOOD_PINE_TONGUE_GROOVE_TEXT, IMAGE_FILE_PREFIX + "wood-pine-tongue-groove", sa);
                    validateExamples(category, "Cedar (Clapboard)", WOOD_CEDAR_CLAPBOARD_TEXT, IMAGE_FILE_PREFIX + "wood-cedar-clapboard", sa);
                    validateExamples(category, "Cedar (Tongue & groove)", WOOD_CEDAR_TONGUE_GROOVE_TEXT, IMAGE_FILE_PREFIX + "wood-cedar-tongue-groove", sa);
                    validateExamples(category, "Redwood (Clapboard)", WOOD_REDWOOD_CLAPBOARD_TEXT, IMAGE_FILE_PREFIX + "wood-redwood-clapboard", sa);
                    validateExamples(category, "Redwood (Tongue & groove)", WOOD_REDWOOD_TONGUE_GROOVE_TEXT, IMAGE_FILE_PREFIX + "wood-redwood-tongue-groove", sa);
                    validateExamples(category, "Plywood (Vertical groove)", WOOD_PLYWOOD_TEXT, IMAGE_FILE_PREFIX + "wood-plywood", sa);
                    validateExamples(category, "Wood shingle/shake", WOOD_SHINGLE_SHAKE_TEXT, IMAGE_FILE_PREFIX + "wood-shingle-shake", sa);
                    validateExamples(category, "Wood shingle/shake (scalloped)", WOOD_SHINGLE_SHAKE_SCALLOPED_TEXT, IMAGE_FILE_PREFIX + "wood-shingle-shake-scalloped", sa);
                    validateExamples(category, "Board and Batten", WOOD_BOARD_BATTEN_TEXT, IMAGE_FILE_PREFIX + "wood-board-batten", sa);
                    validateExamples(category, "Hardboard/masonite", WOOD_HARDBOARD_MASONITE_TEXT, IMAGE_FILE_PREFIX + "wood-hardboard-masonite", sa);
                    break;
                case ADOBE:
                    validateExamples(category, "Adobe block", ADOBE_BLOCK_TEXT, IMAGE_FILE_PREFIX + "adobe", sa);
                    break;
                case MASONRY:
                    validateExamples(category, "Solid brick construction", MASONRY_SOLID_BRICK_CONSTRUCTION_TEXT, IMAGE_FILE_PREFIX + "masonry-solid-brick-construction", sa);
                    validateExamples(category, "Concrete block", MASONRY_CONCRETE_BLOCK_TEXT, IMAGE_FILE_PREFIX + "masonry-concrete-block", sa);
                    validateExamples(category, "Solid concrete", MASONRY_SOLID_CONCRETE_TEXT, IMAGE_FILE_PREFIX + "Image%20placeholder", sa);
                    validateExamples(category, "Brick solid", MASONRY_BRICK_SOLID_TEXT, IMAGE_FILE_PREFIX + "masonry-solid-brick-construction", sa);
                    validateExamples(category, "Brick solid (custom)", MASONRY_BRICK_SOLID_CUSTOM_TEXT, IMAGE_FILE_PREFIX + "masonry-brick-solid-custom", sa);
                    validateExamples(category, "Solid stone", MASONRY_SOLID_STONE_TEXT, IMAGE_FILE_PREFIX + "masonry-solid-stone", sa);
                    break;
                default:
                    sa.fail("Unknown Exterior wall finish category: " + category);
            }
        }
        waitAndClickElement(closeEditPropertyExamplesModal);
    }

    public void validateEditFoundationType(String foundationType, FarmersSoftAssert sa) throws Exception {
        final String FOUNDATION_TYPE_TEXT = "The type of foundation your house predominately has.";
        final String[] FOUNDATION_TYPE_RADIO_BUTTONS = {"Basement", "Shallow basement", "Concrete slab", "Crawlspace",
                "Pier & grade beam", "Elevated post/pier & beam (stilts)", "Stilts with sweep away walls", "Deep pilings"};

        clickEditModalPropertyDetailsFieldEditButton(FOUNDATION_TYPE);
        sa.assertEquals(getTextFromElement(editPropertyModalTitle), FOUNDATION_TYPE, "Property Details Modal - Edit Foundation type title.");
        sa.assertEquals(getTextFromElement(editPropertyModalText), FOUNDATION_TYPE_TEXT, "Property Details Modal - Edit Foundation type text.");
        if (!foundationType.equals(NONE)) {
            sa.assertEquals(getTextFromElement(editPropertyModalSelectedRadioButton), foundationType, "Property Details Modal - Edit Foundation type selected value.");
        } else {
            sa.assertFalse(isElementDisplayed(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH + "[contains(@class,'radio-checked')]")),
                    "Property Details Modal - Edit Foundation type, no value is selected.");
        }
        Object[] radioButtons = locators(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH)).stream().map(this::getTextFromElement).map(String::strip).toArray();
        sa.assertEquals(radioButtons, FOUNDATION_TYPE_RADIO_BUTTONS, "Property Details Modal - Edit Foundation type radio-buttons.");

        waitAndClickElement(closeEditPropertyModal);
    }

    public void validateEditFinishedBasement(String finishedBasement, FarmersSoftAssert sa) throws Exception {
        final String FINISHED_BASEMENT_HEADER_TEXT = "What % would you say your basement is considered finished?";
        final String FINISHED_BASEMENT_FOOTER_TEXT = "\"Finished\" includes all living space (including closets and stairwells) that is heated and/or cooled, " +
                "has finished walls and ceilings, and has floor covering.";
        final String[] FINISHED_BASEMENT_RADIO_BUTTONS = {"Unfinished", "25% finished", "50% finished", "75% finished", "100% finished"};

        if (finishedBasement != null) {
            clickEditModalPropertyDetailsFieldEditButton(FINISHED_BASEMENT);
            sa.assertEquals(getTextFromElement(editPropertyModalTitle), FINISHED_BASEMENT, "Property Details Modal - Edit Finished basement title.");
            sa.assertEquals(getTextFromElement(editPropertyModalText), FINISHED_BASEMENT_HEADER_TEXT, "Property Details Modal - Edit Finished basement header text.");
            sa.assertEquals(getTextFromElement(editPropertyModalText), FINISHED_BASEMENT_HEADER_TEXT, "Property Details Modal - Edit Finished basement header text.");
            sa.assertEquals(getTextFromElement(editPropertyModalCaption), FINISHED_BASEMENT_FOOTER_TEXT, "Property Details Modal - Edit Finished basement footer text.");
            if (!finishedBasement.isBlank()) {
                if (!finishedBasement.equals(ZERO)) {
                    sa.assertTrue(getTextFromElement(editPropertyModalSelectedRadioButton).startsWith(finishedBasement), "Property Details Modal - Edit Finished basement selected value.");
                } else {
                    sa.assertTrue(getTextFromElement(editPropertyModalSelectedRadioButton).startsWith("Unfinished"), "Property Details Modal - Edit Finished basement value - Unfinished.");
                }
            }
            Object[] radioButtons = locators(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH)).stream().map(this::getTextFromElement).toArray();
            sa.assertEquals(radioButtons, FINISHED_BASEMENT_RADIO_BUTTONS, "Property Details Modal - Edit Finished basement radio-buttons.");
            waitAndClickElement(closeEditPropertyModal);
        } else {
            sa.assertFalse(isEditModalPropertyDetailsFieldDisplayed(FINISHED_BASEMENT), "Property Details Modal - Edit Finished basement field is not displayed");
        }
    }

    public void validateEditRoofCover(String roofCover, FarmersSoftAssert sa) throws Exception {
        final String ROOF_COVER_TEXT = "The type of material predominately installed on your roof \u2014 like shingles, metal or membrane.";
        final String SEE_EXAMPLES_BUTTON_XPATH = "//tui-subcategory-modal//button[contains(text(),'See examples')]";
        final String[] ROOF_COVER_CATEGORY_TITLES = {"Asphalt composition", "Flat", "Metal", "Tile", "Wood"};
        final String CATEGORY_TITLES_XPATH = "//tui-subcategory-modal//div[@class='radio-category-title']";
        final String[] ROOF_COVER_RADIO_BUTTONS = {"3-tab shingle", "Architectural shingle", "Impact resistant shingle",
                "Synthetic roofing", "Roll roofing", "Built-up (hot mopped) w/ Gravel", "Built-up (hot mopped) w/o Gravel",
                "Membrane \u2014 EPDM or PVC", "Sprayed polyurethane foam (SPF)", "Standing seam", "Copper shingle", "Standing seam copper",
                "Corrugated galvanized", "Tile/shake", "Painted Rib", "Clay", "Concrete", "Glazed", "Cement fiber", "Slate", "Shingles or shake",
                "Shingles/Shakes-Deco Ptrn."};

        clickEditModalPropertyDetailsFieldEditButton(ROOF_COVER);
        sa.assertEquals(getTextFromElement(editPropertyModalTitle), ROOF_COVER, "Property Details Modal - Edit Roof cover title.");
        sa.assertEquals(getTextFromElement(editPropertyModalText), ROOF_COVER_TEXT, "Property Details Modal - Edit Roof cover text.");
        if (!roofCover.equals(NONE)) {
            sa.assertEquals(getTextFromElement(editPropertyModalSelectedRadioButton), roofCover, "Property Details Modal - Edit Roof cover selected value.");
        } else {
            sa.assertFalse(isElementDisplayed(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH + "[contains(@class,'radio-checked')]")),
                    "Property Details Modal - Edit Roof cover, no value is selected.");
        }
        Object[] radioButtons = locators(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH)).stream().map(this::getTextFromElement).map(String::strip).toArray();
        Log.info("Roof cover radio-buttons:: " + Arrays.toString(radioButtons));
        sa.assertEquals(radioButtons, ROOF_COVER_RADIO_BUTTONS, "Property Details Modal - Edit Roof cover radio-buttons.");
        sa.assertTrue(isElementDisplayed(pwXPath(SEE_EXAMPLES_BUTTON_XPATH)), "Property Details Modal - Edit Roof cover, button to see examples.");
        Object[] categories = locators(pwXPath(CATEGORY_TITLES_XPATH)).stream().map(this::getTextFromElement).map(String::strip).toArray();
        sa.assertEquals(categories, ROOF_COVER_CATEGORY_TITLES, "Property Details Modal - Edit Roof cover, Category titles.");

        validateRoofCoverExamples(sa);

        waitAndClickElement(closeEditPropertyModal);
    }

    public void validateRoofCoverExamples(FarmersSoftAssert sa) throws Exception {
        final String ROOF_COVER_EXAMPLES_TITLE = "Roof cover examples";
        final String ASPHALT = "Asphalt composition";
        final String FLAT = "Flat";
        final String METAL = "Metal";
        final String TILE = "Tile";
        final String WOOD = "Wood";
        final List<String> ROOF_COVER_CATEGORIES = Arrays.asList(ASPHALT, FLAT, METAL, TILE, WOOD);
        final String IMAGE_FILE_PREFIX = "roof-cover-examples/";

        final String ASPHALT_3TAB_SHINGLE_TEXT = "A composition roofing material including one layer of asphalt that is reinforced with " +
                "fiberglass or organic felt and has 3 distinct breaks or tabs for each shingle. When installed, it creates a distinct " +
                "symmetrical pattern resembling stacked bricks. It is commonly referred to as a 3-tab shingle, though formerly referred " +
                "to as an \"asphalt shingle\".";
        final String ASPHALT_ARCHITECTURAL_SHINGLE_TEXT = "Architectural (or laminated) shingles are double layered or 3-dimensional and " +
                "placed side-by-side when installed. Then the next course is placed 1/2 way on top of the last course. Unlike 3 Tab Shingles, " +
                "Architectural shingles do not create a visible pattern. The vertical lines of these shingles are slightly angled giving " +
                "the appearance of a roof more like a wood shake where the vertical lines do not have a distinct pattern. May also be called " +
                "\"laminated shingles\" or \"three-dimensional shingles.\"";
        final String ASPHALT_IMPACT_RESISTANT_SHINGLE_TEXT = "Composition roof shingles that are laminated, have a class A fire rating, " +
                "a class 4 impact resistance rating, and are designed to minimize damage caused by impact, such as hail.";
        final String ASPHALT_SYNTHETIC_ROOFING_TEXT = "Synthetic composition roofing is composed of fibers, cement, and a polymer resin " +
                "treatment made to resemble wood shakes. Typically a 50-year shingle.";

        final String FLAT_ROLL_ROOFING_TEXT = "Roofing material produced in rolls, made by saturating a fiberglass or organic mat with " +
                "asphalt or coal-tar pitch and embedding mineral particles on the surface exposed to the weather.";
        final String FLAT_HOT_MOPPED_GRAVEL_TEXT = "This type of roofing material is typically installed on flat roofs. Multi-layered " +
                "roofing felts with hot tar mopped between each layer. Sometimes a layer of pea gravel, rocks, or marble chips are " +
                "placed on top to protect the tar layer from the sun and add weight so that the roof won't blow off in a windstorm. " +
                "May also be called \"tar and gravel\". This type of roofing would also be inclusive of Modified Bitumen. " +
                "Modified roofing is somewhat similar in application to built-up's without gravel, with the pricing being very similar. " +
                "Modified Bitumen roofing may also include a colored granulated top sheet.";
        final String FLAT_HOT_MOPPED_NO_GRAVEL_TEXT = EMPTY_STRING;
        final String FLAT_MEMBRANE_EPDM_PVC_TEXT = "Roof coating membrane sheet made of ethylene propylene diene terpolymer material " +
                "that is long-lasting, UV resistant, and has elastic properties.";
        final String FLAT_SPF_TEXT = "Insulating sprayed-on foam usually coated with an elastomeric membrane to protect it from the elements.";

        final String METAL_STANDING_SEAM_TEXT = "Roofs that are built by installing sheets of copper with a standing seam pattern between the " +
                "sheets. Copper roofs turn green over time as the surface oxidizes.";
        final String METAL_COPPER_SHINGLE_TEXT = "Roofs that are built by installing copper shingles. Copper roofs turn green over time as " +
                "the surface oxidizes.";
        final String METAL_STANDING_SEAM_COPPER_TEXT = "Formed or extruded or roll-formed metal panels usually made of 24 gauge steel " +
                "installed over wood or steel framing.";
        final String METAL_CORRUGATED_GALVANIZED_TEXT = "Roofs that are built by installing sheets of metal. This may present a repeat " +
                "pattern of parallel ridges and valleys for a lineal appearance and is typically used for porches or patio covers.";
        final String METAL_TILE_SHAKE_TEXT = "Interlocking steel or aluminum roofing tile or strips that are covered in stone or embossed " +
                "and colored to look like individual wood shakes or clay tiles.";

        final String TILE_CLAY_TEXT = "This roof material comes in several styles. Flat, barrel (or mission), and \"S\" tile are the common " +
                "styles. This tile made from clay has been forced through an extruder, cut to size, air-dried, and then fired in a kiln. " +
                "It may be glazed or unglazed. Unglazed tiles may also be called \"Spanish\".";
        final String TILE_CONCRETE_TEXT = "This roof material comes in several styles. Flat, barrel (or mission), and \"S\" tile are the " +
                "common styles. Made primarily from cement, aggregate, water, and admixtures.";
        final String TILE_GLAZED_TEXT = "This roof material comes in several styles. Flat, barrel (or mission), and \"S\" tile are the " +
                "common styles. This tile made from clay has been forced through an extruder, cut to size, air-dried, and then fired in a kiln. " +
                "It may be glazed or unglazed. Unglazed tiles may also be called \"Spanish\".";
        final String TILE_CEMENT_FIBER_TEXT = "Composite shingles made of fiber-cement or cementitious material combined with Portland cement, " +
                "sand, clay and cellulose fiber. Cement fiber tiles have the appearance of wood.";
        final String TILE_SLATE_TEXT = "These roofs have thin pieces of slate arranged in overlapping rows. Roofing slate comes in a variety " +
                "of colors classified as unfading or weathering. Unfading colors stay very close to their original color throughout their life. " +
                "Weathering colors change as they age.";

        final String WOOD_SHINGLES_SHAKE_TEXT = "Shingles or shakes (about 3/8\" thick) that are installed in overlapping rows on the roof " +
                "slope to facilitate water runoff. There are several types of wood shingles. The appropriate wood shingle is assigned based on " +
                "the quality of the structure.";

        waitAndClickElement(seeExamples);
        sa.assertEquals(getTextFromElement(examplesCategoryTitle), ROOF_COVER_EXAMPLES_TITLE, "Roof cover examples title.");
        List<String> categories = getListOfCategories();
        sa.assertEquals(categories, ROOF_COVER_CATEGORIES, "Roof cover examples - list of categories.");
        for (String category : categories) {
            selectCategoryByName(category);
            switch (category) {
                case ASPHALT:
                    validateExamples(category, "3-tab shingle", ASPHALT_3TAB_SHINGLE_TEXT, IMAGE_FILE_PREFIX + "asphalt-3tab-shingle", sa);
                    validateExamples(category, "Architectural shingle", ASPHALT_ARCHITECTURAL_SHINGLE_TEXT, IMAGE_FILE_PREFIX + "asphalt-architectural-shingle", sa);
                    validateExamples(category, "Impact resistant shingle", ASPHALT_IMPACT_RESISTANT_SHINGLE_TEXT, IMAGE_FILE_PREFIX + "asphalt-impact-resistant-shingle", sa);
                    validateExamples(category, "Synthetic roofing", ASPHALT_SYNTHETIC_ROOFING_TEXT, IMAGE_FILE_PREFIX + "asphalt-synthetic-roofing", sa);
                    break;
                case FLAT:
                    validateExamples(category, "Roll roofing", FLAT_ROLL_ROOFING_TEXT, IMAGE_FILE_PREFIX + "flat-roll-roofing", sa);
                    validateExamples(category, "Built-up (hot mopped) w/ Gravel", FLAT_HOT_MOPPED_GRAVEL_TEXT, IMAGE_FILE_PREFIX + "flat-builtup-hot-mopped-with-gravel", sa);
                    validateExamples(category, "Built-up (hot mopped) w/o Gravel", FLAT_HOT_MOPPED_NO_GRAVEL_TEXT, IMAGE_FILE_PREFIX + "flat-builtup-hot-mopped-no-gravel", sa);
                    validateExamples(category, "Membrane \u2014 EPDM or PVC", FLAT_MEMBRANE_EPDM_PVC_TEXT, IMAGE_FILE_PREFIX + "flat-membrane-epdm-pvc", sa);
                    validateExamples(category, "Sprayed polyurethane foam (SPF)", FLAT_SPF_TEXT, IMAGE_FILE_PREFIX + "flat-SPF", sa);
                    break;
                case METAL:
                    validateExamples(category, "Standing seam", METAL_STANDING_SEAM_TEXT, IMAGE_FILE_PREFIX + "metal-standing-seam", sa);
                    validateExamples(category, "Copper shingle", METAL_COPPER_SHINGLE_TEXT, IMAGE_FILE_PREFIX + "metal-copper-shingle", sa);
                    validateExamples(category, "Standing seam copper", METAL_STANDING_SEAM_COPPER_TEXT, IMAGE_FILE_PREFIX + "metal-standing-seam-copper", sa);
                    validateExamples(category, "Corrugated galvanized", METAL_CORRUGATED_GALVANIZED_TEXT, IMAGE_FILE_PREFIX + "metal-corrugated-galvanized", sa);
                    validateExamples(category, "Tile/shake", METAL_TILE_SHAKE_TEXT, IMAGE_FILE_PREFIX + "metal-tile-shake", sa);
                    break;
                case TILE:
                    validateExamples(category, "Clay", TILE_CLAY_TEXT, IMAGE_FILE_PREFIX + "tile-clay", sa);
                    validateExamples(category, "Concrete", TILE_CONCRETE_TEXT, IMAGE_FILE_PREFIX + "tile-concrete", sa);
                    validateExamples(category, "Glazed", TILE_GLAZED_TEXT, IMAGE_FILE_PREFIX + "tile-glazed", sa);
                    validateExamples(category, "Cement fiber", TILE_CEMENT_FIBER_TEXT, IMAGE_FILE_PREFIX + "tile-cement-fiber", sa);
                    validateExamples(category, "Slate", TILE_SLATE_TEXT, IMAGE_FILE_PREFIX + "tile-slate", sa);
                    break;
                case WOOD:
                    validateExamples(category, "Shingles or shake", WOOD_SHINGLES_SHAKE_TEXT, IMAGE_FILE_PREFIX + "wood-shingles-shake", sa);
                    break;
                default:
                    sa.fail("Unknown Roof cover category: " + category);
            }
        }
        waitAndClickElement(closeEditPropertyExamplesModal);
    }

    public void enterPropertyDetails(ApplicantAceHome applicant) throws Exception {
        enterNotPrefilledPropertyDetails(applicant);

        if (!applicant.isKeep360Prefill()) {
            clickEditDetailsButton();
            if (!getEditModalPropertyDetailsFieldValue(YEAR_BUILT).equals(String.valueOf(applicant.getYearBuilt()))) {
                clickEditModalPropertyDetailsFieldEditButton(YEAR_BUILT);
                waitAndClickElement(editPropertyModalInput);
                sendKeysToElement(editPropertyModalInput, String.valueOf(applicant.getYearBuilt()));
                waitForElements("//mat-option");
                selectValueInDropDown(editPropertyModalInput, String.valueOf(applicant.getYearBuilt()));
                clickUpdatePropertyDetail(YEAR_BUILT, false);
            }
            if (!getEditModalPropertyDetailsFieldValue(TOTAL_SQ_FT).equals(applicant.getSquareFeet())) {
                clickEditModalPropertyDetailsFieldEditButton(TOTAL_SQ_FT);
                waitAndClickElement(editPropertyModalInput);
                sendKeysToElement(editPropertyModalInput, applicant.getSquareFeet() + Keys.TAB);
                clickUpdatePropertyDetail(TOTAL_SQ_FT, false);
            }
            if (!getEditModalPropertyDetailsFieldValue(STORIES).equals(applicant.getNumberOfStories())) {
                clickEditModalPropertyDetailsFieldEditButton(STORIES);
                selectEditModalRadioButtonByName(applicant.getNumberOfStories());
                clickUpdatePropertyDetail(STORIES, false);
            }
            if (!getEditModalPropertyDetailsFieldValue(BATHROOMS).equals(applicant.getBathrooms())) {
                clickEditModalPropertyDetailsFieldEditButton(BATHROOMS);
                waitAndClickElement(editPropertyModalInput);
                enterBathrooms(applicant.getBathrooms());
            }
            String fireplace = applicant.getFireplace().equals(EMPTY_STRING) ? NONE : applicant.getFireplace();
            if (!getEditModalPropertyDetailsFieldValue(FIREPLACE).equals(fireplace)) {
                clickEditModalPropertyDetailsFieldEditButton(FIREPLACE);
                selectEditModalRadioButtonByName(fireplace);
                clickUpdatePropertyDetail(FIREPLACE, false);
            }
            Log.info("Floor details - " + getEditModalPropertyDetailsFieldValue(FLOORS));
            Log.info("Floor data from applicant - " + applicant.getFloorCoverings());
            if (!getEditModalPropertyDetailsFieldValue(FLOORS).
                    equals(applicant.getFloorCoverings().replace(COMMA, ", "))) {
                clickEditModalPropertyDetailsFieldEditButton(FLOORS);
                selectEditModalCheckboxByName(applicant.getFloorCoverings());
                clickUpdatePropertyDetail(FLOORS, false);
            }
            if (!getEditModalPropertyDetailsFieldValue(GARAGE_STYLE).equals(applicant.getGarageStyle())) {
                clickEditModalPropertyDetailsFieldEditButton(GARAGE_STYLE);
                String garageStyle = applicant.getGarageStyle();
                // The dash in Built-in causes problems... don't need it for the purpose of selecting the radio button
                if (garageStyle.contains("Attached")) {
                	garageStyle = "Attached";
                }
                selectEditModalRadioButtonByName(garageStyle);
                clickUpdatePropertyDetail(GARAGE_STYLE, false);
            }
            if (isEditModalPropertyDetailsFieldDisplayed(GARAGE_CARPORT) &&
                    !getEditModalPropertyDetailsFieldValue(GARAGE_CARPORT).equals(applicant.getGarageCarport())) {
                clickEditModalPropertyDetailsFieldEditButton(GARAGE_CARPORT);
                selectEditModalRadioButtonByName(applicant.getGarageCarport());
                clickUpdatePropertyDetail(GARAGE_CARPORT, false);
            }
            if (isEditModalPropertyDetailsFieldDisplayed(EXTERIOR_WALL_FINISH) &&
                    !getEditModalPropertyDetailsFieldValue(EXTERIOR_WALL_FINISH).equals(applicant.getExteriorWallFinish())) {
                clickEditModalPropertyDetailsFieldEditButton(EXTERIOR_WALL_FINISH);
                selectEditModalRadioButtonByName(applicant.getExteriorWallFinish());
                clickUpdatePropertyDetail(EXTERIOR_WALL_FINISH, false);
            }
            if (isEditModalPropertyDetailsFieldDisplayed(FOUNDATION_TYPE) &&
                    !getEditModalPropertyDetailsFieldValue(FOUNDATION_TYPE).equals(applicant.getFoundationType())) {
                clickEditModalPropertyDetailsFieldEditButton(FOUNDATION_TYPE);
                selectEditModalRadioButtonByName(applicant.getFoundationType());
                clickUpdatePropertyDetail(FOUNDATION_TYPE, false);
            }
            if (isEditModalPropertyDetailsFieldDisplayed(FINISHED_BASEMENT) &&
                    !getEditModalPropertyDetailsFieldValue(FINISHED_BASEMENT).startsWith(applicant.getFinishedPercentOfBasement())) {
                clickEditModalPropertyDetailsFieldEditButton(FINISHED_BASEMENT);
                selectEditModalRadioButtonByName(applicant.getFinishedPercentOfBasement());
                clickUpdatePropertyDetail(FINISHED_BASEMENT, false);
            }
            if (isEditModalPropertyDetailsFieldDisplayed(ROOF_COVER) &&
                    !getEditModalPropertyDetailsFieldValue(ROOF_COVER).equals(applicant.getRoofCover())) {
                clickEditModalPropertyDetailsFieldEditButton(ROOF_COVER);
                selectEditModalRadioButtonByName(applicant.getRoofCover());
                clickUpdatePropertyDetail(ROOF_COVER, false);
            }
            waitAndClickElement(closeEditHomeDetailsModal);
            waitElementBeInvisible(closeEditHomeDetailsModal);
        }
    }

    private List<String> getNotPrefilledPropertyDetails() throws Exception {
        List<String> notPrefilled = new ArrayList<>();
        for (String detail : listOfPropertyDetails) {
            if (isPropertyDetailsFieldDisplayed(detail) && getPropertyDetailsFieldValue(detail).equals("---")) {
                notPrefilled.add(detail);
            }
        }
        return notPrefilled;
    }

    public void enterNotPrefilledPropertyDetails(ApplicantAceHome applicant) throws Exception {
        List<String> notPrefilled = getNotPrefilledPropertyDetails();
        int numberOfNonPrefilled = notPrefilled.size();
        for (int i=0; i< numberOfNonPrefilled; i++) {
            clickEditDetailsButton();
            switch (notPrefilled.get(i)) {
                case STORIES:
                    String stories = applicant.getNumberOfStories().equals(EMPTY_STRING) ? "1 story" : applicant.getNumberOfStories();
                    clickEditModalPropertyDetailsFieldEditButton(STORIES);
                    selectEditModalRadioButtonByName(stories);
                    clickUpdatePropertyDetail(STORIES, true);
                    break;
                case BATHROOMS:
                    String bathrooms = applicant.getBathrooms().equals(EMPTY_STRING) ? "1" : applicant.getBathrooms();
                    clickEditModalPropertyDetailsFieldEditButton(BATHROOMS);
                    waitAndClickElement(editPropertyModalInput);
                    enterBathrooms(bathrooms);
                    break;
                case FIREPLACE:
                    String fireplace = applicant.getFireplace().equals(EMPTY_STRING) ? NONE : applicant.getFireplace();
                    clickEditModalPropertyDetailsFieldEditButton(FIREPLACE);
                    selectEditModalRadioButtonByName(fireplace);
                    clickUpdatePropertyDetail(FIREPLACE, true);
                    break;
                case FLOORS:
                    String floors = applicant.getFloorCoverings().equals(EMPTY_STRING) ? "Carpet" : applicant.getFloorCoverings();
                    clickEditModalPropertyDetailsFieldEditButton(FLOORS);
                    selectEditModalCheckboxByName(floors);
                    clickUpdatePropertyDetail(FLOORS, true);
                    break;
                case GARAGE_STYLE:
                    String garageStyle = applicant.getGarageStyle().equals(EMPTY_STRING) ? NONE : applicant.getGarageStyle();
                    clickEditModalPropertyDetailsFieldEditButton(GARAGE_STYLE);
                    selectEditModalRadioButtonByName(garageStyle);
                    clickUpdatePropertyDetail(GARAGE_STYLE, true);
                    if (!notPrefilled.contains(GARAGE_CARPORT) && !applicant.getGarageCarport().equals(NONE)) {
                        String garageCarport = applicant.getGarageCarport().equals(EMPTY_STRING) ? "1 car" : applicant.getGarageCarport();
                        clickEditModalPropertyDetailsFieldEditButton(GARAGE_CARPORT);
                        selectEditModalRadioButtonByName(garageCarport);
                        clickUpdatePropertyDetail(GARAGE_CARPORT, true);
                    }
                    break;
                case GARAGE_CARPORT:
                    String garageCarport = applicant.getGarageCarport().equals(EMPTY_STRING) ? "1 car" : applicant.getGarageCarport();
                    if (!garageCarport.equals(NONE)) {
                        clickEditModalPropertyDetailsFieldEditButton(GARAGE_CARPORT);
                        selectEditModalRadioButtonByName(garageCarport);
                        clickUpdatePropertyDetail(GARAGE_CARPORT, true);
                    }
                    break;
                case EXTERIOR_WALL_FINISH:
                    String exteriorWallFinish = applicant.getExteriorWallFinish().equals(EMPTY_STRING) ? "Traditional hard coat"
                            : applicant.getExteriorWallFinish();
                    clickEditModalPropertyDetailsFieldEditButton(EXTERIOR_WALL_FINISH);
                    selectEditModalRadioButtonByName(exteriorWallFinish);
                    clickUpdatePropertyDetail(EXTERIOR_WALL_FINISH, true);
                    break;
                case FOUNDATION_TYPE:
                    String foundationType = applicant.getFoundationType().equals(EMPTY_STRING) ? "Concrete slab" : applicant.getFoundationType();
                    clickEditModalPropertyDetailsFieldEditButton(FOUNDATION_TYPE);
                    selectEditModalRadioButtonByName(foundationType);
                    clickUpdatePropertyDetail(FOUNDATION_TYPE, true);
                    break;
                case FINISHED_BASEMENT:
                    String finishedBasement = applicant.getFinishedPercentOfBasement().isBlank() ? "100" : applicant.getFinishedPercentOfBasement();
                    clickEditModalPropertyDetailsFieldEditButton(FINISHED_BASEMENT);
                    selectEditModalRadioButtonByName(finishedBasement);
                    clickUpdatePropertyDetail(FINISHED_BASEMENT, true);
                    break;
                case ROOF_COVER:
                    String roofCover = applicant.getRoofCover().equals(EMPTY_STRING) ? "Architectural shingle" : applicant.getRoofCover();
                    clickEditModalPropertyDetailsFieldEditButton(ROOF_COVER);
                    selectEditModalRadioButtonByName(roofCover);
                    clickUpdatePropertyDetail(ROOF_COVER, true);
                    break;
                case TYPE_OF_HOME:
                    String typeOfHome = "Single family detached";
                    clickEditModalPropertyDetailsFieldEditButton(TYPE_OF_HOME);
                    selectEditModalRadioButtonByName(typeOfHome);
                    clickUpdatePropertyDetail(TYPE_OF_HOME, true);
                    break;
                case MARKET_VALUE:
                    String marketValue = getSessionStorageAppStore().getHome().getReconstructionCost(); // "500,000";
                    clickEditModalPropertyDetailsFieldEditButton(MARKET_VALUE);
                    waitAndClickElement(editPropertyModalInput);
                    sendKeysToElement(editPropertyModalInput, marketValue + Keys.TAB);
                    clickUpdatePropertyDetail(MARKET_VALUE, true);
                    break;
                case FIRE_SPRINKLER_SYSTEM:
                    String sprinkler = applicant.getSprinklerSystem().isBlank() ? NONE : "One";
                    clickEditModalPropertyDetailsFieldEditButton(FIRE_SPRINKLER_SYSTEM);
                    selectEditModalRadioButtonByName(sprinkler);
                    clickUpdatePropertyDetail(FIRE_SPRINKLER_SYSTEM, true);
                    break;
                default:
                    throw new IllegalStateException("Invalid Property Details option:" + notPrefilled.get(i));
            }
            waitAndClickElement(closeEditHomeDetailsModal);
        }
    }

    public void validateEditTypeOfHome(String typeOfHome, FarmersSoftAssert sa) throws Exception {
        final String TYPE_OF_HOME_TEXT = "The type of structure of your home.";
        final String[] TYPE_OF_HOME_RADIO_BUTTONS = {"Single family detached", "Single family attached end unit",
                "Single family attached interior unit", "Two family (duplex)", "Other Tri-plex, Four-plex, multi-family, etc."};

        clickEditModalPropertyDetailsFieldEditButton(TYPE_OF_HOME);
        sa.assertEquals(getTextFromElement(editPropertyModalTitle), TYPE_OF_HOME, "Property Details Modal - Edit Type of home title.");
        sa.assertEquals(getTextFromElement(editPropertyModalText), TYPE_OF_HOME_TEXT, "Property Details Modal - Edit Type of home text.");
        if (!typeOfHome.equals(NONE)) {
            sa.assertEquals(getTextFromElement(editPropertyModalSelectedRadioButton), typeOfHome, "Property Details Modal - Edit Type of home selected value.");
        } else {
            sa.assertFalse(isElementDisplayed(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH + "[contains(@class,'radio-checked')]")),
                    "Property Details Modal - Edit Type of home, no value is selected.");
        }
        Object[] radioButtons = locators(pwXPath(EDIT_MODAL_RADIO_BUTTON_XPATH)).stream().map(this::getTextFromElement).map(String::strip).toArray();
        sa.assertEquals(radioButtons, TYPE_OF_HOME_RADIO_BUTTONS, "Property Details Modal - Edit Type of home radio-buttons.");

        waitAndClickElement(closeEditPropertyModal);
    }

    public void validatePropertyDetails(ApplicantAceHome applicant, String propertyType, FarmersSoftAssert sa) throws Exception {
        LinkedHashMap<String, String> propertyDetailsHash = new LinkedHashMap<>();
        AppStore appStore = this.getSessionStorageAppStore();
        AppStore.Home.PropertyForm propertyForm = appStore.getHome().getPropertyForm();
        AppStore.Home.PropertyDetailsForm propertyDetailsForm = appStore.getHome().getPropertyDetailsForm();

        sa.assertTrue(this.isPageSubtitleDisplayed(), "Property Details page - Subtitle is displayed.");
        sa.assertEquals(getPropertyDetailsAddressLine1().toUpperCase(), appStore.getHome().getAddressForm().getFields().get(0).getAddress(), "Property Details page - Street address (line 1)");
        sa.assertEquals(getPropertyDetailsAddressLine2().toUpperCase(), applicant.getCity().toUpperCase() + ", " + applicant.getStateCode().toUpperCase()
                + SPACE + applicant.getZipCode().toUpperCase(), "Property Details page - City, State and Zip code (address line 2)");

        if (applicant.isKeep360Prefill()) {
            propertyDetailsHash.put("year built", propertyForm.getFields().get(0).getYearBuilt());
            propertyDetailsHash.put("total sq. ft", String.format("%,d", Integer.parseInt(propertyForm.getFields().get(0).getSqFeet())));
            applicant.setYearBuilt(Integer.parseInt(propertyForm.getFields().get(0).getYearBuilt()));
            applicant.setSquareFeet(propertyForm.getFields().get(0).getSqFeet());
            String stories = propertyDetailsForm.getFieldValueByName("numberOfStories");
            propertyDetailsHash.put("stories", (stories.matches("^\\d.*") ? stories.split(SPACE)[0] : stories));
            String bathrooms = appStore.getHome().getPropertyDetailsForm().getFieldValueByName("numberOfBathroom");
            bathrooms = (bathrooms.contains(COMMA)) ?
                    Integer.toString(Stream.of(bathrooms.split(COMMA)).map(String::strip).mapToInt(Integer::parseInt).sum()) : bathrooms;
            propertyDetailsHash.put("bathrooms", bathrooms);
            String firePlaces = propertyDetailsForm.getFieldValueByName("firePlaces");
            propertyDetailsHash.put("fireplace", ((firePlaces == null) ? "None" : firePlaces));
            String floorCovering = propertyDetailsForm.getFieldValueByName("floorCoverings");
            propertyDetailsHash.put("floors", floorCovering.contains("Wood - Unknown Type") ? floorCovering.replace("Wood - Unknown Type", "Hardwood") : floorCovering);
            propertyDetailsHash.put("garage style", propertyDetailsForm.getFieldValueByName("garageStyle"));
            if(!propertyDetailsForm.getFieldValueByName("garageStyle").equals("No garage")) {
                String garageCarport = propertyDetailsForm.getFieldValueByName("garageCarport");
                garageCarport = (garageCarport == null) ? "---" : garageCarport;
                if (Integer.parseInt(garageCarport.substring(0, 1)) > 3) {
                    garageCarport = "4 or more cars";
                }
                propertyDetailsHash.put("garage carport", garageCarport);
            }
            propertyDetailsHash.put("exterior wall finish", propertyDetailsForm.getFieldValueByName("exteriorWallFinish"));
            propertyDetailsHash.put("foundation type", propertyDetailsForm.getFieldValueByName("foundationType"));
            String finishedBasement = propertyDetailsForm.getFieldValueByName("finishedPercentOfLowestLevel");
            if (finishedBasement != null) {
                finishedBasement = (finishedBasement.equals(ZERO)) ? "Unfinished" : finishedBasement;
            }
            propertyDetailsHash.put("finished basement", finishedBasement);
            propertyDetailsHash.put("roof cover", propertyDetailsForm.getFieldValueByName("roofCover"));
            propertyDetailsHash.put("type of home", propertyDetailsForm.getFieldValueByName("typeOfHome"));
        } else {
            propertyDetailsHash.put("year built", String.valueOf(applicant.getYearBuilt()));
            propertyDetailsHash.put("total sq. ft", String.format("%,d", Integer.parseInt(applicant.getSquareFeet())));
            String stories = applicant.getNumberOfStories();
            propertyDetailsHash.put("stories", (stories.matches("^\\d.*") ? stories.split(SPACE)[0] : stories));
            String bathrooms = applicant.getBathrooms();
            bathrooms = (bathrooms.contains(COMMA)) ?
                    Integer.toString(Stream.of(bathrooms.split(COMMA)).map(String::strip).mapToInt(Integer::parseInt).sum()) : bathrooms;
            propertyDetailsHash.put("bathrooms", bathrooms);
            propertyDetailsHash.put("fireplace", applicant.getFireplace());
            propertyDetailsHash.put("floors", applicant.getFloorCoverings().replace(COMMA, ", "));
            String garageStyle = applicant.getGarageStyle().isBlank() ? "No garage" : applicant.getGarageStyle();
            propertyDetailsHash.put("garage style", garageStyle);
            if(!garageStyle.equals("No garage")) {
                propertyDetailsHash.put("garage carport", applicant.getGarageCarport());
            }
            propertyDetailsHash.put("exterior wall finish", applicant.getExteriorWallFinish());
            propertyDetailsHash.put("foundation type", applicant.getFoundationType());
            propertyDetailsHash.put("finished basement", applicant.getFinishedPercentOfBasement());
            propertyDetailsHash.put("roof cover", applicant.getRoofCover());
            propertyDetailsHash.put("type of home", "Single family detached");
        }

        sa.assertEquals(this.getAceQuoteNumberInThePage(), applicant.getQuoteNumber(), "Property Details page - Quote number.");

        sa.assertEquals(this.getPropertyDetailsFieldValue("Year built"), propertyDetailsHash.get("year built"), "Property details page - Year built value.");
        sa.assertEquals(this.getPropertyDetailsFieldValue("Total finished sq. ft"), propertyDetailsHash.get("total sq. ft"),
                "Property details page - Total finished sq. ft value.");
        sa.assertEquals(this.getPropertyDetailsFieldValue("Stories"), propertyDetailsHash.get("stories"), "Property details page - Stories value.");
        sa.assertEquals(this.getPropertyDetailsFieldValue("Bathrooms"), propertyDetailsHash.get("bathrooms"), "Property details page - Bathrooms value.");
        sa.assertEquals(this.getPropertyDetailsFieldValue("Fireplace"), propertyDetailsHash.get("fireplace"), "Property details page - Fireplace value.");
        sa.assertEquals(Stream.of(this.getPropertyDetailsFieldValue("Floors").split(", ")).sorted().collect(Collectors.toList()),
                Stream.of(propertyDetailsHash.get("floors").split(", ")).sorted().collect(Collectors.toList()), "Property details page - Floors value.");
        sa.assertEquals(this.getPropertyDetailsFieldValue("Garage style"), propertyDetailsHash.get("garage style"), "Property details page - Garage style value.");
        if (this.isPropertyDetailsFieldDisplayed("Garage / carport")) {
            sa.assertEquals(this.getPropertyDetailsFieldValue("Garage / carport"), propertyDetailsHash.get("garage carport"), "Property details page - Garage / carport value.");
        }
        if (!propertyType.equals(CONDO)) {
            sa.assertEquals(this.getPropertyDetailsFieldValue("Exterior wall finish"), propertyDetailsHash.get("exterior wall finish"), "Property Details page - Exterior wall finish.");
            sa.assertEquals(this.getPropertyDetailsFieldValue("Foundation type"), propertyDetailsHash.get("foundation type"), "Property Details page - Foundation type.");
            if (isPropertyDetailsFieldDisplayed("Finished basement")) {
                String finishedBasement = propertyDetailsHash.get("finished basement");
                finishedBasement = finishedBasement.equals("Unfinished") ? finishedBasement : finishedBasement + "% finished";
                sa.assertEquals(this.getPropertyDetailsFieldValue("Finished basement"), finishedBasement, "Property Details page - Finished basement.");
            }
            sa.assertEquals(this.getPropertyDetailsFieldValue("Roof cover"), propertyDetailsHash.get("roof cover"), "Property Details page - Roof cover.");
        }
        if (propertyType.equals(TOWNHOME)) {
            sa.assertEquals(this.getPropertyDetailsFieldValue("Type of home"), propertyDetailsHash.get("type of home"), "Property Details page - Type of Home.");
        }
    }

    public void validateADA(String lobType) throws Exception {
        clickEditDetailsButton();
        performADATesting(this.getClass().getSimpleName()+"_EditDetails",MARKETING_IT,lobType);
        List<String> propertyDetails = getListOfPropertyDetailsEditModal();
        for (String field : propertyDetails) {
            Log.info("Selecting Edit Property Details Modal category: " + field);
            clickEditModalPropertyDetailsFieldEditButton(field);
            if (List.of("Year built", "Total sq. ft", "Bathrooms").contains(field)) {
                clearInputFieldModal(); // exposes empty input fields errors
            }
            if (field.contains("Stories")) {
                clickAtticButton(!this.getAttic()); // exposes Update button
            }
            performADATesting(this.getClass().getSimpleName()+"_EditDetails_"+"_"+field.replace("/","_"),MARKETING_IT,lobType);
            waitAndClickElement(closeEditPropertyModal);
        }
        waitAndClickElement(closeEditHomeDetailsModal);
        scrollToBottomOfPage();
        waitAndClickElement(reviewDiscountsLink);
        performADATesting(this.getClass().getSimpleName()+"_ReviewDiscounts",MARKETING_IT,lobType);
        waitAndClickElement(closeDiscountsSidesheet);
    }

}
