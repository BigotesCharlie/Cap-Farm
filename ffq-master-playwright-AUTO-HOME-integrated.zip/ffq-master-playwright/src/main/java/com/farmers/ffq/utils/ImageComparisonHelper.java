package com.farmers.ffq.utils;

import com.farmers.ffq.common.pages.BasePage;
import com.farmers.framework.report.Log;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static com.farmers.framework.AutomationFramework.page;

/** Screenshot and pixel-comparison support implemented only with Playwright and Java. */
public class ImageComparisonHelper {
    public void takeAndSaveWholePageScreenShot(Class<? extends BasePage> pageClass, String lob) throws Exception {
        BufferedImage wholePageImage = takeWholePageScreenShot();
        ImageIO.write(wholePageImage, "png", outputFile(getImageLocation(pageClass.getSimpleName(), lob)));
    }

    public void takeAndSaveLocatorScreenShot(Locator locator, String lob, String imageName) throws Exception {
        BufferedImage image = takeLocatorScreenShot(locator);
        ImageIO.write(image, "png", outputFile(getImageLocation(imageName, lob)));
    }

    public BufferedImage takeWholePageScreenShot() throws IOException {
        byte[] bytes = page().screenshot(new Page.ScreenshotOptions().setFullPage(true));
        return ImageIO.read(new ByteArrayInputStream(bytes));
    }

    public BufferedImage takeLocatorScreenShot(Locator locator) throws IOException {
        byte[] bytes = locator.screenshot();
        return ImageIO.read(new ByteArrayInputStream(bytes));
    }

    public boolean compareImages(BufferedImage expected, BufferedImage actual, String expectedImageName) throws IOException {
        int width = Math.max(expected.getWidth(), actual.getWidth());
        int height = Math.max(expected.getHeight(), actual.getHeight());
        BufferedImage marked = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = marked.createGraphics();
        graphics.drawImage(actual, 0, 0, null);
        graphics.dispose();

        boolean different = expected.getWidth() != actual.getWidth() || expected.getHeight() != actual.getHeight();
        int sharedWidth = Math.min(expected.getWidth(), actual.getWidth());
        int sharedHeight = Math.min(expected.getHeight(), actual.getHeight());
        int marker = new Color(255, 0, 0, 170).getRGB();
        for (int y = 0; y < sharedHeight; y++) {
            for (int x = 0; x < sharedWidth; x++) {
                if (expected.getRGB(x, y) != actual.getRGB(x, y)) {
                    different = true;
                    marked.setRGB(x, y, marker);
                }
            }
        }

        if (different) {
            File diff = outputFile("src/test/resources/screenshots/auto/difference/" + expectedImageName + ".png");
            ImageIO.write(marked, "png", diff);
            Log.error(expectedImageName + " image differs from the actual image");
        } else {
            Log.info(expectedImageName + " image has no pixel differences");
        }
        return !different;
    }

    public BufferedImage getExpectedImage(String image, String lob) throws IOException {
        return ImageIO.read(new File(getImageLocation(image, lob)));
    }

    public BufferedImage getExpectedWholePageImage(Class<? extends BasePage> pageClass, String lob) throws IOException {
        return ImageIO.read(new File(getImageLocation(pageClass.getSimpleName(), lob)));
    }

    private String getImageLocation(String image, String lob) {
        if (AUTO.equals(lob)) {
            return "src/test/resources/screenshots/auto/" + image + ".png";
        }
        if (HOME.equals(lob) || CONDO.equals(lob) || RENTERS.equals(lob) || LIFE.equals(lob)) {
            return "src/test/resources/screenshots/" + lob.toLowerCase() + "/" + image + ".png";
        }
        throw new IllegalArgumentException("Unsupported line of business for screenshot: " + lob);
    }

    private File outputFile(String path) throws IOException {
        File file = new File(path);
        File parent = file.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs() && !parent.exists()) {
            throw new IOException("Unable to create screenshot directory: " + parent);
        }
        return file;
    }
}
