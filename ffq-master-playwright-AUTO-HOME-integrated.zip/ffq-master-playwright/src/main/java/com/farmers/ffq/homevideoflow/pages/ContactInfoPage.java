package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.farmers.ffq.homevideoflow.support.DomArtifacts;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public final class ContactInfoPage extends BaseHomePage {
    private final DomArtifacts artifacts;

    public ContactInfoPage(Page page) {
        this(page, null);
    }

    public ContactInfoPage(Page page, DomArtifacts artifacts) {
        super(page);
        this.artifacts = artifacts;
    }

    public void complete(VideoScenarioData d) {
        String currentUrl = page.url();
        if (currentUrl != null && currentUrl.toLowerCase().contains("/quote/auto/contact-info")) {
            page.navigate(currentUrl.replace("/quote/auto/contact-info", "/quote/home/contact-info"));
        }

        waitForBodyReady();
        waitForSpinnerToClear();

        fillPolicyDate(d);
        selectMailingAddress(d.address());
        fillEmail(d.email());
        fillPhone(d.mobilePhone());

        if (artifacts != null) {
            captureContactInfoEvidence();
        }

        Locator submit = button("Agree and submit");
        if (submit.count() == 0) {
            submit = page.getByText("Agree and submit", new Page.GetByTextOptions().setExact(true));
        }
        System.out.printf("[VIDEO FLOW] Submit state enabled=%s disabled=%s count=%d url=%s%n",
                submit.count() > 0 && submit.first().isEnabled(),
                submit.count() > 0 && submit.first().isDisabled(),
                submit.count(),
                page.url());
        if (submit.count() > 0) {
            submit.first().click();
        } else {
            throw new IllegalStateException("Agree and submit not found @ " + page.url());
        }

        page.waitForFunction(
                "() => {" +
                        "const u = document.location.href.toLowerCase();" +
                        "const text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();" +
                        "return text.includes('review your dwelling coverage')" +
                        " || u.includes('custom-coverage')" +
                        " || text.includes('home coverages')" +
                        " || text.includes('thank you for choosing farmers insurance')" +
                        " || text.includes('how would you like to pay')" +
                        " || text.includes('home policy payment')" +
                        " || u.includes('inconvenience') || u.includes('knockout')" +
                        " || text.includes(\"we're sorry, we can't finish\")" +
                        " || text.includes('try again');" +
                        "}",
                null,
                new Page.WaitForFunctionOptions().setTimeout(30_000)
        );
    }

    private void fillPolicyDate(VideoScenarioData d) {
        String runtimeDate = d.runtimePolicyStartDate().replace("/", "");
        Locator date = page.locator("input[aria-label='When would you like your policy to begin? Policy start date in the format of mmddyyyy.']");
        if (date.count() == 0) {
            date = page.getByLabel("When would you like your policy to begin?", new Page.GetByLabelOptions().setExact(false));
        }
        if (date.count() > 0) {
            date.first().fill(runtimeDate);
            date.first().press("Tab");
            System.out.printf("[VIDEO FLOW] Policy start date: video=%s runtime=%s%n", d.videoPolicyStartDate(), runtimeDate);
        }
    }

    private void selectMailingAddress(String address) {
        Locator mailing = page.getByLabel(address, new Page.GetByLabelOptions().setExact(true));
        if (mailing.count() > 0) {
            Locator choice = mailing.first();
            if (!choice.isChecked()) {
                choice.check();
            }
            return;
        }
        Locator text = page.getByText(address, new Page.GetByTextOptions().setExact(false));
        if (text.count() > 0) {
            text.first().click();
        }
    }

    private void fillEmail(String email) {
        Locator field = page.locator("#flex-field-emailAddress-input_contactInfo");
        if (field.count() == 0) {
            field = page.getByLabel("Email address", new Page.GetByLabelOptions().setExact(false));
        }
        if (field.count() > 0) {
            field.first().fill(email);
            field.first().press("Tab");
            System.out.printf("[VIDEO FLOW] Email value now=%s%n", safeValue(field.first()));
        }
    }

    private void fillPhone(String phone) {
        Locator field = page.locator("#flex-field-phoneNumber-input_contactInfo");
        if (field.count() == 0) {
            field = page.getByLabel("Mobile phone", new Page.GetByLabelOptions().setExact(false));
        }
        if (field.count() > 0) {
            String formatted = formatPhone(phone);
            field.first().fill(formatted);
            field.first().press("Tab");
            System.out.printf("[VIDEO FLOW] Phone value now=%s%n", safeValue(field.first()));
        }
    }

    private String formatPhone(String phone) {
        String digits = phone == null ? "" : phone.replaceAll("\\D+", "");
        if (digits.length() == 10) {
            return "(" + digits.substring(0, 3) + ") " + digits.substring(3, 6) + "-" + digits.substring(6);
        }
        return phone;
    }

    private void captureContactInfoEvidence() {
        artifacts.captureNamed("contact-info-before-submit");
        artifacts.writeText("contact-info-url.txt", page.url());
        artifacts.writeText("contact-info-fields.txt", summarizeFields());
        artifacts.writeText("contact-info-buttons.txt", summarizeButtons());
        artifacts.writeText("contact-info-validation.txt", summarizeValidation());
    }

    private String summarizeFields() {
        StringBuilder out = new StringBuilder();
        appendGroup(out, "input", "input");
        appendGroup(out, "select", "select");
        appendGroup(out, "textarea", "textarea");
        appendGroup(out, "app-date-picker", "app-date-picker");
        appendGroup(out, "mat-form-field", "mat-form-field");
        appendGroup(out, "mat-checkbox", "mat-checkbox");
        appendGroup(out, "mat-radio-button", "mat-radio-button");
        return out.toString();
    }

    private String summarizeButtons() {
        StringBuilder out = new StringBuilder();
        Locator buttons = page.locator("button,[role='button']");
        for (int i = 0; i < buttons.count(); i++) {
            Locator b = buttons.nth(i);
            if (!b.isVisible()) continue;
            out.append(describe("button", b)).append('\n');
        }
        return out.toString();
    }

    private String summarizeValidation() {
        StringBuilder out = new StringBuilder();
        Locator validation = page.locator("[aria-invalid='true'], .error, .errors, .validation, .invalid, mat-error, [role='alert']");
        for (int i = 0; i < validation.count(); i++) {
            Locator v = validation.nth(i);
            if (!v.isVisible()) continue;
            out.append(v.textContent()).append('\n');
        }
        return out.toString();
    }

    private void appendGroup(StringBuilder out, String tag, String selector) {
        Locator group = page.locator(selector);
        for (int i = 0; i < group.count(); i++) {
            Locator el = group.nth(i);
            if (!el.isVisible()) continue;
            out.append(describe(tag, el)).append('\n');
        }
    }

    private String describe(String tag, Locator el) {
        return String.join(" | ",
                "tag=" + tag,
                "id=" + safeAttr(el, "id"),
                "name=" + safeAttr(el, "name"),
                "formControlName=" + safeAttr(el, "formcontrolname"),
                "aria-label=" + safeAttr(el, "aria-label"),
                "placeholder=" + safeAttr(el, "placeholder"),
                "value=" + safeValue(el),
                "required=" + safeAttr(el, "required") + "/" + safeAttr(el, "aria-required"),
                "disabled=" + safeBool(() -> el.isDisabled()),
                "aria-invalid=" + safeAttr(el, "aria-invalid"),
                "visible=" + safeBool(el::isVisible),
                "editable=" + safeBool(el::isEditable),
                "checked=" + safeBool(el::isChecked)
        );
    }

    private String safeAttr(Locator el, String name) {
        try {
            String value = el.getAttribute(name);
            return value == null ? "" : value;
        } catch (RuntimeException e) {
            return "";
        }
    }

    private String safeValue(Locator el) {
        try {
            String value = el.inputValue();
            return value == null ? "" : value;
        } catch (RuntimeException e) {
            return "";
        }
    }

    private String safeBool(BooleanSupplier supplier) {
        try {
            return Boolean.toString(supplier.getAsBoolean());
        } catch (RuntimeException e) {
            return "";
        }
    }

    @FunctionalInterface
    private interface BooleanSupplier {
        boolean getAsBoolean();
    }
}
