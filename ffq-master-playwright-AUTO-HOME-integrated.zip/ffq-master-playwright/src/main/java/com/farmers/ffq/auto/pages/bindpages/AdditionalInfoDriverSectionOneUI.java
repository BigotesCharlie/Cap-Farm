package com.farmers.ffq.auto.pages.bindpages;




import com.farmers.framework.playwright.PlaywrightActions;
import com.farmers.framework.playwright.Keys;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Auto.Driver;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.LicenseFormatByState;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import net.datafaker.Faker;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.RandomUtils;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AdditionalInfoDriverSectionOneUI extends AutoBasePage {

    private static String DRIVER_SECTION_XPATH = "//p[contains(.,'%s')]/../../..";
    private static String DRIVER_SECTION_LICENSENUMBER_INPUT_XPATH = "//input[@aria-label='License']";

        private Locator driverLabel = locator(pwXPath("//h3[contains(text(), 'license info')]"));

    //private static final String DRIVER_SIDEBAR_QUESTION = "Why do you need my driver’s license number?";
        private Locator whyNeedDriverLicenseQuestion = locator(pwXPath("//p[contains(text(), 'Why do you need my driver')]"));

        private Locator whyNeedDriverLicenseQuestionMB = locator(pwXPath("//h1[contains(text(), 'Why do you need my driver')]"));

    private static final String DRIVER_SIDEBAR_ANSWER = "This is required to check your driving history and motor vehicle report.";
        private Locator whyNeedDriverLicenseExplanation = locator(pwXPath("//p[contains(text(), 'This is required to check your driving history')]"));

        private Locator getWhyNeedDriverLicenseQuestionTipMB = locator(pwXPath("//div[contains(@class,'additional-info-driver-section')]//div[contains(@class,'additional_info_tips_section_medium')]//mat-icon"));
        private Locator parentNodeForDriverList = locator(pwXPath("//div[@formarrayname ='drivers']"));

        public Locator driverLicenseNumberInputTextBoxes = locator(pwXPath("//input[@data-gtm='FFQ_Auto_AddDriverDetails_DriverLicense_text']"));

        private Locator driverLicenseStateDropDownLocatorList = locator(pwXPath("//mat-select[@data-gtm='FFQ_Auto_AddDriverDetails_DriverLicenseState_text']"));

    private final String RACE_TOGGLE_GROUP_XPATH = "//mat-button-toggle-group[@formcontrolname='customerrnogConsent']";

        private Locator test = locator(pwXPath("//mat-label[contains(text(),'State')]"));

    private final String DRIVER_LICENSE_PLACEHOLDER_TEXT = "Driver's license #";
        private Locator driverLicenseNumberInputPlaceHolders = locator(pwXPath("//mat-label[contains(text(),\"Driver's license #\")]"));

    private final String ENTER_DRIVER_LICENSE_ERROR = "Please enter license number.";
        private Locator enterDriverLicenseNumberErrors = locator(pwXPath("//mat-error[contains(text(),'license number')]"));

        private Locator listOfAllTheStatesInLicenseStateDropdown = locator(pwXPath("//span[@class='mat-option-text']"));

        private Locator invalidLicenseError = locator(pwXPath("//mat-error[contains(text(),'License # not valid for this state.')]"));

    private final String COMPLETED_MATURE_DRIVER_SAFETY_COURSE_LAST_3_YEARS = "Completed a mature driver safety course in the last 3 years";
        private Locator completedMatureDriverSafetyCourseLastThreeYears = locator(pwXPath("//span[contains(text(),'" + COMPLETED_MATURE_DRIVER_SAFETY_COURSE_LAST_3_YEARS + "')]"));

        private Locator disabledMatureSafetyCourseToggleButton = locator(pwXPath("//mat-slide-toggle[@formcontrolname='mddCourseToggle']//input[@aria-checked='false']"));

        private Locator enabledMatureSafetyCourseToggleButton = locator(pwXPath("//mat-slide-toggle[@formcontrolname='mddCourseToggle']//input[@aria-checked='true']"));

        private Locator mddSafetyCourseDateInputBox = locator(pwXPath("//input[@formcontrolname='mddSafetyCourseDate']"));

    private final String PROVIDE_COMPLETION_DATE_TOGGLE_OFF_HINT = "Provide completion date, or toggle off completed course";
        private Locator provideCompletionDateOrToggleOffHint = locator(pwXPath("//mat-hint[contains(text(),'" + PROVIDE_COMPLETION_DATE_TOGGLE_OFF_HINT + "')]"));

    private final String PROVIDE_COMPLETION_DATE_CHECK_CHECKBOX_HINT = "Provide completion date, or check the box below";
        private Locator provideCompletionDateOrCheckCheckboxHint = locator(pwXPath("//mat-hint[contains(text(),'" + PROVIDE_COMPLETION_DATE_CHECK_CHECKBOX_HINT + "')]"));

        private Locator mddSafetyCourseDateIDoNotKnowCheckbox = locator(pwXPath("//mat-checkbox[@formcontrolname='mddSafetyCourseDateIDoNotKnow']//label//input[@type='checkbox']"));

        private Locator mddSafetyCourseDateIDoNotKnowLabel = locator(pwXPath("//mat-checkbox[@formcontrolname='mddSafetyCourseDateIDoNotKnow']//label//span[@class='mat-checkbox-label']"));

    //The date must be between
        private Locator mddSafetyCourseDateRangeError = locator(pwXPath("//mat-error[contains(text(),'The date must be between')]"));

    private final String MDD_MUST_BE_MMYYYY_FORMAT = "Date must be in mm/yyyy format";
        private Locator mddMustBeInMMYYYYFormatError = locator(pwXPath("//mat-error[contains(text(),'" + MDD_MUST_BE_MMYYYY_FORMAT + "')]"));

        private Locator countryDropDowns = locator(pwCss("mat-select[formcontrolname='licenseCountry']"));

        private Locator foreignDlInputField = locator(pwCss("input[formcontrolname='countryLicenseNumber']"));

        private Locator fdlStartDateInputFields = locator(pwXPath("//input[contains(@aria-label,'Select license start')]"));

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public AdditionalInfoDriverSectionOneUI() throws Exception {
    }


    public void verifyDriverSection(AppStore retrieveQuoteResponseSessionStorage, FarmersSoftAssert fsa) throws Exception {
        removeQualtricsPopUp();
        List<Driver> listOfDriverWithEmptyLicenseNumber = checkIfDriverSectionAvailable();
          if(!listOfDriverWithEmptyLicenseNumber.isEmpty()){
              removeQualtricsPopUp();
              validateDriverSectionLabelsAndTexts(fsa);
              validateDriversNameAndDriverLicenseTextBox(retrieveQuoteResponseSessionStorage, listOfDriverWithEmptyLicenseNumber, fsa);
              validateEditDriverLicense(listOfDriverWithEmptyLicenseNumber, fsa);
              validateStatesInDriverLicenseStateDropdown(fsa);
              validateMatureDriverSafetyDates(retrieveQuoteResponseSessionStorage, fsa);
          }

          validateDriverInfoRaceSectionIfAvailable(fsa);

    }

    private void validateDriverInfoRaceSectionIfAvailable(FarmersSoftAssert softAssert) throws Exception {

        if(!getSessionStorageAppStore().getData().getLandingStateCode().equals(CA)) {
            return; // this test is only applicable for CA
        }
        List<Locator> driverInfoRaceQuestions = locators(pwXPath(RACE_TOGGLE_GROUP_XPATH));

        softAssert.assertFalse(driverInfoRaceQuestions.isEmpty(), "RNOG, race section should not be empty, it should be visible at least for PNI");
        // validate labels
        String expectedQuestion = "Do you wish to provide the Department of Insurance with information regarding your race, national origin and gender?";
        int numberOfQuestions = driverInfoRaceQuestions.size();
        for (int i = 0; i < numberOfQuestions; i++) {
            List<Locator> questions = locators(pwXPath(RACE_TOGGLE_GROUP_XPATH + "/../..//label[contains(.,'Department')]"));
            softAssert.assertEquals(getTextFromElement(questions.get(i)), expectedQuestion);

            // validate error message
            clickContinueButton();
            Locator errorMessages = locator(pwXPath(RACE_TOGGLE_GROUP_XPATH + "/..//mat-error"));
            softAssert.assertEquals(getTextFromElement(errorMessages), "Must choose a selection");

            // validate no drop down selected error message
            Locator yesToggle = locators(pwXPath("//mat-button-toggle-group[@formcontrolname='customerrnogConsent']//mat-button-toggle[contains(.,'Yes')]")).get(i);
            waitAndClickElement(yesToggle);

            clickContinueButton();
            softAssert.assertTrue(isElementPresent(pwXPath("//mat-error[contains(.,'Please select race or national origin')]"), 1));

        }

    }

    public List<AppStore.Auto.Driver> checkIfDriverSectionAvailable() throws Exception {
        List<AppStore.Auto.Driver> listOfDriverWithEmptyLicenseNumber = getSessionStorageAppStore().getAuto().getDrivers().stream().filter(item-> item.getLicNumber() == null && item.isHasDriverLicense()).collect(Collectors.toList());
        return listOfDriverWithEmptyLicenseNumber;
    }

    public void validateDriverSectionLabelsAndTexts(FarmersSoftAssert fsa) throws Exception {
        if(isUseMobileViewEnabled()) {
            waitAndClickElement(getWhyNeedDriverLicenseQuestionTipMB.nth(0));
            fsa.assertTrue(whyNeedDriverLicenseQuestionMB.isVisible(), "Why Need Driver License Question MB displayed");
            waitAndClickElement(closeIconMB);
        } else {
            fsa.assertTrue(whyNeedDriverLicenseQuestion.isVisible(), "Why Need Driver License Question displayed");
            fsa.assertEquals(getTextFromElement(whyNeedDriverLicenseExplanation), DRIVER_SIDEBAR_ANSWER, "Why Need Driver License Question content verification");
        }

    }

    // validate full name and landing state code of drivers in Driver license info section
    public void validateDriversNameAndDriverLicenseTextBox(AppStore quoteResponseSessionStorage, List<Driver> driverList, FarmersSoftAssert fsa) throws Exception {
    	int numberOfDrivers = driverList.size();
        for(int i = 0; i < numberOfDrivers; i++){
            String driverFullNameXpath = "//p[text()=' " + driverList.get(i).getFirstName()+ " " + driverList.get(i).getLastName()+ " ']";
            Locator driverElement = locator(pwXPath(driverFullNameXpath));
            fsa.assertTrue(driverElement.isVisible(), "Driver" + i +" In Drivers License Section displayed");
            fsa.assertEquals(getTextFromElement(driverLicenseStateDropDownLocatorList.nth(i)), quoteResponseSessionStorage.getData().getLandingStateCode(), "Landing State Code In License State Dropdown for" +
                    " Driver" + i +" verification");
            fsa.assertTrue(driverLicenseNumberInputTextBoxes.nth(i).isVisible(), "Driver License Number Input TextBox displayed for Driver" + i);
            waitElementBeVisible(driverLicenseNumberInputPlaceHolders.nth(i));
            fsa.assertEquals(getTextFromElement(driverLicenseNumberInputPlaceHolders.nth(i)), DRIVER_LICENSE_PLACEHOLDER_TEXT, "Driver License Number Input TextBox Placeholder Text Is Not Available For Driver" + i);
           // scrollToElementWithOffset(driverLicenseNumberInputTextBoxes.nth(i), 30);

            waitAndClickElement(driverLicenseNumberInputTextBoxes.nth(i));
            //driverLicenseNumberInputTextBoxes.nth(i).click();
            sendKeys(driverLicenseNumberInputTextBoxes.nth(i), Keys.chord(Keys.TAB));

        }
        fsa.assertEquals(enterDriverLicenseNumberErrors.count(), driverList.size(), "Enter Driver License Error Is Not Displayed On Empty Driver License Input Box.");
    }

    public void validateEditDriverLicense(List<Driver> driverList, FarmersSoftAssert fsa) throws Exception {
    	int numberOfDrivers = driverList.size();
    	for (int i = 0; i < numberOfDrivers; i++) {

            int randomIndex = new Random().nextInt(listOfAllStates().size());
            String randomState = listOfAllStates().get(randomIndex);
            String randomlySelectedStateLicenseNumber = LicenseFormatByState.getLicenseNumberByState(randomState);

            String licenseNumber = LicenseFormatByState.getLicenseNumberByState(getTextFromElement(driverLicenseStateDropDownLocatorList.nth(i)));

            // landing state code - invalid driver license number
            sendKeysOneByOne(driverLicenseNumberInputTextBoxes.nth(i), licenseNumber + "AB");
            sendKeys(driverLicenseNumberInputTextBoxes.nth(i), Keys.chord(Keys.TAB));

            waitElementBeVisible(invalidLicenseError);
            fsa.assertEquals(invalidLicenseError.isVisible(), true, "Driver License Number Is Valid for driver " + i);

            // landing state code - valid driver license number
            waitAndClickElement(driverLicenseNumberInputTextBoxes.nth(i));
//            driverLicenseNumberInputTextBoxes.nth(i).click();
            sendKeysOneByOne(driverLicenseNumberInputTextBoxes.nth(i), licenseNumber);
            sendKeys(driverLicenseNumberInputTextBoxes.nth(i), Keys.chord(Keys.TAB));


            // randomly select state in drop down - valid license number
            clickOnHiddenElement(driverLicenseStateDropDownLocatorList.nth(i));
            //driverLicenseStateDropDownLocatorList.nth(i).click();
            List<Locator> stateDropDownElements = locators(pwXPath("//span[@class='mat-option-text']"));
            Locator randomlySelectedState = stateDropDownElements.get(randomIndex);
            scrollAndClickOnHiddenElement(randomlySelectedState);
            sendKeysOneByOne(driverLicenseNumberInputTextBoxes.nth(i), randomlySelectedStateLicenseNumber);
            sendKeys(driverLicenseNumberInputTextBoxes.nth(i), Keys.chord(Keys.TAB));


            // randomly select state in drop down - invalid license number
            sendKeysOneByOne(driverLicenseNumberInputTextBoxes.nth(i), randomlySelectedStateLicenseNumber + "AB");
            sendKeys(driverLicenseNumberInputTextBoxes.nth(i), Keys.chord(Keys.TAB));

            waitElementBeVisible(invalidLicenseError);
            fsa.assertEquals(invalidLicenseError.isVisible(), true, "Driver License Number Is Valid for driver " + i);

            // back to randomly select state in drop down - valid license number
            sendKeysOneByOne(driverLicenseNumberInputTextBoxes.nth(i), randomlySelectedStateLicenseNumber);
            sendKeys(driverLicenseNumberInputTextBoxes.nth(i), Keys.chord(Keys.TAB));

        }
    }

    public void validateStatesInDriverLicenseStateDropdown(FarmersSoftAssert fsa) throws Exception {
        PlaywrightActions builder = actions();
        List<String> expectedAllStateAbbreviation = listOfAllStates();
    	int numberOfElements = driverLicenseStateDropDownLocatorList.count();
        for(int i =0; i< numberOfElements; i++){
            clickOnHiddenElement(driverLicenseStateDropDownLocatorList.nth(i));
            waitForUiSettled();
            List<String> foundAllStateAbbreviation =  listOfAllTheStatesInLicenseStateDropdown.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
            fsa.assertEquals(foundAllStateAbbreviation, expectedAllStateAbbreviation, "All The States Are Not Available In State DropDown for driver " + i + "." );
            waitForUiSettled();
            builder.moveToElement(driverLicenseStateDropDownLocatorList.nth(i), 100, 100).click().build().perform();
        }
    }

    public void enterDriverLicenseNumber(AppStore retrieveQuoteResponseSessionStorage) throws Exception {
        closeQualtricsPopUp();
    	int numberOfElements = driverLicenseStateDropDownLocatorList.count();
        for(int i =0; i< numberOfElements; i++){
            // enter driving license number
            String licenseNumber = LicenseFormatByState.getLicenseNumberByState(getTextFromElement(driverLicenseStateDropDownLocatorList.nth(i)));
            Locator dlInputElement = driverLicenseNumberInputTextBoxes.nth(i);
            scrollElementToMiddle(dlInputElement);
            waitAndClickElement(dlInputElement);
            sendKeysOneByOne(dlInputElement, licenseNumber);
            sendKeys(dlInputElement, Keys.TAB);
            waitForSpinnerToBeGone();
            Log.info("Entering US dl number: " + licenseNumber);
        }
        enterForeignDriverLicenseDetails();
    }

    public void fillOutDriverInfoSectionForRace() throws Exception {
        closeQualtricsPopUp();
        List<Locator> raceQuestions = locators(pwXPath(RACE_TOGGLE_GROUP_XPATH));
    	int numberOfElements = raceQuestions.size();
        for (int i = 0; i < numberOfElements; i++) {
            // randomly select Yes or No
            String yesOrNo = YES;
            Locator toggleElement = locators(pwXPath(String.format("//mat-button-toggle-group[@formcontrolname='customerrnogConsent']//mat-button-toggle[contains(.,'%s')]", yesOrNo))).get(i);
            waitAndClickElement(toggleElement);
            Log.info(String.format("User selected %s for the race question", yesOrNo));
            if (yesOrNo.equals(YES)) {
                waitForUiSettled();
                Locator raceDropDown = locators(pwCss("mat-select[formcontrolname='raceEthinicity']")).get(i);
                waitAndClickElement(raceDropDown);
                waitForUiSettled();
                List<Locator> listOfAvailableRaces = locators(pwXPath("//mat-option[contains(.,'African')]/..//mat-option"));
                waitAndClickElement(listOfAvailableRaces.get(new Random().nextInt(listOfAvailableRaces.size()- 1)));
            }
        }
    }

    public void enterDriverLicenseNumber(String stateCode) throws Exception {
        closeQualtricsPopUp();
    	int numberOfElements = driverLicenseStateDropDownLocatorList.count();
        for(int i =0; i< numberOfElements; i++){
            // enter driving license number
            String licenseNumber = LicenseFormatByState.getLicenseNumberByState(stateCode);
            waitAndClickElement(driverLicenseStateDropDownLocatorList.nth(i));
            Locator desiredState = locator(pwXPath(String.format("//mat-option[contains(.,'%s')]", stateCode)));
            waitAndClickElement(desiredState);
            Locator dlInputElement = driverLicenseNumberInputTextBoxes.nth(i);
            scrollElementToMiddle(dlInputElement);
            waitAndClickElement(dlInputElement);
            sendKeysOneByOne(dlInputElement, licenseNumber);
            sendKeys(dlInputElement, Keys.TAB);
            waitForSpinnerToBeGone();
            Log.info("Entering US dl number: " + licenseNumber);
        }
        enterForeignDriverLicenseDetails();
    }

    public void enterDriverLicenseNumber(String stateCode, String licenseNumber) throws Exception {
        closeQualtricsPopUp();
        int numberOfElements = driverLicenseStateDropDownLocatorList.count();
        for (int i = 0; i < numberOfElements; i++) {
            String resolvedStateCode = stateCode;
            if (resolvedStateCode == null || resolvedStateCode.isBlank()) {
                resolvedStateCode = getTextFromElement(driverLicenseStateDropDownLocatorList.nth(i));
            }
            String resolvedLicenseNumber = licenseNumber;
            if (resolvedLicenseNumber == null || resolvedLicenseNumber.isBlank()) {
                resolvedLicenseNumber = LicenseFormatByState.getLicenseNumberByState(resolvedStateCode);
            }
            waitAndClickElement(driverLicenseStateDropDownLocatorList.nth(i));
            Locator desiredState = locator(pwXPath(String.format("//mat-option[contains(.,'%s')]", resolvedStateCode)));
            waitAndClickElement(desiredState);
            Locator dlInputElement = driverLicenseNumberInputTextBoxes.nth(i);
            scrollElementToMiddle(dlInputElement);
            waitAndClickElement(dlInputElement);
            sendKeysOneByOne(dlInputElement, resolvedLicenseNumber);
            sendKeys(dlInputElement, Keys.TAB);
            waitForSpinnerToBeGone();
            Log.info("Entering US dl number: " + resolvedLicenseNumber);
        }
        enterForeignDriverLicenseDetails();
    }

    // validate mature driver safety course section
    public void validateMatureDriverSafetyDates(AppStore retrieveQuoteResponseSessionStorage, FarmersSoftAssert fsa) throws Exception {
        // mature driver discount
        String landingStateCode = retrieveQuoteResponseSessionStorage.getData().getLandingStateCode();
        List<Driver> listOfDriversEligibleMatureSafetyCourse = null;
        List<Driver> listOfOriginalDrivers = retrieveQuoteResponseSessionStorage.getAuto().getDrivers();

        if (isMatureDriverSafetyCourseMandatory(landingStateCode)) {
            if (landingStateCode.equals(KS)) {
                listOfDriversEligibleMatureSafetyCourse = filterDriverListByAge(0, listOfOriginalDrivers);
            } else {
                listOfDriversEligibleMatureSafetyCourse = filterDriverListByAge(55, listOfOriginalDrivers);
            }
            checkMatureDriverDiscount(listOfDriversEligibleMatureSafetyCourse, true, fsa);
        }
//        else{
//            listOfDriversEligibleMatureSafetyCourse = filterDriverListByAge(55, listOfOriginalDrivers);
//            checkMatureDriverDiscount(listOfDriversEligibleMatureSafetyCourse, false, sa);
//        }
    }

    // filter driver list by age for mature driver safety course date validation
    public List<Driver> filterDriverListByAge(int age, List<Driver> listOfOriginalDrivers){
        List<Driver> filteredDriverListBasedOnAge = listOfOriginalDrivers.stream().filter(i -> i.getAge() >= age).collect(Collectors.toList());
        return filteredDriverListBasedOnAge;
    }

    // Validate content, errors and format for mature driver safety course
    public void checkMatureDriverDiscount(List<Driver> listOfDriversEligibleMatureSafetyCourse, boolean isMatureSafetyCourseDateMandatory, FarmersSoftAssert fsa) throws Exception {
        List<Driver> listOfDriversWithoutMatureSafetyCourse = listOfDriversEligibleMatureSafetyCourse.stream().filter(i -> i.getSafetyCourseCompleted().equals("N")).collect(Collectors.toList());
        List<Driver> listOfDriversWithMatureSafetyCourse = listOfDriversEligibleMatureSafetyCourse.stream().filter(i -> i.getSafetyCourseCompleted().equals("Y")).collect(Collectors.toList());

        // Mdd input fields/toggle buttons/labels/Hits validation on initial load
        fsa.assertEquals(disabledMatureSafetyCourseToggleButton.count(), listOfDriversWithoutMatureSafetyCourse.size(), "Disabled mature driver safety toggle buttons are not matching.");
        fsa.assertEquals(enabledMatureSafetyCourseToggleButton.count(), listOfDriversWithMatureSafetyCourse.size(),"Enabled mature driver safety toggle buttons are not matching.");
        fsa.assertEquals(mddSafetyCourseDateInputBox.count(), listOfDriversWithMatureSafetyCourse.size(),"Mdd safety course date input box are not matching.");
        if(!isMatureSafetyCourseDateMandatory){
            fsa.assertEquals(mddSafetyCourseDateIDoNotKnowCheckbox.count(), listOfDriversWithMatureSafetyCourse.size(),"Mdd safety course date check box are not matching.");
            fsa.assertEquals(mddSafetyCourseDateIDoNotKnowLabel.count(), listOfDriversWithMatureSafetyCourse.size(), "Mdd safety course date I do not know labels are not matching.");
            fsa.assertEquals(provideCompletionDateOrCheckCheckboxHint.count(), listOfDriversWithMatureSafetyCourse.size(),"Provide completion date or check checkbox hints are not matching.");
        }else{
            fsa.assertEquals(provideCompletionDateOrToggleOffHint.count(), listOfDriversWithMatureSafetyCourse.size(),"Provide completion date or toggle off hints are not matching.");
            fsa.assertEquals(mddSafetyCourseDateInputBox.count(), listOfDriversWithMatureSafetyCourse.size(),"Mdd safety course date input box are not matching.");
        }

        // enable all the MDD toggle button for validations
        disabledMatureSafetyCourseToggleButton.all().forEach(i -> waitAndClickElement(i));
        String todayDateInMMYYYY = todayDateInMMYYYY();

        if(isMatureSafetyCourseDateMandatory){
            // validate if mdd input fields are matching after enabling all the fields
            fsa.assertEquals(mddSafetyCourseDateInputBox.count(), listOfDriversEligibleMatureSafetyCourse.size(),"Mdd safety course date input box are not matching.");

            // click continue to payment button in order to validate errors for mdd
            AdditionalInfoContinueToPaymentOneUI additionalInfoContinueToPaymentOneUI = new AdditionalInfoContinueToPaymentOneUI();
            additionalInfoContinueToPaymentOneUI.clickContinueToPaymentButton();

            // Validate mdd date range error
            fsa.assertEquals(mddSafetyCourseDateRangeError.count(), listOfDriversEligibleMatureSafetyCourse.size(),"Mdd date range errors are not matching");

            // Validate mdd date range error contains valid range
            String mddDateRange = mddValidRange();
            fsa.assertEquals(mddSafetyCourseDateRangeError.all().stream().filter(i -> getTextFromElement(i).contains(mddDateRange)).collect(Collectors.toList()).size(), listOfDriversEligibleMatureSafetyCourse.size(),
                    "Mdd date range errors do not contains valid date range "+ mddDateRange);
            // Enter valid date in mdd input box
            mddSafetyCourseDateInputBox.all().forEach(i -> sendKeysOneByOne(i, todayDateInMMYYYY));
        }else{
            // Add valid mdd dates and  Clear out input box, validate date format mm/yyyy error
            mddSafetyCourseDateInputBox.all().forEach(i -> sendKeys(i, todayDateInMMYYYY));
            mddSafetyCourseDateInputBox.all().forEach(i -> clearOutFieldUsingBackSpace(i));
            fsa.assertEquals(mddMustBeInMMYYYYFormatError.count(), listOfDriversEligibleMatureSafetyCourse.size(), "Mdd date must be mm/yyyy errors are not matching.");

            // Check I do not know checkbox in order to validate disabled and empty input box
            mddSafetyCourseDateInputBox.all().forEach(i -> sendKeys(i, todayDateInMMYYYY));
            mddSafetyCourseDateIDoNotKnowCheckbox.all().forEach(i -> waitAndClickElement(i));
            fsa.assertEquals(mddSafetyCourseDateInputBox.all().stream().filter( i -> !i.isEnabled()).collect(Collectors.toList()).size(), listOfDriversEligibleMatureSafetyCourse.size(),
                    "Mdd date input boxes are not disabled");
            fsa.assertEquals(mddSafetyCourseDateInputBox.all().stream().filter(i -> getAttributeData(i, VALUE).equals(EMPTY_STRING)).collect(Collectors.toList()).size(), listOfDriversEligibleMatureSafetyCourse.size(),
                    "Mdd date input box values are not empty");

            // Uncheck I do not know checkbox in order to validate enable input box
            mddSafetyCourseDateIDoNotKnowCheckbox.all().forEach(i -> waitAndClickElement(i));
            fsa.assertEquals(mddSafetyCourseDateInputBox.all().stream().filter( i -> i.isEnabled()).collect(Collectors.toList()).size(), listOfDriversEligibleMatureSafetyCourse.size(),
                    "Mdd date input box are not enable");

            // Enter mdd dates
            mddSafetyCourseDateInputBox.all().forEach(i -> sendKeys(i, todayDateInMMYYYY()));
        }
    }

    public String mddValidRange(){
        LocalDate startDate = LocalDate.now().plusMonths(-34);
        String endDate = todayDateInMMYYYY();
        return startDate.getMonthValue() + "/" + startDate.getYear() + " - " + endDate;
    }

    public String todayDateInMMYYYY(){
        Format f = new SimpleDateFormat("MM/yyyy");
        String endDate = f.format(new Date());
        return endDate;
    }

    // Enter only mature driver safety course date if required
    public void enterForeignDriverLicenseDetails() throws Exception {
    	int numberOfElements = countryDropDowns.count();
        for (int i =0; i< numberOfElements; i++){
            // select countries
            waitAndClickElement(countryDropDowns.nth(i));
            selectValueInDropDown(countryDropDowns.nth(i), "Turkey");
            // enter dl number
            sendKeysToElement(foreignDlInputField.nth(i), RandomStringUtils.randomNumeric(6));

            // enter license start date
            LocalDate now = LocalDate.now();
            sendKeysToElement(fdlStartDateInputFields.nth(i), "0101" + now.getYear());

        }
    }

    // Enter foreign country dl details
    public void enterMatureDriverSafetyCourseDate(String landingStateCode){
        if(isMatureDriverSafetyCourseMandatory(landingStateCode)){
            disabledMatureSafetyCourseToggleButton.all().forEach(i -> waitAndClickElement(i));
            String todayDateInMMYYYY = todayDateInMMYYYY();
            waitForUiSettled();
            mddSafetyCourseDateInputBox.all().forEach(i -> sendKeysOneByOne(i, todayDateInMMYYYY));
        }
    }

    public void fillOutDriverSection(AutoApplicant applicant) throws Exception {
        String applicantFullName = getTheFullNameWithFirstLetterInCaps(applicant.getFirstName() + SPACE + applicant.getLastName());
        String applicantDriverSectionXpath = String.format(DRIVER_SECTION_XPATH, applicantFullName);
        fillOutDriverLicenseInputField(applicant, applicantDriverSectionXpath);
    }

    public void fillOutDriverLicenseInputField(AutoApplicant applicant, String driverXpath) throws Exception {
        Locator dlInputField = locator(pwXPath(driverXpath + DRIVER_SECTION_LICENSENUMBER_INPUT_XPATH));
        scrollToElement(dlInputField);
        sendKeysToElement(dlInputField, new Faker().drivingLicense().drivingLicense(applicant.getStateCode()));
        sendKeysToElement(dlInputField, Keys.TAB);
        waitForSpinnerToBeGone();
        waitForUiSettled();
    }

    public void fillOutInvalidDriverLicenseInputField(AutoApplicant applicant) throws Exception {
        String applicantFullName = getTheFullNameWithFirstLetterInCaps(applicant.getFirstName() + SPACE + applicant.getLastName());
        String applicantDriverSectionXpath = String.format(DRIVER_SECTION_XPATH, applicantFullName);
        Locator dlInputField = locator(pwXPath(applicantDriverSectionXpath + DRIVER_SECTION_LICENSENUMBER_INPUT_XPATH));
        scrollToElement(dlInputField);
        sendKeysToElement(dlInputField, "123456ST01");
        sendKeysToElement(dlInputField, Keys.TAB);
    }

    public void fillOutSuspended_RevokedDriverLicenseInputField(AutoApplicant applicant) throws Exception {

        String applicantFullName = getTheFullNameWithFirstLetterInCaps(applicant.getFirstName() + SPACE + applicant.getLastName());
        String applicantDriverSectionXpath = String.format(DRIVER_SECTION_XPATH, applicantFullName);
        List<Locator> dlInputFields = locators(pwXPath(applicantDriverSectionXpath + DRIVER_SECTION_LICENSENUMBER_INPUT_XPATH));
        Locator dlInputField = null;
        if(dlInputFields.isEmpty()) {
            return;
        } else {
            dlInputField = dlInputFields.get(0);
            scrollToElement(dlInputField);
        }
        //Sending Suspended and Revoked Drivers License for below states to get Reverse-brightlined
        String dlNumber = "";
        switch(applicant.getStateCode()){
            case IL :
                dlNumber = "E53692369305";
                break;
            case NM :
                dlNumber = "888338159";
                break;
        }
        executeScript("arguments[0].value = '';", dlInputField);
        waitForUiSettled();
        sendKeysToElement(dlInputField, dlNumber);
        sendKeysToElement(dlInputField, Keys.TAB);
    }

    public void fillOutHealthInsuranceSection(String pipProvider, String pipPolicyNumber) throws Exception {
        if(isElementPresent(pwXPath("//div[@formarrayname='healthInsurance']"))) {
            fillOutCurrentInsuranceProvider(pipProvider);
            fillOutHealthInsurancePolicyNumber(pipPolicyNumber);
        }
    }

    private void fillOutHealthInsurancePolicyNumber(String policyNumber) throws Exception {
        Locator policyNumberInputField = locator(pwXPath("//input[@formcontrolname='healthPolicyNum']"));
        sendKeysToElement(policyNumberInputField, policyNumber);

    }

    private void fillOutCurrentInsuranceProvider(String currentInsuranceProvider) throws Exception {
        Locator currentInsuranceProviderInput = locator(pwXPath("//input[@formcontrolname='healthInsProvider']"));
        sendKeysToElement(currentInsuranceProviderInput, currentInsuranceProvider);
    }

}
