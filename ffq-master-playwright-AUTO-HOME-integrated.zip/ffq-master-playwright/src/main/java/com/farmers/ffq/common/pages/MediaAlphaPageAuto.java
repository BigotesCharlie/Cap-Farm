package com.farmers.ffq.common.pages;





import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.datatransferobjects.SqlIncident;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCNavigationHelperBasePage.DID_NOT_REACH;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class MediaAlphaPageAuto extends AutoBasePage {
    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public MediaAlphaPageAuto() throws Exception {
    }

    public boolean isOnMediaAlphaPageAuto() {
        return isElementVisible(carYear, Property.PAGELOADTIMEOUT);
    }

    private static final String CAR_YEAR_XPATH = "//table[@id='home-panel-content']//div[@id='car-panel' and contains(.,'model year')]//a";
    private static final String CAR_MAKE_XPATH = "//table[@id='home-panel-content']//div[@id='car-panel' and contains(.,'make')]//a";
    private static final String CAR_MODEL_XPATH = "//table[@id='home-panel-content']//div[@id='car-panel' and contains(.,'model')]//a";
    private static final String CAR_SUBMODEL_XPATH = "//table[@id='home-panel-content']//div[@id='car-panel' and contains(.,'submodel')]//a[contains(@onclick,'update')]";

        private Locator carYear = locator(pwXPath("//table[@id='home-panel-content']//div[@id='car']"));

        private Locator checkBoxAlarm = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-alarm']"));

        private Locator radioPrimaryUseWork = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-primary-use-work']"));
        private Locator radioPrimaryUsePleasure = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-primary-use-pleasure']"));

        private Locator selectAverageMileage = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-average-mileage']"));
        private Locator selectAnnualMileage = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-annual-mileage']"));

        private Locator selectDeductibleCollision = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-collision']"));
        private Locator selectDeductibleComprehensive = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-comprehensive']"));

        private Locator buttonSaveCar = locator(pwXPath("//table[@id='home-panel-content']//button[@id='save-car']"));

        private Locator buttonAddCar = locator(pwXPath("//table[@id='home-panel-content']//button[@id='add-car']"));

        private Locator radioCarLeasedYes = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-car-leased-1']"));
        private Locator radioCarLeasedNo = locator(pwXPath("//table[@id='home-panel-content']//input[@id=''f-car-leased-0']"));

        private Locator streetAddress = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-address']"));

        private Locator aptUnit = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-address2']"));

        private Locator selectHowLongLivedThere = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-home-length']"));

        private Locator cityStateZip = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-city2']"));

        private Locator radioOwnedYes = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-type-own']"));

        private Locator radioOwnedNo = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-type-rent']"));

        private Locator radioGarageYes = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-garage-yes']"));

        private Locator radioGarageNo = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-garage-no']"));

        private Locator goToStep2Button = locator(pwXPath("//table[@id='home-panel-content']//button[contains(.,'go to step 2')]"));

        private Locator goToStep3Button = locator(pwXPath("//table[@id='home-panel-content']//button[contains(.,'go to step 3')]"));

        private Locator almostDoneButton = locator(pwXPath("//table[@id='home-panel-content']//button[contains(.,'almost done!')]"));

        private Locator lastStepButton = locator(pwXPath("//table[@id='home-panel-content']//button[contains(.,'last step')]"));

        private Locator currentlyInsuredCheckbox = locator(pwXPath("//table[@id='home-panel-content']//input[@name='currently_insured']"));

        private Locator goToLastStepButton = locator(pwXPath("//table[@id='home-panel-content']//button[contains(.,'Go to Last Step')]"));

        private Locator yourQuotesButton = locator(pwXPath("//table[@id='home-panel-content']//button[contains(.,'Get Your Quotes')]"));

        private Locator spouseDropDown = locator(pwXPath("//li[@id='add-spouse']"));

       private Locator childDropDown = locator(pwXPath("//li[contains(@onclick,'child')]"));

        private Locator otherDropDown = locator(pwXPath("//li[contains(@onclick,'other')]"));

        private Locator driverName = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-driver-name']"));

        private Locator selectDriverGender = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-gender']"));

        private Locator radioMarriedYes = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-married-yes']"));

        private Locator radioMarriedNo = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-married-no']"));

        private Locator birthday = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-birthday']"));

        private Locator selectFirstLicensed = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-first-licensed']"));

        private Locator selectEducationLevel = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-education']"));

        private Locator selectPrimaryCar = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-primary-car']"));

        private Locator selectCreditRating = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-credit-rating']"));

        private Locator selectOccupation = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-occupation']"));

        private Locator selectOccupationOptions = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-occupation']//option"));

        private Locator radioLicenseActive = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-license-active']"));

        private Locator radioLicenseSuspended = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-license-suspended']"));

        private Locator radioFileSR22Yes = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-sr-22-yes']"));

        private Locator radioFileSR22No = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-sr-22-no']"));

        private Locator viewMyQuoteButton = locator(pwXPath("//button[@data-cb-id='button_cta' and contains(.,'View My Quote')]"));

        private Locator email = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-email']"));

        private Locator phone = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-phone']"));

        private Locator saveDriverButton = locator(pwXPath("//table[@id='home-panel-content']//button[@id='save-driver']"));

        private Locator addDriverButton = locator(pwXPath("//table[@id='home-panel-content']//button[@id='add-driver']"));

        private Locator currentInsuranceCompany = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-current-company']"));

        private Locator continuosCoverage = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-continuous-coverage']"));

        private Locator currentCustomer = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-current-customer']"));

        private Locator currentPolicyExpires = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-current-policy-expires']"));

        private Locator radioMinimumCoverage = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-coverage-minimum']"));

        private Locator radioStandardCoverage = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-coverage-standard']"));

        private Locator radioPremiumCoverage = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-coverage-super']"));

        private Locator incidentType = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-incident-type']"));

        private Locator incidentDriver = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-incident-driver']"));

        private Locator incidentDate = locator(pwXPath("//table[@id='home-panel-content']//input[@id='f-incident-date']"));

        private Locator ticketType = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-ticket-type']"));

        private Locator incidentDescription = locator(pwXPath("//table[@id='home-panel-content']//select[@id='f-incident-description']"));

        private Locator incidentButtonAdd = locator(pwXPath("//table[@id='home-panel-content']//button[@id='add-incident']"));

        private Locator accidentButtonYes = locator(pwXPath("//table[@id='home-panel-content']//button[contains(.,'Yes')]"));

        private Locator accidentButtonNo = locator(pwXPath("//table[@id='home-panel-content']//button[contains(.,'No')]"));

        private Locator redirectButton = locator(pwXPath("//button[@id='redirect-btn'][1]"));

        private Locator proceedToFarmersButton = locator(pwXPath("//button[contains(@class,'mainForm__button')]"));


    private void selectCarYear(String year) throws Exception {
        wait.until(Conditions.visibilityOfAllElementsLocatedBy(pwXPath(CAR_YEAR_XPATH)));
        Locator carAttributeWe = locator(pwXPath(CAR_YEAR_XPATH + "[text()='" + year + "']"));
        waitAndClickElement(carAttributeWe);
        Log.info("Selected car year: " + year);
    }

    private void selectCarMake(String make) throws Exception {
        String carMakeXpath = CAR_MAKE_XPATH + "[text()='" + make + "']";
        wait.until(Conditions.visibilityOfAllElementsLocatedBy(pwXPath(carMakeXpath)));
        List<Locator> makes = locators(pwXPath(carMakeXpath));
        if(makes.isEmpty()) {
            // if make is not available, randomly select
            makes = locators(pwXPath(CAR_MAKE_XPATH));
            Collections.shuffle(makes);
        }
        Locator firstMake = makes.get(0);
        make = getTextFromElement(firstMake);
        waitAndClickElement(firstMake);
        Log.info("Selected car make: " + make);
    }

    private void selectCarModel(String model) throws Exception {
        String carModelXpath = CAR_MODEL_XPATH + "[text()='" + model + "']";
        wait.until(Conditions.visibilityOfAllElementsLocatedBy(pwXPath(carModelXpath)));
        List<Locator> models = locators(pwXPath(carModelXpath));
        if(models.isEmpty()) {
            // if specific model is not present, randomly select model
            models = locators(pwXPath(CAR_MODEL_XPATH));
            Collections.shuffle(models);
        }
        Locator firstModel = models.get(0);
        model = getTextFromElement(firstModel);
        waitAndClickElement(firstModel);
        Log.info("Selected car model: " + model);
    }

    private void selectCarSubModel(String subModel) throws Exception {
        String carSubModelXpath = CAR_SUBMODEL_XPATH + "[contains(text(),'" + subModel + "')]";
        wait.until(Conditions.visibilityOfAllElementsLocatedBy(pwXPath(carSubModelXpath)));

        List<Locator> subModels = locators(pwXPath(carSubModelXpath));
        if(subModels.isEmpty()) {
            // if provided submodel is not there, randomly select
            subModels = locators(pwXPath(CAR_SUBMODEL_XPATH));
            subModels.removeIf(each -> getTextFromElement(each).contains("NOT SURE"));
            Collections.shuffle(subModels);
        }
        waitAndClickElement(subModels.get(0));
        Log.info("Selected car submodel: " + getTextFromElement(subModels.get(0)));
    }

    private void selectCarPrimaryUse(String primaryUse) {
        if (primaryUse.equals("Personal")) {
            waitAndClickElement(radioPrimaryUsePleasure);
        } else {
            waitAndClickElement(radioPrimaryUseWork);
        }
        Log.info("Selected car primary use: " + primaryUse);
    }

    private void selectCarLeased(String lessor) {
        if (lessor.isBlank()) {
            waitAndClickElement(radioCarLeasedNo);
        } else {
            waitAndClickElement(radioCarLeasedYes);
        }
        Log.info("Selected car leased: " + (lessor.isBlank() ? "No" : "Yes"));
    }

    private void enterAddress(String address) {
        sendKeysToElement(streetAddress, address);
        Log.info("Entered street address: " + address);
    }

    private void clickGoToStep2Button() {
        scrollElementToMiddle(goToStep2Button);
        waitAndClickElement(goToStep2Button);
    }

    private void clickGoToStep3Button() {
        scrollElementToMiddle(goToStep3Button);
        waitAndClickElement(goToStep3Button);
    }

    private void clickAlmostDoneButton() {
        scrollElementToMiddle(almostDoneButton);
        waitAndClickElement(almostDoneButton);
    }

    private void clickLastStepButton() {
        waitAndClickElement(lastStepButton);
    }

    private void clickGetYourQuotesButton() {
        scrollElementToMiddle(yourQuotesButton);
        waitAndClickElement(yourQuotesButton);
    }

    private void clickViewMyQuoteButton() {
        if (isElementVisible(viewMyQuoteButton, 15)) {
            scrollAndClickOnElement(viewMyQuoteButton);
        } else {
            throw new IllegalStateException(DID_NOT_REACH + "ViewMyQuoteButton");
        }
    }

    private void clickRedirectButton() {
        waitAndClickElement(redirectButton);
    }

    private void enterMaritalStatus(String status) {
        if(!isElementVisible(radioMarriedYes, 1)) {
            return;
        }
        if (status.equalsIgnoreCase("married")) {
            waitAndClickElement(radioMarriedYes);
        } else {
            waitAndClickElement(radioMarriedNo);
        }
    }

    private void enterBirthday(String birthday) {
        waitAndClickElement(this.birthday);
        sendKeysToElementWithoutClearingField(this.birthday, birthday);
    }

    private void enterEmail(String email) {
        waitAndClickElement(this.email);
        sendKeysOneByOne(this.email, email);
        Log.info("Entered email: " + email);
    }

    private void enterPhone(String phone) {
        waitAndClickElement(this.phone);
        sendKeysToElementWithoutClearingField(this.phone, phone);
        Log.info("Entered phone number: " + phone);
    }

    private void enterVehicleData(AutoApplicant applicant) throws Exception {
        int vehicles = applicant.getVehicles().size();
        for (int i=0; i < vehicles; i++) {
            waitForUiSettled();
            selectCarYear(applicant.getVehicles().get(i).getVehicleYear());
            selectCarMake(applicant.getVehicles().get(i).getVehicleMake());
            selectCarModel(applicant.getVehicles().get(i).getVehicleModel().split(SPACE)[0]);
            waitForUiSettled();
            if (locators(pwXPath(CAR_SUBMODEL_XPATH)).size() > 1) {
                selectCarSubModel(applicant.getVehicles().get(i).getVehicleModel().replaceAll("[^0-9]", EMPTY_STRING));
            }
            selectCarPrimaryUse(applicant.getVehicles().get(i).getVehicleUsage());
            selectCarLeased(applicant.getVehicles().get(i).getLessor());
            waitAndClickElement(buttonSaveCar);
            if ((i+1) < vehicles) {
                waitAndClickElement(buttonAddCar);
            }
        }
    }

    private void enterDriverName(String name) {
        scrollElementToMiddle(driverName);
        waitAndClickElement(driverName);
        sendKeysToElement(driverName, name);
        Log.info("Entered driver name: " + name);
    }

    private void enterDriverGender(String gender) {
        waitElementBeVisible(selectDriverGender);
        selectVisibleTextInDropDown(selectDriverGender, gender);
        Log.info("Driver gender is selected as : " + gender);
    }

    private void enterFirstLicensed(String year) {
        waitElementBeVisible(selectFirstLicensed);
        selectVisibleTextInDropDown(selectFirstLicensed, year);
        Log.info("Entered first licensed year: " + year);
    }

    private void selectPrimaryCar(String car) {
        waitElementBeVisible(selectPrimaryCar);
        selectVisibleTextInDropDown(selectPrimaryCar, car);
    }

    private void selectOccupation(String occupation) {
        waitElementBeVisible(selectOccupation);
        List<String> listOfOccupations = selectOccupationOptions.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        if(listOfOccupations.contains(occupation)) {
            selectVisibleTextInDropDown(selectOccupation, occupation);
        }
        Log.info("Selected occupation: " + occupation);
    }

    private void enterCurrentCompanyName(String company) {
        waitAndClickElement(currentInsuranceCompany);
        sendKeysToElement(currentInsuranceCompany, company);
    }

    private void selectContinuousCoverage(AutoApplicant applicant) {
        waitElementBeVisible(continuosCoverage);
        int age = applicant.getAge();
        String valueToSelect;
        switch(age) {
            case  16: case 17: case 18:
                valueToSelect = "1 year";
                break;
            case 19: case 20: case 21:
                valueToSelect = "3 years";
                break;
            case 22: case 23: case 24:
                valueToSelect = "5 to 10 years";
                break;
            default:
                valueToSelect = "Over 10 years";
        }
        selectVisibleTextInDropDown(continuosCoverage, valueToSelect);
        Log.info("Selected continuous coverage as: " + valueToSelect);
    }

    private void selectCurrentCustomer(String years) {
        waitElementBeVisible(currentCustomer);
        if(years.equals("< 6 Months")) {
            years = "Less than 6 months";
        }
        selectVisibleTextInDropDown(currentCustomer, years);
        Log.info("Selected current customer: " + years);
    }

    private void selectTicketType(String ticketType) {
        wait.until(Conditions.visible(incidentType));
        selectVisibleTextInDropDown(incidentType, ticketType);
            Log.info("Selected ticket type: " + ticketType);
    }

    private void selectIncidentDriver(String driver) {
        waitElementBeVisible(incidentDriver);
        selectVisibleTextInDropDown(incidentType, driver);
    }

    private void enterIncidentDate(String date) {
        waitAndClickElement(incidentDate);
        sendKeysToElement(incidentDate, date);
    }

    private void clickAccidentButtonYes() {
        wait.until(Conditions.visible(accidentButtonYes));
        waitAndClickElement(accidentButtonYes);
    }

    private void clickAccidentButtonNo() {
        waitForUiSettled();
        clickElement(accidentButtonNo);
    }

    private void clickIncidentButtonAdd() {
        wait.until(Conditions.visible(incidentButtonAdd));
        waitAndClickElement(incidentButtonAdd);
    }

    private void enterPNIData(AutoApplicant applicant) {
        enterDriverName(applicant.getFirstName() + SPACE + applicant.getLastName());
        enterDriverGender(applicant.getGender());
        enterMaritalStatus(applicant.getMaritalStatus());
        enterBirthday(applicant.getDateOfBirth());
        enterFirstLicensed(String.valueOf(applicant.getFirstAgeUnitedStatesDriverLicense()));
//        selectPrimaryCar(applicant.getVehicles().get(0).getVehicleYear() + SPACE +
//                applicant.getVehicles().get(0).getVehicleMake() + SPACE + applicant.getVehicles().get(0).getVehicleModel());
        selectOccupation(applicant.getOccupation());
        scrollElementToMiddle(saveDriverButton);
        waitAndClickElement(saveDriverButton);
    }

    private void enterDriversData(SqlAdditionalDriver driver) {
        selectRelationToPNI(driver);
        enterDriverName(driver.getFirstName() + SPACE + driver.getLastName());
        enterDriverGender(driver.getGender());
        enterMaritalStatus(driver.getMaritalStatus());
        enterBirthday(driver.getDateOfBirth());
        enterFirstLicensed(String.valueOf(driver.getFirstAgeUnitedStatesDriverLicense()));
//        selectPrimaryCar(applicant.getVehicles().get(0).getVehicleYear() + SPACE +
//                applicant.getVehicles().get(0).getVehicleMake() + SPACE + applicant.getVehicles().get(0).getVehicleModel());
        selectOccupation(driver.getOccupation());
        scrollElementToMiddle(saveDriverButton);
        waitAndClickElement(saveDriverButton);
    }

    private void selectRelationToPNI(SqlAdditionalDriver driver) {
        String relationshipToApplicant = driver.getRelationshipToApplicant();
        switch (relationshipToApplicant) {
            case "Son": case "Daughter":
                waitAndClickElement(childDropDown);
                break;
            case SPOUSE:
                waitAndClickElement(spouseDropDown);
                break;
            default:
                waitAndClickElement(otherDropDown);
        }
    }

    private void enterCurrentCompanyData(AutoApplicant applicant) {
        if(applicant.getCurrentlyInsuredStatus().equals(NEVER_INSURED)) {
            clickElement(currentlyInsuredCheckbox);
            return;
        }
        enterCurrentCompanyName(applicant.getCurrentInsuranceCompany());
        selectContinuousCoverage(applicant);
        selectCurrentCustomer(applicant.getContinuosInsurancePeriod());
    }

    private void enterIncidentsData(AutoApplicant applicant) {
        int numIncidents = applicant.getIncidents().size();
        for (int i = 0; i < numIncidents; i++) {
            SqlIncident incident = applicant.getIncidents().get(i);
            selectTicketType(incident.getIncidentType());
//            selectIncidentDriver(incident.getApplicantId());



            if (i < (numIncidents + 1)) {
                clickIncidentButtonAdd();
            }
        }

    }

    public void enterAutoApplicantData(AutoApplicant applicant) throws Exception {
        enterVehicleData(applicant);
        clickGoToStep2Button();

        enterPNIData(applicant);

        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        for (int i = 0; i < additionalDrivers.size(); i++) {
            scrollElementToMiddle(addDriverButton);
            waitAndClickElement(addDriverButton);
            enterDriversData(additionalDrivers.get(i));
        }
        clickGoToStep3Button();
        enterCurrentCompanyData(applicant);
        clickAlmostDoneButton();
        if (applicant.getIncidents().isEmpty()) {
            clickAccidentButtonNo();
        } else {
            clickAccidentButtonYes();
            enterIncidentsData(applicant);
            clickLastStepButton();
        }

        enterEmail(applicant.getEmail());
        enterPhone(applicant.getPhoneNumber());
        enterAddress(applicant.getResidentAddress());
        clickGetYourQuotesButton();

        clickViewMyQuoteButton();
        switchToNewTab(2);
        clickRedirectButton();

        if(isElementVisible(proceedToFarmersButton, 60)) {
            waitAndClickElement(proceedToFarmersButton);
            clickRedirectButton();
        }
    }

}
