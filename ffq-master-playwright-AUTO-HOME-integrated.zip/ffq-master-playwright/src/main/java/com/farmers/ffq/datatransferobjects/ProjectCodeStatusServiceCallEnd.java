package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonIgnoreProperties
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ProjectCodeStatusServiceCallEnd {

    @JsonProperty("CommonProjectCodeStatusResponseBean")
    private CommonProjectCodeStatusResponseBean commonProjectCodeStatusResponseBean;

    @JsonIgnoreProperties
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class CommonProjectCodeStatusResponseBean {
        @JsonProperty("auto")
        private Auto auto;
        @JsonIgnoreProperties
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class Auto {
            @JsonProperty("isVehiclesDriversConsolidationImpl")
            private boolean vehiclesDriversConsolidationImpl;
        }
    }

}
