package com.farmers.ffq.ace.life;



import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.datatransferobjects.ApplicantLife;
import com.farmers.ffq.utils.FarmersSoftAssert;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceLifeNameAndDOBPage extends BasePage {

		private Locator nameAndDOBPageTitle = locator(pwXPath("//h1[contains(@class, 'tui-h1')]"));

		private Locator nameAndDOBPageSubtitle = locator(pwId("personal-info_name_dob-subheading"));

		private Locator firstNameInputField = locator(pwXPath("//div[@id='formField_firstName']//input"));

		private Locator firstNameInputFieldErrorLabel = locator(pwXPath("//div[@id='formField_firstName']//mat-error"));

		private Locator lastNameInputField = locator(pwXPath("//div[@id='formField_lastName']//input"));

		private Locator lastNameInputFieldErrorLabel = locator(pwXPath("//div[@id='formField_lastName']//mat-error"));

		private Locator dobInputField = locator(pwXPath("//div[@id='formField_dateOfBirth']//input[contains(@class, 'mat-mdc-input')]"));

		private Locator dobInputFieldErrorLabel = locator(pwXPath("//div[@id='formField_dateOfBirth']//mat-error"));

		private Locator nameAndDOBPageErrorLabel = locator(pwXPath("//p[@role='alert']"));

		private Locator personalInformationUseLink = locator(pwXPath("//div[contains(@class,'personal-info__disclaimer')]//a"));

		private Locator continueButton = locator(pwXPath("//button[contains(@class, 'address-form__continue-cta')]"));

		private Locator nameAndDOBPageImage = locator(pwXPath("//div[contains(@class, 'home-group-image-container')]/img"));

	public AceLifeNameAndDOBPage() throws Exception {
		super();
	}

	public boolean isOnNameAndDOBPage() {
		return isElementVisible(firstNameInputField, 3);
	}

	public void errorMessageValidation(FarmersSoftAssert fsa) {
		final String VALID_SPECIAL_CHARS = " '-.,";
		//Assumption is we have a clean page already loaded
		clickOnContinueButton();
		waitElementBeVisible(nameAndDOBPageErrorLabel);
		//Default no entry messages
		fsa.assertEquals(getTextFromElement(firstNameInputFieldErrorLabel), "Please provide your first name.", "firstNameInputFieldErrorLabel no entry check");
		fsa.assertEquals(getTextFromElement(lastNameInputFieldErrorLabel), "Please provide your last name.", "lastNameInputFieldErrorLabel no entry check");
		fsa.assertEquals(getTextFromElement(dobInputFieldErrorLabel), "Please provide your date of birth (mm/dd/yyyy).", "dobInputFieldErrorLabel no entry check");
		fsa.assertEquals(getTextFromElement(nameAndDOBPageErrorLabel), "One or more required fields are incomplete or incorrect. Please review.", "nameAndDOBPageErrorLabel no entry check");
		//Incomplete data errors
		enterValueInField(SPECIALCHARS_DIGITS, firstNameInputField, "Invalid data in First Name field");
		enterValueInField(SPECIALCHARS_DIGITS, lastNameInputField, "Invalid data in Last Name field");
		enterValueInField("4", dobInputField, "Invalid data in Date of Birth field");
		clickOnContinueButton();
		fsa.assertEquals(getTextFromElement(firstNameInputFieldErrorLabel), "Invalid first name", "firstNameInputFieldErrorLabel invalid data check");
		fsa.assertEquals(getTextFromElement(lastNameInputFieldErrorLabel), "Invalid last name", "lastNameInputFieldErrorLabel invalid data check");
		fsa.assertEquals(getTextFromElement(dobInputFieldErrorLabel), "Date of Birth is not a valid entry.", "dobInputFieldErrorLabel invalid data check");
		fsa.assertEquals(getTextFromElement(nameAndDOBPageErrorLabel), "One or more required fields are incomplete or incorrect. Please review.", "nameAndDOBPageErrorLabel invalid data check");
		//Check for invalid data on fields
		fsa.assertEquals(getValueFromLocator(firstNameInputField), VALID_SPECIAL_CHARS, "First name field should allow special characters [" +  VALID_SPECIAL_CHARS + "]");
		fsa.assertEquals(getValueFromLocator(lastNameInputField), VALID_SPECIAL_CHARS, "Last name field should allow special characters [" +  VALID_SPECIAL_CHARS + "]");
		enterValueInField(INVALID_DOB, dobInputField, "Invalid date of birth");
		fsa.assertEquals(getTextFromElement(dobInputFieldErrorLabel), "Invalid date of birth", "dobInputFieldErrorLabel invalid DOB check");
		enterValueInField(calculateDateOfBirthFromAge(17), dobInputField, "Invalid date of birth - Too young");
		fsa.assertEquals(getTextFromElement(dobInputFieldErrorLabel), "We're sorry, online quotes for this policy type are only available for applicants between the ages of 18-75. For more options, please contact your Farmers agent, or call 800-327-6377.", "dobInputFieldErrorLabel applicant too young check");
		enterValueInField(calculateDateOfBirthFromAge(50), dobInputField, "Set to valid DOB");
		enterValueInField(calculateDateOfBirthFromAge(76), dobInputField, "Invalid date of birth - Too old");
		fsa.assertEquals(getTextFromElement(dobInputFieldErrorLabel), "We're sorry, online quotes for this policy type are only available for applicants between the ages of 18-75. For more options, please contact your Farmers agent, or call 800-327-6377.", "dobInputFieldErrorLabel applicant too old check");
		clickOnContinueButton();
	}

	public void contentValidation(FarmersSoftAssert fsa) throws Exception {
		fsa.assertEquals(getTextFromElement(nameAndDOBPageTitle), "We invite you to get a quote", "Name and DOB page title label");
		fsa.assertEquals(getTextFromElement(nameAndDOBPageSubtitle), "Get started with just a few details.", "Name and DOB page subtitle label");
		fsa.assertEquals(getTextFromElement(personalInformationUseLink), "Personal information use", "Personal information use link label");
		fsa.assertEquals(getTextFromElement(continueButton), "Continue", "Continue button  label");
		String imageSourceValue = getAttributeData(nameAndDOBPageImage, SRC);
		fsa.assertTrue(imageSourceValue!= null && imageSourceValue.contains("life-rebrand.png"), "life-rebrand.png image used in page");
	}

	public void clickOnContinueButton() {
		scrollAndClickOnElement(continueButton);
	}

	public void enterDataAndContinueToPersonalInfoPage(ApplicantLife applicant) {
		waitAndClickElement(firstNameInputField);
		enterValueInField(applicant.getFirstName(), firstNameInputField, "Enter First Name:");
		enterValueInField(applicant.getLastName(), lastNameInputField, "Enter Last Name:");
		enterValueInField(calculateDateOfBirthFromAge(applicant.getAge()), dobInputField, "Date of Birth:");
		clickOnContinueButton();
	}

	public void saveQuoteForLater(ApplicantLife applicant) throws Exception {
		saveLifeApplicantInHashMap(applicant, getClass().getSimpleName(), getSessionStorageAppStore().getData().getQuoteNumber());
	}

	public void testQuoteRetrieval(ApplicantLife applicant, FarmersSoftAssert fsa) throws Exception {
		//For now retrieval only works for completed quotes, if that changes then enter the data
		fsa.assertTrue(new KnockoutInconveniencePage().isUnableToCompleteOnlineQuoteKnockOutPage(), "Unable to complete online quote page displayed");
		//fsa.assertTrue(isOnNameAndDOBPage(), "Returned to Name and DOB Page");
		//enterDataAndContinueToPersonalInfoPage(applicant);
	}

	public void verifyFieldsAreSetAndDisabled(ApplicantLife applicant, FarmersSoftAssert fsa) {
		fsa.assertEquals(getValueFromLocator(firstNameInputField), applicant.getFirstName(), "First name field content verification");
		fsa.assertTrue(isAttributePresent(firstNameInputField, DISABLED), "First name field is disabled");
		fsa.assertEquals(getValueFromLocator(lastNameInputField), applicant.getLastName(), "Last name field content verification");
		fsa.assertTrue(isAttributePresent(lastNameInputField, DISABLED), "Last name field is disabled");
		fsa.assertEquals(getValueFromLocator(dobInputField), calculateDateOfBirthFromAge(applicant.getAge()), "Date of birth field content verification");
		fsa.assertTrue(isAttributePresent(dobInputField, DISABLED), "Date of birth field is disabled");
	}
}
