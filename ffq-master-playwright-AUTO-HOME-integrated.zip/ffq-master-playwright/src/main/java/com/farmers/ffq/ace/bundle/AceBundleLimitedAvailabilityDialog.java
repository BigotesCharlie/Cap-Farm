package com.farmers.ffq.ace.bundle;





import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.utils.FarmersSoftAssert;

import static com.farmers.ffq.utils.GlobalVariables.NO_THANK_YOU;
import static com.farmers.ffq.utils.GlobalVariables.SPACE;
import static com.farmers.ffq.utils.GlobalVariables.YES_CONTINUE;

public class AceBundleLimitedAvailabilityDialog extends BasePage {
	private static final String DIALOG_TITLE_VERIFICATION = "Dialog title verification";
	private static final String DIALOG_TEXT_CONTENT_VERIFICATION = "Dialog text content verification";
	private static final String CONTINUE_BUTTON_LABEL_VERIFICATION = "Continue button label verification";
	private static final String NO_THANKS_LINK_LABEL_VERIFICATION = "No thanks link label verification";

		private Locator dialogTitle = locator(pwXPath("//*[contains(@class, 'monoline_popup_heading')]"));

		private Locator dialogTextContent = locator(pwId("monolineContent"));

		private Locator selectOnePolicyLabel = locator(pwXPath("//div[@class='font-weight-bold']"));

		private Locator autoPolicyRadioButton = locator(pwXPath("//mat-radio-button[@value = 'auto']"));

		private Locator hrcPolicyRadioButton = locator(pwXPath("//mat-radio-button[not(@value)]"));

		private Locator neitherRadioButton = locator(pwXPath("//mat-radio-button[@value = 'cancel']"));

		private Locator speakToRepresentativeLabel = locator(pwXPath("//mat-radio-group//p"));

		private Locator continueButton = locator(pwXPath("//button[text()='Continue']"));

		private Locator yesContinueButton = locator(pwXPath("//div[contains(@class, 'monoline-popup-continue-button')]//button"));

		private Locator noThankYouLink = locator(pwXPath("//div[contains(@class, 'monoline-popup-cancel-button')]//a"));

	public AceBundleLimitedAvailabilityDialog() throws Exception {
		super();
	}

	public void selectAutoPolicyAndContinue() {
		scrollAndClickOnElement(autoPolicyRadioButton);
		clickElement(continueButton);
		waitForSpinnerToBeGone();
	}

	public void selectHRCPolicyAndContinue() {
		scrollAndClickOnElement(hrcPolicyRadioButton);
		clickElement(continueButton);
		waitForSpinnerToBeGone();
	}

	public void selectNeitherAndContinue() {
		scrollAndClickOnElement(neitherRadioButton);
		clickElement(continueButton);
		waitForSpinnerToBeGone();
	}

	public void selectNoThanks() {
		scrollToBottomOfPage();
		clickElement(noThankYouLink);
		waitForSpinnerToBeGone();
	}

	public void selectYesContinue() {
		scrollToBottomOfPage();
		clickElement(yesContinueButton);
		waitForSpinnerToBeGone();
	}

	public boolean isLimitedAvailabilityDialogDisplayed() {
		return isElementDisplayed(dialogTextContent, 5);
	}

	public void verifyLimitedAvailabilityDialogContentWhenBundleNotAvailable(String propertyString, FarmersSoftAssert fsa) {
		fsa.assertEquals(getTextFromElement(dialogTitle), "Choose a policy type", DIALOG_TITLE_VERIFICATION);
		fsa.assertEquals(getTextFromElement(dialogTextContent), "You can get one quote online right now, or our team is happy to help if you want to explore bundling options. " +
				"Which policy would you like to quote and purchase online?", DIALOG_TEXT_CONTENT_VERIFICATION);
		fsa.assertEquals(getTextFromElement(selectOnePolicyLabel), "Please select one:", "Radio group label verification");
		fsa.assertEquals(getTextFromElement(autoPolicyRadioButton), "Auto policy", "Auto policy radio button label verification");
		fsa.assertEquals(getTextFromElement(hrcPolicyRadioButton), propertyString + " policy", propertyString + " radio button label verification");
		fsa.assertEquals(getTextFromElement(neitherRadioButton), "Neither", "Neither radio button label verification");
		fsa.assertEquals(getTextFromElement(speakToRepresentativeLabel), "I'd prefer to speak with a representative.", "Neither radio button subtext verification");
		fsa.assertEquals(getTextFromElement(continueButton), "Continue", CONTINUE_BUTTON_LABEL_VERIFICATION);
	}

	public void verifyRestrictedLimitedAvailabilityDialogContent(String availableLOB, FarmersSoftAssert fsa) {
		fsa.assertEquals(getTextFromElement(dialogTitle), "Continue with " + availableLOB, DIALOG_TITLE_VERIFICATION);
		String article = availableLOB.equalsIgnoreCase("auto")? "an": "a";
		fsa.assertEquals(getTextFromElement(dialogTextContent), "You can get " + article + SPACE + availableLOB + " quote online right now, but we can't offer a bundle quote at this time. "
				+ "Would you like to continue getting "+ article + SPACE + availableLOB + " quote?", DIALOG_TEXT_CONTENT_VERIFICATION);
		fsa.assertEquals(getTextFromElement(yesContinueButton), YES_CONTINUE, CONTINUE_BUTTON_LABEL_VERIFICATION);
		fsa.assertEquals(getTextFromElement(noThankYouLink), NO_THANK_YOU, NO_THANKS_LINK_LABEL_VERIFICATION);
	}

	public void verifyPropertyLOBNotAvailableLimitedAvailabilityDialogContent(FarmersSoftAssert fsa) {
		fsa.assertEquals(getTextFromElement(dialogTitle), "Continue with auto?", DIALOG_TITLE_VERIFICATION);
		fsa.assertEquals(getTextFromElement(dialogTextContent), "You can get an auto quote online right now, but we can't offer a bundle quote for this property. Would you like to continue getting an auto quote?",
				DIALOG_TEXT_CONTENT_VERIFICATION);
		fsa.assertEquals(getTextFromElement(yesContinueButton), YES_CONTINUE, CONTINUE_BUTTON_LABEL_VERIFICATION);
		fsa.assertEquals(getTextFromElement(noThankYouLink), NO_THANK_YOU, NO_THANKS_LINK_LABEL_VERIFICATION);
	}

	public boolean isDefaultMonolineDialog() {
		return isElementVisible(yesContinueButton, 3);
	}
}
