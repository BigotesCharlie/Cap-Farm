package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;

public final class DwellingCoveragePage extends BaseHomePage {
    public DwellingCoveragePage(Page page) { super(page); }
    public void verifyAndContinue(VideoScenarioData d) {
        waitForBodyReady();
        waitForSpinnerToClear();

        assertHeading("Review your dwelling coverage");
        Locator amount = page.getByText("Dwelling coverage", new Page.GetByTextOptions().setExact(false));
        if (amount.count() > 0) {
            PlaywrightAssertions.assertThat(amount.first()).isVisible();
        }

        // Ensure button is enabled before clicking
        Locator btn = page.locator("button").filter(new Locator.FilterOptions().setHasText("Continue"));
        if (btn.count() == 0) btn = page.locator("button").filter(new Locator.FilterOptions().setHasText("Get my quote"));
        if (btn.count() == 0) btn = page.locator("button").filter(new Locator.FilterOptions().setHasText("See my quote"));
        if (btn.count() == 0) throw new IllegalStateException("DwellingCoverage: advance button not found on " + page.url());
        
        // Wait for button to be enabled
        btn.last().waitFor();
        if (!btn.last().isEnabled()) {
            System.out.printf("[HOME VIDEO FLOW] DWELLING_COVERAGE: Continue button found but disabled%n");
            page.waitForTimeout(2000);
        }
        
        btn.last().click();
        waitForSpinnerToClear();
        page.waitForFunction(
                "() => {" +
                        "const u = document.location.href.toLowerCase();" +
                        "const text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();" +
                        "return text.includes('home coverages')" +
                        " || text.includes('optional coverages')" +
                        " || text.includes('one moment, please')" +
                        " || text.includes('how would you like to pay')" +
                        " || text.includes('home policy payment')" +
                        " || u.includes('inconvenience') || u.includes('knockout')" +
                        " || text.includes(\"we are unable to complete your request\")" +
                        " || text.includes(\"we're sorry, we can't finish\");" +
                        "}",
                null,
                new Page.WaitForFunctionOptions().setTimeout(30_000)
        );
    }
}
