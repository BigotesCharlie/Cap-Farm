package com.farmers.ffq.auto.pages.bw;



import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.BWCSSRegistrationEnded;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import static com.farmers.ffq.utils.GlobalVariables.MA;

public class BwCongratulationsPage extends AutoBasePage {

        private Locator pageTitle = locator(pwXPath("//h1[contains(.,'Congratulations')]"));
        private Locator paymentSuccessfulBanner = locator(pwXPath("//div[contains(@class,'dpj-esign-banner') and contains(.,'Payment successful')]"));
        private Locator welcomeToFarmersTitle = locator(pwXPath("//h1[contains(.,'Welcome to Farmers')]"));

        private Locator pageSubTitle = locator(pwCss("p[class='tui-field-label-text']"));

        private Locator downloadIdCardsLink = locator(pwCss("button[id='download-id-cards']"));

        private Locator downloadPolicyDocuments = locator(pwId("download-policy-documents"));

        private Locator passwordInput = locator(pwCss("input[formcontrolname='password']"));

        private Locator createAccountButton = locator(pwCss("button[class='tui-btn tui-btn-primary']"));

        private Locator createdConfirmation = locator(pwXPath("//p[@class='text_align' and  contains(.,'created')]"));

        private Locator yourAccountCreatedConfirmation = locator(pwXPath("//p[contains(.,'Your account has been created!')]"));

        private Locator loginToMyAccountButton = locator(pwXPath("//button[contains(.,'Log in to my account')]"));

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public BwCongratulationsPage() throws Exception {
    }

    public boolean isOnBwCongratsPage() {
        return isElementVisible(pageTitle, 60)
                || isElementVisible(paymentSuccessfulBanner, 30)
                || isElementVisible(welcomeToFarmersTitle, 30);
    }

    public void validateBwCongratsPage(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        validatePageTitle(fsa, getTheFullNameWithFirstLetterInCaps(applicant.getFirstName()));
        validatePageSubTitle(fsa, applicant.getEmail());
        validateLinks(fsa);
        validateAccountCreation(fsa, applicant);
        if (!applicant.getStateCode().equals(MA)) {
            validatedDownloads(fsa);
        }
    }

    private void validatedDownloads(FarmersSoftAssert fsa) {
        waitAndClickElement(downloadIdCardsLink);
        waitAndClickElement(downloadPolicyDocuments);
    }

    private void validatePageTitle (FarmersSoftAssert fsa, String firstName) {
        fsa.assertTrue(testExpectedTextContentForElement(pageTitle, String.format("Congratulations, %s!", firstName)), "Bw Congrats page title validation");
    }

    private void validatePageSubTitle (FarmersSoftAssert fsa, String emailId) {
        fsa.assertTrue(testExpectedTextContentForElement(pageSubTitle, String.format("Thank you for insuring with Bristol West Insurance. We sent a confirmation email with your purchase details and policy information to %s.", emailId)), "Bw Congrats page sub title validation");
    }

    private void validateLinks(FarmersSoftAssert fsa) {
        fsa.assertTrue(downloadIdCardsLink.isVisible() && downloadIdCardsLink.isEnabled(), "Make sure id cards links is displayed and enabled");
        fsa.assertTrue(downloadPolicyDocuments.isVisible() && downloadPolicyDocuments.isEnabled(), "Make sure policy documents links is displayed and enabled");
    }

    private void fillOutPasswordInput(String password) {
        sendKeysOneByOne(passwordInput, password);
        Log.info(String.format("Password is entered for Congrats Page Account Creation: %s", password));
    }

    private void clickCreateAccountButton() {
        waitAndClickElement(createAccountButton);
    }

    private void validateAccountCreation(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        fillOutPasswordInput(randomPasswordGenerator());
        clickCreateAccountButton();
        fsa.assertTrue(isElementVisible(yourAccountCreatedConfirmation, 25), "Account created confirmation message validated");
        fsa.assertTrue(isElementVisible(loginToMyAccountButton, 25), "Log in button is visible validation");
        BWCSSRegistrationEnded bwcssRegisterRestServiceEnded = new ApiHelper().getBWCSSRegisterRestServiceEnded(getSessionStorageAppStore().getData().getQuoteNumber());
        fsa.assertEquals(bwcssRegisterRestServiceEnded.getResponseCode(), "-1");
       }

    public void registerUserForAnAccount() {
        fillOutPasswordInput(randomPasswordGenerator());
        clickCreateAccountButton();
        testStepAssert(getTextFromElement(waitElementBeVisible(createdConfirmation)), "Your account has been created!", "Account creation confirmed", true);
        waitForUiSettled();
        waitForSpinnerToBeGone();
    }

    public void validateNavigateBackFromBWCongratsPage(FarmersSoftAssert fsa) throws Exception {
        this.navigateBack();
        BwPaymentSummaryPage bwPaymentSummaryPage = new BwPaymentSummaryPage();
        // user should not be able to come back to payment summary page after navigating back from congrats page
        fsa.assertFalse(bwPaymentSummaryPage.isOnBwPaymentSummaryPage(), "User should navigate back to the payment page from BW Congrats page");
    }

}
