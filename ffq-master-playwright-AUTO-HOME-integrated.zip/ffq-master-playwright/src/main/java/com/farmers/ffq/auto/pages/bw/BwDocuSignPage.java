package com.farmers.ffq.auto.pages.bw;






import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.framework.report.Log;
import java.util.List;

public class BwDocuSignPage extends AutoBasePage {


        private Locator disclosureCheckbox = locator(pwXPath("//input[contains(@data-qa,'ersd-agree-checkbox')]"));

        private Locator disclosurePopUpContinueButton = locator(pwXPath("//button[@aria-describedby='continue-btn-a11y-desc']"));

        private Locator startButton = locator(pwCss("button[class='btn btn-primary autoNav-relative']"));

        private Locator startButtonAlternative = locator(pwCss("button[data-qa='auto-nav-caret']"));

        private Locator nextButton = locator(pwCss("button[data-qa='action-bar-btn-finish-mobile']"));

        private Locator initialButton = locator(pwCss("button[class='btn btn-primary autoNav-relative btn-caret-right']"));

        private Locator yellowInitials = locator(pwXPath("//button[contains(@data-qa,'initials-tab-required') and @aria-invalid='true']"));

        private Locator yellowSignature = locator(pwXPath("//div[contains(@class,'signature-tab-content')]"));

        private Locator signByRadioButton = locator(pwXPath("//input[contains(@name,'signature-style-radio-buttons')]"));

        private Locator adoptAndInitial = locator(pwCss("button[data-qa='adopt-submit']"));

        private Locator finishButton = locator(pwCss("button[id='action-bar-btn-finish']"));

        private Locator finishButtonMobile = locator(pwCss("button[id='action-bar-btn-finish-mobile']"));

        private Locator requiredFieldLeft = locator(pwXPath("//div[@data-qa='butter-bar-countdown-content' and contains(.,'required field left')]"));


    /**
     * Constructor.
     *
     * @throws Exception
     */
    public BwDocuSignPage() throws Exception {
    }

    public boolean isOnDocuSignPage() {
        return isElementVisible(disclosureCheckbox, 100);
    }

    private void agreeDisclosurePopUpAndContinue() {
        if(isElementVisible(disclosureCheckbox,3)) {
            waitAndClickElement(disclosureCheckbox);
            waitAndClickElement(disclosurePopUpContinueButton);
        }
    }

    public void signDocuments() throws Exception {
        isOnDocuSignPage();
        agreeDisclosurePopUpAndContinue();
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(nextButton);
        } else {
            if(isElementVisible(startButtonAlternative, 2)) {
                waitAndClickElement(startButtonAlternative);
            } else {
                waitAndClickElement(startButton);
            }
        }
        waitForUiSettled();
        fillOutInitials();
        fillOutSignatures();

        if(isElementVisible(requiredFieldLeft, 2)) {
            completeRemainingSignatures();
        }
        clickOnFinishButton();
        testStep("Docusign is signed", true);
    }

    private void fillOutInitials() throws Exception {
        waitForUiSettled();
        List<Locator> initials = locators(pwXPath("//button[contains(@data-qa,'initials-tab-required') and @aria-invalid='true']"));
    	int numberOfElements = initials.size();
        for (int i =0; i< numberOfElements; i++){
            scrollElementToMiddle(initials.get(i));
            waitAndClickElement(initials.get(i));
            if(i == 0) {
                fillOutAdoptYourInitial();
            }
            waitForUiSettled();
        }
        completeRemainingInitials();
    }

    private void completeRemainingInitials() throws Exception {
        //sign remaining initials
        List<Locator> stillInvalidInitials = locators(pwXPath("//div[contains(@class,'initials-tab owned signing-required has-tab-error')]//button"));
    	int numberOfElements = stillInvalidInitials.size();
        for (int i =0; i< numberOfElements; i++){
            waitAndClickElement(stillInvalidInitials.get(i));
        }
    }
    private void completeRemainingSignatures() throws Exception {
        //sign remaining signatures
        List<Locator> stillInvalidSignatures = locators(pwXPath("//div[contains(@class,'signing-required') and contains(@class,'signature') and not(contains(@class,'signed'))]"));
    	int numberOfElements = stillInvalidSignatures.size();
        for (int i =0; i< numberOfElements; i++){
            scrollElementToMiddle(stillInvalidSignatures.get(i));
            waitAndClickElement(stillInvalidSignatures.get(i));
        }
    }


    private void fillOutSignatures() throws Exception {
    	int numberOfElements = yellowSignature.count();
        for (int i =0; i < numberOfElements; i++){
            scrollElementToMiddle(yellowSignature.nth(i));
            waitAndClickElement(yellowSignature.nth(i));
        }
        if(isElementVisible(requiredFieldLeft, 2)) {
            completeRemainingSignatures();
        }
    }

    private void fillOutAdoptYourInitial() {
        if(!isElementVisible(adoptAndInitial,2)) {
            return;
        }
        if (isElementVisible(signByRadioButton,3)) {
            try {
                waitAndClickElement(signByRadioButton);
            } catch (PlaywrightException interceptedException) {
                Log.info("Element click intercepted: " + interceptedException.getMessage());
                scrollAndClickOnElement(signByRadioButton);
            }
        }
        waitAndClickElement(adoptAndInitial);
    }

    public void clickOnFinishButton() {
        if(isUseMobileViewEnabled()) {
            scrollElementToMiddle(finishButtonMobile);
            waitAndClickElement(finishButtonMobile);
    		waitElementBeInvisible(finishButtonMobile);
        } else {
            scrollElementToMiddle(finishButton);
            waitAndClickElement(finishButton);
    		waitElementBeInvisible(finishButton);
        }
        Log.info("DocuSign Finish Button clicked");
    }

}
