package com.farmers.ffq.ace.hrc.common;


import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.AgentDetails;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCThankYouBasePage extends AceHRCBasePage {
    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public AceHRCThankYouBasePage() throws Exception {
    }
        private Locator farmersLogoThankYouScreen = locator(pwXPath("//img[@alt='Farmers Insurance Logo']"));

        private Locator thankYouScreenTitle = locator(pwXPath("//app-thank-you//h1"));
        private Locator thankYouScreenSubTitle = locator(pwXPath("//app-thank-you//div[contains(@class,'thank-you__subtitle')]"));
        private Locator emailLinkDesktop = locator(pwId("emailLink"));
        private Locator emailLinkMobile = locator(pwXPath("//button[@aria-label='Email this quote']"));

        private Locator linkCloseEmailSnackBar = locator(pwXPath("//a[contains(text(),'Done')]"));

        private Locator saveInProgressFooter = locator(pwXPath("//div[contains(@class,'save-in-progress')]/p"));

        private Locator quoteNumberText = locator(pwXPath("//div[contains(@class,'save-quote')]"));

        private Locator farmersLogoFooter = locator(pwXPath("//tui-oneui-footer//div[contains(@class,'tui-oneui-footer-logo-container')]/img"));

        private Locator footerPersonalInfoUseLink = locator(pwXPath("//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_personal-information-use']"));

        private Locator footerDigitalAccessibilityLink = locator(pwXPath("//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_digital-accessibility']"));

        private Locator footerTermsOfUseLink = locator(pwXPath("//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_terms-of-use']"));

        private Locator footerPrivacyCenterLink = locator(pwXPath("//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_privacy-center']"));

        private Locator footerNoticeOfInformationPracticesLink = locator(pwXPath("//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_notice-of-information-practices']"));

        private Locator footerDoNotSellLink = locator(pwXPath("//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_do-not-sell']"));

    private static final String PRESENTMENT_CARD_PRICE_HEADER = "12-month plan starting at";
    private static final String PRESENTMENT_CARD_PRICE_HEADER_XPATH = "//app-thank-you//mat-card//div[contains(@class,'price-description')]";
        private Locator presentmentCardPriceHeader = locator(pwXPath(PRESENTMENT_CARD_PRICE_HEADER_XPATH));

    public static final String QUOTE_PRESENTMENT_DESKTOP_XPATH = "//app-thank-you//mat-card[contains(@class,'tui-quote-presentment-desktop')]";

        private Locator quotePriceOnCard = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tui-price"));

    private static final String VIEW_PAY_MONTHLY_PRICING_LINK_XPATH = "//button[text()='View monthly pricing']";
        private Locator linkViewMonthlyPricing = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + VIEW_PAY_MONTHLY_PRICING_LINK_XPATH));

    private static final String VIEW_PAY_IN_FULL_PRICING_LINK_XPATH = "//button[starts-with(text(),'View pay-in-full pricing')]";

        private Locator linkViewPayInFullPricing = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + VIEW_PAY_IN_FULL_PRICING_LINK_XPATH));

        private Locator includedCoveragesPriceOnCard = locator(pwXPath("(//tr/td[contains(@class,'coverage-prices')])[1]"));

        private Locator optionalCoveragesPriceOnCard = locator(pwXPath("(//tr/td[contains(@class,'coverage-prices')])[2]"));

        private Locator quoteDiscountsOnCard = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//mat-list-item//div"));

    private static final String THANK_YOU_HEADER = "Thank you for choosing Farmers Insurance\u00ae";

        private Locator quoteAllOtherCoveragesPriceOnCard = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[text()='All other coverages']/following-sibling::td"));
        private Locator quotePrimaryCoverageOnCard = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[starts-with(text(),'Primary coverages')]/following-sibling::td"));

    public String getPrimaryCoveragesOnCard() {
        return getTextFromElement(waitElementBeVisible(quotePrimaryCoverageOnCard));
    }

    public String getAllOtherCoveragesPriceOnCard() {
        return getTextFromElement(waitElementBeVisible(quoteAllOtherCoveragesPriceOnCard));
    }

    public boolean isOnThankYouPage() {
        return isElementVisible(thankYouScreenTitle, Property.PAGELOADTIMEOUT);
    }

    public void validateLogoHeaderAndSubHeader(FarmersSoftAssert fsa, String lobType) throws Exception {
        fsa.assertTrue(isElementInViewport(thankYouScreenTitle),  lobType + " Thank you page - " + lobType + " page title is in Viewport");
        String thankYouPageSubHeaderText;
        if(lobType.equals(CONDO) || lobType.equals(RENTERS)){
            thankYouPageSubHeaderText = "Please contact us if interested in purchasing a policy.";
        }else{
            thankYouPageSubHeaderText = "Because your home is a duplex, we need to double-check that your home's information is accurate. Please contact us if interested in purchasing a policy.";
        }
        fsa.assertEquals(getAttributeData(farmersLogoThankYouScreen, "alt"), "Farmers Insurance Logo", "Farmers logo above the page title not displayed.");
        fsa.assertEquals(getTextFromElement(thankYouScreenTitle), THANK_YOU_HEADER, "Thank you title not displayed.");
        fsa.assertEquals(getTextFromElement(thankYouScreenSubTitle), thankYouPageSubHeaderText, "Thank you screen sub title not displayed");
    }

    public void validateLogoHeaderAndSubHeaderCA(FarmersSoftAssert fsa, String agentId, String stateCode) throws Exception {
        String THANK_YOU_SUB_HEADER_AOR = "To purchase, please contact us. See your quote below. We will email you a summary shortly.";
        String THANK_YOU_SUB_HEADER_NA = "To purchase, please contact us at 1-833-259-1611. See your quote below. We will email you a summary shortly.";
        String THANK_YOU_SUB_HEADER_2 = "Please contact us if interested in purchasing a policy.";

        fsa.assertTrue(isElementInViewport(thankYouScreenTitle),  "Thank you page - page title is in Viewport");
        fsa.assertEquals(getAttributeData(farmersLogoThankYouScreen, "alt"), "Farmers Insurance Logo", "Farmers logo above the page title not displayed.");
        fsa.assertEquals(getTextFromElement(thankYouScreenTitle), THANK_YOU_HEADER, "Thank you screen title.");

        String subHeader = agentId.isBlank() && stateCode.equals(CA) ? THANK_YOU_SUB_HEADER_NA : THANK_YOU_SUB_HEADER_AOR;
        String thankYouSubTitleText = getTextFromElement(thankYouScreenSubTitle);
        Log.info("Found Thank you page sub-title: " + thankYouSubTitleText);
        fsa.assertTrue(thankYouSubTitleText.equals(subHeader) || thankYouSubTitleText.equals(THANK_YOU_SUB_HEADER_2), "Thank you screen sub-title match.");
    }

    public void validateEmailThisQuoteLink(ApplicantAceHome applicant, FarmersSoftAssert sa) throws Exception {
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(emailLinkMobile);
        } else {
            waitAndClickElement(emailLinkDesktop);
        }
        waitForPageToBeReady();
        sa.assertTrue(isSnackBarMessageDisplayed(String.format("A copy of your quote number has been emailed to %s",
                applicant.getEmailAddress())), "Thank You page - Email sent snack bar message displayed.");
        waitAndClickElement(linkCloseEmailSnackBar);
    }

    public void validateQuoteSavedText(String quoteNumber, FarmersSoftAssert sa) {
        final String EXPECTED_QUOTE_PROGRESS_SAVED = "Quote progress is saved!";
        sa.assertEquals(getTextFromElement(saveInProgressFooter), EXPECTED_QUOTE_PROGRESS_SAVED, "Property Details page - Quote progress is saved.");
        String quoteNumberDisplayed = getTextFromElement(quoteNumberText).replaceAll("\\D", EMPTY_STRING);
        sa.assertEquals(quoteNumberDisplayed, quoteNumber, "Quote number and Quote progress is saved text are displayed.");
    }

    public void validateAgentDetailAndContactMe(FarmersSoftAssert sa) throws Exception {
        AgentDetails agentDetails = new AgentDetails();
        if (agentDetails.isYourAgentLabelDisplayed()) {
            if (agentDetails.isContactMeLinkDisplayed()) {
                agentDetails.clickAgentContactMeButton();
            } else {
                sa.assertTrue(agentDetails.isAgentNamePresent(), "Agent name is displayed.");
                sa.assertTrue(agentDetails.isContactFarmersRepresentativeLinkDisplayed(), "Contact Farmers representative link displayed.");
            }
        } else {
            sa.assertTrue(agentDetails.isContactUsLinkDisplayed(), "Contact us link displayed.");
            sa.assertTrue(agentDetails.isQuestionsDisplayed(), "Questions? text is displayed.");
        }
    }

    public void validateThankYouPageLinkText(FarmersSoftAssert sa) {
        sa.assertEquals(getAttributeData(farmersLogoFooter, "alt"), "Farmers logo", "Farmers logo at footer.");
        sa.assertEquals(getTextFromElement(footerPersonalInfoUseLink), "Personal information use", "Personal information use footer link.");
        sa.assertEquals(getTextFromElement(footerDigitalAccessibilityLink), "Digital accessibility", "Digital accessibility footer link.");
        sa.assertEquals(getTextFromElement(footerTermsOfUseLink), "Terms of use", "Terms of use footer link.");
        sa.assertEquals(getTextFromElement(footerPrivacyCenterLink), "Privacy center", "Privacy center footer link.");
        sa.assertEquals(getTextFromElement(footerNoticeOfInformationPracticesLink), "Notice of information practices",
                "Notice of information practices footer link.");
        sa.assertEquals(getTextFromElement(footerDoNotSellLink), "Do not sell or share my personal information",
                "Do not sell or share my personal information footer link.");
    }

    public boolean isPresentmentCardPriceHeader() {
        return getTextFromElement(presentmentCardPriceHeader).equals(PRESENTMENT_CARD_PRICE_HEADER);
    }

    public String getQuotePriceOnCard() {
        return getTextFromElement(waitElementBeVisible(quotePriceOnCard));
    }

    public String getIncludedCoveragesPriceOnCard() {
        return getTextFromElement(waitElementBeVisible(includedCoveragesPriceOnCard));
    }

    public String getOptionalCoveragesPriceOnCard() {
        return getTextFromElement(waitElementBeVisible(optionalCoveragesPriceOnCard));
    }

    public String getDiscountsOnCard() {
        return getTextFromElement(quoteDiscountsOnCard);
    }

    public boolean isViewPayInFullPricingLink() throws Exception {
        return isElementPresent(pwXPath(VIEW_PAY_IN_FULL_PRICING_LINK_XPATH));
    }

    public boolean isViewMonthlyPricingLink() throws Exception {
        return isElementPresent(pwXPath(VIEW_PAY_MONTHLY_PRICING_LINK_XPATH));
    }

    public void clickViewPayInFullPricing() {
        waitAndClickElement(linkViewPayInFullPricing);
    }

    public void clickViewMonthlyPricing() {
        waitAndClickElement(linkViewMonthlyPricing);
    }

    public void attemptToChangeUrlOnThankYouPage(String lobType) throws Exception {
        final String THANK_YOU_PAGE_URL = "/thankyou";
        final String JAFMT_PAGE_URL = "/home/additional-info-main";
        final String REVIEW_QUOTE_PAGE_URL = "/home/review-quote";
        final String CUSTOM_COVERAGE_PAGE_URL = "/home/custom-coverage";

        Log.info(">> Reached Thank you page.");
        // Validate Thank you for choosing farmers insurance page
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        String sUrl = page().url();
        //try to navigate to JAFMT page
        sUrl = sUrl.replace(THANK_YOU_PAGE_URL, JAFMT_PAGE_URL);
        navigate(sUrl);
        waitForSpinnerToBeGone();
        fsa.assertTrue(isOnThankYouPage(), "Stayed on Thank you page after attempt to change to JAFMT page.");
        //try to navigate to Review quote page
        sUrl = sUrl.replace(JAFMT_PAGE_URL, REVIEW_QUOTE_PAGE_URL);
        navigate(sUrl);
        waitForSpinnerToBeGone();
        fsa.assertTrue(isOnThankYouPage(), "Stayed on Thank you page after attempt to change to Review quote page.");

        // Click browser back button from Thank you page stays on Thank you page
        back();
        waitForSpinnerToBeGone();
        fsa.assertTrue(isOnThankYouPage(), "Stayed on Thank you page on clicking browser back button");

        if(!lobType.equals(RENTERS)){
            //try to navigate to Dwelling coverage page
            sUrl = sUrl.replace(REVIEW_QUOTE_PAGE_URL, CUSTOM_COVERAGE_PAGE_URL);
            navigate(sUrl);
            waitForSpinnerToBeGone();
            fsa.assertTrue(isOnThankYouPage(), "Stayed on Thank you page after attempt to change to Dwelling coverage page.");
        }

        fsa.assertAll("Validated Landed on Thank you page and cannot manipulate Url to go to Bind flow.");
    }

    public void validateThankYouPage(ApplicantAceHome applicant, FarmersSoftAssert fsa, String lobType, boolean isBindDisabled) throws Exception {
        if (applicant.getStateCode().equals(CA) || isBindDisabled) {
            validateLogoHeaderAndSubHeaderCA(fsa, applicant.getAgentId(), applicant.getStateCode());
        } else {
            validateLogoHeaderAndSubHeader(fsa, lobType);
        }
        verifyQuotePresentmentCard(fsa, lobType);
        validateEmailThisQuoteLink(applicant, fsa);
        validateQuoteSavedText(applicant.getQuoteNumber(), fsa);
        validateThankYouPageLinkText(fsa);
        validateAgentDetailAndContactMe(fsa);
    }

    public void verifyQuotePresentmentCard(FarmersSoftAssert fsa, String lobType) throws Exception {
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);
        for (int i = 0; i < 2; i++) {
            AppStore appStore = getSessionStorageAppStore();
            AppStore.Home.Quote quote = appStore.getHome().getQuote();
            String selectedPackageCode = quote.getSelectedPackageCode();
            String selectedPaymentMode = quote.getSelectedPaymentMode();
            String getCoveragePriceOnCard = lobType.equals(HOME) ? getIncludedCoveragesPriceOnCard() : getPrimaryCoveragesOnCard();
            String getOptionalCoveragePriceOnCard = lobType.equals(HOME) ? getOptionalCoveragesPriceOnCard(): getAllOtherCoveragesPriceOnCard();
            double totalPremium = Double.parseDouble(appStore.getHome().getCoverageForPackage(selectedPackageCode, selectedPaymentMode).getTotalPremium());
            List<AppStore.Home.Discount> discounts = appStore.getHome().getDiscountsForPackage(selectedPackageCode, selectedPaymentMode);
            if (selectedPaymentMode.equals("PIF")) {
                fsa.assertTrue(isPresentmentCardPriceHeader(), "Thank You page - Quote Presentment card - quote price header.");
                fsa.assertEquals(currencyFormat.parse(getQuotePriceOnCard()).doubleValue(), totalPremium,
                        "Thank You page - Quote Presentment card - quote price.");

                fsa.assertEquals(currencyFormat.parse(getCoveragePriceOnCard).doubleValue(), totalPremium,
                        "Thank You page - Quote Presentment card - Included coverages price.");
                fsa.assertEquals(getOptionalCoveragePriceOnCard, "$0", "Thank You page - Quote Presentment card - Optional coverages price.");
                fsa.assertEquals(getDiscountsOnCard(), String.format("%s discounts included", discounts.size()),
                        "Thank You page - Quote Presentment card - number of discounts included.");
                if (isViewMonthlyPricingLink()) {
                    clickViewMonthlyPricing();
                } else {
                    break;
                }
            } else if (selectedPaymentMode.equals("EFT")) {

                totalPremium = Double.parseDouble(appStore.getHome().getCoverageForPackage(selectedPackageCode, selectedPaymentMode).getTotalPremium());
                Double monthlyPremium = Math.round((totalPremium / 12) * 100) / 100.00;
                fsa.assertEquals(currencyFormat.parse(getQuotePriceOnCard()).doubleValue(), monthlyPremium,
                            "Thank You page - Quote Presentment card - quote price.");
                fsa.assertEquals(currencyFormat.parse(getCoveragePriceOnCard).doubleValue(), monthlyPremium,
                            "Thank You page - Quote Presentment card - Included coverages price.");
                fsa.assertEquals(getOptionalCoveragePriceOnCard, "$0", "Thank You page - Quote Presentment card - Optional coverages price.");
                fsa.assertEquals(getDiscountsOnCard(), String.format("%s discounts included", discounts.size()),
                            "Thank You page - Quote Presentment card - number of discounts included.");
                if (isViewPayInFullPricingLink()) {
                    clickViewPayInFullPricing();
                } else {
                    break;
                }
            }
            waitForPageToBeReady();
        }
    }
}
