package com.farmers.ffq.common.pages;



import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.AppStore.KnockOut;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import lombok.Getter;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter
public class KnockoutInconveniencePage extends AutoBasePage {

    private static final String QUOTE_KNOCKOUT_DESKTOP_TOLL_NUMBER = "1-888-422-1618";
    private static final String QUOTE_KNOCKOUT_MOBILE_TOLL_NUMBER = "1-888-587-2121";
    String knockoutTollNumber = isUseMobileViewEnabled()? QUOTE_KNOCKOUT_MOBILE_TOLL_NUMBER : QUOTE_KNOCKOUT_DESKTOP_TOLL_NUMBER;

    public static final String EXPECTED_SPECIAL_ATTENTION_TITLE = "We apologize, but we can't finish your quote online at this time";
    private static final String EXPECTED_THANK_YOU_FOR_CHOOSING_FARMERS_INSURANCE_TITLE = "Thank you for choosing Farmers Insurance!";
    private static final String JUST_FEW_QUESTIONS_LEFT_DESCRIPTION = "We just have a few questions left for you to answer. Please contact us and an agent will work with you to get those questions answered and finish your purchase.";
    private static final String WE_ARE_SORRY = "We’re sorry!";
    private static final String ITS_NOT_YOU = "It's us, not you. You can try again or jot down your quote number and come back later to";
    private static final String UNABLE_TO_QUOTE_AT_THIS_TIME = "We are unable to complete your quote online at this time. Please contact us to see if you qualify.";
    private static final String INCONVENIENCE_PAGE_TITLE_XPATH = "//h1[contains(@class, 'inconvenience__title')]";
    private static final String KO_FOUNDATION_TYPE = "We are unable to complete your request at this time.";
    private static final String KO_FOUNDATION_TYPE_DESCRIPTION = "We're sorry, but we can't finish your quote online at this time. The property has a foundation type that isn't eligible for coverage. Please contact us to complete your quote (we may still be able to offer you coverage).";
    private static final String WE_NOT_ABLE_TO_COMPLETE_YOUR_QUOTE = "We aren't able to complete your quote at this time.";
    private static final String WE_APOLOGIZE_FOR_INCONVENIENCE = "We apologize for the inconvenience. The following company (companies) may be able to provide you with an online quote.";
    private static final String HOME_NOT_OFFERED_DESCRIPTION = "You need an insurance product for your home that we do not offer online at this time. " +
            "Please contact us to complete your quote.";

        private Locator thankYouForYourInterestPage = locator(pwXPath("//app-knockout-lead-form"));

        private Locator inconvenienceTitle = locator(pwCss("h1[class='tui-h1 inconvenience__title']"));

        private Locator inconvenienceHeaderTitle = locator(pwId("inconvenience_header-title"));

        private Locator quoteUnavailablePageTitle = locator(pwCss("div[id='quote_unavailable_header-title']>h1"));

        private Locator knockoutTitle = locator(pwId("knockout_title"));

        private Locator foremostKnockoutPageTitle = locator(pwXPath("//*[contains(@class, 'mobilehome-knockout__title')]"));

        private Locator knockoutDescription = locator(pwCss("p[class='tui-body']"));

        private Locator FGIAknockoutDescription = locator(pwXPath("//app-fgia-knockout//p[contains(@class,'tui-body tui-stacking-top-lg tui-stacking-bottom-lg')]"));

        private Locator inconvenienceDescription = locator(pwCss("span[class='tui-body']"));

        private Locator continueToFGIAButton = locator(pwCss("button[class='tui-btn tui-btn-primary continue-cta']"));

        private Locator agreeAndContinueButtonFGIA = locator(pwCss("button[data-test-id='AGREE_AND_CONTINUE_BUTTON']"));

        private Locator fgiaPageHeader = locator(pwId("pg_intro_title"));

        private Locator farmersLink = locator(pwXPath("//a[.='Farmers.com']"));

    private static final String REFERENCE_QUOTE_NUMBER = "Please reference your quote number:";
        private Locator koQuoteNumberReference = locator(pwXPath("//div[contains(@class,'knockout__quote-number')]//span[1]"));

        private Locator koQuoteNumberReference_fgia = locator(pwXPath("//div[contains(@class,'quote-details')]//p"));

        private Locator quoteNumberReference = locator(pwXPath("//div[contains(@class,'knockout__quote-number')]"));

        private Locator monetizationButtons = locator(pwCss("button[class='mav-partner__button']"));

        private Locator quoteReferenceText = locator(pwXPath("//div[contains(@class,'inconvenience__quote-number')]//span[@class='tui-body']"));

        private Locator quoteNumberInKO = locator(pwXPath("//div[contains(@class,'quote-number')]//span[@class='tui-body-bold']"));

        private Locator quoteNumberInKO_FGIA = locator(pwXPath("//div[contains(@class,'quote-details')]//span[@class='tui-body-bold']"));

        private Locator needMoreHelp = locator(pwXPath("//div/div[contains(.,'Need more help?')]"));

        private Locator youCanCallCustomerService = locator(pwXPath("//div/div[contains(.,'You can call customer service at')]"));

        private Locator youCanLabelElement = locator(pwXPath("//div/div[2][contains(@class, 'knockout__no-agent-text')]"));

        private Locator tryAgain = locator(pwXPath("//div[contains(@class,'inconvenience__cta')]"));
        private Locator tryAgainButton = locatorAny(
                pwXPath("//div[contains(@class,'inconvenience__cta')]//button"),
                pwXPath("//button[contains(.,'Try again')]"));

        private Locator existingCustomerCTA = locator(pwCss("div[class='existingCustomer__cta ng-star-inserted']>button"));

    private static final String YOUR_AGENT = "Your agent";
        private Locator yourAgent = locator(pwXPath("//div[contains(text(),'" + YOUR_AGENT + "')]"));

        private Locator agentsTitle = locator(pwXPath("div[class='yext-agents-title-text tui-body-text-bold']"));

        private Locator agentList = locator(pwXPath("//div[@class='yext-agents-content-container']//div[contains(@class,'auto-agent-details')]"));

        private Locator agentContactButtons = locator(pwXPath("//button[contains(.,'Contact')]"));

        private Locator agentName = locator(pwCss("div[class='tui-body-bold']"));

        private Locator agentsContactButtons = locator(pwCss("button[class='tui-link-button yext-agent-contact-text']"));

        private Locator contactMeButton = locator(pwCss("button[class='tui-link-button']"));

        private Locator tollFreeNumber = locator(pwCss("div[class='tui-h3 knockout__toll-free-number ng-star-inserted']"));

        private Locator tollFreeNumber2 = locator(pwXPath("//div[contains(@class,'agent-details-container')]//a[starts-with(@aria-label,'Contact farmers representative at')]"));

    private static final String BIT_MORE_INFO_ABOUT_VEHICLE = "We need a bit more information about your vehicle(s). Please contact us to complete your quote.";
        private Locator bitMoreInfoAboutVehicleKOMessage = locator(pwXPath("//p[contains(text(), '" + BIT_MORE_INFO_ABOUT_VEHICLE + "')]"));

        private Locator agentsImage = locator(pwXPath("//img[@class='agent-image']"));
        private Locator agentFullNameLocator = locator(pwXPath("//div[contains(@class,'agent-details')]/div[2]/div/div[2]"));

    private static final String LEASE_LOAN_KNOCKOUT_MSG = "We are unable to complete your policy purchase online. Please contact us with your loan or leasing company information so we may finish.";
        private Locator leasLoanKnockOutMessage = locator(pwXPath("//p[contains(text(), '" + LEASE_LOAN_KNOCKOUT_MSG + "')]"));
        private Locator startMyQuoteButtonsOnMonetizationKOPage = locator(pwXPath("//app-knockout//form//div[@id='mediaAlpha']//div[contains(@class,'mav-partner__buttons')]"));

        private Locator doesntOfferBusinessTollNumberDesktop = locator(pwCss("div[id='quote_unavailable_body_farmers']>a"));

        private Locator doesntOfferBusinessTollNumberMobile = locator(pwCss("a[id='quote_unavailable_body_farmers-mobile']"));

        private Locator findFarmersAgent = locator(pwXPath("//a[text()='Find a Farmers Agent']"));

        private Locator koTitleText = locator(pwXPath("//div[@class='knock-out_header-title']"));

        private Locator koDescriptionText = locator(pwXPath("//div[@class='knock-out_body_knock_message']"));

        private Locator agentImage = locator(pwXPath("//img[contains(@class,'knock-out_agent-image')]"));

        private Locator agentNameKOPage = locator(pwXPath("//div[contains(@class,'knock-out_agent-detail-name')]"));

        private Locator agentDetailsText = locator(pwXPath("//div[contains(@class,'knock-out_agent-detail-text')]"));

        private Locator agentEmail = locator(pwXPath("//a[contains(@class,'agent-email-link')]//div[contains(@class,'knock-out_agent-detail-email')]"));

        private Locator agentPhoneDesktop = locator(pwXPath("//div[contains(@class,'knock-out_desktop')]//div[contains(@class,'knock-out_agent-detail-phone')]"));

        private Locator agentPhoneMobile = locator(pwXPath("//div[contains(@class,'knock-out_mobile')]//div[contains(@class,'knock-out_agent-detail-phone')]"));

        private Locator scheduleAppointment = locator(pwXPath("//div[contains(@class,'schedule-appointment-content')]"));

        private Locator agentAddress = locator(pwXPath("//a[contains(@class,'agent-adress-link')]//span"));

        private Locator needMoreHelpDigitalMonetization = locator(pwXPath("//div[@id='knock-out_body_noagent']"));

        private Locator callCustomerServiceDigitalMonetization = locator(pwXPath("//div[@id='knock-out_body_call-custome']"));

        private Locator tollFreeDigitalMonetization = locator(pwXPath("//span[contains(@class,'knock-out_desktop')]//a[@id='default-phone']"));


    /**
     * Constructor.
     *
     * @throws Exception
     */
    public KnockoutInconveniencePage() throws Exception {
    }

    public boolean isOnInconveniencePage() {
        closeQualtricsPopUp();
        return isElementVisible(inconvenienceTitle, 30)
                || isElementVisible(inconvenienceHeaderTitle, 30);
    }

    public boolean clickTryAgainIfPresent() throws Exception {
        if (!isElementVisible(tryAgainButton, 5)) {
            return false;
        }
        waitAndClickElement(tryAgainButton);
        waitForSpinnerToBeGone();
        waitForUiSettled();
        return true;
    }

    public boolean isQuoteKnockedOut() {
        return isElementVisible(inconvenienceTitle, 3) || isElementVisible(knockoutTitle, 3);
    }

    public boolean isOnKnockOutPage() throws Exception {
        return isElementVisible(tollFreeNumber, 15) || isElementVisible(knockoutTitle, 10) || isElementVisible(thankYouForYourInterestPage, 20);
    }

    public boolean isUnableToCompleteOnlineQuoteKnockOutPage() {
        return isElementVisible(inconvenienceHeaderTitle, 3);
    }

    public boolean isOnDigitalMonetizationKOPage() throws Exception {
        return isElementVisible(koTitleText, 5);
    }

    public boolean isQualtricsSurveyPopUpDisplayed() {
        return super.isQualtricsSurveyFormDisplayed();
    }

    public boolean isOnMonetizedMediaAlphaPage() {
        return !(startMyQuoteButtonsOnMonetizationKOPage.count() == 0);
    }

    public boolean isOnForemostKnockoutPage() {
    	return isElementVisible(foremostKnockoutPageTitle, 5);
    }

    public boolean verifyExistingCustomerKnockout() throws Exception {
        final String EXPECTED_EXISTING_CUSTOMER_KNOCKOUT_TITLE = "Our records indicate you have an existing Farmers Auto Policy.";
        waitElementBeVisible(knockoutTitle);
        boolean testPassed = testExpectedTextContentForElement(waitElementBeVisible(knockoutTitle), EXPECTED_EXISTING_CUSTOMER_KNOCKOUT_TITLE);
        final String EXPECTED_EXISTING_CUSTOMER_DESCRIPTION = "As an existing customer, you can manage your policy online at Farmers.com or contact your agent if you'd like to make changes to your policy.";
        final String EXPECTED_EXISTING_CUSTOMER_DESCRIPTION_ALTERNATE = "If you'd like to make changes to your existing auto policy, please contact your agent.";
        String actualDescription = getTextFromElement(knockoutDescription);
        testPassed &= (actualDescription.equals(EXPECTED_EXISTING_CUSTOMER_DESCRIPTION) || actualDescription.equals(EXPECTED_EXISTING_CUSTOMER_DESCRIPTION_ALTERNATE));
        final String EXPECTED_EXISTING_CUSTOMER_CTA_TEXT = "Login or Create Account";
        if(isElementVisible(existingCustomerCTA,2)) {
            testPassed &= testExpectedTextContentForElement(existingCustomerCTA, EXPECTED_EXISTING_CUSTOMER_CTA_TEXT);
            waitAndClickElement(existingCustomerCTA);
            waitForSpinnerToBeGone();
            waitForUiSettled();
            testPassed &=waitElementBeVisible(locator(pwCss("div[class='login-heading']"))).isVisible();
            back();
        }
        return testPassed;
    }

    public boolean verifyStateTurnedOffInconvenience(){
        boolean testResult = testExpectedTextContentForElement(waitElementBeVisible(inconvenienceTitle), WE_ARE_SORRY);
        testResult &= testExpectedTextContentForElement(waitElementBeVisible(inconvenienceDescription), ITS_NOT_YOU);
        return testResult;
    }

    public boolean verifySpecialAttentionKOFromAddressPage_EG005() {
        boolean testPassed = testExpectedTextContentForElement(waitElementBeVisible(knockoutTitle), "Thank you for your interest in Farmers Insurance\u00ae");
        testPassed &= koQuoteNumberReference.isVisible();
        testPassed &= needMoreHelp.isVisible();
        testPassed &= testExpectedTextContentForElement(waitElementBeVisible(tollFreeNumber), knockoutTollNumber);
        testPassed &= quoteNumberInKO.isVisible();
        Log.info("verifySpecialAttentionKOFromAddressPage_EG005", true);
        return testPassed;
    }

    public boolean verifyZipCodeRestricted_EG013() throws Exception{
        maximizeWindow();
        boolean testPassed = testExpectedTextContentForElement(waitElementBeVisible(inconvenienceTitle), WE_ARE_SORRY);
        testPassed &= testExpectedTextContentForElement(waitElementBeVisible(inconvenienceDescription), ITS_NOT_YOU );
        testPassed &= farmersLink.isVisible();
        return testPassed;
    }

    public void verifySpecialAttentionKOFromDriverReviewPage_EK32(String quoteNumber, String realAgentName, boolean isRealAgentAssigned, FarmersSoftAssert fsa) throws Exception {
        isOnKnockOutPage();
        fsa.assertEquals(getTextFromElement(locator(pwId("knockout_title"))), YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION, "Knockout title check");
        final String EXPECTED_DESCRIPTION = "Your Farmers agent will contact you to complete your quote.";
        fsa.assertTrue(waitElementBeVisible(koQuoteNumberReference).isVisible(), "KO quote reference message displayed");
        fsa.assertTrue(waitElementBeVisible(quoteNumberInKO).isVisible(), "KO quote numeber displayed");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(quoteNumberInKO)), quoteNumber, "Quote number matches");
        if (isRealAgentAssigned) {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(knockoutDescription)), EXPECTED_DESCRIPTION, "Knockout page description check");
            fsa.assertEquals(getAssignedRealAgentName(), realAgentName, "Assigned real agent name check");

        } else {
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(tollFreeNumber)), knockoutTollNumber, "KO desktop toll number check");
        	int numberOfElements = agentList.count();
            for (int i = 0; i< numberOfElements; i++) {
                fsa.assertTrue(agentList.nth(i).isVisible(), "Agent " + (i+1) + " is displayed");
            }
        }
        Log.info("verifySpecialAttentionKOFromDriverReviewPage_EK32", true);
    }


    public void verifySpecialAttentionKOFromVehiclePage_VEH007(String quoteNumber, boolean isRealAgentAssigned, String realAgentName, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(knockoutTitle)), EXPECTED_SPECIAL_ATTENTION_TITLE, "Expected ko title check");
        fsa.assertTrue(waitElementBeVisible(koQuoteNumberReference).isVisible(), "KO quote number reference message displayed");
        fsa.assertTrue(quoteNumberInKO.isVisible(),"Quote number displayed");
        fsa.assertEquals(getTextFromElement(quoteNumberInKO), quoteNumber);
        if(isRealAgentAssigned) {
            fsa.assertEquals(this.getAssignedRealAgentName(), realAgentName, "Assigned real agent name check");
        } else {
            fsa.assertTrue(needMoreHelp.isVisible(), "Need more help displayed");
            fsa.assertTrue(youCanCallCustomerService.isVisible(), "You can call customer service message displayed");
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(tollFreeNumber)), knockoutTollNumber, "Toll number check");
        }
        Log.info("verifySpecialAttentionKOFromVehiclePage_VEH007", true);
    }

    public boolean validateFarmersDoesNotOfferBusinessKO_EG004() throws Exception {
        final String EXPECTED_KNOCKOUT_TITLE = "Sorry, we don't offer insurance in your area.";
        boolean testPassed = testExpectedTextContentForElement(waitElementBeVisible(quoteUnavailablePageTitle), EXPECTED_KNOCKOUT_TITLE);

        final String EXPECTED_KNOCKOUT_DESCRIPTION = "Click at least 2 to 3 companies below to find the best rate!";
        Locator description = locator(pwCss("div[id='quote_unavailable_body_message']"));
        testPassed &= testExpectedTextContentForElement(waitElementBeVisible(description), EXPECTED_KNOCKOUT_DESCRIPTION);

        waitForUiSettled();
    	int numberOfElements = monetizationButtons.count();
        for (int i = 0; i< numberOfElements; i++){
            Locator monetizationButton = monetizationButtons.nth(i);
            testPassed &= monetizationButton.isEnabled();
            testPassed &= testExpectedTextContentForElement(waitElementBeVisible(monetizationButton), "Start My Quote");
            Page farmersWindow = currentPage();
            waitAndClickElement(monetizationButton);
            List<Page> windowHandles = pages();
            windowHandles.remove(farmersWindow);
            Page partnerTab = windowHandles.stream().findFirst().orElseThrow();
            switchToPage(partnerTab);
            waitForUiSettled();
            closeCurrentPage();
            switchToPage(farmersWindow);
        }

        testPassed &= needMoreHelp.isVisible();
        testPassed &= youCanCallCustomerService.isVisible();

        if (isUseMobileViewEnabled()) {
            testPassed &= testExpectedTextContentForElement(waitElementBeVisible(doesntOfferBusinessTollNumberMobile), "1-800-420-9008");

        } else {
            testPassed &= testExpectedTextContentForElement(waitElementBeVisible(doesntOfferBusinessTollNumberDesktop), "1-800-206-9469");

        }
        Log.info("validateFarmersDoesNotOfferBusinessKO_EG004", true);
        return testPassed;
    }

    public void verifyGeneralInfoOnBindKnockOut(AppStore.Data.AgentData agentData, FarmersSoftAssert fsa) throws Exception {
        isOnKnockOutPage();
        String agentFullName = agentData.getFirstName() + " " + agentData.getLastName();
        fsa.assertTrue(koQuoteNumberReference.isVisible(), "koQuoteNumberReference.isVisible()");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(koQuoteNumberReference)), REFERENCE_QUOTE_NUMBER, "Reference quote number text check");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(agentFullNameLocator)), agentFullName, "Agent name check");
    }

    public boolean verifyLenderKnockOutMessage(){
        return testExpectedTextContentForElement(waitElementBeVisible(leasLoanKnockOutMessage), LEASE_LOAN_KNOCKOUT_MSG);
    }

    public void validateFinancialFilingInAnotherState(FarmersSoftAssert fsa, String quoteNumber, boolean isAgentAssigned) throws Exception {
        isOnKnockOutPage();
        fsa.assertTrue(isElementPresentByID(knockoutTitle), "KO page title displayed");
        fsa.assertTrue(waitElementBeVisible(knockoutDescription).isVisible(), "KO page description displayed");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(quoteNumberInKO)), quoteNumber, "Quote Number in KO page check");

        if(!isAgentAssigned) {
            fsa.assertTrue(needMoreHelp.isVisible(), "Need more help displayed");
            fsa.assertTrue(youCanCallCustomerService.isVisible(), "'You can call customer service at' message displayed");
        } else {
            fsa.assertTrue(yourAgent.isVisible(), "'Your agent' text is displayed on the KO page for real agent assigned case");
            fsa.assertTrue(agentsImage.isVisible(), "Agent image displayed");
            fsa.assertTrue(agentName.isVisible(), "Agent name displayed");
        }

        Log.info("validateFinancialFilingInAnotherState", true);
    }

    public List<String> getAllKnockOutErrorCodes() throws Exception {
        List<String> errorCodes = getSessionStorageAppStore().getKnockouts().stream().map(KnockOut::getErrorCode).collect(Collectors.toList());
        Log.info("Knockout error codes: " + errorCodes);
        return errorCodes;
    }

    public void validateHRCKnockOuts(FarmersSoftAssert fsa) throws Exception {
        List<AppStore.KnockOut> knockOuts = getSessionStorageAppStore().getKnockouts();
        if (knockOuts.isEmpty()) {
            fsa.assertTrue(false, "Knockouts list is not empty in the session appStore.");
        } else {
        	String koTitle = knockOuts.get(0).getKnockoutTitle();
        	String koDescription = knockOuts.get(0).getKnockoutUIDesc().replace(" or click below for other options", EMPTY_STRING);

        	fsa.assertEquals(getTextFromElement(knockoutTitle), koTitle, "KO page - page title check");
        	fsa.assertEquals(getTextFromElement(knockoutDescription), koDescription, "KO page - KO description check");
        	fsa.assertTrue(koQuoteNumberReference.isVisible(), "KO quote reference number displayed");
        	fsa.assertEquals(getTextFromElement(koQuoteNumberReference), REFERENCE_QUOTE_NUMBER, REFERENCE_QUOTE_NUMBER + " check");

        	if (isElementVisible(tollFreeNumber, 2)) {
        		fsa.assertTrue(needMoreHelp.isVisible(), "Knock-out page - Need more help text displayed.");
        		fsa.assertTrue(youCanCallCustomerService.isVisible(), "Knock-out page - You can call customer service text displayed.");
        		fsa.assertEquals(getTextFromElement(tollFreeNumber), knockoutTollNumber, "Knock-out page - TFN check");
        	} else if (isElementVisible(tollFreeNumber2, 2)) {
        		fsa.assertTrue(yourAgent.isVisible(), "'Your agent' text is displayed on the KO page.");
        		fsa.assertTrue(agentsImage.isVisible(), "Agent image displayed");
        		fsa.assertTrue(agentName.isVisible(), "Agent name displayed");
        	} else if (isElementVisible(contactMeButton, 2)) {
        		fsa.assertTrue(yourAgent.isVisible(), "'Your agent' text is displayed on the KO page for real agent assigned case");
        		fsa.assertTrue(contactMeButton.isVisible(), "Contact me button for the agent displayed");
        		fsa.assertTrue(agentsImage.isVisible(), "Agent image displayed");
        		fsa.assertTrue(agentName.isVisible(), "Agent name displayed");
        	} else {
        		fsa.fail("Did not find toll-free number or 'Contact me' agent link on Knock-out (non-offering)  page.");
        	}
        }
    }

    public void validateKnockOutOnSelectingQuestionsFromJFMT(FarmersSoftAssert fsa, String quoteNumber){
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(knockoutTitle)), EXPECTED_THANK_YOU_FOR_CHOOSING_FARMERS_INSURANCE_TITLE, "Knock Out Page title check");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(knockoutDescription)), JUST_FEW_QUESTIONS_LEFT_DESCRIPTION, "Knock out page description check");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(koQuoteNumberReference)), REFERENCE_QUOTE_NUMBER, "Quote number reference description in knockout page check");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(quoteNumberInKO)), quoteNumber, "Quote number in knockout page check");
        if (isElementVisible(contactMeButton, 2)) {
            fsa.assertTrue(yourAgent.isVisible(), "'Your agent' text is displayed on the KO page for real agent assigned case");
            fsa.assertTrue(contactMeButton.isVisible(), "Contact me button for the agent is displayed");
            fsa.assertTrue(agentsImage.isVisible(), "Agent image is displayed");
            fsa.assertTrue(agentName.isVisible(), "Agent name is displayed");
        }
    }


    public void validateKnockOutForNotOffering(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isOnKnockOutPage(), "Knock-out page - On KO page.");
        fsa.assertEquals(getPageTitle(), YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION, "Knock-out page - Page title.");
        fsa.assertEquals(getPageDescription(), HOME_NOT_OFFERED_DESCRIPTION, "Knock-out page - Page description.");
        if (isElementVisible(tollFreeNumber, 2)) {
            fsa.assertTrue(needMoreHelp.isVisible(), "Knock-out page - Need more help text is displayed.");
            fsa.assertTrue(youCanCallCustomerService.isVisible(), "Knock-out page - You can call customer service text is displayed.");
            fsa.assertEquals(getTextFromElement(tollFreeNumber), knockoutTollNumber, "Knock-out page - TFN is displayed.");
        } else if (isElementVisible(contactMeButton, 2)) {
            fsa.assertTrue(yourAgent.isVisible(), "'Your agent' text is displayed on the KO page for real agent assigned case");
            fsa.assertTrue(contactMeButton.isVisible(), "Contact me button for the agent is displayed");
            fsa.assertTrue(agentsImage.isVisible(), "Agent image is displayed");
            fsa.assertTrue(agentName.isVisible(), "Agent name is displayed");
        } else if (isElementVisible(yourAgent, 2)) {
            fsa.assertTrue(yourAgent.isVisible(), "'Your agent' text is displayed on the KO page for real agent assigned case");
            fsa.assertTrue(agentsImage.isVisible(), "Agent image is displayed");
            fsa.assertTrue(agentName.isVisible(), "Agent name is displayed");
        } else {
            fsa.fail("Did not find toll-free number or 'Contact me' agent link on Knock-out (non-offering)  page.");
        }
    }

    public void validateNYCommuterForNJCustomer() throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(isOnKnockOutPage(), "Knock-out page - On KO page.");
        fsa.assertEquals(getPageTitle(), EXPECTED_SPECIAL_ATTENTION_TITLE, "Knock-out page - Page title.");
        fsa.assertEquals(getPageDescription(), "Unfortunately we need to collect additional information from you. Please contact us at the number below to continue your quote.", "Knock-out page - Page description.");
        fsa.assertEquals(getTextFromElement(koQuoteNumberReference) + SPACE + getQuoteNumber(), String.format("Please reference your quote number: %s", getSessionStorageAppStore().getData().getQuoteNumber()));
        fsa.assertAll();
    }

    public void verifyUnableToCompleteOnlineKnockout(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        waitElementBeVisible(knockoutTitle);
        final String EXPECTED_MONETIZATION_KNOCKOUT_TITLE = "We are unable to complete your request at this time.";
        fsa.assertEquals(getTextFromElement(knockoutTitle), EXPECTED_MONETIZATION_KNOCKOUT_TITLE, "KO page - Page title is not displayed as expected.");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(koQuoteNumberReference)), REFERENCE_QUOTE_NUMBER, "Quote number reference description in knockout page not displayed");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(quoteNumberInKO)), applicant.getQuoteNumber(), "Quote number in knockout page not displayed/Not Matched");
        validateAssignedAgentSection(this, fsa);
    }

    public void verifyMonetizationKnockout(FarmersSoftAssert fsa) {
        waitElementBeVisible(knockoutTitle);
        final String EXPECTED_MONETIZATION_KNOCKOUT_TITLE = "We are unable to complete your request at this time.";
        final String EXPECTED_MONETIZATION_KNOCKOUT_DESCRIPTION = "We're sorry, but we can't finish your quote online at this time. Your property is ineligible based on previous " +
                "losses. Please contact us to complete your quote (we may still be able to offer you coverage) or click below for other options.";
        fsa.assertEquals(getTextFromElement(knockoutTitle), EXPECTED_MONETIZATION_KNOCKOUT_TITLE, "Monetization KO page title check");
        fsa.assertEquals(getTextFromElement(knockoutDescription), EXPECTED_MONETIZATION_KNOCKOUT_DESCRIPTION, "Monetization KO page description check");

        final String NEED_MORE_HELP = "Need more help?";
        final String YOU_CAN_CALL = "You can call customer service at";
        fsa.assertEquals(getTextFromElement(needMoreHelp), NEED_MORE_HELP, "Monetization KO page - Need more help check");
        fsa.assertEquals(getTextFromElement(youCanCallCustomerService), YOU_CAN_CALL, "Monetization KO page - You can call customer service at check");
        fsa.assertEquals(getTextFromElement(tollFreeNumber), knockoutTollNumber, "Monetization KO page - toll free number check");
        fsa.assertEquals(!(startMyQuoteButtonsOnMonetizationKOPage.count() == 0), true, "Monetization KO page - at least one start my quote button from competitors displayed.");
    }

    public void validateUnacceptableRoofKO(FarmersSoftAssert fsa){
        waitElementBeVisible(knockoutTitle);
        final String EXPECTED_MONETIZATION_KNOCKOUT_TITLE = "We are unable to complete your request at this time.";
        final String EXPECTED_MONETIZATION_KNOCKOUT_DESCRIPTION = "We are unable to complete your quote online at this time. Click below for other options.";
        fsa.assertEquals(getTextFromElement(knockoutTitle), EXPECTED_MONETIZATION_KNOCKOUT_TITLE, "KO page title is not displayed as expected.");
        fsa.assertEquals(getTextFromElement(knockoutDescription), EXPECTED_MONETIZATION_KNOCKOUT_DESCRIPTION, "KO page description is not displayed as expected.");

        final String NEED_MORE_HELP = "Need more help?";
        final String YOU_CAN_CALL = "You can call customer service at";
        fsa.assertEquals(getTextFromElement(needMoreHelp), NEED_MORE_HELP, "KO page - Need more help is not displayed as expected.");
        fsa.assertEquals(getTextFromElement(youCanCallCustomerService), YOU_CAN_CALL, "KO page - You can call customer service at is not displayed as expected.");
//        fsa.assertEquals(getTextFromElement(tollFreeNumber), QUOTE_KNOCKOUT_DESKTOP_TOLL_NUMBER, "KO page - toll free number is not displayed as expected.");
    }

    public void validateKnockOutOnSelectingFoundationTypeDeepPilings(FarmersSoftAssert fsa) throws Exception {
        List<KnockOut> knockouts = getSessionStorageAppStore().getKnockouts();
        boolean hasExpectedKnockoutCode = knockouts != null
                && knockouts.stream().anyMatch(k -> "DWCONS009".equals(k.getKnockoutCode()));
        fsa.assertTrue(hasExpectedKnockoutCode, "Knock out code DWCONS009 not present for foundation type - deep pilings");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(knockoutTitle)), KO_FOUNDATION_TYPE, "Not Landed on Knock Out Page");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(knockoutDescription)), KO_FOUNDATION_TYPE_DESCRIPTION, "Knock out page description not matched");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(koQuoteNumberReference)), REFERENCE_QUOTE_NUMBER, "Quote number reference description in knockout page not displayed");
        if (isElementVisible(contactMeButton, 2)) {
            fsa.assertTrue(yourAgent.isVisible(), "'Your agent' text is displayed on the KO page for real agent assigned case");
            fsa.assertTrue(contactMeButton.isVisible(), "Contact me button for the agent is displayed");
            fsa.assertTrue(agentsImage.isVisible(), "Agent image is displayed");
            fsa.assertTrue(agentName.isVisible(), "Agent name is displayed");
        }
    }

    public String getPageTitle() {
        return getTextFromElement(waitElementBeVisible(knockoutTitle));
    }

    public String getInconvenienceHeaderTitle() {
        return getTextFromElement(inconvenienceHeaderTitle);
    }

    public String getPageDescription() {
        return getTextFromElement(waitElementBeVisible(knockoutDescription));
    }

    private String getQuoteNumber() {
        return getTextFromElement(quoteNumberInKO);
    }

    public boolean isInconvenienceTitlePresent() throws Exception {
        return isElementPresent(pwXPath(INCONVENIENCE_PAGE_TITLE_XPATH));
    }

    public void validateIidBehavior_SC_KO(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isOnKnockOutPage(), "User is on the KO page");
        waitElementBeVisible(knockoutTitle);
        fsa.assertEquals(getTextFromElement(knockoutTitle), WE_NOT_ABLE_TO_COMPLETE_YOUR_QUOTE, "SC KO page title validation");
        fsa.assertEquals(getTextFromElement(knockoutDescription), WE_APOLOGIZE_FOR_INCONVENIENCE, "SC KO page description validation");
        fsa.assertFalse((monetizationButtons.count() == 0), "Monetization buttons are not provided");
    }

    public void verifyBundleKnockoutPageContent(String scenario, FarmersSoftAssert fsa) {
    	String knockoutTitleText = "Thank you for choosing Farmers Insurance\u00ae";
    	String scenarioText = "Our team is happy to help if you have any questions or want to explore other options.";
    	String contactText = "You can speak with a representative at";
    	if (scenario.equals(QUOTE_KNOCKOUT)) {
    		knockoutTitleText = "Your quote requires special attention";
    		scenarioText = HOME_NOT_OFFERED_DESCRIPTION;
    		contactText = "You can call customer service at";
    	} else if (scenario.equals(PROPERTY_KNOCKOUT)) {
    		knockoutTitleText = "We are unable to complete your request at this time.";
    		scenarioText = "Your property is ineligible based on previous losses. Please contact us to complete your quote";
    		contactText = "You can call customer service at";
    	}
    	fsa.assertEquals(getTextFromElement(knockoutTitle), knockoutTitleText, "Bundle knockout page title verification");
		fsa.assertTrue(isExpectedTextContainedInElement(knockoutDescription, scenarioText), "Bundle knockout page description verification");
		if (isElementDisplayed(yourAgent, 1)) {
            fsa.assertTrue(yourAgent.isVisible(), "'Your agent' text displayed");
            fsa.assertTrue(agentsImage.isVisible(), "Agent image displayed");
            fsa.assertTrue(agentName.isVisible(), "Agent name displayed");

		} else {
			fsa.assertTrue(isElementDisplayed(needMoreHelp, 3), "Need more help label verification");
			fsa.assertEquals(getTextFromElement(youCanLabelElement), contactText, "Whom to contact label verification");
			fsa.assertEquals(getTextFromElement(tollFreeNumber), knockoutTollNumber, "Toll free number verification.");
		}
    }

    public void validateFGIA_KO_Page(FarmersSoftAssert fsa) throws Exception {
        isOnKnockOutPage();
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(knockoutTitle)), "Continue your quote with Farmers General Insurance Agency, Inc.", "KO page header validation");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(FGIAknockoutDescription)), "We are unable to offer you an online quote for a Farmers-branded policy at this time. However, Farmers General Insurance Agency , Inc. (FGIA) may be able to offer you a quote through other companies.", "KO page description validation");
        String sessionStorageQuoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
        fsa.assertEquals(getTextFromElement(quoteNumberInKO_FGIA), sessionStorageQuoteNumber, "Quote Number check");
        fsa.assertEquals(getTextFromElement(koQuoteNumberReference_fgia), REFERENCE_QUOTE_NUMBER, "Quote reference text check");
        fsa.assertEquals(getTextFromElement(continueToFGIAButton), "Continue to FGIA", "Continue to FGIA button text check");
        waitAndClickElement(continueToFGIAButton);
        waitAndClickElement(agreeAndContinueButtonFGIA);
        waitForSpinnerToBeGone();
        waitForUiSettled();
        String title = page().title();
        fsa.assertTrue(title.contains("Farmers Insurance Choice | Select insurance type") || title.contains("Farmers General Insurance Agency, Inc. | Select insurance type"));
    }

    public void validateQuoteNotAvailableKO() throws Exception {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(isOnKnockOutPage(), "User should be on the KO page");
        fsa.assertEquals(getTextFromElement(knockoutTitle), YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION, "Knockout page title check");
        fsa.assertEquals(getTextFromElement(knockoutDescription), "Online quotes are not available at this time. Please contact your agent for a quote.", "Knockout page description check");
        fsa.assertAll();
    }

    public void digitalMonetizationKOAgentValidation(FarmersSoftAssert fsa, String agentId) throws Exception {
        fsa.assertTrue(isOnDigitalMonetizationKOPage(), "Knock-out page - On KO page.");
        fsa.assertEquals(getTextFromElement(koTitleText), YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION, "Knock-out page - Page title.");
        fsa.assertEquals(getTextFromElement(koDescriptionText), "Online quotes are not available at this time. Please contact your agent for a quote.", "Knockout page description check");
        boolean isAWSFlow = !agentId.isEmpty();
        if (isAWSFlow) {
            fsa.assertTrue(isElementDisplayed(agentImage, 5), "Agent image is displayed");
            fsa.assertTrue(isElementDisplayed(agentNameKOPage, 5), "Agent name is displayed");
            fsa.assertTrue(isElementDisplayed(agentDetailsText, 5), "Agent details text is displayed");
            fsa.assertTrue(isElementDisplayed(agentEmail, 5), "Agent email is displayed");
            if (isUseMobileViewEnabled()) {
                fsa.assertTrue(isElementDisplayed(agentPhoneMobile, 5), "Agent phone number is displayed on mobile view");
            } else {
                fsa.assertTrue(isElementDisplayed(agentPhoneDesktop, 5), "Agent phone number is displayed on desktop view");
            }
            fsa.assertTrue(isElementDisplayed(scheduleAppointment, 5), "Schedule appointment text is displayed");
        } else {
            fsa.assertTrue(isElementDisplayed(needMoreHelpDigitalMonetization, 5), "Knock-out page - Need more help text is displayed.");
            fsa.assertTrue(callCustomerServiceDigitalMonetization.isVisible(), "Knock-out page - You can call customer service text is displayed.");
            fsa.assertEquals(getTextFromElement(tollFreeDigitalMonetization), knockoutTollNumber, "Knock-out page - TFN is displayed.");
        }
    }

    public void policyExclusionKOValidation(FarmersSoftAssert fsa) throws Exception {
        String actualKnockoutTitle = getTextFromElement(knockoutTitle);
        fsa.assertTrue(actualKnockoutTitle.equals(YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION) ||
                actualKnockoutTitle.equals(YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION + PERIOD), "Knock-out page - Page title.");
        fsa.assertEquals(getTextFromElement(knockoutDescription), UNABLE_TO_QUOTE_AT_THIS_TIME, "Knockout page description check");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(koQuoteNumberReference)), REFERENCE_QUOTE_NUMBER, "Quote number reference description in knockout page validation");
        String sessionStorageQuoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
        fsa.assertEquals(getQuoteNumber(), sessionStorageQuoteNumber, "Quote Number check");
        if (isElementVisible(tollFreeNumber, 2)) {
            fsa.assertTrue(needMoreHelp.isVisible(), "Knock-out page - Need more help text is displayed.");
            fsa.assertTrue(youCanCallCustomerService.isVisible(), "Knock-out page - You can call customer service text is displayed.");
            fsa.assertEquals(getTextFromElement(tollFreeNumber), knockoutTollNumber, "Knock-out page - TFN is displayed.");
        } else if (isElementVisible(contactMeButton, 2)) {
            fsa.assertTrue(yourAgent.isVisible(), "'Your agent' text is displayed on the KO page for real agent assigned case");
            fsa.assertTrue(contactMeButton.isVisible(), "Contact me button for the agent is displayed");
            fsa.assertTrue(agentsImage.isVisible(), "Agent image is displayed");
            fsa.assertTrue(agentName.isVisible(), "Agent name is displayed");
        } else if (isElementVisible(yourAgent, 2)) {
            fsa.assertTrue(yourAgent.isVisible(), "'Your agent' text is displayed on the KO page for real agent assigned case");
            fsa.assertTrue(agentsImage.isVisible(), "Agent image is displayed");
            fsa.assertTrue(agentName.isVisible(), "Agent name is displayed");
        } else {
            fsa.fail("Did not find toll-free number or 'Contact me' agent link on Knock-out (non-offering)  page.");
        }
    }

    public void validateMapIsNotPresentInAutoKO(FarmersSoftAssert softAssert) throws Exception {
        isOnKnockOutPage();
        softAssert.assertTrue((agentList.count() == 0), "Agent list should be empty for auto KO page");
    }

}
