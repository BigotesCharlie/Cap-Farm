package com.farmers.ffq.common.pages;






import com.microsoft.playwright.Page;
import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoContinueToPaymentOneUI;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Data.CustomerData;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class PolicyPaymentBasePage extends AdditionalInfoContinueToPaymentOneUI {
    protected static final String AUTO_POLICY_PAYMENT_HEADER = "Auto policy payment";
        protected Locator autoPolicyPaymentHeader = locator(pwXPath("//h1[contains(text(), '" + AUTO_POLICY_PAYMENT_HEADER + "')]"));

    private static final String FEES = "Fees";
        protected Locator feeSideBarHeader = locator(pwXPath("//p[contains(@class,'tui-info-box-header')]"));

    private static final String MEMBERSHIP_FEE_MESSAGE = "A membership fee per vehicle is applied for new auto policies and new vehicles added to your policy. It covers the administrative costs associated with you becoming a member of the insurance exchange and the issuance of your policy.";
        protected Locator membershipFeeMessageSideBar = locator(pwXPath("//p[contains(text(), 'A membership fee per vehicle is applied ')]"));

    private static final String POLICY_FEE_MESSAGE = "A policy fee per vehicle is applied for new auto policies and new vehicles added to your policy. This is for administrative costs associated with writing your new policy.";
        protected Locator policyFeeMessageSideBar = locator(pwXPath("//p[contains(text(), 'A policy fee per vehicle is applied for new auto')]"));

    private static final String VEHICLE_FEE_MESSAGE = "A fee per vehicle is applied for new auto policies and new vehicles added to your policy. This is for administrative costs associated with writing your new policy.";
        protected Locator vehicleFeeMessageSideBar = locator(pwXPath("//p[contains(text(), 'A fee per vehicle is applied for new auto')]"));

    private static final String SIX_MONTH_TERM_PAYMENT = "6-month term payment";
        protected Locator sixMonthTermPayment = locator(pwXPath("//span[contains(text(),'" + SIX_MONTH_TERM_PAYMENT + "')]"));

        private Locator sixTermPriceSubHeader = locator(pwXPath("//span[contains(text(), '6-month term price')]"));

        protected Locator fees = locator(pwXPath("//span[contains(text(),'" + FEES + "')]"));

    public static final String DUE_TODAY_LABEL = "Due today";
        private Locator dueTodayLabel = locator(pwXPath("//section[contains(@class,'autopay-details')]//*[contains(text(),'" + DUE_TODAY_LABEL + "')]"));

    private static final String SET_UP_PAYMENT_METHOD = "Set up payment method";
        protected Locator setUpPaymentMethodButton = locator(pwXPath("//button[contains(text(),'" + SET_UP_PAYMENT_METHOD + "')]"));

        protected Locator setUpPaymentMethodButtonInIframe = locator(pwXPath("//mat-dialog-container//button[contains(text(),'" + SET_UP_PAYMENT_METHOD + "')]"));

        private Locator addPaymentMethodContainerCloseIcon = locator(pwXPath("//mat-icon[contains(text(), 'close')]"));

        private Locator addPaymentMethodDialogContainer = locator(pwXPath("//mat-dialog-container[@aria-labelledby='addPaymentHeading']"));

    private static final String ADD_BUTTON = "ADD";
        private Locator addButton = locator(pwXPath("//button[@name='submitBtn']"));

    private static final String ADD_PAYMENT_METHOD_LABEL = "Add payment method";
        private Locator addPaymentMethodLabel = locator(pwXPath("//h1[text() = '" + ADD_PAYMENT_METHOD_LABEL + "']"));

    private static final String ADD_BANK = "Add bank";
        private Locator addBankHeader = locator(pwXPath("//h1[contains(text(), '" + ADD_BANK + "')]"));

    private static final String BANK_PAYMENT_BUTTON_TEXT = "Bank payment";
        protected Locator bankPaymentButton = locator(pwXPath("//app-add-payment//*[contains(text(),'" + BANK_PAYMENT_BUTTON_TEXT + "')]"));

    protected static final String BANK_BUTTON_TEXT = "Bank";
        protected Locator bankButton = locator(pwXPath("//app-add-payment//*[contains(text(),'" + BANK_BUTTON_TEXT + "')]"));

    private static final String DEBIT_CREDIT_CARD_BUTTON = "Debit / Credit card";
        protected Locator debitCreditCardButton = locator(pwXPath("//div[@role='tab']//span[contains(text(),'Debit / Credit card')]"));

        protected Locator cardButtonIframe = locator(pwXPath("//div[@role='tab']//span[contains(text(),'Card')]"));

    private static final String CARD_BUTTON = "Card";
        private Locator cardButton = locator(pwXPath("//div[@class='mat-tab-label-content' and contains(text(),'" + CARD_BUTTON + "')]"));

    private static final String PAPERLESS_TERMS_OF_USE = "Paperless Terms of Use";
        private Locator paperlessTermsOfUseLink = locator(pwXPath("//a[contains(text(), '" + PAPERLESS_TERMS_OF_USE + "')]"));

    private static final String INFORMATION_STORAGE_AUTHORIZATION = "Information Storage Authorization";
        private Locator informationStorageAuthorizationLink = locator(pwXPath("//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]"));

    private static final String PAYMENT_AUTHORIZATION = "Payment Authorization Terms & Conditions.";
        private Locator paymentAuthorizationLink = locator(pwXPath("//a[contains(text(), '" + PAYMENT_AUTHORIZATION + "')]"));


    List<Locator> listOfLinksToClick = Arrays.asList(paperlessTermsOfUseLink, informationStorageAuthorizationLink, paymentAuthorizationLink);
    private static final String TERMS_AND_CONDITIONS_TITLE = "Terms of Use | Farmers Insurance";
    private static final String PAYMENT_AUTHORIZATION_TITLE = "Payment Authorization Terms and Conditions | Farmers Insurance";
    private static final String INFORMATION_STORAGE_AUTHORIZATION_TITLE = "Payment Card Storage Terms & Conditions | Farmers Insurance";

    private static final List<String> listOfTabTitles = Arrays.asList(TERMS_AND_CONDITIONS_TITLE, INFORMATION_STORAGE_AUTHORIZATION_TITLE, PAYMENT_AUTHORIZATION_TITLE);


    private static final String BY_CLICKING_COMPLETER_PURCHASE = "String clicking \"Complete purchase\" below:";
        private Locator byClickingCompletePurchaseLabel = locator(pwXPath("//div[contains(text(), '" + BY_CLICKING_COMPLETER_PURCHASE + "')]"));

    private static final String READ_AND_AGREED_TO_THE_BULLET_ONE = "I confirm that I have read and agree to the Paperless Terms of Use; and";
        private Locator readAndAgreedToTheBulletPointOne = locator(pwXPath("//a[contains(text(), '" + PAPERLESS_TERMS_OF_USE + "')]/parent::p"));

    private static final String IF_DO_NOT_AGREE_WITH_TERMS = "If you do not agree with the Terms and Conditions above and/or have any questions, please contact your agent or Farmers Direct Sales Center to complete this transaction. You can always change your Paperless and Automatic Payment settings for future transactions by logging in to your Farmers.com account.";
        private Locator ifDoNotAgreeWithTermsAndConditionLabel = locator(pwXPath("//p[contains(text(), 'If you do not agree with the Terms and Conditions above ')]"));

    private static final String COMPLETE_PURCHASE_BUTTON = "Complete purchase";
        protected Locator completePurchaseButton = locator(pwXPath("//button[contains(text(), '" + COMPLETE_PURCHASE_BUTTON + "')]"));

    private static final String PAYMENT_METHOD_ALREADY_ADDED_ERROR = "You have already saved this payment method. Cannot save duplicate.";
        private Locator paymentMethodAlreadyAdded = locator(pwXPath("//li[@id='profile']"));

    private static final String READ_AND_AGREED_TO_THE_BULLET_TWO_MONTHLY_PAY = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries (\"Farmers\") to initiate One-Time and Automatic Payment processes.";
        private Locator readAndAgreedToTheBulletPointTwoMonthlyPay = locator(pwXPath("//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p"));

    private static final String READ_AND_AGREED_TO_THE_BULLET_TWO = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries (\"Farmers\") to initiate:";
    private static final String READ_AND_AGREED_TO_THE_BULLET_TWO_ALTERNATE = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries(\"Farmers\") to initiate:";
        private Locator readAndAgreedToTheBulletPointTwo = locator(pwXPath("//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p"));

    private static final String FARMERS_FAST_QUOTE = "FARMERS FAST QUOTE";
    private static final String PAY_IN_FULL_HEADER = "Pay in full";
        private Locator payInFullHeader = locator(pwXPath("//h2[contains(text(), '" + PAY_IN_FULL_HEADER + "')]"));

    protected static final String ADD_YOUR_PREFERRED_PAYMENT_METHOD1 = "Add your preferred payment method.";
        private Locator selectPreferredPaymentMethod = locator(pwXPath("//span[contains(text(),'" + ADD_YOUR_PREFERRED_PAYMENT_METHOD1 + "')]"));
    private static final String USE_BANK_DEBIT_CREDIT = "Use bank payment, debit card, or credit card";
        private Locator useBankDebitCreditCard = locator(pwXPath("//p[contains(text(), 'bank payment, debit card, or credit')]"));

    protected static final String NO_SERVICE_CHARGES_WHEN_YOU_PAY_IN_FULL = "No service charges when you pay in full";
        private Locator noServiceChargesWhenPayInFull = locator(pwXPath("//p[contains(text(), 'No service charges when you pay in full')]"));

    public static final String MONTHLY_AUTO_PAY_BANK_HEADER = "Monthly autopay - bank";
    public static final String MONTHLY_AUTO_PAY_CARD_HEADER = "Monthly autopay - card";
        private Locator monthlyAutoPayBankHeader = locator(pwXPath("//h2[contains(text(), '" + MONTHLY_AUTO_PAY_BANK_HEADER + "')]"));
        private Locator monthlyAutoPayCardHeader = locator(pwXPath("//h2[contains(text(), '" + MONTHLY_AUTO_PAY_CARD_HEADER + "')]"));
        private Locator monthlyDirectBillHeader = locator(pwXPath("//h2[contains(text(), '" + MONTHLY_DIRECT_BILL + "')]"));
    private static final String FIRST_MONTHLY_PAYMENT = "First monthly payment";
        private Locator firstMonthlyPaymentLabel = locator(pwXPath("//p[contains(text(), '" + FIRST_MONTHLY_PAYMENT + "')]"));
    private static final String FEES_LABEL = "Fees";
        private Locator feesLabel = locator(pwXPath("//p[contains(text(), '" + FEES_LABEL + "')]"));

    private static final String SELECT_PREFERRED_PAYMENT_LABEL = "Select your preferred payment method.";
        private Locator selectPreferredPaymentLabel = locator(pwXPath("//p[contains(text(), '" + SELECT_PREFERRED_PAYMENT_LABEL + "')]"));
        private Locator bankPaymentRadiobutton = locator(pwXPath("//input[@value='bank-transfer']"));
        private Locator bankPaymentRadiobuttonInIframe = locator(pwXPath("//mat-dialog-content//input[@value='bank-transfer']"));
        private Locator changeBankPaymentRadiobutton = locator(pwXPath("//label[contains(text(),'Bank payment')]/preceding::input[@value='bank-transfer']"));
        protected Locator bankPaymentRadiobuttonAlternate = locator(pwXPath("//mat-radio-button[@value='bank-transfer']"));

        protected Locator bankPaymentRadiobuttonLabel = locator(pwXPath("//mat-radio-button[@value='bank-transfer']//label"));

        protected Locator bankPaymentRadiobuttonSideSheet = locator(pwXPath("//mat-radio-group[@name='monthly-autopay-options-sidesheet']//mat-radio-button[@value='bank-transfer']"));

        private Locator bankPaymentLabel = locator(pwXPath("//mat-radio-button[@value='bank-transfer']//label"));
        private Locator cardPaymentLabel = locator(pwXPath("//mat-radio-button[@value='card']//label"));
    private static final String DOLLAR_ZERO = "$0";
        private Locator dollarZeroLabel = locator(pwXPath("//span[contains(text(), '$0')]"));

    private static final String IN_SERVICE_CHARGES_LABEL = "in service charges";
        private Locator inServiceChargesElement = locator(pwXPath("//li[contains(.,'" + IN_SERVICE_CHARGES_LABEL + "')]"));

    //     private Locator cardPaymentRadiobutton = locator(pwXPath("//p[contains(text(),' Select your preferred payment method. ')]//following::mat-radio-button[@value='card']"));

        protected Locator cardPaymentRadiobuttonAlternative = locator(pwXPath("//mat-radio-button[@value='card']"));

        protected Locator cardPaymentRadiobuttonLabel = locator(pwXPath("//mat-radio-button[@value='card']//label"));

        private Locator changeCardPaymentRadiobutton = locator(pwXPath("//label[contains(text(),'Card')]/preceding::input[@value='card']"));

    private static final String FUTURE_MONTHLY_SERVICE_CHARGES = "Future monthly service charge:";
        private Locator futureMonthlyChargesLabel = locator(pwXPath("//p[contains(text(), 'Future monthly service charge:')]"));

        private Locator debitCardServiceChargeLabel = locator(pwXPath("//li[contains(.,'Debit card')]"));

        private Locator creditCardServiceChargeLabel = locator(pwXPath("//li[contains(.,'Credit card')]"));


    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public PolicyPaymentBasePage() throws Exception {
    }

    public boolean clickSetUpPaymentButton() throws Exception {
        waitAndClickElement(setUpPaymentMethodButton);
        waitForSpinnerToBeGone();
        wait.until(Conditions.clickable(addPaymentMethodContainerCloseIcon));
        waitForUiSettled();
        return addPaymentMethodDialogContainer.isVisible();
    }

    public boolean clickSetUpPaymentButtonSideSheet() throws Exception {
        List<Locator> setUpPaymentMethodElements = locators(pwXPath("//button[contains(.,'Set up payment method')]"));
        waitAndClickElement(setUpPaymentMethodElements.get(1));
        wait.until(Conditions.clickable(addPaymentMethodContainerCloseIcon));
        waitForUiSettled();
        return addPaymentMethodDialogContainer.isVisible();
    }

    public boolean closeAddPaymentMethodContainer(Boolean isComingFromChangePayment) throws Exception {
        waitAndClickElement(addPaymentMethodContainerCloseIcon);
        if (isComingFromChangePayment) {
            return true;
        }
        return setUpPaymentMethodButton.isEnabled();
    }

    public boolean goBackToHowWouldYouLikeToPayPage() throws Exception {
        back();
        return isExpectedTextDisplayed(howWouldYouLikeToPay, HOW_WOULD_YOU_LIKE_TO_PAY);
    }

    public boolean isSixMonthTermPaymentAmountDisplayed(String payPlanDescription, String htmlElement, AppStore retrieveQuoteResponseSessionStorage) throws Exception {
        String downPayment = getDownPayment(retrieveQuoteResponseSessionStorage, payPlanDescription);
        Locator sixTermPaymentAmount = listOfFullAmountLocators(downPayment, htmlElement, true).get(0);
        return sixTermPaymentAmount.isVisible();
    }

    public boolean isPolicyFeeAmountDisplayedAuto(String htmlElement) throws Exception {
        AppStore.VerifyResponse verifyResponse = getAutoVerifyRateResponse();
        String policyFee = verifyResponse.getPolicyFee().getAmount();
        Locator administrativeFeeAmount = listOfFullAmountLocators(policyFee, htmlElement, true).get(0);
        return administrativeFeeAmount.isVisible();
    }

    public void isDueTodayAmountDisplayedAuto(String payPlanDescription, FarmersSoftAssert fsa) throws Exception {
        String policyFee = getAutoVerifyRateResponse().getPolicyFee().getAmount();
        String onePayDownPayment = getDownPayment(getSessionStorageAppStore(), payPlanDescription);
        Double dueToday = Double.parseDouble(policyFee) + Double.parseDouble(onePayDownPayment);
        Locator dueTodayAmountElement = locator(pwXPath("//div[contains(@class,'autopay-details-bottom-row')]/span[contains(.,'$')]"));
        fsa.assertEquals(getTextFromElement(dueTodayAmountElement), String.format("$%,.2f", dueToday), "Due today amount verification for " + payPlanDescription);
    }

    public boolean isAddButtonTextCorrect() {
        return isExpectedTextDisplayed(addButton, ADD_BUTTON);
    }

    public void clickAddButton() throws Exception {
        try {
            scrollAndClickOnElement(addButton);
            waitForSpinnerToBeGone();
        } catch (Exception e) {
            Log.info("Add button not clicked");
        }
    }


    public boolean isAddPaymentMethodLabelCorrect() {
        return isExpectedTextDisplayed(waitElementBeVisible(addPaymentMethodLabel), ADD_PAYMENT_METHOD_LABEL);
    }

    public boolean isAddBankHeaderCorrect() {
        return isExpectedTextDisplayed(addBankHeader, ADD_BANK);
    }

    public boolean isBankPaymentButtonTextCorrect() {
        isOnPaymentAdditionSideSheet();
        if(isElementVisible(bankPaymentButton, 5)){
            return isExpectedTextDisplayed(bankPaymentButton, BANK_PAYMENT_BUTTON_TEXT);
        } else {
            return isExpectedTextDisplayed(waitElementBeVisible(bankButton), BANK_BUTTON_TEXT);
        }
    }

    public boolean isBankButtonTextCorrect() {
        return isExpectedTextDisplayed(waitElementBeVisible(bankButton), BANK_BUTTON_TEXT);
    }

    public boolean isDebitCreditCardButtonTextCorrect() {
        return isExpectedTextDisplayed(debitCreditCardButton, DEBIT_CREDIT_CARD_BUTTON);
    }

    public boolean isCardButtonTextCorrect() {
        return isExpectedTextDisplayed(cardButtonIframe, CARD_BUTTON);
    }

    public void clickBankTransferButton() {
        waitForUiSettled();
        scrollAndClickOnElement(bankPaymentButton);
    }

    public void clickDebitCreditCardButton() {
        waitAndClickElement(debitCreditCardButton);
    }

    public void clickCardButton() {
        waitAndClickElement(cardButton);
    }

    public String fullNameFromCustomerData(CustomerData customerData) {
        return customerData.getFirstName() + " " + customerData.getLastName();
    }

    public boolean validateOpeningLinksInNewTab() throws Exception {
        boolean isTitleFound = false;
    	int numberOfElements = listOfLinksToClick.size();
        Page mainWindow = currentPage();
        for (int i = 0; i< numberOfElements; i++){
            clickElement(listOfLinksToClick.get(i));
            waitForUiSettled();
            ArrayList<Page> tabHandles = new ArrayList<>(pages());
            for (Page eachHandle : tabHandles) {
                switchToPage(eachHandle);
                if (List.of(FIREFOX, SAFARI).contains(Property.getBrowser())) {
                    waitForUiSettled();
                }
                // Check title of each opened tab
                if (!page().title().trim().equals(FARMERS_FAST_QUOTE)) {
                    if (page().title().equalsIgnoreCase(listOfTabTitles.get(i))) {
                        closeCurrentPage();
                        switchToPage(mainWindow);
                        isTitleFound = true;
                    }
                }
            }
        }
        return isTitleFound;
    }

    // validate if links are enabled/displayed
    public boolean validateClickableLinksPaymentPage() {
        boolean isLinkDisplayedAndEnabled = false;
    	int numberOfElements = listOfLinksToClick.size();
        for (int i = 0; i< numberOfElements; i++){
            isLinkDisplayedAndEnabled = listOfLinksToClick.get(i).isVisible() && listOfLinksToClick.get(i).isEnabled();
        }
        return isLinkDisplayedAndEnabled;
    }

    public boolean isByClickingCompletePurchaseLabelCorrect() {
        return isExpectedTextDisplayed(waitElementBeVisible(byClickingCompletePurchaseLabel), BY_CLICKING_COMPLETER_PURCHASE);
    }

    public boolean isReadAndAgreedBulletPointOneCorrect() {
        return isExpectedTextDisplayed(readAndAgreedToTheBulletPointOne, READ_AND_AGREED_TO_THE_BULLET_ONE);
    }

    public boolean isIfDoNotAgreeWithTermsAndConditionLabelCorrect() {
        return isExpectedTextDisplayed(ifDoNotAgreeWithTermsAndConditionLabel, IF_DO_NOT_AGREE_WITH_TERMS);
    }

    public boolean isCompletePurchaseButtonTextMatching() {
        return isExpectedTextDisplayed(completePurchaseButton, COMPLETE_PURCHASE_BUTTON);
    }

    public void clickCompletePurchaseButton() throws Exception {
        scrollToBottomOfPage();
        waitElementBeVisibleClickable(completePurchaseButton);
        clickElement(completePurchaseButton);
        waitForSpinnerToBeGone();
    }
    public boolean isPaymentMethodAlreadyAddedMsgCorrect() {
        wait.until(Conditions.visible(paymentMethodAlreadyAdded));
        return isExpectedTextDisplayed(paymentMethodAlreadyAdded, PAYMENT_METHOD_ALREADY_ADDED_ERROR);
    }

    public boolean isReadAndAgreedBulletPointTwoMonthlyPayCorrect() {
        return isExpectedTextDisplayed(readAndAgreedToTheBulletPointTwoMonthlyPay, READ_AND_AGREED_TO_THE_BULLET_TWO_MONTHLY_PAY);
    }

    public boolean isReadAndAgreedBulletPointTwoCorrect() {
        return isAnyExpectedTextDisplayed(readAndAgreedToTheBulletPointTwo, READ_AND_AGREED_TO_THE_BULLET_TWO, READ_AND_AGREED_TO_THE_BULLET_TWO_ALTERNATE);
    }

    public boolean isDueTodayCorrect() {
        return isExpectedTextDisplayed(dueTodayLabel, DUE_TODAY_LABEL);
    }

    public boolean isSetUpPaymentMethodCorrect() {
        return isExpectedTextDisplayed(setUpPaymentMethodButton, SET_UP_PAYMENT_METHOD);
    }

    public boolean isOnPayInFullPage() {
        return isElementVisible(payInFullHeader, 25);
    }

    public boolean isPayInFullHeaderCorrect() {
        return isExpectedTextDisplayed(payInFullHeader, PAY_IN_FULL_HEADER);
    }

    public boolean isSelectPreferredPaymentCorrect() {
        return isExpectedTextDisplayed(selectPreferredPaymentMethod, ADD_YOUR_PREFERRED_PAYMENT_METHOD1);
    }

    public boolean isBankDebitCreditPaymentCorrect() {
        return isExpectedTextDisplayed(useBankDebitCreditCard, USE_BANK_DEBIT_CREDIT);
    }

    public boolean isNoServiceChargeCorrect() {
        return isExpectedTextDisplayed(noServiceChargesWhenPayInFull, NO_SERVICE_CHARGES_WHEN_YOU_PAY_IN_FULL);
    }

    public void validateADA_PayInFullPage() throws Exception {
        if (!isADATestingEnabled()) return;

        isOnPayInFullPage();
        performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
        PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
        policyPaymentBasePage.clickSetUpPaymentButton();
        performADATesting(this.getClass().getSimpleName() + "_AddPaymentMethodBankPaymentSideSheet", MARKETING_IT, ACE_AUTO);
        policyPaymentBasePage.clickDebitCreditCardButton();
        performADATesting(this.getClass().getSimpleName() + "_AddPaymentMethodDebitCreditCardPaymentSideSheet", MARKETING_IT, ACE_AUTO);
        policyPaymentBasePage.closeAddPaymentMethodContainer(false);
    }

    public boolean isMonthlyAutoPayBankHeaderCorrect() {
        return isExpectedTextDisplayed(waitElementBeVisible(monthlyAutoPayBankHeader), MONTHLY_AUTO_PAY_BANK_HEADER);
    }

    public boolean isMonthlyAutoPayCardHeaderCorrect() {
        return isExpectedTextDisplayed(monthlyAutoPayCardHeader, MONTHLY_AUTO_PAY_CARD_HEADER);
    }

    public boolean isMonthlyDirectBillHeaderCorrect() {
        return isExpectedTextDisplayed(monthlyDirectBillHeader, MONTHLY_DIRECT_BILL);
    }

    public boolean isMonthlyAutoPayHeaderCardCorrect() {
        return isExpectedTextDisplayed(monthlyAutoPayBankHeader, MONTHLY_AUTO_PAY_BANK_HEADER);
    }

    public boolean isFirstMonthlyPaymentLabelCorrect() {
        return isExpectedTextDisplayed(firstMonthlyPaymentLabel, FIRST_MONTHLY_PAYMENT);
    }

    public boolean isOneTimeFeeLabelCorrect() {
        return isExpectedTextDisplayed(feesLabel, FEES_LABEL);
    }

    public boolean isSelectPreferredPaymentLabelCorrect() {
        return isExpectedTextDisplayed(selectPreferredPaymentLabel, SELECT_PREFERRED_PAYMENT_LABEL);
    }

    public boolean isBankPaymentRadioButtonDisplayed() {
        return bankPaymentRadiobutton.isVisible();
    }

    public boolean isBankPaymentRadioButtonDisplayedAlternative() {
        return isElementDisplayed(bankPaymentRadiobuttonAlternate, 15);
    }

    public boolean isBankPaymentLabelCorrect(String expectedText) {
        return getTextFromElement(bankPaymentLabel).equals(expectedText);
    }

    public boolean isCardPaymentLabelCorrect(String expectedText) {
        return getTextFromElement(cardPaymentLabel).equals(expectedText);
    }

    public void isBankAccountServiceChargesAmountCorrect(String expectedText, FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(inServiceChargesElement), expectedText, "Bank payment service amount verification");
    }

    public boolean isBankPaymentRadioButtonSelected() {
        return getAttributeData(bankPaymentRadiobutton, CLASS).contains(RADIO_BUTTON_CHECKED);
    }

    public boolean isCardPaymentRadioButtonDisplayed() {
        return isElementDisplayed(cardPaymentRadiobuttonAlternative, 15);
    }

    public boolean isCardPaymentRadioButtonDisplayedAlternative() {
        return isElementDisplayed(cardPaymentRadiobuttonAlternative, 15);
    }

    public boolean isCardPaymentRadioButtonSelected() {
        return getAttributeData(cardPaymentRadiobuttonAlternative, CLASS).contains(RADIO_BUTTON_CHECKED);
    }

    public boolean isFutureMonthlyChargesLabelCorrect() {
        return isExpectedTextDisplayed(futureMonthlyChargesLabel, FUTURE_MONTHLY_SERVICE_CHARGES);
    }

    public void isDebitCardAdministrativeFeeLabelCorrect(String expectedText, FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(debitCardServiceChargeLabel), expectedText, "Monthly Autopay page, Future service charge for Debit card verification");
    }

    public void isCreditCardAdministrativeFeeLabelCorrect(String expectedText, FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(creditCardServiceChargeLabel), expectedText, "Monthly Autopay page, Future service charge for Credit card verification");
    }

    public void selectCardPaymentRadioButtonHRC() throws Exception {
        waitForUiSettled();
        clickOnHiddenElement(changeCardPaymentRadiobutton);
    }

    public void selectCardPaymentRadioButtonAlternative() throws Exception {
        waitAndClickElement(cardPaymentRadiobuttonLabel);
    }

    public void selectBankPaymentRadioButton() {
        if (!isElementDisplayed(bankPaymentRadiobutton, 5)) {
            waitForUiSettled();
        }
        scrollToElement(bankPaymentRadiobutton);
        clickElement(bankPaymentRadiobutton);
    }
    public void selectBankPaymentRadioButtonInIframe() {
        if (!isElementDisplayed(bankPaymentRadiobuttonInIframe, 5)) {
            waitForUiSettled();
        }
        scrollToElement(bankPaymentRadiobuttonInIframe);
        clickElement(bankPaymentRadiobuttonInIframe);
    }

    public void selectBankPaymentRadioButtonHRC() throws Exception {
        waitForUiSettled();
        clickOnHiddenElement(changeBankPaymentRadiobutton);
    }

    public void selectBankPaymentRadioButtonAlternate() throws Exception {
        waitAndClickElement(bankPaymentRadiobuttonLabel);
    }

    public void selectBankPaymentRadioButtonSideSheet() throws Exception {
        waitAndClickElement(bankPaymentRadiobuttonSideSheet);
    }

    public boolean isOnAutoPolicyPaymentMonthlyBankPage() {
        return isElementVisible(monthlyAutoPayCardHeader, 25);
    }

    public void validateADA_AutoPolicyPaymentMonthlyPay() {
        isOnAutoPolicyPaymentMonthlyBankPage();
        if (isADATestingEnabled()) {
            performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
        }
    }

    public boolean isPolicyFeeSideBarHeaderCorrect() {
        return isExpectedTextDisplayed(feeSideBarHeader, FEES);
    }

    public void clickSetUpPaymentButtonBundle() throws Exception {
        waitElementBeVisible(setUpPaymentMethodButton);
        waitAndClickElement(setUpPaymentMethodButton);
    }

    protected void switchToBankPaymentToggleInPaymentSideSheet() {
        if (isElementVisible(bankButton, 1)) {
            scrollAndClickOnElement(bankButton);
        } else {
            scrollAndClickOnElement(bankPaymentButton);
        }
    }

    protected boolean isOnPaymentAdditionSideSheet() {
        return isElementVisible(addPaymentMethodDialogContainer, 3);
    }

}
