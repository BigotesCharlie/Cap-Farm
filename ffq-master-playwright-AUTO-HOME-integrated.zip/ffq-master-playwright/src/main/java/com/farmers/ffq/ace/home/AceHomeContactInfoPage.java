package com.farmers.ffq.ace.home;


import com.microsoft.playwright.Locator;
import com.farmers.ffq.ace.hrc.common.AceHRCContactInfoBasePage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeContactInfoPage extends AceHRCContactInfoBasePage {

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public AceHomeContactInfoPage() throws Exception {
        super();
    }

    public void fillOutWildfireRiskReductionCA(String wildfireRiskReduction) throws Exception {
        if (isElementDisplayed(pwXPath(WILDFIRE_RISK_REDUCTION_XPATH))) {
            if (!wildfireRiskReduction.isBlank()) {
                if (!getAttributeData(wildfireRiskMatButtonToggleYes, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED)) {
                    clickElement(wildfireRiskButtonToggleYes);
                    enterWildfireRiskReductionOptions(wildfireRiskReduction);
                }
            } else {
                if (!getAttributeData(wildfireRiskMatButtonToggleNo, CLASS).contains(MAT_TOGGLE_BUTTON_CHECKED)) {
                    clickElement(wildfireRiskButtonToggleNo);
                }
            }
        }
    }

    public void enterWildfireRiskReductionOptions(String options) throws Exception {
        List<String> listOptions = Stream.of(options.split(COMMA)).map(String::trim).collect(Collectors.toList());
        boolean updated = false;
        for (String option: listOptions) {
            Locator weMatCheckbox = locator(pwXPath(String.format(WILDFIRE_RISK_REDUCTION_MAT_CHECKBOX_XPATH,option)));
            if (getAttributeData(weMatCheckbox, CLASS).contains(MAT_CHECKBOX_DISABLED)) {
                continue;
            }
            if (!getAttributeData(weMatCheckbox, CLASS).contains(MAT_CHECKBOX_CHECKED)) {
                Locator weOption = locator(pwXPath(String.format(WILDFIRE_RISK_REDUCTION_TEMPLATE_XPATH, option)));
                waitAndClickElement(weOption);
                updated = true;
            }
        }
        if (updated) {
            waitAndClickElement(saveButtonWildfireRisk);
        } else {
            waitAndClickElement(closeWildfireSideSheet);
            if (isElementDisplayed(buttonNoChangesOk,2)) {
                waitAndClickElement(buttonNoChangesOk);
            }
        }
    }

    public void fillOutContactInfoPage(ApplicantAceHome applicant) throws Exception {
        enterPolicyStartDate(applicant);
        enterFireHydrantData(applicant);
        if (applicant.getStateCode().equals(CA) && !applicant.getWildFireRisk().isBlank()) {
            fillOutWildfireRiskReductionCA(applicant.getWildFireRisk());
        }
        fillOutBundleAndSave(applicant, HOME);
        enterEmailIdAndPhoneNumberInContactInfoPage(applicant);
        clickOnAgreeAndSubmitButton();
    }
}
