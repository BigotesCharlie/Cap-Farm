package com.farmers.ffq.common.pages;











import com.microsoft.playwright.options.ViewportSize;
import com.farmers.framework.playwright.PlaywrightActions;
import com.farmers.framework.playwright.Keys;
import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.TimeoutError;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.home.pages.YourInfoPageHome;
import com.farmers.ffq.integration.RallyContext;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.ImageComparisonHelper;
import com.farmers.ffq.utils.MyRunnable;
import com.farmers.framework.AutomationFramework;
import com.farmers.framework.Property;
import com.farmers.framework.playwright.PlaywrightArtifacts;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.testng.Assert;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.farmers.ffq.utils.GlobalVariables.*;
import static com.farmers.framework.saucelabs.SauceRest.getPublicJobLink;
/**
 * Farmers Fast Quote (FFQ) - Base Page for FFQ + Top Navigation Menu.
 */
public class BasePage extends AutomationFramework {

    protected static ConcurrentHashMap<String, ApplicantRetQuote> returningQuoteConcurrentHashMap = new ConcurrentHashMap<>();
    protected static final String DROPDOWN_ENTRY_XPATH = DROPDOWN_OPTIONS_XPATH + "[contains(text(), \"";
    private static List<String> errorList = new ArrayList<>();
    private static final int MAX_RANDOM_STRING_LENGTH = 8;
    private static final int MYTHREADS = 50;
    private static final int ONE_INT = 1;
    private static final String REDESIGNED_QUOTE_NUMBER_XPATH = "//div[contains(@class,'sidepanel-container')]//div[@class='active-page-title ng-star-inserted']";
    private static final int ZERO_INT = 0;
    private static final String VISIBILITY = "visibility";
    private static final String HIDDEN = "hidden";
    protected static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    protected static final String SAVE_QUOTE_BUTTON_XPATH = "//button[contains(.,'Save quote')]";
    public static final String BRISTOL_WEST_LOGO_ACE_XPATH = "//img[@alt='Bristol West logo']";
    private static final String STEPPER_DESKTOP_XPATH = "//div[@class='tui-desktop-nav-stepper']//div[contains(@class,'tui-nav-stepper-container')]";
    private static final String STEPPER_MOBILE_XPATH = "//div[@class='tui-mobile-nav-stepper']//div[contains(@class,'tui-nav-stepper-container')]";

        private Locator desktopStepper = locator(pwXPath(STEPPER_DESKTOP_XPATH));

        private Locator mobileStepper = locator(pwXPath(STEPPER_MOBILE_XPATH));

    private Random randomNumberGenerator = new Random();
    protected ImageComparisonHelper imageComparisonHelper = new ImageComparisonHelper();

    public static volatile Map<String, String> currentMap = null;
    public static Object lockbox = new Object();
    public static Map<String, String> newMap = Collections.synchronizedMap(new HashMap<String, String>());

    private static final String CLOSE_SURVEY_XPATH = "//div[contains(@class,'QSIPopOver')]//img[contains(@src,'close-btn')]";
        private Locator closeModalSurveyButton = locator(pwXPath(CLOSE_SURVEY_XPATH));

        protected Locator headerLogo = locator(pwId("logoPlaceHolder"));

        private Locator zipCodeErrorMessage = locator(pwId("ZipCodeError"));

        private Locator legacySpinner = locator(pwClass(LEGACY_WAIT_DIALOG_CLASSNAME));

        private Locator waitForResponseSpinner = locator(pwId(WAIT_QUOTE_READY_ID));

    private static final String RECALCULATING_POPUP_ID = "jsAlert99_popup";
        private Locator recalculatingPopup = locator(pwId(RECALCULATING_POPUP_ID));

    private static final String RECALCULATING_POPUP_CLASS = "quoteChangecalculate";
        private Locator recalculatingAndProcessingPopup = locator(pwClass(RECALCULATING_POPUP_CLASS));

        private static Locator sideNavBar = locator(pwXPath("//app-navigation-drawer"));

    private static final String PAGE_LOADING_MESSAGE_ID = "nonRedsnMesg";
        private Locator pageIsLoadingMessage = locator(pwId(PAGE_LOADING_MESSAGE_ID));

    private static final String ONEUI_SPINNER_XPATH = "//mat-progress-spinner";
        private Locator oneuiSpinner = locator(pwXPath(ONEUI_SPINNER_XPATH));

    private static final String ACE_SPINNER_SECTION_XPATH = "//div[contains(@class, 'tui-spinner-center-content')]";
        private Locator aceSpinnerSection = locator(pwXPath(ACE_SPINNER_SECTION_XPATH));

    private static final String ACE_REVIEW_QUOTE_SKELETON_XPATH = "//app-loading-skeleton";
        protected Locator reviewQuoteSkeleton = locator(pwXPath(ACE_REVIEW_QUOTE_SKELETON_XPATH));

    private static final String ACE_ONE_MOMENT_TITLE_XPATH = "//h1[contains(text(),'One moment, please')]";
        protected Locator oneMomentPleasePage = locator(pwXPath(ACE_ONE_MOMENT_TITLE_XPATH));

        protected Locator closeIconMB = locator(pwXPath("//mat-icon[contains(text(), 'close')]"));
    private static final Random randomNumber = new Random();

        protected Locator continueToFGIA = locator(pwXPath("//button[contains(@class, 'auto-module_continue-to-bw-button-primary')]"));

    protected static final String CONTINUE_TO_DIGITAL_MONETIZATION_BUTTON_XPATH = "//button[contains(@class, 'dialog__info-dialog-button-no-thanks')]";
        protected Locator continueToDigitalMonetization = locator(pwXPath(CONTINUE_TO_DIGITAL_MONETIZATION_BUTTON_XPATH));

        protected Locator buttonContinue = locator(pwXPath("//button[contains(text(),'Continue') or contains(text(),'Agree')][not(@hidden)]"));

        protected Locator startCheckOutButton = locator(pwXPath("//button[contains(@class,'tui-btn tui-quote-presentment-button')]"));

        protected Locator qualtricsPopUpSwitcher = locator(pwCss("div[id='aceIndicator']"));

        protected Locator listOfQualtricsCloseButtons = locator(pwXPath("//img[contains(@src,'qualtrics') and contains(@src,'close-btn')]"));

        protected Locator snackBar = locator(pwId("snackbarDesc"));
    private static final String SAVE_QUOTE_LINK_XPATH = "//div/button[contains(@id,'save-quote-link')]";
        protected Locator saveQuoteTextContent = locator(pwXPath(SAVE_QUOTE_LINK_XPATH));
        protected Locator saveQuoteModalHeader = locator(pwXPath("//div[@class='tui-save-quote-modal']//h4"));

        protected Locator saveQuoteModalCloseIcon = locator(pwXPath("//a[@class='close-container']//mat-icon"));

        protected Locator saveQuoteModalQuoteNumber = locator(pwXPath("//div[@class='tui-save-quote-modal']//h3"));

        protected Locator saveQuoteModalQuoteNumberText = locator(pwXPath("//div[@class='modal-content']//p"));

        protected Locator saveQuoteModalInfoText = locator(pwXPath("//tui-save-quote-modal//p[@class='modal-info']/following-sibling::p"));

        protected Locator saveQuoteModalEmailFieldHeader = locator(pwXPath("//tui-save-quote-modal//p[@class='tui-field-label']"));

        protected Locator saveQuoteModalEmailInputField = locator(pwXPath("//tui-save-quote-modal//input"));

        protected Locator saveQuoteModalEmailFieldLabel = locator(pwXPath("//div[contains(@class,'modal-form')]//mat-label"));

        protected Locator saveQuoteModalSubmitButton = locator(pwCss("button[class='tui-btn tui-btn-primary auto-add-vehicle-submit__button']"));
        protected Locator discountAddedText = locator(pwXPath("//div[@class='discount-description']/p[1]"));
        protected Locator reviewDiscountsButton = locator(pwXPath("//div[@class='discount-description']//p[@role='button']"));
        protected Locator closeIcon = locator(pwXPath("//mat-icon[contains(.,'close')]"));
        protected Locator discounts = locator(pwXPath("//span[contains(@class,'discount-name')]"));
        protected Locator discountsSidesheetAppliedText = locatorAny(pwXPath("//app-home-discount-sidesheet//div[@id='appliedDiscounts']"), pwXPath("//app-auto-discount-sidesheet//div[@id='appliedDiscounts']"));
        protected Locator discountPiggyBankImage = locatorAny(pwXPath("//app-home-discount//img"), pwXPath("//app-auto-discount//img"));
        protected Locator discountsSidesheetTitle = locatorAny(pwXPath("//app-home-discount-sidesheet//h1"), pwXPath("//app-auto-discount-sidesheet//h1"));
        protected Locator discountsSidesheetSubTitle = locatorAny(pwXPath("//app-home-discount-sidesheet//p[contains(@class,'tui-input-text')]"), pwXPath("//app-auto-discount-sidesheet//p[contains(@class,'tui-input-text')]"));
    private static final String QUOTE_NUMBER_XPATH = "//div[contains(@class,'auto-agent-details__save-quote')]";
        protected Locator quoteNumber = locator(pwXPath(QUOTE_NUMBER_XPATH));
        protected Locator emailInputFieldErrorMessage = locator(pwXPath("//tui-save-quote-modal//mat-error"));
    protected LocalDate currentDate = getTodayDate();
    protected String formattedTodayDate = currentDate.format(dateTimeFormatter);
    protected String formattedTomorrowDate = currentDate.plusDays(1).format(dateTimeFormatter);
    protected String formattedDateAfterTwoMonths = currentDate.plusDays(59).format(dateTimeFormatter);
    protected String formattedDateAfterAMonth = currentDate.plusDays(30).format(dateTimeFormatter);

    protected static final String AGENT_IMAGE_CLASS_NAME = "agent-image";
    	protected Locator agentImage = locator(pwClass(AGENT_IMAGE_CLASS_NAME));

    	protected Locator agentSectionYourAgent = locator(pwXPath("//div[contains(@class,'tui-agent-box-column-2')]/div/div[1]"));

    	protected Locator agentSectionAgentName = locator(pwXPath("//div[contains(@class,'tui-agent-box-column-2')]/div/div[2]"));

        private Locator agentMailID = locator(pwXPath("//app-agent-details//a[contains(@aria-label, 'emailId')]"));

        private Locator agentAddress = locator(pwXPath("//div[contains(@class,'agent-details-container')]/p/a[@target = '_blank']"));

    	protected Locator agentPhoneNumber = locator(pwXPath("//a[contains(@aria-label,'Contact farmers representative') and contains(@class,'footer')]"));

        private Locator emailLinkDesktop = locator(pwId("emailLink"));
        private Locator emailLinkMobile = locator(pwXPath("//button[contains(text(),'Email this quote')]"));
        private Locator linkCloseEmailSnackBar = locator(pwLinkText("Done"));
        private Locator notAbleToOfferBundleQuoteMessageIcon = locator(pwXPath("//mat-card[contains(@class,'limited-message-card-section')]//mat-icon"));
        private Locator notAbleToOfferBundleQuoteCard = locator(pwXPath("//div[contains(@class,'limited-message-card')]"));
        private Locator notAbleToOfferBundleQuoteMessage = locator(pwXPath("//div[contains(@class,'limited-message-card-description')]//p[1]"));
        private Locator weCanStillOfferThisLOBQuoteMessage = locator(pwXPath("//div[contains(@class,'limited-message-card-description')]//p[2]"));
        private Locator addressSelection = locator(pwXPath("//div[contains(@id, 'mat-autocomplete')]/mat-option"));
        protected Locator agreeAndSubmitButton = locator(pwXPath("//button[contains(text(),'Agree and submit')]"));

        protected Locator expandQuoteCardButton = locator(pwXPath("//mat-icon[@aria-label='expand quote card']"));

    public boolean isSnackBarMessageDisplayed(String message) {
        boolean messageFound = false;
        try {
            String actualMessage = getTextFromElement(waitElementBeVisible(snackBar, 5));
            messageFound = actualMessage.contains(message) || actualMessage.equals(message);
            if (!messageFound) {
                Log.warn("Snackbar message-> Expected: [" + message + "]  Actual: [" + actualMessage + "]");
            }
        } catch (Exception e) {
            Log.warn("SnackBar was not found for message text: " + message);
        }
        return messageFound;
    }

    public void clickContinueButton() throws Exception {
        scrollAndClickOnElement(buttonContinue);
        testStep("Clicked continue button at " + page().url(), false);
    }

    public void clickAgreeAndSubmitButton() throws Exception {
        scrollAndClickOnElement(agreeAndSubmitButton);
        testStep("Clicked Agree and submit button at " + page().url(), false);
    }

    public static String generateEmailAddress() {
        return generateEmailAddress("yopmail.com");
    }

    public static String generateEmailAddress(String domain) {
        return generateString().toLowerCase() + randomNumber.nextInt(1000) + "@" + domain;
    }

    public static String generateString() {
        String randomString = UUID.randomUUID().toString().replace("-", EMPTY_STRING).replaceAll("\\d*", EMPTY_STRING);
        if (randomString.length() <= ONE_INT) {
            randomString = "AA";
        }
        if (randomString.length() > MAX_RANDOM_STRING_LENGTH) {
            randomString = randomString.substring(ZERO_INT, MAX_RANDOM_STRING_LENGTH);
        }
        return randomString.substring(ZERO_INT, ONE_INT).toUpperCase(Locale.US) + randomString.substring(ONE_INT).toLowerCase(Locale.US);
    }

    public static String generateFakeAddress() {
        return randomNumber.nextInt(5000) + " Main St";
    }

    public static void sendGetRequest(Locator element) {
        String url = (isAttributePresent(element, HREF)) ? element.getAttribute(HREF) : element.getAttribute(SRC);
        if (isValidToTest(url)) {
            try (CloseableHttpClient httpClient = HttpClientBuilder.create().build()) {
                HttpResponse response = httpClient.execute(new HttpGet(url));
                int code = response.getStatusLine().getStatusCode();
                if (code != 200 && code != 204 && code != 403) {
                    errorList.add(url);
                }
            } catch (IOException e) {
                Log.error("Exception processing [" + url + "]");
                Log.error(e.toString());
            }
        }
    }

    /**
     * Returns a date string with the specified periods added to now().
     * <p> period is in the form of [-]P{N}{periodType}
     * <p> where:
     * <ul>
     * <li> - : Specify minus to subtract, nothing to add
     * <li> N : Number of periods to add/subtract to the current date
     * <li> periodType : One of D M Y to indicate days, months or years
     * </ul>
     * Example : add 5 days is P5D, subtract 3 months is -P3M
     * <p>
     *
     * @param period String representing the period to add or substract
     * @return String in the format of "MMddyyyy"
     */
    protected static String calculateDateFromPeriod(String period) {
        Log.debug("Calculating Date based on period: " + period);
        return LocalDate.now().plus(Period.parse(period)).format(DateTimeFormatter.ofPattern("MMddyyyy"));
    }

    /**
     * Calculate Date Of Birth From Age.
     *
     * @param age
     * @return MM/dd/yyyy String
     */
    public static String calculateDateOfBirthFromAge(int age) {
        Log.debug("Calculating Date Of Birth from Age " + age);
        int adjustment = age <= MAX_AGE ? -7 : 7;
        return LocalDate.now().plusDays(adjustment).minusYears(age).format(dateTimeFormatter);
    }

    public synchronized boolean findInCallStack(String searchForMethodName) {
        StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
        int stackSize = stackTraceElements.length;
        for (int index = 0; index < stackSize; index++) {
            if (stackTraceElements[index].getMethodName().contains(searchForMethodName)) {
                return true;
            }
        }
        return false;
    }

    protected static void checkAllURLsAndImages(List<Locator> allLinksAndImages) {
        Log.info("Verifying All url(s)...");
        Log.info("Total number of URLs AND Images found is " + allLinksAndImages.size());
        errorList.clear();
        ExecutorService executor = Executors.newFixedThreadPool(MYTHREADS);

        for (Locator element : allLinksAndImages) {
            Runnable worker = new MyRunnable(element);
            executor.execute(worker);
        }
        executor.shutdown();

        if (!executor.isTerminated()) {
            while (!executor.isTerminated()) {
                // Empty cycle to wait for thread to terminate
            }
        }

        if (!errorList.isEmpty()) {
            for (String link : errorList) {
                Log.info("Broken Url = " + link);
            }

            if (!errorList.stream().allMatch(item -> item.contains("javascript:void(0)"))) {
                errorList.removeIf(item -> item.contains("javascript:void(0)"));
                Assert.fail("Page contains " + errorList.size() + " broken url(s) " + errorList);
            }
        }
    }

    protected boolean checkImageIsDisplayed(Locator element) throws Exception {
        Boolean imageDisplayed = (Boolean) element.evaluate(
                "image => image.complete && typeof image.naturalWidth !== 'undefined' && image.naturalWidth > 0");
        if (!imageDisplayed) {
            Log.error("Image is not displayed: " + getAttributeData(element, "alt"));
        }
        return imageDisplayed;
    }

    protected static void clickOnHiddenElement(Locator element) throws Exception {
        executeScript("arguments[0].click();", element);
    }

    /**
     * Delete all cookies.
     */
    protected static void deleteAllCookies() throws Exception {
        Log.debug("Deleting all cookies");
        clearCookies();
    }

    /**
     * Find all links in the page.
     */
    protected static List<Locator> findAllURLsAndImages() throws Exception {
        Log.debug("Finding all links in the page");
        List<Locator> finalList = new ArrayList<>();

        for (Locator url : locators(pwTag("a"))) {
            String visibility = url.getAttribute(VISIBILITY);
            if (visibility != null && !visibility.equals(HIDDEN) && url.getAttribute(HREF) != null) {
                finalList.add(url);
            }
        }

        for (Locator image : locators(pwTag("img"))) {
            String visibility = image.getAttribute(VISIBILITY);
            if (visibility != null && !visibility.equals(HIDDEN)) {
                String imageSource = image.getAttribute(SRC);
                if (imageSource != null && !imageSource.equals(EMPTY_STRING)) {
                    finalList.add(image);
                }
            }
        }
        return finalList;
    }

    protected static String getHiddenText(Locator element) {
        try {
            return (String) executeScript("return (arguments[0]).innerText;", element);
        } catch (Exception e) {
            Log.info("Exception caught in javascript execution, could not get innerText");
            return EMPTY_STRING;
        }
    }

    /**
     * Scroll to element's location on the page and add additional vertical offset.
     */
    protected static void scrollToElementWithOffset(Locator element, int height) throws Exception {
        Log.debug("Moving to element's location on the page");
        scrollToElement(element);
        moveNumberOfPixelsVertically(height);
    }

    protected static Locator refreshElement(Locator element) {
        return Objects.requireNonNull(element, "element");
    }

    /**
     * Scroll to bottom of page.
     */
    protected static void scrollToBottomOfPage() {
        Log.debug("Scrolling to bottom of page");
        try {
            executeScript("window.scrollTo({top: window.outerHeight, left: 0, behavior: 'instant'})");
        } catch (Exception e) {
            Log.info(e.getMessage() + " exception caught when trying to scroll to bottom of page");
        }
    }

    /**
     * Scroll to specific element.
     *
     * @param element
     */
    protected static void scrollToElement(Locator element) {
        Log.debug("Scrolling specific element to top");
        try {
            executeScript("arguments[0].scrollIntoView(true);", element);
        } catch (Exception e) {
            Log.debug(e.getMessage() + " exception caught when trying to scroll to " + element.toString());
        }
    }

    protected static void scrollToElementBottom(Locator element) {
        Log.debug("Scrolling specific element to bottom");
        try {
            executeScript("arguments[0].scrollIntoView(false);", element);
        } catch (Exception e) {
            Log.debug(e.getMessage() + " exception caught when trying to scroll to the bottom of " + element.toString());
        }
    }

    protected static void scrollElementToMiddle(Locator element) {
        Log.debug("Scrolling specific element to middle of screen (rect-based)");
        try {
            executeScript(
                    "const el = arguments[0];" +
                            "const rect = el.getBoundingClientRect();" +
                            "const elCenterY = rect.top + (rect.height / 2);" +
                            "const vpCenterY = (window.innerHeight || document.documentElement.clientHeight) / 2;" +
                            "window.scrollBy({ top: (elCenterY - vpCenterY), left: 0, behavior: 'instant' });",
                    element
            );
        } catch (Exception e) {
            Log.debug(e.getMessage() + " exception caught when trying to scroll " + element + " to the middle of the screen");
        }
    }



    protected static void scrollElementToTop(Locator element) {
        Log.debug("Scrolling specific element to top of screen");
        try {
            executeScript(
                    "arguments[0].scrollIntoView({block:'start', inline:'nearest', behavior:'instant'});",
                    element
            );
        } catch (Exception e) {
            Log.debug(e.getMessage() + " exception caught when trying to scroll " + element.toString() + " to the top of the screen");
        }
    }


    /**
     * Scroll to top of page.
     */
    protected static void scrollToTopOfPage() {
        Log.debug("Scrolling to top of page");
        try {
            executeScript("window.scrollTo({top:0, left:0, behavior:'instant'})");
        } catch (Exception e) {
            Log.info(e.getMessage() + " exception caught when trying to scroll to top of page");
        }
    }

    /**
     * Set Attribute.
     *
     * @param attName
     * @param attValue
     * @param element
     */
    protected static void setAttribute(Locator element, String attName, String attValue) throws Exception {
        executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", element, attName, attValue);
    }

    /**
     * Verify All Tool Tips in Page.
     *
     * @param toolTips
     */
    protected static void verifyAllToolTipsInPage(Map<Locator, Locator> toolTips, Map<Locator, LinkedHashMap<Locator, String>> expToolTipsText) throws Exception {
        Log.debug("Verifying All Tool Tips in Page");
        for (Map.Entry<Locator, Locator> entry : toolTips.entrySet()) {

            conditionalWait(5).until(Conditions.visible(entry.getKey()));
            conditionalWait(5).until(Conditions.clickable(entry.getKey()));
            entry.getKey().click();

            conditionalWait(5).until(Conditions.visible(entry.getValue()));
            for (Map.Entry<Locator, String> expToolTips : expToolTipsText.get(entry.getKey()).entrySet()) {

                conditionalWait(5).until(Conditions.visible(expToolTips.getKey()));
                String toolTipText = expToolTips.getKey().innerText();
                Log.debug("Tool tips text: " + toolTipText);
                Assert.assertEquals(toolTipText, expToolTips.getValue(), "Tool tips text doesn't match " + expToolTips.getValue());
            }
            entry.getValue().click();
        }
        Log.info("Verifying Tool Tips size: Actual size is " + toolTips.size() + " Expected size is " + expToolTipsText.size());
        Assert.assertEquals(toolTips.size(), expToolTipsText.size(), "Actual size " + toolTips.size() + " match with expected size " + expToolTipsText.size());
    }

    protected static void verifyElementExpectedAttribute(List<Locator> elementList, Map<Locator, String> expectedAttributeValueStringMap, String attribute, FarmersSoftAssert fsa) {
        for (Locator element : elementList) {
            fsa.assertEquals(element.getAttribute(attribute), expectedAttributeValueStringMap.get(element), "Attribute: " + attribute + " check for " + element);
        }
    }

    protected void verifyElementExpectedContent(List<Locator> elementList, Map<Locator, String> expectedElementStringMap, FarmersSoftAssert fsa) {
        for (Locator element : elementList) {
            scrollToElement(element);
            String elementDescription = element.getAttribute("aria-label");
            fsa.assertEquals(getTextFromElement(element), expectedElementStringMap.get(element), "Verifying content of element " + (elementDescription.isEmpty() ? element : elementDescription));
        }
    }

    public String getTextFromElement(Locator element) {
        Objects.requireNonNull(element, "element");
        String text;
        try {
            text = element.innerText();
        } catch (PlaywrightException error) {
            text = element.textContent();
        }
        return removeSpecialCharFromString(text == null ? EMPTY_STRING : text);
    }

    //Use this method to remove text from children nodes
    public String getNodeText(Locator element) {
        String text = getTextFromElement(element);
        for (Locator child : element.locator(pwXPath("./*")).all()) {
            String textToRemove = getTextFromElement(child);
            if (!textToRemove.isBlank()) {
                text = text.replaceFirst(Pattern.quote(textToRemove), EMPTY_STRING);
            }
        }
        return removeSpecialCharFromString(text);
    }

    public String removeSpecialCharFromString(String inputString) {
        return inputString.replace("\u00a0", SPACE).replace("\u2013", "-").replace("\u2018", "'").replace("\u2019", "'").replace("\u201c", "\"").replace("\u201d", "\"")
                .replace("\u2022", EMPTY_STRING).replace("\u2026", "...")
                .replaceAll("\\p{Cntrl}", SPACE).replace("\r", SPACE).replaceAll("\\s{2,}", SPACE).strip();
    }

    protected void verifyHomeHelpLinks(List<Locator> links, LinkedHashMap<String, String> destinationsAndTitles) throws Exception {
        Page baseWindow = currentPage();
        int activeWindows = 1;
        for (Locator element : links) {
            scrollAndClickOnElement(element);
            boolean linkReached = false;
            conditionalWait(15).until(Conditions.pageCount(activeWindows + 1));
            List<Page> newHandles = pages();
            activeWindows = newHandles.size();
            for (Page handle : newHandles) {
                if (!baseWindow.equals(handle)) {
                    switchToPage(handle);
                    conditionalWait(Property.PAGELOADTIMEOUT).until(Conditions.textMatches(pwXPath("//title"), java.util.regex.Pattern.compile(".*\\S*")));
                    String currentURL = page().url();
                    String pageTitle = page().title();
                    for (Map.Entry<String, String> entry : destinationsAndTitles.entrySet()) {
                        String destinationURL = entry.getKey();
                        String expectedTitle = entry.getValue();
                        if (currentURL.contains(destinationURL)) {
                            Assert.assertTrue(pageTitle.contains(expectedTitle), "[" + pageTitle + "] page title should contain text [" + expectedTitle + "]");
                            linkReached = true;
                            closeCurrentPage();
                            activeWindows--;
                            break;
                        }
                    }
                }
            }
            switchToPage(baseWindow);
            if (!linkReached) {
                Log.error("*** destination not reached for " + element);
            }
        }
    }

    public static void writeDataToKnockoutLogFile(String data) {
        writeStringToFile(data + NEWLINE, KNOCKOUT_QUOTE_DATA_LOG_FILE);
    }

    private static String getStateCodeForQuote() throws Exception {
    	ObjectMapper mapper = new ObjectMapper();
    	mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    	String stateCode =  mapper.readValue((String) executeScript("return sessionStorage.getItem('appStore')"), AppStore.class).getData().getLandingStateCode();
    	if (stateCode == null) {
    		stateCode =  mapper.readValue((String) executeScript("return sessionStorage.getItem('appStore')"), AppStore.class).getError().getErrorInfo().getState();
    	}
    	return stateCode;
    }

    protected void writeDataToQuoteLogFile(String data) throws Exception {
    	writeStringToFile(data + NEWLINE, QUOTE_DATA_LOG_FILE + PERIOD + getStateCodeForQuote());
    }

    protected static void writeCreatedQuoteInformationToFile(String informationOnCreatedQuote) {
        writeStringToFile(informationOnCreatedQuote + NEWLINE, CREATED_QUOTES_FILE);
    }

    protected static void writeRatedQuoteInformationToFile(String informationOnRatedQuote) {
        writeStringToFile(informationOnRatedQuote + NEWLINE, RATED_QUOTES_FILE);
    }

    protected static void writeTestcaseState(String function, String state, List<String> listOfTestcases, String status) {
        try {
            String verdict = PASSED.equals(status)
                    ? com.farmers.ffq.integration.RallyService.VERDICT_PASS
                    : com.farmers.ffq.integration.RallyService.VERDICT_FAIL;
            String notes = function + " | state: " + state;
            com.farmers.ffq.integration.RallyService.getInstance().postResults(listOfTestcases, verdict, notes);
        } catch (Exception e) {
            Log.error("writeTestcaseState: Rally reporting error – " + e.getMessage(), false);
        }
    }

    protected static boolean isAttributePresent(Locator element, String attribute) {
        return element.getAttribute(attribute) != null;
    }

    private static boolean isValidToTest(String url) {
        return !(url.isEmpty() || url.contains("tel:") || url.contains("javascript:") || url.equalsIgnoreCase("http://null/") || url.contains("mailto:"));
    }

    private static void moveNumberOfPixelsVertically(int height) throws Exception {
        Log.debug("Moving " + height + " pixels vertically on the page");
        executeScript("window.scrollBy(0," + height + ")");
        executeScript("window.scrollBy(0, -2);"); //To force action in saucelabs
        executeScript("window.scrollBy(0, 2);"); //To force action in saucelabs
    }

    private static void writeStringToFile(String stringToWrite, String filePath) {
        try {
            Files.write(Paths.get(filePath), stringToWrite.getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void enterValueInField(String value, Locator textEntryField, String logMessage) {
        Log.debug(logMessage + SPACE + value);
        scrollToElement(textEntryField);
        scrollElementToMiddle(textEntryField);
        sendKeysToElement(textEntryField, value);
    }

    protected boolean enterGoogleAddress(Locator addressTextBox, String address, String city) {
        Log.info("Entering Address, selecting first google lookup option: " + address + SPACE + city);
        sendKeysToElement(addressTextBox, address + SPACE + city);
        try {
            waitForElements("//mat-option");
            return clickElement(addressSelection.nth(0)) && getAttributeData(addressTextBox, CLASS).contains("ng-valid");
        } catch (Exception e) {
            Log.info("Entering Address without lookup option selected");
            sendKeysToElement(addressTextBox, address);
            return false;
        }
    }

    private static final String ACCEPT_COOKIES_BUTTON_ID = "onetrust-accept-btn-handler";
        private Locator acceptTargetingCookiesButton = locator(pwId(ACCEPT_COOKIES_BUTTON_ID));

    public void acceptCookies() {
        if (isElementPresent(pwId(ACCEPT_COOKIES_BUTTON_ID), 5)) {
            clickElement(acceptTargetingCookiesButton);
        }
    }

        protected Locator closeModalButton = locator(pwId("popupClose"));

        protected Locator legacyQuoteNumber = locator(pwXPath("//*[@id='quoteBig']"));

        protected Locator summaryPopupOpen = locator(pwXPath("//*[@id='mSum' or contains(@class, 'summaryBtn')]"));

        protected Locator redesignedSummaryPopupButton = locator(pwId("header_menu-icon-mobile"));

        protected Locator summaryPopupClose = locator(pwXPath("//div[@id='summaryLB']//*[@id='mSum' or @id='summaryCloseBtn']"));

        protected Locator summaryLegacyQuoteNumber = locator(pwXPath("//*[@id='summaryquoteBig']"));

        protected Locator redesignedQuoteNumber = locator(pwXPath(REDESIGNED_QUOTE_NUMBER_XPATH));

    protected static final String YOURINFOPAGE_SMALL_SCREEN_NAVIGATION_LINK_XPATH = "//div[@class='navigationStepperTop']/div/a[1]";
        protected Locator yourInfoPageSmallScreenNavigationLink = locator(pwXPath(YOURINFOPAGE_SMALL_SCREEN_NAVIGATION_LINK_XPATH));


        protected Locator errorMessageElement = locator(pwClass("errorOff"));

    protected PlaywrightWait wait;

    protected int pageConditionTimeoutSeconds = (Property.PAGELOADTIMEOUT > 0) ? Property.PAGELOADTIMEOUT : 90;

    /**
     * Constructor.
     *
     * @throws Exception when page initialization fails
     */
    public BasePage() {
        // Page Objects are commonly constructed as test fields before TestNG invokes @BeforeMethod.
        // Locators resolve lazily against the per-test Page, so construction must not open a browser.
        wait = conditionalWait(pageConditionTimeoutSeconds);
    }

    public boolean isLegacyQuoteKnockout() {
        return (isElementPresentByXPath("//*[contains(text(), 'We apologize for the inconvenience')] | //*[contains(text(), 'special attention')]"));
    }

    /**
     * Click element without waiting.
     *
     * @param element
     * @throws Exception
     */
    protected boolean clickElement(Locator element) {
        Objects.requireNonNull(element, "element");
        try {
            element.click();
            return true;
        } catch (PlaywrightException firstFailure) {
            Log.warn("Standard Playwright click failed for " + element + ": " + firstFailure.getMessage());
            try {
                element.scrollIntoViewIfNeeded();
                element.click(new Locator.ClickOptions().setTrial(true));
                element.click();
                return true;
            } catch (PlaywrightException retryFailure) {
                Log.error("Unable to click element after actionability re-check: " + element, retryFailure);
                return false;
            }
        }
    }

    protected void clickAway() throws Exception {
        locator(pwXPath("//html")).click();
    }

    public String getElementValue(Locator webEl, String elementName) {
        try {
            scrollToElement(webEl);
        } catch (Exception e) {
            Log.info("Could not scroll to " + webEl.toString());
        }
        waitElementBeVisible(webEl);
        String elementValue = getAttributeData(webEl, VALUE);
        if (elementValue == null) {
            elementValue = EMPTY_STRING;
        }
        Log.info(elementName + SPACE + elementValue);
        return elementValue;
    }

    public String getAceQuoteNumberInThePage() {
        String quoteNum;
        try {
            waitElementBeVisible(quoteNumber);
            scrollElementToMiddle(quoteNumber);
            quoteNum = getTextFromElement(quoteNumber);
        } catch (PlaywrightException e) {
            Log.warn("Text was not available on the first locator evaluation; retrying once.");
            quoteNum = getTextFromElement(waitElementBeVisible(quoteNumber));
        }
        return quoteNum.replaceAll("\\D", EMPTY_STRING);
    }

    public String getLegacyQuoteNumber() {
        Log.info("Getting Quote Number");
        if (isSmallScreenUsed()) {
            closeSurveyDialog();
            waitAndClickElement(summaryPopupOpen);
            String quoteNumberOnPage = getTextFromElement(summaryLegacyQuoteNumber).replaceAll("\\D", EMPTY_STRING);
            closeSurveyDialog();
            waitAndClickElement(summaryPopupClose);
            longWaitForElementToBeGoneByXpath("//div[@id='summaryLB']//*[@id='mSum' or @id='summaryCloseBtn']");
            return quoteNumberOnPage;
        } else {
            waitElementBeVisible(legacyQuoteNumber);
            return getTextFromElement(legacyQuoteNumber).replaceAll("\\D", EMPTY_STRING);
        }
    }

    protected boolean isSmallScreenUsed() {
        return (isElementVisible(redesignedSummaryPopupButton, 2) && redesignedSummaryPopupButton.isEnabled()) ||
                (isElementVisible(summaryPopupOpen, 2) && summaryPopupOpen.isEnabled());
    }

    public String getRedesignedQuoteNumber() {
        boolean isMobile = isSmallScreenUsed();
        if (isMobile) {
            waitAndClickElement(redesignedSummaryPopupButton);
        }
        wait.until(Conditions.attached(pwXPath(REDESIGNED_QUOTE_NUMBER_XPATH)));
        String quoteNumber = getTextFromElement(redesignedQuoteNumber).replaceAll("\\D", EMPTY_STRING);
        if (isMobile) {
            waitAndClickElement(redesignedSummaryPopupButton);
        }
        if (quoteNumber.isEmpty()) {
            return "Quote number not found";
        } else {
            return quoteNumber;
        }
    }

    protected boolean isAutoSmallScreenUsed() {
        return isElementPresentByXPath(YOURINFOPAGE_SMALL_SCREEN_NAVIGATION_LINK_XPATH) && yourInfoPageSmallScreenNavigationLink.isVisible();
    }

    protected boolean isElementPresent(String elementXpath) throws Exception {
        return !locators(elementXpath).isEmpty();
    }

    protected boolean isElementDisplayed(String elementXpath) throws Exception {
        return locators(elementXpath).stream().anyMatch(Locator::isVisible);
    }


    /**
     * Check if element defined with the FindBy id strategy is found.<br>
     * ONLY USE IF ELEMENT WAS DEFINED USING id
     */
    protected boolean isElementPresentByID(Locator element) {
        return isElementPresent(element, LOWERCASE_ID, EMPTY_STRING);
    }

    /**
     * Check if element defined with the FindBy className strategy is found.<br>
     * ONLY USE IF ELEMENT WAS DEFINED USING className
     */
    protected boolean isElementPresentByClass(Locator element) {
        return isElementPresent(element, CLASS, EMPTY_STRING);
    }

    /**
     * Check if an element with the provided xpath is defined.<br>
     *
     * @param xpathValue : XPATH value used for find.
     */
    protected boolean isElementPresentByXPath(String xpathValue) {
        // closeModalButton is not used and prevents a lint rule fail
        return isElementPresent(closeModalButton, XPATH, xpathValue);
    }

    /**
     * Check if element is present using the specified locator and value.
     *
     * @param element : The element to search for in @id and @class cases
     * @param locator : ARIA_LABEL - use the element's @aria-label value for search<br>
     *                DATA_GTM - use the element's @data-gtm value for search <br>
     *                XPATH - use xpath to search for the element
     * @param value   : The string value of the element's aria-label or data-gtm property or the xpath to the element being searched for
     */
    private boolean isElementPresent(Locator element, String locator, String value) {
        boolean elementFound = false;
        try {
            StringTokenizer tokens = new StringTokenizer(element.toString(), ":");
            String locatorData = EMPTY_STRING;
            while (tokens.hasMoreTokens()) {
                locatorData = tokens.nextToken().trim();
                if (locatorData.contains("/")) {
                    break;
                }
            }
            locatorData = locatorData.substring(0, locatorData.length() - 1);
            switch (locator) {
                case LOWERCASE_ID:
                    elementFound = !locators(pwId(locatorData)).isEmpty();
                    break;
                case CLASS:
                    elementFound = !locators(pwClass(locatorData)).isEmpty();
                    break;
                case XPATH:
                    elementFound = !locators(pwXPath(value)).isEmpty();
                    break;
                default:
                    Log.error("Invalid locator selected: " + locator);
            }
        } catch (PlaywrightException exception) {
        } catch (Exception e) {
            Log.info(e.toString());
        }
        return elementFound;
    }

    /**
     * Check if a Locator is visible up to the time the timer expires.
     *
     * @param element : The element to search for.
     * @param timer   : Max number of seconds to wait for the element to appear.
     */
    protected boolean isElementVisible(Locator element, int timer) {
        boolean found = false;
        try {
            conditionalWait(timer).until(Conditions.visible(element));
            found = true;
        } catch (PlaywrightException exception) {
        } catch (Exception e) {
            Log.info(e.toString());
        }
        return found;
    }

    protected boolean isElementVisibleAndClickable(Locator element, int timer) {
        boolean found = false;
        try {
            conditionalWait(timer).until(Conditions.clickable(element));
            found = true;
        } catch (PlaywrightException exception) {
        } catch (Exception e) {
            Log.info(e.toString());
        }
        return found;
    }

    /**
     * Check if a Locator is present in the DOM for up to the timer expiring.
     *
     * @param byObject : The element to search for.
     * @param timer    : Max number of seconds to wait for the element to be defined in the DOM.
     */
    protected boolean isElementPresent(String byObject, int timer) {
        boolean found = false;
        try {
            conditionalWait(timer).until(Conditions.allAttached(byObject));
            found = true;
        } catch (PlaywrightException exception) {
        } catch (Exception e) {
            Log.info(e.toString());
        }
        return found;
    }

    /**
     * Check if Locator is present in the Viewport (viewable on the page w/o any scrolling)
     *
     * @param element : The Locator to check
     */
    public boolean isElementInViewport(Locator element) throws Exception {
        waitElementBeVisible(element);
        Object result = executeScript(
                "var rect = arguments[0].getBoundingClientRect();" +
                        "return (" +
                        "rect.top >= 0 &&" +
                        "rect.left >= 0 &&" +
                        "rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&" +
                        "rect.right <= (window.innerWidth || document.documentElement.clientWidth)" +
                        ");", element);
        return result != null && (Boolean) result;
    }

    protected boolean isExpectedTextContainedInElement(Locator element, String expectedContent) {
        return isTextContainedInOtherText(getTextFromElement(element), expectedContent);
    }

    protected boolean isTextContainedInOtherText(String textToScan, String textToLookFor) {
        boolean isExpectedTextContained = textToScan.contains(textToLookFor);
        if (!isExpectedTextContained) {
            Log.error("Text " + NEWLINE + "[" + textToScan + "]" + NEWLINE + " does not contain the subtext" + NEWLINE + "[" + textToLookFor + "]");
        }
        return isExpectedTextContained;
    }

    protected boolean isExpectedTextDisplayed(Locator element, String expectedContent) {
        scrollToElement(element);
        String elementText = getTextFromElement(element);
        boolean isExpectedTextDisplayed = elementText.equals(expectedContent);
        if (!isExpectedTextDisplayed) {
            Log.error("[" + elementText + "] does not match the expected text [" + expectedContent + "]");
        }
        return isExpectedTextDisplayed;
    }

    protected boolean isAnyExpectedTextDisplayed(Locator element, String... expectedContents) {
        boolean result = false;
        String displayedText = getTextFromElement(element);
        for (String text : expectedContents) {
            if (displayedText.equals(text)) {
                result = true;
                Log.info("Expected text match found: [" + text + "]");
                break;
            }
        }
        return result;
    }

    protected boolean isButtonSelected(Locator buttonToCheck) {
    	return checkButtonSelectionState(buttonToCheck, LOWERCASE_TRUE);
    }

    protected boolean isButtonNotSelected(Locator buttonToCheck) {
    	return checkButtonSelectionState(buttonToCheck, LOWERCASE_FALSE);
    }

    private boolean checkButtonSelectionState(Locator buttonToCheck, String expectedState) {
    	//Adding aria_checked for those environments that have migrated to newer angular versions
    	//The aria-pressed check can be removed once upgrade is completed on all systems (including production)
		return getAttributeData(buttonToCheck, ARIA_PRESSED).equals(expectedState) || getAttributeData(buttonToCheck, ARIA_CHECKED).equals(expectedState);
	}

    protected boolean isElementDisabled(Locator elementToCheck) {
    	return getAttributeData(elementToCheck, ARIA_DISABLED).equals(LOWERCASE_TRUE);
    }

    protected boolean isElementNotDisabled(Locator elementToCheck) {
        return getAttributeData(elementToCheck, ARIA_DISABLED).equals(EMPTY_STRING);
    }

    protected boolean isCheckboxChecked(Locator checkboxToCheck) {
    	return checkCheckboxSelectionState(checkboxToCheck) == true;
    }

    protected boolean isCheckboxNotChecked(Locator checkboxToCheck) {
    	return checkCheckboxSelectionState(checkboxToCheck) == false;
    }

    private boolean checkCheckboxSelectionState(Locator checkboxToCheck) {
		return getAttributeData(checkboxToCheck,CLASS).contains(MDC_CHECKBOX_SELECTED);
	}

    protected boolean isPETEnvironment() {
        return checkForEnvironment(PET_ENVIRONMENT);
    }

    public boolean isProdEnvironment() {
        return checkForEnvironment(PROD_ENVIRONMENT);
    }

    public boolean isRA11Environment() {
        return checkForEnvironment(RA11_ENVIRONMENT);
    }

    public boolean isMA11Environment() {
        return checkForEnvironment(MA11_ENVIRONMENT);
    }

    protected boolean isTSK1Environment() {
        return checkForEnvironment(TSK1_ENVIRONMENT);
    }

    protected boolean isMA61Environment() {
        return checkForEnvironment(MA61_ENVIRONMENT);
    }

    protected boolean isRA61Environment() {
        return checkForEnvironment(RA61_ENVIRONMENT);
    }

    private boolean checkForEnvironment(String environment) {
        try {
            return (Property.getUri().contains(environment) || page().url().contains(environment));
        } catch (Exception e) {
            return false;
        }
    }

        private Locator footerPrivacyPolicyLink = locator(pwXPath("//*[@id='footUl']/li[1]/a"));

        private Locator footerTermsOfUseLink = locator(pwXPath("//*[@id='footUl']/li[2]/a"));

        private Locator footerContactUsLink = locator(pwXPath("//*[@id='footUl']/li[3]/a"));

        private Locator footerNoticeOfInformationLink = locator(pwXPath("//*[@id='footUl']/li[4]/a"));

    protected List<Locator> getListWithHomeLOBFooterLinks() {
        return new ArrayList<>(Arrays.asList(footerPrivacyPolicyLink, footerTermsOfUseLink, footerContactUsLink, footerNoticeOfInformationLink));
    }

    protected LinkedHashMap<String, String> getListWithHomeLOBFooterURLDestinationsTitle() {
        LinkedHashMap<String, String> urlsAndTitles = new LinkedHashMap<>();
        urlsAndTitles.put("donotsell", PERSONAL_INFO_USE_URL.replace("-", SPACE));
        urlsAndTitles.put(TERMS_OF_USE_URL.toLowerCase(), TERMS_OF_USE_URL.replace("-", SPACE));
        urlsAndTitles.put(CONTACT_US_URL.toLowerCase(), CONTACT_US_URL.replace("-", SPACE));
        urlsAndTitles.put(NOTICE_OF_INFORMATIONAL_PRACTICES_URL.toLowerCase(), NOTICE_OF_INFORMATIONAL_PRACTICES_URL.replace("-", SPACE));
        return urlsAndTitles;
    }


    public boolean isEasternExpansionState(String stateCode) {
        List<String> easternExpansionStates = new ArrayList<>(Arrays.asList(KY, LA, MA, MS, NC));
        return easternExpansionStates.contains(stateCode);
    }

    protected void longWaitForElementToBeGoneByClass(String className) {
        longWaitForElementToBeGone(CLASS, className);
    }

    protected void longWaitForElementToBeGoneByID(String elementID) {
        longWaitForElementToBeGone(LOWERCASE_ID, elementID);
    }

    protected void longWaitForElementToBeGoneByXpath(String xpathToElement) {
        longWaitForElementToBeGone(XPATH, xpathToElement);
    }

    protected boolean noErrorsPresentInHomeQuote() throws Exception {
        List<Locator> listOfErrorElements = locators(pwXPath("//*[@class='bvalidator_invalid Focus']"));
        return evaluateErrorElements(listOfErrorElements);
    }

    protected boolean noErrorsPresentInPage() throws Exception {
        List<Locator> listOfErrorElements = locators(pwXPath("//mat-error[string-length()>0]"));
        return evaluateErrorElements(listOfErrorElements);
    }

    protected boolean noErrorsPresentInRentersQuote() throws Exception {
        List<Locator> lookForElements = locators(pwId("errordiv"));
        return evaluateErrorElements(lookForElements);
    }

    private boolean evaluateErrorElements(List<Locator> lookForElements) {
        if (lookForElements.isEmpty()) {
            Log.debug("no error elements found");
            return true;
        } else {
            StringBuilder message = new StringBuilder("Error elements found: " + NEWLINE);
            for (Locator errorLabel : lookForElements) {
                scrollElementToMiddle(errorLabel);
                message.append(getTextFromElement(errorLabel) + NEWLINE);
            }
            Log.error(message.toString());
            return false;
        }
    }

    protected boolean isZipCodeErrorMessageFound() {
        return isElementVisible(zipCodeErrorMessage, 5);
    }

    protected void scrollAndClickOnElement(Locator element) {
        scrollToElementThenClick(element, false);
    }

    protected void scrollAndClickOnHiddenElement(Locator element) throws Exception {
        scrollToElement(element);
        clickOnHiddenElement(element);
    }

    protected void scrollOffsetClickOnElement(Locator element) {
        scrollToElementThenClick(element, true);
    }

    private void scrollToElementThenClick(Locator element, boolean offset) {
        try {
            if (offset) {
                scrollToElementWithOffset(element, -150);
            } else {
                scrollElementToMiddle(element);
            }
        } catch (Exception e) {
            Log.info("Could not scroll into view, " + e.getMessage());
        } finally {
            clickElement(element);
        }
    }


    protected void selectFromDropDown(Locator element, String key) {
        wait.until(Conditions.textContains(element, key));
        waitElementBeVisible(element);
        selectVisibleTextInDropDown(element, key);
    }

    protected void selectFromDropDownByValue(Locator element, String key) {
        wait.until(Conditions.textContains(element, key));
        selectByValue(element, key);
    }

    protected void selectFromDropDownByIndex(Locator element, int position) {
        selectByIndex(element, position);
    }

    protected int getNumberOfOptionsForDropdown(Locator element) {
        return select(element).getOptions().size();
    }

    protected boolean selectValueInDropdown(String value, Locator dropdown, Locator resetElement) throws Exception {
        return findDropdownOptionsThatContainValue(dropdown, value, resetElement, true);
    }

    protected Locator getDropDownOption(String valueText) throws Exception {
        // wait until there is at least one drop down option
        wait.until(Conditions.numberOfElementsToBeMoreThan(pwXPath("//mat-option"), 0));
        String expectedValue = normalizeDropdownOptionValue(valueText);
        for (Locator option : locators(pwXPath("//mat-option[not(@aria-disabled='true')]"))) {
            String visibleText = normalizeDropdownOptionValue(getTextFromElement(option));
            String ariaLabel = normalizeDropdownOptionValue(option.getAttribute("aria-label"));
            if (visibleText.equalsIgnoreCase(expectedValue) || ariaLabel.equalsIgnoreCase(expectedValue)
                    || ariaLabel.endsWith(SPACE + expectedValue)) {
                return option;
            }
        }
        return locator(pwXPath(String.format("//span[contains(.,'%s')]/parent::mat-option", valueText)));
    }

    private String normalizeDropdownOptionValue(String value) {
        return value == null ? EMPTY_STRING : value.replace('\u00A0', ' ').replaceAll("\\s+", " ").trim();
    }

    protected void selectValueInDropDown(Locator dropDown, String value) throws Exception {
        waitAndClickElement(dropDown);
        waitForUiSettled();
        waitAndClickElement(getDropDownOption(value));
    }

    protected void selectVisibleTextInDropDown(Locator dropDown, String text) {
        selectByVisibleText(dropDown, text);
    }

    protected void sendKeysAndSelectValueFromDropDown(Locator element, String keyToSend) throws Exception {
        sendKeysToElement(element, keyToSend);
        selectValueInDropDown(element, keyToSend);
    }

    private boolean findDropdownOptionsThatContainValue(Locator dropdown, String value, Locator resetElement, boolean retry) throws Exception {
        boolean isSuccessful = false;
        scrollAndClickOnElement(dropdown);
        waitForElements(DROPDOWN_OPTIONS_XPATH);
        List<Locator> listOfOptionsWithValue = locators(pwXPath(DROPDOWN_ENTRY_XPATH + value + "\")]"));
        if (!listOfOptionsWithValue.isEmpty()) {
            isSuccessful = findOptionAndClick(listOfOptionsWithValue, value);
        } else {
            Log.info("Did not find [" + value + "] in " + dropdown);
        }
        if (retry && !isSuccessful) {
            if (isElementVisible(resetElement, 1)) {
                scrollAndClickOnElement(resetElement);
            }
            isSuccessful = findDropdownOptionsThatContainValue(dropdown, value, resetElement, false);
        }
        if (isElementVisible(resetElement, 1)) {
            scrollAndClickOnElement(resetElement);
        }
        return isSuccessful;
    }

    private boolean findOptionAndClick(List<Locator> listOfOptionsWithValue, String value) {
        boolean isSuccessful = false;
        if (listOfOptionsWithValue.size() > 1) {
            for (Locator lookForValue : listOfOptionsWithValue) {
                if (getTextFromElement(lookForValue).equals(value)) {
                    waitAndClickElement(lookForValue);
                    isSuccessful = true;
                    break;
                }
            }
        } else {
            waitAndClickElement(listOfOptionsWithValue.get(0));
            isSuccessful = true;
        }
        return isSuccessful;
    }

    protected void selectRandomOptionInDropdown(Locator dropdown) {
        int numberOfOptionsFound = getNumberOfOptionsForDropdown(dropdown);
        int randomIndex = randomNumberGenerator.nextInt(numberOfOptionsFound);
        scrollElementToMiddle(dropdown);
        selectFromDropDownByIndex(dropdown, randomIndex);
    }

    public boolean areTwoListEqual(List<String> listOfActualValues, List<String> listOfExpectedValues) {
        Collections.sort(listOfActualValues);
        Collections.sort(listOfExpectedValues);
        if (listOfActualValues.equals(listOfExpectedValues)) {
            return true;
        } else {
            Log.warn("expected values: " + listOfExpectedValues);
            Log.warn("actual values: " + listOfActualValues);
            return false;
        }
    }

    // Some text fields in non-chrome browsers behave improperly by beginning the data entry point beyond the first character
    // This is a workaround to that problem.
    protected void sendKeysToElementAlternate(Locator misbehavingTextField, String fieldData) {
        if (!Property.getBrowser().equals(CHROME)) {
            try {
                clickElement(misbehavingTextField);
                misbehavingTextField.fill("");
                clickElement(misbehavingTextField);
                String inputValue = StringUtils.repeat("\u0008", fieldData.length() + 3);
                PlaywrightActions a = actions();
                sendKeys(a, misbehavingTextField, inputValue + fieldData).build().perform();
            } catch (Exception e) {
                Log.info("Unable to access Playwright page: " + e);
            }
        } else {
            sendKeysToElement(misbehavingTextField, fieldData);
        }
    }

    protected void sendKeysToElement(Locator element, int keys) {
        sendKeysToElement(element, String.valueOf(keys));
    }

    /**
     * Clear and send keys to element.
     *
     * @param element
     * @param keys
     */
    protected void sendKeysToElement(Locator element, String keys) {
        sendKeysToElement(element, keys, true);
    }

    /**
     * Safari-safe JS sendKeys
     *
     * @param element Locator to type into
     * @param value   text to enter
     */
    protected void jsSendKeys(Locator element, String value) throws Exception {
        if (element == null) {
            throw new IllegalArgumentException("Locator cannot be null");
        }

        executeScript(
                "if(!arguments[0].disabled && !arguments[0].readOnly){" +
                        "  arguments[0].scrollIntoView({block:'center'});" +
                        "  arguments[0].focus();" +
                        "  arguments[0].value='';" +
                        "  arguments[0].value=arguments[1];" +
                        "  arguments[0].dispatchEvent(new Event('input', { bubbles: true }));" +
                        "  arguments[0].dispatchEvent(new Event('change', { bubbles: true }));" +
                        "}",
                element, value
        );
    }

    protected void sendKeysToElementWithoutClearingField(Locator element, String keys) {
        sendKeysToElement(element, keys, false);
    }

    private void sendKeysToElement(Locator element, String keys, boolean clearField) {
        try {
            if (clearField) {
                element.fill("");
                if (!getAttributeData(element, VALUE).equals(EMPTY_STRING)) {
                	element.fill("");
                }
            }
            sendKeys(element, keys);
        } catch (Exception e) {
            System.out.println("Inside sendKeysToElement catch " + e);
        }
    }

    protected void sendKeysOneByOne(Locator element, String keys) {
        scrollAndClickOnElement(element);
        sendKeysOneByOne(element, keys, true);
    }

    protected void sendKeysOneByOne(Locator element, String keys, boolean clearField) {
        if (clearField) {
            element.fill("");
        }
        for (int i = 0; i < keys.length(); i++) {
            sendKeys(element, keys.subSequence(i, i + 1));
        }
    }

    protected void sendKeysToElementUsingClipboard(Locator inputField, String keys) throws Exception {
        executeScript("navigator.clipboard.writeText('" + keys + "')");
        String pasteChars = Property.isMacPlatform() ? Keys.chord(Keys.COMMAND, "V") : Keys.chord(Keys.CONTROL, "V");
        sendKeysToElement(inputField, pasteChars);
    }

    @SneakyThrows
    public void pressEscKey() {
        PlaywrightActions a = actions();
        sendKeys(a, Keys.ESCAPE).build().perform();
    }

    /**
     * Setting a checkbox or unchecking it if it is already selected.
     */
    public void setCheckboxTo(Locator checkbox, boolean checked) {
        if (checkbox.isEnabled()) {
            Log.debug("setting " + checkbox + " to " + checked);
            if (checked) {
                if (!checkbox.isChecked()) {
                    clickElement(checkbox);
                }
            } else {
                if (checkbox.isChecked()) {
                    clickElement(checkbox);
                }
            }
        } else {
            Log.warn(checkbox + " is not enabled");
        }
    }

    protected void switchBackToBaseWindow(Page baseWindow) throws Exception {
        closeCurrentPage();
        switchToPage(baseWindow);
    }

    protected Page switchToNewWindow(Locator link) throws Exception {
        List<Page> newHandles = pages();
        int activeWindows = newHandles.size();
        Page baseWindow = currentPage();
        clickElement(link);
        conditionalWait(5).until(Conditions.pageCount(activeWindows + 1));
        for (Page handle : pages()) {
            if (!baseWindow.equals(handle)) {
                switchToPage(handle);
            }
        }
        return baseWindow;
    }

    /**
     * Verify Drop Down List Values.
     *
     * @param dropDowns
     * @param expValues
     */
    protected void verifyDropDownListValues(List<Locator> dropDowns, Map<Locator, List<String>> expValues, FarmersSoftAssert fsa) {
        Log.debug("Verifying Drop Down List Values");
        for (Map.Entry<Locator, List<String>> entry : expValues.entrySet()) {
            Locator dropdownElement = entry.getKey();
            List<String> listOfExpectedValues = entry.getValue();
            List<Locator> listOfActualOptions = select(dropdownElement).getOptions();
            fsa.assertEquals(listOfActualOptions, listOfExpectedValues, "Check options for " + dropdownElement);
        }
    }

    /**
     * Verify Is Missing Fields Error Messages Visible.
     *
     * @param elementsMap
     * @param errorMessages
     */
    protected void verifyIsMissingFieldsErrorMessagesVisible(LinkedHashMap<Locator, List<String>> errorMessages, LinkedHashMap<Locator, Locator> elementsMap, ApplicantHome applicant) throws Exception {
        Log.debug("Verifying Is Missing Fields Error Messages Visible");
        for (Map.Entry<Locator, Locator> entry : elementsMap.entrySet()) {
            waitElementBeVisible(entry.getValue());
            Assert.assertTrue(entry.getKey().isVisible(), entry.getKey() + "is not displayed");
            Assert.assertEquals(getTextFromElement(entry.getValue()), errorMessages.get(entry.getKey()).get(0), "Error Message doesn't match for " + entry.getValue());
            if (entry.getKey().toString().contains("maritalStatus")) {
                YourInfoPageHome infoPage = new YourInfoPageHome();
                if (infoPage.isMailingCheckBoxDisplayed()) {
                    infoPage.selectMailingAddressDifferentOption();
                }
                infoPage.selectMaritalStatus(applicant.getMaritalStatus());
                infoPage.clickStartQuoteButton();
            }
            String errorMessageText = getTextFromElement(errorMessageElement);
            if (errorMessageText.contains("\"Home Exterior Wall type\"")) {
                entry.getKey().click();
            }
            if (errorMessageText.contains("\"Type of roof\"")) {
                entry.getKey().click();
            }
        }
    }

    /**
     * Wait for element to be clickable and Click.
     *
     * @param element
     */
    protected Locator waitAndClickElement(Locator element) {
        waitElementBeVisibleClickable(element);
        clickElement(element);
        return element;
    }

    protected Locator waitAndClickElement(Locator element, int timeInSeconds) {
        waitElementBeVisible(element, timeInSeconds);
        clickElement(element);
        return element;
    }

    protected Locator waitElementBeVisible(Locator element) {
        return wait.until(Conditions.visible(element));
    }

    protected Locator waitElementBeVisible(Locator element, int timer) {
        return conditionalWait(timer).until(Conditions.visible(element));
    }

    @SneakyThrows
    protected boolean waitElementBeInvisible(Locator e) {
        boolean isElementInvisible = wait.until(Conditions.invisible(e)) ? true : false;
        return isElementInvisible;
    }

    protected boolean waitElementPresent(String byObject, int timer) {
        boolean found = false;
        try {
            conditionalWait(timer).until(Conditions.allAttached(byObject));
            found = true;
        } catch (PlaywrightException exception) {
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return found;
    }

    protected boolean areNumberOfElementsMatch(String by, int number, int timer) {
        boolean found = true;
        try {
            conditionalWait(timer).until(Conditions.numberOfElementsToBe(by, number));
        } catch (PlaywrightException exception) {
            found = false;
        } catch (Exception e) {
            Log.error(e.toString());
            found = false;
        }
        return found;
    }

    public void waitElementBeVisibleClickable(Locator e) {
        wait.until(Conditions.clickable(e));
    }

    protected void waitForPageToBeReady() {
        waitForSpinnerToBeGone();
        waitForJSToLoad();
    }

    public void waitForSpinnerToBeGone() {
        try {
            conditionalWait(3).until(Conditions.or(Conditions.attached(pwXPath(WAIT_SPINNER_XPATH)),
                    Conditions.attached(pwXPath(ONEUI_SPINNER_XPATH)),
                    Conditions.attached(pwXPath(ACE_SPINNER_SECTION_XPATH))));
        } catch (PlaywrightException exception) {
            //Spinner never found, done.
            return;
        } catch (Exception e) {
            Log.debug("driverWait exception" + e.getMessage());
        }
        longWaitForElementToBeGoneByXpath(WAIT_SPINNER_XPATH);
        longWaitForElementToBeGoneByXpath(ONEUI_SPINNER_XPATH);
        longWaitForElementToBeGoneByXpath(ACE_SPINNER_SECTION_XPATH);
    }

    public void waitForSkeletonToBeGone() {
        if (isElementPresent(pwXPath(ACE_REVIEW_QUOTE_SKELETON_XPATH), 6)) {
            longWaitForElementToBeGoneByXpath(ACE_REVIEW_QUOTE_SKELETON_XPATH);
        }
    }

    public void waitForOneMomentPageToBeGone() {
        if (isElementPresent(pwXPath(ACE_ONE_MOMENT_TITLE_XPATH), 6)) {
            longWaitForElementToBeGoneByXpath(ACE_ONE_MOMENT_TITLE_XPATH);
        }
    }

    protected void waitForLegacySpinnerToBeGone() {
        if (isElementPresent(pwClass(LEGACY_WAIT_DIALOG_CLASSNAME), 1)) {
            longWaitForElementToBeGoneByClass(LEGACY_WAIT_DIALOG_CLASSNAME);
        } else if (isElementPresent(pwId(PAGE_LOADING_MESSAGE_ID), 1)) {
            longWaitForElementToBeGoneByID(PAGE_LOADING_MESSAGE_ID);
        } else if (isElementPresent(pwId(WAIT_QUOTE_READY_ID), 1) && !isElementPresent(pwXPath("//button[contains(@id, 'Update')]"), 1)) {
            longWaitForElementToBeGoneByID(WAIT_QUOTE_READY_ID);
        }
    }

    protected void waitForRecalculationPopupToBeGone() {
        try {
            conditionalWait(2).until(Conditions.or(Conditions.attached(pwId(RECALCULATING_POPUP_ID)),
                    Conditions.attached(pwClass(RECALCULATING_POPUP_CLASS))));
        } catch (PlaywrightException exception) {
            //Pop-up never found, done.
            return;
        } catch (Exception e) {
            Log.debug("driverWait exception" + e.getMessage());
        }
        longWaitForElementToBeGoneByID(RECALCULATING_POPUP_ID);
        longWaitForElementToBeGoneByClass(RECALCULATING_POPUP_CLASS);
    }

    protected void closeSurveyDialog() {
        closeSurveyDialog(true);
    }

    private void closeSurveyDialog(boolean retry) {
        if (isElementPresent(pwXPath(CLOSE_SURVEY_XPATH), 3)) {
            clickElement(closeModalSurveyButton);
            closeSurveyDialog(false);
            try {
                longWaitForElementToBeGoneByXpath(CLOSE_SURVEY_XPATH);
            } catch (TimeoutError te) {
                if (isElementPresent(pwXPath(CLOSE_SURVEY_XPATH), 2) && retry) {
                    clickElement(closeModalSurveyButton);
                    closeSurveyDialog(false);
                }
            }
        }
    }

    private void longWaitForElementToBeGone(String locatorType, String value) {
        String locator = null;
        switch (locatorType) {
            case XPATH:
                locator = pwXPath(value);
                break;
            case CLASS:
                locator = pwClass(value);
                break;
            case LOWERCASE_ID:
                locator = pwId(value);
                break;
            default:
                Log.warn("Undefined locator type specified: " + locatorType);
        }
        try {
            conditionalWait(Property.PAGELOADTIMEOUT).until(Conditions.invisible(locator));
        } catch (TimeoutError te) {
            Log.debug(locatorType + SPACE + value + " is still there");
            wait.until(Conditions.invisible(locator));
        } catch (PlaywrightException | NullPointerException exception) {
            Log.debug(locatorType + SPACE + value + " no longer found");
        } catch (Exception e) {
            Log.debug("locator " + locator + " exception in long wait " + e);
        }
    }

    private void waitForJSToLoad() {
        Log.debug("Waiting for document readiness");
        page().waitForCondition(() -> "complete".equals(page().evaluate("document.readyState")),
                new Page.WaitForConditionOptions().setTimeout(Property.pageLoadTimeoutMillis()));
    }

    protected void waitForElements(String elementsXpath) throws Exception {
        for (int i = 10; i > 0; i--) {
            List<Locator> webElements = locators(pwXPath(elementsXpath));
            if (!webElements.isEmpty()) {
                break;
            } else {
                waitForUiSettled();
            }
        }
    }

    protected static synchronized void saveLifeApplicantInHashMap(ApplicantLife applicant, String leftPage, String quoteNumber) {
        ApplicantRetQuote applicantRetQuote = new ApplicantRetQuote();
        applicantRetQuote.setLastName(applicant.getLastName());
        applicantRetQuote.setAge(applicant.getAge());
        applicantRetQuote.setZipCode(applicant.getZipCode());
        applicantRetQuote.setEmailAddress(applicant.getEmailAddress());
        applicantRetQuote.setQuoteNumber(quoteNumber);
        applicantRetQuote.setPageLeftOn(leftPage);
        returningQuoteConcurrentHashMap.put(applicant.getLastName() + applicant.getZipCode() + quoteNumber, applicantRetQuote);
        Reporter.pass(applicantRetQuote.toString());
    }

    /**
     * Capture screen content.
     *
     * @param element        - Scroll to this Locator before screen capture
     * @param fileNamePrefix - String prefix for file name where screen capture will be stored
     * @param pageSize       - String that specifies size (MEDIUM, LARGE, EXTRA_LARGE) that screen will be set to prior to capture
     * @param zoomOut        - Boolean that indicates whether to zoom out before screen capture
     * @throws Exception page() call exceptions
     */
    protected void screenCapture(Locator element, String fileNamePrefix, String pageSize, boolean zoomOut) throws Exception {
        if (Property.getTestProperty(SUITE).equals(PEWC) || isADATestingEnabled()) {
            ViewportSize currentWindowSize = viewportSize();
            switch (pageSize) {
                case MEDIUM:
                    setDimensionScrollToElementAndCapture(1400, 1800, zoomOut, element, fileNamePrefix);
                    break;
                case LARGE:
                    setDimensionScrollToElementAndCapture(1400, 3800, zoomOut, element, fileNamePrefix);
                    break;
                case EXTRA_LARGE:
                    setDimensionScrollToElementAndCapture(1400, 5800, zoomOut, element, fileNamePrefix);
                    break;
                default:
                    setDimensionScrollToElementAndCapture(currentWindowSize.width, currentWindowSize.height, zoomOut, element, fileNamePrefix);
                    break;
            }
            setViewportSize(currentWindowSize.width, currentWindowSize.height);
        }
    }

    private void setDimensionScrollToElementAndCapture(int width, int height, boolean zoomOut, Locator element, String fileNamePrefix) throws Exception {
        ViewportSize d = new ViewportSize(width, height);
        setViewportSize(width, height);
        scrollToElement(element);
        scrollToElement(element);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String dateTimeStamp = LocalDateTime.now().format(formatter);
        if (zoomOut) {
            executeScript("document.body.style.zoom = '75%';");
        }
        String release = isADATestingEnabled() ? EMPTY_STRING : "R07_";
        Log.warn("*** Screen capture at " + width + "x" + height + SPACE + "***" + NEWLINE, fileNamePrefix + UNDERSCORE + release + dateTimeStamp + "UTC");
        if (zoomOut) {
            // restore zoom level
            executeScript("document.body.style.zoom = '100%';");
        }
    }

    public boolean isFlexState(String stateCode) {
        List<String> flexStates = new ArrayList<>(Arrays.asList(AL, AR, AZ, CO, CT, GA, ID, IL, MI, MO, ND, NE, NM, OK, OR, PA, SD, TN, TX, UT, VA, WI, WY));
        return flexStates.contains(stateCode);
    }

    protected boolean isHVQEnabledState(String stateCode) {
        List<String> hvqStates = new ArrayList<>(Arrays.asList(AR, AZ, CT, CO, ID, IL, IN, KS, KY, MA, MD, MI, MN, MO, MS, NC, ND, NE, NM, OK, OR, PA, SD, TN, TX, UT, WA, WI, WY));
        return hvqStates.contains(stateCode);
    }

    protected boolean isMatureDriverSafetyCourseMandatory(String stateCode) {
        return new ArrayList<>(Arrays.asList(AR, AZ, IL, KS, MD, MI, MN, MS, NM, OR)).contains(stateCode);
    }

    public void clearOutFieldUsingBackSpace(Locator element) {
        while (!element.getAttribute(VALUE).equals(EMPTY_STRING)) {
            sendKeysToElement(element, Keys.BACK_SPACE);
        }
    }

    protected void performRepeatedAction(int number, boolean refresh, Runnable runnable) throws Exception {
        for (int count = 0; count < number; count++) {
            try {
                runnable.run();
            } catch (RuntimeException exception) {
                if (refresh) {
                    refreshPage();
                }
                runnable.run();
                continue;
            }
            break;
        }
    }

    public void setBrowserDimensionToMobileBreakPoint() throws Exception {
        setViewportSize(PlaywrightArtifacts.MOBILE.width(), PlaywrightArtifacts.MOBILE.height());
    }

    public void maximizeTheBrowser() throws Exception {
        maximizeWindow();
    }

    public void showSaucelabsLinkOnSuccessfulTest(boolean checkForUsage) {
        if (!checkForUsage || isOndemandJob()) {
            addLinkToTest();
            Log.info(EMPTY_STRING, true);
        }
    }

    private boolean isOndemandJob() {
        String stateListPropertyValue = Property.getTestProperty("stateList");
        return (stateListPropertyValue != null && !stateListPropertyValue.equals(EMPTY_STRING) && !stateListPropertyValue.equals("all"));
    }

    private void addLinkToTest() {
        if (Property.getTestProperty("remote").equalsIgnoreCase("saucelabs")) {
            Reporter.pass(NEWLINE + ">>> SauceLabs link: " + getPublicJobLink() + NEWLINE);
        }
    }

    public void logInfoMessage(String quoteNumber) {
        testStep("Quote number for this flow is : " + quoteNumber);
    }

    public void addSauceLabsLinkInLog() {
        addLinkToTest();
    }

    public boolean isUseMobileViewEnabled() {
        String useMobileView = Property.getTestProperty("useMobileView");
        return useMobileView != null && useMobileView.equalsIgnoreCase("true");
    }

    public boolean isADATestingEnabled() {
        String adaTestingEnabled = Property.getTestProperty("adaTestingEnabled");
        return adaTestingEnabled != null && adaTestingEnabled.equalsIgnoreCase("true");
    }

    public static String getFormattedForPolicyStartDate(LocalDate date) {
        return dateTimeFormatter.format(date);
    }

    protected static String getFormattedTodayDate() {
        return getTodayDate().format(dateTimeFormatter);
    }

    protected static String getFormattedTomorrowDate() {
        return getTodayDate().plusDays(1).format(dateTimeFormatter);
    }

    protected static String getFormattedYesterdayDate() {
        return getTodayDate().minusDays(1).format(dateTimeFormatter);
    }

    public static String getFormattedDateAfter8days() {
        return getTodayDate().plusDays(8).format(dateTimeFormatter);
    }

    protected static LocalDate getFormattedDateFromStringDate(String dateInString) {
        return LocalDate.parse(dateInString, dateTimeFormatter);
    }

    protected static String errorMessage(String message) {
        return message + " verification";
    }

    protected static LocalDate getTodayDate() {
        return LocalDate.now();
    }

    public boolean isEndOfTheMonthDate(String formattedTodayDate) {
        Integer[] endOfMonthDays = {28, 30, 31};
        int dateOfMonth = LocalDate.parse(formattedTodayDate, dateTimeFormatter).getDayOfMonth();
        return Arrays.asList(endOfMonthDays).contains(dateOfMonth);
    }

    protected static String getValueFromLocator(Locator element) {
        return element.getAttribute(VALUE);
    }

    protected static LocalDate todayPlus8Days() {
        return LocalDate.now().plusDays(8);
    }

    protected static LocalDate todayPlus6Days() {
        return LocalDate.now().plusDays(6);
    }

    protected static LocalDate todayPlus59Days() {
        return LocalDate.now().plusDays(59);
    }

    protected static LocalDate todayPlus60Days() {
        return LocalDate.now().plusDays(60);
    }

    protected static String getTheFullNameWithFirstLetterInCaps(String fullName) {
        String[] split = fullName.split(SPACE);
        String result = "";
        for (String s : split) {
            result += StringUtils.capitalize(StringUtils.toRootLowerCase(s)) + SPACE;
        }
        return result.strip();
    }

    protected List<String> getTextFromListOfLocatorNodes(List<Locator> listOfLocators) {
    	//Gets text from element and removes text from children
        List<String> listOfText = new ArrayList<>();
        for (Locator element : listOfLocators) {
            listOfText.add(getNodeText(element));
        }
        return listOfText;
    }

    protected List<String> getTextFromListOfLocatorsAndDescendents(List<Locator> listOfLocators) {
        List<String> listOfText = new ArrayList<>();
        for (Locator element : listOfLocators) {
            listOfText.add(getTextFromElement(element));
        }
        return listOfText;
    }

    public boolean isRequiredMembershipFees(String stateCode) {
        List<String> statesRequiredMemberShipFees = new ArrayList<>(Arrays.asList(AL, AR, AZ, CA, CO, CT, GA, IA, KY, LA, MA, MD, MI, MN, MO, MS, MT, ND, NE, NM, NV, OR, PA, SD, TN, UT, WA, WI, WY));
        return statesRequiredMemberShipFees.contains(stateCode);
    }

    public boolean isRequiredVehicleFees(String stateCode) {
        List<String> statesRequiredMemberShipFees = new ArrayList<>(Arrays.asList(CT, IN, KS, OH, VA));
        return statesRequiredMemberShipFees.contains(stateCode);
    }

	protected boolean isShortcutToPurchaseState(String stateCode) {
		return List.of(CO, TX).contains(stateCode);
	}

    @SneakyThrows
    public void selectBundle(boolean selectBundle, String bundleName) {
       	String BUNDLE_DISCOUNTS_XPATH = "//app-save-bundle-sheet//fieldset[contains(@class,'save-bundle-discount-sheet')]//mat-checkbox[contains(.,'%s')]//input";
       	List<Locator> bundleElements = locators(pwXPath(String.format(BUNDLE_DISCOUNTS_XPATH, bundleName)));
    	if (!bundleElements.isEmpty()) {
    		setCheckboxTo(bundleElements.get(FIRST_AVAILABLE_OPTION), selectBundle);
    		Log.info("Bundle option is" + (selectBundle? SPACE : " not ") + "selected for: " + bundleName);
    	}
    }

    public AppStore getSessionStorageAppStore() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        String appStoreJson = getItemFromSessionStorage("appStore");
        if (StringUtils.isBlank(appStoreJson)) {
            throw new IllegalStateException(
                    "FFQ sessionStorage item 'appStore' is not initialized at URL: " + page().url());
        }
        AppStore appStore = mapper.readValue(appStoreJson, AppStore.class);

        // Automatically propagate the quote number to RallyContext so it appears in Rally
        // results without requiring individual tests to call RallyContext.setQuoteNumber().
        // Only runs when no quote number has been set yet — a value already stored by the
        // test takes priority and must not be overwritten.
        // Auto flow: data.quoteNumber  |  Home/Renters/Condo flow: home.quote.quoteNumber
        try {
            if (StringUtils.isEmpty(RallyContext.getQuoteNumber())) {
                String qn = null;
                if (appStore.getData() != null) {
                    qn = appStore.getData().getQuoteNumber();
                }
                if ((qn == null || qn.isEmpty()) && appStore.getHome() != null
                        && appStore.getHome().getQuote() != null) {
                    qn = appStore.getHome().getQuote().getQuoteNumber();
                }
                if (qn != null && !qn.isEmpty()) {
                    RallyContext.setQuoteNumber(qn);
                }
            }
        } catch (Exception ignored) {
            // Never let Rally housekeeping affect the actual test flow
        }

        return appStore;
    }

    public BusinessStore getSessionStorageBusinessStore() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return mapper.readValue(getItemFromSessionStorage("businessStore"), BusinessStore.class);
    }

    public String getItemFromSessionStorage(String key) throws Exception {
        ensureWebStorageOrigin("sessionStorage", key);
        return (String) executeScript(String.format(
                "return sessionStorage.getItem('%s');", key));
    }

    public void setItemFromSessionStorage(String key, String value) throws Exception {
        ensureWebStorageOrigin("sessionStorage", key);
        executeScript(String.format(
                "return sessionStorage.setItem('%s', '%s');", key, value));
    }

    private void ensureWebStorageOrigin(String storageName, String key) {
        Page activePage = page();
        if (activePage.isClosed()) {
            throw new IllegalStateException(
                    "Cannot access " + storageName + " item '" + key + "' because the Playwright page is closed.");
        }

        String currentUrl = StringUtils.trimToEmpty(activePage.url());
        String normalizedUrl = currentUrl.toLowerCase(Locale.ROOT);
        if (!normalizedUrl.startsWith("http://") && !normalizedUrl.startsWith("https://")) {
            throw new IllegalStateException(
                    "Cannot access " + storageName + " item '" + key
                            + "' before navigation to an HTTP(S) application origin. Current URL: "
                            + (currentUrl.isEmpty() ? "<empty>" : currentUrl));
        }
    }

    @SneakyThrows
    public void removeQualtricsPopUp() {
        // remove qualtrics survey form for additional Info page
        //setItemFromSessionStorage("showQualtricsPopupForSubsetOfUsers", "false");
        setItemFromSessionStorage("aceIndicator", "false");

        // remove qualtrics survey form for remaining cases
        executeScript("arguments[0].innerHTML = arguments[1]", qualtricsPopUpSwitcher, "false");
    }

    public void closeQualtricsPopUp() {
        Locator closeButton = listOfQualtricsCloseButtons.nth(0);
        if (isElementVisible(closeButton, 2)) {
            clickElement(closeButton);
        }
    }

    public int getEleCount(List<Locator> xpathvalue, int seconds) {
        int webElementCount = 0;
        try {
            if (areElementsDisplayed(xpathvalue, seconds)) {
                webElementCount = xpathvalue.size();
                System.out.println("webElementCount::" + webElementCount);
            }
        } catch (Exception e) {
            webElementCount = 0;
            System.out.println("webElementCount exception:xpathvalue " + xpathvalue);
        }

        return webElementCount;
    }

    public int getEleCount(Locator locator, int seconds) {
        return getEleCount(locator.all(), seconds);
    }

    public boolean areElementsDisplayed(List<Locator> elements, int seconds) {
        boolean flag = false;
        try {
            conditionalWait(20).ignoring(PlaywrightException.class);
            conditionalWait(seconds).until(Conditions.visibilityOfAllElements(elements));
            flag = true;
        } catch (TimeoutError te) {
            // Not found
        } catch (Exception e) {
            System.out.println("Inside areElementsDisplayed catch. Exception is: " + e);
        }
        return flag;
    }

    public boolean isElementDisplayed(Locator element, int seconds) {
        boolean flag = false;
        try {
            conditionalWait(seconds).ignoring(PlaywrightException.class);
            conditionalWait(seconds).until(Conditions.visible(element));
            flag = true;
        } catch (PlaywrightException e) {
            // Not found
        } catch (Exception e) {
            System.out.println("Inside isElementDisplayed catch. Exception is: " + e);
        }
        return flag;
    }

    public Locator generateXpath(String xpathvalue, String oldChar, String newValue) {
        Locator element = null;
        try {
            System.out.println("generatedXpath  :" + xpathvalue.replace(oldChar, newValue.trim()));
            element = locator(pwXPath(xpathvalue.replace(oldChar, newValue)));
        } catch (Exception e) {
            System.out.println("Inside generatexpath catch: " + e);
            System.out.println("Inside generatexpath catch waiting 2s and retrying ");
            waitForUiSettled();
            try {
                element = locator(pwXPath(xpathvalue.replace(oldChar, newValue)));
            } catch (Exception e1) {
                System.out.println("Inside generatexpath catch.Retry not worked.ISSUE:  " + e1);
            }
        }
        return element;
    }

    public boolean isOnBristolWest() throws Exception {
        waitForSpinnerToBeGone();
        return isElementDisplayed(pwXPath(BRISTOL_WEST_LOGO_ACE_XPATH));
    }

    private boolean validateSaveQuoteModalContent(String quoteNumber, boolean isEmailInputPrefilled) throws Exception {
        boolean contentValidated = true;
        boolean isOnBw = isOnBristolWest();
        if (isAutoSaveDisabled()) {
            clickOnSaveQuoteButton();
            waitForSpinnerToBeGone();
            if (isOnBw) {
                boolean emailFieldNotVisible = !isElementVisible(saveQuoteModalEmailInputField, 1);
                waitAndClickElement(saveQuoteModalCloseIcon);
                return emailFieldNotVisible;
            }
            contentValidated &= doesElementHaveFocus(waitElementBeVisible(saveQuoteModalEmailInputField, 3));
            if (contentValidated) {
                Log.info("Email input field had focus when dialog rendered");
            } else {
                Log.error("Email input field does not have focus when dialog rendered", true);
            }
            final String EXPECTED_MODAL_TITLE = "Quote saved";
            final String EXPECTED_QUOTE_TEXT = "Quote number";
            final String EXPECTED_MODAL_CONTENT_BODY = "Please note down your quote number to retrieve your quote at a later time. Or, you can send the quote number to your email.";
            final String EXPECTED_FORM_FIELD_HEADER = "Email me my quote number";
            final String EXPECTED_EMAIL_INPUT_LABEL = "Email address";
            final String EXPECTED_SUBMIT_BUTTON_TEXT = "Submit";
            final String EXPECTED_EMAIL_INPUT_ERROR_MESSAGE = "Please enter your email";
            final String EXPECTED_INVALID_EMAIL_INPUT_ERROR_MESSAGE = "Email is invalid";
            contentValidated &= testExpectedTextContentForElement(waitElementBeVisible(saveQuoteModalHeader), EXPECTED_MODAL_TITLE);
            contentValidated &= testExpectedTextContentForElement(waitElementBeVisible(saveQuoteModalQuoteNumber), quoteNumber);
            contentValidated &= testExpectedTextContentForElement(waitElementBeVisible(saveQuoteModalQuoteNumberText), EXPECTED_QUOTE_TEXT);
            contentValidated &= testExpectedTextContentForElement(waitElementBeVisible(saveQuoteModalInfoText), EXPECTED_MODAL_CONTENT_BODY);
            contentValidated &= testExpectedTextContentForElement(waitElementBeVisible(saveQuoteModalEmailFieldHeader), EXPECTED_FORM_FIELD_HEADER);
            contentValidated &= testExpectedTextContentForElement(waitElementBeVisible(saveQuoteModalEmailFieldLabel), EXPECTED_EMAIL_INPUT_LABEL);
            contentValidated &= testExpectedTextContentForElement(waitElementBeVisible(saveQuoteModalSubmitButton), EXPECTED_SUBMIT_BUTTON_TEXT);

            if (isEmailInputPrefilled || getAttributeData(waitElementBeVisible(saveQuoteModalEmailInputField), CLASS).contains("ng-valid")) {
                contentValidated &= getAttributeData(waitElementBeVisible(saveQuoteModalEmailInputField), CLASS).contains("ng-valid");
            } else {
                clickSaveQuoteModalSubmitButton();
                if (!getAttributeData(waitElementBeVisible(saveQuoteModalEmailInputField), CLASS).contains("ng-valid")) {
                    clearOutFieldUsingBackSpace(waitElementBeVisible(saveQuoteModalEmailInputField));
                    contentValidated &= testExpectedTextContentForElement(waitElementBeVisible(emailInputFieldErrorMessage), EXPECTED_EMAIL_INPUT_ERROR_MESSAGE);
                    sendKeysToElement(saveQuoteModalEmailInputField, "invalidEmail@");
                    clickSaveQuoteModalSubmitButton();
                    contentValidated &= testExpectedTextContentForElement(emailInputFieldErrorMessage, EXPECTED_INVALID_EMAIL_INPUT_ERROR_MESSAGE);
                }

            }
            waitAndClickElement(saveQuoteModalCloseIcon);
        }
        return contentValidated;
    }

    public void clickSaveQuoteModalSubmitButton() {
        waitAndClickElement(saveQuoteModalSubmitButton);
    }

    public boolean isEmailConfirmationDisplayed(String email) {
        String emailConfirmationText = String.format("A copy of your quote number has been emailed to %s", email);
        return isSnackBarMessageDisplayed(emailConfirmationText);
    }

    protected boolean testExpectedTextContentForElement(Locator element, String expectedText) {
        String elementTextFound = getTextFromElement(element);
        if (elementTextFound.equals(expectedText)) {
            return true;
        } else {
            Log.error("[" + elementTextFound + "] element text did not equal expected [" + expectedText + "]");
            return false;
        }
    }

    public boolean isAutoSaveDisabled() {
        return isElementPresent(pwXPath(SAVE_QUOTE_BUTTON_XPATH), 3);
    }

    public void clickOnSaveQuoteButton() throws Exception {
        if (isAutoSaveDisabled()) {
            Locator element = locator(pwXPath(SAVE_QUOTE_BUTTON_XPATH));
            scrollAndClickOnElement(waitElementBeVisible(element));
        }
    }

    protected boolean doesElementHaveFocus(Locator element) {
        try {
            return element.equals(activeElement());
        } catch (Exception e) {
            Log.debug("Exception while using Playwright page");
            return false;
        }
    }

    public synchronized String getErrorMessagesFromAllFields() throws Exception {
        StringBuilder errorMessage = new StringBuilder();
        List<Locator> listOfErrorMesages = locators(pwXPath("//mat-error[contains(@class,'mat-mdc-form-field-error')]"));
        if (!listOfErrorMesages.isEmpty()) {
            listOfErrorMesages.forEach(error -> errorMessage.append(getTextFromElement(error)));
        }
        return errorMessage.toString();
    }

    public boolean validateSaveQuoteModal(boolean isEmailInputPrefilled) throws Exception {
        final String SAVE_QUOTE_CONTENT = "Save quote";
        if (!isElementVisible(saveQuoteTextContent, 1)) {
            return true;
        }
        Assert.assertEquals(getTextFromElement(saveQuoteTextContent), SAVE_QUOTE_CONTENT, "Save Quote text is not matching.");
        return validateSaveQuoteModalContent(getAceQuoteNumberInThePage(), isEmailInputPrefilled);
    }


    public String getFormattedPhoneNumber(String number) {
        String formatted = "(%s) %s-%s";
        return String.format(formatted, number.substring(0, 3), number.substring(3, 6), number.substring(6));
    }

    public String getAttributeData(Locator webElement, String strAttributeName) {
        try {
            if (!strAttributeName.trim().isEmpty()) {
                String attributeData = webElement.getAttribute(strAttributeName);
                if (attributeData != null) {
                    return attributeData;
                } else {
                    return EMPTY_STRING;
                }
            }
        } catch (Exception e) {
            Log.info("Attribute: " + strAttributeName + " for " + webElement + " not found");
        }
        return EMPTY_STRING;
    }

    /**
     * Checks whether the specified attribute of a Locator contains the given text.
     * Waits 1 second before reading the attribute to allow for any DOM update latency.
     *
     * @param element       the Locator to inspect
     * @param attribute     the attribute name (e.g. "class", "value", "placeholder")
     * @param expectedText  the substring expected to be present in the attribute value
     * @return {@code true} if the attribute value contains {@code expectedText}; {@code false} otherwise
     */
    public boolean doesAttributeContainText(Locator element, String attribute, String expectedText) {
        String attributeValue = getAttributeData(element, attribute);
        boolean contains = attributeValue.contains(expectedText);
        if (!contains) {
            Log.info("Attribute [" + attribute + "] value [" + attributeValue + "] does not contain expected text [" + expectedText + "]");
        }
        return contains;
    }

    public void sendTab(Locator element) {
        try {
            sendKeys(element, Keys.TAB);
        } catch (Exception e) {
            System.out.println("Inside sendtab catch: " + e.getLocalizedMessage());
        }
    }

    public void jsClickElement(Locator element) throws Exception {
        try {
            conditionalWait(10).until(Conditions.clickable(element));
            waitForJSToLoad();
            executeScript("arguments[0].click();", element);
            Log.info("JS Click Element Successful");
        } catch (Exception e) {
            Log.warn("Error in clicking js click element");
        }
    }

    private static final String FAQ_XPATH = "//div[contains(@style, 'block')]//div[contains(@class,'AddPopup')]";
        protected Locator faqDialogTitle = locator(pwXPath(FAQ_XPATH + "/h2"));

        protected Locator faqDialogContent = locator(pwXPath(FAQ_XPATH + "/p"));

        protected Locator faqDialogOKButton = locator(pwXPath(FAQ_XPATH + "//input[@type='button']"));

    protected void validateFAQContent(LinkedHashMap<Locator, List<String>> faqContentMap, FarmersSoftAssert fsa) {
        for (Map.Entry<Locator, List<String>> faq : faqContentMap.entrySet()) {
            Locator faqButton = faq.getKey();
            List<String> faqContent = faq.getValue();
            scrollAndClickOnElement(faqButton);
            if (!isElementPresent(pwClass("AddPopup"), 3)) {
                scrollAndClickOnElement(faqButton);
            }
            waitElementBeVisible(faqDialogContent);
            String helpTitle = getTextFromElement(faqDialogTitle);
            if (helpTitle.contains("dogs")) {
                fsa.assertTrue(helpTitle.contains(faqContent.get(0)), faqDialogTitle + " title check");
            } else {
                fsa.assertEquals(helpTitle, faqContent.get(0), faqDialogTitle + " title check");
            }
            fsa.assertEquals(getTextFromElement(faqDialogContent), faqContent.get(1), faqDialogTitle + "dialog content check");
            clickElement(faqDialogOKButton);
        }
    }

    public void switchToParentWindow() throws Exception {
        switchToParentFrame();
    }

    public List<String> getDisplayedDiscounts() {
        clickReviewDiscountButton();
        waitElementBeVisible(discountsSidesheetTitle);
        List<String> displayedDiscounts = discounts.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        Collections.sort(displayedDiscounts);
        waitAndClickElement(closeIcon);
        return displayedDiscounts;
    }

    public boolean isSaveQuoteSideSheetOpen() {
        return isElementVisible(saveQuoteModalHeader, 1);
    }

    public void clickReviewDiscountButton() {
        closeQualtricsPopUp();
        scrollElementToMiddle(reviewDiscountsButton);
        waitAndClickElement(reviewDiscountsButton);
    }

    public void reviewDiscountSection(String page) throws Exception {
        int count = getTheDiscountCountFromBottomOfThePage();
        List<String> displayedDiscountsSideSheet = getDisplayedDiscounts();
        int sideSheetDiscountCount = displayedDiscountsSideSheet.size();
        testStepAssert(count == sideSheetDiscountCount, "Discount counts are matching in " + page);

    }

    public int getTheDiscountCountFromBottomOfThePage() throws Exception {
        String totalDiscountsAdded = getTextFromElement(discountAddedText);
        return Integer.parseInt(totalDiscountsAdded.replaceAll("[^0-9]", ""));
    }

    public boolean isDiscountSectionDisplayed() {
        return isElementVisible(discountAddedText, 1) || isElementVisible(reviewDiscountsButton, 1);
    }

    public void validateAssignedAgentSection(BasePage page, FarmersSoftAssert fsa) throws Exception {
        AppStore.Data.AgentData agentData = this.getSessionStorageAppStore().getData().getAgentData();
        String agentType = agentData.getAgentType() == null ? agentData.getAgencyType() : agentData.getAgentType();
        if (agentType != null && !agentType.equals("Political")) {
            String agentFirstName = agentData.getFirstName();
            String agentLastName = agentData.getLastName();
            String agentFullName = agentFirstName + SPACE + agentLastName;
            String simplePageName = page.getClass().getSimpleName();
            String agentPhone = agentData.getCommunication().getPhoneNumber().getPhoneNumber();
            String agentMail = agentData.getCommunication().getEmailId().getEmailAddress();
            String agentStreet = String.valueOf(agentData.getAddress().getStreet());
            String agentCity = String.valueOf(agentData.getAddress().getCity());
            String agentState = String.valueOf(agentData.getAddress().getState());
            String agentZipCode = String.valueOf(agentData.getAddress().getZip());
            boolean usingSafari = isSafariBrowser();
            String separator = usingSafari? EMPTY_STRING : SPACE;
            String agentCommunicationData = Stream.of(agentStreet,separator,agentCity,SPACE,agentState,SPACE,agentZipCode)
                    .filter(s -> s != null)
                    .collect(Collectors.joining(""));
            String agentAddressData = agentCommunicationData.replace("|", SPACE);
            scrollToBottomOfPage();
            //Agent images are not loading in test environments which is an issue for safari, so we can only check if element is present in DOM in that browser
            fsa.assertTrue(usingSafari ? isElementPresent(pwClass(AGENT_IMAGE_CLASS_NAME), 3) : isElementDisplayed(agentImage, 3), "Agent image found in " + simplePageName);
            fsa.assertTrue(!getAttributeData(agentImage, SRC).isEmpty(), "Agent image 'src' attribute is not empty in " + simplePageName);
            fsa.assertTrue(agentSectionYourAgent.isVisible(), "Your agent section displayed in "  + simplePageName);
            fsa.assertEquals(getTextFromElement(agentSectionYourAgent), "Your agent", "'Your agent' text in " + simplePageName);
            fsa.assertEquals(getTextFromElement(agentSectionAgentName).toLowerCase(), agentFullName.toLowerCase(), "Agent full name check in " + simplePageName);
            if (!StringUtils.isEmpty(agentPhone)) {
                fsa.assertTrue(agentPhoneNumber.isVisible(), "Agent phoneNumber displayed in " + simplePageName);
                fsa.assertEquals(getTextFromElement(agentPhoneNumber).replaceAll("[^0-9]", EMPTY_STRING).toLowerCase(), agentPhone.toLowerCase(), "Agent phoneNumber displayed in " + simplePageName);
            }
            if (!StringUtils.isEmpty(agentMail)) {
                fsa.assertTrue(agentMailID.isVisible(), "Agent MailID displayed");
                fsa.assertEquals(getTextFromElement(agentMailID).toLowerCase(), agentMail.toLowerCase(), "Agent MailID in " + simplePageName);
            }
            if (!agentStreet.contains("Po Box")) {
                fsa.assertTrue(agentAddress.isVisible(), "Agent Address displayed in " + simplePageName);
                fsa.assertEquals(getTextFromElement(agentAddress).replace(",", EMPTY_STRING).toLowerCase(), agentAddressData.toLowerCase().replace("|", EMPTY_STRING), "Agent address data check in " + simplePageName);
            }
            testStep("Validating agent section for the page: " + simplePageName, true);
        }
    }

    public boolean isEmailThisQuoteLinkDisplayed() {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCardButton, 2)) {
                scrollAndClickOnElement(expandQuoteCardButton);
            }
            return isElementDisplayed(emailLinkMobile, 2);
        } else {
            return isElementDisplayed(emailLinkDesktop, 2);
        }
    }

    public void validateEmailThisQuoteLink(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCardButton, 2)) {
                scrollAndClickOnElement(expandQuoteCardButton);
            }
            waitAndClickElement(emailLinkMobile, 5);
        } else {
            waitAndClickElement(emailLinkDesktop, 5);
        }
        waitForSpinnerToBeGone();
        scrollToBottomOfPage();
        boolean wasEmailSent = isSnackBarMessageDisplayed(String.format("A copy of your quote number has been emailed to %s", applicant.getEmailAddress()));
        fsa.assertTrue(wasEmailSent, this.getClass().getSimpleName() + " - Email sent snack bar message displayed.");
        if (wasEmailSent) {
        	waitAndClickElement(linkCloseEmailSnackBar, 5);
        }
    }

    protected static final String NAV_BAR_STEPPER_XPATH = "//tui-stepper-navbar//div[@class='tui-%s-nav-stepper']";

    public String getSelectedStepper(String browserType) throws Exception {
        String xpath = pwXPath(String.format(NAV_BAR_STEPPER_XPATH, browserType) +
                "/descendant::*[contains(@class,'tui-current-step-label') or contains(@class,'tui-completed-step-label')]");
        List<Locator> weSteps = locators(xpath);
        if (weSteps.isEmpty()) {
            return "No step currently selected";
        }
        if (weSteps.size() == 1) {
            return getTextFromElement(weSteps.get(0));

        } else {
            return getTextFromElement(weSteps.get(weSteps.size() - 1));
        }
    }

    public void selectStepper(String step) throws Exception {
        String browserType = isUseMobileViewEnabled() ? MOBILE_BROWSER : DESKTOP_BROWSER;
        Locator weStepperStep = locator(pwXPath(String.format(NAV_BAR_STEPPER_XPATH, browserType) +
                "/descendant::div/span[contains(text(),'" + step + "')]"));
        clickElement(weStepperStep);
    }

    public boolean isStepperDisplayed() {
        return isElementVisible(isUseMobileViewEnabled() ? mobileStepper : desktopStepper, 3);
    }

    public List<String> getListOfSteps() throws Exception {
        String browserType = isUseMobileViewEnabled() ? MOBILE_BROWSER : DESKTOP_BROWSER;
        String xpath = pwXPath(String.format(NAV_BAR_STEPPER_XPATH, browserType) +
                "/descendant::*[contains(@class,'tui-step-label')]");
        List<Locator> listOfSteps = locators(xpath);
        List<String> listOfStepStrings = listOfSteps.stream().map(this::getTextFromElement).collect(Collectors.toList());
        return listOfStepStrings;
    }

    public String getStepState(String step) throws Exception {
        String stepState = DISABLED;
        String browserType = isUseMobileViewEnabled() ? MOBILE_BROWSER : DESKTOP_BROWSER;
        String xpath = pwXPath(String.format(NAV_BAR_STEPPER_XPATH, browserType) +
                String.format("/descendant::*[contains(text(),'%s')]", step));
        List<Locator> listOfSteps = locators(xpath);
        if (!listOfSteps.isEmpty()) {
        	String stepClass = getAttributeData(listOfSteps.get(0), CLASS);
        	if (stepClass.contains("current") || stepClass.contains("completed")) {
        		stepState = "enabled";
        	}
        }
        return stepState;
    }

    // bundle related elements
    protected static final String CARD_XPATH_STRING = "//mat-card[contains(@class, '%s')]";
        protected Locator bundleQuoteContainer = locator(pwXPath("//div[contains(@class, 'container')][not(contains(@class, '-container'))]"));

    protected void verifyBundleQuoteLedgerComponent(String propertyType, String currentPageLOB, FarmersSoftAssert fsa) {
        String MONTHTLY_AUTOPAY_COLUMN_TITLE_XPATH = CARD_XPATH_STRING + "//thead//th[contains(@class, 'monthlyAutopay')]";
        String PAY_IN_FULL_COLUMN_TITLE_XPATH = CARD_XPATH_STRING + "//thead//th[contains(@class, 'payInFull')]";
        String LISTED_BUNDLES_COLUMN_XPATH = CARD_XPATH_STRING + "//div[@class='bundle-presentment-label']";
        String breakpoint = isUseMobileViewEnabled() || isMobileApplication() ? "mobile" : "desktop";
        Locator lookForElement = bundleQuoteContainer.locator(pwXPath(String.format(MONTHTLY_AUTOPAY_COLUMN_TITLE_XPATH, breakpoint)));
        fsa.assertEquals(getTextFromElement(lookForElement), "Monthly autopay", "Summary dialog monthly autopay column title verification");
        lookForElement = bundleQuoteContainer.locator(pwXPath(String.format(PAY_IN_FULL_COLUMN_TITLE_XPATH, breakpoint)));
        fsa.assertEquals(getTextFromElement(lookForElement), "Pay in full", "Summary dialog pay in full column title verification");
        List<Locator> listOfElements = bundleQuoteContainer.locator(pwXPath(String.format(LISTED_BUNDLES_COLUMN_XPATH, breakpoint))).all();
        fsa.assertEquals(getTextFromListOfLocatorsAndDescendents(listOfElements), new ArrayList<>(Arrays.asList("Auto", propertyType, "Total")), "Summary dialog listed bundles column content verification");
        List<Locator> listOfIcons = bundleQuoteContainer.locator(pwXPath(String.format(CARD_XPATH_STRING + "//mat-icon", breakpoint))).all();
        int rowIndex = currentPageLOB.equals(AUTO) ? 0 : 1;
        fsa.assertTrue(getTextFromElement(listOfIcons.get(rowIndex)).equals("forward"), "Arrow icon displayed for " + currentPageLOB);
        Locator fullPriceForPropertyLink = bundleQuoteContainer.locator(pwXPath(String.format(CARD_XPATH_STRING + "//a", breakpoint)));
        if (!getTextFromElement(fullPriceForPropertyLink).contains("full pricing")) {
            clickElement(fullPriceForPropertyLink);
        }
        fsa.assertTrue(isExpectedTextContainedInElement(fullPriceForPropertyLink, "View " + currentPageLOB.toLowerCase() + " quote with pay-in-full pricing"), "Full price " + currentPageLOB + " quote pricing link text");
        clickElement(fullPriceForPropertyLink);
        fsa.assertEquals(getTextFromElement(fullPriceForPropertyLink), "View " + currentPageLOB.toLowerCase() + " quote with monthly pricing", "Monthly price " + currentPageLOB + " quote link text");
        clickElement(fullPriceForPropertyLink);
    }

    protected static String randomPasswordGenerator() {
        return RandomStringUtils.randomAlphabetic(1).toUpperCase() + "_" + RandomStringUtils.randomAlphabetic(1).toLowerCase() + RandomStringUtils.randomAlphabetic(5) + RandomStringUtils.randomNumeric(5) + "!";
    }

    public String getBwAcceptableVin() throws Exception {

        List<AppStore.Auto.AppStoreVehicle> vehicles = getSessionStorageAppStore().getAuto().getVehicles();

        vehicles.removeIf(vehicle -> {
            try {
                String vin = vehicle.getVin();
                return vin == null;
            } catch (NullPointerException e) {
                // Defensive: if getVin() throws, remove the vehicle
                return true;
            }
        });
        List<String> bwVins = Arrays.asList("1HGCG165028C04291", "1HGEJ612XTLC05743", "5NPDH4AE0DH194307", "JTJGKCEZXN5004436", "YV4H60CX8P1940431", "1FTFW1EFXFKD13114", "2FMTK3J82FBB03727", "1FAFP31N27W308222");
        Collections.shuffle(bwVins);
        String selectedVin = bwVins.get(0);
        List<String> alreadyAddedVins = vehicles.stream().map(AppStore.Auto.AppStoreVehicle::getVin).collect(Collectors.toList());
        while (alreadyAddedVins.contains(selectedVin)) {
            Collections.shuffle(bwVins);
            selectedVin = bwVins.get(0);
        }
        return selectedVin;
    }

    public boolean isElementInRedColor(Locator element) {
        String messageColor = String.valueOf(element.evaluate("(e,p)=>getComputedStyle(e).getPropertyValue(p)", "color"));
        boolean inRedColor = messageColor.equals("rgba(197, 22, 45, 1)") || messageColor.equals("rgb(197, 22, 45)");

        if (!inRedColor) {
            String textFromElement = getTextFromElement(element);
            Log.warn("Element with text '" + textFromElement + "' is not in red");
        }
        return inRedColor;
    }

    public void verifyNotAbleToOfferBundleCardContent(FarmersSoftAssert fsa, String propertyType) {
        fsa.assertTrue(notAbleToOfferBundleQuoteCard.isVisible(), "Not able to offer bundle quote");
        fsa.assertTrue(notAbleToOfferBundleQuoteMessageIcon.isVisible(), "Message icon in not able to offer bundle quote card");
        final String EXPECTED_NOT_ABLE_TO_OFFER_BUNDLE_MSG = "We're sorry, we are not able to offer a bundle quote at this time.";
        fsa.assertEquals(getTextFromElement(notAbleToOfferBundleQuoteMessage), EXPECTED_NOT_ABLE_TO_OFFER_BUNDLE_MSG, "Not able to offer bundle quote message text verification");
        final String EXPECTED_WE_CAN_STILL_OFFER_LOB_QUOTE_MSG = "We can still offer this " + propertyType.toLowerCase() + " quote below, but it won't include the bundle discount.";
        fsa.assertEquals(getTextFromElement(weCanStillOfferThisLOBQuoteMessage), EXPECTED_WE_CAN_STILL_OFFER_LOB_QUOTE_MSG, "We can still offer quote message text verification");
    }

    public void navigateBack() throws Exception {
        back();
        waitForSpinnerToBeGone();
    }

    public List<String> getSortedList(List<String> list) {
        List<String> sortedList = new ArrayList<>(list);
        Collections.sort(sortedList);
        return sortedList;
    }

    public boolean containsSubstringInList(List<String> stringList, String subString) {
        for (String s : stringList) {
            if (s.contains(subString)) {
                return true; // Found a string in the list that contains the subString
            }
        }
        return false; // No string in the list contains the subString
    }


    protected void switchToNewTab(int tab) throws Exception {
        ArrayList<Page> availableWindows = new ArrayList<>(pages());
        if (!availableWindows.isEmpty()) {
            int targetIndex = Math.min(tab, availableWindows.size() - 1);
            if (targetIndex != tab) {
                Log.info("Requested tab index " + tab + " but only " + availableWindows.size() + " page(s) were available. Switching to newest page instead.");
            }
            switchToPage(availableWindows.get(targetIndex));
        }
    }

    protected String getLobTypeFromAppStore() throws Exception {
        return getSessionStorageAppStore().getData().getLob();
    }

    protected String getStateCodeFromAppStore() throws Exception {
        return getSessionStorageAppStore().getData().getLandingStateCode();
    }

    public String getPniFullNameFromAutoApplicant(AutoApplicant applicant){
        return applicant.getFirstName() + SPACE + applicant.getLastName();
    }

    public String getPniFullNameFromAutoAdpfApplicant(ADPFApplicant applicant){
        return applicant.getFirstName() + SPACE + applicant.getLastName();
    }

    public void validateTFNIsNotDisplayedInAgentFlow(FarmersSoftAssert fsa){
        fsa.assertTrue(!isElementPresentByXPath("//a[@data-test-id='TUI_PHONE_ICON']"), "Toll Free Number is not displayed");
    }

    public void noSaveQuoteLinkAndQuoteNumber(FarmersSoftAssert fsa){
        fsa.assertTrue(!isElementPresent(pwXPath(QUOTE_NUMBER_XPATH), 1), "Save quote button and quote number is not displayed");
    }

    /**
     * Checks if all expected values are present in the actual values list.
     * @param expected List of expected values
     * @param actual List of actual values
     * @return true if all expected values are present in actual
     */
    public boolean isExpectedListIncludedInActual(List<String> expected, List<String> actual) {
        if (expected == null || actual == null) return false;
        return expected.stream().allMatch(actual::contains);
    }

    public void validateQuoteSourceIndicator(FarmersSoftAssert fsa, String sourceIndicator, String page) throws Exception {
        fsa.assertEquals(getSessionStorageAppStore().getData().getSourceIndicator(), sourceIndicator, "Quote sourceIndicator is " +
                sourceIndicator + " on page: " + page);
    }

    protected boolean isSafariBrowser() {
        return Property.getBrowser().equals(SAFARI);
    }

}
