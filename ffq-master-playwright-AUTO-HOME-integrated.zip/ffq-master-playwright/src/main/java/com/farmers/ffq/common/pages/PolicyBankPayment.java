package com.farmers.ffq.common.pages;





import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.bindpages.AutoPolicyPaymentBasePage;
public class PolicyBankPayment extends AutoPolicyPaymentBasePage {

    private static final String BANK_ACCOUNT_TYPE_HEADER = "BANK ACCOUNT TYPE";
        private Locator bankAccountTypeHeader = locator(pwXPath("//legend[contains(text(), '" + BANK_ACCOUNT_TYPE_HEADER + "')]"));

        private Locator checkingRadioButton = locator(pwXPath("//fieldset//div/div[1]"));

        private Locator checkingRadioButtonInput = locator(pwXPath("//fieldset//div/div[1]/input"));

    private static final String CHECKING_LABEL = "Checking";
        private Locator checkingLabel = locator(pwXPath("//label[text() = '" + CHECKING_LABEL + "']"));

        private Locator savingsRadioButton = locator(pwXPath("//fieldset//div/div[2]"));

        private Locator businessCheckingRadioButton = locator(pwXPath("//fieldset//div/div[3]"));

    private static final String ACCOUNT_HOLDER_NAME_LABEL = "Account Holder Name";
        private Locator accountHolderNameLabel = locator(pwXPath("//label[text() = '" + ACCOUNT_HOLDER_NAME_LABEL + "']"));

    private static final String BANK_ROUTING_NUMBER = "Bank Routing Number (9 digits)";
        private Locator bankRoutingNumberLabel = locator(pwXPath("//label[text() = '" + BANK_ROUTING_NUMBER + "']"));

        private Locator routingNumberInputField = locator(pwXPath("//input[@id='routingNumberField']"));

    private static final String ACCOUNT_NUMBER = "Account Number";
        private Locator accountNumberLabel = locator(pwXPath("//label[text() = '" + ACCOUNT_NUMBER + "']"));

        private Locator accountNumberInputField = locator(pwXPath("//input[@id='bankAccountField']"));

    private static final String CONFIRM_ACCOUNT_NUMBER = "Confirm Account Number";
        private Locator confirmAccountNumberLabel = locator(pwXPath("//label[text() = '" + CONFIRM_ACCOUNT_NUMBER + "']"));

        private Locator confirmBankAccountInputField = locator(pwXPath("//input[@id='confirmBankAccountField']"));


    private static final String CHECK_CIRCLE = "check_circle";
        private Locator greenCheckMark = locator(pwXPath("//mat-icon[text() = '" + CHECK_CIRCLE + "']"));

    public static final String NO_SERVICE_CHARGE_WHEN_USING_BANK = "No service charges when using bank transfer.";
        private Locator noServiceChargeWhenUsingBankTransfer = locator(pwXPath("//span[text() = '" + NO_SERVICE_CHARGE_WHEN_USING_BANK + "']"));

        private Locator maskedAccountNumber = locator(pwXPath("//*[@id='accountNumber']"));

    protected static final String CHANGE_TO_NEW_PAYMENT_METHOD = "Change to a new payment method";
        private Locator changeToNewPaymentMethodHeader = locator(pwXPath("//span[contains(text(), 'Change to a new payment method')]"));

    private static final String INFORMATION_STORAGE_AUTHORIZATION = "Information Storage Authorization";
    private static final String READ_AND_AGREED_TO_THE_BULLET_TWO_PAY_IN_FULL = "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries (\"Farmers\") to initiate:";
        private Locator readAndAgreedToTheBulletPointTwoPayInFull = locator(pwXPath("//a[contains(text(), '" + INFORMATION_STORAGE_AUTHORIZATION + "')]/parent::p"));

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public PolicyBankPayment() throws Exception {
    }

    public boolean isBankAccountTypeHeaderCorrect() {
        return isExpectedTextDisplayed(bankAccountTypeHeader, BANK_ACCOUNT_TYPE_HEADER);
    }

    public boolean isCheckingRadioButtonSelected(){
        waitElementBeVisible(checkingRadioButton);
        return checkingRadioButtonInput.isChecked();
    }

    public boolean isCheckingLabelCorrect(){
        return isExpectedTextDisplayed(checkingLabel, CHECKING_LABEL);
    }

    public boolean isSavingsRadioButtonEnabled(){
        return savingsRadioButton.isEnabled();
    }


    public boolean isBusinessCheckingRadioButtonEnabled(){
        return businessCheckingRadioButton.isEnabled();
    }

    public boolean isAccountHolderNameLabelCorrect(){
        return isExpectedTextDisplayed(accountHolderNameLabel, ACCOUNT_HOLDER_NAME_LABEL);
    }

    public boolean isBankRoutingNumberLabelCorrect(){
        return isExpectedTextDisplayed(bankRoutingNumberLabel, BANK_ROUTING_NUMBER);
    }

    public boolean isAccountNumberLabelCorrect(){
        return isExpectedTextDisplayed(accountNumberLabel, ACCOUNT_NUMBER);
    }

    public boolean isConfirmAccountNumberLabelCorrect(){
        return isExpectedTextDisplayed(confirmAccountNumberLabel, CONFIRM_ACCOUNT_NUMBER);
    }

    public void enterAccountNumber(String accountNumber){
        sendKeysOneByOne(accountNumberInputField, accountNumber);
    }

    public void enterConfirmAccountNumber(String accountNumber){
        sendKeysOneByOne(confirmBankAccountInputField, accountNumber);
    }

    public boolean isNoServiceChargeWhenUsingBankMsgCorrect(){
        return isExpectedTextDisplayed(noServiceChargeWhenUsingBankTransfer, NO_SERVICE_CHARGE_WHEN_USING_BANK);
    }


    public boolean isHiddenBankAccountMonthlyPayTextCorrect(String bankAccountNumber) throws Exception {
        String lastFourDigitOfAccountNumber;
        if(bankAccountNumber == null){
            lastFourDigitOfAccountNumber = getSessionStorageAppStore().getPaymentusIframeData().getMaskedAccountNumber().replaceAll("[*]","");
        }else{
            lastFourDigitOfAccountNumber = bankAccountNumber.substring(bankAccountNumber.length()-2);
        }
        wait.until(Conditions.visible(maskedAccountNumber));
        return getTextFromElement(maskedAccountNumber).contains(lastFourDigitOfAccountNumber);
    }

    public boolean isHiddenBankAccountPayInFullTextCorrect(String bankAccountNumber) throws Exception {
        String lastFourDigitOfAccountNumber;
        if(bankAccountNumber == null){
            lastFourDigitOfAccountNumber = getSessionStorageAppStore().getPaymentusIframeData().getMaskedAccountNumber().replaceAll("[*]","");
        }else{
            lastFourDigitOfAccountNumber = bankAccountNumber.substring(bankAccountNumber.length()-4);
        }
        scrollElementToMiddle(maskedAccountNumber);
        return getTextFromElement(maskedAccountNumber).contains(lastFourDigitOfAccountNumber);
    }

    public boolean isChangeToPaymentMethodLabelCorrect(){
        wait.until(Conditions.visible(changeToNewPaymentMethodHeader));
        return isExpectedTextDisplayed(changeToNewPaymentMethodHeader, CHANGE_TO_NEW_PAYMENT_METHOD);
    }

    public boolean isReadAndAgreedBulletPointTwoPayInFullCorrect(){
        return isExpectedTextDisplayed(readAndAgreedToTheBulletPointTwoPayInFull, READ_AND_AGREED_TO_THE_BULLET_TWO_PAY_IN_FULL);
    }

}
