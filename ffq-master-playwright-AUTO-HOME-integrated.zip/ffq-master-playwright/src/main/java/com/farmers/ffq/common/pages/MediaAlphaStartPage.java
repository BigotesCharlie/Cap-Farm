package com.farmers.ffq.common.pages;


import com.microsoft.playwright.Locator;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;

import org.testng.Assert;
import org.testng.SkipException;

import static com.farmers.ffq.utils.GlobalVariables.AUTO;
import static com.farmers.ffq.utils.GlobalVariables.HOME;


public class MediaAlphaStartPage extends BasePage {
    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public MediaAlphaStartPage() throws Exception {
    }

    public boolean isOnMediaAlphaStartPage() {
        return isElementVisible(zipCode, Property.PAGELOADTIMEOUT);
    }

        private Locator zipCode = locator(pwXPath("//div[@id='main-panel']//form[@id='zip-form']//input[@name='zip']"));

        private Locator startMyQuoteButton = locator(pwXPath("//div[@id='main-panel']//form[@id='zip-form']//button[contains(text(),'Start My Quote')]"));

    public void processMediaAlphaStartPage(String zip, String lob) throws Exception {
        String envProperty = "";
        if (lob.equals(HOME)) {
            envProperty = "ma_home";
        } else if (lob.equals(AUTO)) {
            envProperty = "ma_auto";
        }
        String urlMediaAlpha = Property.getEnvironmentProperty(envProperty);
        if (urlMediaAlpha==null || urlMediaAlpha.isBlank()) {
        	throw new SkipException ("Media alpha site definition not found for " + Property.getTestProperty("environment"));
        }
        if (isUseMobileViewEnabled()) {
            setBrowserDimensionToMobileBreakPoint();
        } else {
            maximizeTheBrowser();
        }
        Log.info("Currenlty running media alpha tests only in browser with desktop view.");

        navigate(urlMediaAlpha);
        Log.info("Media Alpha URL: " + urlMediaAlpha);
        Assert.assertTrue(isOnMediaAlphaStartPage(), "Did not reach Media Alpha Start page.");

        enterZip(zip);
        clickStartMyQuote();
        switchToNewTab(1);
    }

    private void enterZip(String zip) {
        sendKeysToElement(waitElementBeVisible(zipCode), zip);
        Log.info("Zip code entered: " + zip);
    }

    private void clickStartMyQuote() {
        waitAndClickElement(startMyQuoteButton);
    }

}
