package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.farmers.ffq.homevideoflow.support.DomArtifacts;
import com.farmers.ffq.common.SubmitDiagnostics;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public final class AboutYouPage extends BaseHomePage {
    private final DomArtifacts artifacts;

    public AboutYouPage(Page page) {
        this(page, null);
    }

    public AboutYouPage(Page page, DomArtifacts artifacts) {
        super(page);
        this.artifacts = artifacts;
    }

    public void complete(VideoScenarioData d) {
        waitForBodyReady();
        waitForSpinnerToClear();

        fillFirstName(d.firstName());
        fillLastName(d.lastName());
        fillDob(d.dob());
        selectGender(d.gender());

        if (artifacts != null) {
            captureAboutYouEvidence();
            captureBeforeSubmitEvidence();
        }

        Locator continueButton = page.locator("div.button-display button").last();
        if (continueButton.count() == 0) {
            continueButton = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Continue").setExact(true));
        }
        if (continueButton.count() == 0) {
            throw new IllegalStateException("HVF-ABOUT-001: Continue button not found at " + page.url());
        }

        boolean enabledBefore = continueButton.first().isEnabled();
        String buttonText = safeText(continueButton.first());
        String urlBefore = page.url();
        long clickTs = System.currentTimeMillis();
        if (artifacts != null) {
            artifacts.writeText("about-you-submit-event.txt",
                    "timestamp=" + clickTs + System.lineSeparator()
                            + "urlBefore=" + urlBefore + System.lineSeparator()
                            + "buttonText=" + buttonText + System.lineSeparator()
                            + "buttonEnabled=" + enabledBefore + System.lineSeparator()
                            + "buttonDisabled=" + continueButton.first().isDisabled() + System.lineSeparator());
        }

        SubmitDiagnostics diagnostics = null;
        if (artifacts != null) {
            diagnostics = new SubmitDiagnostics(page);
            diagnostics.start("video-about-you-submit");
        }
        try {
            continueButton.first().click();
            page.waitForTimeout(5_000);
            try {
                waitForSpinnerToClear();
            } catch (RuntimeException ignored) {
            }

            if (artifacts != null) {
                captureAfterSubmitEvidence();
            }

            String currentUrl = page.url().toLowerCase();
            if (currentUrl.contains("contact-info")
                    || currentUrl.contains("review-quote")
                    || currentUrl.contains("custom-coverage")) {
                return;
            }

            if (currentUrl.contains("inconvenience")) {
                if (artifacts != null) {
                    captureInconvenienceEvidence();
                }
                throw new IllegalStateException("HVF-ABOUT-001: ABOUT_YOU submit navigated to inconvenience at " + page.url());
            }

            if (currentUrl.contains("knockout")) {
                throw new IllegalStateException("HVF-ABOUT-001: ABOUT_YOU submit navigated to knockout at " + page.url());
            }

            throw new IllegalStateException("HVF-ABOUT-001: ABOUT_YOU submit did not advance from " + page.url());
        } finally {
            if (diagnostics != null && artifacts != null) {
                diagnostics.stop("video-about-you-submit");
                artifacts.writeText("about-you-network-events.txt", diagnostics.networkEventsText());
                artifacts.writeText("about-you-console.txt", diagnostics.consoleEventsText());
                artifacts.writeText("about-you-page-errors.txt", diagnostics.pageErrorsText());
                artifacts.writeText("about-you-request-failures.txt", diagnostics.requestFailuresText());
                diagnostics.close();
            }
        }
    }

    private void fillFirstName(String firstName) {
        Locator field = page.getByLabel("First name", new Page.GetByLabelOptions().setExact(false));
        if (field.count() == 0) {
            field = page.locator("input[aria-label*='First name']");
        }
        if (field.count() > 0) {
            field.first().fill(firstName);
            field.first().press("Tab");
        }
    }

    private void fillLastName(String lastName) {
        Locator field = page.getByLabel("Last name", new Page.GetByLabelOptions().setExact(false));
        if (field.count() == 0) {
            field = page.locator("input[aria-label*='Last name']");
        }
        if (field.count() > 0) {
            field.first().fill(lastName);
            field.first().press("Tab");
        }
    }

    private void fillDob(String dob) {
        String mmddyyyy = dob.replace("/", "");
        Locator field = page.locator("input[aria-label='Date of birth in the format of mmddyyyy.']");
        if (field.count() == 0) {
            field = page.getByLabel("Date of birth", new Page.GetByLabelOptions().setExact(false));
        }
        if (field.count() > 0) {
            field.first().fill(mmddyyyy);
            field.first().press("Tab");
        }
    }

    private void selectGender(String gender) {
        Locator radio = page.getByRole(AriaRole.RADIO, new Page.GetByRoleOptions().setName(gender).setExact(true));
        if (radio.count() > 0) {
            Locator choice = radio.first();
            if (!choice.isChecked()) {
                choice.click();
            }
            return;
        }
        Locator text = page.getByText(gender, new Page.GetByTextOptions().setExact(true));
        if (text.count() > 0) {
            text.first().click();
        }
    }

    private void captureAboutYouEvidence() {
        artifacts.captureNamed("about-you-before-continue");
        artifacts.writeText("about-you-url.txt", page.url());
        artifacts.writeText("about-you-fields.txt", summarizeFields());
        artifacts.writeText("about-you-buttons.txt", summarizeButtons());
        artifacts.writeText("about-you-validation.txt", summarizeValidation());
    }

    private void captureBeforeSubmitEvidence() {
        artifacts.captureNamed("about-you-before-submit");
        artifacts.writeText("about-you-before-submit-fields.txt", summarizeFields());
        artifacts.writeText("about-you-before-submit-url.txt", page.url());
    }

    private void captureAfterSubmitEvidence() {
        artifacts.captureNamed("about-you-after-submit");
        artifacts.writeText("about-you-after-submit-url.txt", page.url());
        artifacts.writeText("about-you-after-submit-fields.txt", summarizeFields());
        artifacts.writeText("about-you-after-submit-buttons.txt", summarizeButtons());
        artifacts.writeText("about-you-after-submit-validation.txt", summarizeValidation());
    }

    private void captureInconvenienceEvidence() {
        artifacts.captureNamed("about-you-inconvenience");
        artifacts.writeText("about-you-inconvenience-url.txt", page.url());
    }

    private String summarizeFields() {
        StringBuilder out = new StringBuilder();
        appendGroup(out, "input", "input");
        appendGroup(out, "select", "select");
        appendGroup(out, "textarea", "textarea");
        appendGroup(out, "mat-form-field", "mat-form-field");
        appendGroup(out, "mat-radio-button", "mat-radio-button");
        return out.toString();
    }

    private String summarizeButtons() {
        StringBuilder out = new StringBuilder();
        Locator buttons = page.locator("button,[role='button']");
        for (int i = 0; i < buttons.count(); i++) {
            Locator b = buttons.nth(i);
            if (!b.isVisible()) continue;
            out.append(describe("button", b)).append('\n');
        }
        return out.toString();
    }

    private String summarizeValidation() {
        StringBuilder out = new StringBuilder();
        Locator validation = page.locator("[aria-invalid='true'], .error, .errors, .validation, .invalid, mat-error, [role='alert']");
        for (int i = 0; i < validation.count(); i++) {
            Locator v = validation.nth(i);
            if (!v.isVisible()) continue;
            out.append(v.textContent()).append('\n');
        }
        return out.toString();
    }

    private void appendGroup(StringBuilder out, String tag, String selector) {
        Locator group = page.locator(selector);
        for (int i = 0; i < group.count(); i++) {
            Locator el = group.nth(i);
            if (!el.isVisible()) continue;
            out.append(describe(tag, el)).append('\n');
        }
    }

    private String describe(String tag, Locator el) {
        return String.join(" | ",
                "tag=" + tag,
                "id=" + safeAttr(el, "id"),
                "name=" + safeAttr(el, "name"),
                "formControlName=" + safeAttr(el, "formcontrolname"),
                "aria-label=" + safeAttr(el, "aria-label"),
                "placeholder=" + safeAttr(el, "placeholder"),
                "value=" + safeValue(el),
                "required=" + safeAttr(el, "required") + "/" + safeAttr(el, "aria-required"),
                "disabled=" + safeBool(el::isDisabled),
                "aria-invalid=" + safeAttr(el, "aria-invalid"),
                "visible=" + safeBool(el::isVisible),
                "editable=" + safeBool(el::isEditable),
                "checked=" + safeBool(el::isChecked)
        );
    }

    private String safeAttr(Locator el, String name) {
        try {
            String value = el.getAttribute(name);
            return value == null ? "" : value;
        } catch (RuntimeException e) {
            return "";
        }
    }

    private String safeValue(Locator el) {
        try {
            String value = el.inputValue();
            return value == null ? "" : value;
        } catch (RuntimeException e) {
            return "";
        }
    }

    private String safeText(Locator el) {
        try {
            String value = el.innerText();
            return value == null ? "" : value.trim();
        } catch (RuntimeException e) {
            return "";
        }
    }

    private String safeBool(BooleanSupplier supplier) {
        try {
            return Boolean.toString(supplier.getAsBoolean());
        } catch (RuntimeException e) {
            return "";
        }
    }

    @FunctionalInterface
    private interface BooleanSupplier {
        boolean getAsBoolean();
    }
}
