package com.farmers.ffq.auto.pages.legacy;


import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.SqlApplicant;
import com.farmers.ffq.datatransferobjects.SqlPayment;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;

import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PaymentPage extends AutoBasePage  {
	private static final String PAYMENT_PAGE_HEADER = "//div[@id='PaymentContent']/div[@id='Intro']";
		private Locator paymentPageTitle = locator(pwXPath(PAYMENT_PAGE_HEADER + "/p[@title='PAYMENT DETAILS']"));

		private Locator paymentPageDescription = locator(pwXPath(PAYMENT_PAGE_HEADER + "/p[@class='subTitleAlign']"));

		private Locator termPremium = locator(pwXPath(PAYMENT_PAGE_HEADER + "/p[@id='termPremiumSecText']"));

		private Locator paymentPlanHeader = locator(pwXPath("//span[contains(@id,'payment:paymentHeaderText')]"));

		private Locator changePaymentPlanLink = locator(pwId("MoreOptions"));
	
		private Locator continueToSignButton = locator(pwId("payment:doInitiateESignature"));

		private Locator agreeToUseESign = locator(pwId("disclosureAccepted"));
	
		private Locator continueFromESign = locator(pwId("action-bar-btn-continue"));
	
		private Locator bwFinishDocReviewButton = locator(pwId("action-bar-btn-finish"));
	  
	//Select Payment Dialog
		private Locator selectPaymentDialogTitle = locator(pwXPath("//div[contains(@class, 'selectPaymentOptionHeading')]"));

	private static final String RADIO_BUTTON_SECTION = "//div[contains(@class, 'radioAlign')]";
	private static final String DUE_TODAY_SECTION = "//div[contains(@class, 'dueToday')]";
	private static final String NEXT_PAYMENT_SECTION = "//div[contains(@class, 'nextPaymentDueClass')]";
	private static final String PAYMENT_SCHEDULE_SECTION = "//div[contains(@class, 'paymentScheduleClass')]";

	//Payment plans
	//Pay in Full
	private static final String PAY_IN_FULL_SECTION = "//div[contains(@class, 'A1DivClass')]";
		private Locator payInFullOption = locator(pwXPath(PAY_IN_FULL_SECTION));

		private Locator payInFullRadioButtonSection = locator(pwXPath(PAY_IN_FULL_SECTION + RADIO_BUTTON_SECTION));

		private Locator payInFullDueTodaySection = locator(pwXPath(PAY_IN_FULL_SECTION + DUE_TODAY_SECTION));

		private Locator payInFullNextPaymentSection = locator(pwXPath(PAY_IN_FULL_SECTION + NEXT_PAYMENT_SECTION));

		private Locator payInFullPaymentScheduleSection = locator(pwXPath(PAY_IN_FULL_SECTION + PAYMENT_SCHEDULE_SECTION));

	// Monthly Auto Pay - Bank Account
	private static final String MONTHLY_BANK_ACCOUNT_SECTION = "//div[contains(@class, 'MTEFDivClass')]";
		private Locator monthlyBankAccountOption = locator(pwXPath(MONTHLY_BANK_ACCOUNT_SECTION));

		private Locator monthlyBankAccountRadioButtonSection = locator(pwXPath(MONTHLY_BANK_ACCOUNT_SECTION + RADIO_BUTTON_SECTION));

		private Locator monthlyBankAccountDueTodaySection = locator(pwXPath(MONTHLY_BANK_ACCOUNT_SECTION + DUE_TODAY_SECTION));

		private Locator monthlyBankAccountNextPaymentSection = locator(pwXPath(MONTHLY_BANK_ACCOUNT_SECTION + NEXT_PAYMENT_SECTION));

		private Locator monthlyBankAccountPaymentScheduleSection = locator(pwXPath(MONTHLY_BANK_ACCOUNT_SECTION + PAYMENT_SCHEDULE_SECTION));

	// Monthly Auto Pay - Credit Card
	private static final String MONTHLY_CREDIT_CARD_SECTION = "//div[contains(@class, 'MTPCDivClass')]";
		private Locator monthlyCreditCardOption = locator(pwXPath(MONTHLY_CREDIT_CARD_SECTION));

		private Locator monthlyCreditCardRadioButtonSection = locator(pwXPath(MONTHLY_CREDIT_CARD_SECTION + RADIO_BUTTON_SECTION));

		private Locator monthlyCreditCardDueTodaySection = locator(pwXPath(MONTHLY_CREDIT_CARD_SECTION + DUE_TODAY_SECTION));

		private Locator monthlyCreditCardNextPaymentSection = locator(pwXPath(MONTHLY_CREDIT_CARD_SECTION + NEXT_PAYMENT_SECTION));

		private Locator monthlyCreditCardPaymentScheduleSection = locator(pwXPath(MONTHLY_CREDIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION));

	// Monthly Auto Pay - Debit Card
	private static final String MONTHLY_DEBIT_CARD_SECTION = "//div[contains(@class, 'MTPDDivClass')]";
		private Locator monthlyDebitCardOption = locator(pwXPath(MONTHLY_DEBIT_CARD_SECTION));

		private Locator monthlyDebitCardRadioButtonSection = locator(pwXPath(MONTHLY_DEBIT_CARD_SECTION + RADIO_BUTTON_SECTION));

		private Locator monthlyDebitCardDueTodaySection = locator(pwXPath(MONTHLY_DEBIT_CARD_SECTION + DUE_TODAY_SECTION));

		private Locator monthlyDebitCardNextPaymentSection = locator(pwXPath(MONTHLY_DEBIT_CARD_SECTION + NEXT_PAYMENT_SECTION));

		private Locator monthlyDebitCardPaymentScheduleSection = locator(pwXPath(MONTHLY_DEBIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION));

	//Monthly Billing
	private static final String MONTHLY_BILLING_SECTION = "//div[contains(@class, 'MTDivClass')]";
		private Locator monthlyBillingOption = locator(pwXPath(MONTHLY_BILLING_SECTION));

		private Locator monthlyBillingRadioButtonSection = locator(pwXPath(MONTHLY_BILLING_SECTION + RADIO_BUTTON_SECTION));

		private Locator monthlyBillingDueTodaySection = locator(pwXPath(MONTHLY_BILLING_SECTION + DUE_TODAY_SECTION));

		private Locator monthlyBillingNextPaymentSection = locator(pwXPath(MONTHLY_BILLING_SECTION + NEXT_PAYMENT_SECTION));

		private Locator monthlyBillingPaymentScheduleSection = locator(pwXPath(MONTHLY_BILLING_SECTION + PAYMENT_SCHEDULE_SECTION));

	// Bristol West Payment plans
	// Pay in Full
	private static final String BW_PAY_IN_FULL_SECTION = "//div[contains(@class, 'PIFDivClass')]";
		private Locator bwPayInFullOption = locator(pwXPath(BW_PAY_IN_FULL_SECTION));

		private Locator bwPayInFullRadioButtonSection = locator(pwXPath(BW_PAY_IN_FULL_SECTION + RADIO_BUTTON_SECTION));

		private Locator bwPayInFullDueTodaySection = locator(pwXPath(BW_PAY_IN_FULL_SECTION + DUE_TODAY_SECTION));

		private Locator bwPayInFullNextPaymentSection = locator(pwXPath(BW_PAY_IN_FULL_SECTION + NEXT_PAYMENT_SECTION));

		private Locator bwPayInFullPaymentScheduleSection = locator(pwXPath(BW_PAY_IN_FULL_SECTION + PAYMENT_SCHEDULE_SECTION));

	// Monthly Auto Pay - Bank Account
	private static final String BW_MONTHLY_BANK_ACCOUNT_SECTION = "//div[contains(@class, 'EFTBDivClass')]";
		private Locator bwMonthlyBankAccountOption = locator(pwXPath(BW_MONTHLY_BANK_ACCOUNT_SECTION));

		private Locator bwMonthlyBankAccountRadioButtonSection = locator(pwXPath(BW_MONTHLY_BANK_ACCOUNT_SECTION + RADIO_BUTTON_SECTION));

		private Locator bwMonthlyBankAccountDueTodaySection = locator(pwXPath(BW_MONTHLY_BANK_ACCOUNT_SECTION + DUE_TODAY_SECTION));

		private Locator bwMonthlyBankAccountNextPaymentSection = locator(pwXPath(BW_MONTHLY_BANK_ACCOUNT_SECTION + NEXT_PAYMENT_SECTION));

		private Locator bwMonthlyBankAccountPaymentScheduleSection = locator(pwXPath(BW_MONTHLY_BANK_ACCOUNT_SECTION + PAYMENT_SCHEDULE_SECTION));

	// Monthly Auto Pay - Credit Card
	private static final String BW_MONTHLY_CREDIT_CARD_SECTION = "//div[contains(@class, 'EFTCDivClass')]";
		private Locator bwMonthlyCreditCardOption = locator(pwXPath(BW_MONTHLY_CREDIT_CARD_SECTION));

		private Locator bwMonthlyCreditCardRadioButtonSection = locator(pwXPath(BW_MONTHLY_CREDIT_CARD_SECTION + RADIO_BUTTON_SECTION));

		private Locator bwMonthlyCreditCardDueTodaySection = locator(pwXPath(BW_MONTHLY_CREDIT_CARD_SECTION + DUE_TODAY_SECTION));

		private Locator bwMonthlyCreditCardNextPaymentSection = locator(pwXPath(BW_MONTHLY_CREDIT_CARD_SECTION + NEXT_PAYMENT_SECTION));

		private Locator bwMonthlyCreditCardPaymentScheduleSection = locator(pwXPath(BW_MONTHLY_CREDIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION));

	// Monthly Auto Pay - Debit Card
	private static final String BW_MONTHLY_DEBIT_CARD_SECTION = "//div[contains(@class, 'EFTDDivClass')]";
		private Locator bwMonthlyDebitCardOption = locator(pwXPath(BW_MONTHLY_DEBIT_CARD_SECTION));

		private Locator bwMonthlyDebitCardRadioButtonSection = locator(pwXPath(BW_MONTHLY_DEBIT_CARD_SECTION + RADIO_BUTTON_SECTION));

		private Locator bwMonthlyDebitCardDueTodaySection = locator(pwXPath(BW_MONTHLY_DEBIT_CARD_SECTION + DUE_TODAY_SECTION));

		private Locator bwMonthlyDebitCardNextPaymentSection = locator(pwXPath(BW_MONTHLY_DEBIT_CARD_SECTION + NEXT_PAYMENT_SECTION));

		private Locator bwMonthlyDebitCardPaymentScheduleSection = locator(pwXPath(BW_MONTHLY_DEBIT_CARD_SECTION + PAYMENT_SCHEDULE_SECTION));

	//Monthly Billing
	private static final String BW_MONTHLY_BILLING_SECTION = "//div[contains(@class, 'NONDivClass')]";
		private Locator bwMonthlyBillingOption = locator(pwXPath(BW_MONTHLY_BILLING_SECTION));

		private Locator bwMonthlyBillingRadioButtonSection = locator(pwXPath(BW_MONTHLY_BILLING_SECTION + RADIO_BUTTON_SECTION));

		private Locator bwMonthlyBillingDueTodaySection = locator(pwXPath(BW_MONTHLY_BILLING_SECTION + DUE_TODAY_SECTION));

		private Locator bwMonthlyBillingNextPaymentSection = locator(pwXPath(BW_MONTHLY_BILLING_SECTION + NEXT_PAYMENT_SECTION));

		private Locator bwMonthlyBillingPaymentScheduleSection = locator(pwXPath(BW_MONTHLY_BILLING_SECTION + PAYMENT_SCHEDULE_SECTION));

		private Locator continueButton = locator(pwXPath("//input[@value='Continue']"));

	/**
	 * Constructor.
	 *
	 * @throws Exception 
	 */
	public PaymentPage() throws Exception {
		super();
		checkForKnockout("PaymentPage constructor");
		if (!isElementPresentByClass(errorMessageElement)) {
			waitElementBeVisible(selectPaymentDialogTitle);
		}
	}

	public void processPaymentPage(SqlApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		if (!isElementPresentByClass(errorMessageElement)) {
			boolean isBristolWestQuote = isBristolWestQuote();
			if (isElementPresentByID(continueToSignButton)) {
				clickElement(continueToSignButton);
				waitForPageToBeReady();
				waitForSpinnerToBeGone();
				waitAndClickElement(agreeToUseESign);
				waitAndClickElement(continueFromESign);			
				waitForPageToBeReady();
				waitForSpinnerToBeGone();
				waitAndClickElement(bwFinishDocReviewButton);
			} else {
				Log.warn("Got to payment page with payment plan: " + applicant.getPayment().getPaymentPlan(), true);
				verifyPaymentPlans(applicant.getStateCode(), isBristolWestQuote, fsa);
				selectPaymentPlan(applicant.getPayment(), isBristolWestQuote);
			}
		}
	}

	private void selectPaymentPlan(SqlPayment paymentObject, boolean isBristolWestQuote) {
		Log.warn("Select payment plan", true);
		if (isBristolWestQuote) {
			switch (paymentObject.getPaymentPlan()) {
			case "Pay in Full" :
				scrollAndClickOnElement(bwPayInFullRadioButtonSection);
				break;
			case "Monthly Automatic - Bank Account" :
				clickElement(bwMonthlyBankAccountRadioButtonSection);
				break;
			case "Monthly Automatic - Credit/Debit Card" :
				if (paymentObject.getPaymentMethod().equals("Credit Card")) {
					clickElement(bwMonthlyCreditCardRadioButtonSection);
				} else {
					clickElement(bwMonthlyDebitCardRadioButtonSection);
				}
				break;
			case "Monthly":
				clickElement(bwMonthlyBillingRadioButtonSection);
				break;
			default:
				throw new IllegalArgumentException("Invalid Payment Plan: <" + paymentObject.getPaymentPlan() + ">");				
			}
		} else {
			switch (paymentObject.getPaymentPlan()) {
			case "Pay in Full" :
				scrollAndClickOnElement(payInFullRadioButtonSection);
				break;
			case "Monthly Automatic - Bank Account" :
				clickElement(monthlyBankAccountRadioButtonSection);
				break;
			case "Monthly Automatic - Credit/Debit Card" :
				clickElement(monthlyCreditCardRadioButtonSection);				
				break;
			case "Monthly":
				clickElement(monthlyBillingRadioButtonSection);
				break;
			default:
				throw new IllegalArgumentException("Invalid Payment Plan: <" + paymentObject.getPaymentPlan() + ">");				
			}
		}
		scrollToElementBottom(continueButton);
		clickElement(continueButton);
	}

	private void verifyPaymentPlans(String stateCode, boolean isBristolWestQuote, FarmersSoftAssert fsa) {
		if (isBristolWestQuote) {
			fsa.assertTrue(getTextFromElement(selectPaymentDialogTitle).contains("How would you like to pay?"), "selectPaymentDialogTitle");	
			fsa.assertTrue(bwPayInFullRadioButtonSection.isVisible(), "PayInFull radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwPayInFullRadioButtonSection).contains("Payment in full"), "bwPayInFullRadioButtonSection");
			fsa.assertTrue(bwMonthlyBankAccountRadioButtonSection.isVisible(), "MonthlyAutoBankAcnt radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwMonthlyBankAccountRadioButtonSection).contains("Monthly payment (AutoPay) bank account"), "bwMonthlyBankAccountRadioButtonSection");
			fsa.assertTrue(bwMonthlyCreditCardRadioButtonSection.isVisible(), "MonthlyAutoCredit radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwMonthlyCreditCardRadioButtonSection).contains("Monthly payment (AutoPay) credit card"), "bwMonthlyCreditCardRadioButtonSection");
			fsa.assertTrue(bwMonthlyDebitCardRadioButtonSection.isVisible(), "MonthlyAutoDebit radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwMonthlyDebitCardRadioButtonSection).contains("Monthly payment (AutoPay) debit card"), "bwMonthlyBillingRadioButtonSection");
			fsa.assertTrue(bwMonthlyBillingRadioButtonSection.isVisible(), "Monthly radio button in pop-up window visible!");
			fsa.assertTrue(getTextFromElement(bwMonthlyBillingRadioButtonSection).contains("Monthly billing"), "bwMonthlyBillingRadioButtonSection");
		} else {		
			fsa.assertTrue(getTextFromElement(selectPaymentDialogTitle).contains("SELECT A PAYMENT PLAN"), "selectPaymentDialogTitle");	
			if (isEasternExpansionState(stateCode)) { // LA
				fsa.assertTrue(monthlyBankAccountRadioButtonSection.isVisible(), "MonthlyAutoBankAcnt radio button in pop-up window visible!");
				fsa.assertTrue(getTextFromElement(monthlyBankAccountRadioButtonSection).contains("Monthly automatic with bank account"), "monthlyBankAccountRadioButtonSection");
				fsa.assertTrue(monthlyDebitCardRadioButtonSection.isVisible(), "MonthlyAutoDebit radio button in pop-up window visible!");
				fsa.assertTrue(getTextFromElement(monthlyDebitCardRadioButtonSection).contains("Monthly automatic with debit card"), "bwMonthlyBillingRadioButtonSection");
				fsa.assertTrue(monthlyCreditCardRadioButtonSection.isVisible(), "MonthlyAutoCreditDebit radio button in pop-up window visible!");
				fsa.assertTrue(getTextFromElement(monthlyCreditCardRadioButtonSection).contains("Monthly automatic with credit card"), "monthlyCreditCardRadioButtonSection");
				fsa.assertTrue(payInFullRadioButtonSection.isVisible(), "PayInFull radio button in pop-up window visible!");
				fsa.assertTrue(getTextFromElement(payInFullRadioButtonSection).contains("Pay in full"), "payInFullRadioButtonSection");
			} else {
				if (!stateCode.equals(NJ)) {
					fsa.assertTrue(monthlyBankAccountRadioButtonSection.isVisible(), "MonthlyAutoBankAcnt radio button in pop-up window visible!");
					fsa.assertTrue(getTextFromElement(monthlyBankAccountRadioButtonSection).contains("Monthly payment (AutoPay) bank account"), "monthlyBankAccountRadioButtonSection");
				}
				fsa.assertTrue(monthlyCreditCardRadioButtonSection.isVisible(), "MonthlyAutoCreditDebit radio button in pop-up window visible!");
				if (isDebitListedFirstStates(stateCode)) {
					fsa.assertTrue(getTextFromElement(monthlyCreditCardRadioButtonSection).contains("Monthly payment (AutoPay) debit/credit card"), "monthlyCreditCardRadioButtonSection");
				} else {
					fsa.assertTrue(getTextFromElement(monthlyCreditCardRadioButtonSection).contains("Monthly payment (AutoPay) credit/debit card"), "monthlyCreditCardRadioButtonSection");				
				}
				if (!stateCode.equals(TN)) {
					fsa.assertTrue(payInFullRadioButtonSection.isVisible(), "PayInFull radio button in pop-up window visible!");
					fsa.assertTrue(getTextFromElement(payInFullRadioButtonSection).contains("Payment in full"), "payInFullRadioButtonSection");
				}
			}
		}
	}

	private boolean isDebitListedFirstStates(String stateCode) {
		List<String> debitListedFirstStates = new ArrayList<>(Arrays.asList(AL, CT, MT, ND, OR, SD, VA));
		return debitListedFirstStates.contains(stateCode);
	}
}
