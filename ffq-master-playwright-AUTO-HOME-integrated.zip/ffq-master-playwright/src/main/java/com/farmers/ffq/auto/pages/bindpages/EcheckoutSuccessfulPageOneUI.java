package com.farmers.ffq.auto.pages.bindpages;





import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.auto.pages.bw.BwDocuSignPage;

public class EcheckoutSuccessfulPageOneUI extends AutoBasePage {

    private static final String PAYMENT_SUCCESSFUL = "Payment successful";
        private Locator paymentSuccessfulMessage = locator(pwXPath("//div[contains(text()," + PAYMENT_SUCCESSFUL + ")]"));

    private static final String WELCOME_TO_FARMERS = "Welcome to Farmers";
    private final String WELCOME_TO_FARMERS_XPATH = String.format("//h1[contains(.,'%s')]", WELCOME_TO_FARMERS);
        private Locator welcomeToFarmersMessage = locator(pwXPath("//h1[contains(text()," + WELCOME_TO_FARMERS + ")]"));

    private static final String SIGN_ELECTRONICALLY_XPATH = "//h1[contains(.,'Sign electronically')]";
        private Locator signElectronicallyMessage = locator(pwXPath(SIGN_ELECTRONICALLY_XPATH));

    private static final String JOINING_POLICY_HOLDER_MESSAGE = "Thank you for joining us as a policyholder!";
        private Locator joiningAsAPolicyHolderMessage = locator(pwXPath("//h1[contains(text()," + JOINING_POLICY_HOLDER_MESSAGE + ")]"));

        private Locator startSigningButton = locator(pwXPath("//button[contains(@class, 'cta-sign')]"));

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public EcheckoutSuccessfulPageOneUI() throws Exception {
    }

    public boolean isPaymentSuccessfulMessageCorrect() {
        String PAYMENT_SUCCESSFUL_MESSAGE = "Payment successful";
        String PAYMENT_SUCCESSFUL_MESSAGE_BUNDLE = "Your  policy payments were successful!";
        try {
            waitForSpinnerToBeGone();
            wait.until(Conditions.or(Conditions.attached(pwXPath("//div[contains(text(),'" + PAYMENT_SUCCESSFUL_MESSAGE + "')]")),
                    Conditions.attached(pwXPath("//p[contains(text(),'" + PAYMENT_SUCCESSFUL_MESSAGE_BUNDLE + "')]")),
                    		Conditions.attached(pwXPath("//h1[contains(text(),'Choose a Password')]"))));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isWelcomeToFarmersPresent() {
       return isElementPresent(pwXPath(WELCOME_TO_FARMERS_XPATH), 15);
    }

    public boolean isSignElectronicallyPresent() {
       return isElementPresent(pwXPath(SIGN_ELECTRONICALLY_XPATH) , 15);
    }

    public void signDocuments() throws Exception {
    	clickElement(startSigningButton);
    	waitElementBeInvisible(startSigningButton);
    	new BwDocuSignPage().signDocuments();
    }
}
