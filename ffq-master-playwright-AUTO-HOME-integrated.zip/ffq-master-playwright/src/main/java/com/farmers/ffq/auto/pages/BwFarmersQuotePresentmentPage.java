package com.farmers.ffq.auto.pages;



import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
public class BwFarmersQuotePresentmentPage extends AutoBasePage {

    // Static content
    private static final String PAGE_HEADER = "You've got options";
    private static final String PAGE_SUBTITLE = "Exciting news! We have quotes for you from Farmers\u00ae and Bristol West\u00ae, part of the Farmers family. Both offer great coverage options, so you can shop with confidence.";
    private static final String ESTIMATED = "Estimated";
    private static final String SIX_MONTH_PLAN = "6-month plan";
    private static final String FARMERS_BRAND_MESSAGE_1 = "A trusted brand for nearly 100 years";
    private static final String FARMERS_BRAND_MESSAGE_2 = "Comprehensive coverage options";
    private static final String BW_BRAND_MESSAGE_1 = "Affordable, quality coverage";
    private static final String BW_BRAND_MESSAGE_2 = "Flexible payment options";
    private static final String BW_POPUP_DESCRIPTION = "Bristol West is an insurance company in the Farmers Insurance Group. Both companies have excellent customer service, claims support and financial security. Bristol West specializes in drivers that are new to driving, new to the country or may have previous traffic violations. It offers flexible coverage and payment options. Whichever you choose, Farmers or Bristol West, all your insurance coverage will be managed in one convenient place. We also offer products like home, life, umbrella, financial services and more - so you can get coverage that keeps pace with your life's twists and turns.";
    private static final String BW_POPUP_HEADER = "Learn more about Bristol West";

        private Locator pageHeader = locator(pwXPath("//app-bw-farmers-quote//h1"));
        private Locator pageSubtitle = locator(pwCss("div[class='presentment-stitle']"));
        private Locator presentmentCardFarmers = locator(pwXPath("//mat-card[contains(@class,'presentment-card-farmers')]"));
        private Locator presentmentCardBw = locator(pwXPath("//mat-card[contains(@class,'presentment-card-bristol')]"));
        private Locator farmersCardLogo = locator(pwXPath("//mat-card[contains(@class,'farmers')]//img"));
        private Locator bwCardLogo = locator(pwXPath("//mat-card[contains(@class,'bristol')]//img"));
        private Locator learnMoreAboutBwBwLink = locator(pwXPath("//mat-card[contains(@class,'bristol')]//a"));
        private Locator learnMoreAboutBwDialogueHeader = locator(pwXPath("//mat-dialog-container//div[@class='bw-farmers-heading-area']//span"));
        private Locator learnMoreAboutBwDialogueCloseIcon = locator(pwXPath("//mat-dialog-container//div[@class='bw-farmers-heading-area']//button"));
        private Locator learnMoreAboutBwDialogueBwLogo = locator(pwXPath("//mat-dialog-content//img"));
        private Locator learnMoreAboutBwDialogueDescription = locator(pwXPath("//mat-dialog-content//div[@class='tui-body-text-1']"));
        private Locator learnMoreAboutBwDialogueCloseButton = locator(pwXPath("//button[@class='tui-btn tui-btn-primary popup-action-button']"));
        private Locator farmersPrice = locator(pwXPath("//mat-card[contains(@class,'farmers')]//div[contains(@class,'tui-price')]"));
        private Locator bwPrice = locator(pwXPath("//mat-card[contains(@class,'bristol')]//div[contains(@class,'tui-price')]"));
        private Locator farmersPriceDescription = locator(pwXPath("//mat-card[contains(@class,'farmers')]//div[contains(@class,'price-description')]"));
        private Locator bwPriceDescription = locator(pwXPath("//mat-card[contains(@class,'bristol')]//div[contains(@class,'price-description')]"));
        private Locator farmersEstimatedText = locator(pwXPath("//mat-card[contains(@class,'farmers')]//div[contains(@class,'price-text')]"));
        private Locator bwEstimatedText = locator(pwXPath("//mat-card[contains(@class,'bristol')]//div[contains(@class,'price-text')]"));
        private Locator continueWithFarmersButton = locator(pwXPath("//mat-card[contains(@class,'farmers')]//button"));
        private Locator continueWithBwButton = locator(pwXPath("//mat-card[contains(@class,'bristol')]//button"));
        private Locator farmersBrandMessageOne = locator(pwXPath("//mat-card[contains(@class,'farmers')]//div[contains(@class,'presentment-content')][1]"));
        private Locator farmersBrandMessageTwo = locator(pwXPath("//mat-card[contains(@class,'farmers')]//div[contains(@class,'presentment-content')][2]"));
        private Locator bristolWestBrandMessageOne = locator(pwXPath("//mat-card[contains(@class,'bristol')]//div[contains(@class,'presentment-content')][1]"));
        private Locator bristolWestBrandMessageTwo = locator(pwXPath("//mat-card[contains(@class,'bristol')]//div[contains(@class,'presentment-content')][2]"));


    /**
     * Constructor.
     *
     * @throws Exception
     */
    public BwFarmersQuotePresentmentPage() throws Exception {
    }

    public boolean isOnBwFarmersQuotePresentmentPage() {
        return isElementVisible(pageHeader, 40);
    }

    public boolean quickIsOnBwFarmersQuotePresentmentPage() {
        return isElementVisible(pageHeader, 5);
    }

    public void continueWithFarmers() {
        Log.info("User decided to go with Farmers option from " + this.getClass().getSimpleName(), true);
        waitAndClickElement(continueWithFarmersButton);
    }

    public void continueWithBw() {
        Log.info("User decided to go with BW option from " + this.getClass().getSimpleName(), true);
        waitAndClickElement(continueWithBwButton);
    }

    public void validateBwFarmersQuotePresentmentPageContent(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isOnBwFarmersQuotePresentmentPage(), "User is on the Bw/Farmers quote presentment page");
        fsa.assertEquals(getTextFromElement(pageHeader), PAGE_HEADER, "Page header validated");
        fsa.assertEquals(getTextFromElement(pageSubtitle), PAGE_SUBTITLE, "Page header validated");
        fsa.assertTrue(getAttributeData(farmersCardLogo, "src").contains("farmers-logo"), "Farmers card logo validated");
        fsa.assertTrue(getAttributeData(bwCardLogo, "src").contains("bristol-west"), "Bw card logo validated");
        fsa.assertTrue(isElementDisplayed(farmersCardLogo, 1), "Farmers card loge displayed");
        fsa.assertTrue(isElementDisplayed(bwCardLogo, 1), "Bw card loge displayed");
        fsa.assertEquals(getTextFromElement(farmersPriceDescription), SIX_MONTH_PLAN, "Farmers card price description validated");
        fsa.assertEquals(getTextFromElement(bwPriceDescription), SIX_MONTH_PLAN, "Bw card price description validated");
        fsa.assertTrue(isElementDisplayed(farmersPrice, 1), "Farmers card price displayed");
        fsa.assertTrue(isElementDisplayed(bwPrice, 1), "Bw card price displayed");
        fsa.assertEquals(getTextFromElement(farmersEstimatedText), ESTIMATED, "Farmers card Estimated text validated");
        fsa.assertEquals(getTextFromElement(bwEstimatedText), ESTIMATED, "Bw card Estimated text validated");
        fsa.assertEquals(getTextFromElement(continueWithFarmersButton), "Continue with Farmers", "Farmers card Estimated text validated");
        fsa.assertEquals(getTextFromElement(continueWithBwButton), "Continue with Bristol West", "Bw card Estimated text validated");
        fsa.assertEquals(getTextFromElement(farmersBrandMessageOne), FARMERS_BRAND_MESSAGE_1, "Farmers brand message 1 -left- validated");
        fsa.assertEquals(getTextFromElement(farmersBrandMessageTwo), FARMERS_BRAND_MESSAGE_2, "Farmers brand message 2 -right- validated");
        fsa.assertEquals(getTextFromElement(bristolWestBrandMessageOne), BW_BRAND_MESSAGE_1, "BW brand message 1 -left- validated");
        fsa.assertEquals(getTextFromElement(bristolWestBrandMessageTwo), BW_BRAND_MESSAGE_2, "BW brand message 2 -right- validated");

        // validate learn more about bw pop up
        waitAndClickElement(learnMoreAboutBwBwLink);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(learnMoreAboutBwDialogueHeader)), BW_POPUP_HEADER, "Learn More Pop up header validation");
        String expectedPopUpDescriptionAdjustedForMac = Property.getBrowser().equals("safari") ? BW_POPUP_DESCRIPTION.replace(" Whichever you choose", "Whichever you choose") : BW_POPUP_DESCRIPTION;
        fsa.assertEquals(getTextFromElement(learnMoreAboutBwDialogueDescription), expectedPopUpDescriptionAdjustedForMac, "Learn More Pop up description validation");
        fsa.assertTrue(isElementVisible(learnMoreAboutBwDialogueCloseIcon, 1), "Learn more bw dialog close icon displayed");
        fsa.assertEquals(getTextFromElement(learnMoreAboutBwDialogueCloseButton), "Close", "Learn more bw dialog close button text validated");
        waitAndClickElement(learnMoreAboutBwDialogueCloseButton);
        fsa.assertFalse(isElementVisible(learnMoreAboutBwDialogueHeader, 1), "Learn more about bw dialog should not be visible any more");
        new HeaderAndFooter().isHeaderPhoneNumberCorrect("18002069469", fsa);

        // #417 "Validate if browser back is disabled when user clicks browser back arrow from Quote presentment screen
        back();
        fsa.assertTrue(this.isOnBwFarmersQuotePresentmentPage(), "User should stay in the Quote Presentment page with navigation back click as 'Back' button should not be enabled");

    }

    public String getDisplayedPremiumFarmers() {
        return getTextFromElement(farmersPrice);
    }

    public String getDisplayedPremiumBW() {
        return getTextFromElement(bwPrice);
    }
}
