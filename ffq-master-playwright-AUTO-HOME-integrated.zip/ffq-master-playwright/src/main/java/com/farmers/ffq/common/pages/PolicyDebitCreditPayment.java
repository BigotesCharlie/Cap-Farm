package com.farmers.ffq.common.pages;





import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.bindpages.AutoPolicyPaymentBasePage;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class PolicyDebitCreditPayment extends AutoPolicyPaymentBasePage {

    protected static final String MONTHLY_AUTO_PAY_CARD_HEADER = "Monthly autopay - card";

        private Locator monthlyAutoPayCardHeader = locator(pwXPath("//h2[contains(text(), '" + MONTHLY_AUTO_PAY_CARD_HEADER + "')]"));

        private Locator expirationDateInputField = locator(pwXPath("//input[@id='ccExpirationDate']"));
    private static final String CREDIT_CARD_ADDED_MSG = "Credit card added.";
        private Locator creditCardAddedMsg = locator(pwXPath("//span[contains(text(),'" +  CREDIT_CARD_ADDED_MSG + "')]"));

    private static final String DEBIT_CARD_ADDED_MSG = "Debit card added.";
        private Locator debitCardAddedMsg = locator(pwXPath("//span[contains(text(),'" +  DEBIT_CARD_ADDED_MSG + "')]"));
    public static final String NO_SERVICE_CHARGE_WHEN_PAY_IN_FULL = "No service charges when you pay in full";
        private Locator noServiceChargeWhenPayInFullMsg = locator(pwXPath("//p[contains(text(),'" +  NO_SERVICE_CHARGE_WHEN_PAY_IN_FULL + "')]"));

        private Locator amexIconOnAutoPolicyPaymentScreen = locator(pwXPath("//*[contains(@src,'cc_amex')]"));

        private Locator masterCardIconOnAutoPolicyPaymentScreen = locator(pwXPath("//*[contains(@src,'cc_mastercard')]"));

        private Locator discoverCardIconOnAutoPolicyPaymentScreen = locator(pwXPath("//*[contains(@src,'cc_discover')]"));

        private Locator visaCardIconOnAutoPolicyPaymentScreen = locator(pwXPath("//*[contains(@src,'cc_visa')]"));
        private Locator hiddenCardNumberAndExpDatePayInFull = locator(pwXPath("//span[contains(@class,'pif-autopay-disclaimers-account-numbers')]//span"));

        private Locator hiddenCardNumberAndExpDateMonthlyPay = locator(pwXPath("//span[contains(@class,'monthly-autopay-disclaimers-account-numbers')]//small"));
    private static final String CHANGE_LINK = "Change";
        private Locator changeLink = locator(pwXPath("//a[contains(text(), '" + CHANGE_LINK + "')]"));
    private static final String AUTOMATIC_RECURRING_PAYMENT_TEXT = "A one-time payment and automatic recurring payments.";
        private Locator automaticRecurringPaymentText = locator(pwXPath("//p[contains(text(),'" +  AUTOMATIC_RECURRING_PAYMENT_TEXT + "')]"));
    private static final String ONE_TIME_PAYMENT_TEXT = "A one-time payment only.";
        private Locator oneTimePaymentText = locator(pwXPath("//p[contains(text(),'" +  ONE_TIME_PAYMENT_TEXT + "')]"));
        private Locator oneTimePaymentRadioButton = locator(pwXPath("//input[@value='one-time-payment']"));
        private Locator automaticRecurringPaymentRadioButton = locator(pwXPath("//input[@value='automatic-recurring']"));
    private static final String FUTURE_MONTHLY_PAYMENT_INCLUDE_$5 = "Future monthly payments will include a $5 service charge.";
        private Locator futureMonthlyPaymentInclude$5 = locator(pwXPath("//span[contains(text(), '$5')]/parent::span"));

    private static final String FUTURE_MONTHLY_PAYMENT_INCLUDE_$3 = "Future monthly payments will include a $3 service charge.";
        private Locator futureMonthlyPaymentInclude$3 = locator(pwXPath("//span[contains(text(), '$3')]/parent::span"));

    public static final String FUTURE_MONTHLY_SERVICE_CHARGE_CARD = "Future monthly payments will include a $5 service charge.";
        private Locator futureMonthlyPaymentsServiceChargeCard = locator(pwXPath("//div[contains(@class,'monthly-autopay-disclaimers-details')]//p"));


    private static final String COMPLETE_PURCHASE_BUTTON = "Complete purchase";
        private Locator completerPurchaseButton = locator(pwXPath("//button[contains(text(), '" + COMPLETE_PURCHASE_BUTTON + "')]"));


    public PolicyDebitCreditPayment() throws Exception {
    }

    public boolean isNameOnCardMatching(String fullName){
        String accountHolderNameFromInputField = getValueForFullNamePaymentusFrame();
        boolean isNameOnCardMatching= fullName.equals(accountHolderNameFromInputField);
        return isNameOnCardMatching;
    }

    public boolean isCreditCardAddedMsgCorrect(){
       // wait.until(Conditions.visible(creditCardAddedMsg));
        return isExpectedTextDisplayed(creditCardAddedMsg, CREDIT_CARD_ADDED_MSG);
    }

    public boolean isDebitCardAddedMsgCorrect(){
        return isExpectedTextDisplayed(debitCardAddedMsg, DEBIT_CARD_ADDED_MSG);
    }

    public boolean isNoServiceChargeWhenPayInFullMsgCorrect(String lobType){
        String noServiceChargeMessage = !lobType.equals(AUTO)? NO_SERVICE_CHARGE_WHEN_PAY_IN_FULL+ "." : NO_SERVICE_CHARGE_WHEN_PAY_IN_FULL;
        return isExpectedTextDisplayed(noServiceChargeWhenPayInFullMsg, noServiceChargeMessage);
    }

    public boolean isHiddenCardNumberAndExpDatePayInfFullCorrect(String cardNumber, String expDate, String cardName){
        String lastFourDigitOfCardNumber = getLastFourDigitOfCard(cardNumber);
        boolean cardSymbolDisplayed = waitUntilCardSymbolIsDisplayed(cardName);
        boolean isHiddenCardNumberCorrect = getTextFromElement(hiddenCardNumberAndExpDatePayInFull).contains(lastFourDigitOfCardNumber);
        boolean isExpDateCorrect = getTextFromElement(hiddenCardNumberAndExpDatePayInFull).contains(expDate);
        return isHiddenCardNumberCorrect && isExpDateCorrect && cardSymbolDisplayed;
    }

    public boolean waitUntilCardSymbolIsDisplayed(String cardName){
        boolean cardSymbolDisplayed = false;
        if(cardName.equals(CARD_NAME_VISA)){
            cardSymbolDisplayed = isElementVisible(visaCardIconOnAutoPolicyPaymentScreen, 5);
        } else if(cardName.equals(CARD_NAME_AMEX)){
            cardSymbolDisplayed = isElementVisible(amexIconOnAutoPolicyPaymentScreen, 5);
        } else if(cardName.equals(CARD_NAME_MASTER)){
            cardSymbolDisplayed = isElementVisible(masterCardIconOnAutoPolicyPaymentScreen, 5);
        } else if(cardName.equals(CARD_NAME_DISCOVER)){
            cardSymbolDisplayed = isElementVisible(discoverCardIconOnAutoPolicyPaymentScreen, 5);
        }
        return cardSymbolDisplayed;
    }

    public boolean isHiddenCardNumberAndExpDateMonthlyPayCorrect(String cardNumber, String expDate, String cardName){
        String lastFourDigitOfCardNumber =getLastFourDigitOfCard(cardNumber);
        waitForUiSettled();
        wait.until(Conditions.clickable(changeLink));
        wait.until(Conditions.visible(hiddenCardNumberAndExpDateMonthlyPay));
        boolean isHiddenCardNumberCorrect = testExpectedTextContentContainsForElement(hiddenCardNumberAndExpDateMonthlyPay, lastFourDigitOfCardNumber);
        boolean isExpDateCorrect = testExpectedTextContentContainsForElement(hiddenCardNumberAndExpDateMonthlyPay, expDate);
        boolean cardSymbolDisplayed = waitUntilCardSymbolIsDisplayed(cardName);
        return isHiddenCardNumberCorrect && isExpDateCorrect && cardSymbolDisplayed;
    }

    public void clickChangeLink(){
        scrollAndClickOnElement(changeLink);
    }

    public void waitForCompletePurchaseButtonToBeClickable() throws Exception {
        switchToDefaultContent();
        waitElementBeVisibleClickable(completerPurchaseButton);
    }

    public boolean isAutomaticRecurringTextCorrect(){
        return isExpectedTextDisplayed(automaticRecurringPaymentText, AUTOMATIC_RECURRING_PAYMENT_TEXT);
    }

    public boolean isOneTimePaymentTextCorrect(){
        return isExpectedTextDisplayed(oneTimePaymentText, ONE_TIME_PAYMENT_TEXT);
    }

    public void selectAutomaticRecurringRadioButton(){
        waitAndClickElement(automaticRecurringPaymentRadioButton);
    }

    public void selectOneTimePaymentRadioButton(){
        waitAndClickElement(oneTimePaymentRadioButton);
    }

    public boolean isFutureCreditCardServiceChargesTextMatching(){
        return isExpectedTextDisplayed(futureMonthlyPaymentInclude$5, FUTURE_MONTHLY_PAYMENT_INCLUDE_$5);
    }

    public boolean isFutureDebitCardServiceChargesTextMatching(){
        return isExpectedTextDisplayed(futureMonthlyPaymentInclude$3, FUTURE_MONTHLY_PAYMENT_INCLUDE_$3);
    }

    public boolean isFutureCardServiceChargesTextMatching(){
        return isExpectedTextDisplayed(futureMonthlyPaymentsServiceChargeCard, FUTURE_MONTHLY_SERVICE_CHARGE_CARD);
    }

    public boolean isOnAutoPolicyAutoPayCardPage() {
        return isElementVisible(monthlyAutoPayCardHeader, 25);
    }

    public void validateADA_AutoPolicyPaymentAutoPayCard() {
        isOnAutoPolicyAutoPayCardPage();
        if(isADATestingEnabled()) {
            performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
        }
    }

    public String getLastFourDigitOfCard(String cardNumber){
        return cardNumber.substring(cardNumber.length()-4);
    }
}

