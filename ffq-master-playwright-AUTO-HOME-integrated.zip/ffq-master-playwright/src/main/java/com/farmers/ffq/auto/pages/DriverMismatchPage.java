package com.farmers.ffq.auto.pages;





import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class DriverMismatchPage extends PolicyPaymentBasePage {

		private Locator driverMismatchPageTitle = locator(pwClass("driver-mismatch-page-header"));

		private Locator driverMismatchPageSubtitle = locator(pwClass("driver-mismatch-page-subheading"));

		private Locator driverMismatchPageHelpTitle = locator(pwXPath("//div[@class='auto-driver-review-info-header-content']/div"));

		private Locator driverMismatchPageHelpTextParagraphOne = locator(pwXPath("//div[@class='auto-driver-review-info-header-content']//p[1]"));

		private Locator driverMismatchPageHelpTextParagraphTwo = locator(pwXPath("//div[@class='auto-driver-review-info-header-content']//p[2]"));

		private Locator continueButton = locator(pwXPath("//button[@data-test-id='CONTINUE_BTN']"));

		private Locator returnToDriverSelectionLink = locator(pwXPath("//div[@class='driver-mismatch-page-subheading']//a"));

	private final String REJECT_REASONS_XPATH = "//mat-radio-group[@formcontrolname='rejectReasonFormValue']";
		private Locator rejectReasons = locator(pwXPath(REJECT_REASONS_XPATH));

	private static final String NAME_OF_NON_LISTED_DRIVERS_XPATH = "//div[contains(@class, 'driver-name')]";
		private Locator listOfNamesOfDriversNotIncluded = locator(pwXPath(NAME_OF_NON_LISTED_DRIVERS_XPATH));

		private Locator listOfAgesOfDriversNotIncluded = locator(pwXPath(NAME_OF_NON_LISTED_DRIVERS_XPATH + "/../div[contains(text(), 'Age')]"));

		private Locator listOfUnknownDriverRadioButtons = locator(pwXPath("//mat-radio-button[contains(.,'know this person')]//input"));

		private Locator uncheckedListOfUnknownDriverRadioButtons = locator(pwXPath("//mat-radio-button[contains(.,'know this person') and not(contains(@class,'checked'))]//input"));

		private Locator listOfErrorsInPage = locator(pwXPath("//mat-error"));

	public DriverMismatchPage() throws Exception {
	}

	public HeresWhatWeFoundPage returnToDriverSelectionPage() throws Exception {
		waitAndClickElement(returnToDriverSelectionLink);
		waitForSpinnerToBeGone();
		return new HeresWhatWeFoundPage();
	}

	public boolean validateDriversMismatchPageTitle() {
		return isExpectedTextDisplayed(driverMismatchPageTitle, "Drivers not included");
	}

	public boolean validateDriversMismatchErrorHandling() throws Exception {
		scrollAndClickOnElement(continueButton);
		if ((listOfNamesOfDriversNotIncluded.count() == 0)) {
			return true;
		} else {
			//Should have an error for each driver
			int numberOfDriverRelatedErrors = listOfErrorsInPage.count()-1;
			boolean retValue = listOfNamesOfDriversNotIncluded.count() == numberOfDriverRelatedErrors;
			for (int i=0; i < numberOfDriverRelatedErrors-1; i++) {
				retValue &= isExpectedTextDisplayed(listOfErrorsInPage.nth(i), "This field is required.");
			}
			retValue &= isExpectedTextDisplayed(listOfErrorsInPage.nth(numberOfDriverRelatedErrors), "One or more required fields is incomplete or incorrect. Please review.");
			return retValue;
		}
	}

	public boolean validateDriversMismatchPageDescription() {
		return isExpectedTextDisplayed(driverMismatchPageSubtitle, "We noticed you didn't include some drivers. Everyone who lives in your household needs to be listed on the policy, even if they have their own insurance. Return to the driver selection page to add drivers if this is incorrect.");
	}

	public boolean validateDriversMismatchPageHelp() {
		boolean retValue = isExpectedTextContainedInElement(driverMismatchPageHelpTitle, "Excluded driver(s)");
		retValue &= isExpectedTextContainedInElement(driverMismatchPageHelpTextParagraphOne, "Select \"Not living in my household\" if this person is no longer living in your home and does not have regular access to your vehicle(s). For example: an ex-spouse now living separately, or an adult child with their own home.");
		retValue &= isExpectedTextContainedInElement(driverMismatchPageHelpTextParagraphTwo, "Select \"Exclude this person from my insurance\" if this person lives in your home, but will never drive any vehicle listed on your policy. There will be no coverage for damage to any vehicle driven by this person, and they will have no coverage if they drive any vehicle under your policy.");
		return retValue;
	}

	public void validateDriversListed(FarmersSoftAssert fsa) throws Exception {
        List<Locator> notIncludedDrivers = locators(pwXPath("//div[@class='driver-name ng-star-inserted']//h2"));
        int numberOfElements = rejectReasons.count();
        fsa.assertEquals(numberOfElements, notIncludedDrivers.size(), "Reject reasons radio button groups should be the same size with the excluded driver count");

        for (int i = 0; i < numberOfElements; i++) {
            String fullName = getTextFromElement(notIncludedDrivers.get(i));
            fsa.assertTrue(isElementDisplayed(pwXPath(String.format("//div[@class='driver-name ng-star-inserted' and contains(.,'%s')]", fullName))), "Driver should be displayed on the screen");
            List<Locator> rejectReasonsForEachDriver = locators(pwXPath(String.format(REJECT_REASONS_XPATH + "[%s]//mat-radio-button", i + 1)));
            List<String> radioButtonsDisplayed = rejectReasonsForEachDriver.stream().map(this::getTextFromElement).collect(Collectors.toList());
            Collections.sort(radioButtonsDisplayed);
            List<String> radioButtonExpected = Arrays.asList("I don't know this person", "Not living in my household", "Exclude this person from my insurance", "Already added to this quote");
            Collections.sort(radioButtonExpected);
            fsa.assertEquals(radioButtonsDisplayed, radioButtonExpected, "Reject reason radio buttons label validation for each");
		}
	}

	public boolean validateDriversListed(LinkedHashMap<String, String> mapOfDriversFound) {
		// Compare drivers listed in this page to the ones in "Here's what we found" page
		LinkedHashMap<String, String> namesAndAgesInMismatchPage = new LinkedHashMap<>();
		int namesOfDriversNotIncludedSize = listOfNamesOfDriversNotIncluded.count();
		int agesOfDriversNotIncludedSize = listOfAgesOfDriversNotIncluded.count();
		for (int index=0; index < namesOfDriversNotIncludedSize && index < agesOfDriversNotIncludedSize; index++) {
			namesAndAgesInMismatchPage.put(getTextFromElement(listOfNamesOfDriversNotIncluded.nth(index)).toLowerCase(Locale.US).replace("info",  EMPTY_STRING), getTextFromElement(listOfAgesOfDriversNotIncluded.nth(index)).replace("info",EMPTY_STRING));
		}
		// Now add those entries without age
		for (int index=agesOfDriversNotIncludedSize; index < namesOfDriversNotIncludedSize; index++) {
			namesAndAgesInMismatchPage.put(getTextFromElement(listOfNamesOfDriversNotIncluded.nth(index)).toLowerCase(Locale.US).replace("info",  EMPTY_STRING), EMPTY_STRING);
		}
		// For debugging when maps are not equal.
		boolean success = mapOfDriversFound.equals(namesAndAgesInMismatchPage);
		if (!success) {
			Log.warn("Drivers Found map: " + mapOfDriversFound);
			Log.warn("Mismatched drivers map: " + namesAndAgesInMismatchPage);
		}
		return success;
	}

	public void dontIncludeAnyMismatchedDriversInQuote() throws Exception {
		listOfUnknownDriverRadioButtons.all().forEach(radioButton -> scrollAndClickOnElement(radioButton));
		uncheckedListOfUnknownDriverRadioButtons.all().forEach(radioButton -> scrollAndClickOnElement(radioButton));
		scrollAndClickOnElement(continueButton);
		waitForSpinnerToBeGone();
	}

	public void randomlySelectReasonForNonInclusion() throws Exception {
		LocalDate twentyYearsAgo = LocalDate.now().minusYears(20);
		String inputDoB = "05/05" + twentyYearsAgo.getYear();
    	int numberOfElements = rejectReasons.count();
        for (int i = 0; i < numberOfElements; i++) {
            String attribute = getAttributeData(rejectReasons.nth(i), ARIA_LABEL);
            String nonIncludedDriver = attribute.replace("Select a reason for not including ", EMPTY_STRING);
            List<String> availableOptions = Arrays.asList("I dont know this person", "Not living in my household", "Exclude this person from my insurance");
            Collections.shuffle(availableOptions);
            String selectedOption = availableOptions.get(0);
            String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
            if (landingStateCode.equals(NJ)) {
                selectedOption = "I dont know this person";
            }
            Locator selectedRadioButton;
            if (selectedOption.equals("I dont know this person")) {
                selectedRadioButton = locator(pwXPath(
                        String.format(REJECT_REASONS_XPATH + "[%d]//mat-radio-button[contains(.,'%s') or contains(.,'know this person')]//input", (i + 1), selectedOption)));
            } else {
                selectedRadioButton = locator(pwXPath(
                        String.format(REJECT_REASONS_XPATH + "[%d]//mat-radio-button[contains(.,'%s')]//input", (i + 1), selectedOption)));
            }
            scrollAndClickOnElement(selectedRadioButton);
            if (selectedOption.equals("Exclude this person from my insurance")) {
                //Date of Birth
                List<Locator> dateOfBirthInputs = locators(pwXPath(REJECT_REASONS_XPATH + "[" + (i + 1) + "]//mat-form-field[@id='dateOfBirth' and contains(@class,'invalid')]//input[@aria-label='Date of birth']"));
                if (!dateOfBirthInputs.isEmpty()) {
                    sendKeysToElement(dateOfBirthInputs.get(0), inputDoB);
                }
                //Gender
                List<Locator> genders = locators(pwXPath(REJECT_REASONS_XPATH + "[" + (i + 1) + "]//mat-button-toggle-group[contains(@class,'invalid') and not(ancestor::*[@hidden or contains(@style,'display:none') or contains(@style,'visibility:hidden')])]//mat-button-toggle"));
                if (!genders.isEmpty()) {
                    Collections.shuffle(genders);
                    waitAndClickElement(genders.get(0));
                }

                Log.info("User selected relationship", false);
            }
            // fillout marital if need be
            List<Locator> maritalMatSelects = locators(pwXPath("//mat-form-field[contains(.,'Marital')]//mat-select"));
            if (!maritalMatSelects.isEmpty()) {
                Locator lastMaritalMatSelect = maritalMatSelects.get(maritalMatSelects.size() - 1);
                if (isElementVisible(maritalMatSelects.get(maritalMatSelects.size() - 1), 1) && !getAttributeData(lastMaritalMatSelect, CLASS).contains("ng-valid")) {
                    waitAndClickElement(lastMaritalMatSelect);
                    List<Locator> matOptions = locators(pwTag("mat-option"));
                    Collections.shuffle(matOptions);
                    waitAndClickElement(matOptions.get(0));
                }
            }
            // fillout relations if need be
            List<Locator> relations = locators(pwXPath("//mat-form-field[contains(.,'Relation')]//mat-select"));
            if (!relations.isEmpty()) {
                Locator lastRelationMatCheckbox = relations.get(relations.size() - 1);
                if (isElementVisible(lastRelationMatCheckbox, 1) || !getAttributeData(lastRelationMatCheckbox, CLASS).contains("ng-valid")) {
                    waitAndClickElement(lastRelationMatCheckbox);
                    List<Locator> matOptions = locators(pwTag("mat-option"));
                    Collections.shuffle(matOptions);
                    waitAndClickElement(matOptions.get(0));
                }


            }

            Log.info(String.format("User selected '%s' for person named '%s'", selectedOption, nonIncludedDriver), false);
        }

		List<Locator> dobInputFields = locators(pwXPath("//mat-form-field[@id='dateOfBirth' and contains(@class,'invalid')]//input[@aria-label='Date of birth']"));
    	numberOfElements = dobInputFields.size();
        for (int i = 0; i < numberOfElements; i++) {
            if(isElementVisible(dobInputFields.get(i),1)) {
                sendKeysOneByOne(dobInputFields.get(i), inputDoB);
            }
		}
	}

    public void updateOneSelectionToAlreadyIncluded() throws Exception {
        Locator alreadyAdded = locators(pwXPath("//mat-radio-group[@formcontrolname='rejectReasonFormValue']//mat-radio-button[contains(.,'Already')]")).get(0);
        scrollElementToMiddle(alreadyAdded);
        waitAndClickElement(alreadyAdded);
        waitForUiSettled();
        if(!getAttributeData(alreadyAdded, CLASS).contains(CHECKED)) {
            waitAndClickElement(alreadyAdded);
        }
        Locator includedName = locators(pwXPath(String.format("//mat-radio-button[contains(.,'%s')]", getSessionStorageAppStore().getData().getCustomerData().getFirstName()))).get(0);
        waitAndClickElement(includedName);
    }

	public boolean isOnDriverMismatchPage() {
		return isElementVisible(returnToDriverSelectionLink, 5);
	}

	public String saveQuote(String emailAddress) throws Exception {
		if (isElementPresentByXPath("//button[contains(.,'Save quote')]")) {
	        enterEmailInSaveQuoteModal(emailAddress);
		}
        return getAceQuoteNumberInThePage();
	}

	public void validateADA_DriverMismatchPage() {
		if (isOnDriverMismatchPage() &&  isADATestingEnabled()) {
			performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
		}
	}

	public void validateDriverMismatchPageForBW_US754967(FarmersSoftAssert fsa) throws Exception {
		fsa.assertTrue(validateDriversMismatchPageTitle(), "Driver mismatch page header validation");
		fsa.assertTrue(validateDriversMismatchPageDescription(), "Driver mismatch page page description validation");
		fsa.assertTrue(validateDriversMismatchPageHelp(), "Driver mismatch help text validation");
		validateDriversListed(fsa);
	}

	public void validateBDQSpecificRequirements(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		fsa.assertFalse(isDiscountSectionDisplayed(), "Discount section should NOT be displayed on " + this.getClass().getSimpleName());
		validateValidateAndFooterForBDQ(fsa, applicant, this);
		validateAgentSectionBDQ(fsa, applicant);
	}
	public void validateDriverNamesAreMasked(FarmersSoftAssert fsa){
		// If there are drivers not included, validate that their names are masked
		if(!(listOfNamesOfDriversNotIncluded.count() == 0)){
			for (Locator driverNameElement : listOfNamesOfDriversNotIncluded.all()) {
				String driverNameText = getTextFromElement(driverNameElement);
				fsa.assertTrue(driverNameText.matches("^[A-Z]\\*+ [A-Z]\\*+$"), "Driver names should be masked on driver mismatch page for " + driverNameText);
			}
		}
	}
}
