package com.farmers.ffq.ace.home;






import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.TimeoutError;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.ace.hrc.common.AceHRCReviewQuoteBasePage;
import com.farmers.ffq.common.enums.CoveragesNameAceHome;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Home.Coverage;
import com.farmers.ffq.datatransferobjects.AppStore.Home.PropertyDetailsForm;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.testng.Assert;

import java.text.NumberFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.common.enums.CoveragesNameAceHome.Coverage.*;
import static com.farmers.ffq.common.enums.CoveragesNameVsDescriptionInfoSideSheetAceHome.*;
import static com.farmers.ffq.utils.CurrencyFormat.convertCurrencyStringToDouble;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHomeReviewQuotePage extends AceHRCReviewQuoteBasePage {

    private static final int NOT_FOUND_IN_LIST = -1;
    private static final String PAGE_TITLE1 = "Here are your quotes";
    private static final String PAGE_TITLE2 = "Home coverages";
    private static final String PAGE_SUBTITLE = "Quote is based on your selected dwelling coverage of %s (change coverage).";
    protected static final String EXPECTED_EDIT_DEDUCTIBLES_LINK_TEXT = "Edit deductibles";
    private static final String EXPECTED_POLICY_DEDUCTIBLES_HEADER = "Policy deductibles";

    protected static final String EXPECTED_RECALCULATE_BUTTON_TEXT = "Recalculate";
    protected static final String EXPECTED_RESET_CHANGES_LINK_TEXT = "Reset changes";
    protected static final List<String> CERTAIN_EXTERIOR_WALL_TYPE_FOR_SIDING_AND_ROOF_MATERIAL = Arrays.asList("Alum. or metal", "Steel", "Vinyl");
    protected static final List<String> CERTAIN_ROOF_TYPE_FOR_SIDING_AND_ROOF_MATERIAL = Arrays.asList("3-tab shingle", "Architectural shingle", "Impact resistant shingle");
    protected static final String ACTUAL_CASH_VALUE = "Actual cash value";
    protected static final String ACTUAL_CASH_VALUE_WITHOUT_SPACE = "Actualcashvalue";

    protected static final String REPLACEMENT_COST_WITHOUT_SPACE = "Replacementcost";
    protected static final String CARDS_AND_COMIC_BOOKS_PER_ITEM_PER_LOSS = "Cards and comic books (Enhanced package is per item/per loss)";
    private static final String PAGE_TITLE_XPATH = "//app-home-quote-review//h1[text()=('" + PAGE_TITLE1 + "' or '" + PAGE_TITLE2 + "')]";
        private Locator quoteSummaryHeading = locator(pwXPath(PAGE_TITLE_XPATH));

    protected static final String BUNDLE_DISCOUNT_HEADING = "Bundle and save";
    protected static final String BUNDLE_DISCOUNT_SUBHEADING = "You could save up to $810* when you bundle auto and home with Farmers";
    protected static final String BUNDLE_DISCOUNT_PROMO_CONTENT = "Unlock substantial savings with quality coverage from a brand you can trust.";
    protected static final String BUNDLE_DISCOUNT_SAVING_CONTENT = "Ready to see how much you could save?";
    protected static final String CONTINUE_WITH_BUNDLE_DISCOUNT_CONTENT = "Continue with bundle discount";
    protected static final String CONTINUE_WITH_HOME_ONLY_CONTENT = "Continue with home only";
    protected static final String BUNDLE_DISCOUNT_CARD_CONTENT = BUNDLE_DISCOUNT_SUBHEADING + SPACE +
            "Bundling your auto insurance with your home applies a discount to both policies! And you can manage your policies in one place." + SPACE +
            "See how much you could save on your home now!" + SPACE + "Apply the bundle discount";

    protected static final String BUNDLE_DISCOUNT_APPLIED_CONTENT = BUNDLE_DISCOUNT_SUBHEADING + SPACE +
            "Bundling your auto insurance with your home applies a discount to both policies! And you can manage your policies in one place." + SPACE +
            "check_circle" + SPACE + "Bundle discount applied to home!" + SPACE +
            "Next, we'll just ask a few questions about your vehicles and drivers and apply the discount to your auto policy so you can compare all the numbers.";

    protected static final String BUNDLE_DISCOUNT_CARD_XPATH =  "//div[contains(@class, 'bundle-discount-card tui')]";
    protected static final String BUNDLE_DISCOUNT_REMOVE_XPATH =  "//div[contains(@class, 'remove-bundle-discount')]";
    protected static final String REMOVE_BUNDLE_DISCOUNT_DIALOG_XPATH = "//div[@class='remove-bundle-discount-dialog']";

    protected static final String CHANGE_YOUR_MIND_CONTENT = "Changed your mind?";
    protected static final String REMOVE_BUNDLE_DISCOUNT_CONTENT = "Remove the bundle discount";
    protected static final String REMOVE_BUNDLE_DISCOUNT_DIALOG_TITLE = "Remove bundle discount";
    protected static final String REMOVE_BUNDLE_DISCOUNT_DIALOG_CONTENT = "Are you sure?" + SPACE +
            "If you answer a few quick questions, you can see what your bundled price would be to better compare your options." +
            " Then you can decide if you want to buy auto and home, or just the home policy.";

        private Locator bundleDiscountCard = locator(pwXPath(BUNDLE_DISCOUNT_CARD_XPATH));

        private Locator bundleDiscountAppliedCard = locator(pwXPath("//div[contains(@class, 'bundle-discount-card tui')]"));

        private Locator bundleDiscountCardImages = locator(pwXPath(BUNDLE_DISCOUNT_CARD_XPATH + "//img"));

        private Locator bundleCardApplyDiscountButton = locator(pwXPath(BUNDLE_DISCOUNT_CARD_XPATH + "//button[contains(@class, 'bundle-discount-card')]"));

        private Locator changeYourMindText = locator(pwXPath(BUNDLE_DISCOUNT_REMOVE_XPATH + "//p[@class = 'tui-body text-end']"));

        private Locator removeBundleDiscountLink = locator(pwXPath(BUNDLE_DISCOUNT_REMOVE_XPATH + "//a[contains(@class,'tui-link')]"));

        private Locator removeBundleDiscountDialog = locator(pwXPath(REMOVE_BUNDLE_DISCOUNT_DIALOG_XPATH));

        private Locator removeBundleDiscountDialogTitle = locator(pwXPath(REMOVE_BUNDLE_DISCOUNT_DIALOG_XPATH + "//h2"));

        private Locator removeBundleDiscountDialogContent = locator(pwXPath(REMOVE_BUNDLE_DISCOUNT_DIALOG_XPATH + "//div[contains(@class,'dialog-body')]"));

        private Locator buttonRemoveItBundleDiscountDialog = locator(pwXPath(REMOVE_BUNDLE_DISCOUNT_DIALOG_XPATH + "//button[contains(@class,'remove-btn')]"));

        private Locator buttonKeepDiscountBundleDiscountDialog = locator(pwXPath(REMOVE_BUNDLE_DISCOUNT_DIALOG_XPATH + "//button[contains(@class,'keep-btn')]"));

        private Locator buttonNextAutoDetailsDesktop = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[contains(text(),'Next: Auto details')]"));

        private Locator buttonNextAutoDetailsMobile = locator(pwXPath(QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[contains(text(),'Next: Auto details')]"));

    protected static final String BUNDLE_DISCOUNT_INTERSTITIAL_PAGE_XPATH = "//div[@class='bundle-page-container']";

        private Locator bundleDiscountInterstitialPageHeading = locator(pwXPath(BUNDLE_DISCOUNT_INTERSTITIAL_PAGE_XPATH + "/h1"));

        private Locator bundleDiscountInterstitialPageSubheading = locator(pwXPath(BUNDLE_DISCOUNT_INTERSTITIAL_PAGE_XPATH + "//div[contains(@class, 'bundle-page-title-font')]"));

        private Locator bundleDiscountInterstitialPageImage = locator(pwXPath(BUNDLE_DISCOUNT_INTERSTITIAL_PAGE_XPATH + "//div[contains(@class, 'auto-home-group-image-container')]"));

        private Locator bundleDiscountInterstitialPagePromo = locator(pwXPath(BUNDLE_DISCOUNT_INTERSTITIAL_PAGE_XPATH + "//div[contains(@class, 'bundle-page-promo-trust')]"));

        private Locator bundleDiscountSavingsText = locator(pwXPath(BUNDLE_DISCOUNT_INTERSTITIAL_PAGE_XPATH + "//div[contains(@class, 'bundle-page-title-savings-font')]"));

        private Locator quoteSummarySubheading = locator(pwXPath("//app-home-quote-review//div[contains(@class,'tui-stacking-top-xl')]/div[contains(@class,'tui-stacking-top-md') and not(contains(@class,'bundle-discount-card'))]"));

    private static final String CHANGE_COVERAGE_XPATH = "//a[contains(text(),'Back to dwelling coverage') or contains(text(),'change coverage')]";
        private Locator linkBackToDwellingCoverage = locator(pwXPath(CHANGE_COVERAGE_XPATH));

    private static final String CONTINUE_WITH_HOME_ONLY_XPATH = "//app-bundle-page//a[@data-tui-tracking-id='home__continue-button-cta']";
        private Locator linkToContinueWithHomeOnly = locator(pwXPath(CONTINUE_WITH_HOME_ONLY_XPATH));

    private static final String CONTINUE_WITH_BUNDLE_XPATH = "//app-bundle-page//button[@data-tui-tracking-id='bundle-page__continue-button-cta']";
        private Locator buttonToContinueWithBundle = locator(pwXPath(CONTINUE_WITH_BUNDLE_XPATH));

    private static final String NEXT_AUTO_DETAILS_DESKTOP_XPATH = "//app-home-quote-review//mat-card//button[contains(text(),'Next: Auto details') and contains(@class,'tui-quote-presentment-button')]";
        private Locator buttonToContinueWithAutoBundleDesktop = locator(pwXPath(NEXT_AUTO_DETAILS_DESKTOP_XPATH));

    private static final String NEXT_AUTO_DETAILS_MOBILE_XPATH = "//app-home-quote-review//mat-card//button[contains(text(),'Next: Auto details') and contains(@class,'tui-quote-presentment-minimized-button')]";
        private Locator buttonToContinueWithAutoBundleMobile = locator(pwXPath(NEXT_AUTO_DETAILS_MOBILE_XPATH));

        private Locator quotePriceOnCard = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tui-price"));

        private Locator quotePriceOnCardMobile = locator(pwXPath(QUOTE_PRESENTMENT_MOBILE_XPATH + "//tui-price"));

    private String DEDUCTIBLE_AMOUNT_XPATH = "//div[contains(@class,'deductible-label') and contains(text(),'%s')]/following-sibling::div[contains(@class,'deductible-amount')]";
        private Locator quoteDiscountsOnCard = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//mat-list-item//div[contains(@class,'discounts-included')]"));
        private Locator quoteDiscountsOnCardMobile = locator(pwXPath(QUOTE_PRESENTMENT_MOBILE_XPATH + "//mat-list-item//div[contains(@class,'discounts-included')]"));
        private Locator quoteDiscountsOnCardWithSavings = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//div[contains(@class,'discount-description')]//p[contains(@class,'tui-subtitle')]"));
        private Locator quoteDiscountsOnCardWithSavingsMobile = locator(pwXPath(QUOTE_PRESENTMENT_MOBILE_XPATH + "//div[contains(@class,'discount-description')]//p[contains(@class,'tui-subtitle')]"));
        private Locator quoteDiscountsSavingOnCard = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//div[contains(@class,'discounts-saving')]"));
        private Locator quoteDiscountsSavingOnCardMobile = locator(pwXPath(QUOTE_PRESENTMENT_MOBILE_XPATH + "//div[contains(@class,'discounts-saving')]"));
        private Locator policyDeductibleHeader = locator(pwXPath("//div[contains(@class,'main-content')]/div[1]"));
        protected Locator outOfPocketLossForCoveredLoss = locator(pwXPath("//div[contains(@class,'main-content')]/div[contains(@class,'tui-stacking-top-sm')]"));
        private Locator deductibleLabels = locator(pwXPath("//div[contains(@class,'deductible-label')]"));
        private Locator deductibleAmount = locator(pwXPath("//div[contains(@class,'deductible-amount')]"));
        private Locator allPerilsDeductibleInfoIcon = locator(pwXPath("//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_A']"));
        private Locator windAndHailDeductibleInfoIcon = locator(pwXPath("//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_W']"));
        private Locator hurricaneDeductibleInfoIcon = locator(pwXPath("//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_H']"));
        private Locator tropicalCycloneDeductibleInfoIcon = locator(pwXPath("//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_T']"));
        private Locator waterDeductibleInfoIcon = locator(pwXPath("//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_R']"));
        private Locator deductibleMatDividers = locator(pwXPath("//div[contains(@class,'deductibles')]//mat-divider"));
        protected Locator editDeductibleIcon = locator(pwXPath("//button[contains(@class,'edit-deductibles-button')]//mat-icon"));
        protected Locator editDeductibleText = locator(pwXPath("//button[contains(@class,'edit-deductibles-button')]//span"));
        protected Locator editDeductibleButton = locator(pwXPath("//button[contains(@class,'edit-deductibles-button')]"));
        private Locator infoSideSheetHeaderHomeLob = locator(pwXPath("//app-home-coverages-and-deductibles-info-dialog//h1"));
        private Locator closeIconPolicyDeductibleSideSheet = locator(pwXPath("//app-home-coverages-and-deductibles-info-dialog//button[@aria-label='Close']"));
        private Locator policyDeductibleTitlesInSideSheet = locator(pwXPath("//mat-panel-title//div"));
        private Locator policyDeductibleExplanationInSideSheet = locator(pwXPath("//div[contains(@class,'mat-expansion-panel-body')]//p[contains(@class,'tui-caption-text')][1]"));
        private Locator policyDeductibleTitlesInSideSheetTXState = locator(pwXPath("//app-home-coverages-and-deductibles-info-dialog//mat-expansion-panel-header"));
        private Locator policyDeductibleSubTitlesInSideSheetWindCycloneHailLoss = locator(pwXPath("//app-home-coverages-and-deductibles-info-dialog//h2"));
        private Locator policyDeductibleExplanationInSideSheetTXState = locator(pwXPath("//app-home-coverages-and-deductibles-info-dialog//p"));
        private Locator policyDeductibleSideSheetDividers = locator(pwXPath("//mat-accordion//mat-divider"));
        private Locator deductibleHeader = locator(pwXPath("//app-edit-home-deductibles-side-sheet//h1"));
        private Locator closeIconInDeductibleSideSheet = locator(pwXPath("//app-edit-home-deductibles-side-sheet//button[@data-test-id='CLOSE_BUTTON']"));
        private Locator allPerilLossesHeader = locator(pwXPath("//app-edit-home-deductibles-side-sheet//h2[1]"));
        private Locator allPerilLossesDescription = locator(pwXPath("//div[contains(@class,'tui-caption-text')][1]"));
        private Locator allPerilLossesRadioButtons = locator(pwXPath("//mat-radio-group[@name='allPerilsCoverageSelection']//mat-radio-button//input"));
        private Locator allPerilLossesMatRadioButtons = locator(pwXPath("//mat-radio-group[@name='allPerilsCoverageSelection']//mat-radio-button"));
        private Locator windAndHailLossesHeader = locator(pwXPath("//app-edit-home-deductibles-side-sheet//h2"));
        private Locator windAndHailLossesDescription = locator(pwXPath("//div[contains(@class,'tui-caption-text')]"));
        private Locator waterLossesHeader = locator(pwXPath("(//app-edit-home-deductibles-side-sheet//h2)[2]"));
        private Locator waterLossesDescription = locator(pwXPath("(//div[contains(@class,'tui-caption-text')])[2]"));
        private Locator windAndHailLossesRadioButtons = locator(pwXPath("//mat-radio-group[@name='windAndHailCoverageSelection']//mat-radio-button//input"));
        private Locator windAndHailLossesMatRadioButtons = locator(pwXPath("//mat-radio-group[@name='windAndHailCoverageSelection']//mat-radio-button"));
        private Locator selectTheDeductibleYouWantToChangeHeader = locator(pwXPath("//h2[contains(@text,'Select the deductible you want to change:')]"));
        private Locator hurricaneWindHailToggleButtons = locator(pwXPath("//mat-button-toggle//button[@name='hurricaneWindHailToggleGroup']"));
        private Locator neitherToggleButtonNoteElement = locator(pwXPath("//div[contains(text(),'Note: Both of these deductibles will match the all peril losses deductible.')]"));
        private Locator windHailToggleButtonNoteElement = locator(pwXPath("//div[contains(text(),'Note: The wind and hail deductible will match the all perils losses deductible.')]"));
        private Locator hurricaneToggleButtonNoteElement = locator(pwXPath("//div[contains(text(),'Note: The hurricane deductible will match the all perils losses deductible.')]"));
        private Locator hurricaneMatRadioButtons = locator(pwXPath("//mat-radio-group[@name='hurricaneCoverageSelection']//mat-radio-button"));
        private Locator hurricaneRadioButtons = locator(pwXPath("//mat-radio-group[@name='hurricaneCoverageSelection']//mat-radio-button//input"));
        private Locator waterMatRadioButtons = locator(pwXPath("//mat-radio-group[@name='waterPerilSelection']//mat-radio-button"));
        private Locator waterRadioButtons = locator(pwXPath("//mat-radio-group[@name='waterPerilSelection']//mat-radio-button//input"));
        private Locator matDividerInDeductiblesSideSheet = locator(pwXPath("//app-edit-home-deductibles-dialog//mat-divider"));
        private Locator recalculateButton = locator(pwXPath("//button[@data-test-id='RECALCULATE_BUTTON']"));
        private Locator resetChangesButton = locator(pwXPath("//button[@data-test-id='OPEN_CONFIRM_RESET_DIALOG_BUTTON']"));
        private Locator resetChangesHeader = locator(pwXPath("//h2[contains(@class,'reset-changes-heading')]"));
        private Locator areYouSureYouWantToResetChangesQuestion = locator(pwXPath("//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-content"));
        private Locator keepEditingButton = locator(pwXPath("//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-actions//button[1]"));
        private Locator resetButton = locator(pwXPath("//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-actions//button[2]"));

        private Locator packagePriceSubtitle = locator(pwCss("div.tui-subtitle"));

    private static final String DEDUCTIBLE_SELECTION_ERROR_XPATH = "//mat-error[contains(@class,'home-quote-deductible__error-label')]";
        private Locator deductibleSelectionError = locator(pwXPath(DEDUCTIBLE_SELECTION_ERROR_XPATH));
    private final static String SIDE_SHEET_CLOSE_BUTTON_XPATH = "//app-home-coverages-and-deductibles-info-dialog//button[@aria-label='Close']";
        private Locator closeIconInPolicyDeductibleSideSheet = locator(pwXPath(SIDE_SHEET_CLOSE_BUTTON_XPATH));
        private Locator standardPackageButton = locator(pwXPath("//div[@aria-label='Standard package']"));
        private Locator enhancedPackageButton = locator(pwXPath("//div[@aria-label='Enhanced package']"));
        private Locator premierPackageButton = locator(pwXPath("//div[@aria-label='Premier package']"));
        private Locator packageNameHeader = locator(pwXPath("//div[contains(@class,'package-body-content')]/div[1]"));
        private Locator packageSubTotalHeader = locator(pwXPath("//div[contains(@class,'package-body-content')]/div[2]"));
        private Locator packagePremiumAmount = locator(pwXPath("//div[contains(@class,'package-body-content')]/div[3]"));
        private Locator choiceOfFeaturesLabel = locator(pwXPath("//div[contains(@class,'package-body-content')]/div[4]"));
        private Locator comparePackageDoubleArrowIcon = locator(pwXPath("//button[contains(@class,'compare-button')]//mat-icon"));
        private Locator comparePackageButton = locator(pwXPath("//button[contains(@class,'compare-button')]"));
        private Locator coverageTypeLabels = locator(pwXPath("//div[contains(@class,'coverage-section-label')]"));
        private Locator coveragesLabels = locator(pwXPath("//div[contains(text(),'Coverages')]"));
        private Locator limitLabels = locator(pwXPath("//div[contains(text(),'Limits')]"));
        private Locator coverageNames = locator(pwXPath("//div[contains(@class,'coverage-description')]"));
        private Locator primaryCoverageNames = locator(pwXPath("//div[contains(text(), 'Primary')]//following-sibling::div/div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-description')]"));
        private Locator primaryCoverageAmount = locator(pwXPath("//div[contains(text(), 'Primary')]//following-sibling::div/div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-amount')]"));
        private Locator supplementalCoverageNames = locator(pwXPath("//div[contains(text(), 'Additional')]//following-sibling::div/div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-description')]/div"));
        private Locator supplementalCoverageAmount = locator(pwXPath("//div[contains(text(), 'Additional')]//following-sibling::div/div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-amount')]/div"));
        private Locator supplementalCoverageNamesOptional = locator(pwXPath("//div[contains(text(), 'Optional')]//following-sibling::div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-description')]"));
        private Locator supplementalCoverageAmountOptional = locator(pwXPath("//div[contains(text(), 'Optional')]//following-sibling::div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-amount')]"));
        private Locator specialLimitCoverageNames = locator(pwXPath("//div[contains(text(), 'Special limits (Personal property)')]//following-sibling::div//div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-description')]"));
        private Locator specialLimitCoverageAmount = locator(pwXPath("//div[contains(text(), 'Special limits (Personal property)')]//following-sibling::div//div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-amount')]"));
        private Locator showSpecialLimitsLinkButton = locator(pwXPath("//button[@id='specialLimitsButton']//span"));
        private Locator showSpecialLimitsLinkPlusIcon = locator(pwXPath("//button[@id='specialLimitsButton']//mat-icon[text()='add']"));
        private Locator coverageAmountValues = locator(pwXPath("//div[contains(@class,'coverage-amount')]"));
    protected static final String EXPECTED_OUT_OF_POCKET_COST_FOR_COVERED_LOSS = "Your out-of-pocket cost for a covered loss.";
        private Locator emailLink = locator(pwId("emailLink"));
        private Locator linkCloseEmailSnackBar = locator(pwLinkText("Done"));

        protected Locator buttonReviewOptionalCoverageDesktop = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[contains(text(),'optional coverages')]"));
        protected Locator buttonReviewOptionalCoverageMobile = locator(pwXPath(QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[contains(text(),'optional coverages')]"));

        private Locator dwellingInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_24121']//mat-icon"));
        private Locator separateStructureInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_24404']//mat-icon"));
        private Locator personalPropertyInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_24321']//mat-icon"));
        private Locator lossOfUseInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_24507']//mat-icon"));
        private Locator personalLiabilityInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_10624']//mat-icon"));
        private Locator medicalPaymentToOthersInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_10625']//mat-icon"));
        private Locator coveragesHeadersInInfoSideSheet = locator(pwXPath("//mat-expansion-panel//mat-expansion-panel-header"));

        private Locator coveragesDescriptionsInInfoSideSheet = locator(pwXPath("//div[contains(@class,'mat-expansion-panel-body')]"));
        private Locator closeIconInCoverageInfoSideSheetHomeLob = locator(pwXPath("//app-home-coverages-and-deductibles-info-dialog//mat-icon[contains(text(),'close')]"));

        private Locator roofMaterialInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_23108' or @data-test-id='COVERAGE_INFO_BUTTON_23104']//mat-icon"));
        private Locator fenceInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_23109']//mat-icon"));
        private Locator buildingOrdinanceInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_24204']//mat-icon"));
        private Locator sidingRoofMaterialsInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_20717']//mat-icon"));
        private Locator cyberIdentityShieldInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_10632']//mat-icon"));
        private Locator carpetLossInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_23110']//mat-icon"));
        private Locator limitedMatchingUndamagedPropertyInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_20717']//mat-icon"));
        private Locator homeSharingInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_20999']//mat-icon"));
        private Locator mineSubsidenceInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_20630']//mat-icon"));
        private Locator accessThroughFoundationsAndWallsInfoIcon = locator(pwXPath("//button[@data-test-id='COVERAGE_INFO_BUTTON_20744']//mat-icon"));
        private Locator doubleArrowInComparePackageLink = locator(pwXPath("//button[contains(@class,'compare-button')]//mat-icon"));
        private Locator comparePackageLinkText = locator(pwXPath("//button[contains(@class,'compare-button')]//span"));
        private Locator comparePackageHeaderInComparePkgSideSheet = locator(pwXPath("//app-compare-quotes-modal//h2"));
        private Locator subTextInComparePkgSideSheet = locator(pwXPath("//p[contains(text(),'highlighted the coverages that have different limits')]"));
        private Locator standardVsEnhancedButton = locator(pwXPath("//div[@role='tab'][contains(.,'Standard v. Enhanced')]"));
        private Locator enhancedVsPremierButton = locator(pwXPath("//div[@role='tab'][contains(.,'Enhanced v. Premier')]"));
        private Locator packageLabelsInComparePackageSideSheet = locator(pwXPath("//div[contains(@class,'compare-quotes-title')]"));

    private String SIDE_SHEET_COVERAGE_TABLE_XPATH = "//div[contains(.,'%s')]/div[contains(@class,'compare-quotes-table')]";

        private Locator primaryAdditionalSpecialLimitsLabelsInCompareQuoteSideSheet = locator(pwXPath("//div[contains(@class,'compare-quotes-title')]//p"));

    // Edit primary coverages side-sheet section
        protected Locator editPrimaryCoverageIcon = locator(pwXPath("//button[contains(@class,'edit-coverage-button')]//mat-icon"));
        protected Locator editPrimaryCoverageText = locator(pwXPath("//button[contains(@class,'edit-coverage-button')]//span"));
        protected Locator editPrimaryCoverageButton = locator(pwXPath("//button[contains(@class,'edit-coverage-button')]"));
        protected Locator editPrimaryCoverageCloseButton = locator(pwXPath("//app-edit-coverage//a[.='close']"));
        protected Locator editCoverageSideSheetTitle = locator(pwXPath("//app-edit-coverage//div[@id='editCoverageDialogHeading']"));
        protected Locator editCoverageCards = locator(pwXPath("//app-edit-coverage//coverage-data-card"));
        protected Locator editCoverageCardTitles = locator(pwXPath("//app-edit-coverage//coverage-data-card//label[contains(@class,'tui-input-text-2')]"));
    // Extended dwelling replacement cost group
        protected Locator extendedDRC_radioButtons = locator(pwXPath("//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'23012')]/mat-radio-button"));
    // Separate structures group
        protected Locator separateStructures_radioButtons = locator(pwXPath("//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'24404')]/mat-radio-button"));
    // Personal property limit group
        protected Locator personalPropertyLimit_radioButtons = locator(pwXPath("//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'24321')]/mat-radio-button"));
    // Personal property loss settlement group
        protected Locator personalPropertyLossSettlement_radioButtons = locator(pwXPath("//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'23100')]/mat-radio-button"));
    // Personal property perils group
        protected Locator personalPropertyPerils_radioButtons = locator(pwXPath("//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'24322')]/mat-radio-button"));
    // Loss of use limit group
        protected Locator lossOfUseLimit_radioButtons = locator(pwXPath("//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'24507')]/mat-radio-button"));
    // Loss of use term group
        protected Locator lossOfUseTerm_radioButtons = locator(pwXPath("//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'20645')]/mat-radio-button"));
    // Personal liability group
        protected Locator personalLiability_radioButtons = locator(pwXPath("//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'10624')]/mat-radio-button"));
    // Medical payments group
        protected Locator medicalPayments_radioButtons = locator(pwXPath("//app-edit-coverage//coverage-data-card//mat-radio-group[contains(@id,'10625')]/mat-radio-button"));
        protected Locator editCoverageCardDividers = locator(pwXPath("//app-edit-coverage//div[contains(@class,'edit-coverage-coverage-card')]//mat-divider"));
        private Locator recalculatePrimaryCoveragesButton = locator(pwXPath("//app-edit-coverage//button[contains(@class,'edit-coverage-dialog-submit-button')]"));
        private Locator resetPrimaryCoveragesButton = locator(pwXPath("//app-edit-coverage//button[text()='Reset changes']"));
        private Locator confirmResetButton = locator(pwXPath("//mat-dialog-container//button[@data-test-id='RESET_BUTTON']"));

    // CA Fair Plan Endorsement Exclusions side-sheet section
        private Locator fairPlanEndorsementTitle = locator(pwXPath("//div[contains(@class,'documents-required-popup')]//p[contains(@class,'tui-body-text-bold')]"));
        private Locator fairPlanExclusionsDescription = locator(pwXPath("//div[contains(@class,'documents-required-popup')]//ul"));
        private Locator fairPlanExclusionsFooters = locator(pwXPath("//div[contains(@class,'documents-required-popup')]//p[contains(@class,'same-note')]"));

    // CA Fair Plan Endorsement Pop-up Dialog
        private Locator fairPlanEndorsementDialogTitle = locator(pwXPath("//mat-dialog-container[@aria-labelledby='policyExclusion']//tui-simple-dialog-title"));
        private Locator fairPlanEndorsementDialogContent = locator(pwXPath("//mat-dialog-container[@aria-labelledby='policyExclusion']//mat-dialog-content "));
        private Locator dialogContinueButton = locator(pwXPath("//mat-dialog-container[@aria-labelledby='policyExclusion']//button[text()='Continue']"));

    // F82552: AL - WindHail exclusion
        private Locator windHailExclusionPopupTitle = locator(pwXPath("//mat-dialog-container//h2[text()='Policy exclusions']"));
        private Locator windHailExclusionPopupSubTitleContent = locator(pwXPath("//mat-dialog-container//mat-dialog-content "));
        private Locator windHailExclusionPopupContinueBtn = locator(pwXPath("//mat-dialog-container//mat-dialog-actions//button[text()='Yes']"));
        private Locator windHailExclusionPopupCancelBtn = locator(pwLinkText("No, thanks"));
        private Locator windHailExclusionTitle = locator(pwXPath("//div[contains(@class,'documents-required-popup')]//div[@class='documents-required-card-description']/p"));

    private static final String ALL_PERIL_DEDUCTIBLE_2500 = "$2,500";
    private static final String COVERAGE_VALUE_500000 = "$500,000";
    private static final String COVERAGE_VALUE_10000 = "$10,000";
    private static final String COVERAGE_VALUE_25000 = "$25,000";

        private Locator sweepStakesPopup = locator(pwXPath("//app-sweep-stakes-popup"));
        private Locator sweepStakesHeading = locator(pwXPath("//app-sweep-stakes-popup//h4[@id='sweepStakesHeading']"));
        private Locator sweepStakesContent = locator(pwXPath("//app-sweep-stakes-popup//mat-dialog-content[@id='sweepStakesMessage']/p[1]"));
        private Locator sweepStakesHelpText = locator(pwXPath("//app-sweep-stakes-popup//mat-dialog-content[@id='sweepStakesMessage']/p[contains(@class,'sweep-stakes__help-text')]"));
        private Locator sweepStakesOkButton = locator(pwXPath("//app-sweep-stakes-popup//button[.='Ok']"));

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public AceHomeReviewQuotePage() throws Exception {
    }

    public boolean isOnReviewQuotePageHome(boolean longWait) {
        if (longWait) {
            try {
                wait.until(Conditions.or(
                        Conditions.visible(linkToContinueWithHomeOnly),
                        Conditions.visible(linkBackToDwellingCoverage),
                        Conditions.visible(tryAgainButton)));
            } catch (TimeoutError te) {
                return false;
            }
        }
        return isElementVisibleAndClickable(linkToContinueWithHomeOnly, 2) ||
                isElementVisibleAndClickable(linkBackToDwellingCoverage, 2);
    }

    public String getDwellingCoverageFromHeading() {
        final String subheadingVerbiage = "Packages are based on your selected dwelling coverage of";
        final String changeCoverage = "(change coverage).";
        return getTextFromElement(quoteSummarySubheading).replace(subheadingVerbiage, EMPTY_STRING)
                .replace(changeCoverage,EMPTY_STRING);
    }

    public Double getPriceValue(String price) {
        return Double.parseDouble(price.replace("$",EMPTY_STRING)
                .replace(COMMA,EMPTY_STRING).replace("/mo",EMPTY_STRING));
    }

    public String getQuotePriceOnCard() {
        return isUseMobileViewEnabled() ? getTextFromElement(quotePriceOnCardMobile) : getTextFromElement(quotePriceOnCard);
    }

    public String getPackagePriceOnCard() throws Exception {
        String PRIMARY_PACKAGE_XPATH ="//tr/td[starts-with(text(),'Included') or starts-with(text(),'Primary')]/following-sibling::td";
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard, 2)) {
                clickElement(expandQuoteCard);
            }
            PRIMARY_PACKAGE_XPATH = QUOTE_PRESENTMENT_MOBILE_XPATH + PRIMARY_PACKAGE_XPATH;
        } else {
            PRIMARY_PACKAGE_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + PRIMARY_PACKAGE_XPATH;
        }
        Locator primaryPackagePriceWe = locator(pwXPath(PRIMARY_PACKAGE_XPATH));
        return getTextFromElement(primaryPackagePriceWe);
    }

    public String getOptionalCoveragesPriceOnCard() throws Exception {
        String OPTIONAL_PACKAGE_XPATH = "//tr/td[text()='Optional coverages']/following-sibling::td";
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard, 2)) {
                clickElement(expandQuoteCard);
            }
            OPTIONAL_PACKAGE_XPATH = QUOTE_PRESENTMENT_MOBILE_XPATH + OPTIONAL_PACKAGE_XPATH;
        } else {
            OPTIONAL_PACKAGE_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + OPTIONAL_PACKAGE_XPATH;
        }
        Locator quoteOptionalCoveragesPriceOnCard = locator(pwXPath(OPTIONAL_PACKAGE_XPATH));
        return getTextFromElement(quoteOptionalCoveragesPriceOnCard);
    }

    public String getDiscountsOnCard() {
        Locator discountElement;
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard, 2)) {
                clickElement(expandQuoteCard);
            }
            discountElement = isElementVisible(quoteDiscountsSavingOnCardMobile, 2) ? quoteDiscountsOnCardWithSavingsMobile : quoteDiscountsOnCardMobile;
        } else {
            discountElement = isElementVisible(quoteDiscountsSavingOnCard, 2) ? quoteDiscountsOnCardWithSavings: quoteDiscountsOnCard;
        }
        return getTextFromElement(discountElement);
    }

    public String getDiscountSavingOnCard() {
        Locator savingTextWe = isUseMobileViewEnabled() ? quoteDiscountsSavingOnCardMobile : quoteDiscountsSavingOnCard;
        return getTextFromElement(savingTextWe);
    }

    public String getPageSubtitle(String subtitle, String coverage) {
        return String.format(subtitle, coverage);
    }

    public void validatePageTitleSubtitle(FarmersSoftAssert fsa, String coverage) {
        fsa.assertEquals(getTextFromElement(quoteSummaryHeading), PAGE_TITLE2, "Ace Home Review Quote page - Title.");
        fsa.assertEquals(getTextFromElement(quoteSummarySubheading), getPageSubtitle(PAGE_SUBTITLE, coverage), "Ace Home Review Quote page - Subtitle.");
    }

    public boolean isPageTitleInViewport() throws Exception {
        return isElementInViewport(quoteSummaryHeading);
    }

    public boolean isOnBundleInterstitialPage(boolean longWait) {
        if (longWait) {
            try {
                wait.until(Conditions.visible(linkToContinueWithHomeOnly));
            } catch (Exception e) {
                return false;
            }
        }
        return isElementVisibleAndClickable(linkToContinueWithHomeOnly, 2);
    }

    public void validateBundleDiscountInterstitialPage(FarmersSoftAssert fsa) {

        fsa.assertEquals(getTextFromElement(bundleDiscountInterstitialPageHeading), BUNDLE_DISCOUNT_HEADING, "Bundle discount interstitial page heading verification.");
        fsa.assertEquals(getTextFromElement(bundleDiscountInterstitialPageSubheading), BUNDLE_DISCOUNT_SUBHEADING, "Bundle discount interstitial page sub-heading verification.");
        fsa.assertEquals(bundleDiscountInterstitialPageImage.count(), 1,  "Bundle discount interstitial page image count verification.");
        fsa.assertEquals(getTextFromElement(bundleDiscountInterstitialPagePromo), BUNDLE_DISCOUNT_PROMO_CONTENT, "Bundle discount interstitial page promo content verification.");
        fsa.assertEquals(getTextFromElement(bundleDiscountSavingsText), BUNDLE_DISCOUNT_SAVING_CONTENT, "Bundle discount interstitial page saving content verification.");
        fsa.assertTrue((isElementVisibleAndClickable(buttonToContinueWithBundle, 2)), "Continue with bundle discount button visibility and clickability verification.");
        fsa.assertEquals(getTextFromElement(buttonToContinueWithBundle),CONTINUE_WITH_BUNDLE_DISCOUNT_CONTENT, "Continue with bundle button text validation");
        fsa.assertTrue((isElementVisibleAndClickable(linkToContinueWithHomeOnly, 2)), "Continue with Home link visibility and clickability verification.");
        fsa.assertEquals(getTextFromElement(linkToContinueWithHomeOnly),CONTINUE_WITH_HOME_ONLY_CONTENT, "Continue with Home link text validation");
    }

    public void validateBundleDiscountContent(FarmersSoftAssert fsa, String stateCode) {
        if (isBundleDiscountStateV2(stateCode)) {
            fsa.assertTrue(isElementDisplayed(bundleDiscountCard, 3), "Bundle discount card displayed.");
            fsa.assertEquals(getTextFromElement(bundleDiscountCard), BUNDLE_DISCOUNT_CARD_CONTENT, "Bundle discount card content verification.");
            fsa.assertEquals(bundleDiscountCardImages.count(), 2, "Bundle discount card image count verification.");
            fsa.assertTrue(isElementDisplayed(bundleCardApplyDiscountButton, 3), "Bundle discount card - Apply discount button displayed.");
        } else {
            fsa.assertFalse(isElementDisplayed(bundleDiscountCard, 3), "Bundle discount card should not be displayed.");
        }
    }

    public void validateBundleDiscountAppliedToHomeContent(FarmersSoftAssert fsa, String stateCode) {
        if (isBundleDiscountStateV2(stateCode)) {
            fsa.assertTrue(isElementDisplayed(bundleDiscountCard, 3), "Bundle discount card displayed.");
            fsa.assertEquals(getTextFromElement(bundleDiscountAppliedCard), BUNDLE_DISCOUNT_APPLIED_CONTENT, "Bundle discount applied content verification.");
            fsa.assertEquals(bundleDiscountCardImages.count(), 2, "Bundle discount card image count verification.");
            fsa.assertFalse(isElementDisplayed(bundleCardApplyDiscountButton, 3), "Bundle discount card - Apply discount button not displayed.");
            fsa.assertEquals(getTextFromElement(removeBundleDiscountLink), REMOVE_BUNDLE_DISCOUNT_CONTENT, "remove Bundle Discount Link content verification.");
            fsa.assertTrue(isNextAutoDetailsButtonAvailable(), "Next - Auto details button visibility and clickability verification.");
        } else {
            fsa.assertFalse(isElementDisplayed(bundleDiscountCard, 3), "Bundle discount card should not be displayed.");
        }
    }

    public boolean isNextAutoDetailsButtonAvailable() {
        return isElementVisibleAndClickable(isUseMobileViewEnabled() ?
                 buttonNextAutoDetailsMobile : buttonNextAutoDetailsDesktop, 3);
    }

    public void validateBundleDiscountAppliedContent(FarmersSoftAssert fsa) {
        fsa.assertTrue(isElementDisplayed(bundleDiscountCard, 3), "Bundle discount card displayed.");
        fsa.assertEquals(getTextFromElement(bundleDiscountAppliedCard), BUNDLE_DISCOUNT_APPLIED_CONTENT, "Bundle discount applied content verification.");
        fsa.assertEquals(bundleDiscountCardImages.count(), 2, "Bundle discount card image count verification.");
        fsa.assertEquals(getTextFromElement(changeYourMindText), CHANGE_YOUR_MIND_CONTENT, "Bundle discount - Change your mind content verification.");
        fsa.assertTrue(isElementVisibleAndClickable(removeBundleDiscountLink, 2), "Remove bundle discount link visibility and clickability verification.");
        fsa.assertEquals(getTextFromElement(removeBundleDiscountLink), REMOVE_BUNDLE_DISCOUNT_CONTENT, "remove Bundle Discount Link content verification.");
        fsa.assertTrue(isNextAutoDetailsButtonAvailable(), "Next - Auto details button visibility and clickability verification.");
    }

    public void validateRemoveDiscountDialogContent(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(removeBundleDiscountDialogTitle), REMOVE_BUNDLE_DISCOUNT_DIALOG_TITLE, "Remove bundle discount dialog title verification.");
        fsa.assertEquals(getTextFromElement(removeBundleDiscountDialogContent), REMOVE_BUNDLE_DISCOUNT_DIALOG_CONTENT, "Remove bundle discount dialog content verification.");
        fsa.assertTrue(isElementVisibleAndClickable(buttonRemoveItBundleDiscountDialog, 2), "Remove it button visibility and clickability verification in remove bundle discount dialog.");
        fsa.assertTrue(isElementVisibleAndClickable(buttonKeepDiscountBundleDiscountDialog, 2), "Keep discount button visibility and clickability verification in remove bundle discount dialog.");
    }

    public void clickApplyBundleDiscountButton() {
        waitAndClickElement(bundleCardApplyDiscountButton, 3);
    }

    public void clickApplyBundleDiscountButtonIfPresent() {
        if (isElementVisibleAndClickable(bundleCardApplyDiscountButton,3)) {
            waitAndClickElement(bundleCardApplyDiscountButton);
        }
    }

    public void clickContinueWithAutoBundleButton() {
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(buttonToContinueWithAutoBundleMobile, 3);
        } else {
            waitAndClickElement(buttonToContinueWithAutoBundleDesktop, 3);
        }
    }

    public void clickRemoveDiscountLink() {
        waitAndClickElement(removeBundleDiscountLink, 3);
    }

    public void clickRemoveDiscountDialogButton() {
        waitAndClickElement(buttonRemoveItBundleDiscountDialog, 3);
    }

    public void clickKeepDiscountDialogButton() {
        waitAndClickElement(buttonKeepDiscountBundleDiscountDialog, 3);
    }

    public void clickReviewOptionalCoverageButton() {
    	if (isUseMobileViewEnabled()) {
    		waitAndClickElement(buttonReviewOptionalCoverageMobile, 3);
    	} else {
    		waitAndClickElement(buttonReviewOptionalCoverageDesktop, 3);
    	}
    }

    public boolean isRemoveDiscountDialogDisplayed() {
        return isElementVisible(removeBundleDiscountDialog, 2);
    }

    public void validateAmountLabelForPolicyDeductible(FarmersSoftAssert fsa, String stateCode, String label) throws Exception {
        if(isWindHailExclusionState(stateCode)) {
            boolean isWindHailExclusionSelected = getSessionStorageAppStore().getControlData().isWindHailExclusionSelected();
            if (isWindHailExclusionSelected) {
                String message = stateCode.equals(AL)? "Hurricane" : "Tropical Cyclone";
                String notCoveredLabel = "Not covered";
                fsa.assertTrue(getTextFromElement(deductibleAmount.nth(1)).equals(notCoveredLabel), "Wind & hail amount text includes: " + label);
                fsa.assertTrue(getTextFromElement(deductibleAmount.nth(2)).equals(notCoveredLabel), String.format("%s amount text includes: ", message) + label);
            }
        } else {
            fsa.assertTrue(getTextFromElement(deductibleAmount.nth(1)).contains(label), "Wind & hail amount text includes: " + label);
            fsa.assertTrue(getTextFromElement(deductibleAmount.nth(2)).contains(label), "Hurricane amount text includes: " + label);
        }
    }

    private boolean isWindHailExclusionState(String stateCode) {
        return List.of(AL, TX).contains(stateCode);
    }

    private boolean isAllPerilDefaultValueState(String stateCode) {
        // All Peril default is set to $2,500
        return List.of(KS, MO, OK, UT).contains(stateCode);
    }


    public void validateContentOfPolicyDeductibleSection(FarmersSoftAssert fsa, String stateCode) throws Exception {
        waitElementBeVisible(policyDeductibleHeader);
        fsa.assertEquals(getTextFromElement(policyDeductibleHeader), EXPECTED_POLICY_DEDUCTIBLES_HEADER, "Policy deductible header verification.");

        fsa.assertEquals(getTextFromElement(outOfPocketLossForCoveredLoss), EXPECTED_OUT_OF_POCKET_COST_FOR_COVERED_LOSS, "Out of pocket covered loss text verification.");
        String deductibleLabel = "deductible";
        String expectedWindAndHailLabel = "Wind & hail";
        String expectedAllPerilsExceptWindAndHailLabel;
        if (List.of(AL, CT, GA, MD, PA, TN, VA).contains(stateCode)){
            expectedAllPerilsExceptWindAndHailLabel = stateCode.equals(CT)? "All perils except wind & hail" : "All perils";
            String expectedHurricaneLabel = "Hurricane";
            fsa.assertEquals(deductibleLabels.count(), 3, "All perils, Hurricane, Wind and hail label count.");
            fsa.assertTrue(hurricaneDeductibleInfoIcon.isVisible(), "Hurricane info icon displayed.");
            fsa.assertEquals(deductibleMatDividers.count(), 3, "Mat divider count verification.");
            fsa.assertEquals(getTextFromElement(deductibleLabels.nth(2)), expectedHurricaneLabel, "Hurricane label verification.");
            validateAmountLabelForPolicyDeductible(fsa, stateCode, deductibleLabel);
        } else if (stateCode.equals(TX)){
            expectedAllPerilsExceptWindAndHailLabel = "All perils";
            String expectedTropicalCycloneLabel = "Tropical cyclone";
            fsa.assertEquals(deductibleLabels.count(), 3, "All perils, Wind and hail, Tropical cyclones label count.");
            fsa.assertTrue(hurricaneDeductibleInfoIcon.isVisible(), "Tropical cyclone info icon displayed.");
            fsa.assertEquals(deductibleMatDividers.count(), 3, "Mat divider count verification.");
            fsa.assertEquals(getTextFromElement(deductibleLabels.nth(1)), expectedWindAndHailLabel, "Wind and hail label verification.");
            fsa.assertEquals(getTextFromElement(deductibleLabels.nth(2)), expectedTropicalCycloneLabel, "Tropical cyclone label verification.");
            validateAmountLabelForPolicyDeductible(fsa, stateCode, deductibleLabel);
        } else if (stateCode.equals(CA)) {
            boolean fairPlanIndicator = getSessionStorageAppStore().getControlData().isFairPlanIndicator();
            String expectedWaterLabel = "Water";
            expectedAllPerilsExceptWindAndHailLabel = "All perils except water";
            if (fairPlanIndicator) {
                expectedAllPerilsExceptWindAndHailLabel += " & excluded perils from (FPCE) CA Fair Plan Endorsement";
            }
            fsa.assertEquals(getTextFromElement(deductibleLabels.nth(1)), expectedWaterLabel, "Water label verification.");
            fsa.assertEquals(deductibleMatDividers.count(), 2, "Mat divider count verification.");
            fsa.assertTrue(getTextFromElement(deductibleAmount.nth(1)).contains(deductibleLabel), "Water deductible amount text includes: " + deductibleLabel);
        } else {
            expectedAllPerilsExceptWindAndHailLabel = "All perils except wind & hail";
            fsa.assertEquals(getTextFromElement(deductibleLabels.nth(1)), expectedWindAndHailLabel, "Wind and hail label verification.");
            fsa.assertEquals(deductibleMatDividers.count(), 2, "Mat divider count verification.");
            // MO - US902799 - We should match the default all peril deductible (existing logic applies that it cannot be lower than all peril)
            if (isAllPerilDefaultValueState(stateCode)) {
                String windHailDeductibleAmount = getDeductibleAmountByName(expectedWindAndHailLabel);
                double dAmount = convertCurrencyStringToDouble(windHailDeductibleAmount);
                fsa.assertTrue(dAmount >= 2500d, "Wind Hail deductible amount is >= $2,500: " + expectedWindAndHailLabel);
            }
            fsa.assertTrue(getTextFromElement(deductibleAmount.nth(1)).contains(deductibleLabel), "Wind & hail deductible amount displayed as expected.");
        }
        fsa.assertEquals(getTextFromElement(deductibleLabels.nth(0)), expectedAllPerilsExceptWindAndHailLabel, expectedAllPerilsExceptWindAndHailLabel + " label verification.");
        deductibleLabel = isAllPerilDefaultValueState(stateCode) ? ALL_PERIL_DEDUCTIBLE_2500 + SPACE + deductibleLabel : deductibleLabel;
        fsa.assertTrue(getTextFromElement(deductibleAmount.nth(0)).contains(deductibleLabel), "Expected " + expectedAllPerilsExceptWindAndHailLabel + " deductible amount displayed.");
        fsa.assertTrue(allPerilsDeductibleInfoIcon.isVisible(), "All perils except wind and hail info icon displayed.");
        if (!stateCode.equals(CA)) {
            fsa.assertTrue(windAndHailDeductibleInfoIcon.isVisible(), "Wind and hail info icon displayed.");
        } else {
            fsa.assertTrue(waterDeductibleInfoIcon.isVisible(), "Water deductible info icon displayed.");
        }
        fsa.assertTrue(editDeductibleButton.isVisible(), "Edit deductible button displayed.");
        fsa.assertTrue(editDeductibleIcon.isVisible(), "Edit deductible info icon displayed.");
        fsa.assertEquals(getTextFromElement(editDeductibleText), EXPECTED_EDIT_DEDUCTIBLES_LINK_TEXT, "Edit deductible text verification.");
    }

    public void validateContentOfPolicyDeductiblesSideSheetAllPerils(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome) {
        waitElementBeVisible(infoSideSheetHeaderHomeLob);

        fsa.assertEquals(getTextFromElement(infoSideSheetHeaderHomeLob), EXPECTED_POLICY_DEDUCTIBLES_HEADER, "Policy deductible header verification in policy deductible side sheet.");
        fsa.assertTrue(isElementPresent(pwXPath(SIDE_SHEET_CLOSE_BUTTON_XPATH),3), "Close icon displayed in policy deductible side sheet.");
        String stateCode = applicantAceHome.getStateCode();
        String expectedAllPerilsExceptWindAndHailHeaderInSideSheet;
        if(List.of(AL, GA, MD, PA, TN, VA).contains(stateCode)){
            expectedAllPerilsExceptWindAndHailHeaderInSideSheet = "All perils";
            String expectedHurricaneHeaderInSideSheet = "Hurricane";
            fsa.assertEquals(getTextFromElement(policyDeductibleTitlesInSideSheet.nth(2)), expectedHurricaneHeaderInSideSheet,
                    "Hurricane header verification in policy deductible side sheet.");
        } else if (stateCode.equals(TX)) {
            expectedAllPerilsExceptWindAndHailHeaderInSideSheet = "All perils";
            fsa.assertEquals(getTextFromElement(policyDeductibleTitlesInSideSheetTXState.nth(0)), expectedAllPerilsExceptWindAndHailHeaderInSideSheet,
                    "All perils header verification in policy deductible side sheet.");

            String expectedAllPerilsDescriptionInSideSheet = "The deductible is the amount you pay toward any covered loss. The deductible applies separately to each loss or damage event. This deductible applies to all causes of loss, " +
                    "unless a separate deductible for a certain cause of loss is shown and selected.";
            fsa.assertEquals(getTextFromElement(policyDeductibleExplanationInSideSheetTXState.nth(0)), expectedAllPerilsDescriptionInSideSheet,
                    "All perils description verification in policy deductible side sheet.");

            String expectedWindCycloneHailSubHeaderInSideSheet = "Wind & hail";
            fsa.assertEquals(getTextFromElement(policyDeductibleTitlesInSideSheetTXState.nth(1)), expectedWindCycloneHailSubHeaderInSideSheet,
                    "Wind & hail losses sub-header verification in policy deductible side sheet.");

            String expectedWindHailCycloneDescriptionInSideSheet = "Tropical cyclone";
            fsa.assertEquals(getTextFromElement(policyDeductibleTitlesInSideSheetTXState.nth(2)), expectedWindHailCycloneDescriptionInSideSheet,
                    "Tropical cyclone sub-header verification in policy deductible side sheet.");
        } else {
            expectedAllPerilsExceptWindAndHailHeaderInSideSheet = "All perils except wind & hail";
        }

        if (!List.of(CA,TX).contains(stateCode)) {
            fsa.assertEquals(getTextFromElement(policyDeductibleTitlesInSideSheet.nth(0)), expectedAllPerilsExceptWindAndHailHeaderInSideSheet,
                    expectedAllPerilsExceptWindAndHailHeaderInSideSheet + " header verification in policy deductible side sheet.");

            String expectedAllPerilsExceptWindAndHailDescriptionInSideSheet = "The deductible is the amount you pay toward any covered loss. The deductible applies separately to each loss or damage event. " +
                    "This deductible applies to all causes of loss, unless a separate deductible for a certain cause of loss is shown and selected.";
            fsa.assertEquals(getTextFromElement(policyDeductibleExplanationInSideSheet.nth(0)), expectedAllPerilsExceptWindAndHailDescriptionInSideSheet,
                    expectedAllPerilsExceptWindAndHailHeaderInSideSheet + " description verification in policy deductible side sheet.");

            String expectedWindAndHailHeaderInSideSheet = "Wind & hail";
            fsa.assertEquals(getTextFromElement(policyDeductibleTitlesInSideSheet.nth(1)), expectedWindAndHailHeaderInSideSheet,
                    "Wind and hail header verification in policy deductible side sheet.");
        } else if (stateCode.equals(CA)){
            expectedAllPerilsExceptWindAndHailHeaderInSideSheet = "All perils";
            fsa.assertEquals(getTextFromElement(policyDeductibleTitlesInSideSheet.nth(0)), expectedAllPerilsExceptWindAndHailHeaderInSideSheet,
                    expectedAllPerilsExceptWindAndHailHeaderInSideSheet + " header verification in policy deductible side sheet.");

            String expectedAllPerilsExceptWindAndHailDescriptionInSideSheet = "The deductible is the amount you pay toward any covered loss. The deductible applies separately to each loss or damage event. " +
                    "This deductible applies to all causes of loss, unless a separate deductible for a certain cause of loss is shown and selected.";
            fsa.assertEquals(getTextFromElement(policyDeductibleExplanationInSideSheet.nth(0)), expectedAllPerilsExceptWindAndHailDescriptionInSideSheet,
                    expectedAllPerilsExceptWindAndHailHeaderInSideSheet + " description verification in policy deductible side sheet.");

            String expectedWaterHeaderInSideSheet = "Water";
            fsa.assertEquals(getTextFromElement(policyDeductibleTitlesInSideSheet.nth(1)), expectedWaterHeaderInSideSheet,
                    "Water header verification in policy deductible side sheet.");
        }

        clickOnCloseIconInPolicyDeductibleSideSheet();
    }

    public void validateContentOfPolicyDeductiblesSideSheetWindAndHail(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome){
        waitElementBeVisible(infoSideSheetHeaderHomeLob);

        waitForUiSettled();
        fsa.assertEquals(getTextFromElement(infoSideSheetHeaderHomeLob), EXPECTED_POLICY_DEDUCTIBLES_HEADER, "Policy deductible header verification in policy deductible side sheet.");
        fsa.assertTrue(isElementPresent(pwXPath(SIDE_SHEET_CLOSE_BUTTON_XPATH),3), "Close icon displayed in policy deductible side sheet.");
        String stateCode = applicantAceHome.getStateCode();
        String expectedAllPerilsExceptWindAndHailHeaderInSideSheet = "All perils";
        if (List.of(AL, GA, MD, TN, VA).contains(stateCode)) {
            String expectedHurricaneHeaderInSideSheet = "Hurricane";
            fsa.assertEquals(getTextFromElement(policyDeductibleTitlesInSideSheet.nth(2)), expectedHurricaneHeaderInSideSheet,
                    "Hurricane header verification in policy deductible side sheet.");
        } else if (stateCode.equals(CA)) {
            String expectedWaterHeaderInSideSheet = "Water";
            fsa.assertEquals(getTextFromElement(policyDeductibleTitlesInSideSheet.nth(1)), expectedWaterHeaderInSideSheet,
                    "Water header verification in policy deductible side sheet.");
        } else {
            expectedAllPerilsExceptWindAndHailHeaderInSideSheet = "All perils except wind & hail";
        }
        fsa.assertEquals(getTextFromElement(policyDeductibleTitlesInSideSheet.nth(0)), expectedAllPerilsExceptWindAndHailHeaderInSideSheet,
                "All perils except wind and hail header verification in policy deductible side sheet.");

        if (!stateCode.equals(CA)) {
            String expectedWindAndHailHeaderInSideSheet = "Wind & hail";
            fsa.assertEquals(getTextFromElement(policyDeductibleTitlesInSideSheet.nth(1)), expectedWindAndHailHeaderInSideSheet,
                    "Wind and hail header verification in policy deductible side sheet.");

            String expectedWindAndHailDescriptionInSideSheet = "The deductible is the amount you pay toward any covered loss. " +
                    "The deductible applies separately to each loss or damage event. This deductible specifically applies to Wind and hail coverage.";
            fsa.assertEquals(getTextFromElement(policyDeductibleExplanationInSideSheet.nth(1)), expectedWindAndHailDescriptionInSideSheet,
                    "Wind and hail description verification in policy deductible side sheet.");
        } else {
            String expectedWaterHeaderInSideSheet = "Water";
            fsa.assertEquals(getTextFromElement(policyDeductibleTitlesInSideSheet.nth(1)), expectedWaterHeaderInSideSheet,
                    "Water header verification in policy deductible side sheet.");
            String expectedWaterDescriptionInSideSheet = "The deductible is the amount you pay toward any covered loss. The deductible " +
                    "applies separately to each loss or damage event. This deductible specifically applies to water coverage.";
            fsa.assertEquals(getTextFromElement(policyDeductibleExplanationInSideSheet.nth(1)), expectedWaterDescriptionInSideSheet,
                    "Water description verification in policy deductible side sheet.");
        }
        clickOnCloseIconInPolicyDeductibleSideSheet();
    }


    public void validateContentOfDeductiblesSideSheetHomeLob(FarmersSoftAssert fsa, String stateCode) throws Exception {
        validateCommonContentInDeductiblesSideSheet(fsa, stateCode);

        String expectedWindAndHailLossesHeader;
        String expectedWindAndHailLossesDescription;
        List<String> foundCoverageValuesForWindAndHailLosses;
        List<String> foundCoverageValuesForHurricane;

        List<String> expectedCoverageValuesForWindAndHail;
        if(Arrays.asList(AL, CT, GA, MD, PA, VA, TN).contains(stateCode)){
            expectedCoverageValuesForWindAndHail = expectedCoveragesValue("W", HOME);
            List<String> expectedCoverageValuesForHurricane = expectedCoveragesValue("H", HOME);
            expectedWindAndHailLossesHeader = "Other deductibles";
            expectedWindAndHailLossesDescription = "The default deductibles for these losses are the same as for all peril losses." +
                    " You can choose a higher deductible for either of these losses (but not both), to help reduce your premium.";
            List<String> expectedHurricaneWindToggleButtonNames = Arrays.asList("Neither", "Wind / hail", "Hurricane");
            List<String> foundHurricaneWindToggleButtonNames = hurricaneWindHailToggleButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
            fsa.assertEquals(foundHurricaneWindToggleButtonNames, expectedHurricaneWindToggleButtonNames, "Hurricane and wind hail toggle button names verification.");
            fsa.assertTrue(hurricaneWindHailToggleButtons.nth(0).isVisible(), "Neither toggle button displayed");
            clickNeitherMatToggleButton();
            fsa.assertTrue(neitherToggleButtonNoteElement.isVisible(), "Neither button note displayed");

            clickWindAndHailMatToggleButton();
            waitElementBeVisible(windHailToggleButtonNoteElement);
            foundCoverageValuesForWindAndHailLosses = getFoundCoverageValuesForWindAndHailLosses();
            fsa.assertTrue(hurricaneWindHailToggleButtons.nth(1).isVisible(), "Wind and hail button displayed");
            fsa.assertEquals(foundCoverageValuesForWindAndHailLosses, expectedCoverageValuesForWindAndHail, "Wind and hail losses coverage values verification.");
            fsa.assertEquals(getTextFromElement(windAndHailLossesHeader.nth(1)), expectedWindAndHailLossesHeader, "Wind and hail losses header verification in deductible side sheet.");
            fsa.assertEquals(getTextFromElement(windAndHailLossesDescription.nth(1)), expectedWindAndHailLossesDescription, "Wind and hail losses description verification in deductible side sheet.");

            clickHurricaneMatToggleButton();
            waitElementBeVisible(hurricaneToggleButtonNoteElement);
            foundCoverageValuesForHurricane = getFoundCoverageValuesForHurricane();
            fsa.assertTrue(hurricaneWindHailToggleButtons.nth(2).isVisible(), "Hurricane button displayed");
            fsa.assertEquals(foundCoverageValuesForHurricane, expectedCoverageValuesForHurricane, "Hurricane coverage values are matching.");

        } else if (stateCode.equals(CA)) {
            List<String> expectedCoverageValuesForWater = expectedCoveragesValue("R", HOME);
            String expectedWaterLossesHeader = "Water";
            String expectedWaterLossesDescription = "The deductible is the amount you pay toward any covered loss. The deductible applies separately to each loss or damage event. " +
                    "This deductible specifically applies to Water coverage.";
            List<String> foundCoverageValuesForWater = getFoundCoverageValuesForWater();
            fsa.assertEquals(getSortedList(foundCoverageValuesForWater), getSortedList(expectedCoverageValuesForWater), "Water losses coverage values are matching.");
            fsa.assertEquals(getTextFromElement(waterLossesHeader), expectedWaterLossesHeader + " losses", "Water losses header verification in deductible side sheet.");
            fsa.assertEquals(getTextFromElement(waterLossesDescription).split("\\$")[0], expectedWaterLossesDescription, "Water losses description verification in deductible side sheet.");
        } else {
            expectedCoverageValuesForWindAndHail = expectedCoveragesValue("W", HOME);
            expectedWindAndHailLossesHeader = "Wind / hail losses";
            expectedWindAndHailLossesDescription = "We pay for loss or damage when a covered loss exceeds the deductible applicable to the property. The deductible applies separately to each loss or damage event. " +
                    "This deductible applies only to losses caused by wind or hail.";
            foundCoverageValuesForWindAndHailLosses = getFoundCoverageValuesForWindAndHailLosses();
            fsa.assertEquals(getSortedList(foundCoverageValuesForWindAndHailLosses), getSortedList(expectedCoverageValuesForWindAndHail), "Wind and hail losses coverage values verification.");
            fsa.assertEquals(getTextFromElement(windAndHailLossesHeader.nth(1)), expectedWindAndHailLossesHeader, "Wind and hail losses header verification in deductible side sheet.");
            fsa.assertEquals(getTextFromElement(windAndHailLossesDescription.nth(1)), expectedWindAndHailLossesDescription, "Wind and hail losses description verification in deductible side sheet.");
        }

        // Randomly select All peril loss and validate content of recalculate, reset value pop up
        validateContentFunctionalityOfRecalculateAndResetButton(fsa);

        waitForUiSettled();
        //   List<String> expectedAllPerilLossesCoveragesValues = expectedCoveragesValue("A", HOME);
        String expectedDefaultAllPerilLossValue = getTextFromElement(deductibleAmount.nth(0));
        String onlyDollarValueFromAllPerilLoss = expectedDefaultAllPerilLossValue.split(SPACE, 2)[0];
        fsa.assertTrue(getTextFromElement(getCheckedAllPerilLossesCoverageValue(allPerilLossesMatRadioButtons)).contains(onlyDollarValueFromAllPerilLoss),
                "Default all peril losses selection verification.");

        if (!(hurricaneWindHailToggleButtons.count() == 0) && !stateCode.equals(CA)) {
            clickWindAndHailMatToggleButton();
            // Select invalid combination of All peril loss and wind/hail coverage selection and validate error and close the deductible side sheet
            scrollAndClickOnHiddenElement(allPerilLossesRadioButtons.nth(5));
            scrollAndClickOnHiddenElement(windAndHailLossesRadioButtons.nth(0));
        }

        if(isElementPresent(pwXPath(DEDUCTIBLE_SELECTION_ERROR_XPATH))){
            fsa.assertTrue(deductibleSelectionError.isVisible(), "Wind and hail deductible can not be lower than all peril deductible error displayed.");
            //            String expectedWindAndHailDeductibleCannotBeLowerThanAllPerilError = "Wind and hail deductible must be greater than the selected all perils deductible.";
            //            fsa.assertEquals(getTextFromElement(deductibleSelectionError), expectedWindAndHailDeductibleCannotBeLowerThanAllPerilError,
            //                    "Wind and hail deductible can not be lower than all peril deductible error text verification.");
        }

        // to get rid of the error, otherwise the reset button displayed
        scrollAndClickOnHiddenElement(allPerilLossesRadioButtons.nth(0));
        if (isElementDisplayed(resetChangesButton, 2)) {
            clickResetChangesButtonHomeLob();
            clickResetValueButton();
        }
        clickCloseIconOnDeductibleSideSheet();

        // Select deductible values and validate updated value on main page
        clickEditDeductiblesLink();
        waitElementBeVisible(deductibleHeader);

        String selectedWindAndHailLoss;
        String selectedWaterLoss;

        if (List.of(AL, GA, MD, PA, VA, TN).contains(stateCode)) {
            scrollAndClickOnHiddenElement(allPerilLossesRadioButtons.nth(3));
            String selectedAllPerilLoss = getTextFromElement(allPerilLossesMatRadioButtons.nth(3));

            clickWindAndHailMatToggleButton();
            waitForUiSettled();
            int lastIndexOfWindHailRadiobutton = windAndHailLossesMatRadioButtons.count() - 1;
            int secondLastIndexOfWindHailRadiobutton = windAndHailLossesMatRadioButtons.count() - 2;
            if (!windAndHailLossesRadioButtons.nth(lastIndexOfWindHailRadiobutton).isChecked()) {
                scrollAndClickOnHiddenElement(windAndHailLossesRadioButtons.nth(lastIndexOfWindHailRadiobutton));
            } else{
                scrollAndClickOnHiddenElement(windAndHailLossesRadioButtons.nth(secondLastIndexOfWindHailRadiobutton));
            }
            // selectedWindAndHailLoss = getTextFromElement(windAndHailLossesMatRadioButtons.nth(lastIndexOfWindHailRadiobutton));
            clickRecalculateButtonHomeLobInSideSheet();
            waitForSkeletonToBeGone();
            if (isOnReviewQuotePageHome(false)) {
                fsa.assertTrue(getTextFromElement(deductibleAmount.nth(0)).contains(selectedAllPerilLoss), "All peril loss value updated as selected from deductible side sheet.");

                clickEditDeductiblesLink();
                waitElementBeVisible(deductibleHeader);
                clickHurricaneMatToggleButton();
                waitForUiSettled();
                int lastIndexOfHurricaneRadiobutton = hurricaneMatRadioButtons.count() - 1;
                int secondLastIndexOfHurricaneRadiobutton = hurricaneMatRadioButtons.count() - 2;
                if (!hurricaneMatRadioButtons.nth(lastIndexOfHurricaneRadiobutton).isChecked()) {
                    scrollAndClickOnHiddenElement(hurricaneMatRadioButtons.nth(lastIndexOfHurricaneRadiobutton));
                } else {
                    scrollAndClickOnHiddenElement(hurricaneMatRadioButtons.nth(secondLastIndexOfHurricaneRadiobutton));
                }
                //   String selectedHurricaneLoss = getTextFromElement(hurricaneMatRadioButtons.nth(lastIndexOfHurricaneRadiobutton));

                clickRecalculateButtonHomeLobInSideSheet();
                waitForSkeletonToBeGone();
                if (isOnReviewQuotePageHome(false)) {
                    fsa.assertTrue(getTextFromElement(deductibleAmount.nth(0)).contains(selectedAllPerilLoss), "All peril loss value updated as selected from deductible side sheet.");
                } else {
                    Log.warn("Could not validate updated deductible values", true);
                }
            } else {
                Log.warn("Could not validate updated deductible values", true);
            }
        } else if (stateCode.equals(CA)) {
            // Row: 843. Validate Split water deductible available.  If no minimum is enforced (per below), then it must be displayed as same as all peril, and cannot go lower than all peril.
            String minAllPeril = getTextFromElement(allPerilLossesMatRadioButtons.nth(0));
            String minWater = getTextFromElement(waterMatRadioButtons.nth(0));
            fsa.assertEquals(minWater, minAllPeril, "Review quote page - Min available Water losses equals to All peril losses.");

            scrollAndClickOnHiddenElement(allPerilLossesRadioButtons.nth(3));
            String selectedAllPerilLoss = getTextFromElement(allPerilLossesMatRadioButtons.nth(3));

            int lastIndexOfWaterRadiobutton = waterMatRadioButtons.count() - 1;
            int secondLastIndexOfWaterRadiobutton = waterMatRadioButtons.count() - 2;
            int selectedIndex;
            if (!waterRadioButtons.nth(lastIndexOfWaterRadiobutton).isChecked()) {
                scrollAndClickOnHiddenElement(waterRadioButtons.nth(lastIndexOfWaterRadiobutton));
                selectedIndex = lastIndexOfWaterRadiobutton;
            } else{
                scrollAndClickOnHiddenElement(waterRadioButtons.nth(secondLastIndexOfWaterRadiobutton));
                selectedIndex = secondLastIndexOfWaterRadiobutton;
            }
            selectedWaterLoss = getTextFromElement(waterMatRadioButtons.nth(selectedIndex));

            clickRecalculateButtonHomeLobInSideSheet();
            waitForSkeletonToBeGone();
            if (isOnReviewQuotePageHome(false)) {
                fsa.assertTrue(getTextFromElement(deductibleAmount.nth(0)).contains(selectedAllPerilLoss), "All peril loss value updated as selected from deductible side sheet.");
                fsa.assertTrue(getTextFromElement(deductibleAmount.nth(1)).contains(selectedWaterLoss), "Water loss value updated as selected from deductible side sheet.");
            } else {
                Log.warn("Could not validate updated deductible values", true);
            }
        } else {
            scrollAndClickOnHiddenElement(allPerilLossesRadioButtons.nth(3));
            String selectedAllPerilLoss = getTextFromElement(allPerilLossesMatRadioButtons.nth(3));

            if (!(hurricaneWindHailToggleButtons.count() == 0)) {
                clickWindAndHailMatToggleButton();
            }
            int lastIndexOfWindHailRadiobutton = windAndHailLossesMatRadioButtons.count() - 1;
            int secondLastIndexOfWindHailRadiobutton = windAndHailLossesMatRadioButtons.count() - 2;
            int selectedIndex;
            if (!windAndHailLossesRadioButtons.nth(lastIndexOfWindHailRadiobutton).isChecked()) {
                scrollAndClickOnHiddenElement(windAndHailLossesRadioButtons.nth(lastIndexOfWindHailRadiobutton));
                selectedIndex = lastIndexOfWindHailRadiobutton;
            } else{
                scrollAndClickOnHiddenElement(windAndHailLossesRadioButtons.nth(secondLastIndexOfWindHailRadiobutton));
                selectedIndex = secondLastIndexOfWindHailRadiobutton;
            }
            selectedWindAndHailLoss = getTextFromElement(windAndHailLossesMatRadioButtons.nth(selectedIndex));

            clickRecalculateButtonHomeLobInSideSheet();
            waitForSkeletonToBeGone();
            if (deductibleAmount.count()>=2) {
                fsa.assertTrue(getTextFromElement(deductibleAmount.nth(0)).contains(selectedAllPerilLoss), "All peril loss value updated as selected from deductible side sheet.");
                fsa.assertTrue(getTextFromElement(deductibleAmount.nth(1)).contains(selectedWindAndHailLoss), "Wind and hail loss value updated as selected from deductible side sheet.");
            } else {
                Log.warn("Could not validate updated deductible values", true);
            }
        }
    }

    public void validateCommonContentInDeductiblesSideSheet(FarmersSoftAssert fsa, String stateCode) throws Exception {
        String expectedDeductiblesHeader = "Deductibles";
        fsa.assertEquals(getTextFromElement(deductibleHeader), expectedDeductiblesHeader, "Deductible header verification in deductible side sheet.");

        waitElementBeVisibleClickable(closeIconInDeductibleSideSheet);
        fsa.assertTrue(closeIconInDeductibleSideSheet.isVisible(), "Close icon displayed in deductible side sheet.");

        String expectedAllPerilLossesHeader = "All peril losses";
        fsa.assertEquals(getTextFromElement(allPerilLossesHeader), expectedAllPerilLossesHeader, "All peril losses header verification in deductible side sheet.");

        String expectedAllPerilLossesDescription = stateCode.equals(CA) ? "This deductible applies to all causes of loss, unless a separate deductible for a certain cause of loss is shown and selected. " +
                "Excluded causes of losses are not covered with this deductible." :
                "This deductible applies to all causes of loss, unless a separate deductible for a certain cause of loss is shown and selected.";

        fsa.assertEquals(getTextFromElement(allPerilLossesDescription), expectedAllPerilLossesDescription, "All peril losses description verification in deductible side sheet.");

        List<String> foundCoverageValuesForAllPerilLosses = allPerilLossesMatRadioButtons.all().stream().map(this::getTextFromElement).sorted().collect(Collectors.toList());
        Log.info("List of All peril deductibles displayed in side-sheet: " + foundCoverageValuesForAllPerilLosses);

        if (isExtendedDeductibleOptionsState(stateCode)) {
            List<String> specificExpectedAllPerilValues = List.of("(1.5% of Dwelling limit)", "(3% of Dwelling limit)");
            for (String deductibleVal : specificExpectedAllPerilValues) {
                fsa.assertTrue(containsSubstringInList(foundCoverageValuesForAllPerilLosses, deductibleVal), "All peril deductible: " + deductibleVal + " found in the list.");
            }
        }
        fsa.assertEquals(foundCoverageValuesForAllPerilLosses, expectedCoveragesValue(ALL_PERILS_COVERAGE_CODE, HOME), "All peril losses coverage values verification in deductible side sheet.");
    }


    public void validateContentOfCAFairPlanEndorsementExclusionsSection(FarmersSoftAssert fsa) {
        final String CA_FAIR_PLAN_TITLE = "CA Fair Plan Endorsement Exclusions";
        final String CA_FAIR_PLAN_CONTENT = "Fire or lightning Internal explosion Windstorm* or hail Explosion Riot or civil commotion, including looting during a riot or " +
                "civil commotion Aircraft, including self-propelled missiles and spacecraft Vehicles Smoke, including sudden and accidental damage from smoke* Volcanic " +
                "eruption Vandalism or malicious mischief";
        final String CA_FAIR_PLAN_FOOTERS = "While fire coverage isn't included due to your home's location, don't worry -- after you get your quote, " +
                "a licensed representative can guide you through the process of getting aCalifornia FAIR Planpolicy and help you get the coverage you want for your home.";
        fsa.assertEquals(getTextFromElement(fairPlanEndorsementTitle), CA_FAIR_PLAN_TITLE, "Review quote page - Deductibles side-sheet - CA FAIR Plan Title.");
        fsa.assertEquals(getTextFromElement(fairPlanExclusionsDescription), CA_FAIR_PLAN_CONTENT, "Review quote page - Deductibles side-sheet - CA FAIR Plan Exclusions.");
        String footers = EMPTY_STRING;
        for (Locator footer: fairPlanExclusionsFooters.all()) {
            footers += getTextFromElement(footer);
        }
        fsa.assertEquals(footers, CA_FAIR_PLAN_FOOTERS, "Review quote page - Deductibles side-sheet - CA FAIR Plan Footers.");
        pressEscKey();
    }

    public void validateCAFairPlanDialog(FarmersSoftAssert fsa) {
        final String CA_FAIR_PLAN_DIALOG_TITLE = "Policy exclusions";
        final String CA_FAIR_PLAN_DIALOG_CONTENT = "Based on your home's location, coverage is excluded for loss or damage caused by the following perils: " +
                "Fire or lightning Explosion Windstorm or hail And other excluded perils (more details available on next page) To be sure you have coverage " +
                "for fire, you'll need a California FAIR Plan policy. A licensed representative can help you get this policy after your quote. Please note, " +
                "fire protection related discounts may be unavailable with a Farmers\u00ae policy.";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(fairPlanEndorsementDialogTitle)), CA_FAIR_PLAN_DIALOG_TITLE, "Review quote page - Pop-up CA FAIR Plan Dialog Title.");
        fsa.assertEquals(getTextFromElement(fairPlanEndorsementDialogContent), CA_FAIR_PLAN_DIALOG_CONTENT, "Review quote page - Pop-up CA FAIR Plan Dialog Content.");
        waitAndClickElement(dialogContinueButton);
    }

    public boolean isCAFairPlanDialogPresent() {
        return isElementDisplayed(dialogContinueButton, 3);
    }

    public void validateContentFunctionalityOfRecalculateAndResetButton(FarmersSoftAssert fsa) throws Exception {
        randomlySelectAllPerilLosses(allPerilLossesRadioButtons);
        waitElementBeVisible(recalculateButton);
        fsa.assertTrue(recalculateButton.isVisible(), "Recalculate button displayed.");
        fsa.assertTrue(resetChangesButton.isVisible(), "Reset changes button displayed.");

        fsa.assertEquals(getTextFromElement(recalculateButton), EXPECTED_RECALCULATE_BUTTON_TEXT, "Recalculate button text verification.");
        fsa.assertEquals(getTextFromElement(resetChangesButton), EXPECTED_RESET_CHANGES_LINK_TEXT, "Reset changes button text verification.");

        clickResetChangesButtonHomeLob();
        validateContentOfResetChangesPopUp(fsa);
        clickKeepEditingButton();
        clickResetChangesButtonHomeLob();
        clickResetValueButton();
    }

    public void clickFairPlanDialogContinueButton() {
        waitAndClickElement(dialogContinueButton);
    }

    public void validateContentOfDeductibleSideSheetWithOnlyAllPerilSection(FarmersSoftAssert fsa, String stateCode) throws Exception {
        validateCommonContentInDeductiblesSideSheet(fsa, stateCode);
        validateContentFunctionalityOfRecalculateAndResetButton(fsa);
        int radioButtonIndex = allPerilLossesRadioButtons.nth(3).isChecked() ? 2: 3;
        scrollAndClickOnHiddenElement(allPerilLossesRadioButtons.nth(radioButtonIndex));
        String selectedAllPerilLoss = getTextFromElement(allPerilLossesMatRadioButtons.nth(radioButtonIndex));
        clickRecalculateButtonHomeLobInSideSheet();
        waitForSkeletonToBeGone();
        fsa.assertTrue(getTextFromElement(deductibleAmount.nth(0)).contains(selectedAllPerilLoss), "All peril loss value updated as selected from deductible side sheet.");
    }

    List<String> getFoundCoverageValuesForWindAndHailLosses(){
        List<String> foundCoverageValuesForWindAndHailLosses = windAndHailLossesMatRadioButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        return  foundCoverageValuesForWindAndHailLosses;
    }

    List<String> getFoundCoverageValuesForHurricane(){
        List<String> foundCoverageValuesForHurricane = hurricaneMatRadioButtons.all().stream().map(i -> getTextFromElement(i)).collect(Collectors.toList());
        return foundCoverageValuesForHurricane;
    }

    public void clickNeitherMatToggleButton(){
        waitAndClickElement(hurricaneWindHailToggleButtons.nth(0));
    }

    public void clickWindAndHailMatToggleButton(){
        waitAndClickElement(hurricaneWindHailToggleButtons.nth(1));
    }

    public void clickHurricaneMatToggleButton(){
        waitAndClickElement(hurricaneWindHailToggleButtons.nth(2));
    }

    public List<String> getFoundCoverageValuesForWater() {
        List<String> foundCoverageValuesForWater = waterMatRadioButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        return foundCoverageValuesForWater;
    }

    public void verifyQuotePresentmentCard(String stateCode, FarmersSoftAssert fsa) throws Exception {
        final List<String> RATE_PACKAGES = Arrays.asList("Enhanced", "Standard", "Premier");
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.US);
        String discountsTextFormat = isDiscountsTransparencyState(stateCode) ? "%s discounts applied" : "%s discounts included";

        fsa.assertTrue(isPresentmentCardPriceHeader(), "Review Quote page - Quote Presentment card - quote price header.");

        for (int i = 0; i < getNumberOfPackageTabs(); i++) {
            AppStore appStore = getSessionStorageAppStore();
            AppStore.Home.Quote quote = appStore.getHome().getQuote();
            String selectedPackageCode = quote.getSelectedPackageCode();
            String selectedPaymentMode = quote.getSelectedPaymentMode();
            double totalPremium = Double.parseDouble(appStore.getHome().getCoverageForPackage(selectedPackageCode, selectedPaymentMode).getTotalPremium());
            List<AppStore.Home.Discount> discounts = appStore.getHome().getDiscountsForPackage(selectedPackageCode, selectedPaymentMode);
            String totalSavingFromAppstore = appStore.getHome().getTotalSavingForPackage(selectedPackageCode, selectedPaymentMode);
            String totalSavingExpected = "Total discount savings of $" + totalSavingFromAppstore;
            if (selectedPaymentMode.equals("PIF")) {
                changeBundleQuotePricing(FULL_PRICING);
                fsa.assertEquals(currencyFormat.parse(getQuotePriceOnCard()).doubleValue(), totalPremium,
                        "Review Quote page - Quote Presentment card - Quote PIF price.");
                fsa.assertEquals(currencyFormat.parse(getPackagePriceOnCard()).doubleValue(), totalPremium,
                        "Review Quote page - Quote Presentment card - Package PIF price.");
                if (!getOptionalCoverageSumFromAppStore().equals("$0")) {
                    fsa.assertEquals(getOptionalCoveragesPriceOnCard(), getOptionalCoverageSumFromAppStore(), "Review Quote page - Quote Presentment card - Optional coverages price (PIF).");
                }
                if (isDiscountsTransparencyState(stateCode)) {
                    fsa.assertEquals(getDiscountSavingOnCard(), totalSavingExpected, "Review Quote page - Quote Presentment card - total savings (PIF).");
                }
                if (isViewMonthlyPricingLinkPresent()) {
                    clickViewMonthlyPricing();
                }
            } else if (selectedPaymentMode.equals("EFT")) {
                Double monthlyPremium = Math.round((totalPremium / 12) * 100) / 100.00;
                fsa.assertEquals(currencyFormat.parse(getQuotePriceOnCard()).doubleValue(), monthlyPremium,
                        "Review Quote page - Quote Presentment card - Quote monthly price.");
                fsa.assertEquals(currencyFormat.parse(getPackagePriceOnCard()).doubleValue(), monthlyPremium,
                        "Review Quote page - Quote Presentment card - Package monthly price.");
                if (!getOptionalCoverageSumFromAppStore().equals("$0")) {
                    fsa.assertEquals(getOptionalCoveragesPriceOnCard(), getOptionalCoverageSumFromAppStore(), "Review Quote page - Quote Presentment card - Optional coverages price (EFT).");
                }
                if (isDiscountsTransparencyState(stateCode)) {
                    fsa.assertEquals(getDiscountsOnCard(), String.format(discountsTextFormat, discounts.size()),
                            "Review Quote page - Quote Presentment card - number of discounts included (EFT)");
                    fsa.assertEquals(getDiscountSavingOnCard(), totalSavingExpected, "Review Quote page - Quote Presentment card - total savings (EFT).");
                }
                if (isViewPayInFullPricingLink()) {
                    clickViewPayInFullPricing();
                }
            }
            if ((i + 1) < getNumberOfPackageTabs()) {
                selectRatePackage(RATE_PACKAGES.get(i+1));
                waitForPageToBeReady();
            }
        }
    }

    public void validateContentOfResetChangesPopUp(FarmersSoftAssert fsa){
        String expectedResetChangesHeader = "Reset changes";
        fsa.assertEquals(getTextFromElement(resetChangesHeader), expectedResetChangesHeader, "Reset changes header verification in reset changes pop up.");

        String expectedAreYouSureYouWantToResetValuesQuestion = "Are you sure you want to reset all to default values?";
        fsa.assertEquals(getTextFromElement(areYouSureYouWantToResetChangesQuestion), expectedAreYouSureYouWantToResetValuesQuestion, "Are you sure you want to reset all to default values? question text verification.");

        String expectedKeepEditingText = "Keep editing";
        fsa.assertEquals(getTextFromElement(keepEditingButton), expectedKeepEditingText, "Keep editing button text verification.");

        String expectedResetValueText = "Reset value";
        fsa.assertEquals(getTextFromElement(resetButton), expectedResetValueText, "Reset value text verification.");
    }


    public void clickAllPerilsInfoIcon(){
        waitAndClickElement(allPerilsDeductibleInfoIcon);
    }

    public void clickWindAndHailInfoIcon(){
        waitAndClickElement(windAndHailDeductibleInfoIcon);
    }

    public void clickHurricaneInfoIcon() {
        waitAndClickElement(hurricaneDeductibleInfoIcon);
    }

    public void clickWaterInfoIcon(){
        waitAndClickElement(waterDeductibleInfoIcon);
    }

    public void randomlySelectAllPerilLosses(Locator allPerilLossesRadioButtons) throws Exception {
        randomlySelectAllPerilLosses(allPerilLossesRadioButtons.all());
    }

    public void randomlySelectAllPerilLosses(List<Locator> allPerilLossesRadioButtons) throws Exception {
        Random random = new Random();
        int randomIndex = NOT_FOUND_IN_LIST;
        boolean isNewValueSelected = false;
        while(!isNewValueSelected){
            randomIndex = random.nextInt(allPerilLossesRadioButtons.size() - 2) + 2;
            if(!allPerilLossesRadioButtons.get(randomIndex).isChecked()){
                scrollAndClickOnHiddenElement(allPerilLossesRadioButtons.get(randomIndex));
                isNewValueSelected = true;
            }
        }
        Log.info("Randomly selected All perils radio-button index: " + randomIndex);
    }

    public boolean isAllPackagesDisplayedOnReviewQuotePage() throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        AppStore.Home.Quote quote = appStore.getHome().getQuote();
        List<AppStore.Home.RateQuoteResponse> rateQuoteResponses = quote.getRateQuoteResponses();
        List<AppStore.Home.RateQuoteResponse> rateQuoteResponsesWithoutKnockOut = rateQuoteResponses.stream().filter(i -> i.getKnockOutBeanList() == null).collect(Collectors.toList());
        return rateQuoteResponsesWithoutKnockOut.size() == 6;
    }

    public void validatePackageOnReviewQuotePage(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception {
        String stateCode = applicant.getStateCode();
        waitElementBeVisible(policyDeductibleHeader);
        AppStore appStore = getSessionStorageAppStore();
        AppStore.Home.Quote quote = appStore.getHome().getQuote();
        List<AppStore.Home.RateQuoteResponse> rateQuoteResponses = quote.getRateQuoteResponses();
        List<AppStore.Home.RateQuoteResponse> rateQuoteResponsesWithoutKnockOut = rateQuoteResponses.stream().filter(i -> i.getKnockOutBeanList() == null).collect(Collectors.toList());
        int expectedPackageSize;
        if (stateCode.equals(UT)) {
            expectedPackageSize = 3;
        } else if (List.of(KY,LA,MA,MS,NC).contains(stateCode)) {
            expectedPackageSize = 1;
            fsa.assertEquals(rateQuoteResponsesWithoutKnockOut.size(), 2, "Review quote page - former EE states get only 1 package (EFT and PIF)");
            if (List.of(LA,MA).contains(stateCode)) {
                fsa.assertTrue(getFoundSupplementalCoveragesNames(stateCode).contains("Homeshare"), "Review quote page - Homeshare additional coverage is available");
            }
        } else {
            expectedPackageSize = 6;
        }

        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.enable(SerializationFeature.INDENT_OUTPUT);
            String json = mapper.writeValueAsString(getSessionStorageAppStore());
            writeDataToQuoteLogFile("App store content for "+ stateCode + COLON + SPACE + json);
        } catch (Exception e) {
            Log.warn("EXCEPTION while beautifying appstore");
            writeDataToQuoteLogFile("Exception - App store content for "+ stateCode + COLON + SPACE + getSessionStorageAppStore());
        }

        if(rateQuoteResponsesWithoutKnockOut.size() != expectedPackageSize ){
            List<AppStore.Home.RateQuoteResponse> enhancePackages = rateQuoteResponsesWithoutKnockOut.stream().filter(i -> i.getRatePackage().equals("E")).collect(Collectors.toList());
            if(!enhancePackages.isEmpty()){
                validateEnhancedPackageOnReviewQuote(fsa, applicant, true);
            }
        } else {
            clickOnStandardPackage();
            validateStandardPackageOnReviewQuote(fsa, applicant);
            clickOnEnhancedPackage();
            validateEnhancedPackageOnReviewQuote(fsa, applicant, false);
            clickOnPremierPackage();
            validatePremierPackageOnReviewQuote(fsa, applicant);
        }
    }

    public void validatePersonalPropertyWithPerils(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception {
        List<String> packages = List.of("S", "E", "P");
        for (String packageCode: packages) {
            String packageFromAppStore = getSessionStorageAppStore().getHome().getQuote().getSelectedPackageCode();
            switch (packageCode) {
                case "S":
                    if (!packageFromAppStore.equals(packageCode) && isElementDisplayed(standardPackageButton, 2)) {
                        clickOnStandardPackage();
                        waitForUiSettled();
                        packageFromAppStore = getSessionStorageAppStore().getHome().getQuote().getSelectedPackageCode();
                    }
                    break;
                case "E":
                    if (!packageFromAppStore.equals(packageCode) && isElementDisplayed(enhancedPackageButton, 2)) {
                        clickOnEnhancedPackage();
                        waitForUiSettled();
                        packageFromAppStore = getSessionStorageAppStore().getHome().getQuote().getSelectedPackageCode();
                    }
                    break;
                case "P":
                    if (!packageFromAppStore.equals(packageCode) && isElementDisplayed(premierPackageButton, 2)) {
                        clickOnPremierPackage();
                        waitForUiSettled();
                        packageFromAppStore = getSessionStorageAppStore().getHome().getQuote().getSelectedPackageCode();
                    }
                    break;
            }
            if (packageFromAppStore.equals(packageCode)) {
                boolean coverageExpected = isNamedPerilsState(applicant.getStateCode());
                fsa.assertEquals(getFoundPrimaryCoverageNames().stream().anyMatch(coverage -> coverage.contains("perils")), coverageExpected,
                        String.format("Verify Personal Property with perils coverage for %s package %s present", packageCode, (coverageExpected? "is" : "is not")));
            }
            waitForUiSettled();
        }
    }

    private void validateStandardPackageOnReviewQuote(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome) throws Exception {
        waitElementBeVisible(standardPackageButton);
        clickOnStandardPackage();
        AppStore appStore = getSessionStorageAppStore();
        String stateCode = getStateCodeFromSessionStorage();
        String selectedPackageCode = getSelectedPackage(appStore);
        String expectedStandardPackageHeaderName = isSPHOState(stateCode) ? "Standard package" : "Balanced protection";
        fsa.assertEquals(getTextFromElement(packageNameHeader), expectedStandardPackageHeaderName, "Standard package name verification.");
        String selectedPaymentMode = "PIF";
        Coverage coverage = appStore.getHome().getCoverageForPackage(selectedPackageCode, selectedPaymentMode);
        int dwellingCoverageValue = getDwellingCoverageInInt(appStore);
        if (!isEditPrimaryCoveragesState(applicantAceHome.getStateCode())) {
            String expectedPackageSubTotalHeader = "Package subtotal";
            fsa.assertEquals(getTextFromElement(packageSubTotalHeader), expectedPackageSubTotalHeader, "Package subtotal header verification.");
            changeBundleQuotePricing(FULL_PRICING);
            validateCommonThingsInPackagesSection(coverage, expectedStandardPackageHeaderName, fsa, false);
            String expectedReducedCoverageForReducedPriceLabel = "Balanced protection";
            fsa.assertEquals(getTextFromElement(choiceOfFeaturesLabel), expectedReducedCoverageForReducedPriceLabel, "Standard package label verification verification.");
        } else {
            fsa.assertEquals(getPackagePrice(), CurrencyFormat.convertStringIntoCurrencyFormat(coverage.getTotalPremium()), "Standard package price verification after selecting dwelling coverage.");
        }

        // Validate primary coverage name
        List<String> foundPrimaryCoveragesNames = getFoundPrimaryCoverageNames();
        List<String> expectedPrimaryCoverageNames = getExpectedStandardPrimaryCoverageNames(stateCode);
        fsa.assertEquals(foundPrimaryCoveragesNames, expectedPrimaryCoverageNames, "Standard package - primary coverage names verification.");

        // Validate primary coverage amount
        List<String> foundPrimaryCoveragesAmount = getFoundPrimaryCoverageAmountStandardPkg(stateCode);
        List<String> expectedCvgAmtPrimaryWithPercentOnly = getExpectedCvgAmtPrimaryWithPercentOnlyStandardPkg(coverage, dwellingCoverageValue, stateCode);
        fsa.assertEquals(foundPrimaryCoveragesAmount, expectedCvgAmtPrimaryWithPercentOnly, "Standard package - Primary coverage amount verification.");

        // validate additional coverage and amount
        List<String> foundSupplementalCoveragesNames = getFoundSupplementalCoveragesNames(stateCode);
        List<String> expectedSupplementalCoverageNames = getExpectedSupplementalCoverageNamesStandardPkg(applicantAceHome);
        fsa.assertEquals(foundSupplementalCoveragesNames, expectedSupplementalCoverageNames, "Standard package - supplemental coverage names verification.");

        List<String> foundSupplementalCoveragesAmount = getFoundSupplementalCoveragesAmount(stateCode);
        List<String> expectedSupplementalCoverageAmount = getExpectedSupplementalCoverageAmountStandardPkg(coverage);
        fsa.assertEquals(foundSupplementalCoveragesAmount, expectedSupplementalCoverageAmount, "Standard package - Supplemental coverage amount verification.");

        // Validate special limit coverage and amount
        showOrHideSpecialLimitsSection(true);
        List<String> foundSpecialLimitCoveragesNames = getFoundSpecialLimitCoveragesNames();
        List<String> expectedSpecialLimitCoveragesNames = getExpectedSpecialLimitCoveragesNamesStandardPkg();
        fsa.assertEquals(foundSpecialLimitCoveragesNames, expectedSpecialLimitCoveragesNames, "Standard package - special limit coverage names verification.");

        int indexOfPersonalPropertyAtSecondaryResidence = foundSpecialLimitCoveragesNames.indexOf(PERSONAL_PROPERTY_AT_SECONDARY_RESIDENCE);

        if (indexOfPersonalPropertyAtSecondaryResidence == NOT_FOUND_IN_LIST) {
            Log.warn(PERSONAL_PROPERTY_AT_SECONDARY_RESIDENCE + " not found in special limit coverage names");
        } else {
            String personalPropertyValue = getPersonalPropertyCoverageValueForSelectedPackage(coverage,	dwellingCoverageValue);
            List<String> expectedSpecialLimitCvgAmount = getExpectedSpecialLimitCvgAmountStandardPkg(appStore, personalPropertyValue, indexOfPersonalPropertyAtSecondaryResidence);
            List<String> foundSpecialLimitCoveragesAmount = getFoundSpecialLimitCoveragesAmount();
            fsa.assertEquals(foundSpecialLimitCoveragesAmount, expectedSpecialLimitCvgAmount, "Standard package - Special limit coverage amount verification.");
        }
    }

    protected String getPersonalPropertyCoverageValueForSelectedPackage(Coverage coverage, int dwellingCoverageValue) {
        List<String> personalPropertyValueFromPrimaryCoverageList = coverage.getCvgInfo().stream().filter(i -> i.getCvgSection().equals("Primary") && i.getCvgDesc().equals("Personal property"))
                .map(AppStore.Home.CvgInfo::getCvgAmt).collect(Collectors.toList());
        int multiplier = Integer.parseInt(personalPropertyValueFromPrimaryCoverageList.get(0).replace("%", EMPTY_STRING));
        return CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf((multiplier*dwellingCoverageValue)/100));
    }

    private String getPackagePrice() {
        return getTextFromElement(packagePriceSubtitle);
    }

    int getIndexOfPersonalPropertyValueFromPrimaryCoverage(String stateCode, String selectedPackageCode) throws Exception {
        String personalPropertyIndexName;
        List<String> listOfCoveragesInPackage;
        if (selectedPackageCode.equals("E")){
            listOfCoveragesInPackage = getExpectedEnhancedPrimaryCoverageNames(stateCode);
            personalPropertyIndexName = PERSONAL_PROPERTY_REPLACEMENT_COST_VALUE_BROAD_NAMED_PERILS;
        } else if (selectedPackageCode.equals("P")){
            listOfCoveragesInPackage = getExpectedPremierPrimaryCoverageNames(stateCode);
            personalPropertyIndexName = PERSONAL_PROPERTY_REPLACEMENT_COST_VALUE_OPEN_PERILS;
        } else {
            listOfCoveragesInPackage = getExpectedStandardPrimaryCoverageNames(stateCode);
            switch (stateCode) {
                case AZ: case CT: case GA: case KS: case LA: case MA: case MS: case OK: case PA:
                    personalPropertyIndexName = PERSONAL_PROPERTY_ACTUAL_CASH_VALUE;
                    break;
                case NC: case VA:
                    personalPropertyIndexName = PERSONAL_PROPERTY_REPLACEMENT_COST_VALUE;
                default:
                    personalPropertyIndexName = PERSONAL_PROPERTY_ACTUAL_CASH_VALUE_BROAD_NAMED_PERILS;
                    break;
            }
        }
        return listOfCoveragesInPackage.indexOf(personalPropertyIndexName);
    }

    private void validateEnhancedPackageOnReviewQuote(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome, boolean isOnePackageAvailable) throws Exception {
        changeBundleQuotePricing(FULL_PRICING);
        AppStore appStore = getSessionStorageAppStore();
        AppStore.Home.Quote quote = appStore.getHome().getQuote();
        String selectedPackageCode = quote.getSelectedPackageCode();
        String selectedPaymentMode = quote.getSelectedPaymentMode();
        Coverage coverage = appStore.getHome().getCoverageForPackage(selectedPackageCode, selectedPaymentMode);
        int dwellingCoverageValue = getDwellingCoverageInInt(appStore);
        String expectedEnhancedPackageHeaderName = "Enhanced package";
        if (!isOnePackageAvailable && !isEditPrimaryCoveragesState(applicantAceHome.getStateCode())) {
            waitElementBeVisible(enhancedPackageButton);
            fsa.assertEquals(getTextFromElement(packageNameHeader), expectedEnhancedPackageHeaderName, "Enhanced package name verification.");
            String expectedHigherCoverageForExtraFeatureLabel = "Broader protection";
            fsa.assertEquals(getTextFromElement(choiceOfFeaturesLabel), expectedHigherCoverageForExtraFeatureLabel, "Enhanced package - Broader protection label verification.");
            validateCommonThingsInPackagesSection(coverage, expectedEnhancedPackageHeaderName, fsa, isOnePackageAvailable);
        } else {
            if (isViewMonthlyPricingLink()) {
                fsa.assertEquals(getPackagePrice(), CurrencyFormat.convertStringIntoCurrencyFormat(coverage.getTotalPremium()), "Broader protection label verification after selecting dwelling coverage.");
            }
        }

        String stateCode = getStateCodeFromSessionStorage();
        // Enhanced package - Primary coverage and primary coverage amount validation enhanced
        List<String> foundPrimaryCoveragesNames = getFoundPrimaryCoverageNames();
        List<String> expectedPrimaryCoverageName = getExpectedEnhancedPrimaryCoverageNames(stateCode);
        if (stateCode.equals(AR)) {
            expectedPrimaryCoverageName.set(0, DWELLING);
        } else if (stateCode.equals(CT)) {
            expectedPrimaryCoverageName.set(0, DWELLING_COV_25_PER_OF_REPLACEMENT_COST);
            expectedPrimaryCoverageName.set(4, LOSS_OF_USE_TEXT);
        }
        fsa.assertEquals(foundPrimaryCoveragesNames, expectedPrimaryCoverageName, "Enhanced package - primary coverage names verification.");

        List<String> foundPrimaryCoveragesAmount = getFoundPrimaryCoverageAmount();
        List<String> expectedCvgAmtPrimaryWithPercentOnly = getExpectedCvgAmtPrimaryWithPercentOnlyEnhancedPkg(coverage, dwellingCoverageValue, stateCode);
        fsa.assertEquals(foundPrimaryCoveragesAmount, expectedCvgAmtPrimaryWithPercentOnly, "Enhanced package - Primary coverage amount verification.");

        // validate supplemental coverage and amount enhanced package
        List<String> foundSupplementalCoveragesNames = getFoundSupplementalCoveragesNames(stateCode);
        List<String> expectedSupplementalCoverageNames = getExpectedSupplementalCoverageNamesEnhancedPkg(applicantAceHome);
        fsa.assertEquals(foundSupplementalCoveragesNames, expectedSupplementalCoverageNames, "Enhanced package - supplemental coverage names verification.");

        List<String> foundSupplementalCoveragesAmount = getFoundSupplementalCoveragesAmount(stateCode);
        List<String> expectedSupplementalCoverageAmount = getExpectedSupplementalCoverageAmountEnhancedPkg(coverage, dwellingCoverageValue);
        fsa.assertEquals(foundSupplementalCoveragesAmount, expectedSupplementalCoverageAmount, "Enhanced package - Supplemental coverage amount verification.");

        // Validate special limit coverage and amount enhanced package
        List<String> foundSpecialLimitCoveragesNames = getFoundSpecialLimitCoveragesNames();
        List<String> expectedSpecialLimitCoveragesNames = new ArrayList<>(getExpectedSpecialLimitCoveragesNamesEnhancedPkg());
        if (stateCode.equals(CO)) {
            expectedSpecialLimitCoveragesNames.remove(MOTOR_VEHICLE_PARTS);
        }
        fsa.assertEquals(foundSpecialLimitCoveragesNames, expectedSpecialLimitCoveragesNames, "Enhanced - special limit coverage names verification.");

        int personalPropertyValue = Integer.parseInt(getPersonalPropertyCoverageValueForSelectedPackage(coverage, dwellingCoverageValue).replaceAll("[$,]",EMPTY_STRING));
        List<String> foundSpecialLimitCoveragesAmount = getFoundSpecialLimitCoveragesAmount();
        List<String> expectedSpecialLimitCvgAmount = getExpectedSpecialLimitCvgAmountEnhancedPkg(appStore, personalPropertyValue);
        fsa.assertEquals(foundSpecialLimitCoveragesAmount, expectedSpecialLimitCvgAmount, "Enhanced package - Special limit coverage amount verification.");
        showOrHideSpecialLimitsSection(true);
        validatePrimaryCoverageHelpInfoIconSideSheet(fsa, stateCode);
        validateAdditionalCoverageHelpInfoIconSideSheetEnhancedPackage(fsa, applicantAceHome, getCoverageAmountByNameAndType(ROOF_MATERIALS, PRIMARY));
    }

    public void validatePremierPackageOnReviewQuote(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome) throws Exception {
        waitElementBeVisible(premierPackageButton);
        AppStore appStore = getSessionStorageAppStore();
        String selectedPackageCode = getSelectedPackage(appStore);
        String expectedEnhancedPackageHeaderName = "Premier package";
        fsa.assertEquals(getTextFromElement(packageNameHeader), expectedEnhancedPackageHeaderName, "Premier package name verification.");

        String selectedPaymentMode = "PIF";
        changeBundleQuotePricing(FULL_PRICING);
        Coverage coverage = appStore.getHome().getCoverageForPackage(selectedPackageCode, selectedPaymentMode);
        validateCommonThingsInPackagesSection(coverage, expectedEnhancedPackageHeaderName, fsa, false);

        String expectedHigherCoverageForGreatestChoiceFeatureLabel = "Higher level of protection";
        fsa.assertEquals(getTextFromElement(choiceOfFeaturesLabel), expectedHigherCoverageForGreatestChoiceFeatureLabel, "highest coverage limits and greatest choice of features verification - premier package.");

        // Premier package - Primary coverage and primary coverage amount validation enhanced
        String stateCode = getStateCodeFromSessionStorage();
        List<String> foundPrimaryCoveragesNames = getFoundPrimaryCoverageNames();
        List<String> expectedPrimaryCoverageName = getExpectedPremierPrimaryCoverageNames(stateCode);

        if (stateCode.equals(CO)) {
            expectedPrimaryCoverageName.set(0, DWELLING_COV_50_PER_OF_REPLACEMENT_COST);
        } else if (stateCode.equals(CT)) {
            expectedPrimaryCoverageName.set(0, DWELLING_COV_50_PER_OF_REPLACEMENT_COST);
            expectedPrimaryCoverageName.set(4, LOSS_OF_USE_TEXT);
        }

        fsa.assertEquals(foundPrimaryCoveragesNames, expectedPrimaryCoverageName, "Premier package - primary coverage names verification.");


        // scenarios listed at serial no - 145, 146, 147, 148 from Home LOB Regression Sheet
        // US897162 - MI
        if (List.of(AR, TN, TX, UT, MI).contains(stateCode)) {
            validateCoverageAndAmountOnReviewQuotePage(fsa, PERSONAL_LIABILITY, PRIMARY, COVERAGE_VALUE_500000);
            if(!stateCode.equals(MI)) {
                validateCoverageAndAmountOnReviewQuotePage(fsa, CYBER_IDENTITY_SHIELD, ADDITIONAL, COVERAGE_VALUE_25000);
            }
            if (!List.of(TN, TX).contains(stateCode)) {
                validateCoverageAndAmountOnReviewQuotePage(fsa, LIMITED_MATCHING_COVERAGE_SIDING_AND_ROOF, ADDITIONAL, COVERAGE_VALUE_10000);
            }
        }
        List<String> foundPrimaryCoveragesAmount = getFoundPrimaryCoverageAmount();
        List<String> expectedCvgAmtPrimaryWithPercentOnly = getExpectedCvgAmtPrimaryWithPercentOnlyPremierPkg(coverage, appStore, stateCode);
        fsa.assertEquals(foundPrimaryCoveragesAmount, expectedCvgAmtPrimaryWithPercentOnly, "Premier package - primary coverage amount verification.");
        int dwellingCoverageValue = getDwellingCoverageInInt(appStore);

        // validate supplemental coverage and amount enhanced package
        List<String> foundSupplementalCoveragesNames = getFoundSupplementalCoveragesNames(stateCode);
        List<String> expectedSupplementalCoverageNames = getExpectedSupplementalCoverageNamesPremierPkg(appStore, applicantAceHome, expectedCvgAmtPrimaryWithPercentOnly);
        fsa.assertEquals(foundSupplementalCoveragesNames, expectedSupplementalCoverageNames, "Premier package - Special limit coverage name verification.");

        int index = foundSupplementalCoveragesNames.indexOf(BUILDING_ORDINANCE_OR_LAW);
        if (index == NOT_FOUND_IN_LIST) {
            Log.warn("foundSupplementalCoveragesNames.indexOf(BUILDING_ORDINANCE_OR_LAW) = not found");
        } else {
            List<String> foundSupplementalCoveragesAmount = getFoundSupplementalCoveragesAmount(stateCode);
            //expected list removes "On"
            foundSupplementalCoveragesAmount = foundSupplementalCoveragesAmount.stream().filter(i -> !i.contains("On")).collect(Collectors.toList());
            List<String> expectedSupplementalCoverageAmount = getExpectedSupplementalCoverageAmount(coverage, index, dwellingCoverageValue);
            fsa.assertEquals(foundSupplementalCoveragesAmount, expectedSupplementalCoverageAmount, "Premier package - Supplemental coverage amount verification.");
        }

        // Validate special limit coverage and amount premier package
        List<String> foundSpecialLimitCoveragesNames = getFoundSpecialLimitCoveragesNames();
        List<String> expectedSpecialLimitCoveragesNames = getExpectedSpecialLimitCoveragesNamesPremierPkg();
        fsa.assertEquals(foundSpecialLimitCoveragesNames, expectedSpecialLimitCoveragesNames, "Premier package - Special limit coverage names verification.");

        int indexOfCardsAndComicBooksCoverageName = foundSpecialLimitCoveragesNames.indexOf(CARDS_AND_COMIC_BOOKS);
        if (indexOfCardsAndComicBooksCoverageName == NOT_FOUND_IN_LIST) {
            Log.warn("foundSpecialLimitCoveragesNames.indexOf(CARDS_AND_COMIC_BOOKS) = not found");
        } else {
            String personalPropertyValue = getPersonalPropertyCoverageValueForSelectedPackage(coverage, dwellingCoverageValue);
            List<String> expectedSpecialLimitCvgAmount = getExpectedSpecialLimitCvgAmountPremierPkg(appStore, personalPropertyValue, indexOfCardsAndComicBooksCoverageName);
            List<String> foundSpecialLimitCoveragesAmount = getFoundSpecialLimitCoveragesAmount();
            fsa.assertEquals(foundSpecialLimitCoveragesAmount, expectedSpecialLimitCvgAmount, "Premier package - Special limit coverage amount verification.");
        }
        showOrHideSpecialLimitsSection(true);
    }

    // Validate content of common things in all three packages
    private void validateCommonThingsInPackagesSection(Coverage coverage, String packageName, FarmersSoftAssert fsa, boolean onlyOnePackageAvailable) throws Exception{
        if(onlyOnePackageAvailable){
            waitElementBeVisible(packageNameHeader);
            String expectedSubTotalHeader = "Subtotal";
            fsa.assertEquals(getTextFromElement(packageNameHeader), expectedSubTotalHeader, "Package subtotal header verification - " + packageName + ".");

            double totalPremium = Double.parseDouble(coverage.getTotalPremium());
            fsa.assertEquals(getTextFromElement(packageSubTotalHeader), CurrencyFormat.convertStringIntoCurrencyFormat(String.valueOf(totalPremium)), "Package premium verification - " + packageName + ".");
        }else{
            String expectedPackageSubTotalHeader = "Package subtotal";
            fsa.assertEquals(getTextFromElement(packageSubTotalHeader), expectedPackageSubTotalHeader, "Package subtotal header verification - " + packageName + ".");

            double totalPremium = Double.parseDouble(coverage.getTotalPremium());
            fsa.assertEquals(getTextFromElement(packagePremiumAmount), CurrencyFormat.convertStringIntoCurrencyFormat(String.valueOf(totalPremium)), "Package premium verification - " + packageName + ".");

            fsa.assertTrue(comparePackageDoubleArrowIcon.isVisible(), "Compare package arrow icon displayed - " + packageName + ".");
            fsa.assertTrue(comparePackageButton.isVisible(), "Compare package button displayed - " + packageName + ".");
        }

        showOrHideSpecialLimitsSection(false);
        fsa.assertEquals(getTextFromElement(showSpecialLimitsLinkButton), "Show Special limits (Personal property)", "Show Special limits (Personal property) text verification - " + packageName + ".");
        fsa.assertTrue(isElementDisplayed(showSpecialLimitsLinkPlusIcon, 2), "Show Special limits (Personal property) plus icon displayed - " + packageName + ".");
        showOrHideSpecialLimitsSection(true);

        String expectedPrimaryCoverageTypeLabel = "Primary";
        waitElementBeVisible(coveragesLabels.nth(0));
        fsa.assertEquals(getTextFromElement(coverageTypeLabels.nth(0)), expectedPrimaryCoverageTypeLabel, "Primary coverages label text verification - " + packageName + ".");

        String expectedSupplementalCoverageTypeLabel = getCoverageSectionDescriptionForSupplementalCoverage();
        fsa.assertEquals(getTextFromElement(coverageTypeLabels.nth(1)), expectedSupplementalCoverageTypeLabel, "Supplemental coverages label text verification - " + packageName + ".");

        String expectedSpecialLimitsCoverageTypeLabel = "Special limits (Personal property)";
        fsa.assertEquals(getTextFromElement(coverageTypeLabels.nth(2)), expectedSpecialLimitsCoverageTypeLabel, "Special limits (Personal property) coverages label text verification - " + packageName + ".");

        fsa.assertEquals(coveragesLabels.count() ,3, "Coverages labels count verification - " + packageName + ".");
        fsa.assertEquals(limitLabels.count() , 3, "Limits labels count verification - " + packageName + ".");
    }


    // Validate info icon and related text in the side sheet for primary package
    private void validatePrimaryCoverageHelpInfoIconSideSheet(FarmersSoftAssert fsa, String stateCode){
        List<Locator> primaryCoverageInfoIcons = Arrays.asList(dwellingInfoIcon, roofMaterialInfoIcon, separateStructureInfoIcon, personalPropertyInfoIcon,
                lossOfUseInfoIcon, personalLiabilityInfoIcon, medicalPaymentToOthersInfoIcon);

        waitAndClickElement(primaryCoverageInfoIcons.get(0));
        waitElementBeVisible(infoSideSheetHeaderHomeLob);
        String expectedInfoSideSheetHeaderInHomeLob = "Primary Coverages";
        fsa.assertEquals(getTextFromElement(infoSideSheetHeaderHomeLob), expectedInfoSideSheetHeaderInHomeLob, expectedInfoSideSheetHeaderInHomeLob + " header verification in Home lob coverage info side sheet.");
        List<String> foundCoveragesHeadersInInfoSideSheet = coveragesHeadersInInfoSideSheet.all().stream().map(this::getTextFromElement).collect(Collectors.toList());

        clickCloseIconInCoverageInfoSideSheet();
        List<String> expectedPrimaryCoverageHeadersInInfoSideSheet = new ArrayList<>();
        List<String> expectedPrimaryCoverageDescriptionsInInfoSideSheet = new ArrayList<>();

        switch (stateCode) {
            case AL: case AR: case AZ: case CT: case GA: case IA: case ID: case IN: case OH: case OR: case MD: case MI:
            case MO: case MN: case ND: case NE: case NM: case SD: case TN: case TX: case WA: case WI:
                expectedPrimaryCoverageHeadersInInfoSideSheet = ENHANCED_PRIMARY_COVERAGE_HEADER_IN_SIDE_SHEET.getCoveragesHeaderDescriptionInInfoSideSheet();
                expectedPrimaryCoverageDescriptionsInInfoSideSheet = ENHANCED_PRIMARY_COVERAGE_DESCRIPTION_IN_SIDE_SHEET_WITH_PERILS.getCoveragesHeaderDescriptionInInfoSideSheet();
                if (stateCode.equals(AR)) {
                    expectedPrimaryCoverageHeadersInInfoSideSheet.set(0, DWELLING);
                    expectedPrimaryCoverageDescriptionsInInfoSideSheet.set(0, CoverageInfoDetails.DWELLING_COST_DESCRIPTION);
                } else if (stateCode.equals(CT)) {
                    expectedPrimaryCoverageHeadersInInfoSideSheet.set(4, LOSS_OF_USE_TEXT);
                    expectedPrimaryCoverageDescriptionsInInfoSideSheet.set(4, CoverageInfoDetails.LOSS_OF_USE_DESCRIPTION);
                }
                break;
            case KS:
                expectedPrimaryCoverageHeadersInInfoSideSheet.addAll(ENHANCED_PRIMARY_COVERAGE_HEADER_IN_SIDE_SHEET_KS.getCoveragesHeaderDescriptionInInfoSideSheet());
                expectedPrimaryCoverageDescriptionsInInfoSideSheet = ENHANCED_PRIMARY_COVERAGE_DESCRIPTION_IN_SIDE_SHEET_WITH_PERILS.getCoveragesHeaderDescriptionInInfoSideSheet();
                break;
            case UT:
                expectedPrimaryCoverageHeadersInInfoSideSheet = ENHANCED_PRIMARY_COVERAGE_HEADER_IN_SIDE_SHEET_MD.getCoveragesHeaderDescriptionInInfoSideSheet();
                expectedPrimaryCoverageDescriptionsInInfoSideSheet = ENHANCED_PRIMARY_COVERAGE_DESCRIPTION_IN_SIDE_SHEET_MD.getCoveragesHeaderDescriptionInInfoSideSheet();
                break;
            case VA:
                expectedPrimaryCoverageHeadersInInfoSideSheet = ENHANCED_PRIMARY_COVERAGE_HEADER_IN_SIDE_SHEET_VA.getCoveragesHeaderDescriptionInInfoSideSheet();
                expectedPrimaryCoverageDescriptionsInInfoSideSheet = ENHANCED_PRIMARY_COVERAGE_DESCRIPTION_IN_SIDE_SHEET_VA.getCoveragesHeaderDescriptionInInfoSideSheet();
                break;
            default:
                expectedPrimaryCoverageHeadersInInfoSideSheet = ENHANCED_PRIMARY_COVERAGE_HEADER_IN_SIDE_SHEET.getCoveragesHeaderDescriptionInInfoSideSheet();
                expectedPrimaryCoverageDescriptionsInInfoSideSheet = ENHANCED_PRIMARY_COVERAGE_DESCRIPTION_IN_SIDE_SHEET.getCoveragesHeaderDescriptionInInfoSideSheet();
                if (stateCode.equals(CA)) {
                    expectedPrimaryCoverageDescriptionsInInfoSideSheet.set(1, CoverageInfoDetails.ROOF_MATERIAL_ACV_DESCRIPTION);
                    expectedPrimaryCoverageDescriptionsInInfoSideSheet.set(3, CoverageInfoDetails.PERSONAL_PROPERTY_DESCRIPTION_COVERAGE_C);
                }
                break;
        }

        List<Integer> listOfSizes = new ArrayList<>(Arrays.asList(primaryCoverageInfoIcons.size(), foundCoveragesHeadersInInfoSideSheet.size(), expectedPrimaryCoverageHeadersInInfoSideSheet.size(), expectedPrimaryCoverageDescriptionsInInfoSideSheet.size()));
        int maxIndex = listOfSizes.stream().min(Integer::compare).get();
        fsa.assertTrue(listOfSizes.stream().allMatch(listOfSizes.get(0)::equals), "Number of expected Primary Coverage Icons, headers and descriptions are the same " + listOfSizes + SPACE + "expectedHeaders:" + expectedPrimaryCoverageHeadersInInfoSideSheet + " foundHeaders:" + foundCoveragesHeadersInInfoSideSheet);
        for (int i = 0; i < maxIndex; i++){
            waitAndClickElement(primaryCoverageInfoIcons.get(i));
            fsa.assertEquals(foundCoveragesHeadersInInfoSideSheet.get(i), expectedPrimaryCoverageHeadersInInfoSideSheet.get(i),
                    "Primary coverage header in info side sheet for " +  expectedPrimaryCoverageHeadersInInfoSideSheet.get(i) + " coverage is correct - Home lob.");
            waitForUiSettled();
            boolean contentCheckSuccessful = getFoundListOfCoverageDescriptionFromCoverageInfoSideSheet().get(0).contains(expectedPrimaryCoverageDescriptionsInInfoSideSheet.get(i));
            fsa.assertTrue(contentCheckSuccessful, "Primary coverage description for " +  expectedPrimaryCoverageHeadersInInfoSideSheet.get(i) + " coverage is correct - Home lob.");
            if (!contentCheckSuccessful) {
                Log.warn("Description expected: " + expectedPrimaryCoverageDescriptionsInInfoSideSheet.get(i));
                Log.warn("Description found: " + getFoundListOfCoverageDescriptionFromCoverageInfoSideSheet().get(0));
            }
            clickCloseIconInCoverageInfoSideSheet();
        }
    }

    // Validate info icon and related text in the side sheet for enhanced package
    private void validateAdditionalCoverageHelpInfoIconSideSheetEnhancedPackage(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome, String roofMaterialCost) throws Exception {
        List<Locator> enhancedCoverageInfoIcons = new ArrayList<>();
        List<String> expectedCoverageHeaderNameInSideSheet = new ArrayList<>();
        List<String> expectedCoverageDescriptionInSideSheet = new ArrayList<>();
        String stateCode = applicantAceHome.getStateCode();
        if (List.of(IA, IN, KS, MD, MN, MT, OH, TN, WA).contains(stateCode)) {
            switch (stateCode) {
                case IA: case IN:
                    enhancedCoverageInfoIcons.addAll(List.of(fenceInfoIcon, carpetLossInfoIcon, buildingOrdinanceInfoIcon));
                    expectedCoverageHeaderNameInSideSheet.addAll(List.of(CoverageInfoDetails.FENCE_COV_HEADER, CoverageInfoDetails.CARPET_COV_HEADER,
                            CoverageInfoDetails.BUILDING_ORDINANCE_COV_HEADER));
                    expectedCoverageDescriptionInSideSheet.addAll(List.of(CoverageInfoDetails.FENCE_COV_DESCRIPTION, CoverageInfoDetails.CARPET_LOSS_COV_DESCRIPTION,
                            CoverageInfoDetails.BUILDING_ORDINANCE_COV_DESCRIPTION));
                    break;
                case TN:
                    enhancedCoverageInfoIcons.addAll(List.of(fenceInfoIcon, buildingOrdinanceInfoIcon, cyberIdentityShieldInfoIcon));
                    expectedCoverageHeaderNameInSideSheet.addAll(List.of(CoverageInfoDetails.FENCE_COV_HEADER, CoverageInfoDetails.BUILDING_ORDINANCE_COV_HEADER,
                            CoverageInfoDetails.CYBER_IDENTITY_COV_HEADER));
                    expectedCoverageDescriptionInSideSheet.addAll(List.of(CoverageInfoDetails.FENCE_COV_DESCRIPTION, CoverageInfoDetails.BUILDING_ORDINANCE_COV_DESCRIPTION,
                            CoverageInfoDetails.CYBER_IDENTITY_COV_DESCRIPTION));
                    break;
                default:
                    enhancedCoverageInfoIcons.addAll(List.of(fenceInfoIcon, carpetLossInfoIcon, buildingOrdinanceInfoIcon, limitedMatchingUndamagedPropertyInfoIcon));
                    expectedCoverageHeaderNameInSideSheet.addAll(List.of(CoverageInfoDetails.FENCE_COV_HEADER, CoverageInfoDetails.CARPET_COV_HEADER,
                            CoverageInfoDetails.BUILDING_ORDINANCE_COV_HEADER, CoverageInfoDetails.LIMITED_MATCHING_UNDAMAGED_PROPERTY_COV_HEADER));
                    expectedCoverageDescriptionInSideSheet.addAll(List.of(CoverageInfoDetails.FENCE_COV_DESCRIPTION, CoverageInfoDetails.CARPET_LOSS_COV_DESCRIPTION,
                            CoverageInfoDetails.BUILDING_ORDINANCE_COV_DESCRIPTION, CoverageInfoDetails.LIMITED_MATCHING_UNDAMAGED_PROPERTY_COV_DESCRIPTION));
                    break;
            }
        } else {
            boolean isSidingAndRoofMaterialsCoverageRequired = !getStateCodeFromAppStore().equals(CA) && isSidingAndRoofMaterialsCoverageRequired(roofMaterialCost);
            boolean expectMineSubsidence = applicantAceHome.isMineSubsidence() && isMineSubsidenceState(stateCode);
            if (applicantAceHome.isTemporaryRentals() && isSidingAndRoofMaterialsCoverageRequired && expectMineSubsidence){
                enhancedCoverageInfoIcons.addAll(List.of(fenceInfoIcon, buildingOrdinanceInfoIcon, sidingRoofMaterialsInfoIcon, cyberIdentityShieldInfoIcon, homeSharingInfoIcon, mineSubsidenceInfoIcon));
                expectedCoverageHeaderNameInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_HEADER_WITH_SIDING_AND_ROOF_HOME_SHARING_MINE.getCoveragesHeaderDescriptionInInfoSideSheet());
                expectedCoverageDescriptionInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION_WITH_SIDING_AND_ROOF_HOME_SHARING_MINE.getCoveragesHeaderDescriptionInInfoSideSheet());
            } else if (applicantAceHome.isTemporaryRentals() && isSidingAndRoofMaterialsCoverageRequired) {
                enhancedCoverageInfoIcons.addAll(List.of(fenceInfoIcon, buildingOrdinanceInfoIcon, sidingRoofMaterialsInfoIcon, cyberIdentityShieldInfoIcon, homeSharingInfoIcon));
                expectedCoverageHeaderNameInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_HEADER_WITH_SIDING_AND_ROOF_HOME_SHARING.getCoveragesHeaderDescriptionInInfoSideSheet());
                expectedCoverageDescriptionInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION_WITH_SIDING_AND_ROOF_HOME_SHARING.getCoveragesHeaderDescriptionInInfoSideSheet());
            } else if(applicantAceHome.isTemporaryRentals() && expectMineSubsidence){
                enhancedCoverageInfoIcons.addAll(List.of(fenceInfoIcon, buildingOrdinanceInfoIcon, cyberIdentityShieldInfoIcon, homeSharingInfoIcon, mineSubsidenceInfoIcon));
                expectedCoverageHeaderNameInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_HEADER_WITH_HOME_SHARING_MINE.getCoveragesHeaderDescriptionInInfoSideSheet());
                expectedCoverageDescriptionInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION_WITH_HOME_SHARING_MINE.getCoveragesHeaderDescriptionInInfoSideSheet());
            } else if(isSidingAndRoofMaterialsCoverageRequired && expectMineSubsidence) {
                enhancedCoverageInfoIcons.addAll(List.of(fenceInfoIcon, buildingOrdinanceInfoIcon, sidingRoofMaterialsInfoIcon, cyberIdentityShieldInfoIcon, mineSubsidenceInfoIcon));
                expectedCoverageHeaderNameInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_HEADER_WITH_SIDING_AND_ROOF_MINE.getCoveragesHeaderDescriptionInInfoSideSheet());
                expectedCoverageDescriptionInSideSheet = ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION_WITH_SIDING_AND_ROOF_MINE.getCoveragesHeaderDescriptionInInfoSideSheet();
            } else if(applicantAceHome.isTemporaryRentals()) {
                enhancedCoverageInfoIcons.addAll(List.of(fenceInfoIcon, buildingOrdinanceInfoIcon, cyberIdentityShieldInfoIcon, homeSharingInfoIcon));
                expectedCoverageHeaderNameInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_HEADER_WITH_HOME_SHARING.getCoveragesHeaderDescriptionInInfoSideSheet());
                expectedCoverageDescriptionInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION_WITH_HOME_SHARING.getCoveragesHeaderDescriptionInInfoSideSheet());
            } else if (isSidingAndRoofMaterialsCoverageRequired) {
                enhancedCoverageInfoIcons.addAll(List.of(fenceInfoIcon, buildingOrdinanceInfoIcon, sidingRoofMaterialsInfoIcon, cyberIdentityShieldInfoIcon));
                expectedCoverageHeaderNameInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_HEADER_WITH_SIDING_AND_ROOF.getCoveragesHeaderDescriptionInInfoSideSheet());
                expectedCoverageDescriptionInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION_WITH_SIDING_AND_ROOF.getCoveragesHeaderDescriptionInInfoSideSheet());
            } else if (expectMineSubsidence) {
                enhancedCoverageInfoIcons.addAll(List.of(fenceInfoIcon, buildingOrdinanceInfoIcon, cyberIdentityShieldInfoIcon, mineSubsidenceInfoIcon));
                expectedCoverageHeaderNameInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_HEADER_WITH_MINE.getCoveragesHeaderDescriptionInInfoSideSheet());
                expectedCoverageDescriptionInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION_WITH_MINE.getCoveragesHeaderDescriptionInInfoSideSheet());
            } else {
                enhancedCoverageInfoIcons.addAll(List.of(fenceInfoIcon, buildingOrdinanceInfoIcon, cyberIdentityShieldInfoIcon));
                expectedCoverageHeaderNameInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_HEADER.getCoveragesHeaderDescriptionInInfoSideSheet());
                expectedCoverageDescriptionInSideSheet.addAll(ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION.getCoveragesHeaderDescriptionInInfoSideSheet());
            }
            if (stateCode.equals(CA)) {
                enhancedCoverageInfoIcons.add(1, carpetLossInfoIcon);
                expectedCoverageHeaderNameInSideSheet.add(1, CoverageInfoDetails.CARPET_COV_HEADER);
                expectedCoverageDescriptionInSideSheet.add(1, CoverageInfoDetails.CARPET_LOSS_COV_DESCRIPTION);
            } else if (stateCode.equals(CT)) {
                enhancedCoverageInfoIcons.add(accessThroughFoundationsAndWallsInfoIcon);
                expectedCoverageHeaderNameInSideSheet.add(ACCESS_THROUGH_FOUNDATION_WALL);
                expectedCoverageDescriptionInSideSheet.add(CoverageInfoDetails.ACCESS_THROUGH_FOUNDATION_WALL_DESCRIPTION);
            }
        }
        //Remove cyberIdentity if appropriate
        if (List.of(AR, AZ, GA, MI, MO, MT, OK, TX).contains(stateCode)) {
            int indexForCyberObject = expectedCoverageHeaderNameInSideSheet.indexOf(CoverageInfoDetails.CYBER_IDENTITY_COV_HEADER);
            if (indexForCyberObject!= NOT_FOUND_IN_LIST) {
                enhancedCoverageInfoIcons.remove(indexForCyberObject);
                expectedCoverageHeaderNameInSideSheet.remove(indexForCyberObject);
                expectedCoverageDescriptionInSideSheet.remove(indexForCyberObject);
            }
        }

        waitAndClickElement(enhancedCoverageInfoIcons.get(0));
        waitElementBeVisible(infoSideSheetHeaderHomeLob);
        List<String> foundCoveragesHeadersInInfoSideSheet = coveragesHeadersInInfoSideSheet.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        String expectedInfoSideSheetHeaderInHomeLob = "Additional coverages";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoSideSheetHeaderHomeLob)), expectedInfoSideSheetHeaderInHomeLob, expectedInfoSideSheetHeaderInHomeLob + " header verification in Home lob coverage info side sheet.");
        clickCloseIconInCoverageInfoSideSheet();


        List<Integer> listOfSizes = new ArrayList<>(Arrays.asList(enhancedCoverageInfoIcons.size(), foundCoveragesHeadersInInfoSideSheet.size(), expectedCoverageHeaderNameInSideSheet.size(), expectedCoverageDescriptionInSideSheet.size()));
        int maxIndex = listOfSizes.stream().min(Integer::compare).get();
        fsa.assertTrue(listOfSizes.stream().allMatch(listOfSizes.get(0)::equals), "Number of Enhanced Package expected additional Coverage Icons, headers and descriptions are the same " + listOfSizes + " found coverages:" + foundCoveragesHeadersInInfoSideSheet + " expected coverages:" + expectedCoverageHeaderNameInSideSheet);
        for (int i = 0; i < maxIndex; i++) {
            Locator coverageInfoIconElement = enhancedCoverageInfoIcons.get(i);
            if (isElementVisible(coverageInfoIconElement, 3)) {
                waitAndClickElement(coverageInfoIconElement);
                fsa.assertEquals(foundCoveragesHeadersInInfoSideSheet.get(i), expectedCoverageHeaderNameInSideSheet.get(i),
                        "Enhanced coverage header verification in coverage info side sheet for " +  foundCoveragesHeadersInInfoSideSheet.get(i) + " - Home lob.");
                waitForUiSettled();
                boolean contentCheckSuccessful = getFoundListOfCoverageDescriptionFromCoverageInfoSideSheet().get(0).contains(expectedCoverageDescriptionInSideSheet.get(i));
                fsa.assertTrue(contentCheckSuccessful, "Enhanced coverage description verification in coverage info side sheet for coverage " +  foundCoveragesHeadersInInfoSideSheet.get(i) + " - Home lob.");
                if (!contentCheckSuccessful) {
                    Log.warn("Description expected: " + expectedCoverageDescriptionInSideSheet.get(i));
                    Log.warn("Description found: " + getFoundListOfCoverageDescriptionFromCoverageInfoSideSheet().get(0));
                }
                clickCloseIconInCoverageInfoSideSheet();
            } else {
                fsa.assertTrue(false, "Expecting to find " + expectedCoverageHeaderNameInSideSheet.get(i) + " coverage in page");
            }
        }
    }

    private void clickCloseIconInCoverageInfoSideSheet(){
        waitAndClickElement(closeIconInCoverageInfoSideSheetHomeLob);
    }

    private List<String> getFoundListOfCoverageDescriptionFromCoverageInfoSideSheet(){
        return coveragesDescriptionsInInfoSideSheet.all().stream().map(this::getTextFromElement).filter(i -> !i.isEmpty()).collect(Collectors.toList());
    }

    // decide if the siding roof material coverage is required or not in the package
    private boolean isSidingAndRoofMaterialsCoverageRequired(String roofMaterialCoverageLimit) throws Exception {
        AppStore.Home appStore = getSessionStorageAppStore().getHome();
        PropertyDetailsForm propertyDetailsForm =  appStore.getPropertyDetailsForm();
        String exteriorWallFinish = propertyDetailsForm.getFieldValueByName("exteriorWallFinish");
        String roofType = propertyDetailsForm.getFieldValueByName("roofCover");
        boolean isSidingAndRoofMaterialsCoverageRequired = false;
        if(roofMaterialCoverageLimit.equals(REPLACEMENT_COST)){
            isSidingAndRoofMaterialsCoverageRequired = CERTAIN_EXTERIOR_WALL_TYPE_FOR_SIDING_AND_ROOF_MATERIAL.contains(exteriorWallFinish) ||
                    CERTAIN_ROOF_TYPE_FOR_SIDING_AND_ROOF_MATERIAL.contains(roofType);
        }
        return isSidingAndRoofMaterialsCoverageRequired;
    }

    public List<String> getFoundPrimaryCoverageNames() {
        return primaryCoverageNames.all().stream()
                .map(this::getTextFromElement)
                .filter(name -> !name.contains("mos"))
                .filter(name -> !name.isBlank())
                .map(name -> name.replaceFirst("Coverage\\s*", EMPTY_STRING))
                .collect(Collectors.toList());
    }

    public List<String> getFoundPrimaryCoverageAmount(){
        List<String> listOfCoverageAmountsFoundInPage = primaryCoverageAmount.all().stream()
                .map(this::getTextFromElement)
                .map(text -> text.replaceFirst("Limit\\s*", EMPTY_STRING))
                .filter(s -> s.matches(".*[0-9$,.].*")).collect(Collectors.toList());
        for (int index=0; index<listOfCoverageAmountsFoundInPage.size(); index++) {
            String amount = listOfCoverageAmountsFoundInPage.get(index);
            if (amount.contains("(")) {
                listOfCoverageAmountsFoundInPage.remove(amount);
                amount = amount.substring(0, amount.indexOf("(")).strip();
                listOfCoverageAmountsFoundInPage.add(index, amount);
            }
            if (amount.contains("+")) {
                StringTokenizer st = new StringTokenizer(amount, "+");
                listOfCoverageAmountsFoundInPage.remove(amount);
                for (int i = 0; st.hasMoreTokens(); i++) {
                    listOfCoverageAmountsFoundInPage.add(index+i, st.nextToken().strip());
                }
            }
        }
        return listOfCoverageAmountsFoundInPage;
    }

    public String getCoverageAmountByName(String coverage) throws Exception {
        String COVERAGE_AMOUNT_XPATH = "//div[contains(text(), '" + coverage + "')]/../../div[contains(@class,'coverage-amount')]";
        return getTextFromElement(locator(pwXPath(COVERAGE_AMOUNT_XPATH))).replace("Limit", EMPTY_STRING).strip();
    }

    public String getPrimaryCoverageFullDescriptionByName(String coverage) throws Exception {
        String COVERAGE_DESCRIPTION_XPATH = "//div[contains(@class,'coverage-description')][div[contains(text(),'" + coverage + "')]]";
        return getTextFromElement(locator(pwXPath(COVERAGE_DESCRIPTION_XPATH))).replace("Coverage", EMPTY_STRING).strip();
    }

    public boolean isPolicyExclusionPopUpDisplayed() {
        int maxRetries = 2;
        int retries = 0;
        while (retries < maxRetries) {
            if (isElementDisplayed(windHailExclusionPopupTitle, Property.PAGELOADTIMEOUT)) {
                return true;
            } else if (isElementDisplayed(tryAgainButton, 3)) {
                waitAndClickElement(tryAgainButton);
                retries++;
            } else {
                Log.info("Neither Try Again button nor Wind/Hail Exclusion Pop-up is displayed.");
                break;
            }
        }
        if (isElementDisplayed(windHailExclusionPopupTitle, Property.PAGELOADTIMEOUT)){
            return true;
        }
        Log.info("Wind/Hail Exclusion Pop-up is not displayed.");
        return false;
    }

    public void validateWindHailExclusionPopUpAndCoverages(FarmersSoftAssert fsa, String stateCode) throws Exception {
        validatePolicyExclusionPopupContent(fsa, stateCode);
        Assert.assertTrue(isOnReviewQuotePageHome(true), "Did not reach Review Quote page after retrieval");
        validateContentOfPolicyDeductibleSection(fsa, stateCode);
        clickAllPerilsInfoIcon();
        validateContentOfPolicyExclusionOnDeductibleInfoSideSheet(fsa, stateCode);
        clickWindAndHailInfoIcon();
        validateContentOfPolicyExclusionOnDeductibleInfoSideSheet(fsa, stateCode);
        clickHurricaneInfoIcon();
        validateContentOfPolicyExclusionOnDeductibleInfoSideSheet(fsa, stateCode);
        validateCoverageAndAmountOnReviewQuotePage(fsa, ROOF_MATERIALS, PRIMARY, REPLACEMENT_COST);
        if (isAllPackagesDisplayedOnReviewQuotePage()) {
            clickOnStandardPackage();
            validateCoverageAndAmountOnReviewQuotePage(fsa, ROOF_MATERIALS, PRIMARY, REPLACEMENT_COST);
            clickOnPremierPackage();
            validateCoverageAndAmountOnReviewQuotePage(fsa, ROOF_MATERIALS, PRIMARY, REPLACEMENT_COST);
            validateCoverageAndAmountOnReviewQuotePage(fsa, MARRING_TO_CERTAIN_METAL_MATERIALS, ADDITIONAL, OFF);
            List<String> foundSupplementalCoveragesNames = getFoundSupplementalCoveragesNames(stateCode);
            fsa.assertFalse(foundSupplementalCoveragesNames.contains(FORTIFIED_ROOF_UPGRADE), "Premier package contains Fortified Roof Upgrade supplemental coverage.");
        }
    }

    public void validateCoverageAndAmountOnReviewQuotePage(FarmersSoftAssert fsa, String coverageName, String coverageType, String expectedAmount) throws Exception {
        String coverageVal = getCoverageAmountByName(coverageName);
        fsa.assertEquals(coverageVal, expectedAmount, coverageType + " coverage amount verification for " + coverageName + ".");
    }

    public String getCoverageAmountByNameAndType(String coverageName, String coverageType) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        AppStore.Home.Quote quote = appStore.getHome().getQuote();
        String selectedPackageCode = quote.getSelectedPackageCode();
        String selectedPaymentMode = quote.getSelectedPaymentMode();
        Coverage coverage = appStore.getHome().getCoverageForPackage(selectedPackageCode, selectedPaymentMode);
        List<String> listOfCoverageAmountsForSelectedPackageAndPaymentMode = coverage.getCvgInfo().stream().filter(i -> i.getCvgSection().equals(coverageType) && i.getCvgDesc().equals(coverageName))
                .map(AppStore.Home.CvgInfo::getCvgAmt).collect(Collectors.toList());
        return listOfCoverageAmountsForSelectedPackageAndPaymentMode.isEmpty()? EMPTY_STRING : listOfCoverageAmountsForSelectedPackageAndPaymentMode.get(0);
    }

    public List<String> getExpectedStandardPrimaryCoverageNames(String stateCode) throws Exception {
        switch(stateCode) {
            case AR: case IA: case IL: case IN: case MD: case MO: case MN: case MT: case NE:
                return CoveragesNameAceHome.STANDARD_PRIMARY_PERSONAL_PROP_WITH_ACV_BROAD_NAMED_PERILS.getCoverages();
            case CT:
                return CoveragesNameAceHome.STANDARD_PRIMARY_PERSONAL_PROP_WITH_ACV_BROAD_NAMED_PERILS_LOSS_OF_USE.getCoverages();
            case KS:
                return CoveragesNameAceHome.STANDARD_PRIMARY_WITH_BROAD_PERILS_GUEST_MEDICAL.getCoverages();
            case VA:
                return CoveragesNameAceHome.STANDARD_PRIMARY_PERSONAL_PROP_WITH_RCV.getCoverages();
            default:
                if(isNamedPerilsState(stateCode)) {
                    return CoveragesNameAceHome.STANDARD_PRIMARY_WITH_BROAD_PERILS.getCoverages();
                } else {
                    return CoveragesNameAceHome.STANDARD_PRIMARY.getCoverages();
                }
        }
    }

    public List<String> getExpectedEnhancedPrimaryCoverageNames(String stateCode) throws Exception {
        switch(stateCode) {
            case AL: case AR: case AZ: case CT: case GA: case IA: case ID: case IL: case IN: case MD: case MI: case MN: case MO: case MT:
            case NE: case NM: case OH: case OR: case SD: case TN: case TX: case UT: case WA: case WI: case WY:
                return CoveragesNameAceHome.ENHANCED_PRIMARY_WITH_BROAD_PERILS.getCoverages();
            case CA: case OK: case PA:
                return CoveragesNameAceHome.ENHANCED_PRIMARY_ADDITIONAL_LIVING_EXPENSE.getCoverages();
            case CO:
                return CoveragesNameAceHome.ENHANCED_PRIMARY_NO_ROOF.getCoverages();
            case KS:
                return CoveragesNameAceHome.ENHANCED_PRIMARY_WITH_BROAD_PERILS_GUEST_MEDICAL.getCoverages();
            case VA:
                return CoveragesNameAceHome.ENHANCED_PRIMARY_LOSS_OF_USE.getCoverages();
            default:
                return CoveragesNameAceHome.ENHANCED_PRIMARY.getCoverages();
        }
    }

    public List<String> getExpectedPremierPrimaryCoverageNames(String stateCode) throws Exception {
        switch(stateCode) {
            case AL: case AR: case AZ: case CT: case GA: case IA: case ID: case IL: case IN: case MD: case MI: case MO: case MN: case MT:
            case NE: case NM: case OH: case OR: case PA: case SD: case TN: case TX: case UT: case WA: case WI: case WY:
                return CoveragesNameAceHome.PREMIER_PRIMARY_WITH_OPEN_PERILS.getCoverages();
            case KS:
                return CoveragesNameAceHome.PREMIER_PRIMARY_WITH_OPEN_PERILS_GUEST_MEDICAL.getCoverages();
            case VA:
                return CoveragesNameAceHome.PREMIER_PRIMARY_LOSS_OF_USE.getCoverages();
            default:
                return CoveragesNameAceHome.PREMIER_PRIMARY.getCoverages();
        }
    }

    public List<String> getFoundSupplementalCoveragesNames(String stateCode){
        List<Locator> listOfCoverageNames = stateCode.equals(WI) ? supplementalCoverageNamesOptional.all() : supplementalCoverageNames.all();
        return listOfCoverageNames.stream().map(this::getTextFromElement)
                .filter(text -> !text.isEmpty())
                .collect(Collectors.toList());
    }

    public List<String> getFoundSupplementalCoveragesAmount(String stateCode) {
        List<Locator> listOfCoverageAmounts = stateCode.equals(WI) ? supplementalCoverageAmountOptional.all() : supplementalCoverageAmount.all();
        return listOfCoverageAmounts.stream().map(this::getTextFromElement)
                .filter(amount -> !amount.isEmpty())
                .collect(Collectors.toList());
    }

    List<String> getExpectedSupplementalCoverageAmountStandardPkg(Coverage coverage) throws Exception {
        String stateCode = getStateCodeFromSessionStorage();
        AppStore appStore = getSessionStorageAppStore();
        String coverageSection = getCoverageSectionDescriptionForSupplementalCoverage();
        List<String> expectedCvgAmtSupplementalForStandardPkg = coverage.getCvgInfo().stream().filter(i -> i.getCvgSection().equals(coverageSection)).map(AppStore.Home.CvgInfo::getCvgAmt).collect(Collectors.toList());

        if (List.of(CA, CT, MN, MT).contains(stateCode)){
            String valueToSet;
            int dwellingCoverageValue = getDwellingCoverageInInt(appStore);
            int numberOfExpectedAmounts = expectedCvgAmtSupplementalForStandardPkg.size();
            for (int i = 0; i < numberOfExpectedAmounts; i++){
                if(expectedCvgAmtSupplementalForStandardPkg.get(i).contains("%")){
                    int multiplier = Integer.parseInt(expectedCvgAmtSupplementalForStandardPkg.get(i).replace("%", EMPTY_STRING));
                    valueToSet = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf((multiplier*dwellingCoverageValue)/100));
                    expectedCvgAmtSupplementalForStandardPkg.set(i, valueToSet);
                }
            }
        }
        return expectedCvgAmtSupplementalForStandardPkg;
    }

    List<String> getFoundSpecialLimitCoveragesNames(){
        showOrHideSpecialLimitsSection(true);
        wait.until(Conditions.numberOfElementsToBeMoreThan(pwXPath("//div[contains(text(), 'Special limits (Personal property)')]//following-sibling::div//div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-description')]"), 1));
        return specialLimitCoverageNames.all().stream().map(i -> getTextFromElement(i)).collect(Collectors.toList());
    }

    List<String> getExpectedSpecialLimitCoveragesNamesStandardPkg(){
        return CoveragesNameAceHome.STANDARD_SPECIAL_LIMIT.getCoverages();
    }

    List<String> getExpectedSpecialLimitCoveragesNamesEnhancedPkg(){
        return CoveragesNameAceHome.ENHANCED_SPECIAL_LIMIT.getCoverages();
    }

    List<String> getExpectedSpecialLimitCoveragesNamesPremierPkg(){
        return CoveragesNameAceHome.PREMIER_SPECIAL_LIMIT.getCoverages();
    }

    List<String> getFoundSpecialLimitCoveragesAmount(){
        wait.until(Conditions.numberOfElementsToBeMoreThan(pwXPath("//div[contains(text(), 'Special limits (Personal property)')]//following-sibling::div//div[contains(@class,'coverage-item-container')]//div[contains(@class,'coverage-amount')]"), 1));
        return specialLimitCoverageAmount.all().stream().map(i -> getTextFromElement(i)).collect(Collectors.toList());
    }

    public List<String> getExpectedCvgAmtPrimaryWithPercentOnlyStandardPkg(Coverage coverage, int dwellingCoverageValue, String stateCode){
        List<String> expectedCvgAmtPrimaryWithPercentOnlyStandardPkg = coverage.getCvgInfo().stream().filter(i -> i.getCvgSection().equals("Primary"))
                .map(AppStore.Home.CvgInfo::getCvgAmt).filter(s -> s.matches(".*[0-9%].*")).filter(s -> !s.matches(".*\\s.*")).collect(Collectors.toList());

        String valueToSet;
        int numberOfExpectedCoveragePercentageAmounts = expectedCvgAmtPrimaryWithPercentOnlyStandardPkg.size();
        for (int i = 0; i < numberOfExpectedCoveragePercentageAmounts; i++){
            if(expectedCvgAmtPrimaryWithPercentOnlyStandardPkg.get(i).contains("%")){
                int multiplier = Integer.parseInt(expectedCvgAmtPrimaryWithPercentOnlyStandardPkg.get(i).replace("%", EMPTY_STRING));
                valueToSet = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf((multiplier*dwellingCoverageValue)/100));
                expectedCvgAmtPrimaryWithPercentOnlyStandardPkg.set(i, valueToSet);
            }
        }
        return expectedCvgAmtPrimaryWithPercentOnlyStandardPkg;
    }

    List<String> getFoundPrimaryCoverageAmountStandardPkg(String stateCode){
        List<String> foundPrimaryCoveragesAmount = getFoundPrimaryCoverageAmount();
        List<String> foundPrimaryCoverageNames = getFoundPrimaryCoverageNames();
        if(!stateCode.equals(VA)){
            int indexOfLossOfUseCoverage1 = foundPrimaryCoverageNames.indexOf(LOSS_OF_USE);
            int indexOfLossOfUseCoverage2 = foundPrimaryCoverageNames.indexOf(LOSS_OF_USE_TEXT);
            int indexOfLossOfUseCoverage = indexOfLossOfUseCoverage1 != NOT_FOUND_IN_LIST ? indexOfLossOfUseCoverage1 : indexOfLossOfUseCoverage2;
            if ((indexOfLossOfUseCoverage == NOT_FOUND_IN_LIST)) {
                Log.warn("getFoundPrimaryCoverageNames().indexOf(LOSS_OF_USE) = not found");
            } else {
                indexOfLossOfUseCoverage -= 1;
                String[] splitLossOfUseAmountToDollarValue = foundPrimaryCoveragesAmount.get(indexOfLossOfUseCoverage).split(SPACE);
                foundPrimaryCoveragesAmount.set(indexOfLossOfUseCoverage, splitLossOfUseAmountToDollarValue[0]);
            }
        }
        return foundPrimaryCoveragesAmount;
    }

    List<String> getExpectedSupplementalCoverageNamesStandardPkg(ApplicantAceHome applicantAceHome) {
        boolean expectMineSubsidence = applicantAceHome.isMineSubsidence() && isMineSubsidenceState(applicantAceHome.getStateCode());

        List<String> expectedSupplementalCoverageNames;
        if (applicantAceHome.isTemporaryRentals() && expectMineSubsidence){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.STANDARD_SUPPLEMENTAL_WITH_HOME_SHARING_MINE.getCoverages();
        }else if(applicantAceHome.isTemporaryRentals()){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.STANDARD_SUPPLEMENTAL_WITH_HOME_SHARING.getCoverages();
        }else if(expectMineSubsidence){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.STANDARD_SUPPLEMENTAL_WITH_MINE.getCoverages();
        }else{
            expectedSupplementalCoverageNames = CoveragesNameAceHome.STANDARD_SUPPLEMENTAL.getCoverages();
        }

        List<String> expectedSupplementalCoverageNamesUpdated = new ArrayList<>(expectedSupplementalCoverageNames);
        String stateCode = applicantAceHome.getStateCode();
        switch(stateCode) {
            case CT:
                expectedSupplementalCoverageNamesUpdated.addAll(Arrays.asList(BUILDING_ORDINANCE_OR_LAW, ACCESS_THROUGH_FOUNDATION_WALL));
                break;
        }
//		case IA: case IN: case MD: case OH: case WA:
//			expectedSupplementalCoverageNamesUpdated.fill("");
//			expectedSupplementalCoverageNamesUpdated.addAll(List.of(FENCE_LOSS_SETTLEMENT, CARPET_LOSS_SETTLEMENT));
//			break;
//		case KS:
//			expectedSupplementalCoverageNamesUpdated.fill("");
//			expectedSupplementalCoverageNamesUpdated.addAll(List.of("Fences", "Carpet(loss settlement)"));
//			break;
//		case MN: case MT:
//			expectedSupplementalCoverageNamesUpdated.fill("");
//			expectedSupplementalCoverageNamesUpdated.addAll(Arrays.asList(FENCE_LOSS_SETTLEMENT, CARPET_LOSS_SETTLEMENT, BUILDING_ORDINANCE_OR_LAW));
//			break;
//		case VA:
//			expectedSupplementalCoverageNamesUpdated.add(ACCESS_THROUGH_FOUNDATION_WALL);
//			break;
//		case WY:
//			expectedSupplementalCoverageNamesUpdated.add(MARRING_TO_CERTAIN_METAL_MATERIALS);
//			break;
//		}
        return expectedSupplementalCoverageNamesUpdated;
    }

    List<String> getExpectedSpecialLimitCvgAmountStandardPkg(AppStore appStore, String personalPropertyValueFromPrimaryCoverage, int indexOfPersonalPropertyAtSecondaryResidence){
        List<String> expectedSpecialLimitCvgAmount = appStore.getStaticContent().getHome().getReviewQuote().getSpecialLimits().getStandard().stream().map(AppStore.StaticContent.Home.ReviewQuote.SpecialLimits.Standard::getValue).collect(Collectors.toList());
        int personalPropertyValue = Integer.parseInt(personalPropertyValueFromPrimaryCoverage.replaceAll("[$,]",EMPTY_STRING));
        int multiplier = Integer.parseInt(expectedSpecialLimitCvgAmount.get(0).replace("%", EMPTY_STRING));
        String valueToSet = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf((multiplier*personalPropertyValue)/100));
        expectedSpecialLimitCvgAmount.set(indexOfPersonalPropertyAtSecondaryResidence, valueToSet);
        return expectedSpecialLimitCvgAmount;
    }

    List<String> getExpectedCvgAmtPrimaryWithPercentOnlyEnhancedPkg(Coverage coverage, int dwellingCoverageValue, String stateCode) throws Exception {
        List<String> expectedCvgAmtPrimaryWithPercentOnly = coverage.getCvgInfo().stream().filter(i -> i.getCvgSection().equals("Primary"))
                .map(AppStore.Home.CvgInfo::getCvgAmt).filter(s -> s.matches(".*[0-9%].*")).filter(s -> !s.matches(".*\\s.*")).collect(Collectors.toList());
        String valueToSet;
        int numberOfExpectedAmountsWithPctOnly = expectedCvgAmtPrimaryWithPercentOnly.size();
        for (int i = 0; i < numberOfExpectedAmountsWithPctOnly; i++){
            if(expectedCvgAmtPrimaryWithPercentOnly.get(i).contains("%")){
                int multiplier = Integer.parseInt(expectedCvgAmtPrimaryWithPercentOnly.get(i).replace("%", EMPTY_STRING));
                valueToSet = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf((multiplier*dwellingCoverageValue)/100));
                expectedCvgAmtPrimaryWithPercentOnly.set(i, valueToSet);
            }
        }
        List<String> listOfPrimaryCoverageNamesEnhancedPkg = getExpectedEnhancedPrimaryCoverageNames(stateCode);
        int indexOfDwellingCoverageName;
        if (stateCode.equals(AR)) {
            indexOfDwellingCoverageName = listOfPrimaryCoverageNamesEnhancedPkg.indexOf(DWELLING);
        } else if(stateCode.equals(CO)){
            indexOfDwellingCoverageName = listOfPrimaryCoverageNamesEnhancedPkg.indexOf(DWELLING_COV_25_PER_OF_REPLACEMENT_COST);
        } else {
            indexOfDwellingCoverageName = listOfPrimaryCoverageNamesEnhancedPkg.indexOf(DWELLING_COV_10_PER_OF_REPLACEMENT_COST);
        }

        int indexOfSeparateStructureCoverageName = listOfPrimaryCoverageNamesEnhancedPkg.indexOf(SEPARATE_STRUCTURES);
        if (indexOfSeparateStructureCoverageName == NOT_FOUND_IN_LIST || indexOfDwellingCoverageName == NOT_FOUND_IN_LIST) {
            Log.warn("indexOfSeparateStructureCoverageName= " + indexOfSeparateStructureCoverageName + " indexOfDwellingCoverageName= " + indexOfDwellingCoverageName);
        } else {
            expectedCvgAmtPrimaryWithPercentOnly.add(indexOfDwellingCoverageName + 1, expectedCvgAmtPrimaryWithPercentOnly.get(indexOfSeparateStructureCoverageName));
            expectedCvgAmtPrimaryWithPercentOnly.remove(indexOfSeparateStructureCoverageName+1);
        }
        return expectedCvgAmtPrimaryWithPercentOnly;
    }

    List<String> getExpectedSupplementalCoverageNamesEnhancedPkg(ApplicantAceHome applicantAceHome) throws Exception {
        String stateCode = applicantAceHome.getStateCode();
        List<String> expectedSupplementalCoverageNames;
        boolean isSidingAndRoofMaterialsCoverageRequired = !List.of(CA, GA).contains(stateCode) && isSidingAndRoofMaterialsCoverageRequired(getCoverageAmountByNameAndType(ROOF_MATERIALS, PRIMARY));
        boolean expectMineSubsidence = applicantAceHome.isMineSubsidence() && isMineSubsidenceState(applicantAceHome.getStateCode());
        if(applicantAceHome.isTemporaryRentals() && isSidingAndRoofMaterialsCoverageRequired && expectMineSubsidence){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.ENHANCED_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_HOME_SHARING_MINE.getCoverages();
        }else if(applicantAceHome.isTemporaryRentals() && isSidingAndRoofMaterialsCoverageRequired){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.ENHANCED_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_HOME_SHARING.getCoverages();
        }else if(applicantAceHome.isTemporaryRentals() && expectMineSubsidence){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.ENHANCED_SUPPLEMENTAL_WITH_HOME_SHARING_MINE.getCoverages();
        }else if(isSidingAndRoofMaterialsCoverageRequired && expectMineSubsidence){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.ENHANCED_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_MINE.getCoverages();
        }else if(applicantAceHome.isTemporaryRentals()){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.ENHANCED_SUPPLEMENTAL_WITH_HOME_SHARING.getCoverages();
        }else if(isSidingAndRoofMaterialsCoverageRequired){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.ENHANCED_SUPPLEMENTAL_WITH_SIDING_AND_ROOF.getCoverages();
        }else if(expectMineSubsidence){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.ENHANCED_SUPPLEMENTAL_WITH_MINE.getCoverages();
        }else{
            expectedSupplementalCoverageNames = CoveragesNameAceHome.ENHANCED_SUPPLEMENTAL.getCoverages();
        }

        List<String> expectedSupplementalCoverageNamesWithUpdates = new ArrayList<>(expectedSupplementalCoverageNames);
        switch (stateCode) {
//		case ID: case NE: case NM: case WI:
//			expectedSupplementalCoverageNamesWithUpdates = CoveragesNameAceHome.ENHANCED_SUPPLEMENTAL_WITH_SIDING_AND_ROOF.getCoverages();
//			break;
//		case AR: case MI: case TX: case UT: // US897162 - Optimization: Enhanced and premier package changes - MI || For AR, TX, UT and TN please refer to serial no 145, 146, 147 in Home Regression sheet.
//			expectedSupplementalCoverageNamesWithUpdates.removeAll(Arrays.asList(LIMITED_MATCHING_COVERAGE_SIDING_AND_ROOF, CYBER_IDENTITY_SHIELD));
//			break;
//		case AZ: case GA: case MO: case OR: case PA: case TN:
//			expectedSupplementalCoverageNamesWithUpdates.remove(CYBER_IDENTITY_SHIELD);
//			break;
            case CA:
                expectedSupplementalCoverageNamesWithUpdates.add(1, CARPET_LOSS_SETTLEMENT);
                break;
            case CO:
                expectedSupplementalCoverageNamesWithUpdates.add(0, ROOF_MATERIALS);
                expectedSupplementalCoverageNamesWithUpdates.removeAll(Arrays.asList(BUILDING_ORDINANCE_OR_LAW, CYBER_IDENTITY_SHIELD));
                break;
            case CT:
                expectedSupplementalCoverageNamesWithUpdates.add(ACCESS_THROUGH_FOUNDATION_WALL);
                break;
            case GA:
                expectedSupplementalCoverageNamesWithUpdates.remove(CYBER_IDENTITY_SHIELD);
                break;
//		case IA: case IN: case MD: case MN: case MT: case OH: case WA:
//			expectedSupplementalCoverageNamesWithUpdates.fill("");
//			expectedSupplementalCoverageNamesWithUpdates.addAll(List.of(FENCE_LOSS_SETTLEMENT, CARPET_LOSS_SETTLEMENT, BUILDING_ORDINANCE_OR_LAW, LIMITED_MATCHING_UNDAMAGED_PROPERTY));
//			if (stateCode.equals(IN)) {
//				expectedSupplementalCoverageNames.remove(LIMITED_MATCHING_UNDAMAGED_PROPERTY);
//			}
//			break;
//		case KS:
//			expectedSupplementalCoverageNamesWithUpdates.fill("");
//			expectedSupplementalCoverageNamesWithUpdates.addAll(List.of("Fences", "Building ordinance", LIMITED_MATCHING_COVERAGE_SIDING_AND_ROOF, "Carpet(loss settlement)"));
//			break;
//		case OK:
//			expectedSupplementalCoverageNamesWithUpdates.fill("");
//			expectedSupplementalCoverageNamesWithUpdates.addAll(CoveragesNameAceHome.ENHANCED_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_HOME_SHARING_NO_CYBER.getCoverages());
//			if (!applicantAceHome.isTemporaryRentals()) {
//				expectedSupplementalCoverageNamesWithUpdates.remove(HOME_SHARING_BUSINESS);
//			}
//			break;
//		case VA:
//			expectedSupplementalCoverageNamesWithUpdates = CoveragesNameAceHome.ENHANCED_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_ACCESS_THROUGH_WALL.getCoverages();
//			break;
//		case WY:
//			expectedSupplementalCoverageNamesWithUpdates = CoveragesNameAceHome.ENHANCED_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_MARRING.getCoverages();
//			break;
        }
        return expectedSupplementalCoverageNamesWithUpdates;
    }

    List<String> getExpectedSupplementalCoverageAmountEnhancedPkg(Coverage coverage, int dwellingCoverageValue) throws Exception {
        String coverageSection = getCoverageSectionDescriptionForSupplementalCoverage();
        List<String> expectedSupplementalCoverageAmount = coverage.getCvgInfo().stream().filter(i -> i.getCvgSection().equals(coverageSection)).map(AppStore.Home.CvgInfo::getCvgAmt).collect(Collectors.toList());

        int index = expectedSupplementalCoverageAmount.indexOf("10%");
        if (index != NOT_FOUND_IN_LIST) {
            int multiplier = Integer.parseInt(expectedSupplementalCoverageAmount.get(index).replace("%", EMPTY_STRING));
            String buildingOrdinanceValue = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf((multiplier*dwellingCoverageValue)/100));
            expectedSupplementalCoverageAmount.set(index, buildingOrdinanceValue);
        }
        return expectedSupplementalCoverageAmount;
    }

    private String getCoverageSectionDescriptionForSupplementalCoverage() throws Exception {
        String coverageSection;
        switch (getStateCodeFromSessionStorage()) {
            case WI:
                coverageSection = "Optional";
                break;
            default:
                coverageSection = "Additional";
                break;
        }
        return coverageSection;
    }

    List<String> getExpectedSpecialLimitCvgAmountEnhancedPkg(AppStore appStore, int personalPropertyValue) {
        List<String> expectedSpecialLimitCvgAmount = appStore.getStaticContent().getHome().getReviewQuote().getSpecialLimits().getEnhanced().stream().map(AppStore.StaticContent.Home.ReviewQuote.SpecialLimits.Enhanced::getValue).collect(Collectors.toList());
        int multiplier = Integer.parseInt(expectedSpecialLimitCvgAmount.get(0).replace("%", EMPTY_STRING));
        double value = (multiplier*personalPropertyValue)/100.0;
        int finalValue = (int)Math.ceil(value);
        String valueToSet = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(finalValue));
        expectedSpecialLimitCvgAmount.set(0, valueToSet);
        return expectedSpecialLimitCvgAmount;
    }

    List<String> getExpectedCvgAmtPrimaryWithPercentOnlyPremierPkg(Coverage coverage, AppStore appStore, String stateCode) throws Exception {
        List<String> expectedCvgAmtPrimaryWithPercentOnly = coverage.getCvgInfo().stream().filter(i -> i.getCvgSection().equals("Primary"))
                .map(AppStore.Home.CvgInfo::getCvgAmt).filter(s -> s.matches(".*[0-9%].*")).filter(s -> !s.matches(".*\\s.*")).collect(Collectors.toList());
        int dwellingCoverageValue = getDwellingCoverageInInt(appStore);
        String valueToSet;
        int numberOfExpectedAmountsWithPctOnly = expectedCvgAmtPrimaryWithPercentOnly.size();
        for (int i = 0; i < numberOfExpectedAmountsWithPctOnly; i++) {
            if(expectedCvgAmtPrimaryWithPercentOnly.get(i).contains("%")){
                int multiplier = Integer.parseInt(expectedCvgAmtPrimaryWithPercentOnly.get(i).replace("%", EMPTY_STRING));
                valueToSet = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf((multiplier*dwellingCoverageValue)/100));
                expectedCvgAmtPrimaryWithPercentOnly.set(i, valueToSet);
            }
        }
        return expectedCvgAmtPrimaryWithPercentOnly;
    }

    List<String> getExpectedSupplementalCoverageNamesPremierPkg(AppStore appStore, ApplicantAceHome applicantAceHome, List<String> expectedCvgAmtPrimaryWithPercentOnly) throws Exception {
        List<String> expectedSupplementalCoverageNames;
        String stateCode = applicantAceHome.getStateCode();
        String roofMaterialCoverageLimit = getCoverageAmountByNameAndType(ROOF_MATERIALS, PRIMARY);
        boolean isSidingAndRoofMaterialsCoverageRequired = isSidingAndRoofMaterialsCoverageRequired(roofMaterialCoverageLimit);
        String roofType = appStore.getHome().getPropertyDetailsForm().getFieldValueByName("roofCover");
        boolean isFortifiedRoofCoverageRequired = !stateCode.equals(GA) && (CERTAIN_ROOF_TYPE_FOR_SIDING_AND_ROOF_MATERIAL.contains(roofType) || roofMaterialCoverageLimit.equals(REPLACEMENT_COST))
                && applicantAceHome.getFortifiedHome().isEmpty();
        boolean expectMineSubsidence = applicantAceHome.isMineSubsidence() && isMineSubsidenceState(applicantAceHome.getStateCode());

        if(applicantAceHome.isTemporaryRentals() && isSidingAndRoofMaterialsCoverageRequired
                && expectMineSubsidence && isFortifiedRoofCoverageRequired){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_HOME_SHARING_FORTIFIED_ROOF_MINE.getCoverages();
        } else if(applicantAceHome.isTemporaryRentals() && isSidingAndRoofMaterialsCoverageRequired && expectMineSubsidence){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_HOME_SHARING_MINE.getCoverages();
        } else if(applicantAceHome.isTemporaryRentals() && isSidingAndRoofMaterialsCoverageRequired && applicantAceHome.getFortifiedHome().isEmpty()){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_FORTIFIED_ROOF_HOME_SHARING.getCoverages();
        } else if(isSidingAndRoofMaterialsCoverageRequired && applicantAceHome.getFortifiedHome().isEmpty() && expectMineSubsidence){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_FORTIFIED_ROOF_MINE.getCoverages();
        } else if(applicantAceHome.isTemporaryRentals() && expectMineSubsidence && applicantAceHome.getFortifiedHome().isEmpty()){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_HOME_SHARING_FORTIFIED_ROOF_MINE.getCoverages();
        } else if(applicantAceHome.isTemporaryRentals() && expectMineSubsidence){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_HOME_SHARING_AND_MINE.getCoverages();
        } else if(isSidingAndRoofMaterialsCoverageRequired && expectMineSubsidence){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_MINE.getCoverages();
        } else if(applicantAceHome.isTemporaryRentals() && isSidingAndRoofMaterialsCoverageRequired){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_HOME_SHARING.getCoverages();
        } else if(applicantAceHome.isTemporaryRentals() && isFortifiedRoofCoverageRequired){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_HOME_SHARING_FORTIFIED_ROOF.getCoverages();
        } else if(isSidingAndRoofMaterialsCoverageRequired && isFortifiedRoofCoverageRequired){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_FORTIFIED_ROOF.getCoverages();
        } else if(expectMineSubsidence && isFortifiedRoofCoverageRequired){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_FORTIFIED_ROOF_MINE.getCoverages();
        } else if(applicantAceHome.isTemporaryRentals()){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_HOME_SHARING.getCoverages();
        } else if(isSidingAndRoofMaterialsCoverageRequired){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_SIDING_AND_ROOF.getCoverages();
        } else if(expectMineSubsidence){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_MINE.getCoverages();
        } else if(!applicantAceHome.getFortifiedHome().isEmpty()){
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_FORTIFIED_ROOF.getCoverages();
        } else{
            expectedSupplementalCoverageNames = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL.getCoverages();
        }
        List<String> expectedSupplementalCoverageNamesUpdated = new ArrayList<>(expectedSupplementalCoverageNames);
//		boolean isWindHailExclusionSelected = getSessionStorageAppStore().getControlData().isWindHailExclusionSelected();
        switch (stateCode) {
            case CT:
                expectedSupplementalCoverageNamesUpdated.remove(MARRING_TO_CERTAIN_METAL_MATERIALS);
                break;
//		case AR:
//			expectedSupplementalCoverageNamesUpdated = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_SIDING_AND_ROOF.getCoverages();
//			break;
//		case AZ: case TX: case UT: case WY:
//			expectedSupplementalCoverageNamesUpdated = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_HOME_SHARING.getCoverages();
//			if (stateCode.equals(TX) && isWindHailExclusionSelected){
//				expectedSupplementalCoverageNamesUpdated.remove(FORTIFIED_ROOF_UPGRADE);
//			}
//			break;
//		case GA:
//			expectedSupplementalCoverageNamesUpdated.fill("");
//			expectedSupplementalCoverageNamesUpdated.addAll(List.of(
//					FENCE_LOSS_SETTLEMENT, BUILDING_ORDINANCE_OR_LAW, CYBER_IDENTITY_SHIELD, MARRING_TO_CERTAIN_METAL_MATERIALS, ACCESS_THROUGH_FOUNDATION_WALL));
//			break;
//		case IA: case IN: case MD: case MN: case MT: case OH: case WA:
//			expectedSupplementalCoverageNamesUpdated.addAll(List.of(
//					FENCE_LOSS_SETTLEMENT, CARPET_LOSS_SETTLEMENT, BUILDING_ORDINANCE_OR_LAW, LIMITED_MATCHING_UNDAMAGED_PROPERTY, IDENTITY_FRAUD, ACCESS_COVERAGE_LIMITED_WATER));
//			if (stateCode.equals(MT)) {
//				expectedSupplementalCoverageNamesUpdated.remove(LIMITED_MATCHING_UNDAMAGED_PROPERTY);
//			}
//			break;
//		case ID: case NE: case NM: case WI:
//			expectedSupplementalCoverageNamesUpdated = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_FORTIFIED_ROOF.getCoverages();
//			break;
//		case KS:
//			expectedSupplementalCoverageNamesUpdated.fill("");
//			expectedSupplementalCoverageNamesUpdated.addAll(List.of("Fences", "Building ordinance", "Limited matching coverage for siding and roof materials","Carpet(loss settlement)"));
//			break;
//		case MI:
//			expectedSupplementalCoverageNamesUpdated.remove(CYBER_IDENTITY_SHIELD);
//			if (aceHRCAdditionalCoveragesBasePage.isRoofTypeEligibleForFortifiedRoofUpgrade()) {
//				expectedSupplementalCoverageNamesUpdated.remove(FORTIFIED_ROOF_UPGRADE);
//			}
//			break;
//		case MO:
//			if (aceHRCAdditionalCoveragesBasePage.isRoofTypeEligibleForFortifiedRoofUpgrade()) {
//				expectedSupplementalCoverageNamesUpdated.remove(FORTIFIED_ROOF_UPGRADE);
//			}
//			break;
//		case OK:
//			expectedSupplementalCoverageNamesUpdated.fill("");
//			expectedSupplementalCoverageNamesUpdated.addAll(CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_HOME_SHARING.getCoverages());
//			expectedSupplementalCoverageNamesUpdated.remove(CYBER_IDENTITY_SHIELD);
//			break;
//		case OR: case PA:
//			expectedSupplementalCoverageNamesUpdated = CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_SIDING_AND_ROOF.getCoverages();
//			break;
//		case TN:
//			expectedSupplementalCoverageNamesUpdated.removeAll(List.of(LIMITED_MATCHING_COVERAGE_SIDING_AND_ROOF, FORTIFIED_ROOF_UPGRADE));
//			break;
//		case VA:
//			expectedSupplementalCoverageNamesUpdated.fill("");
//			expectedSupplementalCoverageNamesUpdated.addAll(CoveragesNameAceHome.PREMIER_SUPPLEMENTAL_WITH_SIDING_AND_ROOF_FORTIFIED_ROOF.getCoverages());
//			expectedSupplementalCoverageNamesUpdated.remove(MARRING_TO_CERTAIN_METAL_MATERIALS);
//			break;
        }
        return expectedSupplementalCoverageNamesUpdated;
    }

    List<String> getExpectedSupplementalCoverageAmount(Coverage coverage, int index, int dwellingCoverageValue) throws Exception {
        String coverageSection = getCoverageSectionDescriptionForSupplementalCoverage();
        List<String> expectedSupplementalCoverageAmount = coverage.getCvgInfo().stream().filter(i -> i.getCvgSection().equals(coverageSection))
                .map(AppStore.Home.CvgInfo::getCvgAmt).filter(s -> !s.equalsIgnoreCase("on")).filter(s -> !s.equalsIgnoreCase("off")).collect(Collectors.toList());
        int multiplier = Integer.parseInt(expectedSupplementalCoverageAmount.get(index).replace("%", EMPTY_STRING).replace("$", EMPTY_STRING).replace(COMMA, EMPTY_STRING));
        String buildingOrdinanceValue = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf((multiplier*dwellingCoverageValue)/100));
        expectedSupplementalCoverageAmount.set(index, buildingOrdinanceValue);
        return expectedSupplementalCoverageAmount;
    }

    List<String> getExpectedSpecialLimitCvgAmountPremierPkg(AppStore appStore, String personalPropertyValueFromPrimaryCoverage, int indexOfCardsAndComicBooksCoverageName){
        List<String> expectedSpecialLimitCvgAmount = appStore.getStaticContent().getHome().getReviewQuote().getSpecialLimits().getPremier().stream()
                .map(AppStore.StaticContent.Home.ReviewQuote.SpecialLimits.Premier::getValue).collect(Collectors.toList());
        int personalPropertyValue = Integer.parseInt(personalPropertyValueFromPrimaryCoverage.replaceAll("[$,]",EMPTY_STRING));

        int indexOfPersonalPropertyAtSecondaryResidence = getExpectedSpecialLimitCoveragesNamesPremierPkg().indexOf(PERSONAL_PROPERTY_AT_SECONDARY_RESIDENCE);
        if (indexOfPersonalPropertyAtSecondaryResidence == NOT_FOUND_IN_LIST) {
            Log.warn("indexOfPersonalPropertyAtSecondaryResidence not found");
        } else {
            int multiplier = Integer.parseInt(expectedSpecialLimitCvgAmount.get(indexOfPersonalPropertyAtSecondaryResidence).replace("%", EMPTY_STRING));
            double valueTimesMultiplier = (multiplier*personalPropertyValue)/100.0;
            int finalValue = (int)Math.ceil(valueTimesMultiplier);
            String valueToSet = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(finalValue));
            expectedSpecialLimitCvgAmount.set(indexOfPersonalPropertyAtSecondaryResidence, valueToSet);
        }
        // set cards and comic books value
        expectedSpecialLimitCvgAmount.set(indexOfCardsAndComicBooksCoverageName, personalPropertyValueFromPrimaryCoverage);
        return expectedSpecialLimitCvgAmount;
    }

    public void clickOnComparePackageButton(){
        waitAndClickElement(comparePackageButton);
    }

    public void validateContentOfCompareQuoteSideSheet(FarmersSoftAssert fsa, ApplicantAceHome applicantAceHome, String lobType) throws Exception {
        if (isElementDisplayed(doubleArrowInComparePackageLink, 5)) {
            AppStore appStore = getSessionStorageAppStore();
            clickOnStandardPackage();
            validateCompareQuoteLink(fsa, lobType);
            clickOnComparePackageButton();
            validateComparePackageSideSheetHeaderSubtextToggleButton(fsa, applicantAceHome, lobType);
            validateStandardVsEnhancedTablePrimary(fsa, appStore, lobType);
            validateStandardVsEnhancedTableAdditional(fsa, appStore, applicantAceHome, lobType);
            validateStandardVsEnhancedTableSpecialLimits(fsa, appStore, lobType);
            if (!applicantAceHome.getStateCode().equals(CA)) {
                clickOnEnhancedVsPremierPkg();
                validateEnhancedVsPremierTablePrimary(fsa, appStore, lobType);
                validateEnhancedVsPremierTableAdditional(fsa, appStore, applicantAceHome, lobType);
                validateEnhancedVsPremierTableSpecialLimits(fsa, appStore, lobType);
            }
        } else {
            scrollToTopOfPage();
            Log.warn("Compare packages link was not displayed: " + applicantAceHome.getQuoteNumber(), true);
        }
    }

    public void validateCompareQuoteLink(FarmersSoftAssert fsa, String lobType){
        fsa.assertEquals(doubleArrowInComparePackageLink.isVisible(), true, "Double arrow in compare quote link displayed - " + lobType);
        String expectedComparePackageText = "Compare packages";
        fsa.assertEquals(getTextFromElement(comparePackageLinkText), expectedComparePackageText, "Compare package link text verification - " + lobType);
    }

    public void validateComparePackageSideSheetHeaderSubtextToggleButton(FarmersSoftAssert fsa, ApplicantAceHome applicant, String lobType) throws Exception {
        String expectedComparePackagesHeader = "Compare coverage levels";
        fsa.assertEquals(getTextFromElement(comparePackageHeaderInComparePkgSideSheet), expectedComparePackagesHeader, expectedComparePackagesHeader + " header verification - " + lobType);

        String expectedComparePackageSubtext = "We've highlighted the coverages that have different limits between the packages for convenience.";
        fsa.assertEquals(getTextFromElement(subTextInComparePkgSideSheet), expectedComparePackageSubtext, "Compare package subtext verification in compare packages side sheet - " + lobType);

        if (!applicant.getStateCode().equals(CA)) {
            fsa.assertEquals(standardVsEnhancedButton.isVisible(), true, "Standard vs Enhanced button displayed in compare packages side sheet - " + lobType);
            fsa.assertEquals(enhancedVsPremierButton.isVisible(), true, "Enhanced vs Premier button displayed in compare packages side sheet - " + lobType);
        }
        fsa.assertEquals(packageLabelsInComparePackageSideSheet.count(), 3, "Package label size verification in compare packages side sheet - " + lobType);

        List<String> foundPrimaryAdditionalSpecialLimitsLabelsInCompareQuoteSideSheet = primaryAdditionalSpecialLimitsLabelsInCompareQuoteSideSheet.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> expectedPrimaryAdditionalSpecialLimitsLabelsInCompareQuoteSideSheet = getPrimaryAdditionalSpecialLimitsLabelsInCompareQuoteSideSheet();

        fsa.assertEquals(foundPrimaryAdditionalSpecialLimitsLabelsInCompareQuoteSideSheet, expectedPrimaryAdditionalSpecialLimitsLabelsInCompareQuoteSideSheet,
                "Primary, Additional or Special limits (Personal property) labels verification - " + lobType);
    }

    private List<String> getPrimaryAdditionalSpecialLimitsLabelsInCompareQuoteSideSheet() throws Exception {
        return Arrays.asList("Primary coverages", getCoverageSectionDescriptionForSupplementalCoverage(), "Special limits (Personal property)");
    }

    public void validateStandardVsEnhancedTablePrimary(FarmersSoftAssert fsa, AppStore appStore, String lobType) throws Exception {
        String stateCode = getStateCodeFromSessionStorage();
        Locator primaryCoverageLocatorInStandardVsEnhanced = locator(pwXPath(String.format(SIDE_SHEET_COVERAGE_TABLE_XPATH, PRIMARY)));
        List<Locator> coverageNamesLocatorsStandardVsEnhancedPrimary = primaryCoverageLocatorInStandardVsEnhanced.locator(pwXPath(".//child::td[contains(@class,'cdk-column-cvgDesc')]")).all();

        List<String> foundCoverageNamesStandardVsEnhancedPrimary = coverageNamesLocatorsStandardVsEnhancedPrimary.stream().map(i -> getTextFromElement(i)).collect(Collectors.toList());
        List<String> expectedCoverageNamesStandardVsEnhancedPrimary = getExpectedEnhancedPrimaryCoverageNames(stateCode).stream().map(i -> i.replaceAll(SPACE, EMPTY_STRING)).collect(Collectors.toList());

        if(stateCode.equals(VA)){
            expectedCoverageNamesStandardVsEnhancedPrimary.remove(LOSS_OF_USE.replaceAll(SPACE, EMPTY_STRING));
        }

        fsa.assertEquals(foundCoverageNamesStandardVsEnhancedPrimary, expectedCoverageNamesStandardVsEnhancedPrimary, "Standard vs enhanced coverage names for primary package verification - " + lobType);

        List<Locator> coverageAmountLocatorsStandardVsEnhancedPrimaryStandard = primaryCoverageLocatorInStandardVsEnhanced.locator(pwXPath(".//child::td[contains(@class,'cdk-column-firstCvgAmt')]")).all();
        List<String> foundCoverageValuesStandardVsEnhancedPrimaryStandard = coverageAmountLocatorsStandardVsEnhancedPrimaryStandard.stream().map(i -> getTextFromElement(i).split("\n")[0].trim()).filter(s -> !s.equals("--")).collect(Collectors.toList());
        String selectedPaymentMode = "PIF";
        changeBundleQuotePricing(FULL_PRICING);
        Coverage coverage = appStore.getHome().getCoverageForPackage("S", selectedPaymentMode);

        List<String> expectedCoverageValuesStandardVsEnhancedPrimaryStandard = getExpectedCvgAmtPrimaryWithPercentOnlyStandardPkg(coverage, getDwellingCoverageInInt(appStore), stateCode);
        replaceAcvAndRcvValues(expectedCoverageValuesStandardVsEnhancedPrimaryStandard);
        fsa.assertEquals(foundCoverageValuesStandardVsEnhancedPrimaryStandard, expectedCoverageValuesStandardVsEnhancedPrimaryStandard, "Standard vs enhanced coverage amount for primary package standard verification - " + lobType);

        List<Locator> coverageAmountLocatorsStandardVsEnhancedPrimaryEnhanced = primaryCoverageLocatorInStandardVsEnhanced.locator(pwXPath(".//child::td[contains(@class,'cdk-column-secondCvgAmt')]")).all();
        List<String> foundCoverageValuesStandardVsEnhancedPrimaryEnhanced = coverageAmountLocatorsStandardVsEnhancedPrimaryEnhanced.stream().map(i -> getTextFromElement(i).replaceAll(SPACE, EMPTY_STRING)).collect(Collectors.toList());
        coverage = appStore.getHome().getCoverageForPackage("E", selectedPaymentMode);
        List<String> expectedCoverageValuesStandardVsEnhancedPrimaryEnhanced = getExpectedCvgAmtPrimaryWithPercentOnlyEnhancedPkg(coverage, getDwellingCoverageInInt(appStore), stateCode).stream().map(i -> i.replaceAll(SPACE, EMPTY_STRING)).collect(Collectors.toList());
        expectedCoverageValuesStandardVsEnhancedPrimaryEnhanced = replaceAcvAndRcvValues(expectedCoverageValuesStandardVsEnhancedPrimaryEnhanced);
        fsa.assertEquals(foundCoverageValuesStandardVsEnhancedPrimaryEnhanced, expectedCoverageValuesStandardVsEnhancedPrimaryEnhanced, "Standard vs enhanced coverage amount for primary package enhanced verification - " + lobType);
    }

    public void validateStandardVsEnhancedTableAdditional(FarmersSoftAssert fsa, AppStore appStore, ApplicantAceHome applicantAceHome, String lobType) throws Exception {
        Locator additionalCoverageLocatorInStandardVsEnhanced = locator(pwXPath(String.format(SIDE_SHEET_COVERAGE_TABLE_XPATH, getCoverageSectionDescriptionForSupplementalCoverage())));
        List<Locator> coverageNamesLocatorsStandardVsEnhancedAdditional = additionalCoverageLocatorInStandardVsEnhanced.locator(pwXPath("//div[contains(@class,'compare-quotes-section')][2]//tbody//td[contains(@class,'cdk-column-cvgDesc')]")).all();

        List<String> foundCoverageNamesStandardVsEnhancedAdditional = coverageNamesLocatorsStandardVsEnhancedAdditional.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> expectedCoverageNamesStandardVsEnhancedAdditional = getExpectedSupplementalCoverageNamesEnhancedPkg(applicantAceHome);
        fsa.assertEquals(foundCoverageNamesStandardVsEnhancedAdditional,expectedCoverageNamesStandardVsEnhancedAdditional, "Standard vs enhanced coverage names for additional package standard verification - " + lobType);

        List<Locator> coverageAmountLocatorsStandardVsEnhancedAdditionalStandard = additionalCoverageLocatorInStandardVsEnhanced.locator(pwXPath("//div[contains(@class,'compare-quotes-section')][2]//tbody//td[contains(@class,'cdk-column-firstCvgAmt')]")).all();
        List<String> foundCoverageValuesStandardVsEnhancedPrimaryStandard = coverageAmountLocatorsStandardVsEnhancedAdditionalStandard.stream().map(i -> getTextFromElement(i).split("\n")[0].trim()).filter(s -> !s.equals("--")).collect(Collectors.toList());

        String selectedPaymentMode = "PIF";
        changeBundleQuotePricing(FULL_PRICING);
        Coverage coverage = appStore.getHome().getCoverageForPackage("S", selectedPaymentMode);
        List<String> expectedCoverageValuesStandardVsEnhancedAdditionalStandard = getExpectedSupplementalCoverageAmountStandardPkg(coverage);
        expectedCoverageValuesStandardVsEnhancedAdditionalStandard = replaceAcvAndRcvValues(expectedCoverageValuesStandardVsEnhancedAdditionalStandard);

        fsa.assertEquals(foundCoverageValuesStandardVsEnhancedPrimaryStandard, expectedCoverageValuesStandardVsEnhancedAdditionalStandard,"Standard vs enhanced coverage amount for additional package standard verification - " + lobType);

        List<Locator> coverageAmountLocatorsStandardVsEnhancedAdditionalEnhanced = additionalCoverageLocatorInStandardVsEnhanced.locator(pwXPath("//div[contains(@class,'compare-quotes-section')][2]//tbody//td[contains(@class,'cdk-column-secondCvgAmt')]")).all();
        List<String> foundCoverageValuesStandardVsEnhancedAdditionalEnhanced = coverageAmountLocatorsStandardVsEnhancedAdditionalEnhanced.stream().map(this::getTextFromElement).collect(Collectors.toList());
        coverage = appStore.getHome().getCoverageForPackage("E", selectedPaymentMode);
        int dwellingCoverageValueInInt = getDwellingCoverageInInt(appStore);
        List<String> expectedCoverageValuesStandardVsEnhancedAdditionalEnhanced = getExpectedSupplementalCoverageAmountEnhancedPkg(coverage, dwellingCoverageValueInInt);
        expectedCoverageValuesStandardVsEnhancedAdditionalEnhanced = replaceAcvAndRcvValues(expectedCoverageValuesStandardVsEnhancedAdditionalEnhanced);
        fsa.assertEquals(foundCoverageValuesStandardVsEnhancedAdditionalEnhanced, expectedCoverageValuesStandardVsEnhancedAdditionalEnhanced, "Standard vs enhanced coverage amount for additional package enhanced verification - " + lobType);
    }

    public void validateStandardVsEnhancedTableSpecialLimits(FarmersSoftAssert fsa, AppStore appStore, String lobType) throws Exception {
        List<Locator> coverageNamesLocatorsStandardVsEnhancedSpecialLimits = locators(pwXPath("//div[contains(@class,'compare-quotes-section')][3]//tbody//td[contains(@class,'cdk-column-cvgDesc')]"));

        List<String> foundCoverageNamesStandardVsEnhancedAdditional = coverageNamesLocatorsStandardVsEnhancedSpecialLimits.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> expectedCoverageNamesStandardVsEnhancedAdditional = getExpectedSpecialLimitCoveragesNamesEnhancedPkg();
        fsa.assertEquals(foundCoverageNamesStandardVsEnhancedAdditional, expectedCoverageNamesStandardVsEnhancedAdditional, "Standard vs enhanced coverage names for additional package standard verification - " + lobType);

        List<Locator> coverageAmountLocatorsStandardVsEnhancedSpecialLimitsStandard = locators(pwXPath("//div[contains(@class,'compare-quotes-section')][3]//tbody//td[contains(@class,'cdk-column-firstCvgAmt')]"));
        List<String> foundCoverageValuesStandardVsEnhancedSpecialLimitsStandard = coverageAmountLocatorsStandardVsEnhancedSpecialLimitsStandard.stream().map(i -> getTextFromElement(i).split("\n")[0].trim()).filter(s -> !s.equals("--")).collect(Collectors.toList());

        String selectedPaymentMode = "PIF";
        changeBundleQuotePricing(FULL_PRICING);
        int dwellingCoverageValueInInt = getDwellingCoverageInInt(appStore);
        String stateCode = getStateCodeFromSessionStorage();
        Coverage coverage = appStore.getHome().getCoverageForPackage("S", selectedPaymentMode);
        List<String> expectedCvgAmtPrimaryWithPercentOnly = getExpectedCvgAmtPrimaryWithPercentOnlyStandardPkg(coverage, dwellingCoverageValueInInt, stateCode);
        replaceAcvAndRcvValues(expectedCvgAmtPrimaryWithPercentOnly);
        int indexOfPersonalPropertyAtSecondaryResidence = foundCoverageNamesStandardVsEnhancedAdditional.indexOf(PERSONAL_PROPERTY_AT_SECONDARY_RESIDENCE);
        if (indexOfPersonalPropertyAtSecondaryResidence == NOT_FOUND_IN_LIST || expectedCvgAmtPrimaryWithPercentOnly.size()<4) {
            Log.warn("indexOfPersonalPropertyAtSecondaryResidence not found or not enough expectedCvgAmtPrimaryWithPercentOnly items");
        } else {
            List<String> expectedCoverageValuesStandardVsEnhancedSpecialLimitsStandard = getExpectedSpecialLimitCvgAmountStandardPkg(appStore, getPersonalPropertyCoverageValueForSelectedPackage(coverage, dwellingCoverageValueInInt), indexOfPersonalPropertyAtSecondaryResidence);
            fsa.assertEquals(foundCoverageValuesStandardVsEnhancedSpecialLimitsStandard, expectedCoverageValuesStandardVsEnhancedSpecialLimitsStandard, "Standard vs enhanced coverage amount for special limits package standard verification - " + lobType);
        }
        List<Locator> coverageAmountLocatorsStandardVsEnhancedSpecialLimitsEnhanced = locators(pwXPath("//div[contains(@class,'compare-quotes-section')][3]//tbody//td[contains(@class,'cdk-column-secondCvgAmt')]"));

        List<String> foundCoverageValuesStandardVsEnhancedSpecialLimitsEnhanced = coverageAmountLocatorsStandardVsEnhancedSpecialLimitsEnhanced.stream().map(this::getTextFromElement).collect(Collectors.toList());
        coverage = appStore.getHome().getCoverageForPackage("E", selectedPaymentMode);
        int personalPropertyValue = Integer.parseInt(getPersonalPropertyCoverageValueForSelectedPackage(coverage, dwellingCoverageValueInInt).replaceAll("[$,]",EMPTY_STRING));
        List<String> expectedCoverageValuesStandardVsEnhancedSpecialLimitsEnhanced = getExpectedSpecialLimitCvgAmountEnhancedPkg(appStore, personalPropertyValue);
        fsa.assertEquals(foundCoverageValuesStandardVsEnhancedSpecialLimitsEnhanced, expectedCoverageValuesStandardVsEnhancedSpecialLimitsEnhanced, "Standard vs enhanced coverage amount for special limits package enhanced verification - " + lobType);
    }

    public List<String> replaceAcvAndRcvValues(List<String> originalListOfValues){
        List<String> temporaryList = originalListOfValues;
        temporaryList.replaceAll(value -> (value.equals(ACTUAL_CASH_VALUE) || value.equals(ACTUAL_CASH_VALUE_WITHOUT_SPACE))? "ACV" : value);
        temporaryList.replaceAll(value -> (value.equals(REPLACEMENT_COST) || value.equals(REPLACEMENT_COST_WITHOUT_SPACE))? "RCV" : value);
        return temporaryList;
    }

    public void clickOnEnhancedVsPremierPkg(){
        waitAndClickElement(enhancedVsPremierButton);
    }

    public void validateEnhancedVsPremierTablePrimary(FarmersSoftAssert fsa, AppStore appStore, String lobType) throws Exception {
        String stateCode = getStateCodeFromSessionStorage();
        Locator primaryCoverageLocatorInEnhancedVsPremier = locator(pwXPath(String.format(SIDE_SHEET_COVERAGE_TABLE_XPATH, PRIMARY)));
        List<Locator> coverageNamesLocatorsEnhancedVsPremierPrimary = primaryCoverageLocatorInEnhancedVsPremier.locator(pwXPath(".//child::td[contains(@class,'cdk-column-cvgDesc')]")).all();

        List<String> foundCoverageNamesEnhancedVsPremierPrimary = coverageNamesLocatorsEnhancedVsPremierPrimary.stream().map(i-> getTextFromElement(i).replaceAll(SPACE, EMPTY_STRING)).map(i -> i.replaceAll(SPACE, EMPTY_STRING)).collect(Collectors.toList());
        List<String> expectedCoverageNamesStandardVsEnhancedPrimary = getExpectedPremierPrimaryCoverageNames(stateCode).stream().map(i -> i.replaceAll(SPACE, EMPTY_STRING)).collect(Collectors.toList());
        if(stateCode.equals(VA)){
            expectedCoverageNamesStandardVsEnhancedPrimary.remove(LOSS_OF_USE.replaceAll(SPACE, EMPTY_STRING));
        }
        fsa.assertEquals(foundCoverageNamesEnhancedVsPremierPrimary, expectedCoverageNamesStandardVsEnhancedPrimary, "Enhanced vs premier coverage names for primary package verification - " + lobType);

        List<Locator> coverageAmountLocatorsEnhancedVsPremierPrimaryEnhanced = primaryCoverageLocatorInEnhancedVsPremier.locator(pwXPath(".//child::td[contains(@class,'cdk-column-firstCvgAmt')]")).all();
        List<String> foundCoverageValuesEnhancedVsStandardPrimaryEnhanced = coverageAmountLocatorsEnhancedVsPremierPrimaryEnhanced.stream().map(i -> getTextFromElement(i).replaceAll(SPACE, EMPTY_STRING)).filter(s -> !s.equals("--")).collect(Collectors.toList());
        String selectedPaymentMode = "PIF";
        changeBundleQuotePricing(FULL_PRICING);

        Coverage coverage = appStore.getHome().getCoverageForPackage("E", selectedPaymentMode);
        List<String> expectedCoverageValuesStandardVsEnhancedPrimaryEnhanced = getExpectedCvgAmtPrimaryWithPercentOnlyEnhancedPkg(coverage, getDwellingCoverageInInt(appStore), stateCode).stream().map(i -> i.replaceAll(SPACE, EMPTY_STRING)).collect(Collectors.toList());
        expectedCoverageValuesStandardVsEnhancedPrimaryEnhanced = replaceAcvAndRcvValues(expectedCoverageValuesStandardVsEnhancedPrimaryEnhanced);
        fsa.assertEquals(foundCoverageValuesEnhancedVsStandardPrimaryEnhanced, expectedCoverageValuesStandardVsEnhancedPrimaryEnhanced, "Enhanced vs premier coverage amount for primary package enhanced verification - " + lobType);

        List<Locator> coverageAmountLocatorsEnhancedVsPrimaryPremier = primaryCoverageLocatorInEnhancedVsPremier.locator(pwXPath(".//child::td[contains(@class,'cdk-column-secondCvgAmt')]")).all();
        List<String> foundCoverageValuesStandardVsEnhancedPrimaryPremier = coverageAmountLocatorsEnhancedVsPrimaryPremier.stream().map(i -> getTextFromElement(i).replaceAll(SPACE, EMPTY_STRING)).collect(Collectors.toList());
        coverage = appStore.getHome().getCoverageForPackage("P", selectedPaymentMode);

        List<String> expectedCoverageValuesStandardVsEnhancedPrimaryPremier = getExpectedCvgAmtPrimaryWithPercentOnlyPremierPkg(coverage, appStore, stateCode).stream().map(i -> i.replaceAll(SPACE, EMPTY_STRING)).collect(Collectors.toList());
        expectedCoverageValuesStandardVsEnhancedPrimaryPremier = replaceAcvAndRcvValues(expectedCoverageValuesStandardVsEnhancedPrimaryPremier);
        fsa.assertEquals(foundCoverageValuesStandardVsEnhancedPrimaryPremier, expectedCoverageValuesStandardVsEnhancedPrimaryPremier, "Enhanced vs premier coverage amount for primary package premier verification - " + lobType);
    }

    public void validateEnhancedVsPremierTableAdditional(FarmersSoftAssert fsa, AppStore appStore, ApplicantAceHome applicantAceHome, String lobType) throws Exception {
        List<Locator> coverageNamesLocatorsEnhancedVsPremierAdditional = locators(pwXPath("//div[contains(@class,'compare-quotes-section')][2]//tbody//td[contains(@class,'cdk-column-cvgDesc')]"));

        List<String> foundCoverageNamesEnhancedVsPremierAdditional = coverageNamesLocatorsEnhancedVsPremierAdditional.stream().map(this::getTextFromElement).collect(Collectors.toList());
        List<String> expectedCoverageNamesEnhancedVsPremierAdditional = getExpectedSupplementalCoverageNamesEnhancedPkg(applicantAceHome);
        fsa.assertEquals(foundCoverageNamesEnhancedVsPremierAdditional, expectedCoverageNamesEnhancedVsPremierAdditional,"Enhanced vs premier coverage names for additional package enhanced verification - " + lobType);

        List<Locator> coverageAmountLocatorsEnhancedVsPremierAdditionalEnhanced = locators(pwXPath("//div[contains(@class,'compare-quotes-section')][2]//tbody//td[contains(@class,'cdk-column-firstCvgAmt')]"));
        List<String> foundCoverageValuesEnhancedVsPremierAdditionalEnhanced = coverageAmountLocatorsEnhancedVsPremierAdditionalEnhanced.stream().map(i -> getTextFromElement(i).split("\n")[0].trim()).filter(s -> !s.equals("--")).collect(Collectors.toList());

        String selectedPaymentMode = "PIF";
        changeBundleQuotePricing(FULL_PRICING);
        Coverage coverage = appStore.getHome().getCoverageForPackage("E", selectedPaymentMode);
        int dwellingCoverageAmount = getDwellingCoverageInInt(appStore);
        List<String> expectedCoverageValuesStandardVsEnhancedAdditionalEnhanced = getExpectedSupplementalCoverageAmountEnhancedPkg(coverage, dwellingCoverageAmount);
        expectedCoverageValuesStandardVsEnhancedAdditionalEnhanced = replaceAcvAndRcvValues(expectedCoverageValuesStandardVsEnhancedAdditionalEnhanced);

        fsa.assertEquals(foundCoverageValuesEnhancedVsPremierAdditionalEnhanced, expectedCoverageValuesStandardVsEnhancedAdditionalEnhanced, "Enhanced vs premier coverage amount for additional package standard verification - " + lobType);

        List<Locator> coverageAmountLocatorsEnhancedVsPremierAdditionalPremier = locators(pwXPath("//div[contains(@class,'compare-quotes-section')][2]//tbody//td[contains(@class,'cdk-column-secondCvgAmt')]"));

        List<String> foundCoverageValuesEnhancedVsPremierAdditionalPremier = coverageAmountLocatorsEnhancedVsPremierAdditionalPremier.stream().map(this::getTextFromElement).filter(s -> !s.equalsIgnoreCase("on")).collect(Collectors.toList());
        coverage = appStore.getHome().getCoverageForPackage("P", selectedPaymentMode);
        int index = foundCoverageNamesEnhancedVsPremierAdditional.indexOf(BUILDING_ORDINANCE_OR_LAW);
        if (index == NOT_FOUND_IN_LIST) {
            Log.warn("foundCoverageNamesEnhancedVsPremierAdditional.indexOf(BUILDING_ORDINANCE_OR_LAW) not found");
        } else {
            int dwellingCoverageValueInInt = getDwellingCoverageInInt(appStore);
            List<String> expectedCoverageValuesEnhancedVsPremierAdditionalPremier = getExpectedSupplementalCoverageAmount(coverage, index, dwellingCoverageValueInInt);
            expectedCoverageValuesEnhancedVsPremierAdditionalPremier = replaceAcvAndRcvValues(expectedCoverageValuesEnhancedVsPremierAdditionalPremier);
            fsa.assertEquals(foundCoverageValuesEnhancedVsPremierAdditionalPremier, expectedCoverageValuesEnhancedVsPremierAdditionalPremier, "Enhanced vs premier coverage amount for additional package premier verification - " + lobType);
        }
    }

    public void validateEnhancedVsPremierTableSpecialLimits(FarmersSoftAssert fsa, AppStore appStore, String lobType) throws Exception {
        Locator specialLimitCoverageLocatorInEnhancedVsPremier = locator(pwXPath(String.format(SIDE_SHEET_COVERAGE_TABLE_XPATH, "Special limits")));
        List<Locator> coverageNamesLocatorsEnhancedVsPremierSpecialLimits = specialLimitCoverageLocatorInEnhancedVsPremier.locator(pwXPath(".//child::td[contains(@class,'cdk-column-cvgDesc')]")).all();

        List<String> foundCoverageNamesEnhancedVsPremierAdditional = coverageNamesLocatorsEnhancedVsPremierSpecialLimits.stream().map(this::getTextFromElement).collect(Collectors.toList());

        List<String> expectedCoverageNamesEnhancedVsPremierAdditional = getExpectedSpecialLimitCoveragesNamesPremierPkg();
        int indexOfCardsAndComicBooks = expectedCoverageNamesEnhancedVsPremierAdditional.indexOf(CARDS_AND_COMIC_BOOKS);
        if (indexOfCardsAndComicBooks != NOT_FOUND_IN_LIST) {
            expectedCoverageNamesEnhancedVsPremierAdditional.set(indexOfCardsAndComicBooks, CARDS_AND_COMIC_BOOKS_PER_ITEM_PER_LOSS);
        }
        fsa.assertEquals(foundCoverageNamesEnhancedVsPremierAdditional, expectedCoverageNamesEnhancedVsPremierAdditional, "Enhanced vs premier coverage names for special limit verification - " + lobType);

        List<Locator> coverageAmountLocatorsEnhancedVsPremierSpecialLimitsEnhanced = specialLimitCoverageLocatorInEnhancedVsPremier.locator(pwXPath(".//child::td[contains(@class,'cdk-column-firstCvgAmt')]")).all();
        List<String> foundCoverageValuesEnhancedVsPremierSpecialLimitsStandard = coverageAmountLocatorsEnhancedVsPremierSpecialLimitsEnhanced.stream().map(i -> getTextFromElement(i).split("\n")[0].trim()).filter(s -> !s.equals("--")).collect(Collectors.toList());

        String selectedPaymentMode = "PIF";
        changeBundleQuotePricing(FULL_PRICING);
        int dwellingCoverageValueInInt = getDwellingCoverageInInt(appStore);
        Coverage coverage = appStore.getHome().getCoverageForPackage("E", selectedPaymentMode);
        int personalPropertyValue = Integer.parseInt(getPersonalPropertyCoverageValueForSelectedPackage(coverage, dwellingCoverageValueInInt).replaceAll("[$,]",EMPTY_STRING));
        List<String> expectedCoverageValuesEnhancedVsPremierSpecialLimitsEnhanced = getExpectedSpecialLimitCvgAmountEnhancedPkg(appStore, personalPropertyValue);

        fsa.assertEquals(foundCoverageValuesEnhancedVsPremierSpecialLimitsStandard, expectedCoverageValuesEnhancedVsPremierSpecialLimitsEnhanced, "Enhanced vs premier coverage amount for special limits package enhanced verification - " + lobType);

        List<Locator> coverageAmountLocatorsEnhancedVsPremierSpecialLimitsPremier = specialLimitCoverageLocatorInEnhancedVsPremier.locator(pwXPath(".//child::td[contains(@class,'cdk-column-secondCvgAmt')]")).all();
        List<String> foundCoverageValuesEnhancedVsPremierSpecialLimitsPremier = coverageAmountLocatorsEnhancedVsPremierSpecialLimitsPremier.stream().map(this::getTextFromElement).collect(Collectors.toList());

        coverage = appStore.getHome().getCoverageForPackage("P", selectedPaymentMode);

        int indexOfCardsAndComicBooksCoverageName = foundCoverageNamesEnhancedVsPremierAdditional.indexOf(CARDS_AND_COMIC_BOOKS_PER_ITEM_PER_LOSS);
        if (indexOfCardsAndComicBooksCoverageName == NOT_FOUND_IN_LIST) {
            Log.warn("indexOfCardsAndComicBooksCoverageName not found");
        } else {
            String personalPropertyCoverageValue = getPersonalPropertyCoverageValueForSelectedPackage(coverage, dwellingCoverageValueInInt);
            List<String> expectedCvgAmtEnhancedVsPremierSpecialLimitsPremier = getExpectedSpecialLimitCvgAmountPremierPkg(appStore, personalPropertyCoverageValue, indexOfCardsAndComicBooksCoverageName);
            fsa.assertEquals(foundCoverageValuesEnhancedVsPremierSpecialLimitsPremier, expectedCvgAmtEnhancedVsPremierSpecialLimitsPremier, "Enhanced vs premier coverage amount for special limits package premier verification - " + lobType);
        }
    }

    public void  validateADA() throws Exception {
        showOrHideSpecialLimitsSection(true);
        clickEditDeductiblesLink();
        randomlySelectAllPerilLosses(allPerilLossesRadioButtons);
        performADATesting(this.getClass().getSimpleName()+"_EditDeductibles",MARKETING_IT,FFQ_ACE_HOME);
        waitElementBeVisibleClickable(closeIconInDeductibleSideSheet);

        clickOnComparePackageButton();
        performADATesting(this.getClass().getSimpleName()+"_ComparePackages",MARKETING_IT,FFQ_ACE_HOME);

        waitAndClickElement(dwellingInfoIcon);
        performADATesting(this.getClass().getSimpleName()+"_CoveragesInfoSideSheet",MARKETING_IT,FFQ_ACE_HOME);
        clickCloseIconInCoverageInfoSideSheet();
    }

    public String getStateCodeFromSessionStorage() throws Exception {
        return getSessionStorageAppStore().getData().getLandingStateCode();
    }

    public void clickChangeCoverage() {
        waitAndClickElement(linkBackToDwellingCoverage);
    }

    public String getDeductibleAmountByName(String deductible) throws Exception {
        String amountXpath = String.format(DEDUCTIBLE_AMOUNT_XPATH,deductible);
        return getTextFromElement(locator(pwXPath(amountXpath)));
    }

    public void updateAllPerilsDeductibleAndRecalculate() {
        waitAndClickElement(editDeductibleButton);
        Locator radioWe = allPerilLossesMatRadioButtons.all().stream().filter(we -> !we.getAttribute(CLASS).contains(RADIO_BUTTON_CHECKED)).findFirst().get();
        waitAndClickElement(radioWe.locator(pwXPath("label")));
        clickRecalculateButtonHomeLobInSideSheet();
    }

    public void clickCancelOnPolicyExclusionPopup() {
        waitAndClickElement(windHailExclusionPopupCancelBtn);
    }

    public void validatePolicyExclusionPopupContent(FarmersSoftAssert fsa, String stateCode){
        final String WIND_HAIL_EXCLUSION_POPUP_TITLE_CONTENT = "Policy exclusions";
        String additionalCoverageExclusions = stateCode.equals(AL) ? "Hurricane coverage" : "Tropical cyclone coverage";
        final String WIND_HAIL_EXCLUSION_POPUP_SUBTITLE_CONTENT = String.format("Based on your location, these are excluded from coverage:" +
                " Wind and hail coverage %s Would you like to continue with your online quote?", additionalCoverageExclusions);

        fsa.assertEquals(getTextFromElement(waitElementBeVisible(windHailExclusionPopupTitle, 5)), WIND_HAIL_EXCLUSION_POPUP_TITLE_CONTENT, "Wind/Hail Exclusion Popup Title verification - Home Lob");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(windHailExclusionPopupSubTitleContent, 5)), WIND_HAIL_EXCLUSION_POPUP_SUBTITLE_CONTENT, "Wind/Hail Exclusion Popup Sub-Title verification - Home Lob");
        fsa.assertTrue(isElementDisplayed(windHailExclusionPopupCancelBtn, 5), "Wind/Hail Exclusion Popup cancel link is displayed - Home Lob");
        waitAndClickElement(windHailExclusionPopupContinueBtn);
    }

    public void validateContentOfPolicyExclusionOnDeductibleInfoSideSheet(FarmersSoftAssert fsa, String stateCode){
        final String WIND_HAIL_EXCLUSION_POPUP_TITLE_1 = "Exclusions";
        String additionalCoverageExclusions = stateCode.equals(AL) ? "hurricane" : "tropical cyclone";
        final String WIND_HAIL_EXCLUSION_POPUP_TITLE_2 = String.format("Wind and hail, and %s losses", additionalCoverageExclusions);
        final String WIND_HAIL_EXCLUSION_POPUP_SUBTITLE = String.format("Direct or indirect loss or damage caused by, resulting from, or contributed to by wind and hail, or %s are not covered.", additionalCoverageExclusions);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(windHailExclusionTitle.nth(0), 3)), WIND_HAIL_EXCLUSION_POPUP_TITLE_1, "Wind/Hail Exclusion Title 1 verification on Peril Side sheet - Home Lob");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(windHailExclusionTitle.nth(1), 3)), WIND_HAIL_EXCLUSION_POPUP_TITLE_2, "Wind/Hail Exclusion Title 2 verification on Peril Side sheet - Home Lob");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(windHailExclusionTitle.nth(2), 3)), WIND_HAIL_EXCLUSION_POPUP_SUBTITLE, "Wind/Hail Exclusion Title 3 verification on Peril Side sheet - Home Lob");
        pressEscKey();
    }

    public void validateSupplementalCoverageNameAndValue(ApplicantAceHome applicant, FarmersSoftAssert fsa, String coverageName, String coverageVal) throws Exception {
        List<String> additionalCoverages = getFoundSupplementalCoveragesNames(applicant.getStateCode());
        Log.info("Supplementary coverages found: >> " + additionalCoverages);
        fsa.assertTrue(additionalCoverages.contains(coverageName), coverageName + " is present.");
        int indexCount = additionalCoverages.indexOf(coverageName);
        String coverageValue = getFoundSupplementalCoveragesAmount(applicant.getStateCode()).get(indexCount);
        fsa.assertEquals(coverageValue, coverageVal, coverageName + " value is: " + coverageVal);
    }

    public boolean clickContinueWithHomeOnly() {
        boolean isButtonAvailable = false;
        if (isElementVisibleAndClickable(linkToContinueWithHomeOnly, 5)){
            clickElement(linkToContinueWithHomeOnly);
            isButtonAvailable = true;
        }
        return isButtonAvailable;
    }

    public void clickContinueWithBundle() {
        waitAndClickElement(buttonToContinueWithBundle);
    }

    public void clickEditPrimaryCoveragesLink() {
        waitAndClickElement(editPrimaryCoverageButton);
    }

    public void clickCloseEditPrimaryCoveragesSideSheet() {
        waitAndClickElement(editPrimaryCoverageCloseButton);
    }

    public void openPrimaryCoveragesSideSheet() throws Exception {
        if (!isElementDisplayed(editCoverageSideSheetTitle, 2)) {
            if (isElementDisplayed(minimizeQuoteCard, 2)) {
                clickElement(minimizeQuoteCard);
            }
            clickEditPrimaryCoveragesLink();
            testStepAssert(isElementDisplayed(editCoverageSideSheetTitle, 3), "Review quote page - Edit primary coverages side-sheet title was not displayed.", true);
            if ((editCoverageCards.count() == 0)) {
                refreshPage();
                clickEditPrimaryCoveragesLink();
                testStepAssert(isElementDisplayed(editCoverageSideSheetTitle, 5), "Review quote page - Edit primary coverages side-sheet title was still not displayed.", true);
            }
        }
    }

    public List<String> getExpectedPrimaryCoveragesTitles() throws Exception {
        List<String> expectedPrimaryCoveragesTitles = new ArrayList<>(List.of(EXTENDED_DWELLING_REPLACEMENT_COST, SEPARATE_STRUCTURES, "Personal property (limit)", "Personal property (loss settlement)",
                "Personal property (perils covered)", "Loss of use (Additional living expense limit)", "Loss of use (Additional living expense term)", PERSONAL_LIABILITY, MEDICAL_PAYMENT_TO_OTHERS));
        AppStore appStore = getSessionStorageAppStore();
        String selectedPackageCode = appStore.getHome().getQuote().getSelectedPackageCode();
        String selectedPaymentMode = appStore.getHome().getQuote().getSelectedPaymentMode();
        Coverage coverage = appStore.getHome().getCoverageForPackage(selectedPackageCode, selectedPaymentMode);
        boolean isExtendedDRC = coverage.getCvgInfoForCvgDesc("Extended replacement cost") != null;
        if (!isExtendedDRC) {expectedPrimaryCoveragesTitles.remove(EXTENDED_DWELLING_REPLACEMENT_COST);}
        return expectedPrimaryCoveragesTitles;
    }

    public void validateEditPrimaryCoveragesSideSheetContent(ApplicantAceHome applicant, FarmersSoftAssert fsa) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        double dwellingRC = getDwellingCoverageInInt(appStore);
        String stateCode = applicant.getStateCode();

        openPrimaryCoveragesSideSheet();
        List<String> expectedPrimaryCoveragesTitles = getExpectedPrimaryCoveragesTitles();
        boolean isExtendedDRCCoveragePresent = expectedPrimaryCoveragesTitles.contains(EXTENDED_DWELLING_REPLACEMENT_COST);
        List<String> primaryCoverages = editCoverageCardTitles.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(primaryCoverages, expectedPrimaryCoveragesTitles, "Review quote page - Primary coverages titles verification in the side-sheet.");

        // Extended dwelling replacement cost radio buttons titles verification
        List<String> extendedDwellingReplacementCostTitles;
        List<Double> extendedDRC_radioButtonsValues;
        if (isExtendedDRCCoveragePresent) {
            if (!stateCode.equals(CO)) {
                extendedDRC_radioButtonsValues = List.of(dwellingRC, (dwellingRC + dwellingRC * 0.1), (dwellingRC + dwellingRC * 0.25));
                extendedDwellingReplacementCostTitles = List.of("Our estimated coverage amount", "About 10% more coverage", "About 25% more coverage");
            } else {
                extendedDRC_radioButtonsValues = List.of(dwellingRC, (dwellingRC + dwellingRC * 0.25), (dwellingRC + dwellingRC * 0.5));
                extendedDwellingReplacementCostTitles = List.of("Our estimated coverage amount", "About 25% more coverage", "About 50% more coverage");
            }
            List<String> radioButtonTitles = extendedDRC_radioButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
            for (int i = 0; i < extendedDwellingReplacementCostTitles.size(); i++) {
                if ((extendedDRC_radioButtonsValues.get(i) > 1000000d && isRCTOneMilLimitState(stateCode)) ||
                        (extendedDRC_radioButtonsValues.get(i) > 1500000d && !isRCTOneMilLimitState(stateCode))) {
                    break;
                }
                String expectedRadioButtonTitle = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(extendedDRC_radioButtonsValues.get(i))) +
                        SPACE + extendedDwellingReplacementCostTitles.get(i);
                fsa.assertEquals(radioButtonTitles.get(i), expectedRadioButtonTitle, "Review quote page - Extended dwelling replacement cost radio buttons titles verification in the side-sheet.");
            }
            if (applicant.isKeep360Prefill()) {
                fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(extendedDRC_radioButtons),
                        CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(extendedDRC_radioButtonsValues.get(0))),
                        "Review quote page - Extended dwelling replacement cost selected radio button value verification in the side-sheet");
            } else {
                fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(extendedDRC_radioButtons),
                        CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(extendedDRC_radioButtonsValues.get(0))),
                        "Review quote page - Extended dwelling replacement cost selected radio button value verification in the side-sheet.");
            }
        }

        // Separate structures coverage title and amount verification
        List<Double> separateStructures_radioButtonsValues = List.of(dwellingRC * 0.05, dwellingRC * 0.10);
        List<String> separateStructuresTitles = List.of("About 5% of the dwelling coverage", "About 10% of the dwelling coverage");
        List<String> separateStructuresCoverageTitles = separateStructures_radioButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        for (int i = 0; i < separateStructuresCoverageTitles.size(); i++) {
            String expectedRadioButtonTitle = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(separateStructures_radioButtonsValues.get(i))) +
                    SPACE + separateStructuresTitles.get(i);
            fsa.assertEquals(separateStructuresCoverageTitles.get(i), expectedRadioButtonTitle, "Review quote page - Separate structure radio buttons titles verification in the side-sheet.");
        }
        fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(separateStructures_radioButtons),
                CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(separateStructures_radioButtonsValues.get(0))),
                "Review quote page - Separate structures selected radio button value verification in the side-sheet");

        // Personal property (limit) coverage title and amount verification
        List<Double> personalPropertyLimit_radioButtonsValues = List.of(dwellingRC * 0.40, dwellingRC * 0.55, dwellingRC * 0.75);
        List<String> personalPropertyLimitTitles = List.of("About 40% of the dwelling coverage", "About 55% of the dwelling coverage", "About 75% of the dwelling coverage");
        List<String> personalPropertyLimitCoverageTitles = personalPropertyLimit_radioButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        for (int i = 0; i < personalPropertyLimitCoverageTitles.size(); i++) {
            String expectedRadioButtonTitle = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(personalPropertyLimit_radioButtonsValues.get(i))) +
                    SPACE + personalPropertyLimitTitles.get(i);
            fsa.assertEquals(personalPropertyLimitCoverageTitles.get(i), expectedRadioButtonTitle, "Review quote page - Personal property (limit) radio buttons titles verification in the side-sheet.");
        }
        fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(personalPropertyLimit_radioButtons),
                CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(personalPropertyLimit_radioButtonsValues.get(0))),
                "Review quote page - Personal property (limit) selected radio button value verification in the side-sheet");

        // Personal property (loss settlement) coverage title and amount verification
        List<String> personalPropertyLossTitlesExpected = List.of("Actual cash value", "Replacement cost");
        List<String> personalPropertyLossCoverageTitles = personalPropertyLossSettlement_radioButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(personalPropertyLossCoverageTitles, personalPropertyLossTitlesExpected, "Review quote page - Personal property (loss settlement) radio buttons titles verification in the side-sheet.");
        fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(personalPropertyLossSettlement_radioButtons),
                personalPropertyLossTitlesExpected.get(0), "Review quote page - Personal property (limit) selected radio button value verification in the side-sheet");

        // Personal property (perils covered) coverage title and amount verification
        List<String> personalPropertyPerilsTitlesExpected = List.of("Broad named perils", "Open perils");
        List<String> personalPropertyPerilsCoverageTitles = personalPropertyPerils_radioButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(personalPropertyPerilsCoverageTitles, personalPropertyPerilsTitlesExpected, "Review quote page - Personal property (perils covered) radio buttons titles verification in the side-sheet.");
        fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(personalPropertyPerils_radioButtons),
                personalPropertyPerilsTitlesExpected.get(0), "Review quote page - Personal property (perils covered) selected radio button value verification in the side-sheet");

        // Loss of use (Additional living expense limit) coverage title and amount verification
        List<Double> lossOfUseLimit_radioButtonsValues = List.of(dwellingRC * 0.10, dwellingRC * 0.20, dwellingRC * 0.30);
        List<String> lossOfUseLimitTitles = List.of("About 10% of the dwelling coverage", "About 20% of the dwelling coverage", "About 30% of the dwelling coverage");
        List<String> lossOfUseLimitCoverageTitles = lossOfUseLimit_radioButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        for (int i = 0; i < personalPropertyLimitCoverageTitles.size(); i++) {
            String expectedRadioButtonTitle = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(lossOfUseLimit_radioButtonsValues.get(i))) +
                    SPACE + lossOfUseLimitTitles.get(i);
            fsa.assertEquals(lossOfUseLimitCoverageTitles.get(i), expectedRadioButtonTitle, "Review quote page - Loss of use (Additional living expense limit) radio buttons titles verification in the side-sheet.");
        }
        fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(lossOfUseLimit_radioButtons),
                CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(lossOfUseLimit_radioButtonsValues.get(0))),
                "Review quote page - Loss of use (Additional living expense limit) selected radio button value verification in the side-sheet");

        // Loss of use (Additional living expense term) coverage title and amount verification
        List<String> lossOfUseTermTitlesExpected = stateCode.equals(CO) ? List.of("24 months") : List.of("12 months", "24 months");
        List<String> lossOfUseTermCoverageTitles = lossOfUseTerm_radioButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(lossOfUseTermCoverageTitles, lossOfUseTermTitlesExpected, "Review quote page - Loss of use (Additional living expense term) radio buttons titles verification in the side-sheet.");
        fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(lossOfUseTerm_radioButtons),
                lossOfUseTermTitlesExpected.get(0), "Review quote page - Personal property (perils covered) selected radio button value verification in the side-sheet");

        // Personal liability coverage title and amount verification
        List<String> personalLiabilityTitlesExpected = List.of("$100,000", "$300,000", "$500,000");
        List<String> personalLiabilityCoverageTitles = personalLiability_radioButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(personalLiabilityCoverageTitles, personalLiabilityTitlesExpected, "Review quote page - Personal liability radio buttons titles verification in the side-sheet.");
        fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(personalLiability_radioButtons),
                personalLiabilityTitlesExpected.get(1), "Review quote page - Personal liability selected radio button value verification in the side-sheet");

        // Medical payments to others coverage title and amount verification
        List<String> medicalPaymentsTitlesExpected = List.of("$1,000", "$2,000", "$5,000");
        List<String> medicalPaymentsCoverageTitles = medicalPayments_radioButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(medicalPaymentsCoverageTitles, medicalPaymentsTitlesExpected, "Review quote page - Medical payments to others radio buttons titles verification in the side-sheet.");
        fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(medicalPayments_radioButtons),
                medicalPaymentsTitlesExpected.get(0), "Review quote page - Medical payments to others selected radio button value verification in the side-sheet");

        int expectedNumberOfCardDividers = isExtendedDRCCoveragePresent ? 5 : 4;
        fsa.assertEquals(editCoverageCardDividers.count(), expectedNumberOfCardDividers, "Review quote page - Edit primary coverages card dividers verification in the side-sheet.");
        clickCloseEditPrimaryCoveragesSideSheet();
        waitElementBeInvisible(editCoverageSideSheetTitle);
    }

    public String getPrimaryCoverageSelectedRadioButton(Locator radios) {
        return getPrimaryCoverageSelectedRadioButton(radios.all());
    }

    public String getPrimaryCoverageSelectedRadioButton(List<Locator> radios) {
        Locator weShortTitle = radios.stream().filter(r -> Objects.toString(r.getAttribute(CLASS), EMPTY_STRING).contains(RADIO_BUTTON_CHECKED)).findFirst().get();
        return getTextFromElement(weShortTitle.locator(pwXPath(".//p[1]")));
    }

    public void selectPrimaryCoverageRadioButton(Locator radios, int number) {
        selectPrimaryCoverageRadioButton(radios.all(), number);
    }

    public void selectPrimaryCoverageRadioButton(List<Locator> radios, int number) {
        scrollAndClickOnElement(radios.get(number));
        boolean isSelected = false;
        int radioSize = radios.size();
        for (int i = 0; i < radioSize; i++) {
            boolean radioSelected = getAttributeData(radios.get(i), CLASS).contains(RADIO_BUTTON_CHECKED);
            if (radioSelected && (number == i)) {
                isSelected = true;
                break;
            }
        }
        if (!isSelected) {
            scrollToElementBottom(radios.get(radios.size() - 1));
            waitAndClickElement(radios.get(number).locator(pwXPath(".//label")));
        }
    }

    public void validatePersonalPropertyLossSettlementValueToACV(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception {
        // update Personal property loss settlement to ACV and Recalculate
        openPrimaryCoveragesSideSheet();
        selectPrimaryCoverageRadioButton(personalPropertyLossSettlement_radioButtons, 0);
        waitAndClickElement(recalculatePrimaryCoveragesButton);
        Log.info("Clicked Recalculate button on Review quote page after updating Personal property loss settlement coverage.");
        new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        openPrimaryCoveragesSideSheet();
        fsa.assertTrue(getAttributeData(personalPropertyLossSettlement_radioButtons.nth(0), CLASS).contains(RADIO_BUTTON_CHECKED), "personal Property Loss Settlement ACV radio button is not selected");
    }

    public void updateVerifyPrimaryCoveragesInSideSheet(FarmersSoftAssert fsa, ApplicantAceHome applicant) throws Exception {
        openPrimaryCoveragesSideSheet();
        // Personal Property Loss Settlement value defaulted to ACV
        fsa.assertTrue(getAttributeData(personalPropertyLossSettlement_radioButtons.nth(0), CLASS).contains(RADIO_BUTTON_CHECKED), "personal Property Loss Settlement ACV radio button is selected by default");
        List<String> expectedPrimaryCoveragesTitles = getExpectedPrimaryCoveragesTitles();
        boolean isExtendedDRCCoveragePresent = expectedPrimaryCoveragesTitles.contains(EXTENDED_DWELLING_REPLACEMENT_COST);
        if (isExtendedDRCCoveragePresent) {
             fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(extendedDRC_radioButtons),
                    CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(getDwellingCoverageInInt(getSessionStorageAppStore()))),
                    "Review quote page - Extended dwelling replacement cost selected radio button value verification in the side-sheet.");
            // update Extended dwelling replacement cost
            selectPrimaryCoverageRadioButton(extendedDRC_radioButtons, 1);
        }
        // update Personal property limit
        selectPrimaryCoverageRadioButton(personalPropertyLimit_radioButtons, 1);
        // update Personal property loss settlement
        selectPrimaryCoverageRadioButton(personalPropertyLossSettlement_radioButtons, 1);
        // update Loss of use (Additional living expense limit)
        selectPrimaryCoverageRadioButton(lossOfUseLimit_radioButtons, 1);
        // update Personal liability
        selectPrimaryCoverageRadioButton(personalLiability_radioButtons, 2);
        // Reset the changes and verify
        waitAndClickElement(resetPrimaryCoveragesButton);
        waitAndClickElement(confirmResetButton);
        waitElementBeInvisible(confirmResetButton);
        if (isExtendedDRCCoveragePresent) {
            fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(extendedDRC_radioButtons), getTextFromElement(extendedDRC_radioButtons.nth(0).locator(pwXPath(".//p[1]"))),
                    "Review quote page - reset Dwelling coverage on side-sheet");
        }
        fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(personalPropertyLimit_radioButtons), getTextFromElement(personalPropertyLimit_radioButtons.nth(0).locator(pwXPath(".//p[1]"))),
                "Review quote page - reset Personal property limit coverage on side-sheet");
        fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(personalPropertyLossSettlement_radioButtons), getTextFromElement(personalPropertyLossSettlement_radioButtons.nth(0).locator(pwXPath(".//p[1]"))),
                "Review quote page - reset Personal property loss settlement coverage on side-sheet");
        fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(lossOfUseLimit_radioButtons), getTextFromElement(lossOfUseLimit_radioButtons.nth(0).locator(pwXPath(".//p[1]"))),
                "Review quote page - reset Loss of use coverage on side-sheet");
        fsa.assertEquals(getPrimaryCoverageSelectedRadioButton(personalLiability_radioButtons), getTextFromElement(personalLiability_radioButtons.nth(1).locator(pwXPath(".//p[1]"))),
                "Review quote page - reset Personal liability coverage on side-sheet");

        // update Primary coverages and Recalculate
        String selectedDwellingCoverage = EMPTY_STRING;
        if (isExtendedDRCCoveragePresent) {
            // update Extended dwelling replacement cost
            selectPrimaryCoverageRadioButton(extendedDRC_radioButtons, 1);
            selectedDwellingCoverage = getTextFromElement(extendedDRC_radioButtons.nth(1)).split(SPACE)[0];
        }
        // update Personal property limit
        selectPrimaryCoverageRadioButton(personalPropertyLimit_radioButtons, 1);
        String selectedPersonalPropertyLimitCoverage = getTextFromElement(personalPropertyLimit_radioButtons.nth(1)).split(SPACE)[0];
        // update Personal property loss settlement
        selectPrimaryCoverageRadioButton(personalPropertyLossSettlement_radioButtons, 1);
        String selectedPersonalPropertyLossSettlementCoverage = getTextFromElement(personalPropertyLossSettlement_radioButtons.nth(1));
        // update Loss of use (Additional living expense limit)
        selectPrimaryCoverageRadioButton(lossOfUseLimit_radioButtons, 1);
        String selectedLossOfUseLimitCoverage = getTextFromElement(lossOfUseLimit_radioButtons.nth(1)).split(SPACE)[0];
        // update Personal liability
        selectPrimaryCoverageRadioButton(personalLiability_radioButtons, 2);
        String selectedPersonalLiabilityCoverage = getTextFromElement(personalLiability_radioButtons.nth(2)).split(SPACE)[0];

        waitAndClickElement(recalculatePrimaryCoveragesButton);
        new AceHomeNavigationHelper().goToAceHomeReviewQuotePage(applicant);
        openPrimaryCoveragesSideSheet();

        if (isExtendedDRCCoveragePresent) {
            String dwellingCoverage = getCoverageAmountByName("Dwelling");
            List<String> dwCoverageAmount = Arrays.asList(dwellingCoverage.split("\\+"));
            double dwCoverageFound = convertCurrencyStringToDouble(dwCoverageAmount.get(0));
            if (dwCoverageAmount.size() > 1) {
                dwCoverageFound += convertCurrencyStringToDouble(dwCoverageAmount.get(1));
            }
            fsa.assertEquals(dwCoverageFound, convertCurrencyStringToDouble(selectedDwellingCoverage), "Review quote page - updated Dwelling coverage on main page");
        }

        String personalPropertyLimitCoverage = getCoverageAmountByName("Personal property");
        fsa.assertEquals(personalPropertyLimitCoverage, selectedPersonalPropertyLimitCoverage, "Review quote page - updated Personal property limit coverage on main page");

        String personalPropertyLossSettlementCoverage = getPrimaryCoverageFullDescriptionByName("Personal property").replace("Personal property",EMPTY_STRING)
                .split(";")[0].replace("(",EMPTY_STRING).replace("value",EMPTY_STRING).strip();
        fsa.assertEquals(personalPropertyLossSettlementCoverage, selectedPersonalPropertyLossSettlementCoverage, "Review quote page - updated Personal property loss settlement coverage on main page");

        String lossOfUseLimitCoverage = getCoverageAmountByName("Loss of use").split("\\(")[0].strip();
        fsa.assertEquals(lossOfUseLimitCoverage, selectedLossOfUseLimitCoverage, "Review quote page - updated Loss of use limit coverage on main page");

        String personalLiabilityCoverage = getCoverageAmountByName("Personal liability");
        fsa.assertEquals(personalLiabilityCoverage, selectedPersonalLiabilityCoverage, "Review quote page - updated Personal liability coverage on main page");
    }

    boolean isMineSubsidenceState(String stateCode) {
        return List.of(KY).contains(stateCode);
    }

    boolean isDiscountsTransparencyState(String stateCode) {
        return List.of(CO, ND, SD, VA).contains(stateCode);
    }

    // Variant 1 is applicable for AZ, and GA state.
    boolean isBundleDiscountStateV1(String stateCode) {
        return List.of(AZ, GA).contains(stateCode);
    }
    // Variant 2 is applicable for OR state
    boolean isBundleDiscountStateV2(String stateCode) {
        return List.of(OR).contains(stateCode);
    }

    public void validateSweepStakesPopup(FarmersSoftAssert fsa) {
        String SWEEPSTAKES_HEADING = "Thanks for completing your quote!";
        String SWEEPSTAKES_CONTENT = "Completing a quote allows you to enter the sweepstakes, provided you meet all sweepstakes eligibility requirements.";
        String SWEEPSTAKES_HELP_TEXT = "Entry is subject to the official rules.";
        fsa.assertEquals(getTextFromElement(sweepStakesHeading), SWEEPSTAKES_HEADING, "Sweepstakes popup title verification - Home Lob");
        fsa.assertEquals(getTextFromElement(sweepStakesContent), SWEEPSTAKES_CONTENT, "Sweepstakes popup content verification - Home Lob");
        fsa.assertEquals(getTextFromElement(sweepStakesHelpText), SWEEPSTAKES_HELP_TEXT, "Sweepstakes popup Help text is displayed - Home Lob");
        fsa.assertTrue(isElementDisplayed(sweepStakesOkButton, 2), "Sweepstakes popup Ok button is displayed - Home Lob");
        waitAndClickElement(sweepStakesOkButton);
        clickChangeCoverage();
    }

    public boolean isSweepStakesPopupDisplayed() {
        return isElementDisplayed(sweepStakesPopup, 5);
    }

}
