package com.farmers.ffq.ace.hrc.common;



import com.microsoft.playwright.Locator;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCPropertyTypeBasePage extends AceHRCBasePage {
    protected static final String PAGE_TITLE = "What type of property is it?";

        protected Locator pageTitle = locator(pwXPath("//app-property-type//h1"));

    protected static final String PROPERTY_TYPE_CARD_XPATH = "//app-property-type//app-image-card";
        protected Locator propertyTypeCard = locator(pwXPath(PROPERTY_TYPE_CARD_XPATH));

        protected Locator togglePartnerIcon = locator(pwXPath("//app-property-type//app-toggle-banner//div[contains(@class,'toggle-icon')]"));

        protected Locator togglePartnerText = locator(pwXPath("//app-property-type//app-toggle-banner//div[contains(@class,'toggle-text')]"));

    private static final List<String> PROPERTY_TYPES = Arrays.asList(HOME, TOWNHOME, DUPLEX, CONDO, OTHER);

    private static final List<String> PROPERTY_TYPE_DESCRIPTIONS = Arrays.asList("Single-family home that you own.",
            "Multi-story home attached to similar homes by shared walls.", "I own the entire structure, but only reside in one unit.",
            "Multi-unit building in which you own an individual unit.", "Any other home type that does not fit in the above categories.");

    /**
     * Default Constructor
     */
    public AceHRCPropertyTypeBasePage() throws Exception {
        super();
    }

    public boolean isOnPropertyTypePage() {
        return isOnPageCheck(Property.PAGELOADTIMEOUT);
    }

    public boolean quickIsOnPropertyTypePageCheck() {
        return isOnPageCheck(5);
    }

    private boolean isOnPageCheck(int secondsToWait) {
        return isElementPresent(pwXPath(PROPERTY_TYPE_CARD_XPATH), secondsToWait);
    }

    public boolean isPageTitleDisplayed() {
        return getTextFromElement(pageTitle).equals(PAGE_TITLE);
    }

    public boolean isPageTitleInViewport() throws Exception {
        return isElementInViewport(pageTitle);
    }

    public List<String> getPropertyTypeCards() throws Exception {
        return locators(pwXPath(PROPERTY_TYPE_CARD_XPATH + "//div[@id='cardHeading']")).stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public List<String> getPropertyTypeCardDescriptions() throws Exception {
        return locators(pwXPath(PROPERTY_TYPE_CARD_XPATH + "//div[@id='cardDescription']")).stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public List<String> getPropertyTypeCardImageAltDescriptions() throws Exception {
        return locators(pwXPath(PROPERTY_TYPE_CARD_XPATH + "//div[contains(@class,'image-container')]/img"))
                .stream().map(w -> getAttributeData(w, "alt")).collect(Collectors.toList());
    }

public void validatePageCards(FarmersSoftAssert sa, String origin) throws Exception {
        List<String> propertyTypeCards = new ArrayList<>(PROPERTY_TYPES);
        List<String> propertyTypeDescriptions = new ArrayList<>(PROPERTY_TYPE_DESCRIPTIONS);
        if (MEDIA_ALPHA.equals(origin)) {
            int index = propertyTypeCards.indexOf(CONDO);
            if (index >= 0) {
                propertyTypeCards.set(index, MOBILE_MANUFACTURED_HOME);
                propertyTypeDescriptions.set(index, "A prefabricated structure, built before being transported to site.");
            }
        }
        sa.assertEquals(getPropertyTypeCards(), propertyTypeCards, "Property Type page - Expected Property Type Cards are displayed.");
        sa.assertEquals(getPropertyTypeCardImageAltDescriptions(), propertyTypeCards, "Property Type page - Property Type Card Image Alt attributes match.");
        sa.assertEquals(getPropertyTypeCardDescriptions(), propertyTypeDescriptions, "Property Type page - Expected Property Type Card Descriptions are displayed.");
    }

    public void selectPropertyType(String propertyType) throws Exception {
        testStep("Selecting property type: " + propertyType);
        String propertyTypeCardXpath;
        propertyTypeCardXpath = PROPERTY_TYPE_CARD_XPATH + String.format("[contains(.,'%s')]//div[@data-test-id='IMAGE_CARD']/div", propertyType);
        Locator we = locator(pwXPath(propertyTypeCardXpath));
        waitAndClickElement(we);
        waitForSpinnerToBeGone();
    }

    public boolean isImageCardSelected(String propertyType) throws Exception {
        String propertyTypeCardXpath = PROPERTY_TYPE_CARD_XPATH + String.format("[contains(.,'%s')]//div[@data-test-id='IMAGE_CARD']", propertyType);
        Locator we = locator(pwXPath(propertyTypeCardXpath));
        return getAttributeData(we, CLASS).contains("selected");
    }

    public boolean isToggleBannerDisplayed() {
        return isElementDisplayed(togglePartnerIcon,1) && isElementDisplayed(togglePartnerText,1);
    }
}
