package com.farmers.ffq.auto.pages;



import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.utils.FarmersSoftAssert;
public class InterstitialBundlePage extends AutoBasePage {

        private Locator pageHeader = locator(pwId("bundlePageHeaderTitle"));
        private Locator pageSubTitle = locator(pwCss("div[class='bundle-page-title-savings bundle-page-title-font']"));
        private Locator bundleImage = locator(pwCss("img[class='auto-home-group-image']"));
        private Locator savingMessageUnderImage = locator(pwCss("div[class='bundle-page-promo-trust']>span"));
        private Locator savingSubMessageUnderImage = locator(pwCss("div[class='bundle-page-title-savings bundle-page-title-savings-font']>span"));
        private Locator continueWithBundleDiscountButton = locator(pwXPath("//div[@class='bundle-page__bundle-continue-button']//button"));
        private Locator continueWithAutoOnlyButton = locator(pwCss("button[data-tui-tracking-id='auto__continue-button-cta']"));
        private Locator pageDisclaimer = locator(pwXPath("//div[contains(@class,'bundle-page-disclaimer-section')]/span"));

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public InterstitialBundlePage() throws Exception {
    }

    public boolean isOnInterstitialBundlePage() {
        return isElementVisible(pageHeader, 10);
    }

    public void continueWithAutoMonoLine() {
        acceptCookies();
        waitAndClickElement(continueWithAutoOnlyButton);
        waitForSpinnerToBeGone();
    }

    public void continueWithBundle() {
        waitAndClickElement(continueWithBundleDiscountButton);
    }

    public void validatePageHeader(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(pageHeader), "Bundle and save", "Interstitial Page header is not as expected");
    }

    public void validateSubHeader(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(pageSubTitle), "You could save up to $810* when you bundle auto and home with Farmers®", "Interstitial Page sub header is not as expected");
    }

    public void validateImagePresent(FarmersSoftAssert softAssert) {
        softAssert.assertTrue(bundleImage.isVisible(), "Bundle image is not displayed on interstitial page");
        softAssert.assertFalse(getAttributeData(bundleImage, "src").isEmpty(), "Bundle image src attribute is empty");
    }

    public void validateSavingMessageUnderImage(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(savingMessageUnderImage), "Unlock substantial savings with quality coverage from a brand you can trust.", "Saving message under image is not as expected");
    }

    public void validateSavingSubMessageUnderImage(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(savingSubMessageUnderImage), "Ready to see how much you could save?", "Saving sub message under image is not as expected");
    }

    public void validateCtaTextForBundle(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(continueWithBundleDiscountButton), "Continue with bundle discount", "CTA text for continue with bundle discount button is not as expected");
    }

    public void validateCtaTextForAutoOnly(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(continueWithAutoOnlyButton), "Continue with auto only", "CTA text for continue with auto only button is not as expected");
    }

    public void validatePageDisclaimer(FarmersSoftAssert softAssert) {
        softAssert.assertEquals(getTextFromElement(pageDisclaimer), "* Based on average nationwide annual savings of new customers surveyed, excluding HI, SC & Farmers GroupSelect\u00ae, from 2/1/23 to 9/19/24 who switched their Home and Auto insurance policies to Farmers\u00ae branded policies, responded to the survey, and realized savings. Potential savings vary by customer and may vary by state and product.", "Page disclaimer text is not as expected");
    }

    public void validatePageContent(FarmersSoftAssert softAssert) {
        validatePageHeader(softAssert);
        validateSubHeader(softAssert);
        validateImagePresent(softAssert);
        validateSavingMessageUnderImage(softAssert);
        validateSavingSubMessageUnderImage(softAssert);
        validateCtaTextForBundle(softAssert);
        validateCtaTextForAutoOnly(softAssert);
        validatePageDisclaimer(softAssert);
    }
}
