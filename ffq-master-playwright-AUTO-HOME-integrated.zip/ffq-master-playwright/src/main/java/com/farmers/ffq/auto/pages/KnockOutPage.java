package com.farmers.ffq.auto.pages;



import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;

import static com.farmers.ffq.utils.GlobalVariables.*;

/**
 * Farmers Fast Quote (FFQ) - Knock Out Page - When Quote Requires Special Attention. 
 */
public class KnockOutPage extends BasePage  {
	
		private Locator knockOutHeader = locator(pwXPath("//*[@id='knock-out_header-title'] | //*[@class='knock-out_header-title']"));

		private Locator knockOutQuoteNumber = locator(pwXPath("//*[@id='knock-out_body_quote_number'] | //*[@class='knock-out_body_quote_number']"));
	
		private Locator agentPhoneNumber = locator(pwId("FFQAuto_Modal_discountOutAgentPhone"));
	
		private Locator emailAgentButton = locator(pwId("FFQAuto_Modal_discountOutMailBtn"));
	
		private Locator agentImage = locator(pwId("FFQAuto_Modal_discountOutAgentImg"));
	
		private Locator farmersDotComLink = locator(pwId("FFQAuto_Modal_discountOutGoToFarmersTag"));
	
		private Locator needmoreHelp = locator(pwId("knock-out_body_noagent"));

		private Locator callCustomerService = locator(pwId("knock-out_body_call-custome"));

		private Locator phoneNumber = locator(pwId("default-phone"));
	
		private Locator inconvenienceHeader = locator(pwId("FFQAuto_Commonpage_inconvHeader"));
	
		private Locator inconvenienceQuoteNumber = locator(pwXPath("//*[@class='qteNumber ng-binding']"));

		private Locator inconvenienceCallCustomerService = locator(pwId("FFQAuto_Commonpage_inconvContent"));

		private Locator invconveniencePhoneNumber = locator(pwId("FFQAuto_Commonpage_inconvPhone"));
	
		private Locator inconvenienceFarmersDotComLink = locator(pwId("FFQAuto_Commonpage_inconvFarmersLink"));

		private Locator restrictedKO_PageHeader = locator(pwId("knockout_title"));

		private Locator restrictedKO_body_content = locator(pwXPath("//app-knockout/form/p"));

		private Locator restrictedKO_agentPhoneNumber = locator(pwXPath("//app-agent-details//div/div[contains(@class,'agent-details-container')]/p/a[contains(@aria-label,'Contact farmers representative')]"));
	
	/**
	 * Constructor.
	 * @throws Exception 
	 */
	public KnockOutPage(String category) throws Exception {
		super();
		switch (category) {
		case SPECIAL_ATTENTION :
		case KNOCKOUT :
			waitElementBeVisible(knockOutHeader);
			break;
		case INCONVENIENCE :
			waitElementBeVisible(inconvenienceHeader);
			break;
			case AWS_REST_ZIP :
				waitElementBeVisible(restrictedKO_PageHeader);
				break;
		default :
			Log.warn("Unknown knockout category: " + category);
			break;
		}
	}
	
	public boolean isOnKnockOutPage() {
	    return isElementDisplayed(knockOutQuoteNumber, 5);
	}
	
	public boolean isOnInconveniencePage() {
	    return isElementDisplayed(inconvenienceQuoteNumber, 5);
	}
	
	public void verifyKnockoutPage(String category) {
		FarmersSoftAssert fsa = new FarmersSoftAssert();
		switch (category) {
		case SPECIAL_ATTENTION :
		case KNOCKOUT :
			fsa.assertTrue(getTextFromElement(knockOutHeader).contains("Your quote requires special attention"), "Knockout page title check");
			fsa.assertTrue(knockOutQuoteNumber.isVisible(), "Quote Number displayed");
			fsa.assertTrue(getTextFromElement(needmoreHelp).contains("Need more help?"), "\"Need more help?\" check");
			fsa.assertTrue(getTextFromElement(callCustomerService).contains("Call Customer Service"), "\"Call Customer Service\" check");
			fsa.assertTrue(getTextFromElement(phoneNumber).contains("1-800-206-9469"), "Customer service phone number check");
			break;
		case INCONVENIENCE :
			fsa.assertTrue(getTextFromElement(inconvenienceHeader).contains("We apologize for the inconvenience"), "Inconvenience page title check");
			fsa.assertTrue(inconvenienceQuoteNumber.isVisible(), "Quote Number check");
			fsa.assertTrue(getTextFromElement(inconvenienceCallCustomerService).contains("Farmers Fast Quote is currently experiencing connectivity errors. We appreciate your patience as we work to resolve this problem. Please try again later and reference your quote number"), "Call Customer Service text check");
			fsa.assertTrue(getTextFromElement(inconvenienceFarmersDotComLink).contains("Go to Farmers.com"), "\"Go to Farmers.com\" link check");
			fsa.assertTrue(getTextFromElement(invconveniencePhoneNumber).contains("(800) 206-9469"), "Customer service phone number check");
			break;
			case AWS_REST_ZIP :
				fsa.assertEquals(getTextFromElement(restrictedKO_PageHeader), "Your quote requires special attention","User landed On AWSREST_KO page");
				fsa.assertEquals(getTextFromElement(restrictedKO_body_content),"Online quotes are not available at this time. Please contact your agent for a quote.", "Text content cehck");
				fsa.assertEquals(getTextFromElement(restrictedKO_agentPhoneNumber), "(248) 468-0222", "Phone number check");
				break;
		default :
			fsa.fail("Unexpected knockout page reached from category: " + category);
			break;
		}
		fsa.assertAll();
	}
}
