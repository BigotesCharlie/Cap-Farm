package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.farmers.ffq.homevideoflow.support.DomArtifacts;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;
import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.WaitForSelectorState;

import java.util.LinkedHashMap;
import java.util.Map;

public final class PropertySummaryPage extends BaseHomePage {
    private final DomArtifacts artifacts;

    public PropertySummaryPage(Page page) {
        this(page, null);
    }

    public PropertySummaryPage(Page page, DomArtifacts artifacts) {
        super(page);
        this.artifacts = artifacts;
    }

    public void applyVideoEditsAndContinue(VideoScenarioData d) {
        waitForBodyReady();
        waitForSpinnerToClear();
        PlaywrightAssertions.assertThat(page.getByText(d.address(), new Page.GetByTextOptions().setExact(false)).first()).isVisible();
        captureBeforeEdit();

        Locator edit = page.getByText("Edit details", new Page.GetByTextOptions().setExact(false));
        if (edit.count() == 0) {
            throw new IllegalStateException("Edit details control not found");
        }
        edit.first().click(new Locator.ClickOptions().setForce(true));

        page.waitForFunction(
                "() => {" +
                        "const text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();" +
                        "return text.includes('year built')" +
                        " || text.includes('fire sprinkler system')" +
                        " || text.includes('save changes')" +
                        " || text.includes('done');" +
                        "}",
                null,
                new Page.WaitForFunctionOptions().setTimeout(15_000)
        );
        captureEditorOpen();

        Map<String, String> edits = new LinkedHashMap<>();
        edits.put("Year built", d.yearBuilt());
        edits.put("Total finished sq. ft", d.finishedSqFt());
        edits.put("Stories", d.stories());
        edits.put("Bathrooms", d.bathrooms());
        edits.put("Fireplace", d.fireplace());
        edits.put("Floors", d.floors());
        edits.put("Garage style", d.garageStyle());
        edits.put("Garage / carport", d.garageCapacity());
        edits.put("Exterior wall finish", d.exteriorWall());
        edits.put("Foundation type", d.foundation());
        edits.put("Finished basement", d.finishedBasement());
        edits.put("Roof cover", d.roofCover());
        edits.put("Type of home", d.typeOfHome());
        edits.put("Fire sprinkler system", d.fireSprinkler());

        for (Map.Entry<String, String> entry : edits.entrySet()) {
            editDrawerField(entry.getKey(), entry.getValue());
        }

        if (artifacts != null) {
            artifacts.captureNamed("property-summary-after-edit");
        }

        Locator close = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Close").setExact(false));
        if (close.count() > 0) {
            close.first().click(new Locator.ClickOptions().setForce(true));
        }

        assertSummaryValue(d.yearBuilt());
        assertSummaryValue(d.finishedSqFt());
        assertSummaryValue(d.roofCover());

        if (artifacts != null) {
            artifacts.captureNamed("property-summary-before-continue");
        }

        Locator continueButton = button("Continue");
        if (continueButton.count() > 0) {
            clickDom(continueButton.first());
        } else {
            Locator continueText = page.getByText("Continue", new Page.GetByTextOptions().setExact(false));
            if (continueText.count() > 0) {
                clickDom(continueText.first());
            } else {
                throw new IllegalStateException("Continue button not found @ " + page.url());
            }
        }
        page.waitForFunction(
                "() => {" +
                        "const u = document.location.href.toLowerCase();" +
                        "const text = (document.body && document.body.innerText ? document.body.innerText : '').toLowerCase();" +
                        "return text.includes('additional home information')" +
                        " || text.includes('about you')" +
                        " || text.includes('custom-coverage')" +
                        " || text.includes('loading')" +
                        " || text.includes('one moment, please')" +
                        " || text.includes('try again')" +
                        " || text.includes(\"we're sorry, we can't finish\")" +
                        " || u.includes('inconvenience') || u.includes('knockout');" +
                        "}",
                null,
                new Page.WaitForFunctionOptions().setTimeout(30_000)
        );
    }

    private void editDrawerField(String label, String value) {
        Locator row = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName(label).setExact(false));
        if (row.count() == 0) {
            row = page.getByText(label, new Page.GetByTextOptions().setExact(true));
        }
        if (row.count() == 0) {
            System.out.printf("[VIDEO FLOW] Drawer field not present/required: %s%n", label);
            return;
        }
        openSubEditor(row.last());
        captureFieldOpen(label);

        Locator field = activeEditorField();
        if (field.count() > 0) {
            if ("Bathrooms".equals(label)) {
                setBathroomCounts(value);
                captureBeforeSave(label);
                saveAndCloseSubEditor();
                return;
            }
            String normalized = value.replace(",", "");

            if ("Year built".equals(label)) {
                field.first().click(new Locator.ClickOptions().setForce(true));
                field.first().press("Control+A");
                field.first().press("Backspace");
                field.first().type(normalized, new Locator.TypeOptions().setDelay(80));
                selectYearBuiltSuggestionOrThrow(normalized);
            } else {
                field.first().fill(normalized);
                page.waitForTimeout(300);
                Locator overlayOption = page.getByRole(AriaRole.OPTION, new Page.GetByRoleOptions().setName(normalized).setExact(false));
                if (overlayOption.count() > 0 && overlayOption.last().isVisible()) {
                    overlayOption.last().click(new Locator.ClickOptions().setForce(true));
                    System.out.printf("[VIDEO FLOW] Clicked overlay option '%s' for field '%s'%n", normalized, label);
                } else {
                    Locator suggestionText = page.getByText(normalized, new Page.GetByTextOptions().setExact(true));
                    if (suggestionText.count() > 0 && suggestionText.last().isVisible()) {
                        suggestionText.last().click(new Locator.ClickOptions().setForce(true));
                        System.out.printf("[VIDEO FLOW] Clicked suggestion '%s' for field '%s'%n", normalized, label);
                    } else {
                        field.first().press("ArrowDown");
                        field.first().press("Enter");
                    }
                }
            }
             
            // Brief pause for the dropdown to close and the Update button to appear
            page.waitForTimeout(500);
            
            System.out.printf("[VIDEO FLOW] Property editor field '%s' value now='%s'%n", label, safeValue(field.first()));
            captureBeforeSave(label);
            saveAndCloseSubEditor();
            return;
        }

        if (value.contains(",")) {
            for (String part : value.split(",")) {
                selectOptionIfAvailable(part.trim());
            }
            Locator done = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Done").setExact(false));
            if (done.count() > 0) {
                done.first().click(new Locator.ClickOptions().setForce(true));
            }
            saveAndCloseSubEditor();
            return;
        }

        selectOptionIfAvailable(value);
        saveAndCloseSubEditor();
    }

    private void selectOptionIfAvailable(String value) {
        Locator dialog = activeDialog();
        Locator exactValueInput = dialog.locator("input[value=\"" + cssValue(value) + "\"]");
        if (exactValueInput.count() > 0) {
            String inputId = exactValueInput.first().getAttribute("id");
            if (inputId != null && !inputId.isBlank()) {
                Locator label = dialog.locator("label[for='" + inputId + "']");
                if (label.count() > 0) {
                    System.out.printf("[VIDEO FLOW] Clicking LABEL for value: %s%n", value);
                    label.first().click(new Locator.ClickOptions().setForce(true));
                    return;
                }
            }
            System.out.printf("[VIDEO FLOW] Clicking INPUT for value: %s%n", value);
            exactValueInput.first().evaluate("el => el.click()");
            return;
        }

        if (checkCheckboxByLabel(dialog, value)) {
            return;
        }

        Locator exactText = dialog.getByText(value, new Locator.GetByTextOptions().setExact(true));
        if (exactText.count() > 0) {
            System.out.printf("[VIDEO FLOW] Clicking EXACT TEXT for value: %s%n", value);
            exactText.first().click(new Locator.ClickOptions().setForce(true));
            return;
        }

        Locator role = dialog.getByRole(AriaRole.RADIO, new Locator.GetByRoleOptions().setName(value).setExact(true));
        if (role.count() > 0) {
            System.out.printf("[VIDEO FLOW] Selecting RADIO for value: %s%n", value);
            role.first().click(new Locator.ClickOptions().setForce(true));
            return;
        }

        Locator checkbox = dialog.getByRole(AriaRole.CHECKBOX, new Locator.GetByRoleOptions().setName(value).setExact(true));
        if (checkbox.count() > 0) {
            if (!checkbox.first().isChecked()) {
                System.out.printf("[VIDEO FLOW] Checking CHECKBOX for value: %s%n", value);
                checkbox.first().check(new Locator.CheckOptions().setForce(true));
            }
            return;
        }

        Locator text = dialog.getByText(value, new Locator.GetByTextOptions().setExact(false));
        if (text.count() > 0) {
            System.out.printf("[VIDEO FLOW] Clicking TEXT for value: %s (found %d matches)%n", value, text.count());
            text.last().click(new Locator.ClickOptions().setForce(true));
            return;
        }

        System.out.printf("[VIDEO FLOW] WARNING: Could not select drawer option '%s' at %s%n", value, page.url());
    }

    private boolean checkCheckboxByLabel(Locator dialog, String value) {
        Locator checkboxes = dialog.locator("input[type='checkbox']");
        if (checkboxes.count() == 0) {
            return false;
        }

        Locator labels = dialog.locator("label");
        for (int i = 0; i < labels.count(); i++) {
            Locator label = labels.nth(i);
            if (!safeVisible(label)) continue;
            if (!safeText(label).trim().equalsIgnoreCase(value)) continue;
            if (i >= checkboxes.count()) continue;

            Locator checkbox = checkboxes.nth(i);
            if (!checkbox.isChecked()) {
                System.out.printf("[VIDEO FLOW] Checking CHECKBOX by label for value: %s%n", value);
                checkbox.check(new Locator.CheckOptions().setForce(true));
            }
            return true;
        }
        return false;
    }

    private void selectYearBuiltSuggestionOrThrow(String normalized) {
        page.waitForTimeout(600);

        Locator overlayOptions = page.locator(
                ".cdk-overlay-pane [role='option']:visible, " +
                        ".cdk-overlay-pane mat-option:visible, " +
                        ".cdk-overlay-pane .mat-mdc-option:visible, " +
                        ".cdk-overlay-pane .mdc-list-item:visible"
        ).filter(new Locator.FilterOptions().setHasText(normalized));
        if (overlayOptions.count() > 0) {
            overlayOptions.first().click(new Locator.ClickOptions().setForce(true));
        } else {
            Locator exactSuggestion = page.getByText(normalized, new Page.GetByTextOptions().setExact(true));
            if (exactSuggestion.count() > 0 && exactSuggestion.first().isVisible()) {
                exactSuggestion.first().click(new Locator.ClickOptions().setForce(true));
            } else {
                Locator field = activeEditorField();
                field.first().press("ArrowDown");
                page.waitForTimeout(200);
                field.first().press("Enter");
            }
        }

        Locator update = activeDialog().getByRole(AriaRole.BUTTON, new Locator.GetByRoleOptions().setName("Update").setExact(false));
        if (update.count() > 0) {
            try {
                update.first().waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE).setTimeout(5_000));
            } catch (RuntimeException ignored) {
                // Throw the detailed error below if Update never becomes visible.
            }
        }
        if (update.count() == 0 || !update.first().isVisible()) {
            throw new IllegalStateException("Year built suggestion did not produce Update control @ " + page.url());
        }
    }

    private void setBathroomCounts(String value) {
        String trimmed = value == null ? "" : value.trim();
        String fullBaths = trimmed;
        if ("2".equals(trimmed)) {
            fullBaths = "2";
        }
        fillFieldById("Full baths_input", fullBaths);
        fillFieldById("1/2 baths_input", "0");
        fillFieldById("3/4 baths_input", "0");
        fillFieldById("1-1/2 baths_input", "0");
    }

    private void fillFieldById(String id, String value) {
        Locator field = activeDialog().locator("input[id='" + id.replace("'", "\\'") + "']");
        if (field.count() == 0) {
            return;
        }
        field.first().fill(value);
        field.first().press("Tab");
    }

    private void assertSummaryValue(String value) {
        Locator l = page.getByText(value, new Page.GetByTextOptions().setExact(false));
        if (l.count() > 0) {
            PlaywrightAssertions.assertThat(l.first()).isVisible();
        }
    }

    private void clickDom(Locator locator) {
        locator.evaluate("el => { el.scrollIntoView({block: 'center', inline: 'center'}); el.click(); }");
    }

    private void captureBeforeEdit() {
        if (artifacts == null) return;
        artifacts.captureNamed("property-summary-before-edit");
        artifacts.writeText("property-summary-before-edit-controls.txt", summarizeControls(page.locator("body")));
    }

    private void captureEditorOpen() {
        if (artifacts == null) return;
        artifacts.captureNamed("property-summary-editor-open");
        artifacts.writeText("property-summary-editor-controls.txt", summarizeControls(activeDialog()));
    }

    private Locator activeDialog() {
        Locator dialog = page.locator("mat-dialog-container:visible");
        if (dialog.count() > 0) {
            return dialog.last();
        }
        return page.locator("body");
    }

    private Locator activeEditorField() {
        Locator dialog = activeDialog();
        Locator field = dialog.locator("input:not([type='radio']):not([type='checkbox']):visible, textarea:visible, select:visible, [contenteditable='true']:visible");
        if (field.count() > 0) {
            return field.last();
        }
        return page.locator("_never_");
    }

    private void saveAndCloseSubEditor() {
        Locator update = activeDialog().getByRole(AriaRole.BUTTON, new Locator.GetByRoleOptions().setName("Update").setExact(false));
        if (update.count() > 0 && update.last().isVisible()) {
            clickDom(update.last());
            page.waitForTimeout(500);
            if (page.locator("#tui-subcategory-modal-close-button:visible").count() == 0) {
                return;
            }
            Locator backAfterUpdate = page.locator("#tui-subcategory-modal-go-back-button:visible");
            if (backAfterUpdate.count() > 0) {
                clickDom(backAfterUpdate.last());
                waitForSubEditorClose();
                return;
            }
            waitForSubEditorClose();
            return;
        }

        Locator done = activeDialog().getByRole(AriaRole.BUTTON, new Locator.GetByRoleOptions().setName("Done").setExact(false));
        if (done.count() > 0 && done.last().isVisible()) {
            done.last().click(new Locator.ClickOptions().setForce(true));
            waitForSubEditorClose();
            return;
        }

        Locator back = page.locator("#tui-subcategory-modal-go-back-button:visible");
        if (back.count() > 0) {
            clickDom(back.last());
            waitForSubEditorClose();
            return;
        }

        Locator close = page.locator("#tui-subcategory-modal-close-button:visible");
        if (close.count() > 0) {
            clickDom(close.last());
            waitForSubEditorClose();
        }
    }

    private void waitForSubEditorClose() {
        page.locator("#tui-subcategory-modal-close-button")
                .waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN).setTimeout(10_000));
    }

    private void openSubEditor(Locator row) {
        row.click(new Locator.ClickOptions().setForce(true));
        if (!waitForSubEditorOpen(2_000)) {
            clickDom(row);
            if (!waitForSubEditorOpen(3_000)) {
                Locator icon = row.locator("mat-icon");
                if (icon.count() > 0) {
                    icon.last().click(new Locator.ClickOptions().setForce(true));
                    if (!waitForSubEditorOpen(3_000)) {
                        throw new IllegalStateException("Sub-editor did not open for " + safeText(row));
                    }
                } else {
                    throw new IllegalStateException("Sub-editor did not open for " + safeText(row));
                }
            }
        }
    }

    private boolean waitForSubEditorOpen(int timeoutMs) {
        try {
            page.waitForFunction(
                    "() => !!document.getElementById('tui-subcategory-modal-close-button')",
                    null,
                    new Page.WaitForFunctionOptions().setTimeout(timeoutMs)
            );
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    private void captureFieldOpen(String label) {
        if (artifacts == null) return;
        String base = "property-summary-field-" + sanitize(label);
        artifacts.captureNamed(base);
        artifacts.writeText(base + "-controls.txt", summarizeControls(activeDialog()));
    }

    private void captureBeforeSave(String label) {
        if (artifacts == null) return;
        String base = "property-summary-before-save-" + sanitize(label);
        artifacts.captureNamed("property-summary-before-save");
        artifacts.captureNamed(base);
        artifacts.writeText(base + "-controls.txt", summarizeControls(activeDialog()));
    }

    private String summarizeControls(Locator scope) {
        StringBuilder out = new StringBuilder();
        appendGroup(out, scope, "input", "input");
        appendGroup(out, scope, "select", "select");
        appendGroup(out, scope, "textarea", "textarea");
        appendGroup(out, scope, "button", "button");
        appendGroup(out, scope, "role=button", "[role='button']");
        appendGroup(out, scope, "role=radio", "[role='radio']");
        appendGroup(out, scope, "role=checkbox", "[role='checkbox']");
        appendGroup(out, scope, "label", "label");
        return out.toString();
    }

    private void appendGroup(StringBuilder out, Locator scope, String tag, String selector) {
        Locator group = scope.locator(selector);
        for (int i = 0; i < group.count(); i++) {
            Locator el = group.nth(i);
            if (!safeVisible(el)) continue;
            out.append(describe(tag, el)).append('\n');
        }
    }

    private String describe(String tag, Locator el) {
        return String.join(" | ",
                "tag=" + tag,
                "text=" + safeText(el),
                "id=" + safeAttr(el, "id"),
                "name=" + safeAttr(el, "name"),
                "formControlName=" + safeAttr(el, "formcontrolname"),
                "placeholder=" + safeAttr(el, "placeholder"),
                "aria-label=" + safeAttr(el, "aria-label"),
                "aria-checked=" + safeAttr(el, "aria-checked"),
                "aria-selected=" + safeAttr(el, "aria-selected"),
                "aria-expanded=" + safeAttr(el, "aria-expanded"),
                "disabled=" + safeAttr(el, "disabled"),
                "value=" + safeValue(el)
        );
    }

    private String safeAttr(Locator el, String name) {
        try {
            String value = el.getAttribute(name);
            return value == null ? "" : value;
        } catch (RuntimeException e) {
            return "";
        }
    }

    private String safeValue(Locator el) {
        try {
            return el.inputValue();
        } catch (RuntimeException e) {
            return "";
        }
    }

    private String safeText(Locator el) {
        try {
            String value = el.textContent();
            return value == null ? "" : value.replace('\n', ' ').trim();
        } catch (RuntimeException e) {
            return "";
        }
    }

    private boolean safeVisible(Locator el) {
        try {
            return el.isVisible();
        } catch (RuntimeException e) {
            return false;
        }
    }

    private String cssValue(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private String sanitize(String value) {
        return value.toLowerCase().replaceAll("[^a-z0-9]+", "-").replaceAll("(^-|-$)", "");
    }
}
