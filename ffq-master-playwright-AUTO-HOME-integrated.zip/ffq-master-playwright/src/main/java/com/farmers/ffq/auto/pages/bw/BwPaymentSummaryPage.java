package com.farmers.ffq.auto.pages.bw;






import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
import com.farmers.ffq.auto.pages.bindpages.AutoPolicyPaymentBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.ffq.utils.PaymentMethods;
import com.farmers.framework.report.Log;
import org.apache.commons.lang.RandomStringUtils;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCPaymentBasePage.*;
import static com.farmers.ffq.utils.GlobalVariables.CLASS;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class BwPaymentSummaryPage extends AutoPolicyPaymentBasePage {

    public static final String SET_UP_PAYMENT_METHOD = "Set up payment method";
    public static final String FIRST_MONTHLY_PAYMENT_INCLUDES_ALL_POLICY_FEES = "First monthly payment (includes all policy fees)";

        private Locator pageHeader = locatorAny(
                pwXPath("//app-payment-overview//h1"),
                pwXPath("//div[contains(@class,'payment-overview')]//h1"));
        private Locator rateAdjustmentMessage = locator(pwXPath("//div[@class='tui-input-text payment-overview-sub-para tui-stacking-bottom-xl ng-star-inserted']"));
        private Locator changeYourCoverageLink = locator(pwCss("a[data-gtm='Auto_Bind_Payplan_CustomCoverage_link']"));
        private Locator leftRightScrollButton = locator(pwXPath("//button[contains(@class,'mat-tab-header-pagination') and not(contains(@class,'disabled'))]"));
        private Locator discountTitle = locator(pwXPath("//div[@class='discount-description']//p[1]"));
        private Locator quoteNumberElement = locator(pwXPath("//div[contains(@class,'auto-agent-details__save-quote')]//span"));
        private Locator sixMonthTermPrice = locator(pwCss("div[class='tui-body-text-bold monthly-autopay-details-header']>span"));

    // app-rate-change-notification component locators
        private Locator appRateChangeNotificationHeader = locator(pwXPath("//app-rate-change-notification//h2"));
        private Locator appRateChangeNotificationDescription = locator(pwXPath("//app-rate-change-notification//p"));
        private Locator appRateChangeNotificationTermLabel = locator(pwXPath("//app-rate-change-notification//div[@class='term-label']"));
        private Locator appRateChangeNotificationOkButton = locator(pwXPath("//app-rate-change-notification//button[@class='ok-button']"));


    //xpath variables for the content of the payment cards:
    private String PAYMENT_CARD_HEADER_XPATH = "//div[@class='tui-presentment-card-header-row-1 ng-star-inserted']//h2";
    private String PAYMENT_CARD_SUB_HEADER_XPATH = "//div[@class='tui-presentment-card-header-row-1 ng-star-inserted']//p";
    private String PAYMENT_DESCRIPTION_XPATH = "//div[@class='tui-presentment-card-header-row-2']/p";
    private String DOLLAR_SIGN_XPATH = "//div[@class='tui-payplan']/div[1]";
    private String DOLLAR_AMOUNT_XPATH = "//div[@class='tui-payplan']/div[2]";
    private String DOLLAR_CENT_XPATH = "//div[@class='tui-payplan']/div[3]";
    private String SELECT_AND_SIGN_DOCUMENTS_XPATH = "//button[contains(.,'Select & sign documents')]";
    private String DIVIDER_ONE_XPATH = "//mat-divider[1]";
    private String PAYMENT_OVERVIEW_ICON_XPATH = "//mat-icon[@class='mat-icon notranslate payment-overview-green-mark material-icons mat-icon-no-color']";
    private String PAYMENT_OVERVIEW_MESSAGE_XPATH = "//p[@class='tui-small-text payment-overview-icon-padding']";
    private String DUE_TODAY_AMOUNT_TEXT_XPATH = "//div[contains(@class,'card-section-2')]/p[1]";
    private String SERVICE_CHARGE_MESSAGE_XPATH = "//p[contains(.,'service charge')]";
    private String DIVIDER_TWO_XPATH = "//mat-divider[2]";
    private String SIX_MONTH_TOTAL_TERM_TEXT_XPATH = "//div[@class='tui-card-content-section']/p[1]";
    private String INCLUDE_ALL_FEES_TEXT_XPATH = "//div[@class='tui-card-content-section']/p[2]";
    private String BANK_DEBIT_CREDIT_MESSAGE_XPATH = "//p[@class='tui-caption-text tui-stacking-top-sm ng-star-inserted']";
    private String BOTTOM_TOTAL_PRICE_XPATH = "//div[contains(@class,'payment-overview-card-premium-font payment-overview-card-downpayment')]";
    private String MONTHLY_AUTOPAY_DOWNPAYMENT_MESSAGE_XPATH = "//p[contains(@class,'tui-caption-text payment-overview-payment-debit')]";


    // Payment addition page locators
    // Pay in full

        private Locator pifPageSubHeader = locator(pwXPath("//app-full-auto-pay//h2"));
        private Locator pifSixMonthTermPriceLabel = locator(pwXPath("//section[@class='pif-autopay-details']/div[1]/span[@class='tui-body-bold']"));
        private Locator sixTermPaymentIncludingAllFeesLabel = locator(pwXPath("//div[@class='pif-autopay-fees']/div/span[1]"));
        private Locator sixTermPaymentIncludingAllFeesAmount = locator(pwXPath("//div[@class='pif-autopay-fees']/div/span[2]"));
        private Locator pifDueTodayIncludesAllFeesLabel = locator(pwXPath("//div[contains(@class,'pif-autopay-details-bottom')]/span[1]"));
        private Locator pifDueTodayIncludesAllFeesAmount = locator(pwXPath("//div[contains(@class,'pif-autopay-details-bottom')]/span[2]"));
        private Locator pifAddPreferredPaymentMethodHeader = locator(pwXPath("//section[contains(@class,'pif-autopay-selection')]/span[1]"));
        private Locator pifUseBankDebitCreditCardBulletPoint = locator(pwXPath("//section[contains(@class,'pif-autopay-selection')]//ul/li[1]"));
        private Locator pifNoServiceChargeWhenYouPayInFullBulletPoint = locator(pwXPath("//section[contains(@class,'pif-autopay-selection')]//ul/li[2]"));
        private Locator pifSetUpPaymentMethodButton = locator(pwXPath("//section[contains(@class,'pif-autopay-selection')]//button"));
        private Locator pifPaymentCardAddedLabel = locator(pwXPath("//section[contains(@class,'pif-autopay-payment-confirmation')]/div[1]/span"));
        private Locator pifPaymentCardAddedGreenMatIcon = locator(pwXPath("//section[contains(@class,'pif-autopay-payment-confirmation')]/div[1]/mat-icon"));
        private Locator pifNoServiceChargeLabel = locator(pwXPath("//p[contains(@class,'pif-autopay-disclaimers-charge-text')]"));
        private Locator pifAddedPaymentIcon = locator(pwXPath("//div[@class='pif-autopay-disclaimers-charge-info']/img"));
        private Locator pifAddedPaymentMethodMaskedNumbersAndExpDate = locator(pwXPath("//div[@class='pif-autopay-disclaimers-charge-info']/span"));
        private Locator pifAddedPaymentMethodChangeButton = locator(pwXPath("//div[@class='pif-autopay-disclaimers-charge-info']/a"));
        private Locator pifDisclaimerTextHeader = locator(pwXPath("//section[contains(@class,'pif-autopay-disclaimers-text')]/div"));
        private Locator pifDisclaimerTextBulletPointOne = locator(pwXPath("//section[contains(@class,'pif-autopay-disclaimers-text')]/ul/li[1]"));
        private Locator pifDisclaimerTextBulletPointTwo = locator(pwXPath("//section[contains(@class,'pif-autopay-disclaimers-text')]/ul/li[2]"));
        private Locator pifOneTimeAndRecurringPaymentRadioButtonInput = locator(pwXPath("//section[contains(@class,'pif-autopay-disclaimers-text')]/mat-radio-group/mat-radio-button[1]//input"));
        private Locator pifOneTimeAndRecurringPaymentRadioButtonLabel = locator(pwXPath("//section[contains(@class,'pif-autopay-disclaimers-text')]/mat-radio-group/mat-radio-button[1]//span[@class='mat-radio-label-content']"));
        private Locator pifOneTimeOnlyPaymentRadioButtonInput = locator(pwXPath("//section[contains(@class,'pif-autopay-disclaimers-text')]/mat-radio-group/mat-radio-button[2]//input"));
        private Locator pifOneTimeOnlyPaymentRadioButtonLabel = locator(pwXPath("//section[contains(@class,'pif-autopay-disclaimers-text')]/mat-radio-group/mat-radio-button[2]//span[@class='mat-radio-label-content']"));
        private Locator pifDisclaimerFinalText = locator(pwXPath("//p[contains(@class,'tui-input-text pif-autopay-disclaimers-final-text')]"));

    // Payment addition page locators
    // Monthly autopay bank

        private Locator monthlyAutoPayBankPageSubHeader = locator(pwXPath("//app-monthly-auto-pay//h2"));
        private Locator monthlyAutoPayBankSixMonthTermPriceLabel = locator(pwXPath("//div[contains(@class,'monthly-autopay-details-header')]"));
        private Locator monthlyAutoPayBankSixTermPaymentIncludingAllFeesLabel = locator(pwXPath("//div[contains(@class,'monthly-autopay-fees-row')]/p[1]"));
        private Locator monthlyAutoPayBankSixTermPaymentIncludingAllFeesAmount = locator(pwXPath("//div[contains(@class,'monthly-autopay-fees-row')]/p[2]"));
        private Locator monthlyAutoPayBankDueTodayIncludesAllFeesLabel = locator(pwXPath("//div[contains(@class,'monthly-autopay-details-bottom-row')]/p[1]"));
        private Locator monthlyAutoPayBankDueTodayIncludesAllFeesAmount = locator(pwXPath("//div[contains(@class,'monthly-autopay-details-bottom-row')]/span"));
        private Locator monthlyAutoPayCardDueTodayIncludesAllFeesAmount = locator(pwXPath("//div[contains(@class,'monthly-autopay-details-bottom-row')]/span"));
        private Locator monthlyAutoPayBankDownPaymentHeader = locator(pwXPath("//span[contains(.,'Down payment')]"));
        private Locator monthlyAutoPayBankFuturePaymentsSectionHeader = locator(pwXPath("//span[contains(.,'Future payments')]"));
        private Locator monthlyAutoPayBankDownPaymentAndFuturePaymentsBoldDescriptions = locator(pwXPath("//p[contains(@class,'monthly-autopay-selection-header')]"));
        private Locator monthlyAutoPayBankDownPaymentAndFuturePaymentsBulletPointsDescriptions = locator(pwXPath("//div[@class='monthly-autopay-selection-sub-section']"));
        private Locator monthlyAutoPayBankDownPaymentSetUpPaymentMethodButton = locator(pwXPath("//section[contains(@class,'monthly-autopay-selection')]//button"));
        private Locator monthlyAutoPayBankAddedAccountMessages = locator(pwXPath("//div[contains(@class,'monthly-autopay-disclaimers-header')]//span"));
        private Locator monthlyAutoPayBankAddedAccountGreenChecks = locator(pwXPath("//div[contains(@class,'monthly-autopay-disclaimers-header')]//mat-icon"));
        private Locator monthlyAutoPayBankDownPaymentAddedCreditCardIcon = locator(pwXPath("//div[@class='monthly-autopay-disclaimers-details']//img"));
        private Locator monthlyAutoPayBankAddedAccountNumbers = locator(pwXPath("//span[contains(@class,'monthly-autopay-disclaimers-account-numbers')]"));
        private Locator monthlyAutoPayBankChangeLinks = locator(pwXPath("//section[contains(@class,'monthly-autopay-payment')]//a"));

    // Payment addition page locators
    // Monthly direct bill


        private Locator monthlyDirectBillPageSubHeader = locator(pwXPath("//app-monthly-auto-pay//h2"));
        private Locator monthlyDirectBillSixMonthTermPriceLabel = locator(pwXPath("//div[contains(@class,'monthly-autopay-details-header')]"));
        private Locator monthlyDirectBillFirstMonthlyPaymentIncludingAllFeesLabel = locator(pwXPath("//div[contains(@class,'monthly-autopay-fees-row')]/p[1]"));
        private Locator monthlyDirectBillFirstMonthlyPaymentIncludingAllFeesAmount = locator(pwXPath("//div[contains(@class,'monthly-autopay-fees-row')]/p[2]"));
        private Locator monthlyDirectBillDueTodayIncludesAllFeesLabel = locator(pwXPath("//div[contains(@class,'monthly-autopay-details-bottom-row')]/p[1]"));
        private Locator monthlyDirectBillDueTodayIncludesAllFeesAmount = locator(pwXPath("//div[contains(@class,'monthly-autopay-details-bottom-row')]/span"));


    // Payment declined pop up locators
        private Locator paymentDeclinedModalHeader = locator(pwXPath("//app-payment-decline-modal//h4"));
        private Locator paymentDeclinedModalMessages = locator(pwXPath("//app-payment-decline-modal//p[@class='tui-body']"));
        private Locator paymentDeclinedModalOkButton = locator(pwXPath("//app-payment-decline-modal//button"));


    // Next:Sign Documents button
        private Locator nextSignDocumentButton = locator(pwCss("button[class='pov2__next-btn tui-btn tui-btn-primary']"));

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public BwPaymentSummaryPage() throws Exception {
    }

    public boolean isOnBwPaymentSummaryPage() {
        return isElementVisible(pageHeader, 60);
    }

    public boolean isOnAutoPolicyPaymentPage() {
        return isElementVisible(autoPolicyPaymentHeader, 45);
    }

    public void processBwPaymentSummaryPage(String paymentMethod) throws Exception {
        testStepAssert(isOnBwPaymentSummaryPage(), "User landed on the BW payment Summary page", true);
        isElementPresent(pwXPath(getSelectAndSignDocumentsElementXpath(paymentMethod)), 10);
        clickElement(locator(pwXPath(getSelectAndSignDocumentsElementXpath(paymentMethod))));
        clickNextSignDocumentButtonIfPresent();
    }

    public void clickNextSignDocumentButtonIfPresent() throws Exception {
        if (isElementVisible(nextSignDocumentButton, 5)) {
            waitAndClickElement(nextSignDocumentButton);
        }
    }

    public void validateBwPaymentSummaryPage(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        validateHeaderAndRateAdjustmentMessage(fsa);
        validatePaymentCards(fsa, applicant);
        validateDiscounts(fsa);
        validateBottomSection(fsa);
    }

    private void validateHeaderAndRateAdjustmentMessage(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(Arrays.asList(HOW_WOULD_YOU_LIKE_TO_PAY, "Let's checkout!").contains(getTextFromElement(pageHeader)), "Page header validation for " + this.getClass().getSimpleName());
        String expectedRateAdjustmentMessage = "";
        if (getAutoVerifyRateResponse().isPremiumIncrease()) {
            expectedRateAdjustmentMessage = "Based on third-party reports on your driving history, your rate may have increased from our initial quote. If you'd like, you can change your coverage options.";
            fsa.assertEquals(getTextFromElement(rateAdjustmentMessage), expectedRateAdjustmentMessage, "Rate adjustment message for increase");
        } else if (getAutoVerifyRateResponse().isPremiumDecrease()) {
            expectedRateAdjustmentMessage = "Your actual rate is lower than our initial quote, based on third-party reports on your driving history. If you'd like, you can change your coverage options.";
            fsa.assertEquals(getTextFromElement(rateAdjustmentMessage), expectedRateAdjustmentMessage, "Rate adjustment message for decrease");
        } else {
            fsa.assertFalse(isElementVisible(rateAdjustmentMessage, 1), "Rate adjustment message is not displayed when there is no change in premium");
        }

        // validateChangeYourCoverage(softAssert);

    }

    private void validateChangeYourCoverage(FarmersSoftAssert fsa) throws Exception {
        waitAndClickElement(changeYourCoverageLink);
        waitForSpinnerToBeGone();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        fsa.assertTrue(quoteSummaryAutoPage.isOnQuoteSummaryAutoPage(), "User is on the " + quoteSummaryAutoPage.getClass().getSimpleName() + " after clicking 'change your coverage link'");
        fsa.assertTrue(quoteSummaryAutoPage.isOnBristolWest(), "Bw logo is displayed");
    }

    private void validatePaymentCards(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        validatePaymentCard(PAY_IN_FULL, fsa, applicant);
        if (!getStateCodeFromAppStore().equals(PA)) {
            // PA only supports PAY in FULL

            validatePaymentCard(MONTHLY_AUTO_PAY_BANK_HEADER, fsa, applicant);
            validatePaymentCard(MONTHLY_AUTO_PAY_CARD_HEADER, fsa, applicant);
            validatePaymentCard(MONTHLY_DIRECT_BILL, fsa, applicant);
        }
    }


    private void validateDiscounts(FarmersSoftAssert fsa) throws Exception {
        Set<String> expectedDiscounts = getAutoVerifyRateResponse().getDiscounts().stream().map(each -> each.getName().replace(" Discount", EMPTY_STRING)).distinct().collect(Collectors.toSet());
        Set<String> actualDiscounts = new HashSet<>(getDisplayedDiscounts());
        fsa.assertEquals(actualDiscounts, expectedDiscounts, "Discounts matching for " + this.getClass().getSimpleName());
        fsa.assertEquals(getTextFromElement(discountTitle), String.format("%d discounts applied", expectedDiscounts.size()), "Discounts applied title is not matching for " + this.getClass().getSimpleName());
    }


    private void validateBottomSection(FarmersSoftAssert fsa) throws Exception {
        String quoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
        getAceQuoteNumberInThePage();
        fsa.assertEquals(getAceQuoteNumberInThePage(), quoteNumber, "Quote number is matching for " + this.getClass().getSimpleName());
        fsa.assertEquals(getTextFromElement(quoteNumberElement), "Quote number");
        fsa.assertTrue(getAttributeData(quoteNumberElement, CLASS).contains("bold"), "Quote number text in bold for " + this.getClass().getSimpleName());
    }

    private void validatePaymentCard(String paymentMethod, FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        String matCardPerPaymentPlanXpath = getMatCardPerPaymentPlanXpath(paymentMethod);
        if (List.of(NEVER_INSURED, EXPIRED).contains(applicant.getCurrentlyInsuredStatus()) && paymentMethod.equals(MONTHLY_AUTO_PAY_BANK)) {
            fsa.assertTrue(locators(pwXPath(matCardPerPaymentPlanXpath)).isEmpty(), "Payment card for " + paymentMethod + " should not be displayed for applicant with currently insured status of " + applicant.getCurrentlyInsuredStatus());
            return;
        }

        Locator cardHeader = locator(pwXPath(matCardPerPaymentPlanXpath + PAYMENT_CARD_HEADER_XPATH));
        Locator cardSubHeader = locator(pwXPath(matCardPerPaymentPlanXpath + PAYMENT_CARD_SUB_HEADER_XPATH));
        Locator cardPaymentDescription = locator(pwXPath(matCardPerPaymentPlanXpath + PAYMENT_DESCRIPTION_XPATH));
        Locator cardDollarSign = locator(pwXPath(matCardPerPaymentPlanXpath + DOLLAR_SIGN_XPATH));
        Locator cardDollarAmount = locator(pwXPath(matCardPerPaymentPlanXpath + DOLLAR_AMOUNT_XPATH));
        Locator cardCentAmount = locator(pwXPath(matCardPerPaymentPlanXpath + DOLLAR_CENT_XPATH));
        Locator selectAndSignDocuments = locator(pwXPath(getSelectAndSignDocumentsElementXpath(paymentMethod)));
        Locator firstDivider = locator(pwXPath(matCardPerPaymentPlanXpath + DIVIDER_ONE_XPATH));
        Locator greenIcon = locator(pwXPath(matCardPerPaymentPlanXpath + PAYMENT_OVERVIEW_ICON_XPATH));
        Locator paymentDiscountMessage = locator(pwXPath(matCardPerPaymentPlanXpath + PAYMENT_OVERVIEW_MESSAGE_XPATH));
        Locator dueTodayTextAndAmount = locator(pwXPath(matCardPerPaymentPlanXpath + DUE_TODAY_AMOUNT_TEXT_XPATH));
        Locator serviceChargeText = locator(pwXPath(matCardPerPaymentPlanXpath + SERVICE_CHARGE_MESSAGE_XPATH));
        boolean isPif = paymentMethod.equals(PAY_IN_FULL);
        Locator dividerTwo = locator(pwXPath(matCardPerPaymentPlanXpath + DIVIDER_TWO_XPATH));
        Locator sixMonthTotalTermText = locator(pwXPath(matCardPerPaymentPlanXpath + SIX_MONTH_TOTAL_TERM_TEXT_XPATH));
        Locator includeAllFeesText = locator(pwXPath(matCardPerPaymentPlanXpath + INCLUDE_ALL_FEES_TEXT_XPATH));
        boolean isDirectBill = paymentMethod.equals(MONTHLY_DIRECT_BILL);
        String debitCreditBankMessageXpath = isDirectBill ? "//p[@class='tui-caption-text tui-stacking-top-sm']" : BANK_DEBIT_CREDIT_MESSAGE_XPATH;
        Locator debitCreditBankMessage = locator(pwXPath(matCardPerPaymentPlanXpath + debitCreditBankMessageXpath));
        String xpathForTotalBottomPrice = isDirectBill ? "//div[@class='tui-subtitle-text-1 payment-overview-card-premium-font tui-stacking-top-sm']" : BOTTOM_TOTAL_PRICE_XPATH;
        Locator bottomTotalPrice = locator(pwXPath(matCardPerPaymentPlanXpath + xpathForTotalBottomPrice));

        //validations
        fsa.assertEquals(getTextFromElement(cardHeader), paymentMethod, "Card header for " + paymentMethod);
        String expectedSubheader = isPif ? "Best value" : "Convenient";
        expectedSubheader = isDirectBill ? "Most control" : expectedSubheader;
        fsa.assertEquals(getTextFromElement(cardSubHeader), expectedSubheader, "Card sub header for " + paymentMethod);
        String numberOfInstallments = getNumberOfInstallments(paymentMethod);
        String monthlyPaymentMessage = String.format("%s monthly payments", numberOfInstallments);
        String expectedCardPaymentDescription = isPif ? "One-time payment" : monthlyPaymentMessage;
        fsa.assertEquals(getTextFromElement(cardPaymentDescription), expectedCardPaymentDescription, "Card payment description for " + paymentMethod);
        String actualInstallmentAmountText = String.format("%s%s%s", getTextFromElement(cardDollarSign), getTextFromElement(cardDollarAmount), getTextFromElement(cardCentAmount));
        double bwInstallmentAmount = Double.parseDouble(getInstallmentAmountBw(paymentMethod));
        fsa.assertEquals(actualInstallmentAmountText, String.format("$%s", getFormattedDecimal(bwInstallmentAmount)), "Installment amount validation for " + paymentMethod);
        fsa.assertTrue(selectAndSignDocuments.isEnabled() && selectAndSignDocuments.isVisible(), "Select & sign documents element is displayed and enabled for " + paymentMethod);
        fsa.assertTrue(firstDivider.isVisible(), "First divider is displayed for " + paymentMethod);
        fsa.assertTrue(greenIcon.isVisible(), "Green icon is displayed for " + paymentMethod);
        String expectedPaymentDiscountMessage = isPif ? "Preferred payment plan savings" : "Autopay savings";
        if (!isDirectBill) {
            fsa.assertEquals(getTextFromElement(paymentDiscountMessage), expectedPaymentDiscountMessage, "Payment plan discount message for " + paymentMethod);
        }
        double downPaymentInDouble = Double.parseDouble(getDownPaymentAmount(paymentMethod));
        String expectedDueTodayText = String.format("$%s due today", getFormattedDecimal(downPaymentInDouble));
        fsa.assertEquals(getTextFromElement(dueTodayTextAndAmount), expectedDueTodayText, "Due today amount text for " + paymentMethod);
        String expectedServiceChargeText = isPif ? "No service charge" : String.format("$%s monthly service charge (future payments only)", getServiceChargeAmount(paymentMethod));
        fsa.assertEquals(getTextFromElement(serviceChargeText), expectedServiceChargeText, "Service charge text validation for " + paymentMethod);
        fsa.assertTrue(dividerTwo.isVisible(), "Divider two is displayed for " + paymentMethod);
        fsa.assertEquals(getTextFromElement(sixMonthTotalTermText), "6-month term total cost", "6-Month term total cost text validation for " + paymentMethod);
        fsa.assertEquals(getTextFromElement(includeAllFeesText), "(includes all fees)", "Includes all fees text validation for " + paymentMethod);

        fsa.assertEquals(getTextFromElement(debitCreditBankMessage), getDebitCreditCardBankMessage(paymentMethod), "Credit card debit / bank payment text validation for " + paymentMethod);
        String expectedBottomTotalPrice = String.format("$%s", getFormattedDecimal(Double.parseDouble(getFullTermPremiumAmountBW(paymentMethod))));
        fsa.assertEquals(getTextFromElement(bottomTotalPrice), expectedBottomTotalPrice, "Bottom total premium amount validation for " + paymentMethod);

        /* checking the bottom total price for monthly payment plans, as it should reflect the full term premium which is the installment amount * number of installments + down payment,
         and for pay in full it should be the same as the installment amount as there is only one payment */
        if (!paymentMethod.equals(PAY_IN_FULL)) {
            double fullTermPremium = bwInstallmentAmount * Integer.parseInt(numberOfInstallments) + downPaymentInDouble;
            fsa.assertEquals(getTextFromElement(bottomTotalPrice), String.format("$%s", getFormattedDecimal(fullTermPremium)), "Bottom total premium amount validation from session storage vs UI validation - " + paymentMethod);
        }

        if (paymentMethod.equals(MONTHLY_AUTO_PAY_BANK_HEADER) || isDirectBill) {
            Locator downPaymentMessageForBankPayment = locator(pwXPath(matCardPerPaymentPlanXpath + MONTHLY_AUTOPAY_DOWNPAYMENT_MESSAGE_XPATH));
            String expectedPaymentMessageAtBottom = "Down payment must be with a debit or credit card";
            fsa.assertEquals(getTextFromElement(downPaymentMessageForBankPayment), expectedPaymentMessageAtBottom, "Additional down payment message for " + paymentMethod);
        }
    }

    private String getMatCardPerPaymentPlanXpath(String paymentPlan) throws Exception {
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(getTheTabXpathByPaymentMethod(paymentPlan));
        }
        return isUseMobileViewEnabled() ? String.format("//mat-tab-header//div[contains(@class,'mat-ripple mat-tab-label mat-focus-indicator') and contains(.,'%s')] | //div[contains(@class,'pov2__plan-card') and contains(.,'%s')]", paymentPlan, paymentPlan) : String.format("//div[contains(@class, 'presentment-card-header d-none d-md-inline-flex')]//mat-card[contains(.,'%s')] | //div[contains(@class,'pov2__plan-card') and contains(.,'%s')]", paymentPlan, paymentPlan);

    }

    private String getServiceChargeAmount(String paymentMethod) throws Exception {
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        String serviceCharge = paymentSchedules.stream().filter(each -> each.getPaymentMethod().equals(convertPaymentMethodToPayPlanCodeBW(paymentMethod))).findFirst().get().getServiceCharge();
        return Arrays.asList(serviceCharge.split("\\.")).get(0);
    }

    private String getDownPaymentAmount(String paymentMethod) throws Exception {
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPaymentMethod().equals(convertPaymentMethodToPayPlanCodeBW(paymentMethod))).findFirst().get().getDownPayment().getAmount().getAmount();
    }

    private String getNumberOfInstallments(String paymentMethod) throws Exception {
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPaymentMethod().equals(convertPaymentMethodToPayPlanCodeBW(paymentMethod))).findFirst().get().getNumberOfInstallments();
    }

    private String getDebitCreditCardBankMessage(String paymentMethod) throws Exception {
        switch (paymentMethod) {
            case PAY_IN_FULL:
            case MONTHLY_AUTO_PAY_CARD_HEADER:
                return "Debit card or Credit card";
            case MONTHLY_DIRECT_BILL:
                return "Bank payment, debit card, or credit card";
            case MONTHLY_AUTO_PAY_BANK_HEADER:
                return "Bank payment";
            default:
                Log.error("Please provide acceptable payment method");
                return null;
        }
    }

    private Locator getTheTabXpathByPaymentMethod(String paymentMethod) throws Exception {
        String locatorHelp = "";
        switch (paymentMethod) {
            case PAY_IN_FULL:
                locatorHelp = PAY_IN_FULL;
                break;
            case MONTHLY_AUTO_PAY_BANK_HEADER:
                locatorHelp = "bank";
                break;
            case MONTHLY_AUTO_PAY_CARD_HEADER:
                locatorHelp = "card";
                break;
            case MONTHLY_DIRECT_BILL:
                locatorHelp = "bill";
                break;
            default:
                Log.error("Please make sure providing the valid payment method");
                break;
        }

        return locator(pwXPath(String.format("//div[@class='mat-tab-label-content' and contains(.,'%s')]", locatorHelp)));

    }

    public String getSelectAndSignDocumentsElementXpath(String paymentMethod) throws Exception {
        List<String> theListOfEligiblePaymentMethods = getTheListOfEligiblePaymentMethods();
        if(!theListOfEligiblePaymentMethods.contains(paymentMethod)) {
            Collections.shuffle(theListOfEligiblePaymentMethods);
            Log.info("The selected payment method: " + paymentMethod + " is not available for this quote, selecting : " + theListOfEligiblePaymentMethods.get(0) + " instead");
            paymentMethod = theListOfEligiblePaymentMethods.get(0);
        }
        return String.format(getMatCardPerPaymentPlanXpath(paymentMethod) + "//button");
    }

    public void validatePaymentSetUpPage(String paymentMethod, FarmersSoftAssert fsa) throws Exception {

        List<String> theListOfEligiblePaymentMethods = getTheListOfEligiblePaymentMethods();

        if (!theListOfEligiblePaymentMethods.contains(paymentMethod)) {
            Collections.shuffle(theListOfEligiblePaymentMethods);
            Log.info("The selected payment method: " + paymentMethod + " is not available for this quote, selecting : " + theListOfEligiblePaymentMethods.get(0) + " instead");
            paymentMethod = theListOfEligiblePaymentMethods.get(0);
        }

        String commonValidationText = " for " + paymentMethod;
        fsa.assertTrue(isAutoPolicyPaymentHeaderCorrect(), AUTO_POLICY_PAYMENT_HEADER + " header validation");
        String fullTermPremiumAmount = getFullTermPremiumAmountBW(paymentMethod);
        double doubleFullTermPremium = Double.parseDouble(fullTermPremiumAmount);
        String downPaymentAmount = getDownPaymentAmount(paymentMethod);
        String formattedDownPaymentAmount = getFormattedDecimal(Double.parseDouble(downPaymentAmount));
        String landingZipCode = getSessionStorageAppStore().getData().getLandingZipCode();
        switch (paymentMethod) {
            case PAY_IN_FULL:
                fsa.assertEquals(getTextFromElement(pifPageSubHeader), PAY_IN_FULL, "Subheader validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(pifSixMonthTermPriceLabel).replace("info", EMPTY_STRING), String.format("$%s for 6-month term price", getFormattedDecimal(doubleFullTermPremium)), "Six month term price validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(sixTermPaymentIncludingAllFeesLabel), "6-month term payment (includes all policy fees)", "Installment text label validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(sixTermPaymentIncludingAllFeesAmount), String.format("$%s", formattedDownPaymentAmount), "Installment amount validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(pifDueTodayIncludesAllFeesLabel), "Due today (includes all policy fees)", "Due today text label validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(pifDueTodayIncludesAllFeesAmount), String.format("$%s", getFormattedDecimal(Double.parseDouble(fullTermPremiumAmount))), "Due today amount validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(pifAddPreferredPaymentMethodHeader), ADD_YOUR_PREFERRED_PAYMENT_METHOD, "Payment add section header validation " + commonValidationText);
                fsa.assertEquals(getTextFromElement(pifUseBankDebitCreditCardBulletPoint), "Use debit card or credit card", "Payment add section bullet one validation " + commonValidationText);
                fsa.assertEquals(getTextFromElement(pifNoServiceChargeWhenYouPayInFullBulletPoint), NO_SERVICE_CHARGES_WHEN_YOU_PAY_IN_FULL, "Payment add section bullet two validation ( No service charge) " + commonValidationText);
                fsa.assertEquals(getTextFromElement(pifSetUpPaymentMethodButton), SET_UP_PAYMENT_METHOD, "Payment add section bullet two validation ( No service charge) " + commonValidationText);
                fsa.assertTrue(pifSetUpPaymentMethodButton.isVisible() && pifSetUpPaymentMethodButton.isEnabled(), SET_UP_PAYMENT_METHOD + " button should be enabled and displayed " + commonValidationText);
                waitAndClickElement(pifSetUpPaymentMethodButton);
                addCardPaymentMethod(MASTER_CARD, landingZipCode);
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(pifPaymentCardAddedLabel)), CREDIT_CARD + " added.", "Credit card added message is validated" + commonValidationText);
                fsa.assertTrue(waitElementBeVisible(pifPaymentCardAddedGreenMatIcon).isVisible(), "Green check icon for added payment method is displayed " + commonValidationText);
                fsa.assertEquals(getTextFromElement(pifNoServiceChargeLabel), "No service charges when you pay in full.", "Service charge validation " + commonValidationText);
                fsa.assertTrue(pifAddedPaymentIcon.isVisible(), "Added payment method icon is displayed" + commonValidationText);
                fsa.assertEquals(getTextFromElement(pifAddedPaymentMethodMaskedNumbersAndExpDate), String.format("5454 | Exp %s", EXP_DATE), "Masked card number and exp date is validated" + commonValidationText);
                fsa.assertTrue(pifAddedPaymentMethodChangeButton.isVisible() && pifAddedPaymentMethodChangeButton.isEnabled(), "Change button is displayed and enabled " + commonValidationText);
                fsa.assertEquals(getTextFromElement(pifDisclaimerTextHeader), "String clicking \"Complete purchase\" below:", "Disclaimer section header validation " + commonValidationText);
                fsa.assertEquals(getTextFromElement(pifDisclaimerTextBulletPointOne), "I confirm that I have read and agree to the Paperless Terms of Use; and", "Disclaimer section bullet point one validation " + commonValidationText);
                String expectedBulletPoint2Text = isBDQFlowEnabled() ? "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Bristol West Auto Insurance and/or its affiliates and subsidiaries to initiate:" : "I confirm I have read and agree to both the Information Storage Authorization and the Payment Authorization Terms & Conditions. I authorize Farmers Insurance Exchange and/or its affiliates and subsidiaries (\"Farmers\") to initiate:";
                fsa.assertEquals(getTextFromElement(pifDisclaimerTextBulletPointTwo), expectedBulletPoint2Text, "Disclaimer section bullet point two validation " + commonValidationText);
                fsa.assertTrue(pifOneTimeAndRecurringPaymentRadioButtonInput.isChecked(), "One time payment automatic payment radio button is selected by default" + commonValidationText);
                fsa.assertTrue(pifOneTimeOnlyPaymentRadioButtonLabel.isVisible() && pifOneTimeOnlyPaymentRadioButtonLabel.isEnabled(), "One time payment only radio button is displayed and selected by default" + commonValidationText);
                String expectedFinalDisclaimerText = isBDQFlowEnabled() ? "If you do not agree with the Terms and Conditions above and/or have any questions, please contact your agent or Bristol West representative to complete this transaction. You can always change your Paperless and Automatic Payment settings for future transactions by logging in to your Bristolwest.com account." : "If you do not agree with the Terms and Conditions above and/or have any questions, please contact your agent or Farmers Direct Sales Center to complete this transaction. You can always change your Paperless and Automatic Payment settings for future transactions by logging in to your Farmers.com account.";
                fsa.assertEquals(getTextFromElement(pifDisclaimerFinalText), expectedFinalDisclaimerText, "Disclaimer section final text validation " + commonValidationText);
                break;
            case MONTHLY_AUTO_PAY_BANK_HEADER:
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankPageSubHeader), paymentMethod, "User should be on the " + paymentMethod + " page");
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankSixMonthTermPriceLabel).replace("info", EMPTY_STRING), String.format("$%s for 6-month term price", getFormattedDecimal(doubleFullTermPremium)), "Six month term price validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankSixTermPaymentIncludingAllFeesLabel), FIRST_MONTHLY_PAYMENT_INCLUDES_ALL_POLICY_FEES, "Installment text label validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankSixTermPaymentIncludingAllFeesAmount), String.format("$%s", getInstallmentAmountBw(paymentMethod)), "Installment amount validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankDueTodayIncludesAllFeesLabel), "Due today (includes all policy fees)", "Due today text label validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankDueTodayIncludesAllFeesAmount), String.format("$%s", formattedDownPaymentAmount), "Due today amount validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankDownPaymentHeader), "1) Down payment", "Down payment section header validation " + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankFuturePaymentsSectionHeader), "2) Future payments", "Future payments section header validation " + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankDownPaymentAndFuturePaymentsBoldDescriptions.nth(0)), "We'll collect the bank account details in a moment, but first, your down payment must be with a card.", "Down payment section bold description validation " + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankDownPaymentAndFuturePaymentsBoldDescriptions.nth(1)), "Now let's collect the bank account details.", "Future payments section bold description validation " + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankDownPaymentAndFuturePaymentsBulletPointsDescriptions.nth(0)), "Use a debit card or credit card", "Down payment section payment desc bullet point label validation " + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankDownPaymentAndFuturePaymentsBulletPointsDescriptions.nth(1)), "Use a bank account", "Future payments section payment desc bullet point label validation " + commonValidationText);
                fsa.assertTrue(monthlyAutoPayBankDownPaymentSetUpPaymentMethodButton.isEnabled(), "Down payment set up payment button is enable validation " + commonValidationText);
                waitAndClickElement(monthlyAutoPayBankDownPaymentSetUpPaymentMethodButton);
                addCardPaymentMethod(PaymentMethods.DISCOVER_CREDIT_CARD_1.getAccountNumber(), landingZipCode);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankAddedAccountMessages.nth(0)), "Credit card added.", "Credit card added message validation " + commonValidationText);
                fsa.assertTrue(monthlyAutoPayBankAddedAccountGreenChecks.nth(0).isVisible(), "Credit card added green checkbox visible validation " + commonValidationText);
                fsa.assertTrue(monthlyAutoPayBankDownPaymentAddedCreditCardIcon.isVisible(), "Credit card icon validation " + commonValidationText);
                String expectedAddedAccountNumbersCreditCard = String.format("0012 | Exp %s", EXP_DATE);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankAddedAccountNumbers.nth(0)), expectedAddedAccountNumbersCreditCard, "Added credit card masked text validation " + commonValidationText);
                fsa.assertTrue(monthlyAutoPayBankChangeLinks.nth(0).isEnabled(), "Down payment section change link is enabled validation " + commonValidationText);
                waitAndClickElement(monthlyAutoPayBankChangeLinks.nth(0));
                addCardPaymentMethod(VISA_DEBIT_CARD, landingZipCode);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankAddedAccountMessages.nth(0)), "Debit card added.", "Credit card added message validation " + commonValidationText);
                fsa.assertTrue(monthlyAutoPayBankAddedAccountGreenChecks.nth(0).isVisible(), "Debit card added green checkbox visible validation " + commonValidationText);
                fsa.assertTrue(monthlyAutoPayBankDownPaymentAddedCreditCardIcon.isVisible(), "Debit card icon validation " + commonValidationText);
                String expectedAddedAccountNumbersDebitCard = String.format("4440 | Exp %s", EXP_DATE);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankAddedAccountNumbers.nth(0)), expectedAddedAccountNumbersDebitCard, "Added debit card masked text validation " + commonValidationText);
                fsa.assertTrue(monthlyAutoPayBankChangeLinks.nth(0).isEnabled(), "Down payment section change link is enabled validation " + commonValidationText);
                break;
            case MONTHLY_AUTO_PAY_CARD_HEADER:
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankPageSubHeader), paymentMethod, "User should be on the " + paymentMethod + " page");
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankSixMonthTermPriceLabel).replace("info", EMPTY_STRING), String.format("$%s for 6-month term price", getFormattedDecimal(doubleFullTermPremium)), "Six month term price validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankSixTermPaymentIncludingAllFeesLabel), FIRST_MONTHLY_PAYMENT_INCLUDES_ALL_POLICY_FEES, "Installment text label validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankSixTermPaymentIncludingAllFeesAmount), String.format("$%s", getFormattedDecimal(Double.parseDouble(getInstallmentAmountBw(paymentMethod)))), "Installment amount validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayBankDueTodayIncludesAllFeesLabel), "Due today (includes all policy fees)", "Due today text label validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyAutoPayCardDueTodayIncludesAllFeesAmount), String.format("$%s", formattedDownPaymentAmount), "Due today amount validation" + commonValidationText);
                break;
            case MONTHLY_DIRECT_BILL:
                fsa.assertEquals(getTextFromElement(monthlyDirectBillPageSubHeader), MONTHLY_DIRECT_BILL, "User should be on the " + paymentMethod + " page");
                fsa.assertEquals(getTextFromElement(monthlyDirectBillSixMonthTermPriceLabel).replace("info", EMPTY_STRING), String.format("$%s for 6-month term price", getFormattedDecimal(doubleFullTermPremium)), "Six month term price validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyDirectBillFirstMonthlyPaymentIncludingAllFeesLabel), FIRST_MONTHLY_PAYMENT_INCLUDES_ALL_POLICY_FEES, "Installment text label validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyDirectBillFirstMonthlyPaymentIncludingAllFeesAmount), String.format("$%s", getFormattedDecimal(Double.parseDouble(getInstallmentAmountBw(paymentMethod)))), "Installment amount validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyDirectBillDueTodayIncludesAllFeesLabel), "Due today (includes all policy fees)", "Due today text label validation" + commonValidationText);
                fsa.assertEquals(getTextFromElement(monthlyDirectBillDueTodayIncludesAllFeesAmount), String.format("$%s", formattedDownPaymentAmount), "Due today amount validation" + commonValidationText);
                break;
            default:
                Log.error("Please provide acceptable payment method");
                break;
        }
    }


    public void validatePaymentDeclineModalContent(FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(paymentDeclinedModalHeader)), "Payment declined", "Payment declined modal header validation");
        List<String> expectedMessages = Arrays.asList("The financial institution declined the payment request using this payment method.", "For your security, we won't save this payment method's details.", "Please enter a new one so we can complete your purchase.");
        List<String> actualMessage = paymentDeclinedModalMessages.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(actualMessage, expectedMessages, "Payment declined modal messages validation");
        fsa.assertEquals(getTextFromElement(paymentDeclinedModalOkButton), "Ok", "Payment declined modal OK button validation");
    }

    public void clickOkOnPaymentDeclinedModal() throws Exception {
        waitAndClickElement(paymentDeclinedModalOkButton);
    }

    public boolean isCreditCardEditMessageDisplayed() {
        return isElementPresent(pwXPath("//span[contains(.,'Credit card added.')]"), 2);
    }

    public void addBwPaymentMethod(String paymentMethod) throws Exception {
        String landingZipCode = getSessionStorageAppStore().getData().getLandingZipCode();
        switch (paymentMethod) {
            case PAY_IN_FULL:
                clickSetUpPaymentButton();
                addCardPaymentMethod(PaymentMethods.VISA_DEBIT_CARD_1.getAccountNumber(), landingZipCode);
                waitForSpinnerToBeGone();
                break;
            case MONTHLY_AUTO_PAY_BANK:
                clickSetUpPaymentButton();
                addCardPaymentMethod(PaymentMethods.DISCOVER_CREDIT_CARD_2.getAccountNumber(), landingZipCode);
                waitForSpinnerToBeGone();
                clickSetUpPaymentButton();
                addCheckingAccountPaymentMethod(PaymentMethods.BANK_ACCOUNT_3.getAccountNumber(), RandomStringUtils.randomNumeric(5));
                break;
            case MONTHLY_DIRECT_BILL:
                clickSetUpPaymentButton();
                addCardPaymentMethod(PaymentMethods.DISCOVER_CREDIT_CARD_2.getAccountNumber(), landingZipCode);
                waitForSpinnerToBeGone();
                break;
            case MONTHLY_AUTO_PAY_CARD:
                clickSetUpPaymentButton();
                addCardPaymentMethod(PaymentMethods.AMEX_CREDIT_CARD_1.getAccountNumber(), landingZipCode);
                waitForSpinnerToBeGone();
                break;
            case MONTHLY_AUTO_PAY_CARD_WITH_PARANTHESIS:
                clickSetUpPaymentButton();
                addCardPaymentMethod(PaymentMethods.AMEX_CREDIT_CARD_1.getAccountNumber(), landingZipCode);
                waitForSpinnerToBeGone();
                break;
            default:
                Log.error("Payment method is not known method please check");
        }
    }

    public void closeRateChangePopUpIfPresent() throws Exception {
        if(isRateChangePopUpDisplayed()) {
            clickElement(appRateChangeNotificationOkButton);
        }
    }

    public boolean isRateChangePopUpDisplayed() {
        return isElementVisible(appRateChangeNotificationOkButton, 10);
    }
}
