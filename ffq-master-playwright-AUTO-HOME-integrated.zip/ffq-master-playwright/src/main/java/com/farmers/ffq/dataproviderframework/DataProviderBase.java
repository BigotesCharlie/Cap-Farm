package com.farmers.ffq.dataproviderframework;

import com.farmers.framework.AutomationFramework;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

import static com.farmers.ffq.utils.GlobalVariables.*;

public abstract class DataProviderBase extends AutomationFramework {

    protected static final List<String> listOfAceAutoStates_PROD = List.of(AZ);
    protected static final List<String> listOfAceHCRStates_PROD = List.of(AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KS, KY, LA, MA, MD, MI, MN, MO, MS, MT, NC, ND, NE, NM, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);

    protected static final List<String> listOfAceAutoStates_RA11 = List.of(AR, AL, AZ, CA, CT, CO, FL, GA, IA, ID, IL, IN, KS, KY, LA, MA, MD, MI, MN, MO, MS, MT, NC, NJ, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    protected static final List<String> listOfAceHCRStates_RA11 = List.of(AL, AR, AZ, CA, CT, CO, GA, IA, ID, IL, IN, KS, KY, MD, MI, MN, MO, MT, ND, NE, NM, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    protected static final List<String> listOfHCRMonetizedStates_RA11 = List.of(FL, LA, MA, MS, NC, NV, NY);

    protected static final List<String> listOfAceAutoStates_MA11 = List.of(AL, AR, AZ, CA, CO, CT, FL, GA, IA, ID, IL, IN, KS, KY, LA, MA, MD, MI, MN, MO, MS, MT, NC, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    protected static final List<String> listOfAceHCRStates_MA11 = List.of(AL, AR, AZ, CA, CO, GA, IA, ID, IL, IN, KS, KY, MD, MI, MN, MO, MT, ND, NE, NM, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    protected static final List<String> listOfHCRMonetizedStates_MA11 = List.of(CT, FL, LA, MA, NC, MT, NJ, NV, NY, MS);

    protected static final List<String> listOfAceAutoStates_TSK1 = List.of(AL, AR, AZ, CA, CO, CT, FL, GA, IA, ID, IL, IN, KS, KY, LA, MA, MD, MI, MN, MO, MS, MT, NC, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    protected static final List<String> listOfAceHCRStates_TSK1 = List.of(AL, AR, AZ, CA, CO, CT, GA, IA, ID, IL, IN, KS, KY, LA, MA, MD, MI, MN, MO, MS, NC, ND, NE, NM, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    protected static final List<String> listOfHCRMonetizedStates_TSK1 = List.of(FL, MT, NJ, NV, NY);

    protected static final List<String> listOfAceAutoStates_PET = List.of(AL, AR, AZ, CA, CO, CT, FL, GA, IA, ID, IL, IN, KS, KY, LA, MA, MD, MI, MN, MO, MS, MT, NC, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    protected static final List<String> listOfAceHCRStates_PET = List.of(AL, AR, AZ, CA, CO, CT, GA, IA, ID, IL, IN, KS, KY, LA, MA, MD, MI, MN, MO, MS, MT, NC, ND, NE, NM, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    protected static final List<String> listOfHCRMonetizedStates_PET = List.of(MT, NJ, NV, NY);

    protected static final List<String> listOfAceAutoStates_MA61 = List.of(AR, AL, AZ, CA, CT, CO, FL, GA, IA, ID, IL, IN, KS, KY, LA, MA, MD, MI, MN, MO, MS, MT, NC, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    protected static final List<String> listOfAceHCRStates_MA61 = List.of(AL, AR, AZ, CA, CO, GA, IA, ID, IL, IN, KS, KY, MD, MI, MN, MO, MS, ND, NE, NM, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    protected static final List<String> listOfHCRMonetizedStates_MA61 = List.of(CT, FL, LA, MA, NC, NJ, NV, NY);
    protected static final List<String> listOfAceLifeStates_MA61 = List.of(AZ, IL, WI);

    protected static final List<String> listOfAceAutoStates_RA61 = List.of(AR, AL, AZ, CA, CT, CO, FL, GA, IA, ID, IL, IN, KS, KY, LA, MA, MD, MI, MN, MO, MS, MT, NC, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    protected static final List<String> listOfAceHCRStates_RA61 = List.of(AL, AR, AZ, CA, CO, GA, IA, ID, IL, IN, KS, KY, MD, MI, MN, MO, MS, NC, ND, NE, NM, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    protected static final List<String> listOfHCRMonetizedStates_RA61 = List.of(CT, FL, LA, MA, NJ, NV, NY);
    protected static final List<String> listOfAceLifeStates_RA61 = List.of(AZ, IL, WI);

    protected static final List<String> listOfAceAutoStates_DEV = List.of(AR, AL, AZ, CA, CT, CO, FL, GA, IA, ID, IL, IN, KS, KY, LA, MA, MD, MI, MN, MO, MS, MT, NC, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);

    protected static final List<String> listOfAceAutoStates_PERF = List.of(AR, AL, AZ, CA, CT, CO, FL, GA, IA, ID, IL, IN, KS, KY, LA, MA, MD, MI, MN, MO, MS, MT, NC, ND, NE, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    protected static final List<String> listOfAceHCRStates_PERF = List.of(AL, AR, AZ, CA, CO, GA, IA, ID, IL, IN, KS, KY, MD, MI, MN, MO, ND, NE, NM, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    protected static final List<String> listOfHCRMonetizedStates_PERF = List.of(CT, FL, LA, MA, MS, NC, NJ, NV, NY);
    protected static final List<String> listOfAceLifeStates_PERF = List.of();

    protected static final String ALL = "all";
    protected static final String STATE_LIST = "stateList";

    protected static Object[][] read(Class<?> targetType, String fileName, String id) throws Exception {
        List<DataObjectBase> set = ExcelReader.read(targetType, fileName, id);
        Object[][] ret = new Object[set.size()][1];
        for (int i = 0; i < set.size(); i++) {
            ret[i][0] = set.get(i);
        }
        return ret;
    }

    protected static List<String> partialList(List<String> listOfStrings, HashSet<Integer> listOfIndices) {
        List<String> retList = new ArrayList<>();
        if (!listOfIndices.isEmpty()) {
            Iterator<Integer> iter = listOfIndices.iterator();
            while (iter.hasNext()) {
                retList.add(listOfStrings.get(iter.next().intValue()));
            }
        }
        return retList;
    }

    protected static HashSet<Integer> randomIntegerSet(int numberOfElements, int minValue, int maxValue) {
        int setSize = (numberOfElements < (maxValue - minValue)) ? numberOfElements : (maxValue - minValue);
        HashSet<Integer> setOfInts = new HashSet<>();
        while (setOfInts.size() < setSize) {
            int randomNum = ThreadLocalRandom.current().nextInt(minValue, maxValue);
            setOfInts.add(Integer.valueOf(randomNum));
        }
        return setOfInts;
    }

    public static List<String> getListOfAceAutoStates(String environmentURI) {
        if (environmentURI.contains(PROD_ENVIRONMENT)) {
            return listOfAceAutoStates_PROD;
        } else if (environmentURI.contains(RA11_ENVIRONMENT)) {
            return listOfAceAutoStates_RA11;
        } else if (environmentURI.contains(MA11_ENVIRONMENT)) {
            return listOfAceAutoStates_MA11;
        } else if (environmentURI.contains(RA61_ENVIRONMENT)) {
            return listOfAceAutoStates_RA61;
        } else if (environmentURI.contains(TSK1_ENVIRONMENT)) {
            return listOfAceAutoStates_TSK1;
        } else if (environmentURI.contains(MA61_ENVIRONMENT)) {
            return listOfAceAutoStates_MA61;
        } else if (environmentURI.contains(PET_ENVIRONMENT)){
            return listOfAceAutoStates_PET;
        }  else if (environmentURI.contains(DEV_ENVIRONMENT)){
            return listOfAceAutoStates_DEV;
        } else if (environmentURI.contains(PERF_ENVIRONMENT)){
            return listOfAceAutoStates_PERF;
        } else {
            return List.of();
        }
    }

    public static List<String> getBDQEnabledStates() {
        return Arrays.asList(AL, AR, AZ, CO, CT, FL, GA, IA, ID, IL, IN, KS, KY, LA, MA, MD, MI, MN, MO, MS, ND, NE, NJ, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    }

    public static List<String> getListOfHCRMonetizedStates(String environmentURI) {
        List<String> monetizedStates = new ArrayList<>(List.of());
        if (environmentURI.contains(TSK1_ENVIRONMENT)) {
            monetizedStates.addAll(listOfHCRMonetizedStates_TSK1);
        } else if (environmentURI.contains(MA61_ENVIRONMENT)) {
            monetizedStates.addAll(listOfHCRMonetizedStates_MA61);
        } else if (environmentURI.contains(PET_ENVIRONMENT)) {
            monetizedStates.addAll(listOfHCRMonetizedStates_PET);
        } else if (environmentURI.contains(RA61_ENVIRONMENT)) {
            monetizedStates.addAll(listOfHCRMonetizedStates_RA61);
        } else if (environmentURI.contains(RA11_ENVIRONMENT)) {
            monetizedStates.addAll(listOfHCRMonetizedStates_RA11);
        } else if (environmentURI.contains(MA11_ENVIRONMENT)) {
            monetizedStates.addAll(listOfHCRMonetizedStates_MA11);
        }
        return monetizedStates;
    }

    public static List<String> getListOfAceHCRStates(String environmentURI) {
        if (environmentURI.contains(PROD_ENVIRONMENT)) {
            return listOfAceHCRStates_PROD;
        } else if (environmentURI.contains(RA11_ENVIRONMENT)) {
            return listOfAceHCRStates_RA11;
        } else if (environmentURI.contains(MA11_ENVIRONMENT)) {
            return listOfAceHCRStates_MA11;
        } else if (environmentURI.contains(TSK1_ENVIRONMENT)) {
            return listOfAceHCRStates_TSK1;
        } else if (environmentURI.contains(MA61_ENVIRONMENT)) {
        	return listOfAceHCRStates_MA61;
        } else if (environmentURI.contains(RA61_ENVIRONMENT)) {
            return listOfAceHCRStates_RA61;
        } else if (environmentURI.contains(PERF_ENVIRONMENT)) {
            return listOfAceHCRStates_PERF;
        } else if (environmentURI.contains(PET_ENVIRONMENT)) {
            return listOfAceHCRStates_PET;
        } else {
            return new ArrayList<>(List.of());
        }
    }

    public static List<String> getListOfAceLifeStates(String environmentURI) {
    	if (environmentURI.contains(MA61_ENVIRONMENT)) {
        	return listOfAceLifeStates_MA61;
        } else if (environmentURI.contains(RA61_ENVIRONMENT)) {
            return listOfAceLifeStates_RA61;
        } else {
            return List.of(AL, AR, AZ, CA, CO, GA, IA, ID, IL, IN, KS, MD, MI, MN, MO, MT, ND, NE, NJ, NM, NV, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
        }
    }

    //Eastern Expansion states (KY, LA, MA, MS, NC) are not available for business quotes
    public static List<String> getListOfAceBusinessStates() {
    	return List.of(AL, AR, AZ, CA, CO, CT, GA, IA, ID, IL, IN, KS, MD, MI, MN, MO, MT, ND, NE, NJ, NM, NV, NY, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
    }

    public static List<String> getListOfAceBundleStates(String environmentURI) {
        if (!environmentURI.isEmpty()){
            return List.of(AL, AR, AZ, CA, CO, GA, IA, ID, IL, IN, KS, KY, LA, MA, MD, MI, MO, MN, MS, MT, NC, ND, NE, NM, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY);
        } else {
            return List.of();
        }
    }

    //US1116567: Mobile home states
    public static List<String> getListOfAceMobileHomeStates(String environmentURI) {
    	//Per Maria - still exclude AK
    	if (environmentURI.contains(RA11_ENVIRONMENT) || environmentURI.contains(MA11_ENVIRONMENT) || environmentURI.contains(MA61_ENVIRONMENT)) {
            return List.of(/*AK,*/ AL, AR, AZ, CA, CO, CT, DE, GA, IA, ID, IL, IN, KS, KY, LA, MA, MD, ME, MI, MN, MO, MS, MT, NC,
            		ND, NE, NH, NJ, NM, NV, NY, OH, OK, OR, PA, RI, SC, SD, TN, TX, UT, VA, VT, WA, WI, WV, WY);
        } else {
            return List.of();
        }
    }
}
