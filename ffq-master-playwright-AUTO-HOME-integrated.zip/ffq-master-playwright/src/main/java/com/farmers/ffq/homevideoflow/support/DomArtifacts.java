package com.farmers.ffq.homevideoflow.support;

import com.farmers.framework.playwright.AutoDebugManager;

import com.microsoft.playwright.Page;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

public final class DomArtifacts {
    private final Page page;
    private final Path runDir;
    private final AtomicInteger sequence = new AtomicInteger(1);

    public DomArtifacts(Page page, String scenarioName) {
        this.page = page;
        String runId = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        this.runDir = Path.of("build", "artifacts", "dom", "home-functional", scenarioName, runId);
        try { Files.createDirectories(runDir); }
        catch (IOException e) { throw new IllegalStateException("Unable to create artifact directory", e); }
    }

    public Path runDir() { return runDir; }

    public void capture(String stateName) {
        AutoDebugManager.checkpoint("home-" + stateName, false);
        int n = sequence.getAndIncrement();
        String prefix = String.format("%02d-%s", n, sanitize(stateName));
        captureTo(prefix);
    }

    public void captureNamed(String prefix) { AutoDebugManager.checkpoint("home-" + prefix, true); captureTo(sanitize(prefix)); }

    public void writeText(String fileName, String content) {
        write(runDir.resolve(fileName), content);
    }

    public void captureFailure(Throwable failure) {
        AutoDebugManager.checkpoint("home-functional-failure", true);
        captureTo("failure-current-page");
        write(runDir.resolve("failure-exception.txt"), failure == null ? "" : failure.toString());
        writeAutoDebug(failure);
    }

    private void captureTo(String prefix) {
        write(runDir.resolve(prefix + ".html"), safeContent());
        write(runDir.resolve(prefix + "-url.txt"), page.url());
        write(runDir.resolve(prefix + "-headings.txt"), safeHeadings());
        try { page.screenshot(new Page.ScreenshotOptions().setPath(runDir.resolve(prefix + ".png")).setFullPage(true)); }
        catch (RuntimeException ignored) { }
    }

    private void writeAutoDebug(Throwable failure) {
        StringBuilder b = new StringBuilder();
        b.append("AUTO-DEBUG SNAPSHOT\n")
         .append("URL: ").append(page.url()).append('\n')
         .append("Headings: ").append(safeHeadings()).append('\n')
         .append("Visible buttons: ").append(safeTexts("button,[role=button]")).append('\n')
         .append("Visible labels: ").append(safeTexts("label")).append('\n')
         .append("Exception: ").append(failure == null ? "" : failure).append('\n')
         .append("Next action: inspect failure-current-page.html before changing locators or waits.\n");
        write(runDir.resolve("AUTODEBUG.txt"), b.toString());
    }

    private String safeContent() { try { return page.content(); } catch (RuntimeException e) { return ""; } }
    private String safeHeadings() { return safeTexts("h1,h2,h3,[role=heading]"); }
    private String safeTexts(String css) { try { return page.locator(css).allInnerTexts().toString(); } catch (RuntimeException e) { return "[]"; } }
    private void write(Path p, String value) { try { Files.writeString(p, value == null ? "" : value, StandardCharsets.UTF_8); } catch (IOException e) { throw new IllegalStateException(e); } }
    private String sanitize(String s) { return s.toLowerCase().replaceAll("[^a-z0-9]+","-").replaceAll("(^-|-$)",""); }
}
