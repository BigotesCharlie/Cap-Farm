package com.farmers.ffq.home.pages;



import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.ApplicantHome;
import com.farmers.ffq.utils.FarmersSoftAssert;

import static com.farmers.ffq.utils.GlobalVariables.FOOTER_DISCLAIMER_STATIC_TEXT;
import static com.farmers.ffq.utils.GlobalVariables.MAX_OLD_AGE;

/**
 * Farmers Fast Quote (FFQ) - Thank You Page - Home.
 *
 *
 */

public class ThankYouPage extends BasePage {

		private Locator headerText = locator(pwId("PolicyIntro"));

		private Locator nextStepsStaticText = locator(pwXPath("//span[contains(@id,'nextStep')]"));

		private Locator premiumAmountCongratText = locator(pwXPath("//div[@class='homeprmHeading']/span[contains(@id, 'buypolicyHome')]/b"));

		private Locator quoteNumber = locator(pwXPath("//*[@id='Content']/div[3]/div[1]/p"));

		private Locator printQuoteButton = locator(pwXPath("//input[contains(@value,'PRINT')]"));

		private Locator emailQuoteButton = locator(pwXPath("//input[contains(@value,'EMAIL')]"));

		private Locator coverageAmount = locator(pwXPath("//*[@id='congratzHomeThankyou']/table[3]/tbody/tr[1]/td[2]"));

		private Locator startQuoteButton = locator(pwId("buypolicyHome:startQuoteDesktop"));

		private Locator footerDisclaimerStaticText = locator(pwId("homeAgentDisclaimer"));

		private Locator qualifyMultiPolicyStaticText = locator(pwXPath("//*[@id='buypolicyHome:HomePolicyWay']/tbody/tr[1]/td/span"));

		private Locator willHelpYouSaveStaticText = locator(pwXPath("//*[@id='buypolicyHome:HomePolicyWay']/tbody/tr[1]/td/div[1]"));

		private Locator crossSellDropDown = locator(pwId("buypolicyHome:quoteType"));

		private Locator startCrossSellQuoteButton = locator(pwId("buypolicyHome:startQuoteDesktop"));

		private Locator lobText = locator(pwXPath("//*[@id='congratzHomeThankyou']/div[1]/table/tbody/tr/td/p"));

		private Locator agentInfo = locator(pwCss("#homeAgentList"));

		private Locator yourFarmersAgentStaticText = locator(pwCss("#PolicyIntro>p"));

		private Locator futurePaymentsStaticText = locator(pwCss(".homethankYouDisclaimer>small"));

		private Locator monthlyPaymentsStaticText = locator(pwXPath("//*[@id='congratzHomeThankyou']/div[1]/table/tbody/tr/td/span"));

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public ThankYouPage() throws Exception {
		// Nothing required
	}

	public void verifyThankYouPageContent(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		waitElementBeVisibleClickable(printQuoteButton);
		fsa.assertEquals(getTextFromElement(yourFarmersAgentStaticText), "Thank you for completing your quote", "Your Farmers agent static text check");
		fsa.assertTrue(agentInfo.isVisible(), "Agent info displayed");
		fsa.assertEquals(getTextFromElement(footerDisclaimerStaticText), FOOTER_DISCLAIMER_STATIC_TEXT, "Footer Disclaimer Static Text check");
		fsa.assertTrue(getTextFromElement(monthlyPaymentsStaticText).contains("monthly automatic*"), "\"monthly automatic*\" is displayed");
		fsa.assertEquals("* Future payments will be automatically withdrawn from your bank/credit account", getTextFromElement(futurePaymentsStaticText), "Future payments static text check");
		fsa.assertTrue(getTextFromElement(headerText).contains("Your Farmers agent is currently reviewing your quote, maximizing your coverage, and searching for more discounts."), "Header text check");
		fsa.assertTrue(premiumAmountCongratText.isVisible(), "\"Congratulations, your estimated policy premium is:\" displayed");
		fsa.assertTrue(page().content().contains(applicant.getLineOfBusiness()), "Applicant LOB displayed");
		fsa.assertTrue(quoteNumber.isVisible(), "Quote number displayed ");
		fsa.assertTrue(emailQuoteButton.isVisible() && emailQuoteButton.isEnabled(), "\"Email Quote\" button displayed");
		fsa.assertTrue(printQuoteButton.isVisible() && printQuoteButton.isEnabled(), "\"Print Quote\" button displayed");
		if (applicant.getAge() < MAX_OLD_AGE) {
			fsa.assertEquals(getTextFromElement(qualifyMultiPolicyStaticText), "Do you qualify for a multi-policy discount?", "Do You qualifyFor multi-policy discount static text check");
			fsa.assertEquals(getTextFromElement(willHelpYouSaveStaticText), "Find out if adding new coverage will help you save", "Find out if adding new coverage will help you save static text check");
			fsa.assertTrue(startQuoteButton.isVisible() && startQuoteButton.isEnabled(), "\"Start Quote\" button displayed");
			fsa.assertTrue(crossSellDropDown.isVisible() && crossSellDropDown.isEnabled(), "Drop down for cross sell displayed");
		}
	}

	public void startCrossSellQuote(String quoteType) {
		closeSurveyDialog();
		selectFromDropDown(crossSellDropDown, quoteType);
		clickElement(startCrossSellQuoteButton);
		waitForSpinnerToBeGone();
		waitForLegacySpinnerToBeGone();
	}

}
