package com.farmers.ffq.auto.pages;








import com.farmers.framework.playwright.Keys;
import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.dataproviders.SqlDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import lombok.SneakyThrows;

import net.datafaker.Faker;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.security.cert.X509Certificate;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import static com.farmers.ffq.utils.GlobalVariables.*;
/**
 * Farmers Fast Quote (FFQ) - Base Page for FFQ + Top Navigation Menu.
 */
public class AutoBasePage extends BasePage {
    public static final String EXPECTED_BRAND_SELECTION_ERROR_MESSAGE = "For an online quote, please provide your consent, or contact a Farmers representative.";
    public static final String EXPECTED_ESIGN_DISCLAIMER = "By clicking \"Agree and submit\", you agree to these ESIGN terms and conditions and to receive marketing calls and texts as detailed below.";
    public static final String EXPECTED_CTA_DISCLAIMER = "We call and/or text consumers with information about products and services. By clicking \"Agree and submit\", you consent to receive marketing calls and texts on behalf of Farmers\u00ae, Foremost\u00ae, Bristol West\u00ae, and Farmers Life\u00ae associated entities and their representatives using an automated telephone dialing system, AI-generated and artificial or pre-recorded voice, even for numbers listed on national, state, or business do-not-call registries. Consent is not a condition of purchase. Go to Farmers.com for alternative contact options. Message and data rates may apply.";

    public static final String MATURE_DRIVER_ADDED_DISCOUNT_MSG = "Great! We've added the mature driver discount.";
    public static final String MATURE_DRIVER_DISCOUNT_REMOVED_MSG = "Mature driver discount has been removed.";
    public static final String DEFENSIVE_DRIVER_ADDED_DISCOUNT_MSG = "Great! We've added the defensive driver discount.";
    public static final String DEFENSIVE_DRIVER_DISCOUNT_REMOVED_MSG = "Defensive driver discount has been removed.";
    public static final String DRIVER_IMPROVEMENT_DISCOUNT_ADDED_MSG = "Great! We've added the driver improvement discount.";
    public static final String DRIVER_IMPROVEMENT_DISCOUNT_REMOVED_MSG = "Driver improvement discount has been removed.";


    private static final String ARIA_VALUENOW = "aria-valuenow";

    private static final String AGENT_ASSIGNED_NAME_XPATH = "//div[contains(@class, 'agent-detail-row') and contains(@class,'ng-star-inserted')]//div[@class='agent-detail-name']";
    protected static final String DONT_FORGET_TO_MAKE_YOUR_SELECTIONS = "Don't forget to make your selection(s).";
    public static final String FARMERS_LOGO_XPATH = "//img[@data-test-id='TUI_LOGO_NO_LINK' and @alt='Farmers Insurance logo']";
    protected boolean isBristolWest = false;
        protected Locator genericHelpPopupTitle = locator(pwId("FFQAuto_Modal_header"));

        protected Locator genericHelpPopupContent = locator(pwId("FFQAuto_Modal_popUpBody"));

        protected Locator helpPopupNeedMoreHelp = locator(pwId("FFQAuto_Modal_needHelp"));
    protected static final String NEED_MORE_HELP_TEXT = "Need more help ? Give us a call at (800) 206-9469";
    protected static final boolean TWO_ELEMENTS = false;
    protected static final boolean THREE_ELEMENTS = true;

        protected Locator retrievedQuoteModalContinueButton = locator(pwId("FFQAuto_Modal_ContBtn"));

    // < Bristol West Path >
        private Locator continueOnlineWithBWButton = locator(pwId("FFQAuto_Modal_discountBWConBWBtn"));

        private Locator speakToBWFarmersAgentButton = locator(pwId("FFQAuto_Modal_discountBWConFarmersBtn"));
    // < / Bristol West Path >

    // < Foremost Path >
        private Locator continueOnlineWithForemostButton = locator(pwId("FFQAuto_Modal_discountBWConBWBtnForeMost"));

        private Locator speakToForemostFarmersAgentButton = locator(pwId("FFQAuto_Modal_discountBWConFarmersBtnForeMost"));
    // < / Foremost Path >

        private Locator buttonNext = locator(pwXPath("//button//span[contains(text(),'NEXT')]"));

        private Locator buttonBack = locator(pwXPath("//button//span[contains(text()='BACK')]"));

        protected Locator brandSelectionErrorMessage = locator(pwCss("p[class='tui-small-text brand-error-message ng-star-inserted']"));

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public AutoBasePage() throws Exception {
        super();
    }

    public boolean isQuoteNumberPresent() {
        waitElementBeVisible(redesignedQuoteNumber);
        return redesignedQuoteNumber.isVisible();
    }

    protected List<Locator> setGenericPopupElementList(boolean hasMoreHelp) {
        List<Locator> popupElements = new ArrayList<>();
        popupElements.add(genericHelpPopupTitle);
        popupElements.add(genericHelpPopupContent);
        if (hasMoreHelp) {
            popupElements.add(helpPopupNeedMoreHelp);
        }
        return popupElements;
    }

    protected Map<Locator, String> setGenericPopupExpectedContentMap(String helpPopupTitle, String helpText, boolean hasThreeElements) {
        Map<Locator, String> popupContentMap = new HashMap<>();
        popupContentMap.put(genericHelpPopupTitle, helpPopupTitle);
        popupContentMap.put(genericHelpPopupContent, helpText);
        if (hasThreeElements) {
            popupContentMap.put(helpPopupNeedMoreHelp, NEED_MORE_HELP_TEXT);
        }
        return popupContentMap;
    }

    //Auto re-design, should move to AutoBasePage once that is created.
        protected Locator faqDialogCloseButton = locator(pwXPath("//button[@class='dialog__info-dialog-button-close']"));

        protected Locator faqDialogTitle = locator(pwClass("dialog_info-dialog-title"));

        protected Locator faqDialogContent = locator(pwClass("dialog_info-dialog-content"));

        protected Locator qualtricsSurveyPopUp = locator(pwCss("div[class*='_PopOverContainer'] > div:first-child"));
        protected Locator yesIWillGiveFeedbackButton = locator(pwCss("div[class*='_PopOverContainer'] > div:last-child img"));

        protected Locator willYouRecommendQuestion = locator(pwXPath("//legend//div//span[text()]"));

        protected Locator notAtAllLikely = locator(pwCss(".ColumnLabel.First"));

        protected Locator nextButton = locator(pwCss(".NextButton.Button"));

        protected Locator extremelyLikely = locator(pwCss(".ColumnLabel.Last"));

        protected Locator whyDidYouGiveARating = locator(pwCss("legend > label"));

        protected Locator whyDidYouGiveARatingTextArea = locator(pwCss(".ChoiceStructure .InputText"));

        protected Locator qualtricsErrorMessage = locator(pwCss("//div[@class='ValidationError']/../div[1]"));

    //label[.//span[text()='No']]
        protected Locator ratingRadioButtonsLabels = locator(pwXPath("//td[./label]//label/span[text()]"));

        protected Locator ratingRadioButtons = locator(pwXPath("//td[./label]//label/span[text()]/ancestor::td/label"));
    private static final String NAVIGATE_AWAY_XPATH = "//mat-dialog-actions/button/span[text()='YES, NAVIGATE AWAY']";
        private Locator navigateAwayButton = locator(pwXPath(NAVIGATE_AWAY_XPATH));

        private Locator yourInfoPageNavigationLink = locator(pwXPath("//a[contains(@data-gtm,'FFQ_Auto_sidepanel_YourInfostepper_button')]"));

        private Locator vehiclesPageNavigationLink = locator(pwXPath("//a[contains(@data-gtm,'FFQ_Auto_sidepanel_Vehiclestepper_button')]"));

        private Locator vehiclesPageSmallScreenNavigationLink = locator(pwXPath("//div[@class='navigationStepperTop']/div/a[2]"));

        private Locator driversPageNavigationLink = locator(pwXPath("//a[contains(@data-gtm,'FFQ_Auto_sidepanel_Driverstepper_button')]"));

        private Locator driversPageSmallScreenNavigationLink = locator(pwXPath("//div[@class='navigationStepperTop']/div/a[3]"));

        private Locator discountsPageNavigationLink = locator(pwXPath("//a[contains(@data-gtm,'FFQ_Auto_sidepanel_Discountstepper_button')]"));

        private Locator discountsPageSmallScreenNavigationLink = locator(pwXPath("//div[@class='navigationStepperTop']/div/a[4]"));

        private Locator quotePageNavigationLink = locator(pwXPath("//a[contains(@data-gtm,'FFQ_Auto_sidepanel_Quotestepper_button')]"));

        private Locator quotePageSmallScreenNavigationLink = locator(pwXPath("//div[@class='navigationStepperTop']/div/a[5]"));

        private Locator saveQuoteAndFinishLaterSidePanelLink = locator(pwXPath("//div[@class='ffq-sidepanel-save-content']"));

        private Locator saveQuoteAndFinishLaterPageLink = locator(pwXPath("//div[@class='ffq-panel-save-text']"));

        private Locator agentImage = locator(pwCss("img[class='agent-image']"));

        private Locator agentSectionYourAgent = locator(pwXPath("//div[contains(@class,'tui-agent-box-column-2')]/div/div[1]"));

        private Locator agentSectionAgentName = locator(pwXPath("//div[contains(@class,'tui-agent-box-column-2')]/div/div[2]"));

        private Locator agentMailID = locator(pwXPath("//div[@class='pre-footer']//p[1]/a/span"));

        private Locator agentAddress = locator(pwXPath("//div[contains(@class,'agent-details-container')]/p/a[@target = '_blank']"));

        private Locator agentPhoneNumber = locator(pwXPath("(//a[contains(@aria-label,'Contact farmers representative')])[2]"));


        private Locator agentContactMeButton = locator(pwId("auto-agent-details__contact-me-link"));

        private Locator noAgentAssigned = locator(pwClass("need-help-caption"));

        private Locator helpPhoneNumber = locator(pwXPath("//*[contains(@class, 'desktop')]/div/div[contains(@class,'agent-detail-phone')]"));

        private Locator smallScreenHelpPhoneNumber = locator(pwXPath("//div[contains(@class,'sidepanel-container')]//div[contains(@class, 'agent-detail-row mobile')]"));

    private static final String BRISTOL_WEST_MODAL_HEADER_XPATH = "//div[contains(@class, 'bristol-west-title')]";
    private static final String BRISTOL_WEST_MODAL_CONTENT_XPATH = "//div[@class='scroll-content']/p[2]";
    private static final String BRISTOL_WEST_LOGO_XPATH = "//*[@id='BwLogo' and string-length(@style)=0]";
    private static final String BRISTOL_WEST_LOGOS_XPATH = "//img[contains(@alt,'Bristol West logo')]";

        private Locator bristolWestModalContent = locator(pwXPath(BRISTOL_WEST_MODAL_CONTENT_XPATH));

        private Locator doNotContinueOnBristolWest = locator(pwXPath("//button[@data-gtm='FFQ_Auto_BWmodal_close_button']"));

        private Locator continueOnBristolWest = locator(pwXPath("//button[contains(@class, 'auto-module_continue-to-bw-button-primary')] | //button[@data-gtm='FFQ_Auto_BWmodal_close_button']/span[text()='Continue']"));

    private static final String CONTINUE_ON_FOREMOST_XPATH = "//button[@data-gtm='FFQ_Auto_Foremostmodal_close_button']";
        private Locator continueOnForemost = locator(pwXPath(CONTINUE_ON_FOREMOST_XPATH));

        private Locator bristolWestLogoByClass = locator(pwClass("bright-line-logo"));

        private Locator inconveniencePageHeader = locator(pwId("inconvenience_header-title"));

    private static final String ACE_CANT_FINISH_QUOTE_TITLE_XPATH = "//*[contains(@class, 'inconvenience__title')]";
        private Locator aceCantFinishQuotePage = locator(pwXPath(ACE_CANT_FINISH_QUOTE_TITLE_XPATH));

        private Locator aceCantFinishQuoteNumber = locator(pwXPath("//*[contains(@class, 'inconvenience__quote-number')]"));

        private Locator inconveniencePageQuoteNumber = locator(pwClass("quote_number"));

        private Locator specialAttentionPageHeader = locator(pwClass("knock-out_header-title"));

        private Locator saveAndExitButton = locator(pwXPath("//button[@data-gtm='FFQ_Auto_savefinishmodal_saveandexit_button']"));

        private Locator enterInfoNavigationBarStepper = locator(pwXPath("//div[@class='tui-desktop-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-enter-info']"));

        private Locator enterInfoNavigationBarStepperMobile = locator(pwXPath("//div[@class='tui-mobile-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-enter-info']"));

        private Locator reviewQuoteNavigationBarStepper = locator(pwXPath("//div[@class='tui-desktop-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-review-quote']"));

        private Locator reviewQuoteNavigationBarStepperMobile = locator(pwXPath("//div[@class='tui-mobile-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-review-quote']"));

        private Locator purchaseNavigationBarStepper = locator(pwXPath("//div[@class='tui-desktop-nav-stepper']//div[@data-tui-tracking-id='navbar-stepper-purchase']"));


    private static final String FARMERS_PHONE_NUMBER = "1-800-206-9469";
    private static final String UPDATED_FARMERS_PHONE_NUMBER = "888-395-2524";
    private static final String FARMERS_PHONE_NUMBER_MONETIZATION_STATE_RATED_QUOTES = "1-800-508-7504";
    private static final String FARMERS_EE_PHONE_NUMBER = "1-888-767-4030";
    private static final String FARMERS_PHONE_NUMBER_MOBILE = "1-800-420-9008";
    private static final String FARMERS_PHONE_NUMBER_MOBILE_MONETIZATION_STATE_RATED_QUOTES = "1-888-654-9784";
    private static final String FARMERS_NC_PHONE_NUMBER = "877-388-6628";
    public static final String OWN_A_HOME = "Own a home";
    public static final String OWN_A_HOUSE = "Own a house";
    public static final String OWN_A_CONDO = "Own a condo or townhome";
    public static final String OWN_A_CONDO_TOWNHOUSE = "Own a condo/townhouse";
    public static final String OWN_APARTMENT = "Own an apartment";
    public static final String OWN_MOBILE_HOME = "Own a mobile or manufactured home";
    public static final String OWN_FARM = "Own a farm";
    public static final String RENT_A_HOME = "Rent a home";
    public static final String RENT_A_CONDO = "Rent a condo, townhome or apartment";
    public static final String RENT_A_CONDO_TOWNHOUSE = "Rent a condo/townhouse";
    public static final String RENT_AN_APARTMENT = "Rent an apartment";
    public static final String RENT_MOBILE_HOME = "Rent a mobile or manufactured home";

    protected List<Locator> setFAQElementList() {
        List<Locator> popupElements = new ArrayList<>();
        popupElements.add(faqDialogTitle);
        popupElements.add(faqDialogContent);
        return popupElements;
    }

    protected void validateProgressbarStatus(String originatingPage, Locator progressbarAceAuto, FarmersSoftAssert fsa) throws Exception {
    	// currently BW does not have the progress bar, so skip checking in case here by mistake
    	if (isBristolWestQuote()) {
    		Log.warn("BW quotes do not have a progress bar");
    	} else {
    		String expectedCompletedValue = EMPTY_STRING;
    		String completedValueFoundInPage = getAttributeData(progressbarAceAuto, ARIA_VALUENOW);
    		Log.info("Completion percentage value found at " + originatingPage + " is " + completedValueFoundInPage);
    		switch (originatingPage) {
    		case "NameAndDobPage" :
    			expectedCompletedValue = "10";
    			break;
    		case "AutoEnterAddressPage" :
    			expectedCompletedValue = "20";
    			break;
    		case "OneMomentPage" : case "VehiclesDriversInfoPage" :
    			expectedCompletedValue = "30";
    			break;
    		case "WhoShouldWeInsurePage" : case "HeresWhatWeFoundPage" :
    			expectedCompletedValue = "40";
    			break;
    		case "VehicleReviewPage":
    			expectedCompletedValue = "50";
    			break;
    		case "DriverReviewPage":
    			expectedCompletedValue = "60";
    			break;
    		case "SignalPageOneUI":
    			expectedCompletedValue = "70";
    			break;
    		case "ContactInfoAutoPage":
    			expectedCompletedValue = "80";
    			break;
    		case "QuoteSummaryAutoPage":
    			expectedCompletedValue = "90";
    			break;
    		case "AdditionalInfoPolicyStartDateOneUI":
    			expectedCompletedValue = "98";
    			break;
    		default:
    			throw new Exception("Unexpected page name provided: " + originatingPage);
    		}
    		fsa.assertTrue(progressbarAceAuto.isVisible(),"Progressbar is present on " + originatingPage);
    		fsa.assertEquals(completedValueFoundInPage, expectedCompletedValue, "Progress value check on "  + originatingPage);
    	}
    }

    protected Map<Locator, String> setFAQExpectedContentMap(String helpPopupTitle, String helpText) {
        Map<Locator, String> popupContentMap = new HashMap<>();
        waitElementBeVisible(faqDialogTitle);
        waitElementBeVisible(faqDialogContent);
        popupContentMap.put(faqDialogTitle, helpPopupTitle);
        popupContentMap.put(faqDialogContent, helpText);
        return popupContentMap;
    }

    protected void validateFAQ(Locator faqButton, String faqTitleText, String faqContentText, FarmersSoftAssert fsa) throws Exception {
        waitAndClickElement(faqButton);
        verifyElementExpectedContent(setFAQElementList(), setFAQExpectedContentMap(faqTitleText, faqContentText), fsa);
        closeFAQDialog();
    }

    protected void validateFAQNoTitle(Locator faqButton, String faqContentText) {
        waitAndClickElement(faqButton);
        if (!isElementPresent(pwClass("dialog_info-dialog-content"), 3)) {
            scrollAndClickOnElement(faqButton);
        }
        waitElementBeVisible(faqDialogContent);
        Assert.assertEquals(getTextFromElement(faqDialogContent), faqContentText, "Text error,");
        closeFAQDialog();
    }

    protected List<String> getDropdownOptions(Locator dropdown, boolean useAriaOwns) throws Exception {
        return getAllOptionsFromADropdown(dropdown, useAriaOwns, true);
    }

    private List<String> getAllOptionsFromADropdown(Locator dropdown, boolean useAriaOwns, boolean retryIfStaleElement) throws Exception {
        scrollAndClickOnElement(dropdown);
        List<Locator> elementsInDropdown = useAriaOwns ? getListUsingAriaOwns(dropdown) : locators(pwXPath(DROPDOWN_OPTIONS_XPATH));
        List<String> optionsListed = new ArrayList<>();
        for (Locator e : elementsInDropdown) {
            try {
                String elementText = getTextFromElement(e);
                if (!elementText.equals(EMPTY_STRING)) {
                    optionsListed.add(elementText);
                }
            } catch (PlaywrightException sere) {
                Log.error("Stale element exception caught for " + e);
                if (retryIfStaleElement) {
                    Log.error(" retry getting options ");
                    return getAllOptionsFromADropdown(dropdown, useAriaOwns, false);
                }
            }
        }
        if (optionsListed.isEmpty()) {
            Log.warn(dropdown + " returned an empty list.");
            if (retryIfStaleElement) {
                Log.warn("trying again.");
                return getAllOptionsFromADropdown(dropdown, useAriaOwns, false);
            }
        }
        clickElement(dropdown);
        return optionsListed;
    }

    private List<Locator> getListUsingAriaOwns(Locator dropdown) throws Exception {
        List<Locator> elementsInDropdown = new ArrayList<>();
        String listOfOptions = getAttributeData(dropdown, ARIA_OWNS);
        if (listOfOptions != null) {
            StringTokenizer tokens = new StringTokenizer(listOfOptions.trim(), SPACE);
            while (tokens.hasMoreTokens()) {
                elementsInDropdown.add(locator(pwId(tokens.nextToken())));
            }
        }
        return elementsInDropdown;
    }

    public boolean isRealAgentAssigned() throws Exception {
        return !locators(pwXPath("//div[contains(@class,'tui-agent-box-column')]//div[text()='Your agent']")).isEmpty();
    }

    public String getAssignedRealAgentName() throws Exception {
        Locator agentName = locator(pwXPath("//div[contains(@class,'tui-agent-box-column')]//div[@class='tui-body-bold']"));
        scrollToElement(agentName);
        return getTextFromElement(agentName);
    }

    protected void selectFromDropDownByPosition(Locator dropdown, int position, Locator resetElement) throws Exception {
        try {
            scrollElementToMiddle(dropdown);
            clickOnHiddenElement(dropdown);
            List<Locator> elementsInDropdown = locators(pwXPath(DROPDOWN_OPTIONS_XPATH));
            if (elementsInDropdown.isEmpty()) {
                Log.info("Try again to find elements in dropdown " + dropdown);
                clickOnHiddenElement(dropdown);
                elementsInDropdown = locators(pwXPath(DROPDOWN_OPTIONS_XPATH));
            }
            if (!elementsInDropdown.isEmpty()) {
                int numberOfOptions = elementsInDropdown.size();
                if (position == LAST_AVAILABLE_OPTION || position == NEXT_TO_LAST_AVAILABLE_OPTION) {
                    position += numberOfOptions;
                }
                for (int index = 0; index < numberOfOptions; index++) {
                    dropdown.press(Keys.ARROW_UP);
                }
                for (int index = 0; index < position; index++) {
                    dropdown.press(Keys.ARROW_DOWN);
                }
                clickElement(resetElement);
            } else {
                Log.error("Did not find any elements in dropdown " + dropdown);
            }
        } catch (PlaywrightException see) {
            Log.warn("see found " + see.getMessage());
            dropdown = refreshElement(dropdown);
            selectFromDropDownByPosition(dropdown, position, resetElement);
        }

    }

    protected void checkForKnockout(String where) throws KnockoutException {
        checkForKnockout(where, EMPTY_STRING);
    }

    protected void checkForKnockout(String where, String quoteNumber) throws KnockoutException {
        String quoteInfo = !quoteNumber.equals(EMPTY_STRING)? " for quote " + quoteNumber : quoteNumber;
        if (isElementPresentByClass(specialAttentionPageHeader)) {
            throw new KnockoutException("Special Attention page reached from " + where + quoteInfo + NEWLINE);
        } else if (isElementPresentByID(inconveniencePageHeader)) {
            if (quoteNumber.equals(LOB_AUTO)) {
                quoteInfo = " for quote " + getTextFromElement(inconveniencePageQuoteNumber).replaceAll("\\D", EMPTY_STRING);
            }
            throw new KnockoutException("Inconvenience page reached from " + where + quoteInfo + NEWLINE);
        } else if (isLegacyQuoteKnockout()) {
            throw new KnockoutException("Inconvenience or Special Attention page reached from " + where + quoteInfo + NEWLINE);
        } else if (isElementPresentByXPath(ACE_CANT_FINISH_QUOTE_TITLE_XPATH)) {
            quoteInfo = " for quote " + getTextFromElement(aceCantFinishQuoteNumber).replaceAll("\\D", EMPTY_STRING);
            throw new KnockoutException("Inconvenience page reached from " + where + quoteInfo + NEWLINE);
        }
    }

    protected void navigateBackToPreviousPage() throws Exception {
        back();
        waitUntilAngular5Ready();
    }

    @SuppressWarnings("serial")
    public static class KnockoutException extends Exception {
        public KnockoutException(String errorMessage) {
            super(errorMessage);
        }
    }

    protected boolean isFarmersPhoneNumberCorrect(String stateCode, String callingMethod) {
        boolean isMobile = isSmallScreenUsed();
        boolean tcResult = false;
        String phoneNumberObserved = isMobile ? getSmallScreenPhoneNumber() : getTextFromElement(helpPhoneNumber);
        if (phoneNumberObserved.isEmpty() || isElementPresentByXPath(AGENT_ASSIGNED_NAME_XPATH)) {
            Log.info("Found assigned agent");
            tcResult = true;
        } else {
            String phoneNumberExpected = isMobile ? FARMERS_PHONE_NUMBER_MOBILE : FARMERS_PHONE_NUMBER;
            if ((isBristolWestQuote() || isDigitalMonetizationState(stateCode)) && callingMethod.contains("QuotePageAuto")) {
                phoneNumberExpected = isMobile ? FARMERS_PHONE_NUMBER_MOBILE_MONETIZATION_STATE_RATED_QUOTES : FARMERS_PHONE_NUMBER_MONETIZATION_STATE_RATED_QUOTES;
            } else if (!isMobile) {
                String yourInfoPage = "YourInfoPageAuto";
                if (isEasternExpansionState(stateCode) && !stateCode.equals(LA)) {
                    if (stateCode.equals(KY) && !callingMethod.contains(yourInfoPage)) {
                        phoneNumberExpected = FARMERS_PHONE_NUMBER;
                    } else if (stateCode.equals(NC) && !callingMethod.contains(yourInfoPage)) {
                        phoneNumberExpected = FARMERS_NC_PHONE_NUMBER;
                    } else {
                        phoneNumberExpected = FARMERS_EE_PHONE_NUMBER;
                    }
                } else if (!callingMethod.contains(yourInfoPage) && !isBristolWestQuote() && !isElementPresentByClass(noAgentAssigned)) {
                    phoneNumberExpected = UPDATED_FARMERS_PHONE_NUMBER;
                }
            }
            tcResult = phoneNumberObserved.equals(phoneNumberExpected);
            if (!tcResult) {
                Log.warn("Observed[" + phoneNumberObserved + "] expected[" + phoneNumberExpected + "]");
            }
        }
        return tcResult;
    }

    private String getSmallScreenPhoneNumber() {
        waitAndClickElement(redesignedSummaryPopupButton);
        if (isElementPresentByXPath(AGENT_ASSIGNED_NAME_XPATH)) {
            waitAndClickElement(redesignedSummaryPopupButton);
            return EMPTY_STRING;
        }
        String phoneNumber = getTextFromElement(waitElementBeVisible(smallScreenHelpPhoneNumber));
        waitAndClickElement(redesignedSummaryPopupButton);
        return phoneNumber;
    }

    public boolean isHomeowner(AutoApplicant applicant) {
        return applicant.getDiscounts().stream().filter(each -> {
            String ownOrRentHome = each.getOwnOrRentHome();
            return ownOrRentHome.contains("Own");
        }).count() > 0;
    }

    public void clickQuickLink(String pageToNavigate) {
        if (isAutoSmallScreenUsed()) {
            switch (pageToNavigate) {
                case YOUR_INFO:
                    scrollAndClickOnElement(yourInfoPageSmallScreenNavigationLink);
                    break;
                case VEHICLES:
                    scrollAndClickOnElement(vehiclesPageSmallScreenNavigationLink);
                    break;
                case DRIVERS:
                    scrollAndClickOnElement(driversPageSmallScreenNavigationLink);
                    break;
                case DISCOUNTS:
                    scrollAndClickOnElement(discountsPageSmallScreenNavigationLink);
                    break;
                case QUOTE:
                    scrollAndClickOnElement(quotePageSmallScreenNavigationLink);
                    break;
                default:
                    Log.error("Invalid page selected: " + pageToNavigate);
                    break;
            }
        } else {
            switch (pageToNavigate) {
                case YOUR_INFO:
                    scrollAndClickOnElement(yourInfoPageNavigationLink);
                    break;
                case VEHICLES:
                    scrollAndClickOnElement(vehiclesPageNavigationLink);
                    break;
                case DRIVERS:
                    scrollAndClickOnElement(driversPageNavigationLink);
                    break;
                case DISCOUNTS:
                    scrollAndClickOnElement(discountsPageNavigationLink);
                    break;
                case QUOTE:
                    scrollAndClickOnElement(quotePageNavigationLink);
                    break;
                case SAVE_AUTO_QUOTE_FINISH_LATER_PAGE_LINK:
                    scrollAndClickOnElement(saveQuoteAndFinishLaterPageLink);
                    break;
                case SAVE_AUTO_QUOTE_FINISH_LATER_SIDE_LINK:
                    scrollAndClickOnElement(saveQuoteAndFinishLaterSidePanelLink);
                    break;
                default:
                    Log.error("Invalid page selected: " + pageToNavigate);
                    break;
            }
        }
        if (isElementPresentByXPath(NAVIGATE_AWAY_XPATH)) {
            clickElement(navigateAwayButton);
        }
        waitForSpinnerToBeGone();
    }

    protected boolean isBrightlinedQuote() {
        return isElementPresent(pwXPath(BRISTOL_WEST_MODAL_HEADER_XPATH), 2);
    }

    public boolean isBristolWestQuote() {
        return (isElementPresentByClass(bristolWestLogoByClass) || isElementPresentByXPath(BRISTOL_WEST_LOGO_XPATH) || isElementPresentByXPath(BRISTOL_WEST_LOGOS_XPATH) || isBrightlinedQuote());
    }

    protected void continueToBristolWest(boolean continueQuoteOnBristolWest) {
        if (isElementPresentByXPath(BRISTOL_WEST_MODAL_CONTENT_XPATH)) {
            scrollElementToMiddle(bristolWestModalContent);
        }
        if (isBrightlinedQuote()) {
            if (isElementPresentByXPath(CONTINUE_ON_FOREMOST_XPATH)) {
                waitAndClickElement(continueOnForemost);
            } else {
                if (continueQuoteOnBristolWest) {
                    waitAndClickElement(continueOnBristolWest);
                } else {
                    waitAndClickElement(doNotContinueOnBristolWest);
                }
            }
            longWaitForElementToBeGoneByXpath(BRISTOL_WEST_MODAL_CONTENT_XPATH);
        }
    }

    protected boolean saveAutoQuoteAndFinishLater(SqlApplicant applicant, String pageSavedQuoteIn, boolean isSaveRetrieveScenario) {
        if (isSaveRetrieveScenario) {
            if (findInCallStack(SAVE_AUTO_QUOTE)) {
                saveAutoApplicant(applicant, pageSavedQuoteIn, getRedesignedQuoteNumber());
                if (pageSavedQuoteIn.equals(QUOTE_PAGE_AUTO)) {
                    clickQuickLink(SAVE_AUTO_QUOTE_FINISH_LATER_SIDE_LINK);
                } else {
                    clickQuickLink(SAVE_AUTO_QUOTE_FINISH_LATER_PAGE_LINK);
                }
                clickElement(saveAndExitButton);
                waitForSpinnerToBeGone();
            } else {
                return false;
            }
        }
        return isSaveRetrieveScenario;
    }

    protected static synchronized void saveAutoApplicant(SqlApplicant applicant, String leftPage, String quoteNumber) {
        ApplicantRetQuote applicantRetQuote = new ApplicantRetQuote();
        applicantRetQuote.setLastName(applicant.getLastName());
        applicantRetQuote.setAge(applicant.getAge());
        applicantRetQuote.setZipCode(applicant.getZipCode());
        applicantRetQuote.setEmailAddress(applicant.getEmail());
        applicantRetQuote.setQuoteNumber(quoteNumber);
        applicantRetQuote.setPageLeftOn(leftPage);
        returningQuoteConcurrentHashMap.put(applicant.getLastName() + applicant.getZipCode(), applicantRetQuote);
        Log.info("Successfully saved data model object: " + applicantRetQuote);
    }

    protected void verifyAllAvailableValuesForMapOfDropdowns(LinkedHashMap<Locator, List<String>> expectedValuesMap, Locator resetElement, FarmersSoftAssert fsa) throws Exception {
        for (Map.Entry<Locator, List<String>> entry : expectedValuesMap.entrySet()) {
            Locator dropdown = entry.getKey();
            List<String> listOfExpectedValues = entry.getValue();
            List<String> listOfAvailableValues = getDropdownOptions(dropdown, false);
            fsa.assertEquals(listOfAvailableValues, listOfExpectedValues, "Value check for " + dropdown);
            scrollAndClickOnElement(resetElement);
        }
    }

    protected void verifyListOfLinks(List<Locator> links, LinkedHashMap<String, String> destinationsAndTitles) throws Exception {
        String linkName = "";
        String[] arrLinkName;
        Page baseWindow = currentPage();
        List<Page> newHandles = pages();
        int activeWindows = newHandles.size();
        if (activeWindows != 1) {
            for (Page handle : newHandles) {
                if (!baseWindow.equals(handle)) {
                    switchToPage(handle);
                    closeCurrentPage();
                }
            }
            switchToPage(baseWindow);
            activeWindows = pages().size();
        }
        boolean isMobile = isSmallScreenUsed();
        if (isMobile) { // Glitch causes links to not appear first time panel is opened
            waitAndClickElement(redesignedSummaryPopupButton);
            waitAndClickElement(redesignedSummaryPopupButton);
            waitAndClickElement(redesignedSummaryPopupButton);
            waitAndClickElement(redesignedSummaryPopupButton);
        }
        for (Locator element : links) {
            String url = getAttributeData(element, HREF);
            String tempLinkName = getAttributeData(element, "data-tui-tracking-id");
            if (!tempLinkName.isEmpty()) {
                arrLinkName = tempLinkName.split("_");
                linkName = arrLinkName[1];
            }
            if (!url.contains("instagram") && !tempLinkName.isEmpty()) {
                if (!(url.contains("apps.apple.com") && isSafariBrowser())) {
                    if (isMobile) {
                        waitAndClickElement(redesignedSummaryPopupButton);
                    }
                    waitAndClickElement(element);
                    boolean linkReached = false;

                    conditionalWait(15).until(Conditions.pageCount(activeWindows + 1));
                    newHandles = pages();
                    activeWindows = newHandles.size();
                    for (Page handle : newHandles) {
                        if (!baseWindow.equals(handle)) {
                            switchToPage(handle);
                            conditionalWait(Property.PAGELOADTIMEOUT).until(Conditions.textMatches(pwXPath("//title"), java.util.regex.Pattern.compile(".*\\S*")));
                            String currentURL = page().url();
                            String pageTitle = page().title().replace("\u00a0", SPACE).replace("\u2019", "'").replace("\u201c", "\"").replace("\u201d", "\"").replaceAll("\\p{Cntrl}", SPACE).replace("\r", SPACE).replace("\\s+", SPACE).strip();
                            for (Map.Entry<String, String> entry : destinationsAndTitles.entrySet()) {
                                String destinationURL = entry.getKey();
                                String expectedTitle = entry.getValue();
                                if (currentURL.contains(destinationURL)) {
                                    testStepAssert(pageTitle.contains(expectedTitle), "Validate page title.Expected: (" + expectedTitle + ") And Actual: (" + pageTitle + ")");
                                    linkReached = true;
                                    closeCurrentPage();
                                    activeWindows--;
                                    break;
                                }
                            }
                        }
                    }
                    switchToPage(baseWindow);
                    if (!linkReached) {
                        if (!linkName.equals("")) {
                            testStep("Validation not success for link: " + linkName, false, true, false);
                        }
                        Log.error("*** destination not reached for " + element);
                    }
                    if (isMobile) {
                        waitAndClickElement(redesignedSummaryPopupButton);
                    }
                }
            }
        }
    }

    protected void verifyCurrentSelectedValueForMapOfDropdowns(LinkedHashMap<Locator, String> dropdownsAndExpectedValue, FarmersSoftAssert fsa) {
        Log.info("Verifying current selection of each dropdown");
        for (Map.Entry<Locator, String> entry : dropdownsAndExpectedValue.entrySet()) {
            Locator dropdown = entry.getKey();
            String expectedValue = entry.getValue();
            scrollElementToMiddle(dropdown);
            fsa.assertEquals(expectedValue, getTextFromElement(dropdown), "Default value in "+ dropdown);
        }
    }

    /**
     * Setting/unsetting a mat-checkbox.
     */
    protected void setMatcheckboxTo(Locator matCheckbox, boolean setBoxToChecked) {
    	boolean isMatcheckboxSelected = getAttributeData(matCheckbox, CLASS).contains(MAT_CHECKBOX_CHECKED);
    	if (isMatcheckboxSelected != setBoxToChecked) {
    		clickElement(matCheckbox);
    	}
    }

    protected boolean testExpectedTextContentForElement(Locator element, String expectedText) {
        String elementTextFound = getTextFromElement(element);
        if (elementTextFound.equals(expectedText)) {
            return true;
        } else {
            Log.error("[" + elementTextFound + "] element text did not equal expected [" + expectedText + "]");
            return false;
        }
    }

    protected boolean testExpectedAriaLabelForElement(Locator element, String expectedText) {
        String elementAriaLabel = getAttributeData(element, ARIA_LABEL);
        if (elementAriaLabel == null) {
            elementAriaLabel = EMPTY_STRING;
        }
        if (elementAriaLabel.equals(expectedText)) {
            return true;
        } else {
            Log.error("[" + elementAriaLabel + "] element aria label did not equal expected [" + expectedText + "]");
            return false;
        }
    }

    protected boolean testExpectedTextContentContainsForElement(Locator element, String expectedTextContains) {
        String elementTextFound = getTextFromElement(element);
        if (elementTextFound.contains(expectedTextContains)) {
            return true;
        } else {
            Log.info("[" + elementTextFound + "] element text did not contain expected [" + expectedTextContains + "]");
            return false;
        }
    }

    protected boolean testExpectedValueForElement(Locator element, String expectedValue) {
        String elementValueFound = getElementValue(element, "element value: ").trim();
        if (elementValueFound.equals(expectedValue)) {
            return true;
        } else {
            Log.error("[" + elementValueFound + "] element value did not equal expected [" + expectedValue + "]");
            return false;
        }
    }

    protected boolean testIsEnabledForElement(Locator element, boolean bEnabled, String elementName) {
        if (element.isEnabled() == bEnabled) {
            return true;
        } else {
            Log.error("[" + elementName + "] is element enabled: " + element.isEnabled() + " expected: " + bEnabled);
            return false;
        }
    }

    protected void closeFAQDialog() {
        clickElement(faqDialogCloseButton);
    }

    public void clickContinueToNextPage() {
        scrollToElement(buttonNext);
        waitAndClickElement(buttonNext);
        waitForSpinnerToBeGone();
    }

    public void clickBack() {
        waitAndClickElement(buttonBack);
    }

    public int limitVehicleCountToMaxAllowed(String stateCode, int currentVehicleCount) {
        switch (stateCode) {
            case ID:
            case KS:
            case NE:
                return Math.min(currentVehicleCount, MAX_NUMBER_OF_VEHICLES_FOUR);
            default:
                return Math.min(currentVehicleCount, MAX_NUMBER_OF_VEHICLES);
        }
    }

    protected boolean isBusinessInsuranceState(String stateCode) {
        List<String> noBusinessInsuranceOfferingStates = new ArrayList<>(Arrays.asList(CA));
        return !(noBusinessInsuranceOfferingStates.contains(stateCode) || isEasternExpansionState(stateCode));
    }

    protected boolean isCondoCrossSellDisabledState(String stateCode) {
        List<String> condoCrossSellDisabledStates = new ArrayList<>(Arrays.asList(WA));
        return condoCrossSellDisabledStates.contains(stateCode);
    }

    protected boolean isHomeCrossSellDisabledState(String stateCode) {
        List<String> homeCrossSellDisabledStates = new ArrayList<>(Arrays.asList(AL, CA, CT, KY, MI));
        return homeCrossSellDisabledStates.contains(stateCode);
    }

    protected boolean isRentersCrossSellDisabledState(String stateCode) {
        List<String> rentersCrossSellDisabledStates = new ArrayList<>(Arrays.asList(WA));
        return rentersCrossSellDisabledStates.contains(stateCode);
    }

    public boolean isSignalDiscountDisabledState(String stateCode) throws Exception {
        SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
        if (stateCode.equals(OR) && signalPageOneUI.isOnSignalPage()) {
            return false;
            // for OR state we have AB testing where some users will see signal discount and some will not see, so we are allowing both scenarios for OR state
        }
        //Finding that some states are disabling signal in MA11
        if (isMA11Environment()) {
        	return new ArrayList<>(Arrays.asList(AK, CA, DC, DE, FL, HI, KY, ME, NH, NY, OR, RI, SC, VT, WV)).contains(stateCode);
        } else {
        	return new ArrayList<>(Arrays.asList(AK, CA, DC, DE, FL, HI, ME, NH, NY, OR, RI, SC, VT, WV)).contains(stateCode);
        }
    }

    protected boolean isEmploymentDiscountDisabledState(String stateCode) {
        List<String> employmentDiscountEnabledStates = new ArrayList<>(Arrays.asList(MA, MS, NC, LA, KY, FL));
        return employmentDiscountEnabledStates.contains(stateCode);
    }

    protected boolean isLifeInsuranceOfferingState(String stateCode) {
        List<String> noLifeInsuranceOfferingStates = new ArrayList<>(Arrays.asList(AR, CA, CO, CT, FL, MI, MT, ND, NJ, NY, SD, VA));
        return !(noLifeInsuranceOfferingStates.contains(stateCode) || isEasternExpansionState(stateCode));
    }

    protected boolean isUmbrellaInsuranceState(String stateCode) {
        List<String> noUmbrellaInsuranceOfferingStates = new ArrayList<>(Arrays.asList(AL, AZ));
        return !(noUmbrellaInsuranceOfferingStates.contains(stateCode) || isEasternExpansionState(stateCode));
    }

    protected boolean isDigitalMonetizationState(String stateCode) {
        return SqlDataProviders.getListOfLegacyAutoMonetizedStates(Property.getUri()).contains(stateCode);
    }

    public boolean isEmployerGroupQuestionState(String stateCode) {
        if (isTSK1Environment()) {
            List<String> employerQuestionStates = new ArrayList<>(Arrays.asList(AL, AR, CA, CT, FL, ID, NV, NY, WA));
            return employerQuestionStates.contains(stateCode);
        } else if (isMA61Environment()) {
            List<String> employerQuestionStates = new ArrayList<>(Arrays.asList(MT));
            return employerQuestionStates.contains(stateCode);
        } else if (isPETEnvironment()) {
            List<String> employerQuestionStates = new ArrayList<>(Arrays.asList(AL, AR, CA, CT, FL, ID, NV, NY, TN, WA));
            return employerQuestionStates.contains(stateCode);
        } else if (isRA11Environment()) {
            List<String> employerQuestionStates = new ArrayList<>(Arrays.asList(AL, AR, CO, CT, FL, IA, ID, IN, KS, KY, MA, MD, MN, MS, MT, NC, ND, NE, NJ, NM, NY, OH, OK, OR, PA, SD, TN, TX, UT, VA, WA, WI, WY));
            return employerQuestionStates.contains(stateCode);
        } else {
            List<String> employerQuestionStates = new ArrayList<>(Arrays.asList(AL, AR, CA, CT, FL, NV, NY, WA));
            return employerQuestionStates.contains(stateCode);
        }
    }

    public void enterEmailInSaveQuoteModal(String emailId) throws Exception {
        boolean isOnBw = isOnBristolWest();
        clickOnSaveQuoteButton();
        waitForSpinnerToBeGone();
        if(isOnBw) {
            waitAndClickElement(closeIcon);
            return;
        }
        waitElementBeVisible(saveQuoteModalEmailInputField);
        String inputFieldDisabled = getAttributeData(saveQuoteModalEmailInputField, "readonly");
        if (!inputFieldDisabled.equals(LOWERCASE_TRUE)) {
            sendKeysToElement(saveQuoteModalEmailInputField, emailId);
        }
        clickSaveQuoteModalSubmitButton();
    }

    public boolean isAutoSaveDisabled() {
        return isElementPresent(pwXPath(SAVE_QUOTE_BUTTON_XPATH), 3);
    }

    public void clickOnSaveQuoteButton() throws Exception {
        if (isAutoSaveDisabled()) {
            Locator element = locator(pwXPath(SAVE_QUOTE_BUTTON_XPATH));
            scrollAndClickOnElement(element);
        }
    }

    @SneakyThrows
    protected String getInputFieldValue(Locator webElement) {
        return (String) executeScript("return arguments[0].value;", webElement);
    }

    protected void waitUntilAngular5Ready() throws Exception {
        try {
            Object angular5Check = executeScript("return getAllAngularRootElements()[0].attributes['ng-version']");
            if (angular5Check != null) {
                Boolean angularPageLoaded = (Boolean) executeScript("return window.getAllAngularTestabilities().findIndex(x=>!x.isStable()) === -1");
                if (!angularPageLoaded) {
                    waitForAngular5Load();
                }
            }
        } catch (PlaywrightException ignored) {
        }
    }

    @SneakyThrows
    public void clickEnterInfoNavigationBarStepper() {
        if (isUseMobileViewEnabled()) {
            scrollAndClickOnElement(enterInfoNavigationBarStepperMobile);
        } else {
            scrollAndClickOnElement(enterInfoNavigationBarStepper);
        }
        waitForSpinnerToBeGone();
    }

    @SneakyThrows
    public void clickReviewQuoteNavigationBarStepper() {
        if (isUseMobileViewEnabled()) {
            scrollAndClickOnElement(reviewQuoteNavigationBarStepperMobile);
        } else {
            scrollAndClickOnElement(reviewQuoteNavigationBarStepper);
        }
        waitForSpinnerToBeGone();
    }

    @SneakyThrows
    public void clickPurchaseNavigationBarStepper() {
        scrollAndClickOnElement(purchaseNavigationBarStepper);
        waitForSpinnerToBeGone();
    }

    private void waitForAngular5Load() throws Exception {
        String angularReadyScript = "return window.getAllAngularTestabilities().findIndex(x=>!x.isStable()) === -1";
        angularLoads(angularReadyScript);
    }

    private void angularLoads(String angularReadyScript) {
        try {
            page().waitForCondition(
                    () -> Boolean.TRUE.equals(page().evaluate(angularReadyScript.replaceFirst("^return\\s+", ""))),
                    new Page.WaitForConditionOptions().setTimeout(10_000));
        } catch (PlaywrightException ignored) {
            Log.debug("Angular stability API is not available on this page; Locator auto-wait remains active.");
        }
    }


    protected boolean enterGoogleAddressAce(Locator addressTextBox, String streetAddress, String stateName, String city) {
        Log.info("Entering Residential Address with google lookup: " + streetAddress + SPACE + stateName);
        scrollElementToMiddle(addressTextBox);
        sendKeysOneByOne(addressTextBox, streetAddress + SPACE + stateName + SPACE);
        waitForUiSettled();
        try {
            sendKeys(addressTextBox, Keys.DOWN);
            sendKeys(addressTextBox, Keys.RETURN);
            waitForSpinnerToBeGone();
            sendKeysToElement(addressTextBox, Keys.TAB);
            return getAttributeData(addressTextBox, CLASS).contains("ng-valid");
        } catch (Exception e) {
            enterValueInField(streetAddress, addressTextBox, "Entering Residential Address ");
            return false;
        }

    }

    public void switchDriverToNewlyOpenedTab(Page origionWindowHandle) throws Exception {
        wait.until(Conditions.pageCount(2));
        List<Page> windowHandles = pages();
        Page farmersPageWindowHandle = windowHandles.stream().filter(handle -> !handle.equals(origionWindowHandle)).findFirst().get();
        switchToPage(farmersPageWindowHandle);
    }

    public boolean isQualtricsSurveyFormDisplayed() {
        scrollElementToMiddle(qualtricsSurveyPopUp);
        return isElementVisible(qualtricsSurveyPopUp, 5);
    }

    protected void clickOnYesIWillGiveFeedbackButton() {
        waitAndClickElement(yesIWillGiveFeedbackButton);
    }

    public boolean isSafetyCourseExpectedState(String stateCode) {
        // given states are not asking for safety course
        return !Arrays.asList(IA, LA, MO, NE, IN, TX).contains(stateCode);
    }

    public boolean isSafetyCourseExpectedStateBDQ(String stateCode) {
        // given states are asking for safety course
        return Arrays.asList(AL, CO, CT, FL, ID, IL, KS, KY, MA, MN, MS, MT, NC, NJ, NM, NV, OH, OR, PA, SD, TN, UT, WA, WI, WY).contains(stateCode);
    }

    public boolean isFinancialFilingQuestionDisabled(String stateCode) {
        return Arrays.asList(CA, KY, MA, NM).contains(stateCode);
    }

    public boolean isHomeownerDiscountDisabledState(AutoApplicant applicant) {
        return Arrays.asList(MN, MA, CA, MI).contains(applicant.getStateCode());
    }

    public boolean isRedState(AutoApplicant applicant) {
        return Arrays.asList(GA, KY, LA, MA, MS, NC, NV, FL).contains(applicant.getStateCode());
    }

    protected boolean doesElementHaveFocus(Locator element) {
        try {
            return element.equals(activeElement());
        } catch (Exception e) {
            Log.info("Exception in page() call");
            return false;
        }
    }

    public void clickAgentContactMeButton() throws Exception {
        scrollElementToMiddle(agentContactMeButton);
        clickElement(agentContactMeButton);
    }

    public boolean isDiscountPresentInTheSideSheet(String discount) {
        List<String> listOfDisplayedDiscounts = getDisplayedDiscounts();
        Log.info("List of displayed discounts: " + listOfDisplayedDiscounts.toString());
        return listOfDisplayedDiscounts.stream().anyMatch(d -> d.equals(discount));
    }

    public void clickCloseIcon() {
        waitAndClickElement(closeIcon);
    }

    public boolean isOnFarmers() throws Exception {
        waitForSpinnerToBeGone();
        return isElementDisplayed(pwXPath(FARMERS_LOGO_XPATH));
    }

    private List<String> getGroupSelectionRequiredStates() {
        return Arrays.asList(AR, AZ, IN, LA, MI, ND, NJ, NV, TX, WI);
    }

    public void processConsentSelection(String brand) throws Exception {
        if (getGroupSelectionRequiredStates().contains(getSessionStorageAppStore().getData().getLandingStateCode()) && isElementPresent(pwXPath("//div[@class='tui-stacking-top-sm ms-8 ng-star-inserted' and contains(.,'Farmers')]//mat-checkbox"))) {
            Locator brandCheckbox = locator(pwXPath(String.format("//div[@class='tui-stacking-top-sm ms-8 ng-star-inserted' and contains(.,'%s')]//mat-checkbox", brand)));
            scrollAndClickOnElement(brandCheckbox);
            wait.until(Conditions.attributeContains(brandCheckbox, CLASS, MAT_CHECKBOX_CHECKED));
        }
    }

    protected boolean isAntiTheftRecoverySystemEnabledState(String stateCode) {
        return Arrays.asList(PA, IL, NM, MN).contains(stateCode);
    }

    //BDQ global variable;
	private static final ThreadLocal<Boolean> isBDQEnabled = ThreadLocal.withInitial(() -> Property.getTestProperty("isBDQFlow").equals(LOWERCASE_TRUE));
	public void setBDQEnabled(boolean value) {
		isBDQEnabled.set(value);
	}

    public boolean isBDQFlowEnabled() {
    	return isBDQEnabled.get();
    }

    /** Fallback VINs for non-CA states when randomvin.com is unreachable. */
    private static final List<String> FALLBACK_VINS = new ArrayList<>(Arrays.asList(
            "JTDZN3EU6FJ018916", "1N4AL3AP4FC113357", "1C3CCBBB0CN135263",
            "JHMCM56426C010995", "WAUGGAFC0CN057935", "1J8HS48P67C591216",
            "4T1BK36BX6U166973", "3FAHP0HA2AR108753", "JTDKB20U040008574",
            "1FTEF15Y4TLB76013", "2C4RDGBG1CR248833", "6G2VX12G54L224085",
            "1HVBBAANXWH591509", "1GKDS13SX32291246", "WBAVB33536KS38833",
            "JF1GPAL63E8273576", "1GYFK63837R234352", "1B3LC56B19N570150",
            "1GKS1AE07BR356694", "JT3HT05J5X0062634", "1J4PN5GK2BW555028"
    ));

    /** Fallback VINs specific to the CA state. */
    private static final List<String> FALLBACK_VINS_CA = new ArrayList<>(Arrays.asList(
            "1C4RJFAG1KC853821", "5TFDY5F1XMX988098", "19UYA42633MKMKP3Z", "19UUA56771C8JBMUV"
    ));

    public boolean isBwFarmersQuotePresentmentPageExpected(String stateCode, boolean rideShareInvolved, String biLimit) {
        List<String> applicableStates = new ArrayList<>(Arrays.asList(AZ, CO, IL, MI, PA, TX));
        return applicableStates.contains(stateCode) && !biLimit.equals(_500K_AND_500K) && !rideShareInvolved;
    }

    /**
     * Returns a random VIN using the state stored by the active FFQ application.
     * Callers that run before application navigation must use the state-aware
     * overload instead of reading sessionStorage from about:blank.
     */
    public String getRandomVinNumber(int retry) throws Exception {
        return getRandomVinNumber(retry, resolveVinStateCodeFromActiveApplication());
    }

    /**
     * Returns a random VIN for a known applicant state without consulting browser
     * storage. This overload is safe during pre-navigation test-data preparation.
     */
    public String getRandomVinNumber(int retry, String stateCode) throws Exception {
        String normalizedStateCode = StringUtils.trimToEmpty(stateCode).toUpperCase(Locale.ROOT);
        if (normalizedStateCode.isEmpty()) {
            throw new IllegalArgumentException("A state code is required to select an appropriate VIN.");
        }
        return getRandomVinNumberForState(Math.max(retry, 0), normalizedStateCode);
    }

    private String getRandomVinNumberForState(int retry, String stateCode) throws Exception {
        String randomVINNumber = null;

        try {
            // Preserve the legacy randomvin.com behavior. When the external service
            // is unavailable, the existing deterministic fallback pools are used.
            TrustManager[] trustAll = new TrustManager[]{
                    new X509TrustManager() {
                        public X509Certificate[] getAcceptedIssuers() {
                            return new X509Certificate[0];
                        }

                        public void checkClientTrusted(X509Certificate[] certs, String authType) {
                        }

                        public void checkServerTrusted(X509Certificate[] certs, String authType) {
                        }
                    }
            };
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, trustAll, new java.security.SecureRandom());
            HostnameVerifier allowAll = (String hostname, SSLSession session) -> true;

            URL url = new URL("https://randomvin.com/getvin.php?type=valid");
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setSSLSocketFactory(sslContext.getSocketFactory());
            con.setHostnameVerifier(allowAll);
            con.setConnectTimeout(5000);
            con.setReadTimeout(5000);
            con.setRequestMethod("GET");

            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    randomVINNumber = inputLine.trim();
                }
            }

            if (StringUtils.isEmpty(randomVINNumber) && retry > 0) {
                return getRandomVinNumberForState(retry - 1, stateCode);
            }
        } catch (Exception e) {
            Log.warn("Could not reach randomvin.com (" + e.getMessage() + "). Falling back to hardcoded VINs.");
        }

        List<String> vins;
        if (CA.equals(stateCode)) {
            vins = new ArrayList<>(FALLBACK_VINS_CA);
        } else if (!StringUtils.isEmpty(randomVINNumber)) {
            vins = new ArrayList<>(List.of(randomVINNumber));
        } else {
            Log.info("randomvin.com unreachable – using hardcoded fallback VINs.");
            vins = new ArrayList<>(FALLBACK_VINS);
        }

        Collections.shuffle(vins);
        return vins.get(0);
    }

    private String resolveVinStateCodeFromActiveApplication() throws Exception {
        Page activePage = page();
        if (activePage.isClosed()) {
            throw new IllegalStateException("Cannot resolve a VIN state because the active Playwright page is closed.");
        }

        String currentUrl = StringUtils.trimToEmpty(activePage.url()).toLowerCase(Locale.ROOT);
        if (!currentUrl.startsWith("http://") && !currentUrl.startsWith("https://")) {
            throw new IllegalStateException(
                    "Cannot read FFQ sessionStorage before navigation to an HTTP(S) application origin. Current URL: "
                            + (currentUrl.isEmpty() ? "<empty>" : currentUrl));
        }

        AppStore appStore = getSessionStorageAppStore();
        if (appStore == null || appStore.getData() == null
                || StringUtils.isBlank(appStore.getData().getLandingStateCode())) {
            throw new IllegalStateException("FFQ sessionStorage does not contain a landing state code for VIN selection.");
        }
        return appStore.getData().getLandingStateCode();
    }

    public void validateValidateAndFooterForBDQ(FarmersSoftAssert fsa, AutoApplicant applicant, BasePage page) throws Exception {
        fsa.assertTrue(isOnBristolWest() && !isOnFarmers(), "User should be on the BW logo, not");
        String phoneNumber = getBdqPhoneNumber(applicant);
        new HeaderAndFooter().validateBdqFooterAndHeader(fsa, phoneNumber, page);
    }

    private String getBdqPhoneNumber(AutoApplicant applicant) throws Exception {
        String phoneNumber = null;
        if (applicant.getTestScenario().contains(BW_ORGANIC_FLOW)) {
            phoneNumber = "8662284622";
        } else if (applicant.getTestScenario().contains(BW_CLICK_TO_BUY_LITE_FLOW)) {
            phoneNumber = "9999999999";
        } else if (applicant.getTestScenario().contains(BW_CLICK_TO_BUY_FULL_FLOW)) {
            AutoDataProviders autoDataProviders = new AutoDataProviders();
            List<BDQFlowData> bdqData = autoDataProviders.getBdqData();
            BDQFlowData bdqFlowData = bdqData.stream().filter(each -> each.getStateAbb().equals(applicant.getStateCode())).collect(Collectors.toList()).get(0);
            phoneNumber = getTheParameterFromUrl(bdqFlowData.getBdqFullUrl(), "DsplayPhn");
        } else if (applicant.getTestScenario().contains(BW_MARKETING_ID_FLOW)) {
            phoneNumber = "8662284622";
        } else {
            Log.error("Given test scenario does not have phone number");
        }
        return phoneNumber;
    }

    public void validateAgentSectionBDQ(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        if (!Arrays.asList(BW_CLICK_TO_BUY_LITE_FLOW, BW_CLICK_TO_BUY_FULL_FLOW).stream().anyMatch(each -> applicant.getTestScenario().contains(each))) {
            return;
        }
        String agentName;
        if (applicant.getTestScenario().contains(BW_CLICK_TO_BUY_LITE_FLOW)) {
            agentName = "Swat Team";
        } else {
            AutoDataProviders autoDataProviders = new AutoDataProviders();
            List<BDQFlowData> bdqData = autoDataProviders.getBdqData();
            BDQFlowData bdqFlowData = bdqData.stream().filter(each -> each.getStateAbb().equals(applicant.getStateCode())).collect(Collectors.toList()).get(0);
            String bdqFullUrl = bdqFlowData.getBdqFullUrl();
            agentName = getTheParameterFromUrl(bdqFullUrl, "Agent_Name");
        }
        fsa.assertEquals(getTextFromElement(agentPhoneNumber).replaceAll("\\D", EMPTY_STRING), getBdqPhoneNumber(applicant), "Agent phone number is matching");
        fsa.assertEquals(getTextFromElement(agentSectionAgentName).toLowerCase(), agentName.toLowerCase(), "Agent name is matching");
    }

    protected String getTheParameterFromUrl(String queryUrl, String queryKey) throws MalformedURLException, UnsupportedEncodingException {
        URL url = new URL(queryUrl);
        String query = url.getQuery();
        Map<String, String> params = new LinkedHashMap<>();
        for (String param : query.split("&")) {
            String[] pair = param.split("=");
            String key = URLDecoder.decode(pair[0], "UTF-8");
            String value = pair.length > 1 ? URLDecoder.decode(pair[1], "UTF-8") : "";
            params.put(key, value);
        }
        return params.get(queryKey);
    }

    protected boolean isDiscountSideSheetOpen() {
        return isElementVisible(discountsSidesheetTitle, 1);
    }

    //F90334 - Review all the FFQ Auto pages and ensure 006BC2 color is used for all the links
    public void validateColorOfTheLinks() throws Exception {
        String expectedColor = "rgba(0, 107, 194, 1)"; // Equivalent of #006BC2 in RGBA
        List<Locator> links = locators(pwTag("//a"));
        for (Locator link : links) {
            String actualColor = String.valueOf(link.evaluate("(e,p)=>getComputedStyle(e).getPropertyValue(p)", "color"));
            Assert.assertEquals(actualColor, expectedColor, "Color is not matching for " + getTextFromElement(link));
        }
    }

    /**
     * @param stateCode
     * @return
     */
    public boolean isVehiclesDriversConsolidationImpl(String stateCode) throws Exception {
        return List.of(AR, AZ, CO, ID, IL, IN, MI, MN, MO, NJ, NM, OH, OK, OR, TN, VA, WA).contains(stateCode);
    }

    public boolean isPartnerFlow() throws Exception {
        String sourceIndicator = getSessionStorageAppStore().getUrlParameterObject().getSourceIndicator();
        return List.of("ME", "BDQI").contains(sourceIndicator);
    }

    protected SqlAdditionalDriver getRandomAdditionalDriver() {
        Faker faker = new Faker();
        SqlAdditionalDriver driver = new SqlAdditionalDriver();
        driver.setFirstName(faker.name().firstName());
        driver.setLastName(faker.name().lastName());
        driver.setGender(RandomUtils.nextBoolean() ? "Male" : "Female");
        driver.setLicenseToDriveInUSA(YES);
        driver.setDateOfBirth("1209" + LocalDate.now().minusYears(25).getYear());
        driver.setCompletedDriversSafetyCourse(false);
        driver.setFinancialFiling(NO);
        driver.setRelationshipToApplicant(SON);
        return driver;
    }

    public boolean isDefensiveDriverDiscountEnabledFarmersStreamlineState(String stateCode) {
        return Arrays.asList(OK).contains(stateCode);
    }
    public boolean isDefensiveDriverDiscountEnabledBW(String stateCode) {
        return Arrays.asList(OK, AR, AL, GA, KS, KY, ND, NJ).contains(stateCode);
    }
    public boolean isNoMatureOrDefensiveDriverSnackbarAndDiscount(String stateCode) {
        return Arrays.asList(SD, WI, WY).contains(stateCode);
    }
    public void validateMatureDriverDiscountPresenceBW(FarmersSoftAssert fsa, AutoApplicant applicant){
        String expectedDiscountName = isDefensiveDriverDiscountEnabledBW(applicant.getStateCode()) ? "Defensive Driver" : "Mature Driver";
        fsa.assertTrue(isDiscountPresentInTheSideSheet(expectedDiscountName), expectedDiscountName + " discount is not displayed after brightline");
    }
    public void validateMatureOrDefensiveDriverDiscountAddedSnackBar(FarmersSoftAssert fsa, boolean isDefensiveDriverDiscountEnabled) throws Exception {
        String expectedSnackBarMessage = isDefensiveDriverDiscountEnabled ? DEFENSIVE_DRIVER_ADDED_DISCOUNT_MSG : MATURE_DRIVER_ADDED_DISCOUNT_MSG;
        fsa.assertTrue(isSnackBarMessageDisplayed(expectedSnackBarMessage), expectedSnackBarMessage + " message validation.");
        wait.until(Conditions.invisible(snackBar));
    }

    public void validateMatureOrDefensiveDriverDiscountRemovedSnackBar(FarmersSoftAssert fsa, boolean isDefensiveDriverDiscountEnabled) throws Exception {
        String expectedSnackBarMessage = isDefensiveDriverDiscountEnabled ? DEFENSIVE_DRIVER_DISCOUNT_REMOVED_MSG : MATURE_DRIVER_DISCOUNT_REMOVED_MSG;
        fsa.assertTrue(isSnackBarMessageDisplayed(expectedSnackBarMessage), expectedSnackBarMessage + " message validation.");
        wait.until(Conditions.invisible(snackBar));
    }
    public void validateMatureOrDefensiveDriverDiscountPresent(FarmersSoftAssert fsa, boolean isDefensiveDriverDiscountEnabledFarmers) throws Exception {
        String discountName = isDefensiveDriverDiscountEnabledFarmers ? DEFENSIVE_DRIVER : MATURE_DRIVER;
        fsa.assertTrue(isDiscountPresentInTheSideSheet(discountName), discountName + " discount validation in the side sheet.");
    }

    public void validateMatureOrDefensiveDriverDiscountNotPresent(FarmersSoftAssert fsa, boolean isDefensiveDriverDiscountEnabledFarmers) throws Exception {
        String discountName = isDefensiveDriverDiscountEnabledFarmers ? DEFENSIVE_DRIVER : MATURE_DRIVER;
        fsa.assertFalse(isDiscountPresentInTheSideSheet(discountName), discountName + " discount not present in the discount side sheet.");
    }

    public void validateDriverImprovementDiscountAddedSnackBar(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(snackBar), DRIVER_IMPROVEMENT_DISCOUNT_ADDED_MSG, DRIVER_IMPROVEMENT_DISCOUNT_ADDED_MSG + " message validation.");
        wait.until(Conditions.invisible(snackBar));
    }

    public void validateDriverImprovementDiscountRemovedSnackBar(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(snackBar), DRIVER_IMPROVEMENT_DISCOUNT_REMOVED_MSG, DRIVER_IMPROVEMENT_DISCOUNT_REMOVED_MSG + " message validation.");
        wait.until(Conditions.invisible(snackBar));
    }

    public void validateDriverImprovementDiscountPresent(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(isDiscountPresentInTheSideSheet(DRIVER_IMPROVEMENT), DRIVER_IMPROVEMENT + " discount validation in the side sheet.");
    }
    public void validateDriverImprovementDiscountNotPresent(FarmersSoftAssert fsa) throws Exception {
        fsa.assertFalse(isDiscountPresentInTheSideSheet(DRIVER_IMPROVEMENT), DRIVER_IMPROVEMENT + " discount not present in the discount side sheet.");
    }
}
