package com.farmers.ffq.auto.pages.bindpages;







import com.farmers.framework.playwright.Keys;
import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Auto.Driver;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.utils.FarmersSoftAssert;

import net.datafaker.Faker;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AdditionalInfoSignalEnrollmentSectionOneUI extends AutoBasePage {

    private static final String SIGNAL_ENROLLMENT_HEADER = "Signal\u00ae enrollment";

        private Locator signalEnrollmentHeader = locator(pwXPath("//div[contains(@class,'additional-info-signal-enrollment')]//h2"));

        private Locator signalDiscountAllEligibleDrivers = locator(pwXPath("//p[contains(@class, 'tui-body-text-1 ng-star-inserted')]"));

    private static final String DOWNLOAD_THE_SIGNAL_APP_TEXT = "Then you'll just download the Signal app and it will monitor your driving behaviors. You'll be rewarded even more when you drive safely.";
        private Locator downloadTheSignalApp = locator(pwId("signalText2"));

        private Locator signalEnrollmentCheckbox = locator(pwXPath("//mat-checkbox[@formcontrolname='signalAgreement']"));

    private static final String BY_CLICKING_CONTINUE_TO_PAYMENT = "String clicking \"Continue\" below, I confirm that I:";
        private Locator byClickingContinueToPaymentText = locator(pwXPath("//span[contains(text(), 'I confirm that I:')]"));

    private static final String SIGNAL_ENROLLMENT_CONSENT_POINT1 = "Consent to share the mobile phone number(s) I have provided with Farmers or its vendor(s) to facilitate participation in Signal.";
        private Locator signalEnrollmentConsentPoint1 = locator(pwXPath("//li[contains(text(), '" + SIGNAL_ENROLLMENT_CONSENT_POINT1 + "')]"));

    private static final String SIGNAL_ENROLLMENT_CONSENT_POINT2 = " Understand that a text message will be sent about downloading the Signal app.";
        private Locator signalEnrollmentConsentPoint2 = locator(pwXPath("//li[contains(text(), '" + SIGNAL_ENROLLMENT_CONSENT_POINT2 + "')]"));

    private static final String SIGNAL_ENROLLMENT_CONSENT_POINT3 = " Agree to receive further text messages associated with Signal and that standard SMS rates apply.";
        private Locator signalEnrollmentConsentPoint3 = locator(pwXPath("//li[contains(text(), '" + SIGNAL_ENROLLMENT_CONSENT_POINT3 + "')]"));

    private static final String SIGNAL_ENROLLMENT_CONSENT_POINT4 = "Have read and agree to Signal";
        private Locator signalEnrollmentConsentPoint4 = locator(pwXPath("//li[contains(text(), '" + SIGNAL_ENROLLMENT_CONSENT_POINT4  + "')]"));

    private static final String READ_AGREEMENT_SELECT_CHECKBOX_ERROR = "Please read the agreement and select the checkbox.";
        private Locator readAgreementAndSelectCheckboxError = locator(pwXPath("//mat-error[contains(text(), '" +READ_AGREEMENT_SELECT_CHECKBOX_ERROR + "')]"));

        private Locator termsOfUseAnchorTagElement = locator(pwXPath("//a[contains(text(), 'Terms of use')]"));

    private static final String CHANGE_YOUR_MIND_QUESTION = "Change your mind?";
        protected Locator changeYourMindQuestion = locator(pwXPath("//span[contains(text(),'"+CHANGE_YOUR_MIND_QUESTION+"')]"));
    private static final String CANCEL_SIGNAL_ENROLLMENT = "Cancel your Signal enrollment";
        protected Locator cancelSignalEnrollmentLink = locator(pwXPath("//a[contains(text(),'"+CANCEL_SIGNAL_ENROLLMENT+"')]"));

    private static final String CANCEL_SIGNAL_ENROLLMENT_QUESTION = "Cancel Signal enrollment?";
        protected Locator cancelSignalEnrollmentQuestion = locator(pwXPath("//mat-dialog-container//span"));

        protected Locator signalCancelDialogContentDescripton = locator(pwXPath("//mat-dialog-content//p"));

    private static final String CANCEL_ENROLLMENT_BUTTON = "Yes, cancel enrollment";
        protected Locator cancelEnrollmentButton = locator(pwXPath("//button[contains(text(),'"+CANCEL_ENROLLMENT_BUTTON+"')]"));

    private static final String KEEP_SIGNAL_LINK = "No, I want to keep Signal";
        protected Locator keepSignalLink = locator(pwXPath("//a[contains(text(),'"+KEEP_SIGNAL_LINK+"')]"));

        protected Locator cancelSignalModalPopUp = locator(pwXPath("mat-dialog-container[@aria-labelledby=\"addEditSignal\"]"));
    private static final String TERMS_OF_USE_PAGE_TITLE = "Terms of Use | Farmers Insurance";

    private static final String PHONE_NUMBER_TEXT_FIELD_XPATH = "//input[@formcontrolname='phoneNumber']";
        private Locator mobileNumberInputBoxElements = locator(pwXPath(PHONE_NUMBER_TEXT_FIELD_XPATH));

        private Locator emptyMobileNumberInputBoxElements = locator(pwXPath("//input[@formcontrolname='phoneNumber' and contains(@class,'ng-invalid')]"));


        private Locator listOfMissingMobileNumberInputBoxElements = locator(pwXPath(PHONE_NUMBER_TEXT_FIELD_XPATH + "[not(following-sibling::*)]"));

        private Locator emailInputBoxElements = locator(pwXPath("//input[@formcontrolname='emailAddress']"));

    private static final String MOBILE_NUMBER_PLACEHOLDER_TEXT = "Mobile number for Signal";
        private Locator mobileNumberPlaceHolderText = locator(pwXPath("//mat-label[contains(text(),'" + MOBILE_NUMBER_PLACEHOLDER_TEXT + "')]"));

    private static final String EMAIL_ADDRESS_PLACEHOLDER_TEXT = "Email address";
        private Locator emailPlaceHolderText = locator(pwXPath("//mat-label[contains(text(),'" + EMAIL_ADDRESS_PLACEHOLDER_TEXT + "')]"));

        private Locator greenCheckMarkMobileNumberInputTextBox = locator(pwXPath("//mat-icon[contains(text(), 'done')]"));

    private static final String PLEASE_ENTER_YOUR_PHONE_NUMBER = "Please enter your phone number.";
        private Locator pleaseEnterYourPhoneNumberError = locator(pwXPath("//mat-error[contains(text(),'" + PLEASE_ENTER_YOUR_PHONE_NUMBER + "')]"));

    private static final String PLEASE_ENTER_VALID_PHONE_NUMBER = "Please enter a valid phone number.";
        private Locator pleaseEnterValidPhoneNumberError = locator(pwXPath("//mat-error[contains(text(),'" + PLEASE_ENTER_VALID_PHONE_NUMBER + "')]"));

    private static final String PHONE_NUMBER_SHOULD_BE_DISTINCT = "The phone number should be distinct from the other drivers.";
        private Locator phoneNumberShouldBeDistinct = locator(pwXPath("//mat-error[contains(text(),'" + PHONE_NUMBER_SHOULD_BE_DISTINCT +  "')]"));

    private static final String OPTIONAL_HINT_TEXT = "Optional";
        private Locator optionEmailIDHitLocators = locator(pwXPath("//mat-hint[contains(text(),'" + OPTIONAL_HINT_TEXT + "')]"));


    private static final String INVALID_EMAIL_ID_ERROR = "Email ID entered is invalid.";
        private Locator invalidEmailIdError = locator(pwXPath("//mat-error[contains(text(),'" + INVALID_EMAIL_ID_ERROR + "')]"));

    private static final String DISTINCT_EMAIL_ID_ERROR = "The Email address should be distinct from the other drivers.";
        private Locator distinctEmailIdError = locator(pwXPath("//mat-error[contains(text(),'" + DISTINCT_EMAIL_ID_ERROR + "')]"));

    private static final String ENROLL_THIS_DRIVER   = "Enroll this driver";
        private Locator enrollThisDriverText = locator(pwXPath("//span[contains(text(),'" + ENROLL_THIS_DRIVER + "')]"));

        private Locator enrollThisDriverSlider = locator(pwXPath("//mat-slide-toggle[@formcontrolname='signalAddRemoveOption']//span[contains(@class, 'mat-slide-toggle-bar')]"));

        private Locator enrollThisDriverSliderInputTags = locator(pwXPath("//mat-slide-toggle[@formcontrolname='signalAddRemoveOption']//span[contains(@class, 'mat-slide-toggle-bar')]/input"));
    private static final String YOUTHFUL_DRIVER_DISCOUNT = "Enroll this driver for the youthful driver component of the Signal factor";
        private Locator youthfulDriverDiscountMessage = locator(pwXPath("//div[contains(text(),'" +  YOUTHFUL_DRIVER_DISCOUNT + "')]"));

        private Locator continueToPaymentButton = locator(pwXPath("//button[contains(text(), 'Continue')]"));

        private Locator safeDrivingLeadsToBiggerRewardsAtRenewalText = locatorAny(pwId("signalText1"), pwId("signalTextLatest"));

        private Locator fillOutInfoTextElement = locator(pwXPath("//*[@id='signalText2']"));


    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public AdditionalInfoSignalEnrollmentSectionOneUI() throws Exception {
    }


    public void verifySignalEnrollmentSection(AppStore retrieveQuoteResponseSessionStorage, boolean enterValuesOnly, FarmersSoftAssert fsa) throws Exception {
        removeQualtricsPopUp();
        if (isOnBristolWest()) {
            fsa.assertTrue(!isElementVisible(signalEnrollmentCheckbox,1), "Signal section not displayed for BW flow");
        }
        boolean isSignalEnrollmentSectionAvailable = retrieveQuoteResponseSessionStorage.getAuto().getDrivers().get(0).getSignalEnrolled().equals("N");
        String landingStateCode = retrieveQuoteResponseSessionStorage.getData().getLandingStateCode();
        List<Driver> listOfDriverWithReferenceNumber = retrieveQuoteResponseSessionStorage.getAuto().getDrivers().stream().filter(i -> i.getReference() != null).collect(Collectors.toList());
        if (!isSignalEnrollmentSectionAvailable){
            waitElementBeVisibleClickable(continueToPaymentButton);
            if (enterValuesOnly) {
                validateDriversNameAndMobileNumberInputBox(listOfDriverWithReferenceNumber, fsa);
                waitElementBeVisibleClickable(signalEnrollmentCheckbox);
                waitAndClickElement(signalEnrollmentCheckbox);
            } else {
                validateSignalEnrollmentLabelsAndTexts(landingStateCode, fsa);
                validateSignalEnrollmentCheckBox(fsa);
                validateOpeningTermsOfUseInNewTab(fsa);
                validateDriversNameAndMobileNumberInputBox(listOfDriverWithReferenceNumber, fsa);
                validateCancelSignalEnrollmentModal(landingStateCode, fsa);
            }
        }
    }

    public void fillOutSignalEnrollmentSection() throws Exception {
        removeQualtricsPopUp();
        if (isOnBristolWest()) {
            testStepAssert(!isElementVisible(signalEnrollmentCheckbox, 1), "Signal section should not be visible for BW quotes");
            testStepAssert(!isElementVisible(signalEnrollmentHeader, 1), "Signal section header should not be visible for BW quotes");
        }
        if (isElementVisible(signalEnrollmentHeader, 3)) {
            enterSignalPhoneNumbersForAdditionalDrivers();
            scrollElementToMiddle(signalEnrollmentCheckbox);
            clickElement(signalEnrollmentCheckbox);
            waitForUiSettled();
            if (!getAttributeData(signalEnrollmentCheckbox, CLASS).contains(CHECKBOX_CHECKED)) {
                waitAndClickElement(signalEnrollmentCheckbox);
            }
        }
    }

    public void enterSignalPhoneNumbersForAdditionalDrivers() throws Exception {
        List<Locator> phoneNumberInputElements = locators(pwXPath(String.format("//input[@formcontrolname='phoneNumber' and contains(@class,'invalid')]")));
    	int numberOfElements = phoneNumberInputElements.size();
        for (int i =0; i< numberOfElements; i++){
            sendKeysOneByOne(phoneNumberInputElements.get(i), new Faker().phoneNumber().phoneNumber());
        }

    }
    public void validateSignalEnrollmentLabelsAndTexts(String stateCode, FarmersSoftAssert fsa) throws Exception {
        wait.until(Conditions.visible(signalEnrollmentHeader));
        fsa.assertEquals(getTextFromElement(signalEnrollmentHeader), SIGNAL_ENROLLMENT_HEADER, "Signal Enrollment Header verification");

        List<String> listOfPossibleSignalDisclaimer1 = Arrays.asList("Safer driving leads to bigger rewards at renewal.", "Fill out the info below to get up to 5% initial discount by enrolling drivers in Signal.", "Fill out the info below for all eligible drivers to maximize your initial Signal discount when enrolling in Signal today!", "Fill out the info below to get your 10% discount by enrolling in Signal!", "Fill out the info below to get up to 10% initial discount by enrolling drivers in Signal.");

        List<String> listOfPossibleSignalDisclaimer2 = Arrays.asList(DOWNLOAD_THE_SIGNAL_APP_TEXT, "Fill out the info below to get a discount by enrolling drivers in Signal. Enrolling more drivers can help increase your discount. We'll send a text to download the Signal app later.");

        fsa.assertTrue(listOfPossibleSignalDisclaimer1.contains(getTextFromElement(signalDiscountAllEligibleDrivers)), "Signal first disclaimer validated");
        fsa.assertTrue(listOfPossibleSignalDisclaimer2.contains(getTextFromElement(downloadTheSignalApp)), "Download The Signal App Text verification");
        fsa.assertEquals(getTextFromElement(byClickingContinueToPaymentText), BY_CLICKING_CONTINUE_TO_PAYMENT, "String Clicking Continue To Payment Header verification");
        fsa.assertTrue(signalEnrollmentConsentPoint1.isVisible(), "Signal Enrollment Consent Point 1 Is Available");
        fsa.assertTrue(signalEnrollmentConsentPoint2.isVisible(), "Signal Enrollment Consent Point 2 Is Available");
        fsa.assertTrue(signalEnrollmentConsentPoint3.isVisible(), "Signal Enrollment Consent Point 3 Is Available");
        fsa.assertTrue(signalEnrollmentConsentPoint4.isVisible(), "Signal Enrollment Consent Point 4 Is Available");
        fsa.assertEquals(getTextFromElement(changeYourMindQuestion), CHANGE_YOUR_MIND_QUESTION.trim(), "Change Your Mind Question verification");
        fsa.assertEquals(getTextFromElement(cancelSignalEnrollmentLink), CANCEL_SIGNAL_ENROLLMENT, "Cancel Signal Enrollment Link Text verification");
    }


    public void validateSignalEnrollmentCheckBox(FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(signalEnrollmentCheckbox.isVisible(),"Signal Enrollment Checkbox Available");

        // check uncheck checkbox and validate read agreement error
        waitElementBeVisibleClickable(signalEnrollmentCheckbox);

        //check the checkbox
        waitForUiSettled();
        scrollElementToMiddle(signalEnrollmentCheckbox);
        waitAndClickElement(signalEnrollmentCheckbox);
        // uncheck the checkbox
        waitAndClickElement(signalEnrollmentCheckbox);
        clickContinueButton();
        wait.until(Conditions.attributeContains(signalEnrollmentCheckbox, CLASS, CHECKBOX_CHECKED));        fsa.assertEquals(getTextFromElement(waitElementBeVisible(readAgreementAndSelectCheckboxError)), READ_AGREEMENT_SELECT_CHECKBOX_ERROR.trim(),"Read Agreement And Select Checkbox Error Text Available");
        waitAndClickElement(signalEnrollmentCheckbox);
    }

    public void validateOpeningTermsOfUseInNewTab(FarmersSoftAssert fsa) throws Exception {
        Page currentPageHandle = currentPage();
        scrollAndClickOnElement(termsOfUseAnchorTagElement);
        ArrayList<Page> tabHandles = new ArrayList<>(pages());
        boolean termsOfUseTabFound = false;
        for (Page eachHandle : tabHandles)
        {
            switchToPage(eachHandle);
            // Check Your Page Title
            if(page().title().equalsIgnoreCase(TERMS_OF_USE_PAGE_TITLE))
            {
                closeCurrentPage(); // Note driver.quit() will close all tabs
                switchToPage(currentPageHandle);
                termsOfUseTabFound = true;
            }
        }
        fsa.assertTrue(termsOfUseTabFound, "Terms Of Use Link Click Did Not Open New Tab");
    }

    public void validateDriversNameAndMobileNumberInputBox(List<Driver> listOfDrivers, FarmersSoftAssert fsa) throws Exception {
        // check if the youthful driver message is displayed if age is less than 25
        List<Driver> listOfDriversWithAgeLessThan25 = listOfDrivers.stream().filter(i -> i.getAge() < 25).collect(Collectors.toList());
        if(!listOfDriversWithAgeLessThan25.isEmpty()) {
            fsa.assertEquals(listOfDriversWithAgeLessThan25.size(), youthfulDriverDiscountMessage.count(), "Youthful driver discount text messages matching");
        }

        String prePopulatedMobileNumber = getAttributeData(mobileNumberInputBoxElements.nth(0), VALUE);
    	int numberOfElements = listOfDrivers.size();
        for (int i =0; i < numberOfElements; i++){
        	String driverFullName = getTheFullNameWithFirstLetterInCaps(listOfDrivers.get(i).getFirstName() + SPACE + listOfDrivers.get(i).getLastName());
            String driverFullNameXpath = "//div[contains(text(),'" + driverFullName + "')]";
            Locator driverElement = locator(pwXPath(driverFullNameXpath));

            //Validate number of mobile input box in signal section
            fsa.assertEquals(mobileNumberInputBoxElements.count(), numberOfElements, "Number Of Mobile Input Box");
            fsa.assertTrue(driverElement.isVisible(), "Driver " + driverFullName +" In Signal Enrollment Section displayed");

            if (listOfDrivers.get(i).getSignalEnrolled() != null && listOfDrivers.get(i).getSignalEnrolled().equals("Y")){
                fsa.assertEquals(getTextFromElement(mobileNumberPlaceHolderText.nth(i)), MOBILE_NUMBER_PLACEHOLDER_TEXT, "Mobile Number Placeholder Text verification");
                validateMobileNumberInputBoxForPrimaryDriver(mobileNumberInputBoxElements.nth(i), prePopulatedMobileNumber, listOfDrivers.get(i).getPhoneNumber().trim(), fsa);
            } else {
                validateSignalSliderForOtherDrivers(enrollThisDriverSlider.nth(i-1), enrollThisDriverText.nth(i-1), enrollThisDriverSliderInputTags.nth(i-1), i, fsa);
                fsa.assertEquals(getTextFromElement(mobileNumberPlaceHolderText.nth(i)), MOBILE_NUMBER_PLACEHOLDER_TEXT, "Mobile Number Placeholder Text verification");
                validateMobileNumberInputBoxForOtherDrivers(mobileNumberInputBoxElements.nth(i), prePopulatedMobileNumber, i, fsa);
                // removing email id validation as it is removed for other drivers - US1063117
                //validateEmailInputBoxForOtherDrivers(emailPlaceHolderText.nth(i-1), emailInputBoxElements.nth(i-1), optionEmailIDHitLocators.nth(i-1), i-1, fsa);
            }
        }
    }

    public void validateMobileNumberInputBoxForOtherDrivers(Locator mobileNumberInputBoxElement, String prePopulatedMobileNumber, int index, FarmersSoftAssert fsa){
        // Error validation when phone number is empty
        scrollElementToMiddle(waitElementBeVisible(mobileNumberInputBoxElement));
        sendKeysOneByOne(mobileNumberInputBoxElement, Keys.chord(Keys.TAB));
        fsa.assertEquals(getTextFromElement(pleaseEnterYourPhoneNumberError), PLEASE_ENTER_YOUR_PHONE_NUMBER.trim(), "Please Enter Your Phone Number Error Available");

        // Distinct phone number validation error
        sendKeysOneByOne(mobileNumberInputBoxElement, Keys.chord(prePopulatedMobileNumber, Keys.TAB));
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(phoneNumberShouldBeDistinct)), PHONE_NUMBER_SHOULD_BE_DISTINCT.trim(), "Phone Number Should Be Distinct Error Available");

        // valid phone number error validation
        mobileNumberInputBoxElement.click();
        sendKeysOneByOne(mobileNumberInputBoxElement, Keys.chord(Keys.BACK_SPACE));
        fsa.assertEquals(getTextFromElement(pleaseEnterValidPhoneNumberError), PLEASE_ENTER_VALID_PHONE_NUMBER, "Please Enter Valid Phone Number Error Available");

        // enter valid phone number
        sendKeysOneByOne(mobileNumberInputBoxElement, new Faker().phoneNumber().phoneNumber());
    }

    public void validateMobileNumberInputBoxForPrimaryDriver(Locator mobileNumberInputBoxElement, String prePopulatedMobileNumber, String phoneNumberFromApiCall, FarmersSoftAssert fsa){
        fsa.assertEquals(removeDashAndSpaceFromString(prePopulatedMobileNumber), removeDashAndSpaceFromString(phoneNumberFromApiCall), "Pre Populated Phone Number verification");

        // enter valid phone number error
        // waitAndClickElement(mobileNumberInputBoxElement).sendKeys(Keys.BACK_SPACE, Keys.TAB);
        clearOutSignalEnrollmentField(mobileNumberInputBoxElement);
        sendKeysOneByOne(mobileNumberInputBoxElement,"0000000000");
        sendKeys(waitAndClickElement(mobileNumberInputBoxElement), Keys.TAB);

        waitElementBeVisible(pleaseEnterValidPhoneNumberError);
        fsa.assertEquals(getTextFromElement(pleaseEnterValidPhoneNumberError), PLEASE_ENTER_VALID_PHONE_NUMBER, "Please Enter Valid Phone Number Error Available");

        // validate error when phone number input box is empty
        clearOutSignalEnrollmentField(mobileNumberInputBoxElement);

        waitElementBeVisible(pleaseEnterYourPhoneNumberError);
        fsa.assertEquals(getTextFromElement(pleaseEnterYourPhoneNumberError), PLEASE_ENTER_YOUR_PHONE_NUMBER, "Please Enter Your Phone Number Error Available");

        // enter valid phone number
        sendKeysOneByOne(mobileNumberInputBoxElement, prePopulatedMobileNumber);
    }


    public void validateEmailInputBoxForOtherDrivers(Locator emailPlaceHolderText, Locator emailInputBoxElement, Locator optionEmailIDHitLocator, int index, FarmersSoftAssert fsa){
        String inValidEmailId = "bidnoneuigmail.com";

        // validate optional hint text
        fsa.assertEquals(getTextFromElement(emailPlaceHolderText), EMAIL_ADDRESS_PLACEHOLDER_TEXT, "Email Placeholder Text verification");
        fsa.assertEquals(getTextFromElement(optionEmailIDHitLocator), OPTIONAL_HINT_TEXT, "Optional Email Id Hint Text verification");

        // validate invalid email id error
        sendKeysOneByOne(emailInputBoxElement, Keys.chord(inValidEmailId, Keys.TAB));
        fsa.assertEquals(getTextFromElement(invalidEmailIdError), INVALID_EMAIL_ID_ERROR, "Invalid Email Id Error Visible");

        emailInputBoxElement.fill("");

        // validate duplicate email id error
        if(index != 0){
            String emailIdFromFirstOtherDriver = getAttributeData(emailInputBoxElements.nth(0), VALUE);
            sendKeysOneByOne(emailInputBoxElement, Keys.chord(emailIdFromFirstOtherDriver, Keys.TAB));
            fsa.assertEquals(getTextFromElement(distinctEmailIdError), DISTINCT_EMAIL_ID_ERROR, "Distinct EmailId Error Visible");
        }

        emailInputBoxElement.fill("");

        // enter valid email id error
        sendKeysOneByOne(emailInputBoxElement, Keys.chord(generateEmailAddress("farminsqa.testinator.com"), Keys.TAB));
        sendKeysToElement(emailInputBoxElement, Keys.TAB);
    }

    public void validateSignalSliderForOtherDrivers(Locator enrollThisDriverSlider, Locator enrollThisDriverText, Locator enrollThisDriverSliderInputTag, int index, FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(getTextFromElement(enrollThisDriverText).equals(ENROLL_THIS_DRIVER));

        // check if slider is turned on initially
        fsa.assertTrue(isButtonSelected(enrollThisDriverSliderInputTag), "Signal slider is turned on by default");

        // turn off the signal slider
        clickOnHiddenElement(waitElementBeVisible(enrollThisDriverSlider));
        fsa.assertTrue(isButtonNotSelected(enrollThisDriverSliderInputTag), "Turn Signal slider off");

        //turn on the signal slider
        clickOnHiddenElement(waitElementBeVisible(enrollThisDriverSlider));
        fsa.assertTrue(isButtonSelected(enrollThisDriverSliderInputTag), "Turn signal slider on");

        fsa.assertTrue(emailInputBoxElements.nth(index-1).isVisible(), "Email input block for " + index + " displayed");
        fsa.assertTrue(mobileNumberInputBoxElements.nth(index).isVisible(), "mobile input block for " + index + " displayed");
    }

    public void validateCancelSignalEnrollmentModal(String stateCode, FarmersSoftAssert fsa){
        scrollElementToMiddle(cancelSignalEnrollmentLink);
        waitAndClickElement(cancelSignalEnrollmentLink);
        String expectedSignalCancelPopUpContent = "String cancelling your enrollment in the Signal program, you will no longer be eligible for this initial Signal discount. Your quote will need to be recalculated.";
        if(Arrays.asList(AZ, GA, IL, IN, KS, KY, LA, MA, MN, MS, NC, OH, OK, TN, TX, MD, WA, WY).contains(stateCode)) {
            expectedSignalCancelPopUpContent = "String cancelling your enrollment in the Signal program, you will no longer be eligible for this initial Signal discount. Your quote will need to be recalculated.";
        } else if(Arrays.asList(AR, CO, ID, MI, MO, ND, NE, NM, PA, SD, UT, WI).contains(stateCode)) {
            expectedSignalCancelPopUpContent = "String cancelling your enrollment in the Signal program, you will no longer be eligible for the initial Signal discount. Your quote will need to be recalculated.";
        } else if(Arrays.asList(AL, CT, NV, VA).contains(stateCode)) {
            expectedSignalCancelPopUpContent = "String cancelling your enrollment in Signal, you will no longer be eligible for the 10% discount. Your quote will need to be recalculated.";
        } else if(Arrays.asList(MI).contains(stateCode)) {
            expectedSignalCancelPopUpContent = "String cancelling your enrollment in the Signal program, you will no longer be eligible for the initial Signal discount. Your quote will need to be recalculated";
        }

        fsa.assertEquals(getTextFromElement(waitElementBeVisible(cancelSignalEnrollmentQuestion)), CANCEL_SIGNAL_ENROLLMENT_QUESTION, "Signal cancel enrollment pop up header validated");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(signalCancelDialogContentDescripton)), expectedSignalCancelPopUpContent, "Signal cancel enrollment pop up content validated");
        fsa.assertEquals(getTextFromElement(cancelEnrollmentButton), CANCEL_ENROLLMENT_BUTTON, "Cancel Enrollment Button Text Matching");
        fsa.assertEquals(getTextFromElement(keepSignalLink), KEEP_SIGNAL_LINK, "Keep Signal Link Text Is Not Matching");

        waitAndClickElement(keepSignalLink);
        fsa.assertTrue(continueToPaymentButton.isEnabled(),"Cancel Signal Modal Pop Up Is Still Open");

        waitAndClickElement(cancelSignalEnrollmentLink);
        waitAndClickElement(cancelEnrollmentButton);
        fsa.assertTrue(continueToPaymentButton.isEnabled(),"Signal Enrollment Header Is Displayed");
    }

    public String removeDashAndSpaceFromString(String phoneNumber){
        String phoneNumberWithoutSpaceAndDash = phoneNumber.replaceAll("\\s", "").replace("-", "");
        return phoneNumberWithoutSpaceAndDash.trim();
    }

    public void addDefaultPhoneNumbersToMissingSignalUsers() {
        waitForSpinnerToBeGone();
        if (isElementVisible(signalEnrollmentHeader, 5)) {
            for (Locator phoneNumberEntryField : listOfMissingMobileNumberInputBoxElements.all()) {
                enterValueInField("310-555-0101", phoneNumberEntryField, "Entring default phone number value");
            }
        }
    }

    public void enrollAndContinue() {
        scrollAndClickOnElement(signalEnrollmentCheckbox);
        scrollAndClickOnElement(continueToPaymentButton);
        waitForSpinnerToBeGone();
    }

    public void clearOutSignalEnrollmentField(Locator element){
        while (!getAttributeData(element, VALUE).equals(EMPTY_STRING)){
            sendKeysToElement(element, Keys.BACK_SPACE);
        }
    }

    public void validateADA_AdditionalInfoSignalEnrollmentSection() {
        if(!isADATestingEnabled()) return;
        if(!isElementDisplayed(cancelSignalEnrollmentLink, 2)) {
           // byPassing as signal is not available
            return;
        }
        scrollAndClickOnElement(waitElementBeVisible(cancelSignalEnrollmentLink));
        waitElementBeVisible(keepSignalLink);
        performADATesting("AdditionalInfoPage_SignalEnrollmentCancellationPopUp", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(keepSignalLink);
    }

    public void verifySignalEnrollmentSectionForLivingAwaySpouse(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {

        SqlAdditionalDriver spouse = applicant.getAdditionalDrivers().stream().filter(each -> each.getRelationshipToApplicant().equals(SPOUSE)).collect(Collectors.toList()).get(0);
        String spouseFullName = getTheFullNameWithFirstLetterInCaps(spouse.getFirstName() + SPACE + spouse.getLastName());
        fsa.assertFalse(isElementDisplayed(pwXPath(String.format("//div[@class='additional-info-signal-enrollment ng-star-inserted']/div/div[@class='ng-star-inserted' and contains(.,'%s')]", spouseFullName))));
    }

    public void validateSignalMessages(FarmersSoftAssert fsa) throws Exception {
        scrollElementToTop(safeDrivingLeadsToBiggerRewardsAtRenewalText);
        //Validate if the below text displays under the signal enrollment section:
        //Safe driving leads to bigger rewards at renewal.
        //Fill out the info below to get a discount by enrolling drivers in Signal. Enrolling more drivers can help increase your discount. We'll send a text to download the Signal app later."
        fsa.assertEquals(getTextFromElement(safeDrivingLeadsToBiggerRewardsAtRenewalText), "Safe driving leads to bigger reward at renewal.", "Safe driving message text verification");
        fsa.assertEquals(getTextFromElement(fillOutInfoTextElement), "Fill out the info below to get a discount by enrolling drivers in Signal. Enrolling more drivers can help increase your discount. We'll send a text to download the Signal app later.", "Fill out the info message text verification");
    }

    public void validateSignalMessagesForEachDriver(FarmersSoftAssert fsa) throws Exception {
        List<Locator> signalMessagesForEachDriverElement = locators(pwId("pniDriverNote"));
        for (Locator webElement : signalMessagesForEachDriverElement) {
            fsa.assertEquals(getTextFromElement(webElement), "This driver will need to download and use the Signal app to qualify for a discount.", "Signal message for each driver verification");
        }
    }

    public void validateEmailAddressesNotDisplayed(FarmersSoftAssert fsa) throws Exception {
        Locator signalSection = locator(pwXPath("//div[contains(@class,'additional-info-signal-enrollment')]"));
        String signalSectionTexts = getTextFromElement(signalSection);

        fsa.assertFalse(signalSectionTexts.toLowerCase().contains("email address"), "Email address field should not be displayed in signal enrollment section");
        fsa.assertFalse(signalSectionTexts.toLowerCase().contains("email"), "Email field should not be displayed in signal enrollment section");
    }

    public void cancelSignalEnrollmentAndReturnToQuoteReview() throws Exception{
        waitForSpinnerToBeGone();
        scrollAndClickOnElement(cancelSignalEnrollmentLink);
        waitAndClickElement(cancelEnrollmentButton);
        waitForSpinnerToBeGone();
        clickReviewQuoteNavigationBarStepper();
    }

}
