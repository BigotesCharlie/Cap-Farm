package com.farmers.ffq.home.pages;







import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.ApplicantHome;
import com.farmers.ffq.datatransferobjects.ApplicantRetQuote;
import com.farmers.ffq.datatransferobjects.SqlAddress;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.testng.Assert;

import java.util.*;

import static com.farmers.ffq.utils.GlobalVariables.*;
/**
 * Farmers Fast Quote (FFQ) - Property Page - Home.
 *
 * @author Valentins Kukjans
 *
 */

public class PropertyPage extends BasePage {

	private static final int OLDEST_HOME = 1492;
	private static final String COPPER = "Copper";
	private static final String RECONSTRUCTION_COST_SCENARIO = "Reconstruction";
	private static final String CANT_FIND = "Can't find ";
	private static final String NAVIGATION_BAR_ITEM_NO_MATCH_MSG = "Navigation bar item doesn't match ";
	private static final String PLEASE_SELECT = "Please select";
	private static final String ESTIMATED_RECONSTRUCTION_COST_STATIC_TEXT = "Your home's estimated reconstruction cost requires that you speak to an agent directly. "
			+ "For further details, Contact Your Farmers Agent or call 1-800-206-9469.";


		protected Locator homeTypeOfRoof = locator(pwId("AddHome:propRoofType"));

		private Locator numberOfAdultsInHousehold = locator(pwId("AddHome:noOfAdult"));

		public Locator propertyLossesInTheLastFiveYearsDropDown = locator(pwId("AddHome:propLosses"));

		private Locator homeExteriorWallType = locator(pwXPath("//*[@id='AddHome:exteriorWallType']"));

		private Locator phoneNumber = locator(pwXPath("//*[@id='AddHome:phone']"));

		public Locator whenYourHomeWasOriginallyBuilt = locator(pwId("AddHome:propYearBuilt"));

		public Locator squareFootage = locator(pwId("AddHome:propSqrFootage"));

		private Locator numberOfSeparateLivingUnitsDropDown = locator(pwId("AddHome:propUnits"));

		private Locator stuccoOnFrameElement = locator(pwId("SCF"));

		private Locator brickVeneerElement = locator(pwId("BKV"));

		private Locator woodSidingElement = locator(pwId("WSD"));

		private Locator cementFiberSidingElement = locator(pwId("CFS"));

		private Locator nextButtonWall = locator(pwXPath("//*[@id='imagesContent']/button[2]"));

		private Locator vinylSidingElement = locator(pwId("VNL"));

		private Locator stoneVeneerElement = locator(pwId("STV"));

		private Locator clapboardWoodElement = locator(pwId("CLW"));

		private Locator stuccoOnMasonryElement = locator(pwId("SCM"));

		private Locator aluminiumSidingElement = locator(pwId("ALS"));

		private Locator solidBrickElement = locator(pwId("SDB"));

		private Locator woodShakesElement = locator(pwId("WSH"));

		private Locator cementShinglesElement = locator(pwId("CMT"));

		private Locator steelSidingElement = locator(pwId("STS"));

		private Locator solidStoneElement = locator(pwId("SDS"));

		private Locator solidWoodElement = locator(pwId("SDL"));

		private Locator logVeneerSidingElement = locator(pwId("LVS"));

		private Locator clapboardRedwoodElement = locator(pwId("CLR"));

		private Locator adobeElement = locator(pwId("ADB"));

		public Locator dwellingStyleDropDown = locator(pwId("AddHome:propDwellingtype"));

		private Locator propNoOfFullBathsDropDown = locator(pwId("AddHome:propNoOfFullBaths"));

		private Locator propNoOfHalfBathsDropDown = locator(pwId("AddHome:propNoOfHalfBaths"));

		private Locator asphaltShingle = locator(pwId("1"));

		private Locator fiberglassDimensionalAsphalt = locator(pwId("C"));

		private Locator spanishTileClay = locator(pwId("5"));

		private Locator concreteCementFiberTile = locator(pwId("6"));

		private Locator steelTileOrShingle = locator(pwId("3"));

		private Locator rockTarGravel = locator(pwId("8"));

		private Locator woodShingleShake = locator(pwId("2"));

		private Locator sheetMetalPanel = locator(pwId("B"));

		private Locator singlePlyMembraneSystems = locator(pwId("M"));

		private Locator aluminum = locator(pwId("O"));

		private Locator rolledAsphaltFlat = locator(pwId("A"));

		private Locator syntheticShingleOrTile = locator(pwId("4"));

		private Locator slate = locator(pwId("7"));

		private Locator copper = locator(pwId("9"));

		private Locator howOldIsYourRoofDropDown = locator(pwId("AddHome:propAgeOfRoof"));

		public Locator typeOfGarageDropDown = locator(pwId("AddHome:propGarageType"));

		private Locator haveAnyDecksYesRadioButton = locator(pwId("AddHome:propDeck:0"));

		private Locator haveAnyDecksNoRadioButton = locator(pwId("AddHome:propDeck:1"));

		private Locator havePoolYesRadioButton = locator(pwId("AddHome:propPool:0"));

		private Locator havePoolNoRadioButton = locator(pwId("AddHome:propPool:1"));

		private Locator haveBasementYesRadioButton = locator(pwId("AddHome:propBasement:0"));

		private Locator haveBasementNoRadioButton = locator(pwId("AddHome:propBasement:1"));

		private Locator hasPlumbingSystemYesRadioButton = locator(pwId("AddHome:homePlumb:0"));

		private Locator hasPlumbingSystemNoRadioButton = locator(pwId("AddHome:homePlumb:1"));

		private Locator typeOfHeatingDropDown = locator(pwId("AddHome:priHeatingSys"));

		private Locator emailAddressTextBox = locator(pwId("AddHome:Email"));

		private Locator agreeAndContinueButton = locator(pwId("AddHome:nextDiscount"));

		private Locator nextButtonRoof = locator(pwXPath("//*[@id='roofsImagesContent']/button[2]"));

		private Locator lastPropertyClaim = locator(pwId("AddHome:lastpropLoss"));

		private Locator numberOfStoriesDropDown = locator(pwId("AddHome:propNoOfStories"));

		private Locator stormShuttersYesRadioButton = locator(pwXPath("//label[@for='AddHome:stormShutters:0']"));

		private Locator stormShuttersNoRadioButton = locator(pwXPath("//label[@for='AddHome:stormShutters:1']"));

		private Locator retrieveHavePoolErrorMessage = locator(pwXPath("//*[@id='AddHome:propPoolPnl']/div"));

		private Locator retrieveSystemReplacedLastTwentyYearsErrorMessage = locator(pwXPath("//*[@id='AddHome:entirehomePlumb']/div"));

		public Locator toolTip = locator(pwClass("TT"));

		public Locator propertyLossesKnockOutMessage = locator(pwXPath("//*[@id='propLossesError']"));

		public Locator toolTips = locator(pwClass("TT"));

		public Locator toolTipsText = locator(pwClass("middle"));

		public Locator retrieveHaveBasementErrorMsg = locator(pwXPath("//*[@id='additionalInfomation']/div[13]"));

		public Locator typeOfRoofTitles = locator(pwCss(".wallImages>label"));

		public Locator wallTypeTitles = locator(pwCss(".wallImages>label"));

		public Locator yourInfoTabButton = locator(pwXPath("//*[@id='AddHome:progress:0:addhome']/span[contains(text(), 'Your Info')]"));

		public Locator estReconstCostMsg = locator(pwId("PVError"));

		public Locator footerStaticText = locator(pwId("AddHome:tcpaTxtDisLbl"));

		private Locator saveAndFinishLaterBtn = locator(pwId("renterSave"));

		private Locator visitFcomBtn = locator(pwId("saveRetrieveLaterForm:farmersRedirectLink"));

		private Locator quoteHasBeenSavedOKButton = locator(pwId("saveRetrieveLaterForm:savetbuttonid"));

		private Locator weApologizeForInconvenienceText = locator(pwXPath("//div[@class='AgentLanding']"));

		private Locator arrowNextBtn = locator(pwCss(".slick-next.slick-arrow"));

		private Locator yourQuoteReqSpecAttentTitle = locator(pwXPath("//*[@id='AgentIntro']/h1"));

		private Locator haveConnectedYesRadioButton = locator(pwXPath("//*[@id='AddHome:vivintSmartHome']/tbody/tr/td[1]/label"));

		private Locator haveConnectedNoRadioButton = locator(pwXPath("//*[@id='AddHome:vivintSmartHome']/tbody/tr/td[2]/label"));

		private Locator propLossesLbl = locator(pwId("AddHome:propLossesLbl"));

		private Locator propDwellingtypeLbl = locator(pwId("AddHome:propDwellingtypeLbl"));

		private Locator propYearBuiltLbl = locator(pwId("AddHome:propYearBuiltLbl"));

		private Locator propSqrFootageLbl = locator(pwId("AddHome:propSqrFootageLbl"));

		private Locator exteriorWallTypeLbl = locator(pwId("AddHome:exteriorWallTypeLbl"));

		private Locator propGarageTypeLbl = locator(pwId("AddHome:propGarageTypeLbl"));

		private Locator priHeatingSysLbl = locator(pwId("AddHome:priHeatingSysLbl"));

		private Locator propNoOfFullBathsLbl = locator(pwId("AddHome:propNoOfFullBathsLbl"));

		private Locator propNoOfHalfBathsLbl = locator(pwId("AddHome:propNoOfHalfBathsLbl"));

		private Locator propRoofTypeLbl = locator(pwId("AddHome:propRoofTypeLbl"));

		private Locator propAgeOfRoofLbl = locator(pwId("AddHome:propAgeOfRoofLbl"));

		private Locator propertyDeckQuestionSection = locator(pwId("AddHome:propDeckPnl"));

		private Locator propDeckLbl = locator(pwId("AddHome:propDeckLbl"));

		private Locator propPoolLbl = locator(pwId("AddHome:propPoolLbl"));

		private Locator propBasementLbl = locator(pwId("AddHome:propBasementLbl"));

		private Locator entirehomePlumbLbl = locator(pwId("AddHome:entirehomePlumbLbl"));

		private Locator phoneLbl = locator(pwId("AddHome:phoneLbl"));

		private Locator emailLbl = locator(pwId("AddHome:emailLbl"));

		private Locator lastProplossLbl = locator(pwId("AddHome:lastProplossLbl"));

		private Locator vivintSmartHomeLbl = locator(pwId("AddHome:vivintSmartHomeLbl"));

		private Locator stormShuttersLbl = locator(pwId("AddHome:stormShuttersLbl"));

		private Locator agentNameLbl = locator(pwId("agentName"));

		private Locator agentAddressLbl = locator(pwId("agentAddress"));

		private Locator lastpropLossError = locator(pwId("lastpropLossError"));

		private Locator propLossesError = locator(pwId("propLossesError"));

		private Locator propDwellingtypeError = locator(pwId("propDwellingtypeError"));

		private Locator propYearBuiltError = locator(pwId("propYearBuiltError"));

		private Locator propSqrFootageError = locator(pwId("propSqrFootageError"));

		private Locator exteriorWallTypeError = locator(pwId("exteriorWallTypeError"));

		private Locator propGarageTypeError = locator(pwId("propGarageTypeError"));

		private Locator priHeatingSysError = locator(pwId("priHeatingSysError"));

		private Locator propNoOfFullBathsError = locator(pwId("propNoOfFullBathsError"));

		private Locator propNoOfHalfBathsError = locator(pwId("propNoOfHalfBathsError"));

		private Locator propRoofTypeError = locator(pwId("propRoofTypeError"));

		private Locator propAgeOfRoofError = locator(pwId("propAgeOfRoofError"));

		private Locator propBasementError = locator(pwId("propBasementError"));

		private Locator phoneError = locator(pwId("phoneError"));

		private Locator emailError = locator(pwId("emailError"));

		private Locator entirehomePlumbError = locator(pwId("entirehomePlumbError"));

		private Locator propBasementContainer = locator(pwId("AddHome:propBasement"));

		private Locator sqrFootageTT = locator(pwId("SqrFootageTT"));

		private Locator sqrFootageTTText = locator(pwXPath("//*[@id='SqrFootagePopup']/p"));

		private Locator sqrFootageTTClodeBtn = locator(pwXPath("//*[@id='SqrFootagePopup']/input"));

		private Locator extWallTypeTT = locator(pwId("extWallTypeTT"));

		private Locator extWallTypeTTText = locator(pwCss("#extWallTypePopup>p"));

		private Locator extWallTypeTTCloseBtn = locator(pwXPath("//*[@id='extWallTypePopup']/input"));

		private Locator roofTypeTT = locator(pwId("roofTypeTT"));

		private Locator roofTypeTTText = locator(pwXPath("//*[@id='roofTypePopup']/p"));

		private Locator roofTypeTTCloseBtnt = locator(pwXPath("//*[@id='roofTypePopup']/input"));

		private Locator phoneTT = locator(pwId("phoneTT"));

		private Locator phoneTTText = locator(pwXPath("//*[@id='phonePopup']/p"));

		private Locator phoneTTCloseBtn = locator(pwXPath("//*[@id='phonePopup']/input"));

		private Locator emailTT = locator(pwId("emailTT"));

		private Locator emailTTText = locator(pwXPath("//*[@id='emailPopup']/p"));

		private Locator emailTTCloseBtn = locator(pwXPath("//*[@id='emailPopup']/input"));

		private Locator yourInfoNavBarText = locator(pwXPath("//*[@id='AddHome:progress:0:addhome']/span[2]"));

		private Locator propertyNavBarText = locator(pwXPath("//*[@id='AddHome:progress:1:addhome']/span[2]"));

		private Locator coverageNavBarText = locator(pwXPath("//*[@id='AddHome:progress:2:addhome']/span[2]"));

		protected Locator quoteNavBarText = locator(pwXPath("//*[@id='AddHome:progress:3:addhome']/span[2]"));

		private Locator blueNavBar = locator(pwId("pbMenuPlaceHolder"));

		private Locator homeHeaderLogo = locator(pwId("HeaderLogo"));

		private Locator completeThisInformationSubHeaderText = locator(pwXPath("//*[@id='HomeIntro']/p"));

		private Locator quoteRequiresSpecialAttentionText = locator(pwId("AgentIntro"));

		private Locator addEmailToRetrieveQuote = locator(pwId("saveRetrieveLaterForm:Email"));

		private Locator continueSavingQuote = locator(pwId("saveRetrieveLaterForm:savetbuttonid"));

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public PropertyPage() throws Exception {
		super();
	}

	/**
	 *
	 * @return Map<String,Locator>
	 */
	private Map<String,Locator> getExteriorWallTypes() {
		Map<String, Locator> wallTypes = new HashMap<>();
		wallTypes.put("Stucco on Frame", stuccoOnFrameElement);
		wallTypes.put("Aluminium Siding", aluminiumSidingElement);
		wallTypes.put("Solid Brick", solidBrickElement);
		wallTypes.put("Brick Veneer", brickVeneerElement);
		wallTypes.put("Adobe", adobeElement);
		wallTypes.put("Cement Fiber Siding", cementFiberSidingElement);
		wallTypes.put("Wood Siding", woodSidingElement);
		wallTypes.put("Vinyl Siding", vinylSidingElement);
		wallTypes.put("Stone Veneer", stoneVeneerElement);
		wallTypes.put("Clapboard Wood", clapboardWoodElement);
		wallTypes.put("Stucco on Masonry", stuccoOnMasonryElement);
		wallTypes.put("Wood Shakes", woodShakesElement);
		wallTypes.put("Cement Shingles", cementShinglesElement);
		wallTypes.put("Steel Siding", steelSidingElement);
		wallTypes.put("Solid Stone", solidStoneElement);
		wallTypes.put("Solid Wood", solidWoodElement);
		wallTypes.put("Log Veneer Siding", logVeneerSidingElement);
		wallTypes.put("Clapboard Redwood", clapboardRedwoodElement);
		return wallTypes;
	}

	/**
	 *
	 * @return Map<String,Locator>
	 */
	private Map<String,Locator> getTypesOfRoof() {
		Map<String, Locator> typesOfRoof = new HashMap<>();
		typesOfRoof.put("Asphalt Shingle", asphaltShingle);
		typesOfRoof.put("Fiberglass / Dimensional Asphalt", fiberglassDimensionalAsphalt);
		typesOfRoof.put("Spanish Tile (Clay)", spanishTileClay);
		typesOfRoof.put("Concrete/Cement -Fiber Tile", concreteCementFiberTile);
		typesOfRoof.put("Steel (Tile or Shingle)", steelTileOrShingle);
		typesOfRoof.put("Rock/Tar Gravel", rockTarGravel);
		typesOfRoof.put("Wood Shingle/Shake", woodShingleShake);
		typesOfRoof.put("Sheet Metal Panel", sheetMetalPanel);
		typesOfRoof.put("Single Ply Membrane Systems", singlePlyMembraneSystems);
		typesOfRoof.put("Aluminum", aluminum);
		typesOfRoof.put("Rolled Asphalt - Flat", rolledAsphaltFlat);
		typesOfRoof.put("Synthetic Shingle or Tile", syntheticShingleOrTile);
		typesOfRoof.put("Slate", slate);
		typesOfRoof.put("Copper", copper);
		return typesOfRoof;
	}

	/**
	 * Select Exterior Wall Type.
	 *
	 * @param wallType
	 * @throws IllegalArgumentException
	 */
	private void selectExteriorWallType(String wallType) {
		Log.info("Selecting Exterior Wall Type: " + wallType);
		clickElement(homeExteriorWallType);
		Locator desiredWallType = getExteriorWallTypes().get(wallType);
		if (desiredWallType != null) {
			if (!(arrowNextBtn.count() == 0)) {
				while (nextButtonWall.isEnabled()) {
					for (Locator title : wallTypeTitles.all()) {
						if (getTextFromElement(title).equals(wallType) && desiredWallType.isEnabled()) {
							clickElement(desiredWallType);
							return;
						}
					}
					if (nextButtonWall.isVisible()) {
						clickElement(nextButtonWall);
					} else {
						throw new IllegalArgumentException(CANT_FIND + wallType + " after scrolling through all types.");
					}
				}
			} else if (!(wallTypeTitles.count() == 0)) {
				for (Locator title : wallTypeTitles.all()) {
					if (getHiddenText(title).equals(wallType)) {
						clickElement(desiredWallType);
						return;
					}
				}
				throw new IllegalArgumentException(CANT_FIND + wallType + " within all listed types");
			} else {
				throw new NullPointerException("wallTypeTitles array is empty " + wallType.isEmpty());
			}
		} else {
			throw new IllegalArgumentException(CANT_FIND + wallType + " in the wallType map.");
		}
	}

	/**
	 * Enter phone number.
	 *
	 * @param number
	 */
	private void enterPhoneNumber(String number) {
		Log.info("Entering Phone Number: " + number);
		if (this.getPhoneNumber().equals(EMPTY_STRING)) {
			enterDataOnTextField(phoneNumber, number);
		}
	}

	private String getPhoneNumber() {
		return getElementValue(phoneNumber, "Phone number: ");
	}

	/**
	 * Enter When Your Home Was Originally Built.
	 *
	 * @param year
	 */
	protected void enterWhenYourHomeWasOriginallyBuilt(int year) {
		Log.info("Selecting When Your Home Was Originally Built: " + year);
		enterDataOnTextField(whenYourHomeWasOriginallyBuilt, String.valueOf(year));
	}

	/**
	 * Enter Square Footage.
	 *
	 * @param square
	 */
	protected void enterSquareFootage(String square) {
		Log.info("Entering Square Footage: " + square);
		enterDataOnTextField(squareFootage, square);
	}

	/**
	 * Select Dwelling Style.
	 *
	 * @param style
	 */
	protected void selectDwellingStyle(String style) {
		Log.info("Selecting Dwelling Style: " + style);
		selectOptionInDropDownField(dwellingStyleDropDown, style);
	}

	/**
	 * Select Number Of Full Bathrooms.
	 *
	 * @param numberOfBath
	 * @throws Exception
	 */
	private void selectNumberOfFullBathrooms(String numberOfBath) {
		Log.info("Selecting Number Of Full Bathrooms: " + numberOfBath);
		selectOptionInDropDownField(propNoOfFullBathsDropDown, numberOfBath);
	}

	/**
	 * Select Number Of Half Bathrooms.
	 *
	 * @param numberOfHalfBath
	 * @throws Exception
	 */
	private void selectNumberOfHalfBathrooms(String numberOfHalfBath)  {
		Log.info("Selecting Number Of Half Bathrooms: " + numberOfHalfBath);
		selectOptionInDropDownField(propNoOfHalfBathsDropDown, numberOfHalfBath);
	}

	/**
	 * Select Type Of Roof.
	 *
	 * @param typeOfRoof
	 * @throws IllegalArgumentException
	 */
	private void selectTypeOfRoof(String typeOfRoof) {
		Log.info("Selecting Type Of Roof: " + typeOfRoof);
		clickElement(homeTypeOfRoof);
		Locator desiredTypeOfRoof = getTypesOfRoof().get(typeOfRoof);
		if (desiredTypeOfRoof != null) {
			if (!(arrowNextBtn.count() == 0)) {
				while (nextButtonRoof.isEnabled()) {
					for (Locator title : typeOfRoofTitles.all()) {
						if (getTextFromElement(title).equals(typeOfRoof) && desiredTypeOfRoof.isEnabled()) {
							clickElement(desiredTypeOfRoof);
							return;
						}
					}
					if (nextButtonRoof.isVisible()) {
						clickElement(nextButtonRoof);
					} else {
						throw new IllegalArgumentException(CANT_FIND + typeOfRoof);
					}
				}
			} else if (!(typeOfRoofTitles.count() == 0)) {
				for (Locator title : wallTypeTitles.all()) {
					if (getHiddenText(title).equals(typeOfRoof)) {
						clickElement(desiredTypeOfRoof);
						return;
					}
				}
				throw new IllegalArgumentException(CANT_FIND + typeOfRoof);
			} else {
				throw new NullPointerException("typeOfRoofTitles array is empty " + typeOfRoof.isEmpty());
			}
		} else {
			throw new IllegalArgumentException(CANT_FIND + typeOfRoof);
		}
	}

	/**
	 * Select How Old Is Your Roof.
	 *
	 * @param howOld
	 */
	private void selectHowOldIsYourRoof(String howOld) {
		Log.info("Selecting How Old Is Your Roof: " + howOld);
		selectOptionInDropDownField(howOldIsYourRoofDropDown, howOld);
	}

	/**
	 * Select Type Of Garage.
	 *
	 * @param typeOfGarage
	 */
	private void selectTypeOfGarage(String typeOfGarage) {
		Log.info("Selecting Type Of Garage: " + typeOfGarage);
		selectOptionInDropDownField(typeOfGarageDropDown, typeOfGarage);
	}

	/**
	 * Select Does Your Home Have Any Decks.
	 *
	 * @param anyDecks
	 */
	private void doesYourHomeHaveAnyDecks(boolean anyDecks) {
		Log.info("Selecting Does Your Home Have Any Decks: " + anyDecks);
		clickOnYesOrNoRadioButton(haveAnyDecksYesRadioButton, haveAnyDecksNoRadioButton, anyDecks);
	}

	/**
	 * Select Does Your Home Have Pool.
	 *
	 * @param havePool
	 */
	private void doesYourHomeHavePool(boolean havePool) {
		Log.info("Selecting Does Your Home Have A Pool: " + havePool);
		clickOnYesOrNoRadioButton(havePoolYesRadioButton, havePoolNoRadioButton, havePool);
	}

	/**
	 * Select Does Your Home Have A Basement.
	 *
	 * @param haveBasement
	 * @throws Exception
	 */
	private void doesYourHomeHaveBasement(boolean haveBasement) {
		Log.info("Selecting Does Your Home Have A Basement: " + haveBasement);
		scrollToElement(haveBasementYesRadioButton);
		clickOnYesOrNoRadioButton(haveBasementYesRadioButton, haveBasementNoRadioButton, haveBasement);
	}

	/**
	 * Select Does Your Home Have A Basement.
	 *
	 * @param haveConnected
	 */
	private void isYourHomeConnected(boolean haveConnected) {
		Log.info("Selecting Do you have a connected home?: " + haveConnected);
		clickOnYesOrNoRadioButton(haveConnectedYesRadioButton, haveConnectedNoRadioButton, haveConnected);
	}

	/**
	 * Select Permanent Storm Shutters.
	 *
	 * @param stormShutters
	 */
	private void selectPermanentStormShutters(boolean stormShutters) {
		Log.info("Selecting Permanent Storm Shutters: " + stormShutters);
		clickOnYesOrNoRadioButton(stormShuttersYesRadioButton, stormShuttersNoRadioButton, stormShutters);
	}

	/**
	 * Select What type of heating system is being currently used at your home.
	 *
	 * @param typeOfHeating
	 */
	protected void selectTypeOfHeatingSystemIsBeingCurrentlyUsed(String typeOfHeating) {
		Log.info("Selecting What type of heating system is being currently used at your home: " + typeOfHeating);
		selectOptionInDropDownField(typeOfHeatingDropDown, typeOfHeating);
	}

	/**
	 * Enter Email Address.
	 *
	 * @param email
	 */
	private void enterEmailAddress(String email) {
		Log.info("Entering Email Address: " + email);
		if (this.getEmailAddress().equals(EMPTY_STRING)) {
			enterDataOnTextField(emailAddressTextBox, email);
		}
	}

	private String getEmailAddress() {
		return getElementValue(emailAddressTextBox, "email address: ");
	}

	/**
	 * Select How Long Ago Was Your Last Property Claim.
	 *
	 * @param claim
	 */
	private void selectHowLongAgoWasYourLastPropertyClaim(String claim) {
		Log.info("Selecting How Long Ago Was Your Last Property Claim: " + claim);
		selectOptionInDropDownField(lastPropertyClaim, claim);
	}

	/**
	 * Click Continue Button.
	 *
	 */
	private void enterDataOnTextField(Locator textEntryField, String data) {
		waitElementBeVisible(textEntryField);
		sendKeysToElement(textEntryField, data);
	}

	private void selectOptionInDropDownField(Locator dropDown, String option) {
		waitElementBeVisible(dropDown);
		try {
			if (needToScrollElementIntoView()) {
				scrollToElement(dropDown);
			}
		} catch (Exception e) {
			Log.info ("Unable to scroll " + dropDown.toString() + " into view");
		}
		selectFromDropDown(dropDown, option);
	}

	private void clickOnYesOrNoRadioButton(Locator yesRadioButton, Locator noRadioButton, boolean clickOnYesButton) {
		if (clickOnYesButton) {
			waitAndClickElement(yesRadioButton);
		} else {
			waitAndClickElement(noRadioButton);
		}
	}

	private void clickAgreeAndContinueButton() {
		scrollAndClickOnElement(agreeAndContinueButton);
	}

	/**
	 * Get Map where Key is text box element and Value is error message associated with this text box.
	 * @return Map<Locator,String>
	 *
	 */
	private LinkedHashMap<Locator,List<String>> getMapWithErrorMessages() {
		Log.info("Getting Map with error messages");
		LinkedHashMap<Locator, List<String>> errorMessages = new LinkedHashMap<>();
		errorMessages.put(lastPropertyClaim, new ArrayList<>(Collections.singletonList("How long ago was your last property claim? is a required field.")));
		errorMessages.put(whenYourHomeWasOriginallyBuilt, new ArrayList<>(Collections.singletonList("What year was your home originally built? is a required field.")));
		errorMessages.put(squareFootage, new ArrayList<>(Arrays.asList("Square Footage is a required field.","The square footage must be at least 100 square feet.")));
		errorMessages.put(homeExteriorWallType, new ArrayList<>(Collections.singletonList("Home Exterior Wall type is a required field.")));
		errorMessages.put(dwellingStyleDropDown, new ArrayList<>(Collections.singletonList("Dwelling style is a required field.")));
		errorMessages.put(typeOfGarageDropDown, new ArrayList<>(Collections.singletonList("Type of garage is a required field.")));
		errorMessages.put(typeOfHeatingDropDown,new ArrayList<>(Collections.singletonList("What type of heating system is being currently used at your home? is a required field.")));
		errorMessages.put(propNoOfFullBathsDropDown, new ArrayList<>(Collections.singletonList("Number of full bathrooms is a required field.")));
		errorMessages.put(propNoOfHalfBathsDropDown,new ArrayList<>(Collections.singletonList("Number of half bathrooms is a required field.")));
		errorMessages.put(howOldIsYourRoofDropDown, new ArrayList<>(Collections.singletonList("How old is your roof? is a required field.")));
		errorMessages.put(phoneNumber,new ArrayList<>(Arrays.asList("Phone number is a required field"," is not a valid entry.")));
		errorMessages.put(emailAddressTextBox, new ArrayList<>(Arrays.asList("Email address is a required field","Email address entered is invalid")));
		return errorMessages;
	}

	/**
	 * Get List with Property Page Elements.
	 * @return List<Locator>
	 *
	 */
	private LinkedHashMap<Locator, Locator> getMapWithPropertyPageElements() {
		Log.info("Getting List with Property Page Elements");
		LinkedHashMap<Locator, Locator> elements = new LinkedHashMap<>();
		elements.put(lastPropertyClaim,lastpropLossError);
		elements.put(whenYourHomeWasOriginallyBuilt, propYearBuiltError);
		elements.put(squareFootage, propSqrFootageError);
		elements.put(homeExteriorWallType, exteriorWallTypeError);
		elements.put(dwellingStyleDropDown, propDwellingtypeError);
		elements.put(typeOfGarageDropDown, propGarageTypeError);
		elements.put(typeOfHeatingDropDown, priHeatingSysError);
		elements.put(propNoOfFullBathsDropDown, propNoOfFullBathsError);
		elements.put(propNoOfHalfBathsDropDown, propNoOfHalfBathsError);
		elements.put(howOldIsYourRoofDropDown, propAgeOfRoofError);
		elements.put(phoneNumber, phoneError);
		elements.put(emailAddressTextBox, emailError);
		return elements;
	}

	/**
	 * Clear What year was your home originally built? field.
	 *
	 */
	private void clearHomeOriginallyBuiltField() {
		Log.info("Clearing What year was your home originally built? field");
		whenYourHomeWasOriginallyBuilt.fill("");
	}

	/**
	 * Clear Square Footage field.
	 *
	 */
	private void clearSquareFootageField() {
		Log.info("Clearing Square Footage field");
		squareFootage.fill("");
	}

	/**
	 * Clear Drop Downs to "Please Select" option.
	 *
	 */
	private void clearDropDowns() throws Exception {
		Log.info("Clearing Drop Downs to Please Select option");
		setAttribute(homeTypeOfRoof,"value","Please Select");
		setAttribute(homeExteriorWallType,"value", "Please Select");
		selectFromDropDownByValue(dwellingStyleDropDown,EMPTY_STRING);
		selectFromDropDownByValue(propNoOfFullBathsDropDown,EMPTY_STRING);
		selectFromDropDownByValue(propNoOfHalfBathsDropDown,EMPTY_STRING);
		selectFromDropDownByValue(howOldIsYourRoofDropDown,EMPTY_STRING);
		selectFromDropDownByValue(typeOfGarageDropDown,EMPTY_STRING);
	}

	/**
	 * Get Map where Key is drop down element and Value is List of values associated with this drop down.
	 * @return Map<Locator,List<String>>
	 *
	 */
	private Map<Locator,List<String>> getMapWithDropDownsValues() {
		Log.info("Getting Map with drop downs values");
		Map<Locator, List<String>> dropDownValues = new HashMap<>();
		dropDownValues.put(lastPropertyClaim, new ArrayList<>(Arrays.asList(PLEASE_SELECT,"None","Less than 3 years","3-5 years","More than 5 years")));
		dropDownValues.put(dwellingStyleDropDown, new ArrayList<>(Arrays.asList(PLEASE_SELECT,"1 Story","1 1/2 Stories","2 Story","2 1/2 Stories","3 Story","Bi-Level/Raised Ranch","Split Level")));
		dropDownValues.put(propNoOfFullBathsDropDown, new ArrayList<>(Arrays.asList(PLEASE_SELECT,"0","1","2","3","4","5","6","6+")));
		dropDownValues.put(propNoOfHalfBathsDropDown, new ArrayList<>(Arrays.asList(PLEASE_SELECT,"0","1","2","3","4","5","6","6+")));
		dropDownValues.put(howOldIsYourRoofDropDown,
				new ArrayList<>(Arrays.asList(PLEASE_SELECT,"0 Year","1 Year","2 Years","3 Years","4 Years","5 Years","6 Years","7 Years","8 Years","9 Years","10 Years","11 Years","12 Years","13 Years","14 Years"
						,"15 Years","16 Years","17 Years","18 Years","19 Years","20 Years","21 Years","22 Years","23 Years","24 Years","25 Years","26 Years","27 Years","28 Years","29 Years","30 or more Years", "I dont know")));
		dropDownValues.put(typeOfGarageDropDown, new ArrayList<>(Arrays.asList(PLEASE_SELECT,"1 Car Attached/Built-in","1 Car Carport","1 Car attached with Living Area Above","2 Car Attached/Built-in","2 Car Carport ","2 Car attached with Living Area Above","3 Car Attached/Built-in","3 Car Carport ","3 Car attached with Living Area Above","4 Car Attached/Built-in","4 Car Carport ","Detached","None")));
		dropDownValues.put(typeOfHeatingDropDown, new ArrayList<>(Arrays.asList(PLEASE_SELECT,"Coal","Electric","Gas","Kerosene","Oil","Other/Unknown","Wood")));
		return dropDownValues;
	}

	/**
	 * Get List with Property Page Drop Downs Elements.
	 * @return List<Locator>
	 *
	 */
	private List<Locator> getListWithPropertyPageDropDownsElements() {
		Log.info("Getting List with Property Page Drop Downs Elements");
		List<Locator> elements = new ArrayList<>();
		elements.add(lastPropertyClaim);
		elements.add(dwellingStyleDropDown);
		elements.add(propNoOfFullBathsDropDown);
		elements.add(propNoOfHalfBathsDropDown);
		elements.add(howOldIsYourRoofDropDown);
		elements.add(typeOfGarageDropDown);
		elements.add(typeOfHeatingDropDown);
		return elements;
	}

	/**
	 * Get Map with Your Info Tool Tips Elements.
	 * @return Map<Locator,Locator>
	 *
	 */
	private Map<Locator,Locator> getMapWithPropertyPageToolTipsElements() {
		Log.info("Getting Map with Your Info Tool Tips Elements");
		Map<Locator,Locator> elements = new LinkedHashMap<>();
		elements.put(sqrFootageTT, sqrFootageTTClodeBtn);
		elements.put(extWallTypeTT, extWallTypeTTCloseBtn);
		elements.put(roofTypeTT, roofTypeTTCloseBtnt);
		elements.put(phoneTT, phoneTTCloseBtn);
		elements.put(emailTT, emailTTCloseBtn);
		return elements;
	}

	/**
	 * Get Map with Your Info Tool Tips Text.
	 * @return Map<Locator,String>
	 *
	 */
	private Map<Locator,LinkedHashMap<Locator,String>> getMapWithToolTipsText() {
		Log.info("Getting Map with Your Info Page Tool Tips text");
		Map<Locator, LinkedHashMap<Locator,String>> mapToolTipsText = new LinkedHashMap<>();

		LinkedHashMap<Locator, String> map1 = new LinkedHashMap<>();
		map1.put(sqrFootageTTText, "Total square footage of your residence.");

		LinkedHashMap<Locator, String> map2 = new LinkedHashMap<>();
		map2.put(extWallTypeTTText, "Please select the type of material your home made from.");

		LinkedHashMap<Locator, String> map3 = new LinkedHashMap<>();
		map3.put(roofTypeTTText, "Please select the primary type of material your roof is made from.");

		LinkedHashMap<Locator, String> map4 = new LinkedHashMap<>();
		map4.put(phoneTTText, "Providing your phone number makes it easier for us to connect you with your personal agent, file any claim, or resolve an issue.");

		LinkedHashMap<Locator, String> map5 = new LinkedHashMap<>();
		map5.put(emailTTText, "We'll email you your quote when it's complete, or you can use your email address to retrieve your quote during the process. We never share or sell your email address, and it will never be spammed.");

		mapToolTipsText.put(sqrFootageTT, map1);
		mapToolTipsText.put(extWallTypeTT, map2);
		mapToolTipsText.put(roofTypeTT, map3);
		mapToolTipsText.put(phoneTT, map4);
		mapToolTipsText.put(emailTT, map5);

		return mapToolTipsText;
	}

	private void verifyAgentSection(ApplicantHome applicant) throws Exception {
		Log.info("Asserting agent info is not displayed for political agent flow");
		List<Locator> agentInfo = locators(pwId("agentName"));
		if (!agentInfo.isEmpty()) {
			Assert.assertFalse(agentNameLbl.isVisible(), "Agent name shouldn't be displayed if political agent flow is : " + applicant.isPoliticalFlowScenario());
		}
		agentInfo = locators(pwId("agentAddress"));
		if (!agentInfo.isEmpty()) {
			Assert.assertFalse(agentAddressLbl.isVisible(), "Agent address shouldn't be displayed if political agent flow is : " + applicant.isPoliticalFlowScenario());
		}
	}

	private void verifyNavBarTitle() {
		Log.info("Asserting navigation bar item title...");
		Assert.assertEquals(getTextFromElement(yourInfoNavBarText), "YOUR INFO", NAVIGATION_BAR_ITEM_NO_MATCH_MSG);
		Assert.assertEquals(getTextFromElement(propertyNavBarText), "PROPERTY", NAVIGATION_BAR_ITEM_NO_MATCH_MSG);
		Assert.assertEquals(getTextFromElement(coverageNavBarText), "COVERAGE", NAVIGATION_BAR_ITEM_NO_MATCH_MSG);
		Assert.assertEquals(getTextFromElement(quoteNavBarText), "QUOTE", NAVIGATION_BAR_ITEM_NO_MATCH_MSG);
		Assert.assertTrue(blueNavBar.isVisible(),"Blue navigation bar doesn't displayed ");
		Assert.assertTrue(homeHeaderLogo.isVisible(),"Header logo doesn't displayed ");
		Assert.assertEquals(getTextFromElement(completeThisInformationSubHeaderText), "Please complete this information about the property you want to insure \u2014 and verify its accuracy.", "Sub header text doesn't match ");
	}

	public ChooseYourCoveragePage propertyPageErrorValidationHome(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		clearHomeOriginallyBuiltField();
		clearSquareFootageField();
		clearDropDowns();
		clickAgreeAndContinueButton();
		verifyIsMissingFieldsErrorMessagesVisible(getMapWithErrorMessages(), getMapWithPropertyPageElements(), applicant);
		return enterPropertyInfo(applicant, fsa);
	}

	public void propertyPageValidationHome(FarmersSoftAssert fsa) throws Exception {
		waitElementBeVisible(lastPropertyClaim);
		verifyNavBarTitle();
		verifyHomeHelpLinks(getListWithHomeLOBFooterLinks(), getListWithHomeLOBFooterURLDestinationsTitle());
		verifyDropDownListValues(getListWithPropertyPageDropDownsElements(), getMapWithDropDownsValues(), fsa);
		verifyAllToolTipsInPage(getMapWithPropertyPageToolTipsElements(), getMapWithToolTipsText());
		checkAllURLsAndImages(findAllURLsAndImages());
	}

	public List<Locator> getListWithPropertyPageElementsForInvalidInput() {
		Log.info("Getting List with property page page Elements");
		List<Locator> elements = new ArrayList<>();
		elements.add(numberOfAdultsInHousehold);
		elements.add(whenYourHomeWasOriginallyBuilt);
		elements.add(squareFootage);
		elements.add(phoneNumber);
		elements.add(emailAddressTextBox);
		return elements;
	}

	private void verifyFooterStaticText() {
		String homePropertyStaticText = "String clicking \"Agree and submit\", you agree to these ESIGN terms and conditions and to receive marketing calls and texts as detailed below.";
		scrollToElement(footerStaticText);
		String footerText = getTextFromElement(footerStaticText);
		Log.info("Asserting footer static text:\n" + footerText);
		Assert.assertEquals(footerText, homePropertyStaticText, "Footer static text doesn't match");
	}

	protected void clickSaveFinishLaterButton() {
		Log.info("Clicking save finish later button");
		clickElement(saveAndFinishLaterBtn);
		clickVisitFcomButton();
	}

	private void clickVisitFcomButton() {
		Log.info("Clicking visit Farmers.com button");
		if (isElementPresentByID(visitFcomBtn)) {
			clickElement(visitFcomBtn);
		} else {
			clickElement(quoteHasBeenSavedOKButton);
		}
	}

	protected static synchronized void saveApplicantFinishLater(ApplicantHome applicant, String leftOnPage, String quoteNumber) {
		ApplicantRetQuote applicantRetQuote = new ApplicantRetQuote();
		applicantRetQuote.setLastName(applicant.getLastName());
		applicantRetQuote.setAge(applicant.getAge());
		applicantRetQuote.setZipCode(applicant.getZipCode());
		applicantRetQuote.setEmailAddress(applicant.getEmailAddress());
		applicantRetQuote.setQuoteNumber(quoteNumber);
		applicantRetQuote.setPageLeftOn(leftOnPage);
		returningQuoteConcurrentHashMap.put(applicant.getLastName() + applicant.getZipCode(), applicantRetQuote);
		Log.info("Successfully saved home quote for later in " + leftOnPage);
	}

	private List<Locator> getListWithLabels(String applicantState) {
		Log.info("Getting List with labels elements");
		List<Locator> labelElements = new ArrayList<>();
		labelElements.add(lastProplossLbl);
		labelElements.add(propDwellingtypeLbl);
		labelElements.add(propYearBuiltLbl);
		labelElements.add(propSqrFootageLbl);
		labelElements.add(exteriorWallTypeLbl);
		labelElements.add(propGarageTypeLbl);
		labelElements.add(priHeatingSysLbl);
		labelElements.add(propNoOfFullBathsLbl);
		labelElements.add(propNoOfHalfBathsLbl);
		labelElements.add(propRoofTypeLbl);
		labelElements.add(propAgeOfRoofLbl);
		if (hasDeckQuestion()) {
			labelElements.add(propDeckLbl);
			labelElements.add(propPoolLbl);
		}
		labelElements.add(propBasementLbl);
		labelElements.add(vivintSmartHomeLbl);
		if (isStormShutterState(applicantState)) {
			labelElements.add(stormShuttersLbl);
		}
		return labelElements;
	}

	/**
	 * Get Map where Key is text box element and Value is error message associated with this text box.
	 * @return Map<Locator,String>
	 *
	 */
	private Map<Locator,String> getMapWithExpLabels(String applicantState) {
		Log.info("Getting Map with expected labels");
		Map<Locator,String> expLabelMap = new HashMap<>();

		expLabelMap.put(lastProplossLbl, "How long ago was your last property claim?");
		expLabelMap.put(propDwellingtypeLbl, "Dwelling style:");
		expLabelMap.put(propYearBuiltLbl, "What year was your home originally built?");
		expLabelMap.put(propSqrFootageLbl, "Square Footage:");
		expLabelMap.put(exteriorWallTypeLbl, "Home Exterior Wall type:");
		expLabelMap.put(propGarageTypeLbl, "Type of garage:");
		expLabelMap.put(priHeatingSysLbl, "What type of heating system is being currently used at your home?");
		expLabelMap.put(propNoOfFullBathsLbl, "Number of full bathrooms:");
		expLabelMap.put(propNoOfHalfBathsLbl, "Number of half bathrooms:");
		expLabelMap.put(propRoofTypeLbl, "Type of roof:");
		expLabelMap.put(propAgeOfRoofLbl, "How old is your roof?");
		if (hasDeckQuestion()) {
			expLabelMap.put(propDeckLbl, "Does your home have any decks?");
			expLabelMap.put(propPoolLbl, "Does your home have a pool?");
		}
		expLabelMap.put(propBasementLbl, "Does your home have a basement?");
		expLabelMap.put(vivintSmartHomeLbl, "Do you have a connected home?");
		if (isStormShutterState(applicantState)) {
			expLabelMap.put(stormShuttersLbl, "Permanent Storm Shutters");
		}
		return expLabelMap;
	}

	public boolean onPropertyPage() {
		waitForLegacySpinnerToBeGone();
		return isElementPresentByID(whenYourHomeWasOriginallyBuilt);
	}

	/**
	 * Add Applicant "Property Info" section. Handles every
	 * option and questions based on State.
	 *
	 * @param applicant
	 * @param fsa TODO
	 * @return DiscountsPageHome
	 * @throws Exception
	 */
	public ChooseYourCoveragePage enterPropertyInfo(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		screenCapture(homeHeaderLogo, "Home_PropertyPage", EMPTY_STRING, true);
		String homeQuoteNumber = getLegacyQuoteNumber();
		writeCreatedQuoteInformationToFile("HOME - " + homeQuoteNumber + SPACE + applicant.getFirstName() + SPACE + applicant.getLastName() + SPACE + applicant.getAddressApt() + SPACE + applicant.getCity() + SPACE + applicant.getStateCode() + SPACE + applicant.getZipCode() + NEWLINE);
		String applicantState = applicant.getState();
		verifyElementExpectedContent(getListWithLabels(applicantState), getMapWithExpLabels(applicantState), fsa);
		if (applicant.isDidNavBack()) {
			enterWhenYourHomeWasOriginallyBuilt(2018);
			enterSquareFootage("1000");
			selectNumberOfFullBathrooms("2");
			clickAgreeAndContinueButton();
			return new ChooseYourCoveragePage();
		}
		selectHowLongAgoWasYourLastPropertyClaim(applicant.getHowLongAgoWasYourLastPropertyClaim());
		if (applicant.isPoliticalFlowScenario()) {
			verifyAgentSection(applicant);
		}
		selectTypeOfHeatingSystemIsBeingCurrentlyUsed(applicant.getHeatingSystemIsBeingUsed());
		if (!applicant.isKeep360Prefill()) {
			selectDwellingStyle(applicant.getDwellingStyle());
			enterWhenYourHomeWasOriginallyBuilt(applicant.getWhenYourHomeWasOriginallyBuilt());
			enterSquareFootage(applicant.getSquareFootage());
			selectExteriorWallType(applicant.getHomeExteriorWallType());
			selectTypeOfGarage(applicant.getTypeOfGarage());
			selectNumberOfFullBathrooms(applicant.getNumberOfFullBathsRooms());
			selectTypeOfRoof(applicant.getTypeOfRoof());
			selectHowOldIsYourRoof(applicant.getHowOldIsYourRoof());
			doesYourHomeHaveBasement(applicant.isYourHomeHaveBasement());
			if (hasDeckQuestion()) {
				doesYourHomeHaveAnyDecks(applicant.isYourHomeHaveAnyDecks());
			}
		}
		selectNumberOfHalfBathrooms(applicant.getNumberOfHalfBathsRooms());
		if (expectPoolQuestion(applicant.getStateCode())) {
			doesYourHomeHavePool(applicant.isYourHomeHavePool());
		}
		isYourHomeConnected(applicant.isYourHomeConnected());
		if (isStormShutterState(applicantState)) {
			selectPermanentStormShutters(applicant.isPermanentStormShutters());
		}
		enterPhoneNumber(applicant.getPhoneNumber());
		enterEmailAddress(applicant.getEmailAddress());
		verifyFooterStaticText();
		if (applicant.isSaveAndRetrievePropPage() && findInCallStack(SAVE_AND_RETRIEVE_HOME_QUOTE)) {
			saveApplicantFinishLater(applicant, PROPERTY_PAGE_HOME, getLegacyQuoteNumber());
			clickSaveFinishLaterButton();
			waitElementBeVisible(addEmailToRetrieveQuote);
			sendKeys(addEmailToRetrieveQuote, applicant.getEmailAddress());
			clickElement(continueSavingQuote);
			return null;
		}
		clickAgreeAndContinueButton();
		waitForLegacySpinnerToBeGone();
		if (isLegacyQuoteKnockout()) {
			if (applicant.getTypeOfRoof().equals(COPPER) && applicantState.equals(NEW_YORK)) {
				waitElementBeVisible(yourQuoteReqSpecAttentTitle);
				Log.info(String.format("Asserting that if roof type is: %s and state is %s system should display \"Your quote requires special attention\" page", applicant.getTypeOfRoof(), applicantState));
				fsa.assertTrue(page().content().contains(YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION), "Page doesn't contain: " + YOUR_QUOTE_REQUIRES_SPECIAL_ATTENTION + " text");
			} else if (applicant.getWhenYourHomeWasOriginallyBuilt() == OLDEST_HOME) {
				Log.info("Asserting oldest home: " + applicant.getWhenYourHomeWasOriginallyBuilt());
				waitElementBeVisible(weApologizeForInconvenienceText);
				fsa.assertTrue(getTextFromElement(weApologizeForInconvenienceText).contains(WE_APOLOGIZE_FOR_THE_INCONVENIENCE), WE_APOLOGIZE_FOR_THE_INCONVENIENCE + " text doesn't match");
			} else {
				fsa.fail("-- Home quote " + homeQuoteNumber + " for " + applicant + " stopped after property page because QUOTE KNOCKED OUT --");
			}
			return null;
		} else if (applicant.getLastName().contains(RECONSTRUCTION_COST_SCENARIO)) {
			if (isElementPresentByID(estReconstCostMsg)) {
				fsa.assertEquals(getTextFromElement(estReconstCostMsg), ESTIMATED_RECONSTRUCTION_COST_STATIC_TEXT, "Estimated reconstruction cost text doesn't match");
			} else {
				fsa.fail("Did not find Estimated reconstruction cost error message for " + applicant.getAddressApt() +  " in " + applicantState);
			}
			return null;
		}
		if (isElementVisible(estReconstCostMsg, 10)) {
			Log.warn("++ Home quote " + homeQuoteNumber + " for " + applicant + " stopped after property page because of reconstruction value ++");
			return null;
		}
		return new ChooseYourCoveragePage();
	}

	public void enterPropertyInfo(SqlAddress address) throws Exception {
		selectHowLongAgoWasYourLastPropertyClaim(NONE);
		if (address.getPropertyType().equalsIgnoreCase(HOUSE)) {
			selectDwellingStyle("2 Story");
		} else {
			selectDwellingStyle("Townhouse - Center Unit");
		}
		enterWhenYourHomeWasOriginallyBuilt(2014);
		enterSquareFootage("1000");
		selectExteriorWallType("Adobe");
		selectTypeOfGarage("1 Car Carport");
		selectTypeOfHeatingSystemIsBeingCurrentlyUsed("Gas");
		selectNumberOfFullBathrooms("1");
		selectNumberOfHalfBathrooms("1");
		selectTypeOfRoof("Slate");
		selectHowOldIsYourRoof("3 Years");
		if (hasDeckQuestion()) {
			doesYourHomeHaveAnyDecks(false);
		}
		if (expectPoolQuestion(address.getStateCode())) {
			doesYourHomeHavePool(false);
		}
		doesYourHomeHaveBasement(false);
		isYourHomeConnected(false);
		if (isStormShutterState(address.getStateName())) {
			selectPermanentStormShutters(false);
		}
		enterPhoneNumber("8189376643");
		enterEmailAddress("farmerstest2017@gmail.com");
		clickAgreeAndContinueButton();
		try {
			waitForLegacySpinnerToBeGone();
			wait.until(Conditions.invisible(pwId(getAttributeData(agreeAndContinueButton, LOWERCASE_ID))));
		} catch (PlaywrightException nse) {
			Log.info("Should no longer be in Property page");
		}
		if (isLegacyQuoteKnockout()) {
			Assert.fail("-- Home quote knocked out after property page --");
		} else {
			ChooseYourCoveragePage coveragePage = new ChooseYourCoveragePage();
			clickElement(coveragePage.propertyNavBarText);
			waitForLegacySpinnerToBeGone();
			clickElement(yourInfoNavBarText);
		}
	}

	public ChooseYourCoveragePage validatePropertyPageHomeAndContinue(ApplicantHome applicant, FarmersSoftAssert fsa) throws Exception {
		fsa.assertEquals(getLegacyQuoteNumber(), applicant.getApplicantRetQuote().getQuoteNumber(), "Quote number");
		return enterPropertyInfo(applicant, fsa);
	}

	private boolean isStormShutterState(String state) {
		List<String> stormShutterStates = new ArrayList<>(Arrays.asList(GEORGIA, NEW_JERSEY));
		return stormShutterStates.contains(state);
	}

	private boolean hasDeckQuestion() {
		return isElementPresentByID(propertyDeckQuestionSection);
	}

	private boolean expectPoolQuestion(String stateCode) {
		return stateCode.equals(NJ);
	}

	private boolean needToScrollElementIntoView() {
		return (Property.getBrowser().equals(EDGE) || isSafariBrowser());
	}
}
