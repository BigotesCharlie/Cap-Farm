package com.farmers.ffq.homevideoflow.support;

import com.microsoft.playwright.Page;

public final class HomeStateDetector {
    private final Page page;

    public HomeStateDetector(Page page) { this.page = page; }

    public HomeState detect() {
        String url = safe(page.url()).toLowerCase();
        String body = safeBody().toLowerCase();

        // URL-based detection first (more reliable than body text)
        if (url.contains("inconvenience")) return HomeState.INCONVENIENCE;
        if (url.contains("knockout")) return HomeState.KNOCKOUT;
        if (url.contains("fastquote")) return HomeState.LANDING;
        if (url.contains("property-type")) return HomeState.PROPERTY_TYPE;
        if (url.contains("personal-info")) return HomeState.ADDRESS;
        if (url.contains("quality-grade")) return HomeState.QUALITY_GRADE;
        if (url.contains("property-details")) return HomeState.PROPERTY_SUMMARY;
        if (url.contains("additional-info")) return HomeState.ADDITIONAL_INFO;
        if (url.contains("/about-you")) return HomeState.ABOUT_YOU;
        if (url.contains("contact-info")) return HomeState.CONTACT_INFO;
        if (url.contains("dwelling-coverage") || url.contains("review-quote") || url.contains("custom-coverage")) return HomeState.DWELLING_COVERAGE;
        if (url.contains("thankyou")) return HomeState.THANK_YOU;
        
        // Fallback to body text if URL doesn't match
        if (body.contains("we can't finish your quote online") || body.contains("try again")) return HomeState.INCONVENIENCE;
        if (body.contains("knockout") || body.contains("unable to continue")) return HomeState.KNOCKOUT;
        if (body.contains("one moment, please")) return HomeState.LOADING;
        if (body.contains("optional coverages")) return HomeState.OPTIONAL_COVERAGES;
        if (body.contains("home coverages")) return HomeState.HOME_COVERAGES;
        if (body.contains("just a few more things")) return HomeState.ADDITIONAL_QUESTIONS;
        if (body.contains("finalizing your quote")) return HomeState.FINALIZING;
        if (body.contains("how would you like to pay")) return HomeState.PAYMENT_OPTIONS;
        if (body.contains("home policy payment")) return HomeState.PAYMENT;
        
        return HomeState.UNKNOWN;
    }

    private String safeBody() {
        try { return page.locator("body").innerText(); }
        catch (RuntimeException ex) { return ""; }
    }

    private String safe(String s) { return s == null ? "" : s; }
}
