package com.farmers.ffq.auto.pages.bw;


import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.auto.pages.QuoteSummaryAutoPage;
public class BristolWestAdditionalDiscountsPage extends AutoBasePage {

        private Locator pageHeader = locator(pwXPath("//app-additional-discounts//h1"));

        private Locator pageSubheader = locator(pwXPath("//app-additional-discounts//h1/../p"));

        private Locator otherPolicyGroupLabel = locator(pwXPath("//app-additional-discounts//h1/../div[1]"));

        private Locator homeownerPolicyRadioButton = locator(pwId("RADIO_BUTTON_FOR_H"));
    
        private Locator homeownerPolicyRadioButtonLabel = locator(pwXPath("//label[contains (@for, 'RADIO_BUTTON_FOR_H')]"));
    
        private Locator mobileHomeownerPolicyRadioButton = locator(pwId("RADIO_BUTTON_FOR_M"));

        private Locator mobileHomeownerPolicyRadioButtonLabel = locator(pwXPath("//label[contains (@for, 'RADIO_BUTTON_FOR_M')]"));

        private Locator rentersPolicyRadioButton = locator(pwId("RADIO_BUTTON_FOR_R"));

        private Locator rentersPolicyRadioButtonLabel = locator(pwXPath("//label[contains (@for, 'RADIO_BUTTON_FOR_R')]"));

        private Locator noPolicyRadioButton = locator(pwId("RADIO_BUTTON_FOR_N"));

        private Locator noPolicyRadioButtonLabel = locator(pwXPath("//label[contains (@for, 'RADIO_BUTTON_FOR_N')]"));

        private Locator otherPeopleInHouseholdLabel = locator(pwXPath("//app-additional-discounts//h1/../div[2]"));

        private Locator otherPeopleLivingInHouseholdButton = locator(pwId("SHOW_HOUSEHOLD_COUNT_YES"));
    
        private Locator noOtherPeopleLivingInHouseholdButton = locator(pwId("SHOW_HOUSEHOLD_COUNT_NO"));
    
        private Locator continueButton = locator(pwId("CONTINUE_CTA"));
    
    public BristolWestAdditionalDiscountsPage() throws Exception {
    	super();
	}

    public boolean isOnBristolWestAdditionalDiscountsPage() {
    	return isElementPresent(pwId("CONTINUE_CTA"), 3);
    }

    public QuoteSummaryAutoPage clickContinue() throws Exception {
    	scrollAndClickOnElement(continueButton);
    	waitForSpinnerToBeGone();
    	return new QuoteSummaryAutoPage();
    }    
}
