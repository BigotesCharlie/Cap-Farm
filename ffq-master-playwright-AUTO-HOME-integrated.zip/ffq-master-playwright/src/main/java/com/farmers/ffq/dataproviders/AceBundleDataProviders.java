package com.farmers.ffq.dataproviders;

import com.farmers.ffq.datatransferobjects.AceBundleApplicant;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import org.testng.SkipException;
import org.testng.annotations.CustomAttribute;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceBundleDataProviders extends DataProviders {
    private static final Random randomNumberGenerator = new Random();
    private static final String AUTO_APPLICANT_DATA = "applicant";
    public static final String BUNDLE_APPLICANT_DATAPROVIDER = "AllBundleApplicantsDataProvider";
    public static final String RANDOM_BUNDLE_APPLICANT = "RandomBundleApplicant";
    public static final String RANDOM_BUNDLE_APPLICANT_WITH_INCIDENTS = "RandomBundleApplicantWithIncidents";
    public static final String RANDOM_BUNDLE_APPLICANT_WITH_THREE_VEHICLES = "RandomBundleApplicantWith3Vehicles";
    public static final String ONE_BUNDLE_APPLICANT_PER_STATE = "OneBundleApplicantPerState";

    @DataProvider(name = BUNDLE_APPLICANT_DATAPROVIDER, parallel = true)
    public static synchronized Iterator<AceBundleApplicant> bundleApplicantsIterator(Method method) throws Exception {
    	String dataProviderDescriptionString = BUNDLE_APPLICANT_DATAPROVIDER;
    	Test annotation = method.getAnnotation(Test.class);
    	List<String> listOfApplicableStates = updateListOfStatesWithTestAttributeAndStateListProperty(method, new ArrayList<>(getListOfAceBundleStates(Property.getUri())));
       	List<AceBundleApplicant> listOfBundleApplicants = new ArrayList<>();
       	if (listOfApplicableStates.isEmpty()) {
            throw new SkipException("The Ace Bundle dataprovider found no applicable data for this test in this environment ");
        } else {
            CustomAttribute[] customAttrs = annotation.attributes();
            String filter = NO_FILTER;
        	for (CustomAttribute testAttribute : customAttrs) {
        		List<String> listOfValuesFromTestcase = Arrays.asList(testAttribute.values());
        		if (testAttribute.name().equals(FILTER)) {
        			// filter Property overrides any custom attribute filtering, so only use value from test case if property is not set
        			String filterByProperty = Property.getTestProperty(FILTER);
        			if (filterByProperty == null || filterByProperty.equals(EMPTY_STRING) || filterByProperty.equals(ALL)) {
        				filter = listOfValuesFromTestcase.get(FIRST_AVAILABLE_OPTION);
        			}
        		}
        	}
    		List<AutoApplicant> listOfAutoApplicants = AutoDataProviders.listOfAutoApplicants(AUTO_APPLICANT_DATA, filter);
    		List<ApplicantAceHome> listOfHRCApplicants = listOfAceHomeApplicants(HOME_APPLICANT_PAGE, NO_FILTER);
    		listOfAutoApplicants.removeIf(applicant -> !listOfApplicableStates.contains(applicant.getStateCode()));
    		for (AutoApplicant autoApplicant : listOfAutoApplicants) {
    			String stateCode = autoApplicant.getStateCode();
    			List<ApplicantAceHome> filteredHRCApplicants = listOfHRCApplicants.stream()
    					.filter(hrcApplicant -> hrcApplicant.getStateCode().equals(stateCode))
    					.collect(Collectors.toList());
    			if (filteredHRCApplicants.isEmpty()) {
    				throw new SkipException("The Ace Home dataprovider found no data for " + stateCode);
    			}
    			ApplicantAceHome hrcApplicant = filteredHRCApplicants.get(randomNumberGenerator.nextInt(filteredHRCApplicants.size()));
    			AceBundleApplicant bundleApplicant = new AceBundleApplicant();
    			bundleApplicant.setAutoApplicant(autoApplicant);
    			bundleApplicant.setHrcApplicant(hrcApplicant);
    			listOfBundleApplicants.add(bundleApplicant);
    		}
    	}
    	if (annotation != null) {
    		String dataProviderScenario = annotation.testName();
    		if (dataProviderScenario != null) {
    			dataProviderDescriptionString = dataProviderScenario;
    			//special case for Production Validation suite
    			String stateListProperty = Property.getTestProperty(STATE_LIST);
    			if (stateListProperty != null && stateListProperty.equals(PRODUCTION_VALIDATION) && !stateListProperty.equals(ALL)) {
    				dataProviderScenario = ONE_BUNDLE_APPLICANT_PER_STATE;
    			}
    			switch (dataProviderScenario) {
    			case RANDOM_BUNDLE_APPLICANT:
    				AceBundleApplicant randomBundleApplicant = listOfBundleApplicants.get(randomNumberGenerator.nextInt(listOfBundleApplicants.size()));
    				listOfBundleApplicants.clear();
    				listOfBundleApplicants.add(randomBundleApplicant);
    				break;
    			case RANDOM_BUNDLE_APPLICANT_WITH_INCIDENTS:
    				List<AceBundleApplicant> listOfBundleApplicantWithIncidents = listOfBundleApplicants.stream().filter(bundleApplicant -> !bundleApplicant.getAutoApplicant().getIncidents().isEmpty() && bundleApplicant.getAutoApplicant().getApplicantId()!=35).collect(Collectors.toList());
    				AceBundleApplicant randomBundleApplicantWithIncidents = listOfBundleApplicantWithIncidents.get(randomNumberGenerator.nextInt(listOfBundleApplicantWithIncidents.size()));
    				listOfBundleApplicants.clear();
    				listOfBundleApplicants.add(randomBundleApplicantWithIncidents);
    				break;
    			case RANDOM_BUNDLE_APPLICANT_WITH_THREE_VEHICLES:
    				List<AceBundleApplicant> listOfBundleApplicantWithThreeVehicles = listOfBundleApplicants.stream().filter(bundleApplicant -> bundleApplicant.getAutoApplicant().getVehicles().size()>2).collect(Collectors.toList());
    				if (!listOfBundleApplicantWithThreeVehicles.isEmpty()) {
    					AceBundleApplicant randomBundleApplicantWithThreeVehicles = listOfBundleApplicantWithThreeVehicles.get(randomNumberGenerator.nextInt(listOfBundleApplicantWithThreeVehicles.size()));
    					listOfBundleApplicants.clear();
    					listOfBundleApplicants.add(randomBundleApplicantWithThreeVehicles);
    				}
    				break;
    			case ONE_BUNDLE_APPLICANT_PER_STATE:
    				List<AceBundleApplicant> listOfRandomEntries = new ArrayList<>();
    				for (String stateCode : listOfApplicableStates) {
    					if (listOfBundleApplicants.stream().anyMatch(bundleApplicant -> (bundleApplicant.getAutoApplicant().getStateCode().equals(stateCode)))) {
    						List<AceBundleApplicant> tempEntries = listOfBundleApplicants.stream().filter(bundleApplicant -> bundleApplicant.getAutoApplicant().getStateCode().equals(stateCode)).collect(Collectors.toList());
    						listOfRandomEntries.add(tempEntries.get(randomNumberGenerator.nextInt(tempEntries.size())));
    					}
    				}
    				listOfBundleApplicants = listOfRandomEntries;
    				break;
    			}
    		}
    	}
    	listOfBundleApplicants.forEach(AceBundleApplicant::normalizeData);
    	Log.info(String.format(DP_LOG_ENTRY, dataProviderDescriptionString, listOfBundleApplicants.size()));
    	return listOfBundleApplicants.iterator();
    }
}
