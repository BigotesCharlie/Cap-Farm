package com.farmers.ffq.auto.pages;



import com.farmers.framework.playwright.Keys;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.datatransferobjects.ADPFApplicant;
import com.farmers.ffq.datatransferobjects.IidResponseBean;
import com.farmers.ffq.utils.ApiHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;

import net.datafaker.Faker;

import org.apache.commons.lang.RandomStringUtils;
import com.farmers.framework.report.Log;
import org.testng.SkipException;

import java.util.List;


public class AutoRecentMoverPage extends AutoBasePage {

    private static final String PAGE_HEADER = "Let's check your address...";
    private static final String PAGE_SUB_HEADER = "Hmm, we can't match you to that address.";
    private static final String RECENT_MOVER_QUESTION = "Have you moved in the last 6 months?";
    public static final String PREVIOUS_ADDRESS_INPUT_LABEL = "Previous address (No PO boxes)";
    public static final String APARTMENT_INPUT_LABEL = "Apartment #";
    public static final String OPTIONAL_LABEL = "Optional";

        private Locator pageHeader = locator(pwXPath("//app-recent-mover-flow//h1"));

        private Locator pageSubHeader = locator(pwCss("div[class='tui-body-text-1 recent-mover-sub-heading']"));

        private Locator recentMoverToggleHeader = locator(pwCss("label[class='tui-field-label-text recent-mover-toggle-label mb-2']"));

        private Locator yesToggleButton = locator(pwXPath("//mat-button-toggle[contains(.,'Yes')]"));

        private Locator noToggleButton = locator(pwXPath("//mat-button-toggle[contains(.,'No')]"));

        private Locator googlePrefilAddressInputField = locator(pwXPath("//address-autocomplete-input//input"));

        private Locator googlePrefillAddressInputLabel = locator(pwXPath("//address-autocomplete-input//label//mat-label"));

        private Locator googlePrefillAddressErrorMessage = locator(pwXPath("//address-autocomplete-input//mat-error"));

        private Locator manualStreetInput = locator(pwXPath("//div[@id='formField_street']//input"));

        private Locator manualStreetInputLabel = locator(pwXPath("//div[@id='formField_street']//label//mat-label"));

        private Locator manualStreetInputErrorMessage = locator(pwXPath("//div[@id='formField_street']//mat-error"));

        private Locator apartmentInput = locator(pwXPath("//div[@id='formField_apartment']//input"));

        private Locator manualApartmentInput = locator(pwCss("input[id='auto-manual-apartment__input-section']"));

        private Locator apartmentInputLabel = locator(pwXPath("//div[@id='formField_apartment']//label//mat-label"));

        private Locator manualApartmentInputLabel = locator(pwXPath("//div[@class='auto-manual-address-mailing-field']//label//mat-label"));

        private Locator optionalLabel = locator(pwXPath("//mat-hint[contains(.,'Optional')]"));

        private Locator manualOptionalLabel = locator(pwXPath("//div[@class='auto-manual-address-mailing-field']//mat-hint"));

        private Locator manualCityInputField = locator(pwXPath("//div[@id='formField_city']//input"));

        private Locator manualCityInputLabel = locator(pwXPath("//div[@id='formField_city']//label//mat-label"));

        private Locator manualCityInputErrorMessage = locator(pwXPath("//div[@id='formField_city']//mat-error"));

        private Locator manualStateDropdown = locator(pwXPath("//div[@id='mailingAddressDiv_state']//mat-select"));

        private Locator manualStateDropdownLabel = locator(pwXPath("//div[@id='mailingAddressDiv_state']//label//mat-label"));

        private Locator manualStateDropdownErrorMessage = locator(pwXPath("//div[@id='mailingAddressDiv_state']//mat-error"));

        private Locator manualZipCodeInput = locatorAny(pwXPath("//mat-form-field[.//label[contains(.,'Zip Code')]]//input"), pwXPath("//div[@id='formField_zipCode']//input"));

        private Locator manualZipCodeLabel = locator(pwXPath("//div[@id='formField_zipCode']//label//mat-label"));

        private Locator manualZipCodeErrorMessage = locator(pwXPath("//div[@id='formField_zipCode']//mat-error"));

        private Locator manualAddressPopupHeader = locator(pwId("manualAddrHeading"));

        private Locator manualAddressPopupContent = locator(pwId("manualAddrContent"));

        private Locator manualAddressGoBackButton = locator(pwCss("a[class='manual-addr_field-label-text']"));

        private Locator manualAddressYesEnterManuallyButton = locator(pwCss("button[class='tui-btn tui-btn-primary tui-button-text manual-addr__action-buttons']"));

        private Locator continueButton = locator(pwCss("button[class='tui-btn tui-btn-primary']"));


    /**
     * Constructor.
     *
     * @throws Exception
     */
    public AutoRecentMoverPage() throws Exception {
    }

    public boolean isOnRecentMoverPage() {
        return isElementVisible(pageHeader, 25);
    }

    public void processRecentMoverPage(ADPFApplicant applicant, boolean isRecentlyMoved, boolean manualEntry, boolean useSameAddress) throws Exception {
        if (isRecentlyMoved) {
            waitAndClickElement(yesToggleButton);
            if (useSameAddress) {
                fillOutPreviousAddressDetails(applicant.getAddress(), applicant.getCity(), applicant.getStateCode(), applicant.getZipCode(), manualEntry);
            } else {
                fillOutPreviousAddressDetails("86 Clintondale Hill Rd", "Mill Hall", "PA", "17751", manualEntry);
            }
        } else {
            waitAndClickElement(noToggleButton);
        }
        waitAndClickElement(continueButton);
        waitForSpinnerToBeGone();
        IidResponseBean iidResponse = new ApiHelper().getIidResponse(getSessionStorageAppStore().getData().getQuoteNumber());
        try {
            if(iidResponse.getTransactionNotification().getTransactionCode().equals("E")) {
              throw new SkipException("Recent mover page was not able to render due to IID call");
            }
        } catch (NullPointerException npe) {
            Log.info("Recent mover page did not throw transaction error");
        }

    }

    private void fillOutPreviousAddressDetails(String street, String city, String stateCode, String zipCode, boolean manualEntry) throws Exception {
        if (manualEntry) {
        	enterGoogleAddress(googlePrefilAddressInputField, new Faker().address().streetAddress(), city);
        	sendKeysToElement(googlePrefilAddressInputField, Keys.TAB);
        } else {
        	enterGoogleAddress(googlePrefilAddressInputField, street, city);
        }

        if (isElementVisible(manualAddressPopupHeader,4) ) {
            waitAndClickElement(manualAddressYesEnterManuallyButton);
            waitElementBeInvisible(manualAddressGoBackButton);
            waitElementBeInvisible(manualAddressYesEnterManuallyButton);
            waitElementBeVisibleClickable(manualStreetInput);
            sendKeysToElement(manualStreetInput, street);
            sendKeysToElement(manualCityInputField, city);
            selectValueInDropDown(manualStateDropdown, stateCode);
            if (isSafariBrowser()) {
                jsSendKeys(manualZipCodeInput, zipCode);
            } else {
                sendKeysToElement(manualZipCodeInput, zipCode);
            }
        }
    }

    public void validateRecentMoverPage(FarmersSoftAssert fsa) throws Exception {
        //validate the db with the code, make sure code 25 is being returned
        IidResponseBean iidResponse = new ApiHelper().getIidResponse(getSessionStorageAppStore().getData().getQuoteNumber());
        IidResponseBean.RiskReports riskReports = iidResponse.getRiskReports();
        fsa.assertTrue(riskReports.isCachedRiskReportIndicator(), "Cached Risk Report Indicator should be true");
        fsa.assertTrue(riskReports.isIidHitIndicator(), "IID Hit Indicator should be true");
        List<IidResponseBean.RiskReports.IidReport.RiskIndicator> riskIndicators =
                riskReports.getIidReport().getRiskIndicators();
        fsa.assertTrue(riskIndicators.stream().anyMatch(each -> each.getCode().equals("25")), "Code 25 is present");

        // validate default labels
        fsa.assertEquals(getTextFromElement(pageHeader), PAGE_HEADER, "Recent mover page header is matching");
        fsa.assertEquals(getTextFromElement(pageSubHeader), PAGE_SUB_HEADER, "Recent mover page sub header is matching");
        fsa.assertEquals(getTextFromElement(recentMoverToggleHeader), RECENT_MOVER_QUESTION, "Recent mover toggle question is matching");
        fsa.assertEquals(getTextFromElement(yesToggleButton), "Yes", "Yes toggle label  is matching");
        fsa.assertEquals(getTextFromElement(noToggleButton), "No", "No toggle label  is matching");
        fsa.assertEquals(getTextFromElement(continueButton), "Continue", "No toggle label  is matching");

        // validate continue button disabled before user makes a selection
        fsa.assertTrue(continueButton.isVisible() && !continueButton.isEnabled(), "Continue button displayed but disabled");

        // click Yes and validate google prefill section
        waitAndClickElement(yesToggleButton);

        // validate labels for input fields
        fsa.assertEquals(getTextFromElement(googlePrefillAddressInputLabel), PREVIOUS_ADDRESS_INPUT_LABEL, "Previous address google prefill label validated");
        fsa.assertEquals(getTextFromElement(apartmentInputLabel), APARTMENT_INPUT_LABEL, "Apartment label is validated for google prefill section");
        fsa.assertEquals(getTextFromElement(optionalLabel), OPTIONAL_LABEL, "Optional label is validated for google prefill section");

        //validate error message for street address
        waitAndClickElement(continueButton);
        fsa.assertEquals(getTextFromElement(googlePrefillAddressErrorMessage), "Please enter your previous address.", "Google prefill address input field error message validated");
        validateTheColorIsRed(googlePrefillAddressErrorMessage, fsa, "The color of google prefill error message is red");
        validateTheColorIsRed(googlePrefillAddressInputLabel, fsa, "The color of google prefill label text is red");

    }

    public void validateRecentMoverZipCodeMismatch(FarmersSoftAssert fsa) throws Exception {
        isOnRecentMoverPage();
        waitAndClickElement(yesToggleButton);
        triggerManualEntryAndAccept();
        sendKeysToElement(manualStreetInput, "161 Chinna Berry Circle");
        sendKeysToElement(manualCityInputField, "Davenport");
        selectValueInDropDown(manualStateDropdown, "FL");
        // enter zipcode that is not from FL
        sendKeysToElement(manualZipCodeInput, "62014");
        waitAndClickElement(continueButton);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(manualZipCodeErrorMessage)), isSafariBrowser() ? "Please enter your ZIP code." : "Please enter a valid State/ZipCode.", "Zipcode and state is not a match");
        //enter correct zipCode and retry
        sendKeysToElement(manualZipCodeInput, "33837");
        waitAndClickElement(continueButton);
        waitForSpinnerToBeGone();
    }

    public void validateManualEntryPopUp(FarmersSoftAssert fsa) {
        waitAndClickElement(yesToggleButton);
        //trigger manual entry pop up
        sendKeysToElement(googlePrefilAddressInputField, RandomStringUtils.randomAlphabetic(5));
        sendKeysToElement(googlePrefilAddressInputField, Keys.TAB);

        //labels validation
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(manualAddressPopupHeader)), "We can't find your address", "Manual address entry pop up header validation");
        fsa.assertEquals(getTextFromElement(manualAddressPopupContent), "Do you want to enter your address manually?", "Manual address entry pop up content validation");
        fsa.assertEquals(getTextFromElement(manualAddressGoBackButton), "Go back", "Manual address entry go back label validation");
        fsa.assertEquals(getTextFromElement(manualAddressYesEnterManuallyButton), "Yes, enter manually", "Manual address entry yes enter manually label validation");

        // validate go back function
        waitAndClickElement(manualAddressGoBackButton);
        waitElementBeInvisible(manualAddressGoBackButton);
        waitElementBeInvisible(manualAddressYesEnterManuallyButton);
        fsa.assertTrue(!isElementVisible(manualAddressPopupHeader,2), "Manual entry pop up should not be visible when user click go back");

    }

    private void triggerManualEntryAndAccept() {
        sendKeysToElement(googlePrefilAddressInputField, RandomStringUtils.randomAlphabetic(5));
        sendKeysToElement(googlePrefilAddressInputField, Keys.TAB);
        waitElementBeVisible(manualAddressPopupHeader);
        waitAndClickElement(manualAddressYesEnterManuallyButton);
        waitElementBeInvisible(manualAddressYesEnterManuallyButton);
        waitElementBeInvisible(manualAddressGoBackButton);
    }

    public void validateManualEntrySection(FarmersSoftAssert fsa) throws Exception {
        waitAndClickElement(yesToggleButton);
        triggerManualEntryAndAccept();

        // validate labels in the manual entry sections
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(manualStreetInputLabel)), PREVIOUS_ADDRESS_INPUT_LABEL, "Manual entry section street address label validation");
        fsa.assertEquals(getTextFromElement(manualApartmentInputLabel), APARTMENT_INPUT_LABEL, "Manual entry section apartment input label validation");
        fsa.assertEquals(getTextFromElement(manualOptionalLabel), OPTIONAL_LABEL, "Manual entry section optional label validation");
        fsa.assertEquals(getTextFromElement(manualCityInputLabel), "City", "Manual entry section city label validation");
        fsa.assertEquals(getTextFromElement(manualStateDropdownLabel), "State", "Manual entry section state dropdown label validation");
        fsa.assertEquals(getTextFromElement(manualZipCodeLabel), "Zip Code", "Manual entry section zipcode input label validation");

        // validate error messages for manual entry section
        waitAndClickElement(continueButton);
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(manualStreetInputErrorMessage)), "Please enter street number and name.", "Manual address entry street input error message");
        validateTheColorIsRed(manualStreetInputLabel, fsa, "Manual entry street mat label color is red");
        validateTheColorIsRed(manualStreetInputErrorMessage, fsa, "Manual entry street input error color is red");
        fsa.assertEquals(getTextFromElement(manualCityInputErrorMessage), "Please enter your city.", "Manual address city input error message");
        validateTheColorIsRed(manualCityInputLabel, fsa, "Manual entry city input field mat label is in red color");
        validateTheColorIsRed(manualCityInputErrorMessage, fsa, "Manual entry city error message is in red color");
        fsa.assertEquals(getTextFromElement(manualStateDropdownErrorMessage), "Please enter your state.", "Manual address state dropdown error message");
        validateTheColorIsRed(manualStateDropdownErrorMessage, fsa, "Manual entry state drop down error message is in red");
        validateTheColorIsRed(manualStateDropdownLabel, fsa, "Manual entry state mat label is in red");
        fsa.assertEquals(getTextFromElement(manualZipCodeErrorMessage), "Please enter your ZIP code.", "Manual address entry zipcode input error message");
        validateTheColorIsRed(manualZipCodeLabel, fsa, "Manual entry zipcode mat label is red color");
        validateTheColorIsRed(manualZipCodeErrorMessage, fsa, "Manual entry zipcode error message is red color");

        // validate when clicked on No toggle, input fields disappear
        waitAndClickElement(noToggleButton);
        fsa.assertTrue(!isElementVisible(manualStreetInput,2), "Manual input section should disappear when user clicks No toggle");

        // #353: Verify if 'We can't find your address' pop up closes and user returns back to 'Lets check your address...' screen on clicking 'Go back' button
        refreshPage();
        waitAndClickElement(yesToggleButton);
        sendKeysToElement(googlePrefilAddressInputField, RandomStringUtils.randomAlphabetic(5));
        sendKeysToElement(googlePrefilAddressInputField, Keys.TAB);
        waitAndClickElement(manualAddressGoBackButton);
        waitElementBeInvisible(manualAddressGoBackButton);
        fsa.assertTrue(isOnRecentMoverPage() && !isElementVisible(manualAddressPopupHeader,2) && isElementVisible(googlePrefilAddressInputField,1), "Verify if 'We can't find your address' pop up closes and user returns back to 'Lets check your address...' screen on clicking 'Go back' button");

    }

    private void validateTheColorIsRed(Locator element, FarmersSoftAssert fsa, String message) {
        String color = String.valueOf(element.evaluate("(e,p)=>getComputedStyle(e).getPropertyValue(p)", "color"));
        fsa.assertTrue(List.of("rgb(197, 22, 45)", "rgba(197, 22, 45, 1)").contains(color), message);
    }

}
