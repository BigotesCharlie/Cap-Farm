package com.farmers.ffq.utils;


import com.microsoft.playwright.Locator;
import static com.farmers.ffq.common.pages.BasePage.sendGetRequest;

public class MyRunnable implements Runnable {

    private final Locator hrefElement;

    public MyRunnable(Locator element) {
        this.hrefElement = element;
    }

    @Override
    public void run() {
        sendGetRequest(hrefElement);
    }
}
