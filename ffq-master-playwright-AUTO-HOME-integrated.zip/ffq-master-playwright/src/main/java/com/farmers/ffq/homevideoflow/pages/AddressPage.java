package com.farmers.ffq.homevideoflow.pages;

import com.farmers.ffq.homevideoflow.config.VideoScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public final class AddressPage extends BaseHomePage {
    public AddressPage(Page page) { super(page); }

    public void complete(VideoScenarioData d) {
        waitForBodyReady();
        waitForSpinnerToClear();
        
        // Fill personal information fields - wait for visibility first
        try {
            Locator firstName = page.locator("#mat-input-0");  // First Name
            if (firstName.count() > 0) {
                firstName.waitFor();
                if (firstName.isVisible()) firstName.fill(d.firstName());
            }
        } catch (Exception e) {
            // Field may not be visible, continue
        }
        
        try {
            Locator lastName = page.locator("#mat-input-1");   // Last Name
            if (lastName.count() > 0) {
                lastName.waitFor();
                if (lastName.isVisible()) lastName.fill(d.lastName());
            }
        } catch (Exception e) {
            // Field may not be visible, continue
        }
        
        try {
            Locator dob = page.locator("#mat-input-2");        // Date of Birth
            if (dob.count() > 0) {
                dob.waitFor();
                if (dob.isVisible()) dob.fill(d.dob());
            }
        } catch (Exception e) {
            // Field may not be visible, continue
        }
        
        // Fill address information
        Locator address = page.getByLabel("Home Address", new Page.GetByLabelOptions().setExact(false));
        if (address.count() == 0) address = page.locator("input:visible").first();
        address.first().fill(d.address());

        // The video chooses the address suggestion; prefer a suggestion containing the full street.
        Locator suggestion = page.getByText(d.address(), new Page.GetByTextOptions().setExact(false));
        if (suggestion.count() > 1) suggestion.last().click();
        else if (suggestion.count() == 1 && suggestion.first().isVisible()) suggestion.first().click();
        
        // Fill city
        try {
            Locator city = page.locator("#mat-input-5");       // City
            if (city.count() > 0) {
                city.waitFor();
                if (city.isVisible()) city.fill(d.city());
            }
        } catch (Exception e) {
            // Field may not be visible, continue
        }

        // Answer form questions
        clickQuestionOption("buying", d.ownedLessThanYear() ? "Yes" : "No");
        clickQuestionOption("primary residence", d.primaryResidence() ? "Yes" : "No");
        clickQuestionOption("property claims", d.claimsLastThreeYears());

        // Submit form
        Locator agree = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Agree").setExact(false));
        if (agree.count() == 0) agree = page.getByText("Agree", new Page.GetByTextOptions().setExact(true));
        agree.first().click();
        
        // Wait for form submission and page transition
        page.waitForTimeout(1000);
        waitForSpinnerToClear();
    }

    private void clickQuestionOption(String questionFragment, String option) {
        Locator q = page.getByText(questionFragment, new Page.GetByTextOptions().setExact(false));
        if (q.count() > 0) {
            Locator block = q.first().locator("xpath=ancestor::*[self::div or self::section][1]");
            Locator choice = block.getByText(option, new Locator.GetByTextOptions().setExact(true));
            if (choice.count() > 0) { choice.last().click(); return; }
        }
        Locator role = page.getByRole(AriaRole.RADIO, new Page.GetByRoleOptions().setName(option).setExact(true));
        if (role.count() > 0) { role.last().click(); return; }
        page.getByText(option, new Page.GetByTextOptions().setExact(true)).last().click();
    }
}
