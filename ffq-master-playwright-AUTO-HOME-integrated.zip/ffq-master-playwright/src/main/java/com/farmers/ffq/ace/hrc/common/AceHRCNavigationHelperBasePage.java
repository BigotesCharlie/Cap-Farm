package com.farmers.ffq.ace.hrc.common;



import com.microsoft.playwright.options.ViewportSize;
import com.microsoft.playwright.Page;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.CSSToFFQAceApplicant;
import com.farmers.ffq.datatransferobjects.ToggleApplicant;
import com.farmers.ffq.utils.AESHelper;
import com.farmers.ffq.utils.GlobalVariables;
import com.farmers.framework.Property;
import com.farmers.framework.playwright.PlaywrightArtifacts;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.Setter;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter
public class AceHRCNavigationHelperBasePage extends AceHRCBasePage {
	public static final String DID_NOT_REACH = "Did not reach ";
    public static final String FAILED_RC2 = "FailedRC2";
    public static final String FAILED_RC3 = "FailedRC3";

    @Setter
    public String resumeFromPage = EMPTY_STRING;

	/**
	 * Constructor.
	 *
	 * @throws Exception
	 */
	public AceHRCNavigationHelperBasePage() throws Exception {
	}

	public void processLandingPage(ApplicantAceHome applicant, String lob) throws Exception {
		if (!(applicant.getAgentId()==null) && !applicant.getAgentId().isEmpty()) {
            lob = lob.equals(LOB_CONDO) ? LOB_HOME : lob;
			new LandingPage(String.format(Property.getUri() + "?Lob=%s&Source_Indicator=AP&State_Code=%s&Agent_Code=%s&Zip_Code=%s",
                    lob.charAt(0), applicant.getStateCode(), applicant.getAgentId(), applicant.getZipCode()), isUseMobileViewEnabled());
		} else {
			LandingPage landingPage = new LandingPage(isUseMobileViewEnabled(), true);
			if (lob.equals(LOB_CONDO) && !landingPage.isLOBButtonAvailable(LOB_CONDO)) {
				lob = LOB_HOME;
			}
			landingPage.enterLandingPageData(lob, applicant.getZipCode());
		}
	}

	public void processPartnerFlowPage(ApplicantAceHome applicant, String lob, boolean newApplicant) throws Exception {
		ToggleApplicant toggleApplicant = new ToggleApplicant(applicant, lob, newApplicant);
		String url = Property.getUri() + "?param=";

		ObjectMapper mapper = new ObjectMapper();
		String customerData = mapper.writeValueAsString(toggleApplicant);
		Log.info("Customer Data:"  + customerData);
		url += AESHelper.encryptToggle(customerData) + "&Flow=TG&SRC=TOGREHBZFQ";
		Log.info("Navigating to: " + url);
		navigate(url);
		if (isUseMobileViewEnabled()) {
			setViewportSize(PlaywrightArtifacts.MOBILE.width(), PlaywrightArtifacts.MOBILE.height());
		} else {
			maximizeWindow();
		}
		acceptCookies();
	}

    public void processSweepStakesCampaign(ApplicantAceHome applicant, String lob, String source_indicator, String source_id) throws Exception {
        String campaignUri = String.format(Property.getUri() + "?Lob=%s&Zip_Code=%s&source_indicator=%s&source_id=%s", lob,
                applicant.getZipCode(), source_indicator, source_id);
        Log.info("Navigating to " + campaignUri);
        navigate(campaignUri);
        if (isUseMobileViewEnabled()) {
            setViewportSize(PlaywrightArtifacts.MOBILE.width(), PlaywrightArtifacts.MOBILE.height());
        } else {
            maximizeWindow();
        }
        acceptCookies();
    }

	public void processCSSToFFQFlowPage(ApplicantAceHome applicant, String lob) throws Exception {
		CSSToFFQAceApplicant cssToFFQAceApplicant = new CSSToFFQAceApplicant(applicant, lob);
		String url = Property.getUri().replace("/fastquote", "/quote") + "?param=";

		ObjectMapper mapper = new ObjectMapper();
		String customerData = mapper.writeValueAsString(cssToFFQAceApplicant);
		Log.info("Customer Data:"  + customerData);
		String value = AESHelper.encryptWithOutIV(customerData);
		url += URLEncoder.encode(value, StandardCharsets.UTF_8);
		if (!applicant.getAgentId().isBlank()) {
			url += "&Flow=CF&Lob=Home&AOR=" + applicant.getAgentId() + "&SRC=MV000000001";
		} else {
			url += "&Flow=CF&Lob=Home&SRC=MV000000001";
		}
		Log.info("Navigating to: " + url);
		navigate(url);
		if (isUseMobileViewEnabled()) {
			setViewportSize(PlaywrightArtifacts.MOBILE.width(), PlaywrightArtifacts.MOBILE.height());
		} else {
			maximizeWindow();
			refreshPage();
		}
		acceptCookies();
	}

	public void retrieveQuoteByQuoteNumber(ApplicantAceHome applicant) throws Exception {
		new LandingPage(isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant.getLastName(), applicant.getDateOfBirth(), applicant.getQuoteNumber(), applicant.getZipCode());
		testStep("Retrieve quote by quote number: " + applicant.getQuoteNumber(), false);
	}

	public void retrieveQuoteByEmail(ApplicantAceHome applicant) throws Exception {
		new LandingPage(isUseMobileViewEnabled()).retrieveQuoteFromLandingPage(applicant.getLastName(), applicant.getDateOfBirth(), applicant.getEmailAddress(), applicant.getZipCode());
		testStep("Retrieve quote by email: " + applicant.getEmailAddress(), false);
	}

	protected AceHRCPropertyTypeBasePage navigateToHRCPropertyTypePage(ApplicantAceHome applicant, String lob) throws Exception {
		if (getResumeFromPage().equals("PropertyTypePage")) {
            AceHRCPropertyTypeBasePage propertyTypePage = new AceHRCPropertyTypeBasePage();
            if (propertyTypePage.quickIsOnPropertyTypePageCheck()) {
                return propertyTypePage;
            } else {
                throw new IllegalStateException(DID_NOT_REACH + "PropertyTypePage");
            }
		}
		processLandingPage(applicant, lob);
		AceHRCPropertyTypeBasePage propertyTypePage = new AceHRCPropertyTypeBasePage();
		if (propertyTypePage.isOnPropertyTypePage()) {
			applicant.setQuoteNumber(propertyTypePage.getSessionStorageAppStore().getData().getQuoteNumber());
			Log.info(NEW_QUOTE_NUMBER + applicant.getQuoteNumber(), true);
			if (isADATestingEnabled()) {
				if (lob.equals(LOB_HOME)) {
					performADATesting(propertyTypePage.getClass().getSimpleName(), MARKETING_IT, FFQ_ACE_HOME);
				}
			}
			Reporter.pass("Navigated to PropertyTypePage");
			return propertyTypePage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "PropertyTypePage");
		}
	}

	protected AceHRCAddressBasePage navigateToHRCAddressPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
		AceHRCAddressBasePage addressPage = new AceHRCAddressBasePage();
		if (getResumeFromPage().equals(ADDRESS_PAGE)) {
			return addressPage;
		}
        processLandingPage(applicant, lob);
        waitForPageToBeReady();
        if (addressPage.isOnAddressPage(false)) {
            Reporter.pass("Navigated to AddressPage");
        } else {
            AceHRCPropertyTypeBasePage propertyTypePage = new AceHRCPropertyTypeBasePage();
            if (propertyTypePage.quickIsOnPropertyTypePageCheck()) {
                propertyTypePage.selectPropertyType(propertyType);
            }
        }
        if (addressPage.isOnAddressPage(true)) {
			Reporter.pass("Navigated to AddressPage");
			if (applicant.getQuoteNumber() == null) {
				String quoteNumber = addressPage.getSessionStorageAppStore().getData().getQuoteNumber();
				Log.info(NEW_QUOTE_NUMBER + quoteNumber, true);
				applicant.setQuoteNumber(quoteNumber);
			}
			writeCreatedQuoteInformationToFile("Ace " + lob + " - " + applicant.getQuoteNumber() + SPACE + applicant.getFirstName() + SPACE + applicant.getLastName() +
					SPACE + applicant.getAddress() + SPACE + applicant.getCity() + SPACE + applicant.getStateCode() + SPACE + applicant.getZipCode());
			if (isADATestingEnabled()) {
				if (lob.equals(LOB_CONDO)) {
					addressPage.validateADA(FFQ_ACE_CONDO);
				} else if (lob.equals(LOB_RENTERS)) {
					addressPage.validateADA(FFQ_ACE_RENTERS);
				} else {
					addressPage.validateADA(FFQ_ACE_HOME);
				}
			}
			return addressPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AddressPage " + lob);
		}
	}

	public AceHRCQualityGradeBasePage navigateToHRCQualityGradePage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
		AceHRCQualityGradeBasePage qualityGradePage = new AceHRCQualityGradeBasePage();
		if (getResumeFromPage().equals(QUALITY_GRADE)) {
			return qualityGradePage;
		}
		AceHRCAddressBasePage addressPage = navigateToHRCAddressPage(applicant, lob, propertyType);
		if (!resumeFromPage.equals(GlobalVariables.ADDRESS_PAGE)) {
			addressPage.enterAddress(applicant);
			addressPage.enterAvailableFields(applicant);
		}
		boolean isPropertyYearBuiltPage = addressPage.clickContinue();
		if (isPropertyYearBuiltPage) {
			AceHRCPropertyBasePage propertyPage = new AceHRCPropertyBasePage();
			if (isADATestingEnabled()) {
				if (lob.equals(LOB_CONDO)) {
					propertyPage.validateADA(FFQ_ACE_CONDO);
				} else if (lob.equals(LOB_RENTERS)) {
					propertyPage.validateADA(FFQ_ACE_RENTERS);
				} else {
					propertyPage.validateADA(FFQ_ACE_HOME);
				}
			}
			waitForUiSettled();
			propertyPage.enterPropertyPageFields(applicant);
			propertyPage.clickContinueButton();
		}

		AceHRCQualityGradeBasePage aceHRCQualityGradeBasePage = new AceHRCQualityGradeBasePage();
		if (aceHRCQualityGradeBasePage.isOnQualityGradePage()) {
			if (isADATestingEnabled()) {
				if (lob.equals(LOB_CONDO)) {
					aceHRCQualityGradeBasePage.validateADA(FFQ_ACE_CONDO);
				} else {
					aceHRCQualityGradeBasePage.validateADA(FFQ_ACE_HOME);
				}
			}
			Reporter.pass("Navigated to Quality grade page");
			return aceHRCQualityGradeBasePage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "Quality grade page");
		}
	}

	protected AceHRCPropertyDetailsBasePage navigateToHRCPropertyDetailsPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
		AceHRCPropertyDetailsBasePage propertyDetailsBasePage = new AceHRCPropertyDetailsBasePage();
		if (getResumeFromPage().equals(PROPERTY_DETAILS)) {
			return propertyDetailsBasePage;
		}
		navigateToHRCQualityGradePage(applicant, lob, propertyType);
		(new AceHRCQualityGradeBasePage()).fillOutQualityGradePage(applicant, getSessionStorageAppStore().getHome().getHomeQualityGradeForm());
		if (propertyDetailsBasePage.isOnPropertyDetailsPage()) {
			if (isADATestingEnabled()) {
				propertyDetailsBasePage.validateADA(FFQ_ACE_HOME);
			}
			Reporter.pass("Navigated to Property Details Page");
			return propertyDetailsBasePage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "Property Details Page");
		}
	}

	protected AceHRCAdditionalInfoBasePage navigateToHRCAdditionalInfoPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
		AceHRCAdditionalInfoBasePage additionalInfoPage = new AceHRCAdditionalInfoBasePage();
		if (getResumeFromPage().equals(ADDITIONAL_INFO)) {
			return additionalInfoPage;
		}
		navigateToHRCPropertyDetailsPage(applicant, lob, propertyType);
		AceHRCPropertyDetailsBasePage propertyDetailsPage = new AceHRCPropertyDetailsBasePage();
		propertyDetailsPage.enterPropertyDetails(applicant);
		propertyDetailsPage.clickContinueButton();
		if (additionalInfoPage.isOnAdditionalInfoPage()) {
			if (isADATestingEnabled()) {
				additionalInfoPage.validateADA(FFQ_ACE_HOME);
			}
			Reporter.pass("Navigated to AdditionalInfoPage");
			return additionalInfoPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AdditionalInfoPage");
		}
	}

	protected AceHRCAboutYouBasePage navigateToHRCAboutYouPage(ApplicantAceHome applicant, String lob, String propertyType) throws Exception {
		AceHRCAboutYouBasePage aboutYouPage = new AceHRCAboutYouBasePage();
		if (getResumeFromPage().equals(ABOUT_YOU)) {
			return aboutYouPage;
		}
		navigateToHRCAdditionalInfoPage(applicant, lob, propertyType).fillOutAdditionalInfoPageHomeLob(applicant, true);
		if (aboutYouPage.isOnAboutYouPage(true)) {
			if (isADATestingEnabled()) {
				aboutYouPage.validateADA(FFQ_ACE_HOME);
			}
			Reporter.pass("Navigated to AboutYouPage");
			return aboutYouPage;
		} else {
			throw new IllegalStateException(DID_NOT_REACH + "AboutYouPage");
		}
	}

}


