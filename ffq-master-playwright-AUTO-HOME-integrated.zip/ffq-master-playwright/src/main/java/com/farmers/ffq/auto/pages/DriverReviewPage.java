package com.farmers.ffq.auto.pages;









import com.farmers.framework.playwright.Keys;
import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.TimeoutError;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.enums.*;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;

import net.datafaker.Faker;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.common.enums.AutoDiscounts.DEFENSIVE_DRIVER;

import static com.farmers.ffq.common.enums.AutoDiscounts.MATURE_DRIVER;
import static com.farmers.ffq.utils.GlobalVariables.*;
public class DriverReviewPage extends AutoBasePage {

    public static final String NG_VALID = "ng-valid";
    private static final String MARITAL_CHECKBOX_INPUT_XPATH = "//app-marriage-option//input[@type='checkbox']";
    private static final String MARITAL_CHECKBOX_XPATH = "//div[@class='auto-driver-review-question-married']//mat-checkbox";
    private static final String FINANCIAL_RESPONSIBILITY_CHECKBOX_XPATH = "//div[contains(@id,'ordered-field-placeholder_requiredFinancialResponsiblity')]//input[@type='checkbox']";
    private static final String FINANCIAL_FILING_ANOTHER_STATE_BUTTON_XPATH = "//mat-radio-button[contains(.,'Another state')]//input";
    private static final String ACCIDENT_OR_VIOLATION_DROPDOWN_XPATH = "//mat-select[@formcontrolname='incidentDescription']";
    private static final String ACCIDENT_OR_VIOLATION_DATE_INPUT_FIELD_XPATH = "//input[@formcontrolname='incidentDate']";
    private static final String ACCIDENT_TOGGLES_XPATH = "//button[contains(@aria-label,'Accident')]";
    private static final String VIOLATION_TOGGLE_XPATH = "//button[contains(@aria-label,'Violation')]";
    private static final String ADDITIONAL_INCIDENT_FORM_XPATH = "//app-incident//form[contains(@class,'ng-invalid')]";
    private static final String HAD_THEIR_DRIVER_LICENSE_CHECKBOX = "//mat-checkbox[@formcontrolname='hadDriveLicense']//input";
    private static final String DRIVER_AGE_XPATH_END = "//div[@class='auto-driver-review-age-display']/span";
    private static final String SAFETY_COURSE_SUBTEXT_XPATH_END = "//p[contains(@class, 'auto-driver-discount-safety-course-subinfo')]";
    private static final String CTA_ERROR_MESSAGE = "One or more required fields are incomplete or incorrect. Please Review.";
    public static final String IS_A_RIDE_SHARE_XPATH = "//mat-checkbox[contains(.,'rideshare')]";
    private static final String LIST_OF_DRIVERS_XPATH = "//div[@class='auto-driver-review-driver-card']//h2/..";

    private static final String COMMUTES_TO_DC_XPATH = "//mat-checkbox[contains(.,'Commutes to DC')]";
    private static final String OCCUPATION_RADIO_BUTTON_XPATH = "//mat-radio-button[contains(.,'%s')]//input";

    private static final String LICENSE_AGE_INPUT_FIELD_XPATH = "//input[@formcontrolname='ageFirstLicensed']";

    private static final String LICENSE_AGE_INPUT_TOGGLE_YES = "//div[contains(@class,'licensing-Info-head')]//mat-button-toggle[contains(.,'Yes')]";

    private static final String LICENSE_AGE_INPUT_TOGGLE_NO = "//div[contains(@class,'licensing-Info-head')]//mat-button-toggle[contains(.,'No')]";

    private static final String ACTIVE_MILITARY_RADIO_BUTTON_XPATH = "//div[contains(@class,'auto-driver-review-active-military-duty ng-star-inserted')]//input";
    private static final String DRIVER_LICENSE_NUMBER_INPUT_XPATH = "//div[@class='auto-driver-license-state-fields']//input";

    private static final String LICENSING_INFO_HEADER_XPATH = "//div[@class='licensing-info ng-star-inserted']//label[@class='tui-subtitle-text-1']";
    private static final String LICENSING_INFO_SUB_HEADER_XPATH = "//div[@class='licensing-info ng-star-inserted']//label[@class='tui-field-label-text']";
    private static final String LICENSING_INFO_US_YES_TOGGLE_XPATH = "//label[contains(.,'Canadian')]/..//mat-button-toggle[contains(.,'Yes')]";
    private static final String LICENSING_INFO_US_NO_TOGGLE_XPATH = "//label[contains(.,'Canadian')]/..//mat-button-toggle[contains(.,'No')]";
    private static final String LICENSING_INFO_US_DL_AGE_INPUT_XPATH = "//input[@formcontrolname='ageFirstLicencedInUS']";
    private static final String LICENSING_INFO_US_DL_AGE_INPUT_LABEL_XPATH = "//input[@formcontrolname='ageFirstLicencedInUS']/..//label";
    private static final String LICENSING_INFO_US_DL_AGE_INPUT_HINT_XPATH = "//input[@formcontrolname='ageFirstLicencedInUS']/ancestor::mat-form-field//strong";
    private static final String LICENSING_INFO_US_DL_AGE_INPUT_ERROR_MESSAGE_XPATH = "//input[@formcontrolname='ageFirstLicencedInUS']/ancestor::mat-form-field//mat-error";
    private static final String LICENSING_INFO_US_DL_DATE_INPUT_XPATH = "//mat-form-field[contains(.,'Date licensed')]//input";
    private static final String LICENSING_INFO_US_DL_DATE_INPUT_LABEL_XPATH = "//mat-form-field[contains(@id,'dateFirstLicensedInUS')]//label";
    private static final String LICENSING_INFO_US_DL_DATE_INPUT_ERROR_MESSAGE_XPATH = "//mat-form-field[contains(@id,'dateFirstLicensedInUS')]//mat-error";
    private static final String LICENSING_INFO_US_DL_DATE_INPUT_DATE_PICKER_XPATH = "//mat-form-field[contains(@id,'dateFirstLicensedInUS')]//mat-datepicker";
    private static final String LICENSING_INFO_US_DL_DATE_INPUT_HINT_XPATH = "//mat-form-field[contains(.,'Date licensed in U.S')]//mat-hint";
    private static final String LICENSING_FOREIGN_DL_QUESTION_CHECKBOX_XPATH = "//mat-checkbox[@formcontrolname='licensedToDriveInForeignCB']//input";
    private static final String LICENSING_FOREIGN_DL_QUESTION_CHECKBOX_LABEL_XPATH = "//mat-checkbox[@formcontrolname='licensedToDriveInForeignCB']//label";
    private static final String LICENSING_FOREIGN_DL_QUESTION_HEADER_XPATH = "//label[contains(.,'4 years ago')]/..//label";
    private static final String LICENSING_INFO_FOREIGN_YES_TOGGLE_XPATH = "//label[contains(.,'4 years ago')]/..//button[contains(.,'Yes')]";
    private static final String LICENSING_INFO_FOREIGN_NO_TOGGLE_XPATH = "//label[contains(.,'4 years ago')]/..//button[contains(.,'No')]";
    private static final String LICENSING_INFO_FOREIGN_DL_AGE_INPUT_XPATH = "//input[@formcontrolname='ageFirstLicencedInForeign' and not(@hidden)]";
    private static final String LICENSING_INFO_FOREIGN_DL_AGE_INPUT_LABEL_XPATH = "//input[@formcontrolname='ageFirstLicencedInForeign']/..//label";
    private static final String LICENSING_INFO_FOREIGN_DL_AGE_INPUT_HINT_XPATH = "//mat-form-field[contains(.,'Age licensed in another')]//strong";
    private static final String LICENSING_INFO_FOREIGN_DL_AGE_INPUT_ERROR_MESSAGE_XPATH = "//mat-form-field[contains(.,'Age licensed in another')]//mat-error";
    private static final String LICENSING_INFO_FOREIGN_DL_DATE_INPUT_XPATH = "//input[contains(@aria-label,'Date of Foreign')]";
    private static final String LICENSING_INFO_FOREIGN_DL_DATE_INPUT_LABEL_XPATH = "//mat-form-field[contains(.,'Date licensed in another')]//label";
    private static final String LICENSING_INFO_FOREIGN_DL_DATE_INPUT_DATE_PICKER = "//mat-form-field[contains(.,'Date licensed in another')]//mat-datepicker-toggle";
    private static final String LICENSING_INFO_FOREIGN_DL_DATE_INPUT_HINT_XPATH = "//mat-form-field[contains(.,'Date licensed in another')]//mat-hint";
    private static final String LICENSING_INFO_FOREIGN_DL_DATE_INPUT_ERROR_MESSAGE_XPATH = "//mat-form-field[contains(.,'Date licensed in another')]//mat-error";
    private static final String PLEASE_ENTER_VALID_AGE = "Please enter valid age";
    private static final String PLEASE_PROVIDE_AGE = "Please provide age";
    private static final String PLEASE_PROVIDE_VALID_DATE = "Please provide a valid date";
    private static final String ENTER_VALID_CASE_NUMBER = "Enter a valid 9-digit case number";
    private static final String DL_LICENSE_NUMBER_INPUT_FIELD_XPATH = "//input[@formcontrolname='licenseNumber']";
        private Locator driverReviewPageHeader = locator(pwId("auto-driver-review-header"));

        private Locator driverReviewPageDescription = locator(pwXPath("//div[@class='auto-driver-review-heading-note']//p[@class='tui-field-label-text']"));

    private static final String REVISE_WHICH_DRIVERS_TO_INCLUDE_LINK = "Revise which drivers to include";
        private Locator driversRevisionHyperlink = locator(pwXPath("//*[@data-tui-tracking-id='auto-drivers-review__drivers-overview-hyperlink']"));

        private Locator additionalDriverInfoIcon = locator(pwCss("mat-icon[data-tui-tracking-id='auto-drivers-review__additional-info']"));

        private Locator pniInfoIcon = locator(pwCss("mat-icon[data-tui-tracking-id='auto-drivers-review__pni-info']"));

        private Locator sniInfoIcon = locator(pwCss("mat-icon[data-tui-tracking-id='auto-drivers-review__sni-info']"));

        private Locator infoBoxHeader = locator(pwXPath("//h1[@class='model-caption-head']"));

        private Locator infoBoxContent = locator(pwXPath("//p[contains(@class,'model-caption-text')]"));

        private Locator infoBoxCloseButton = locator(pwXPath("//mat-icon[.='close']"));

    private static final String EDIT_DRIVER_BUTTON_XPATH = "//button[contains(@class,'auto-driver-_drivers-list-details-edit')]";

        private Locator editDriverButtons = locator(pwXPath(EDIT_DRIVER_BUTTON_XPATH));

        private Locator editDriverDialog = locator(pwXPath("//mat-dialog-container"));

        private Locator genderToggleLabels = locator(pwClass("mat-button-toggle-label-content"));

    private static final String SECOND_DIALOG_XPATH = "//div[@class='cdk-global-overlay-wrapper'][2]";
    private static final String OR_OPERATOR = " | ";

    private static final String DIALOG_CLOSE_LINK_XPATH = "//div[contains(@class,'auto-add-driver-heading__div')]//mat-icon/ancestor::a";
        private Locator editDriverDialogCloseLink = locator(pwXPath(SECOND_DIALOG_XPATH + DIALOG_CLOSE_LINK_XPATH + OR_OPERATOR + DIALOG_CLOSE_LINK_XPATH));

        private Locator addDriverHeading = locator(pwId("addDriverHeading"));

        private Locator driverLicenseQuestionLabel = locator(pwXPath("//label[contains(@class,'auto-add-driver-license__label')]"));

        private Locator currentlyInsuredQuestionLabel = locator(pwXPath("//label[contains(@class,'auto-add-driver-currently-insured__label')]"));

        private Locator saveChangesButton = locator(pwXPath("//div[contains(@class,'auto-add-driver-submit')]//button"));
        private Locator editDriverCancelButton = locator(pwPartialLinkText("Cancel"));

        private Locator occupationSidePanelCancelButton = locator(pwXPath("//mat-dialog-actions//button[contains(.,'Cancel')]"));

    private static final String DIALOG_FIRST_NAME_FIELD_XPATH = "//input[@aria-label='First name']";
    private static final String TABINDEX_XPATH = "[string-length(@tabindex)>0]";
        private Locator listOfFirstNameFields = locator(pwXPath("//mat-form-field[contains(.,'First name')]"));

    private static final String DIALOG_FIRST_NAME_ERROR_LABEL_XPATH = "//div[@id='formField_firstName']//mat-error";
        private Locator firstNameErrorMessage = locator(pwXPath(SECOND_DIALOG_XPATH + DIALOG_FIRST_NAME_ERROR_LABEL_XPATH + OR_OPERATOR + DIALOG_FIRST_NAME_ERROR_LABEL_XPATH));

    private static final String DIALOG_LAST_NAME_FIELD_XPATH = "//input[@aria-label='Last name']";
        private Locator listOfLastNameFields = locator(pwXPath("//mat-form-field[contains(.,'Last name')]"));

    private static final String DIALOG_LAST_NAME_ERROR_LABEL_XPATH = "//div[@id='formField_lastName']//mat-error";
        private Locator lastNameErrorMessage = locator(pwXPath(SECOND_DIALOG_XPATH + DIALOG_LAST_NAME_ERROR_LABEL_XPATH + OR_OPERATOR + DIALOG_LAST_NAME_ERROR_LABEL_XPATH));

    private static final String DIALOG_DATE_OF_BIRTH_ERROR_LABEL_XPATH = "//div[@id='formField_dateOfBirth']//mat-error";
        private Locator dateOfBirthErrorMessage = locator(pwXPath(SECOND_DIALOG_XPATH + DIALOG_DATE_OF_BIRTH_ERROR_LABEL_XPATH + OR_OPERATOR + DIALOG_DATE_OF_BIRTH_ERROR_LABEL_XPATH));

    private static final String DIALOG_DATE_OF_BIRTH_FIELD_XPATH = "//input[@aria-label='Date of birth']";
        private Locator listOfDateOfBirthFields = locator(pwXPath("//mat-form-field[contains(.,'Date of birth')]"));

    private static final String DIALOG_GENDER_BUTTONS_XPATH = "//div[@id='gender']//button/span[contains(text(),'Female')]";
        private Locator listOfFemaleGenderButtons = locator(pwXPath(SECOND_DIALOG_XPATH + DIALOG_GENDER_BUTTONS_XPATH + OR_OPERATOR + "//div[@id='gender']//button[string-length(@tabindex)>0]/span[contains(text(),'Female')]"));

    private static final String DIALOG_GENDER_ERROR_LABEL_XPATH = "//div[@id='formField_gender']//mat-error";
        private Locator genderErrorMessage = locator(pwXPath(SECOND_DIALOG_XPATH + DIALOG_GENDER_ERROR_LABEL_XPATH + OR_OPERATOR + DIALOG_GENDER_ERROR_LABEL_XPATH));

        private Locator drivingSpouseErrorMessage = locator(pwXPath("//div[contains(@class,'licenseToggleQuestion')]//mat-error"));

        private Locator licenseErrorMessageForDrivingSpouse = locator(pwXPath("//div[@id='formField_licenseIssued']//mat-error[not(contains(@aria-hidden,'true'))]"));

    private static final String DIALOG_LICENSED_IN_USA_RADIO_BUTTONS_XPATH = "//div[contains(@id,'licenseIssued')]//mat-radio-button[contains(.,'%s')]";

    private String SPOUSE_DRIVING_VEHICLE_XPATH = "//div[@id='formField_licenseIssued']//mat-button-toggle-group//mat-button-toggle[contains(.,'%s')]";

        private Locator licenseIssuedErrorMessages = locator(pwXPath("//div[@id='formField_licenseIssued']//mat-error"));

        private Locator editDriverModalErrorMessage = locator(pwXPath("//p[contains(@class,'auto-add-driver__error-message')]"));

    private static final String DIALOG_SAVE_BUTTON_XPATH = "//div[contains(@class,'auto-add-driver-submit')]//button";
        private Locator listOfSaveButtons = locator(pwXPath(SECOND_DIALOG_XPATH + DIALOG_SAVE_BUTTON_XPATH + OR_OPERATOR + DIALOG_SAVE_BUTTON_XPATH));

        private Locator changeStatusHeading = locator(pwId("changeStatusHeading"));

        private Locator changeStatusContent = locator(pwId("changeStatusContent"));

    private static final String REMOVE_STATUS_XPATH = "//button[@class='tui-btn tui-btn-primary tui-button-text action-button']";

        private Locator maritalCheckboxSubtexts = locator(pwXPath("//div[@class='auto-driver-review-question-married']//p"));

        private Locator removeStatusButton = locator(pwXPath(REMOVE_STATUS_XPATH));

        private Locator keepAsIsButton = locator(pwCss("button[class='tui-btn tui-btn-secondary tui-button-text']"));

        private Locator accidentCheckboxes = locator(pwXPath("//div[contains(@id,'hadAccidentOrViolation')]//mat-checkbox//input[contains(@aria-label,'Had an accident')]"));

        private Locator accidentQuestions = locator(pwXPath("//div[contains(@id,'ordered-field-placeholder_hadAccidentOrViolation')]//label[@class='mdc-label']"));

        private Locator employedCheckboxes = locator(pwXPath("//mat-checkbox[@formcontrolname='isEmployed']//input"));

        private Locator occupationInputField = locator(pwXPath("//occupation-typeahead//input"));

        private Locator occupationInputFieldLabel = locator(pwXPath("//occupation-typeahead//mat-label"));

        private Locator occupationInputFieldHint = locator(pwXPath("//occupation-typeahead//mat-hint"));

        private Locator employmentDiscountQualification = locator(pwXPath("//div[contains(@class,'auto-occupation-selected-message')]"));

        private Locator employmentDiscountNotEligible = locator(pwCss("div[class='auto-occupation-not-found-message tui-body-text-1 ng-star-inserted']"));

        private Locator minAgeSection = locator(pwCss("div[class='auto-driver-review-question-min-age-section']"));

        private Locator accidentSubTexts = locator(pwXPath("//*[contains(@id,'ordered-field-placeholder_hadAccidentOrViolation')]//p"));

        private Locator bundleCheckbox = locator(pwXPath("//div[@class='col auto-driver-discount-save-bundle-checkbox ng-star-inserted']//input"));

        private Locator bundleCheckboxLabel = locator(pwXPath("//mat-checkbox[@attr.aria-label=\"Farmers Bundle and Save Discount\"]//span[@class='mat-checkbox-label']"));

        private Locator ctaErrorMessage = locator(pwXPath("//div[contains(@class,'auto-driver-review-cta-validation-text-holder')]//span"));

        private Locator continueButton = locator(pwId("auto-driver-review-cta-continue"));

        private Locator ctaDescription = locator(pwXPath("//div[contains(@class,'auto-driver-review-cta-button-container')]//div"));

        private Locator addAdditionalFarmersProductsLink = locator(pwXPath("//a[contains(@class, 'auto-drivers-review__save-bundle-link')]"));

        private Locator bundleCardHeader = locator(pwCss("p[class='tui-body-text-bold auto-driver-review-save-bundle-text']"));

        private Locator bundleCardContent = locator(pwXPath("//div[contains(@class,'auto-driver-review-save-bundle-content')]/p[2]"));

        private Locator bundleLink = locator(pwCss("a[class='auto-drivers-review__save-bundle-link tui-anchor']"));

        private Locator bundleLinkText = locator(pwCss("a[class='auto-drivers-review__save-bundle-link tui-anchor']"));

        private Locator bundleInfoIcon = locator(pwCss("div[class='auto-driver-review-save-bundle-info-icon']>mat-icon"));

        private Locator bundleInfoHeader = locator(pwCss("div[class='auto-driver-review-save-bundle-info-header-content']>h5"));

        private Locator bundleInfoContent = locator(pwCss("div[class='auto-driver-review-save-bundle-info-header-content']>p"));

        private Locator bundleModalHeader = locator(pwXPath("//div[@class='auto-driver-review-save-bundle-side-sheet-title']//h4"));

        private Locator bundleCancelLink = locator(pwCss("div[class='auto-driver-review-cancel-button']>button"));

        private Locator saveBundleItems = locator(pwXPath("//div[contains(@class,'auto-driver-review-save-bundle-items')]//span[@class='mat-checkbox-label']"));

        private Locator bundleCheckboxes = locator(pwXPath("//div[contains(@class,'auto-driver-review-save-bundle-items')]//mat-checkbox"));

        private Locator saveBundleErrorMessage = locator(pwXPath("//span[contains(text(),'Please select a product to be eligible for discount.')]"));

        private Locator saveAndBundleAddButton = locator(pwCss("button[class='tui-btn tui-btn-primary auto-save-bundle-sheet-add-button']"));

        private Locator saveBundleSelectedItem = locator(pwCss("span[class='auto-driver-discount-save-bundle-selected-item']"));

        private Locator removeBundleHeader = locator(pwXPath("//app-remove-bundle//h5"));

        private Locator removeBundleContent = locator(pwId("remove-bundle-content"));

        private Locator removeBundleKeepItButton = locator(pwXPath("//button[contains(@class,'tui-btn tui-btn-link tui-button-text')]"));

        private Locator removeBundleButton = locator(pwCss("div[class='col remove-action-button']"));

        private Locator addEditAdditionalPolicies = locator(pwCss("div[class='col auto-driver-discount-save-bundle-add-edit-link']"));

        private Locator bundleCongratsMessage = locator(pwCss("p[class='auto-driver-review-save-bundle-congratulations-message']"));

        private Locator bundleDialogueCloseIcon = locator(pwXPath("//app-save-bundle-sheet//mat-icon"));

        private Locator studentDiscountCheckboxLabels = locator(pwXPath("//div[contains(@class,'auto-driver-discount-full-time')]//div[contains(@class,'auto-driver-review-student-container')]"));

    private final String OCCUPATION_SIDE_PANEL_HEADER_XPATH = "//app-occupation-list//h1";
        private Locator eligibleOccupationModalHeader = locator(pwXPath(OCCUPATION_SIDE_PANEL_HEADER_XPATH));
        private Locator employedOrRetiredTitle = locator(pwXPath("//div[contains(@class,'row occupation-retired-checkbox')]//p"));

        private Locator selectEligibleOccupationsTitle = locator(pwXPath("//p[contains(.,'Select from the list of eligible occupation(s). Verification of occupation will be required.')]"));

    private final String DISCOUNT_UNAVAILABLE_MESSAGE_XPATH = "//div[contains(@class,'discount-unavailable')]//p";
        private Locator discountUnavailableMessage = locator(pwXPath(DISCOUNT_UNAVAILABLE_MESSAGE_XPATH));

    private final String OCCUPATION_SIDE_PANEL_ERROR_MESSAGE_XPATH = "//div[contains(@class,'auto-occupation')]//mat-error";
        private Locator occupationSidePanelErrorMessage = locator(pwXPath(OCCUPATION_SIDE_PANEL_ERROR_MESSAGE_XPATH));

    private final String SEE_ELIGIBLE_OCCUPATIONS_XPATH = "//div[contains(@class,'auto-driver-discount-employed')]//button";

    final String occupationRadioButtonsXpath = "//div[@class='auto-occupation-list-container']//mat-radio-button";

        private Locator occupationsSidePanelToggles = locator(pwXPath("//div[contains(@class,'row occupation-retired-checkbox')]//mat-button-toggle"));

        private Locator employedToggle = locator(pwXPath("//mat-button-toggle[contains(.,'Employed')]"));

        private Locator retiredToggle = locator(pwXPath("//mat-button-toggle[contains(.,'Retired')]"));

        private Locator discountUnavailable = locator(pwXPath("//div[contains(@class,'discount-unavailable')]"));

        private Locator occupationRadioButtons = locator(pwXPath(occupationRadioButtonsXpath));

    private final String OCCUPATION_ADDED_CONFIRMATION_XPATH = "//div[contains(@class,'auto-drivers-review-occupation-added tui-body-text')]";
        private Locator occupationAddedConfirmation = locator(pwXPath(OCCUPATION_ADDED_CONFIRMATION_XPATH));

        private Locator removeOccupationButton = locatorAny(pwPartialLinkText("Remove occupation"), pwXPath("//a[@class='auto-drivers-review-occupation-remove tui-link-footer offset-1 text-decoration-none']"));
        private Locator removeOccupationPanelHeader = locator(pwXPath("//h1[contains(@class,'remove-occupation-title')]"));

        private Locator keepOccupation = locator(pwXPath("//button[contains(@class,'keep-it-action-button')]"));

        private Locator removeButton = locator(pwXPath("//div[contains(@class,'remove-action-button')]//button"));


    public String seeEligibleOccupationList = pwXPath(SEE_ELIGIBLE_OCCUPATIONS_XPATH);

    private static final String ADD_BUTTON_XPATH = "button[class='tui-btn tui-btn-primary tui-button-text action-button']";
        private Locator addButton = locator(pwCss(ADD_BUTTON_XPATH));

    private final String OCCUPATION_SECTION_XPATH = "//div[contains(@class,'occupation-ab-section-card') or contains(@class,'auto-driver-review-occupation-heading')]";

        Locator occupationHeaders = locatorAny(pwXPath("//div[contains(@class,'occupation-ab-section-card') or contains(@class,'auto-driver-review-occupation-heading')]//p"), pwId("occupationLabel"));

        Locator occupationSubtexts = locatorAny(pwXPath("//div[contains(@class,'occupation-ab-section-card') or contains(@class,'auto-driver-review-occupation-heading')]//p[2]"), pwId("occupationDesc"));

        private Locator driverLicenseNumberInfoBoxHeaderBrowser = locator(pwXPath("//div[contains(@class,'license-info')]//p[@class='tui-info-box-header tui-field-label-text']"));

        private Locator driverLicenseNumberInfoBoxTextBrowser = locator(pwXPath("//div[contains(@class,'license-info')]//p[@class='tui-info-box-content']"));

        private Locator driverLicenseNumberInfoBoxMobileIcon = locator(pwXPath("//mat-icon[@data-tui-tracking-id='auto-drivers-review__driver-license']"));

        private Locator driverLicenseNumberInfoBoxHeaderMobile = locator(pwXPath("//mat-icon[@data-tui-tracking-id='auto-drivers-review__driver-license']"));

        private Locator driverLicenseAgeInfoHeaderBrowser = locator(pwXPath("//div[contains(@class,'auto-driver-review-age-licensed')]//div[@class='auto-driver-review-info-header-content']//p[1]"));

        private Locator driverLicenseInfoInfoHeaderBrowser = locator(pwXPath("//div[contains(@class,'licensing-Info')]//p[@class='tui-info-box-header tui-field-label-text']"));

        private Locator driverLicenseAtWhatAgeBrowser = locator(pwXPath("//div[contains(@class,'auto-driver-review-age-licensed')]//div[@class='auto-driver-review-info-header-content']//p[2]"));

        private Locator driverLicenseGapBrowser = locator(pwXPath("//div[contains(@class,'auto-driver-review-age-licensed')]//div[@class='auto-driver-review-info-header-content']//p[3]"));

        private Locator licensingInfoHelpContent = locator(pwXPath("//div[contains(@class,'licensing-Info')]//p[@class='tui-info-box-content']"));

        private Locator driverLicenseAgeMobileHelpIcon = locator(pwXPath("//mat-icon[contains(@class,'mat-icon notranslate auto-driver-review-age-licensed-info tui-info-box-icon mobile-info-icon')]"));

        private Locator driverLicensingInfoMobileHelpIcon = locator(pwXPath("//mat-icon[@data-tui-tracking-id='auto-drivers-review__licensing-info']"));

    private final String DRIVER_LICENSE_NUMBER_INPUT_ERROR_XPATH = "//div[@class='auto-driver-license-state-fields']//mat-error";
        private Locator driverLicenseNumberInputError = locator(pwXPath(DRIVER_LICENSE_NUMBER_INPUT_ERROR_XPATH));

        private Locator driverLicenseAgeError = locator(pwXPath("//mat-error[contains(@class,'age-license-eror') and not(@hidden)]"));

    public static final String GPA_OVER_3_CHECKBOX_XPATH = "//div[normalize-space(text())='Has a GPA over 3.0']";
        private Locator lblGPAOver30 = locator(pwXPath(GPA_OVER_3_CHECKBOX_XPATH));
    public static final String GPA_OVER_3_INPUT_XPATH = "//div[normalize-space(text())='Has a GPA over 3.0']//input";
        private Locator chkGPAOver30 = locator(pwXPath(GPA_OVER_3_INPUT_XPATH));

    public static final String DISTANT_STUDENT_CHECKBOX_INPUT_XPATH = "//div[normalize-space(text())='Attends school more than 100 miles away from home without custody of a car']//input";

        private Locator chkAttendsSchoolMoreThan300Miles = locator(pwXPath(DISTANT_STUDENT_CHECKBOX_INPUT_XPATH));

    private final String MUST_BE_A_FULL_TIME_STUDENT_LABEL_XPATH = "//p[normalize-space(text())='Must be a full-time student']";
        private Locator lblMustBeAFullTimeStudent = locator(pwXPath(MUST_BE_A_FULL_TIME_STUDENT_LABEL_XPATH));

    private final String MUST_BE_A_FULL_TIME_STUDENT_AND_LICENSED_LESS_THAN_10_YEARS_XPATH = "//p[normalize-space(text())='Must be a full-time student and licensed for less than 10 years']";

        private Locator lblMustBeAFullTimeStudentAndLicensedForLessThan10Yrs = locator(pwXPath(MUST_BE_A_FULL_TIME_STUDENT_AND_LICENSED_LESS_THAN_10_YEARS_XPATH));

    private final String DISTANT_STUDENT_XPATH = "//div[normalize-space(text())='Attends school more than 100 miles away from home without custody of a car']";
        private Locator lblAttendsSchoolMoreThan100Miles = locator(pwXPath(DISTANT_STUDENT_XPATH));

        private Locator lblSharesVehicleUsage = locator(pwXPath("//div[normalize-space(text())='Shares vehicle usage in household']"));

    private final String DISTANT_STUDENT_SUBTEXT_XPATH = "//div[contains(@id,'fullTimeAwayatSchool')]//p";
        private Locator lblMustBeAFullTimeStudentAndChildOfPNI = locator(pwXPath(DISTANT_STUDENT_SUBTEXT_XPATH));

        private Locator chkSharesVehicleUsage = locator(pwXPath("//div[normalize-space(text())='Shares vehicle usage in household']//input"));

        Locator noOccupationToggleOptions = locator(pwXPath("//mat-button-toggle-group[contains(@class,'occupation-affinity-toggle')]//button[@aria-label='No']"));

    private final String SPECIAL_DEFENSIVE_DRIVER_SUBHEADER_TEXT = "Special defensive driver course designed for drivers over 55 years old";
    private final String KS_DEFENSIVE_DRIVER_COURSE_SUBHEADER_TEXT = "Completed an approved driving safety or defensive driving course";
    private final String CT_DEFENSIVE_DRIVER_SUBHEADER_TEXT = "Special defensive driver course designed for drivers over 60 years old";
    private final String MA_DEFENSIVE_DRIVER_SUBHEADER_TEXT = "Special defensive driver course designed for drivers over 65 years old";

    private final String SAFETY_COURSE_CHECKBOX_XPATH = "//mat-checkbox[@formcontrolname='safetyCourseCompleted']";

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public DriverReviewPage() throws Exception {
    }

    public boolean isOnDriverReviewPage() throws Exception {
        scrollToTopOfPage();
        return isElementVisible(driverReviewPageHeader, 30);
    }

    public boolean isOnDriverReviewPageQuickCheck() throws Exception {
        scrollToTopOfPage();
        return isElementVisible(driverReviewPageHeader, 3);
    }

    public void reviewAllDrivers(AutoApplicant applicant, Optional<FarmersSoftAssert> fsa) throws Exception {
        reviewApplicant(applicant, fsa);
        if (!applicant.getAdditionalDrivers().isEmpty() || getSessionStorageAppStore().getAuto().getDrivers().size() > 1) {
            reviewAdditionalDriver(applicant, fsa);
        }
        if (applicant.getIncidents().isEmpty() && !applicant.isHaveAccidentOrViolations() && fsa.isPresent() && !isBDQFlowEnabled()) {
            waitForUiSettled();
            fsa.get().assertTrue(isDiscountPresentInTheSideSheet("Accident free"), "Additional Discounts should include 'Accident free'");
        }
        if (applicant.getTestScenario().contains("UMB")) {
            waitForUiSettled();
            Log.info("Capture driver details" + NEWLINE, applicant.getTestScenario() + "Driver Details");
        }
        // enter driver license age for CA
        if (applicant.getStateCode().equals(CA)) {
            List<String> displayedDrivers = getDisplayedDrivers();
            for (String displayedDriver : displayedDrivers) {
                enterDriverLicenseAge_CA(displayedDriver, 16);
                if(!getApplicantFullName(applicant).equals(displayedDriver)){
                    addEmployment(displayedDriver, applicant.getOccupation());
                }
            }
        }

        // handle not provided age fields
        List<Locator> notHandledAgeFields = locators(pwXPath("//input[@formcontrolname='ageFirstLicensed' and contains(@class,'invalid')]"));
    	int numberOfElements = notHandledAgeFields.size();
        for (int i = 0; i< numberOfElements; i++){
            Locator licenseAgeInputField = notHandledAgeFields.get(i);
            scrollElementToMiddle(licenseAgeInputField);
            waitAndClickElement(licenseAgeInputField);
            sendKeysToElement(licenseAgeInputField, "15");
            sendKeysToElement(licenseAgeInputField, Keys.TAB);
            wait.until(Conditions.attributeContains(licenseAgeInputField, CLASS, NG_VALID));

        }

        // handle not provided dl fields
        List<Locator> notHandledDlInputFields = locators(pwXPath("//input[@formcontrolname='licenseNumber' and contains(@class,'invalid')]"));
    	numberOfElements = notHandledDlInputFields.size();
        for (int i = 0; i< numberOfElements; i++){
            Locator dlInputField = notHandledDlInputFields.get(i);
            scrollElementToMiddle(dlInputField);
            waitAndClickElement(dlInputField);
            String licenseNumber = LicenseFormatByState.getLicenseNumberByState(applicant.getStateCode());
            sendKeysToElement(dlInputField, licenseNumber);
            sendKeysToElement(dlInputField, Keys.TAB);
            waitForSpinnerToBeGone();
            wait.until(Conditions.attributeContains(dlInputField, CLASS, NG_VALID));
        }
    }

    public void fillOutOccupationAffinitySection() {
        for (Locator noOccupationToggleOption : noOccupationToggleOptions.all()) {
            scrollAndClickOnElement(noOccupationToggleOption);
        }
    }

    public void validateBDQSpecificRequirements(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {
        fsa.assertTrue(isOnDriverReviewPage(), "User on the driver review page");

        // validate bw logo present
        fsa.assertTrue(isOnBristolWest() && !isOnFarmers(), "Bristol west logo present");

        // validate Occupation section is not visible for PNI
        AppStore.Data.CustomerData customerData = getSessionStorageAppStore().getData().getCustomerData();
        String pniFullName = customerData.getFirstName() + SPACE + customerData.getLastName();
        String eligibileOccupationLink = getDriverCardXpathByFullName(pniFullName) + SEE_ELIGIBLE_OCCUPATIONS_XPATH;
        fsa.assertTrue(!isElementPresent(pwXPath(eligibileOccupationLink), 1), "'See eligible occupation' link should not be present in bdq flow");
        validateValidateAndFooterForBDQ(fsa, applicant, this);
        fsa.assertTrue(!isDiscountSectionDisplayed(), "Discount section should not be displayed on " + this.getClass().getSimpleName());
        validateAgentSectionBDQ(fsa, applicant);
    }

    private void reviewApplicant(AutoApplicant applicant, Optional<FarmersSoftAssert> fsaOptional) throws Exception {
        FarmersSoftAssert fsa = null;
        String stateCode = applicant.getStateCode();
        if (fsaOptional.isPresent()) {
            fsa = fsaOptional.get();
        }
        boolean operationResult = false;
        String pniFullName = getApplicantFullName(applicant);
        // add marital status for pni
        if (applicant.getMaritalStatus().equals(MARRIED)) {
            scrollToElement(driverReviewPageHeader);
            String sniFullName = getSniFullName(applicant);
            operationResult = setMaritalRelationship(pniFullName, sniFullName);
            if (fsaOptional.isPresent()) {
                fsa.assertTrue(operationResult, "Marital Relation Set up");
            }
        }
        int age = applicant.getAge();

        // enter drivers license number if applicable
        addDriverLicenseNumber(applicant, pniFullName);

        // driver license age
        if (isAskingDriverLicenseAgeState(applicant.getStateCode())) {
            enterDriverLicenseAge(applicant, pniFullName, applicant.getFirstAgeUnitedStatesDriverLicense());
        } else if (age <= MAX_YOUNG_AGE && (age - applicant.getFirstAgeUnitedStatesDriverLicense() < 3)) {
            operationResult = addHadDriversLicense(pniFullName, applicant.getFirstAgeUnitedStatesDriverLicense());
            if (fsaOptional.isPresent()) {
                fsa.assertTrue(operationResult, "Driver License Age Validation");
            }
        }
        // add financial filing
        String financialFiling = applicant.getFinancialFiling();
        if (financialFiling.contains(SR_22)) {
        	operationResult = addFinancialFiling(applicant, pniFullName);
            if (fsaOptional.isPresent()) {
                fsa.assertTrue(operationResult, "Financial Filing Addition");
            }
        }
        // add accident or violation
        if (applicant.isHaveAccidentOrViolations() || !applicant.getIncidents().isEmpty()) {
            List<SqlIncident> applicantIncidents = applicant.getIncidents().stream().filter(incident -> incident.getAdditionalDriverId() == 0).collect(Collectors.toList());
            updateIncidentsWithSessionStorageData(applicantIncidents);
            operationResult = addIncidents(pniFullName, applicantIncidents);
            if (fsaOptional.isPresent()) {
                fsa.assertTrue(operationResult, "Incident Addition Addition");
            }
        }

        // add safety course
        if (isSafetyCourseExpected(applicant, age) && applicant.isCompletedDriversSafetyCourse()) {
            operationResult = addSafetyCourse(pniFullName);
            if (fsaOptional.isPresent()) {
                fsa.assertTrue(operationResult, "Safety course Addition");
                waitForUiSettled();
                String expectedDiscountName = isDefensiveDriverDiscountEnabledOnDriverReview(stateCode) ? DEFENSIVE_DRIVER.getName() : MATURE_DRIVER.getName();
                fsa.assertTrue(isDiscountPresentInTheSideSheet(expectedDiscountName), expectedDiscountName + " listed in Additional Discounts");
            }
        }

        //On active military duty is only applicable for PNI
        if (stateCode.equals(LA)) {
            Locator activeMilitaryElement = locator(pwXPath(getDriverCardXpathByFullName(pniFullName) + ACTIVE_MILITARY_RADIO_BUTTON_XPATH));
            addActiveMilitaryDuty(activeMilitaryElement);
        }
        // add employment
        if (!isMA61Environment() && !isEmploymentDisabledState(stateCode)) {
        	operationResult = addEmployment(getApplicantFullName(applicant), applicant.getOccupation());
            if (fsaOptional.isPresent()) {
                fsa.assertTrue(operationResult, "Employment Addition");
            }
        }

        // add Commutes to DC if applicable randomly
        boolean addCommuteToDC = RandomUtils.nextBoolean();
        if (addCommuteToDC) {
            addCommutesToDC(applicant, pniFullName);
        }

        //click on rideshare checkbox if applicable
        if (isElementDisplayed(pwXPath(IS_A_RIDE_SHARE_XPATH))) {
            clickIsRideShareDriverCheckbox(pniFullName);
            Log.info("Rideshare checkbox is clicked for PNI when rideshare veh is provided");
        }

        // add full time student discount if applicable
        addFullTimeStudent(Optional.empty(), applicant);


    }

    public void addDriverLicenseNumber(AutoApplicant applicant, String fullName) throws Exception {
        if (isAskingForDriverLicenseNumber(applicant)) {
            if(Arrays.asList(CA, MA).contains(applicant.getStateCode()) && applicant.getFirstAgeForeignDriverLicense() == 18) {
                return;
            }
            String stateCode = applicant.getStateCode();
            LicenseFormatByState.getLicenseNumberByState(stateCode);
            String driverLicenseNumber = LicenseFormatByState.getLicenseNumberByState(stateCode);
            scrollToElement(locator(pwXPath(getDriverCardXpathByFullName(fullName))));
            List<Locator> driversLicenseInputs = locators(pwXPath(getDriverCardXpathByFullName(fullName) + DRIVER_LICENSE_NUMBER_INPUT_XPATH));
            if(driversLicenseInputs.isEmpty()) {
                return;
            }
            Locator driversLicenseInput = driversLicenseInputs.get(0);
            scrollAndClickOnHiddenElement(driversLicenseInput);
            sendKeysToElement(driversLicenseInput, driverLicenseNumber);
            sendKeysToElement(driversLicenseInput, Keys.TAB);
            waitForSpinnerToBeGone();
//            wait.until(Conditions.attributeToBe(driversLicenseInput, ARIA_INVALID, LOWERCASE_FALSE));
        }
    }

    private boolean isAskingForDriverLicenseNumber(AutoApplicant applicant) {
        return Arrays.asList(MA).contains(applicant.getStateCode());
    }

    public void clickOccupationLink() throws Exception {
        waitAndClickElement(locators(seeEligibleOccupationList).get(0));
    }

    public boolean isAskingDriverLicenseAgeState(String applicantStateCode) {
        return Arrays.asList(CA, KY, LA, MA).contains(applicantStateCode);
    }

    public static boolean isEmploymentDisabledState(String stateCode) {
        return Arrays.asList(FL, KY, LA, MA, MS, NC).contains(stateCode);
    }

    private void addCommutesToDC(AutoApplicant applicant, String fullName) throws Exception {
        if (!applicant.getStateCode().equals(MD)) {
            return;
        }
        Locator commutesToDcCheckbox = locator(pwXPath(getDriverCardXpathByFullName(fullName) + COMMUTES_TO_DC_XPATH));
        waitAndClickElement(commutesToDcCheckbox);
    }

    private boolean isSafetyCourseExpected(AutoApplicant applicant, int age) {
        String stateCode = applicant.getStateCode();
        boolean isSafetyCourse = isBDQFlowEnabled() ? isSafetyCourseExpectedStateBDQ(applicant.getStateCode()) : isSafetyCourseExpectedState(stateCode);
        if (isBDQFlowEnabled()) {
            if ((age >= MIN_OLD_AGE_ONE_UI || List.of(NJ, KS).contains(stateCode)) && isSafetyCourse) {
                return true;
            } else {
                return false;
            }
        }

        return isSafetyCourseExpectedState(stateCode) && (age >= MIN_OLD_AGE_ONE_UI || List.of(NJ, KS).contains(stateCode));
    }

    public void reviewAdditionalDriver(AutoApplicant applicant, Optional<FarmersSoftAssert> fsaOptional) throws Exception {
        FarmersSoftAssert fsa = null;
        if (fsaOptional.isPresent()) {
            fsa = fsaOptional.get();
        }
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        int additionalDriversSize = java.lang.Math.min(MAX_NUMBER_OF_ADDITIONALDRIVERS, additionalDrivers.size());
        List<SqlIncident> incidents = applicant.getIncidents();
        int additionalDriverId = 1;
        boolean operationResult = false;
        for (int i = 0; i < additionalDriversSize; i++) {
            SqlAdditionalDriver currentDriver = additionalDrivers.get(i);
            String currentDriverFullName = getDriverFullName(currentDriver);
            // validate accident/violation
            int finalAdditionalDriverId = additionalDriverId;
            List<SqlIncident> currentDriverIncidents = incidents.stream().filter(incident -> incident.getAdditionalDriverId() == finalAdditionalDriverId).collect(Collectors.toList());
            additionalDriverId++;
            if (!currentDriverIncidents.isEmpty()) {
                updateIncidentsWithSessionStorageData(currentDriverIncidents);
                operationResult = addIncidents(currentDriverFullName, currentDriverIncidents);
                if (fsaOptional.isPresent()) {
                    fsa.assertTrue(operationResult, "Incidents added for additional driver " + (i+1));
                }
            }
            // add safety course
            String stateCode = applicant.getStateCode();
            if (currentDriver.isCompletedDriversSafetyCourse() && !stateCode.equals(NE) && ((currentDriver.getAge() >= MIN_OLD_AGE_ONE_UI) || stateCode.equals(KS))) {
                operationResult = addSafetyCourse(currentDriverFullName);
                if (fsaOptional.isPresent()) {
                    fsa.assertTrue(operationResult, "Safety course added for additional driver " + (i+1));
                }
            }
            // adding drivers license if applicable
            addDriverLicenseNumber(applicant, currentDriverFullName);

            //  add/validate Has had driver's license for less than 3 years
            if (isAskingDriverLicenseAgeState(applicant.getStateCode())) {
                enterDriverLicenseAge(applicant, currentDriverFullName, 16);
            } else if (currentDriver.getAge() <= MAX_YOUNG_AGE && currentDriver.getAge() - currentDriver.getFirstAgeUnitedStatesDriverLicense() < 3) {
            	operationResult = addHadDriversLicense(currentDriverFullName, applicant.getFirstAgeUnitedStatesDriverLicense());
                if (fsaOptional.isPresent()) {
                    fsa.assertTrue(operationResult, "Driver License Age added for additional driver " + (i+1));
                }
            }
            // add financial filing
            if (currentDriver.getFinancialFiling().contains(SR_22)) {
            	operationResult = addFinancialFiling(applicant, currentDriverFullName);
                if (fsaOptional.isPresent()) {
                    fsa.assertTrue(operationResult, "Financial filing added for additional driver " + (i+1));
                }
            }
            // add SNI occupation
            if (currentDriver.getRelationshipToApplicant().equals(SPOUSE) && !isEmploymentDisabledState(stateCode)) {
            	operationResult = addEmployment(getDriverFullName(currentDriver), currentDriver.getOccupation());
                if (fsaOptional.isPresent()) {
                    fsa.assertTrue(operationResult, "Employment added for additional driver " + (i+1));
                }
            }

            // add Commutes to DC if applicable randomly
            boolean addCommuteToDC = RandomUtils.nextBoolean();
            if (addCommuteToDC) {
                addCommutesToDC(applicant, currentDriverFullName);
            }
            // add full time student discount if applicable
            addFullTimeStudent(Optional.of(currentDriver), applicant);

        }
        List<String> additionalDriversFromData = applicant.getAdditionalDrivers().stream().map(each -> getDriverFullName(each)).collect(Collectors.toList());
        List<String> displayedDrivers = getDisplayedDrivers();
        List<String> notProcessedDrivers = displayedDrivers.stream()
                .filter(item -> !additionalDriversFromData.contains(item))
                .collect(Collectors.toList());

        for (String notProcessedDriver : notProcessedDrivers) {
            addDriverLicenseNumber(applicant, notProcessedDriver);
            enterDriverLicenseAge(applicant, notProcessedDriver, 15);
        }

    }

    private void addActiveMilitaryDuty(Locator activeMilitaryElement) {
        if (RandomUtils.nextBoolean() && RandomUtils.nextBoolean()) {
            // add randomly
            clickElement(activeMilitaryElement);
        }
    }

    public boolean validateDriversReviewPageTitle() {
        waitElementBeVisible(driverReviewPageHeader);
        final String expectedDriversReviewPageHeaderText = "Drivers";
        return testExpectedTextContentForElement(driverReviewPageHeader, expectedDriversReviewPageHeaderText);
    }

    public boolean validateDriversReviewPageDescription() {
        waitElementBeVisible(driverReviewPageDescription);
        final String expectedDriversReviewPageDescription = "Please make sure everyone in the household who will be driving is included.";
        return getTextFromElement(driverReviewPageDescription).replace(REVISE_WHICH_DRIVERS_TO_INCLUDE_LINK, "").trim().equals(expectedDriversReviewPageDescription);
    }

    public void validatePageHeaderAndDescription() {
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(validateDriversReviewPageTitle(), "Drivers Review Page Page Title");
        fsa.assertTrue(validateDriversReviewPageDescription(), "Drivers Review Page Description");
        fsa.assertAll();
    }

    public void validateDisplayedCheckboxes(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String stateCode = applicant.getStateCode();
        if (stateCode.equals(CA)) {
            // CA has a separate test case for this check
            return;
        }
        String expectedSafetyCourseSubtext = stateCode.equals(KS) ? KS_DEFENSIVE_DRIVER_COURSE_SUBHEADER_TEXT : SPECIAL_DEFENSIVE_DRIVER_SUBHEADER_TEXT;
        //validate safety course checkboxes for KS state, as it is different from previously added states
        if (stateCode.equals(KS)) {
            List<Locator> safetyCheckboxesSubTexts = getDriverSafetyCourseSubTextLocators();
            for (Locator safetyCheckboxesSubText : safetyCheckboxesSubTexts) {
                fsa.assertEquals(getTextFromElement(safetyCheckboxesSubText), expectedSafetyCourseSubtext, "Safety course subtext verification");
            }
        }
        // validate marital checkbox subtext
    	int numberOfElements = maritalCheckboxSubtexts.count();
        for (int i = 0; i< numberOfElements; i++) {
            fsa.assertEquals(getTextFromElement(maritalCheckboxSubtexts.nth(i)), "Check to add your spouse or partner (do not check if you are separated, widowed, or divorced)", "Marital subtext verification "+ (i+1));
        }

        int applicantAge = applicant.getAge();
        String applicantFullName = getApplicantFullName(applicant);
        List<String> expectedMiddleAgePniOrSniCheckboxes = DriverReviewPageCheckboxes.getMiddleAgePniOrSniCheckboxes(applicant.getStateName());
        Map<String, Integer> pniSni = new HashMap<>();
        pniSni.put(applicantFullName, applicantAge);
        boolean isMarried = applicant.getMaritalStatus().equals(MARRIED);
        if (isMarried) {
            SqlAdditionalDriver sni = getSni(applicant);
            String sniFullName = getSniFullName(applicant);
            int sniAge = sni.getAge();
            pniSni.put(sniFullName, sniAge);
            setMaritalRelationship(applicantFullName, sniFullName);
        }
        int count = 0;
        for (String s : pniSni.keySet()) {
            int age = pniSni.get(s);
            List<String> actualCheckboxes = getCheckboxesTextsForGivenDriver(s);
            boolean isActiveMilitaryExpected = s.equals(applicantFullName) && stateCode.equals(LA);
            final String activeMilitaryDuty = "On active military duty";
			if (age > MAX_YOUNG_AGE && age < MIN_OLD_AGE_ONE_UI && !stateCode.equals(KS)) {
                if (isActiveMilitaryExpected) {
                    expectedMiddleAgePniOrSniCheckboxes.add(activeMilitaryDuty);
                } else {
                    expectedMiddleAgePniOrSniCheckboxes.remove(activeMilitaryDuty);
                }
                fsa.assertEquals(actualCheckboxes, expectedMiddleAgePniOrSniCheckboxes, "expectedMiddleAgePniOrSniCheckboxes verification");
            }
            if (isSafetyCourseExpected(applicant, age) && !stateCode.equals(KS)) {
                List<String> expectedValues = DriverReviewPageCheckboxes.getOldAgePniOrSniCheckboxes(applicant.getStateName());
                if (isActiveMilitaryExpected) {
                    expectedValues.add(activeMilitaryDuty);
                } else {
                    expectedValues.remove(activeMilitaryDuty);
                }
                fsa.assertEquals(actualCheckboxes, expectedValues, "Displayed checkboxes verification");
                String safetyCourseXpath = getDriverCardXpathByFullName(s) + SAFETY_COURSE_SUBTEXT_XPATH_END;
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(locator(pwXPath(safetyCourseXpath)))), expectedSafetyCourseSubtext, "Expected safety course subtext for " + s);
            }
            if (age <= MAX_YOUNG_AGE) {
                List<String> youngAgePniOrSniCheckboxes = DriverReviewPageCheckboxes.getYoungAgePniOrSniCheckboxes(applicant.getStateName());
                if (isActiveMilitaryExpected) {
                    youngAgePniOrSniCheckboxes.add(activeMilitaryDuty);
                } else {
                    youngAgePniOrSniCheckboxes.remove(activeMilitaryDuty);
                }
                if (isCheckboxChecked(getMaritalCheckbox(getApplicantFullName(applicant))) && count == 0) {
                    youngAgePniOrSniCheckboxes.remove(DriverReviewPageCheckboxes.STUDENT.getCheckBoxText());
                }
                fsa.assertEquals(actualCheckboxes, youngAgePniOrSniCheckboxes, "youngAgePniOrSniCheckboxes verification");
            }
            if (isMarried && count == 1) {
                removeMaritalRelation(getMaritalCheckbox(applicantFullName));
            }
            count++;
            validateCheckboxesForGivenDriver(applicant, s);
        }
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        int additionalDriversSize = Math.min(MAX_NUMBER_OF_ADDITIONALDRIVERS, additionalDrivers.size());
        for (int i = 0; i < additionalDriversSize; i++) {
            SqlAdditionalDriver currentDriver = additionalDrivers.get(i);
            if (currentDriver.getMaritalStatus().equals(MARRIED)) {
                continue;
            }
            String currentDriverName = getDriverFullName(currentDriver);
            String safetyCourseXpath = getDriverCardXpathByFullName(currentDriverName) + SAFETY_COURSE_SUBTEXT_XPATH_END;

            int driverAge = currentDriver.getAge();
            List<String> checkboxes = getCheckboxesTextsForGivenDriver(currentDriverName);
            validateCheckboxesForGivenDriver(applicant, currentDriverName);
            if (driverAge <= MAX_YOUNG_AGE && !currentDriver.getMaritalStatus().equals(MARRIED)) {
                boolean isPniOrSniOver30 = (applicant.getAge() >= MIN_DISTANT_STUDENT_PARENT_AGE) || (isMarried && getSni(applicant).getAge() >= MIN_DISTANT_STUDENT_PARENT_AGE);
                List<String> expectedStudentCheckboxes = DriverReviewPageCheckboxes.getStudentAdditionalDriverCheckboxes(applicant.getStateName());
                fsa.assertEquals(checkboxes, expectedStudentCheckboxes, "expectedStudentCheckboxes verification");
                waitAndClickElement(getFullTimeStudentCheckbox(currentDriverName));
                waitElementBeVisible(studentDiscountCheckboxLabels.nth(0));
                List<String> actualStudentDiscountCheckboxes = studentDiscountCheckboxLabels.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
                List<String> expectedStudentDiscountCheckboxes = DriverReviewPageCheckboxes.getStudentDiscountCheckboxes(applicant, isPniOrSniOver30);
                fsa.assertEquals(actualStudentDiscountCheckboxes, expectedStudentDiscountCheckboxes, "expectedStudentDiscountCheckboxes verification");
            } else if (driverAge >= MIN_OLD_AGE_ONE_UI) {
                List<String> expectedOldAgeAdditionalDriverCheckboxes = DriverReviewPageCheckboxes.getOldAgeAdditionalDriverCheckboxes(applicant.getStateName());
                if (!isSafetyCourseExpected(applicant, driverAge)) {
                    expectedOldAgeAdditionalDriverCheckboxes.remove(DriverReviewPageCheckboxes.SAFETY_COURSE.getCheckBoxText());
                } else {
                    if (!stateCode.equals(LA)) {
                        fsa.assertEquals(getTextFromElement(waitElementBeVisible(locator(pwXPath(safetyCourseXpath)))), expectedSafetyCourseSubtext, "Safety course subtext for " + currentDriverName);
                    }
                }
                fsa.assertEquals(checkboxes, expectedOldAgeAdditionalDriverCheckboxes, "xpectedOldAgeAdditionalDriverCheckboxes verification ");
            } else if (driverAge > MAX_YOUNG_AGE && driverAge < MIN_OLD_AGE_ONE_UI) {
                List<String> expectedMiddleAgeAdditionalDriverCheckboxes = DriverReviewPageCheckboxes.getMiddleAgeAdditionalDriverCheckboxes(applicant.getStateName());
                fsa.assertEquals(checkboxes, expectedMiddleAgeAdditionalDriverCheckboxes, "expectedMiddleAgeAdditionalDriverCheckboxes verification");

            } else {
                List<String> expectedYoungAgeAdditionalDriverCheckboxes = DriverReviewPageCheckboxes.getYoungAgeAdditionalDriverCheckboxes(applicant.getStateName());
                fsa.assertEquals(checkboxes, expectedYoungAgeAdditionalDriverCheckboxes, "expectedYoungAgeAdditionalDriverCheckboxes verification");
            }
        }

    }

    public void validateSaveAndBundleModal(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {

        fsa.assertTrue(validateSaveBundleCard(), "Save Bundle Card validation");
        fsa.assertTrue(validateSaveBundleInfoIcon(), "Save Bundle Info Icon validation");

        scrollAndClickOnElement(bundleLink);
        //validate bundle modal header
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleModalHeader)), "Bundle and Save", "bundleModalHeader verification");
        waitForUiSettled();
        String selectedBundleItem = isHomeowner(applicant) ? "Home" : "Renters";
        Locator bundleItem = locator(pwXPath(String.format("//mat-checkbox[contains(.,'%s')]//input", selectedBundleItem)));
        scrollAndClickOnElement(bundleItem);
        fsa.assertTrue(isCheckboxChecked(bundleItem), "Bundle save checkbox selection");

        fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleCongratsMessage)), "Nice! You are eligible for a discount when you bundle", "bundleCongratsMessage verification");

        scrollAndClickOnElement(waitElementBeVisible(saveAndBundleAddButton));
        fsa.assertTrue(isDiscountPresentInTheSideSheet("Bundled savings"), "Additional Discounts should contain 'Bundled savings'");

        final String EXPECTED_BUNDLE_TEXT = "Farmers bundle and save discount";
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleCheckboxLabel)), EXPECTED_BUNDLE_TEXT, "bundleCheckboxLabel verification");
        fsa.assertEquals(getTextFromElement(saveBundleSelectedItem), selectedBundleItem, "Selected Save Bundle Item");

        waitAndClickElement(addEditAdditionalPolicies);
        waitAndClickElement(bundleDialogueCloseIcon);
        fsa.assertTrue(validateRemoveBundle(), "Validate remove Bundle failed");
        List<String> expectedBundleItems = FfqBundleOptions.getBundleOptions(applicant, isHomeowner(applicant));
        scrollAndClickOnElement(bundleLink);
        waitForUiSettled();
        scrollAndClickOnElement(saveAndBundleAddButton);
        waitForUiSettled();
        //validate bundle modal error message
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(saveBundleErrorMessage)), "Please select a product to be eligible for discount.", "saveBundleErrorMessage verification");
        //validate save bundle Cancel and Add buttons texts
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(saveAndBundleAddButton)), "Add", "saveAndBundleAddButton verification");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(bundleCancelLink)), "Cancel", "bundleCancelLink verification");
        List<String> actualBundleItemsBeforeRefreshed = saveBundleItems.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        // validate bundle checkboxes texts are expected
        if (!Property.getBrowser().equals("safari")) {
            fsa.assertEquals(actualBundleItemsBeforeRefreshed, expectedBundleItems, "Validate bundle checkboxes texts");
        }
        fsa.assertTrue(bundleCancelLink.isEnabled(), "Bundle Dialog cancel link enabled");
        scrollAndClickOnElement(waitElementBeVisible(bundleDialogueCloseIcon));
    }

    private boolean validateRemoveBundle() {
        boolean validated = true;
        final String REMOVE_BUNDLE_HEADER = "Remove bundle?";
        final String REMOVE_BUNDLE_CONTENT = "Are you sure you want to remove the Farmers Bundle and Save Discounts.";
        final String KEEP_IT = "Keep it";
        final String REMOVE_BUNDLE = "Remove bundle";
        waitAndClickElement(bundleCheckbox);
        validated &= testExpectedTextContentForElement(waitElementBeVisible(removeBundleHeader), REMOVE_BUNDLE_HEADER);
        validated &= testExpectedTextContentForElement(waitElementBeVisible(removeBundleContent), REMOVE_BUNDLE_CONTENT);
        validated &= testExpectedTextContentForElement(waitElementBeVisible(removeBundleKeepItButton), KEEP_IT);
        validated &= testExpectedTextContentForElement(waitElementBeVisible(removeBundleButton), REMOVE_BUNDLE);
        waitAndClickElement(removeBundleKeepItButton);
        removeSaveBundle();
        return validated;
    }

    public void removeSaveBundle() {
        waitAndClickElement(bundleCheckbox);
        waitAndClickElement(removeBundleButton);
    }

    private boolean validateSaveBundleCard() {

        boolean validated = true;
        final String EXPECTED_HEADER = "Save more when you bundle";
        final String EXPECTED_CONTENT = "Save money by bundling your Farmers Auto policy with another qualifying Farmers product.";
        final String EXPECTED_LINK_TEXT = "+ Add additional Farmers products (optional)";

        validated &= testExpectedTextContentForElement(bundleCardHeader, EXPECTED_HEADER);
        validated &= testExpectedTextContentForElement(bundleCardContent, EXPECTED_CONTENT);
        validated &= testExpectedTextContentForElement(bundleLinkText, EXPECTED_LINK_TEXT);
        return validated;
    }

    private boolean validateSaveBundleInfoIcon() {

        boolean validated = true;
        final String EXPECTED_HEADER = "How it works";
        final String EXPECTED_CONTENT = "A bundle discount will be applied to your auto quote today. You will have 45 days to purchase the policies you select to retain the discount. A Farmers agent will reach out to you to help you through the process.";
        validated &= testExpectedTextContentForElement(bundleInfoHeader, EXPECTED_HEADER);
        validated &= testExpectedTextContentForElement(bundleInfoContent, EXPECTED_CONTENT);
        return validated;
    }

    public boolean validateGoingBackToADPFScreen() throws Exception {
        boolean validationResult = true;
        waitElementBeVisible(driversRevisionHyperlink);
        validationResult &= getTextFromElement(driversRevisionHyperlink).contains(REVISE_WHICH_DRIVERS_TO_INCLUDE_LINK);
        waitAndClickElement(driversRevisionHyperlink);
        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        validationResult &= whoShouldWeInsurePage.isOnWhoShouldWeInsurePage() || new HeresWhatWeFoundPage().isOnHeresWhatWeFoundPage();
        return validationResult;
    }

    public void validateDriversAges(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        isOnDriverReviewPage();

        String applicantFullName = getApplicantFullName(applicant);

        int applicantAge = applicant.getAge();
        Locator ageLocator = waitElementBeVisible(locator(pwXPath(getDriverCardXpathByFullName(applicantFullName) + DRIVER_AGE_XPATH_END)));
        fsa.assertEquals(getTextFromElement(ageLocator), "Age " + applicantAge, "Applicant age element verification");
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        int additionalDriversSize = Math.min(additionalDrivers.size(), MAX_NUMBER_OF_ADDITIONALDRIVERS);
        for (int i = 0; i < additionalDriversSize; i++) {
            SqlAdditionalDriver currentDriver = additionalDrivers.get(i);
            String driverFullName = getDriverFullName(currentDriver);
            int driverAge = currentDriver.getAge();
            Locator driverAgeElement = waitElementBeVisible(locator(pwXPath(getDriverCardXpathByFullName(driverFullName) + DRIVER_AGE_XPATH_END)));
            fsa.assertEquals(getTextFromElement(driverAgeElement), "Age " + driverAge, "Additional driver age element verification");
        }
    }

    public void validateInfoBoxes(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String additionalDriverContent = "Drivers have the same coverage, but limited access to your insurance account. They can get ID cards, pay bills and get insurance documents. But they cannot make any changes to your coverage.";
        String additionalDriverHeader = "Additional driver(s)";
        String pniContent = "The applicant and main point of contact for the insurance policy. They will be responsible for signing all documents upon purchase.";
        String pniHeader = "Primary named insured";
        String sniContent = "The spouse or domestic partner of the applicant will be added as a \"secondary named insured\" and will have the same rights to sign documents and make changes to the policy.";
        String sniHeader = "Secondary named insured";
        String pniFullName = getApplicantFullName(applicant);
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        int additionalDriversSize = Math.min(MAX_NUMBER_OF_ADDITIONALDRIVERS, additionalDrivers.size());
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(pniInfoIcon);
            validateInfoDialogMobileView(pniHeader, pniContent, fsa);
            if (!additionalDrivers.isEmpty()) {
                for (int i = 0; i < additionalDriversSize; i++) {
                    SqlAdditionalDriver additionalDriver = additionalDrivers.get(i);
                    String additionalDriverFullName = getDriverFullName(additionalDriver);
                    if (additionalDriver.getMaritalStatus().equals(MARRIED)) {
                        setMaritalRelationship(pniFullName, additionalDriverFullName);
                        waitAndClickElement(sniInfoIcon);
                        validateInfoDialogMobileView(sniHeader, sniContent, fsa);
                        removeMaritalRelation(getMaritalCheckbox(pniFullName));
                    } else {
                        waitAndClickElement(additionalDriverInfoIcon);
                        validateInfoDialogMobileView(additionalDriverHeader, additionalDriverContent, fsa);
                    }
                }
            }
        } else {
            validateDriverInfoNonMobileView(pniFullName, pniHeader, pniContent, fsa);
            if (!additionalDrivers.isEmpty()) {
                for (int i = 0; i < additionalDriversSize; i++) {
                    SqlAdditionalDriver additionalDriver = additionalDrivers.get(i);
                    String additionalDriverFullName = getDriverFullName(additionalDriver);
                    if (additionalDriver.getMaritalStatus().equals(MARRIED)) {
                        setMaritalRelationship(pniFullName, additionalDriverFullName);
                        validateDriverInfoNonMobileView(additionalDriverFullName, sniHeader, sniContent, fsa);
                        removeMaritalRelation(getMaritalCheckbox(pniFullName));
                    } else {
                        validateDriverInfoNonMobileView(additionalDriverFullName, additionalDriverHeader, additionalDriverContent, fsa);
                    }
                }
            }
        }

    }

    private void validateDriverInfoNonMobileView(String fullName, String expectedHeader, String expectedContent, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(getInfoHeader(fullName))), expectedHeader, "Browser Info Helper Header");
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(getInfoContent(fullName))), expectedContent, "Browser Info Helper Content");
    }

    private Locator getInfoHeader(String fullName) throws Exception {
        String infoBoxHeaderXpath = "//div[contains(@class, 'auto-driver-review-info-icon-container')]//p[contains(@class, 'tui-info-box-header')]";
        return locator(pwXPath(getDriverCardXpathByFullName(fullName) + infoBoxHeaderXpath));
    }

    private Locator getInfoContent(String fullName) throws Exception {
        String infoBoxContentXpath = "//div[contains(@class, 'auto-driver-review-info-icon-container')]//p[contains(@class, 'tui-info-box-content')]";
        return locator(pwXPath(getDriverCardXpathByFullName(fullName) + infoBoxContentXpath));
    }

    private void validateInfoDialogMobileView(String expectedHeader, String expectedContent, FarmersSoftAssert fsa) throws Exception {
        waitElementBeVisible(infoBoxHeader);
        waitElementBeVisible(infoBoxContent);
        fsa.assertEquals(getTextFromElement(infoBoxHeader), expectedHeader, "Mobile view Help Info Header");
        fsa.assertEquals(getTextFromElement(infoBoxContent), expectedContent, "Mobile view Help Info Content");
        clickOnHiddenElement(infoBoxCloseButton);
    }

    public SqlAdditionalDriver getSni(AutoApplicant applicant) {
        return applicant.getAdditionalDrivers().stream().filter(driver -> driver.getRelationshipToApplicant().equals(SPOUSE)).findFirst().get();
    }

    private String getSniFullName(AutoApplicant applicant) {
        SqlAdditionalDriver sni = getSni(applicant);
        return getDriverFullName(sni);
    }

    public void validateEditDriverSections(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        Locator applicantEditDriverButton = locator(pwXPath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + EDIT_DRIVER_BUTTON_XPATH));
        String stateCode = applicant.getStateCode();
        validateEditDriverSection(applicantEditDriverButton, fsa, true, stateCode);
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        for (int i = 0; i < Math.min(additionalDrivers.size(), MAX_NUMBER_OF_ADDITIONALDRIVERS); i++) {
            SqlAdditionalDriver sqlAdditionalDriver = additionalDrivers.get(i);
            Locator driverEditButton = locator(pwXPath(getDriverCardXpathByFullName(getDriverFullName(sqlAdditionalDriver)) + EDIT_DRIVER_BUTTON_XPATH));
            validateEditDriverSection(driverEditButton, fsa, false, stateCode);
        }
    }

    public void clickEditDriverButton(String fullName) throws Exception {
        waitAndClickElement(getEditDriverButton(fullName));
    }

    public Locator getEditDriverButton(String fullName) throws Exception {
       return locator(pwXPath(getDriverCardXpathByFullName(fullName) + EDIT_DRIVER_BUTTON_XPATH));
    }

    private void validateEditDriverSection(Locator editButton, FarmersSoftAssert fsa, Boolean isApplicant, String stateCode) throws Exception {
        scrollElementToMiddle(editButton);
        waitAndClickElement(editButton);
        waitElementBeVisible(editDriverDialog);
        fsa.assertEquals(getTextFromElement(addDriverHeading), "Edit driver", "Edit driver dialog header");

        // validate gender selection toggles
        List<String> expectedGenderSelections = new ArrayList<>(Arrays.asList("Male", "Female"));
        List<Locator> genderToggleLabels = locators(pwXPath("//div[contains(@class,'auto-add-driver-gender')]//span[@class='mat-button-toggle-label-content']"));
        List<String> genderLabelsActualTexts = genderToggleLabels.stream().map(this::getTextFromElement).collect(Collectors.toList());
        if (isNonBinaryGenderDisplayExpected(stateCode)) {
            expectedGenderSelections.add("Nonbinary");
        }
        if (stateCode.equals(CA)) {
            expectedGenderSelections.add("Not Specified");
        }
        Collections.sort(genderLabelsActualTexts);
        Collections.sort(expectedGenderSelections);
        fsa.assertEquals(genderLabelsActualTexts, expectedGenderSelections, "genderLabels verification");

        fsa.assertEquals(getTextFromElement(driverLicenseQuestionLabel), "Is this driver's license issued by a U.S. state, U.S. territory, or Canadian province?", "Driver License question text should be as expected");

        fsa.assertTrue(isElementPresent(pwXPath("//div[contains(@id,'formField_licenseIssued')]")), "Driver’s license question should be visible for both applicant and additional drivers");

        if (isApplicant) {
            fsa.assertTrue(isElementPresent(pwXPath("//div[@id='currentlyInsured']")), "Currently insured question should be visible for applicant");
            fsa.assertEquals(getTextFromElement(currentlyInsuredQuestionLabel), "Are you currently insured?", "Currently insured question label text");
        }
        fsa.assertEquals(getTextFromElement(saveChangesButton), "Save Changes", "Save changes button label text");
        fsa.assertEquals(getTextFromElement(editDriverCancelButton), "Cancel", "Cancel button label text");
        clickOnHiddenElement(editDriverCancelButton);

    }

    public boolean isEditDriverSideSheetOpen() {
        return isElementVisible(addDriverHeading, 1);
    }

    public boolean isOccupationSideSheetOpen() {
        return isElementVisible(eligibleOccupationModalHeader, 1);
    }

    public boolean validateMaritalToSomeoneNotListed(AutoApplicant applicant, boolean foreignDl) throws Exception {
        boolean validationResult = true;
        Locator maritalCheckbox = getMaritalCheckbox(getApplicantFullName(applicant));
        scrollAndClickOnElement(maritalCheckbox);
        clickOnSpouseToIfExist(applicant);
        validateAddSpouseModalContent();
        validationResult &= validateDriverModalErrorMessages();
        enterSpouseInformation(applicant, true, foreignDl);
        waitForSpinnerToBeGone();
        AppStore.Auto.Driver sni = getSessionStorageAppStore().getAuto().getDrivers().stream().filter(each -> each.getPni().equals("X")).collect(Collectors.toList()).get(0);
        String sniFullName = sni.getFirstName() + SPACE + sni.getLastName();
        // validate marital checkbox is disabled for newly added sni
        validationResult &= isMaritalCheckboxDisabled(sniFullName);
        return validationResult;
    }

    private void validateAddSpouseModalContent() throws Exception {
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();

        if (!landingStateCode.equals(CA)) {
            if(Arrays.asList(TX, MI, IL, AZ, PA, WA, OR, OH, MO, OK).contains(landingStateCode)) {
                String xpathForDrivingVehicle = String.format(SPOUSE_DRIVING_VEHICLE_XPATH, YES);
                waitAndClickElement(locator(pwXPath(xpathForDrivingVehicle)));
                waitForUiSettled();
            }
            Locator licenseQuestion = locator(pwId("formField_label_licenseIssued"));
            testExpectedTextContentForElement(licenseQuestion, "Is this driver's license issued by a U.S. state, U.S. territory, or Canadian province?");
        }
        testExpectedTextContentForElement(addDriverHeading, "Add a spouse");
        // These are not text labels, they are field identifying texts inside the fields
        Assert.assertEquals(getTextFromElement(locator(pwXPath("//mat-form-field[contains(.,'First name')]//div[contains(@class,'text-field')]"))), "First name", "First name field label should be as expected");
        Assert.assertEquals(getTextFromElement(locator(pwXPath("//mat-form-field[contains(.,'Last name')]//div[contains(@class,'text-field')]"))), "Last name", "Last name field label should be as expected");
        Assert.assertEquals(getTextFromElement(locator(pwXPath("//mat-form-field[contains(.,'Date of birth')]//div[contains(@class,'text-field')]"))), "Date of birth", "Last name field label should be as expected");
        testExpectedTextContentForElement(listOfSaveButtons.nth(0), "Save");
    }

    private boolean validateDriverModalErrorMessages() throws Exception {
        boolean validated = true;
        String pleaseProvideYour = "Please provide your ";
        String thisIsRequired = "This is required.";
        String formIncomplete = "One or more required fields are incomplete or incorrect. Please review.";
        waitElementBeVisible(addDriverHeading);
        for (Locator firstNameField : listOfFirstNameFields.all()) {
            waitAndClickElement(firstNameField);
        }
        for (Locator saveButton : listOfSaveButtons.all()) {
            waitAndClickElement(saveButton);
        }
        validated &= testExpectedTextContentForElement(waitElementBeVisible(firstNameErrorMessage), pleaseProvideYour + "first name.");
        validated &= testExpectedTextContentForElement(waitElementBeVisible(lastNameErrorMessage), pleaseProvideYour + "last name.");
        validated &= testExpectedTextContentForElement(waitElementBeVisible(dateOfBirthErrorMessage), pleaseProvideYour + "date of birth.");
        validated &= testExpectedTextContentForElement(waitElementBeVisible(genderErrorMessage), thisIsRequired);

        int index = 0;
        if(Arrays.asList(AZ, IL, TX, MI, PA, WA, OR, OH, MO, OK).contains(getSessionStorageAppStore().getData().getLandingStateCode())) {
            index = 1;
        }
        validated &= testExpectedTextContentForElement(waitElementBeVisible(licenseIssuedErrorMessages.nth(index)), thisIsRequired);
        validated &= testExpectedTextContentForElement(waitElementBeVisible(editDriverModalErrorMessage), formIncomplete);
        return validated;
    }

    public void setMaritalRelationToSomeOneNotListed(AutoApplicant applicant, boolean willBeDriving, boolean foreignDl) throws Exception {
        clickElement(getMaritalCheckbox(getApplicantFullName(applicant)));
        clickOnSpouseToIfExist(applicant);
        enterSpouseInformation(applicant, willBeDriving, foreignDl);
        waitForSpinnerToBeGone();
    }

    private void clickOnSpouseToIfExist(AutoApplicant applicant) throws Exception {
        if (!applicant.getAdditionalDrivers().isEmpty()) {
            getAndClickSpouseTo("someone not listed here");
        }
    }

    private void enterSpouseInformation(AutoApplicant applicant, boolean willBeDriving, boolean foreignDl) throws Exception {
        waitElementBeVisible(addDriverHeading);
        for (Locator firstNameField : locators(pwXPath("//mat-form-field[contains(.,'First name')]//input"))) {
            sendKeysToElement(firstNameField, new Faker().name().firstName());
        }
        for (Locator lastNameField : locators(pwXPath("//mat-form-field[contains(.,'Last name')]//input"))) {
            sendKeysToElement(lastNameField, applicant.getLastName());
        }
        for (Locator dateOfBirthField : locators(pwXPath("//mat-form-field[contains(.,'Date of birth')]//input"))) {
            sendKeysToElement(dateOfBirthField, "01/01/1990");
        }
        for (Locator femaleGenderButton : listOfFemaleGenderButtons.all()) {
            clickElement(femaleGenderButton);
        }

        String willBeDrivingToggle = willBeDriving ? YES : NO;
        String xpathForDrivingVehicle = String.format(SPOUSE_DRIVING_VEHICLE_XPATH, willBeDrivingToggle);
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();

        if (Arrays.asList(CA, AZ, IL, TX, MI, PA, WA, OR, OH, MO, OK).contains(landingStateCode)) {
            waitAndClickElement(locator(pwXPath(xpathForDrivingVehicle)));
        }

        if (willBeDrivingToggle.equals(YES)) {
            String US_CA_Dl_RadioButtons_xpath = foreignDl ? NO : YES;
            waitAndClickElement(locator(pwXPath(String.format(DIALOG_LICENSED_IN_USA_RADIO_BUTTONS_XPATH, US_CA_Dl_RadioButtons_xpath))));
        }

        for (Locator saveButton : listOfSaveButtons.all()) {
            waitAndClickElement(saveButton);
        }
        if (isElementVisible(editDriverDialogCloseLink, 1)) {
            clickElement(editDriverDialogCloseLink);
        }

    }

    private void getAndClickSpouseTo(String spouse) throws Exception {
        Locator someoneNotListedHere = getSpouseToButton(spouse);
        scrollAndClickOnElement(someoneNotListedHere);
    }

    private boolean isMaritalCheckboxDisabled(String sniFullName) throws Exception {
        return getAttributeData(waitElementBeVisible(locator(pwXPath(getDriverCardXpathByFullName(sniFullName) + MARITAL_CHECKBOX_XPATH))), CLASS).contains(DISABLED);
    }

    public void validateMaritalRelationRemoval(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        final String MARITAL_REMOVAL_HEADER = "Change Status?";
        final String MARITAL_REMOVAL_CONTENT = "This driver is currently selected as the spouse to other driver. Unchecking this option will remove the status for both drivers.";
        if (applicant.getMaritalStatus().equals(MARRIED)) {
            String pniFullName = getApplicantFullName(applicant);
            setMaritalRelationship(pniFullName, getSniFullName(applicant));
            Locator pniMaritalCheckbox = getMaritalCheckbox(pniFullName);
            clickElement(pniMaritalCheckbox);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(changeStatusHeading)), MARITAL_REMOVAL_HEADER, "Change status header");
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(changeStatusContent)), MARITAL_REMOVAL_CONTENT, "Change status text check");
            waitAndClickElement(keepAsIsButton);
            removeMaritalRelation(pniMaritalCheckbox);
        }
    }

    private boolean removeMaritalRelation(Locator pniMaritalCheckbox) {
        boolean passed = true;
        clickElement(pniMaritalCheckbox);
        clickElement(removeStatusButton);
        wait.until(Conditions.invisibilityOfElementWithText(pwXPath(REMOVE_STATUS_XPATH), "Remove Status"));
        passed &= !isCheckboxChecked(pniMaritalCheckbox);
        return passed;
    }

    public void validateValidateAccidentCheckbox(FarmersSoftAssert fsa) throws Exception {
    	int numberOfElements = accidentCheckboxes.count();
        for (int i = 0; i < numberOfElements; i++){
            // validate marital checkboxes are clickable
            Locator accidentQuestion = locator(pwXPath(String.format("//div[@id='ordered-field-placeholder_hadAccidentOrViolation_%s']//input", i + 1)));
            scrollAndClickOnHiddenElement(accidentQuestion);
            fsa.assertTrue(accidentQuestion.isChecked(), "Accident checkbox is selected");
            if (!accidentQuestion.isChecked()) {
                scrollAndClickOnHiddenElement(accidentQuestion);
            }
            // validate texts of checkbox
            boolean isCaState = getSessionStorageAppStore().getData().getLandingStateCode().equals(CA);
            String years = isCaState ? "10" : "5";
            fsa.assertEquals(getTextFromElement(accidentQuestions.nth(i)), "Had an accident or violation in last " + years + " years", "Accident checkbox label validation");
            //validate subtexts of checkbox
            fsa.assertEquals(getTextFromElement(accidentSubTexts.nth(i)), "At fault or no fault accident or moving violations only", "Accident checkbox subtext label validation");
            if (i == 0) {
                validateIncidentErrorMessages(fsa);
            }
            accidentQuestion = locator((pwXPath(String.format("//div[@id='ordered-field-placeholder_hadAccidentOrViolation_%s']//input[contains(@class,'mdc-checkbox--selected')]", i + 1))));
            scrollElementToMiddle(accidentQuestion);
            clickElement(accidentQuestion);
        }
    }

    private void validateIncidentErrorMessages(FarmersSoftAssert fsa) throws Exception {
        String pleaseProvide = "Please provide ";
        waitAndClickElement(continueButton);
        waitForSpinnerToBeGone();
        fsa.assertTrue(testExpectedTextContentForElement(getIncidentFormErrorWithIndex(1), pleaseProvide + "accident type"), "Accident type error message for no input");
        fsa.assertTrue(testExpectedTextContentForElement(getIncidentFormErrorWithIndex(2), pleaseProvide + "date of accident"), "Date of accident error message for no input");
        refreshPage();
        isOnDriverReviewPage();
        AppStore.Data.CustomerData customerData = getSessionStorageAppStore().getData().getCustomerData();
        String fullName = customerData.getFirstName() + SPACE + customerData.getLastName();
        clickElement(getAccidentAndViolationCheckbox(fullName));
        waitForUiSettled();
        Locator violationToggle = locator(pwXPath(VIOLATION_TOGGLE_XPATH));
        scrollAndClickOnHiddenElement(waitElementBeVisible(violationToggle));
        fsa.assertTrue(isButtonSelected(violationToggle), "Violation toggle press was successful");
        waitAndClickElement(continueButton);
        fsa.assertTrue(testExpectedTextContentForElement(getIncidentFormErrorWithIndex(1), pleaseProvide + "violation type"), "Violation type error message for no input");
        fsa.assertTrue(testExpectedTextContentForElement(getIncidentFormErrorWithIndex(2), pleaseProvide + "date of violation"), "Date of violation no input error messsage");
        scrollElementToMiddle(ctaErrorMessage);
    }

    private Locator getIncidentFormErrorWithIndex(int index) throws Exception {
        String indexString = String.valueOf(index);
        String xpath = String.format("//app-incident//mat-form-field[%s]//mat-error", indexString);
        return waitElementBeVisible(locator(pwXPath(xpath)));
    }

    public void validateHadTheirDriverLicenseAgeCondition(FarmersSoftAssert fsa, AutoApplicant applicant) throws Exception {

        if (isAskingDriverLicenseAgeState(applicant.getStateCode())) {
            return;
        }

        String applicantFullName = getApplicantFullName(applicant);
        int applicantAge = applicant.getAge();
        if (applicantAge <= MAX_YOUNG_AGE) {
            fsa.assertTrue(isElementPresent(pwXPath(getDriverCardXpathByFullName(applicantFullName) + HAD_THEIR_DRIVER_LICENSE_CHECKBOX)), "Driver License question should be visible for applicant age " + applicantAge);
        }

        // validate upper and lower limit for age input field
        if (applicantAge - applicant.getFirstAgeUnitedStatesDriverLicense() < 3) {
            validateLimitsForAgeInputField(fsa, applicantFullName, applicantAge);
        }
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        int additionalDriversSize = Math.min(MAX_NUMBER_OF_ADDITIONALDRIVERS, additionalDrivers.size());
        for (int i = 0; i < additionalDriversSize; i++) {
            SqlAdditionalDriver currentDriver = additionalDrivers.get(i);
            String currentDriverFullName = getDriverFullName(currentDriver);
            int currentDriverAge = currentDriver.getAge();

            if (currentDriver.getAge() <= MAX_YOUNG_AGE) {
                if (!isAskingDriverLicenseAgeState(applicant.getStateCode())) {
                    Locator hadDriversLicenseCheckbox = getHadDriversLicenseCheckbox(getDriverFullName(currentDriver));
                    scrollElementToMiddle(hadDriversLicenseCheckbox);
                    fsa.assertTrue(isElementDisplayed(hadDriversLicenseCheckbox, 1), "Driver License question should be visible for additional driver age " + currentDriver.getAge());
                }
            }
            if (currentDriverAge - currentDriver.getFirstAgeUnitedStatesDriverLicense() < 3) {
                validateLimitsForAgeInputField(fsa, currentDriverFullName, currentDriverAge);
            }
        }

    }

    private void validateLimitsForAgeInputField(FarmersSoftAssert fsa, String fullName, int age) throws Exception {
        Locator driversLicenseCheckbox = getHadDriversLicenseCheckbox(fullName);
        waitAndClickElement(driversLicenseCheckbox);
        Locator driverLicenceAgeInputField = getDriverLicenceAgeInputField(fullName);
        fsa.assertTrue(doesElementHaveFocus(driverLicenceAgeInputField), "Driver License Age input field should have focus when the checkbox is selected");
        sendKeys(driverLicenceAgeInputField, "14" + Keys.TAB);
        waitForUiSettled();
        String ageConditionError = getTextFromElement(getDriverLicenseAgeConditionError(fullName));
        fsa.assertTrue(isElementDisplayed(getDriverLicenseAgeConditionError(fullName), 1), "Driver License age condition error message should be displayed when input age is below minimum");
        fsa.assertTrue(ageConditionError.contains("Minimum age is 15"), "Driver License age condition error message should indicate minimum age requirement");
        driverLicenceAgeInputField.fill("");
        sendKeys(driverLicenceAgeInputField, "" + (age + 1));
        waitAndClickElement(minAgeSection);
        fsa.assertTrue(isElementDisplayed(getDriverLicenseAgeConditionError(fullName), 1), "Driver License age condition error message should be displayed when input age is above maximum");
        ageConditionError = getTextFromElement(getDriverLicenseAgeConditionError(fullName));
        fsa.assertTrue(ageConditionError.contains("Invalid age"), "Driver License age condition error message should indicate invalid age for above maximum input");
        waitAndClickElement(driversLicenseCheckbox);
    }

    public void validateOccupationSidePanel(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        if (isEmploymentDisabledState(applicant.getStateCode())) {
            fsa.assertTrue(!isElementPresent(seeEligibleOccupationList), "Eligible occupations not displayed");
        }
        List<Locator> seeEligibleOccupationsLinks = locators(seeEligibleOccupationList);
    	int numberOfElements = seeEligibleOccupationsLinks.size();
        for (int i = 0; i< numberOfElements; i++){
            // link  text
            List<String> expectedLinkTexts = Arrays.asList("Let's find my occupation", "See eligible occupations", "Check for discount");
            String actualTitle = getTextFromElement(seeEligibleOccupationsLinks.get(i));
            fsa.assertTrue(expectedLinkTexts.contains(actualTitle), "Occupation link text validated");
            // validate occupation section title and subheader
            String occupationSectionHeader = getTextFromElement(occupationHeaders.nth(i));
            List<String> expectedOccupationHeaders = Arrays.asList("Do you qualify for an Occupational Discount?", "Current or former employed professional (optional)", "You could save up to 15%");
            fsa.assertTrue(expectedOccupationHeaders.contains(occupationSectionHeader), "Occupation section header validated");

            String occupationSectionSubHeader = getTextFromElement(occupationSubtexts.nth(i));
            List<String> expectedOccupationSubHeaders = Arrays.asList("If your occupation is on this list, you can qualify for additional savings", "Depending on your occupation, you may qualify for a discount.", "You may qualify for an occupational discount, even if this driver is retired");

            fsa.assertTrue(expectedOccupationSubHeaders.contains(occupationSectionSubHeader), "Occupation section sub header validated");
        }

        String expectedOccupationSidePanelHeader = "Eligible occupations";
        String expectedEmployedOrRetiredTitle = "Are you currently employed or retired?";

        if (isElementPresent(seeEligibleOccupationList)) {

            List<Locator> seeEligibleOccupations = seeEligibleOccupationsLinks;
        	numberOfElements = seeEligibleOccupations.size();
            for (int i = 0; i< numberOfElements; i++){
                Locator seeEligibleOccupationsForOneDriver = seeEligibleOccupations.get(i);
                scrollAndClickOnElement(seeEligibleOccupationsForOneDriver);
                if (!isElementVisible(eligibleOccupationModalHeader, 2)) {
                    waitAndClickElement(seeEligibleOccupationsForOneDriver);
                }
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(eligibleOccupationModalHeader)), expectedOccupationSidePanelHeader, "eligibleOccupationModalHeader verification");
                fsa.assertEquals(getTextFromElement(employedOrRetiredTitle), expectedEmployedOrRetiredTitle, "employedOrRetiredTitle verification");
                List<String> actualEmployedAndRetiredToggles = occupationsSidePanelToggles.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
                List<String> expectedEmployedAndRetiredToggles = new ArrayList<>(Arrays.asList("Employed", "Retired"));
                fsa.assertEquals(actualEmployedAndRetiredToggles, expectedEmployedAndRetiredToggles, "Occupation Side Panel Employed Retired toggle labels");
                fsa.assertTrue(selectEligibleOccupationsTitle.isVisible(), "'Select from the list of eligible occupation(s). Verification of occupation will be required.' text should be available");
                fsa.assertEquals(getTextFromElement(discountUnavailableMessage), "If you don't see your occupation on the list, you may not be eligible for this discount.", "discountUnavailableMessage verification");
                scrollAndClickOnHiddenElement(addButton);
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(occupationSidePanelErrorMessage)), "Please select one of the above eligible occupations to qualify for a discount or cancel to exit.", "occupationSidePanelErrorMessage verification");
                scrollToElement(occupationSidePanelCancelButton);
                clickOnHiddenElement(occupationSidePanelCancelButton);
                waitForUiSettled();
                fsa.assertTrue(!isElementDisplayed(pwXPath(OCCUPATION_SIDE_PANEL_HEADER_XPATH)), "Occupation side panel should be not be displayed after closing the side panel");
                // add occupation and validated it is selected
                waitForElements(SEE_ELIGIBLE_OCCUPATIONS_XPATH);
                waitAndClickElement(locators(pwXPath(SEE_ELIGIBLE_OCCUPATIONS_XPATH)).get(i));
                waitElementBeVisible(eligibleOccupationModalHeader);
                scrollAndClickOnElement(locator(pwXPath("//mat-radio-button[1]//input")));
                fsa.assertFalse(isElementDisplayed(pwXPath(DISCOUNT_UNAVAILABLE_MESSAGE_XPATH)), "\"If you don't see your occupation on the list, you may not be eligible for this discount.\" message should not be displayed after making selection");
                scrollAndClickOnElement(addButton);
                if (isElementPresent(pwXPath("//app-occupation-list//mat-error"), 1)) {
                    Locator additionalRadioButtonSelection = locators(pwXPath("//mat-radio-button[not(contains(@class,'checked'))]//input")).get(0);
                    scrollAndClickOnElement(additionalRadioButtonSelection);
                    scrollAndClickOnElement(addButton);
                }
                fsa.assertTrue(waitElementBeVisible(occupationAddedConfirmation).isVisible(), "Occupation added confirmation successful");

                // validate remove functionality
                waitAndClickElement(removeOccupationButton);
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(removeOccupationPanelHeader)), "Remove occupation", "removeOccupationPanelHeader verification");
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(removeButton)), "Remove", "removeButton verification");
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(keepOccupation)), "Keep occupation", "keepOccupation verification");
                waitAndClickElement(keepOccupation);
                waitForUiSettled();
                fsa.assertTrue(occupationAddedConfirmation.isVisible(), "After clicking on Keep occupation, occupation should not be removed");
                removeOccupation();
                fsa.assertTrue(!isElementDisplayed(pwXPath(OCCUPATION_ADDED_CONFIRMATION_XPATH)), "After removing occupation, occupation added confirmaiton should not be displayed");
            }
        }
    }

    private void removeOccupation() throws Exception {
        scrollAndClickOnElement(waitElementBeVisible(removeOccupationButton));
        scrollAndClickOnElement(waitElementBeVisible(removeButton));
        validateSnackbarAndDiscountFooterSection("remove", "Drivers-review Page");
    }

    private void validateSnackbarAndDiscountFooterSection(String discount, String pagename) throws Exception {
        isSnackBarMessageDisplayed(discount);
        reviewDiscountSection(pagename);
    }

    public void validateOccupation(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(employmentDiscountQualification), applicant.getOccupation().isBlank() ? OTHER : applicant.getOccupation(), "Applicant Occupation verification.");
    }

    public void validateMaritalStatus(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String applicantFullName = getApplicantFullName(applicant);
        if (applicant.getMaritalStatus().equals(MARRIED)) {
            fsa.assertTrue(isCheckboxChecked(getMaritalCheckbox(applicantFullName)), "PNI Marital checkbox is checked.");
            fsa.assertTrue(isMaritalCheckboxDisabled(applicantFullName), "PNI Marital checkbox is disabled.");
            fsa.assertTrue(isCheckboxChecked(getMaritalCheckbox(getDriverFullName(applicant.getAdditionalDrivers().get(0)))), "SNI Marital checkbox is checked.");
            fsa.assertTrue(isMaritalCheckboxDisabled(getDriverFullName(applicant.getAdditionalDrivers().get(0))), "SNI Marital checkbox is disabled.");
            fsa.assertTrue(getTextFromElement(locator(pwXPath(getDriverCardXpathByFullName(applicantFullName) + "//p[contains(@aria-label,'Spouse to')]"))).contains(getDriverFullName(applicant.getAdditionalDrivers().get(0))), "PNI Driver has reference to spouse.");
            fsa.assertTrue(getTextFromElement(locator(pwXPath(getDriverCardXpathByFullName(getDriverFullName(applicant.getAdditionalDrivers().get(0))) + "//p[contains(@aria-label,'Spouse to')]"))).contains(applicantFullName), "SNI Driver has reference to PNI.");
        } else {
            fsa.assertTrue(!isCheckboxChecked(getMaritalCheckbox(applicantFullName)), "PNI Marital checkbox is unchecked.");
            fsa.assertTrue(isMaritalCheckboxDisabled(applicantFullName), "PNI Marital checkbox disabled.");
        }
    }

    public boolean validateIncidentRemoval(AutoApplicant applicant) throws Exception {
        boolean passed = true;
        if (applicant.isHaveAccidentOrViolations() && applicant.getIncidents().stream().map(incident -> incident.getAdditionalDriverId() == 0).count() > 1) {
            String applicantFullName = getApplicantFullName(applicant);
            passed &= addIncidents(applicantFullName, applicant.getIncidents());
            int initialIncidentCount = getIncidentsAppsForGivenDriver(applicantFullName).size();
            // delete first incident
            waitForUiSettled();
            waitAndClickElement(getIncidentRemovalElement(applicantFullName).get(0));
            int countOfIncidentsAfterRemoval = getIncidentsAppsForGivenDriver(applicantFullName).size();
            passed &= initialIncidentCount - countOfIncidentsAfterRemoval == 1;
        }
        return passed;
    }

    public boolean validateDriverReviewPageCTA(AutoApplicant applicant) throws Exception {
        return validateCTADescription();
    }

    private boolean validateCTADescription() throws Exception {
        boolean passed = true;
        String expectedCtaDescription = "Just one more step until your quote!";
        scrollToElement(ctaDescription);
        passed &= testExpectedTextContentForElement(ctaDescription, expectedCtaDescription);
        return passed;
    }

    public void clickContinueButton() throws Exception {
        scrollAndClickOnElement(continueButton);
        waitForSpinnerToBeGone();
        if (isElementVisible(continueButton, 3)) {
            scrollAndClickOnElement(continueButton);
            waitForSpinnerToBeGone();
        }
        longWaitForElementToBeGoneByID("auto-driver-review-cta-continue");
    }

    public boolean addSafetyCourse(String fullName) throws Exception {
        boolean passed = true;
        Locator safetyCourseCheckbox = getSafetyCourseCheckbox(fullName);
        scrollElementToMiddle(safetyCourseCheckbox);
        waitAndClickElement(safetyCourseCheckbox);
        passed &= safetyCourseCheckbox.getAttribute(CLASS).contains(CHECKBOX_CHECKED);
        if (!passed) {
            Log.error("\n Safety course checkbox selection failed ");
        } else {
            Log.info("Safety course addition successful for: " + fullName);
        }
        return passed;
    }

    private boolean addIncidents(String fullName, List<SqlIncident> incidents) throws Exception {
        boolean passed = true;
        boolean isAdditionalIncident = false;
        for (int i = 0; i < incidents.size(); i++) {
            SqlIncident currentIncident = incidents.get(i);
            isAdditionalIncident = i > 0;
            String incidentType = currentIncident.getIncidentType();
            if (incidentType.equals(ACCIDENT)) {
                passed &= addAccident(fullName, currentIncident, isAdditionalIncident);
            } else if (incidentType.equals(CITATION)) {
                try {
                    passed &= addViolation(fullName, currentIncident, isAdditionalIncident);
                } catch (Exception e) {
                    Log.error(e.getMessage());
                    refreshPage();
                    passed &= addViolation(fullName, currentIncident, isAdditionalIncident);
                }

            } else {
                Log.warn("Please check the incident type as it does not adhere to known incident types");
            }
        }
        return passed;
    }

    private boolean addAccident(String fullName, SqlIncident accident, boolean isAdditionalIncident) throws Exception {
        boolean accidentAdditionPassed = true;
        String driverForm = getDriverCardXpathByFullName(fullName);
        accidentAdditionPassed &= clickForAdditionalIncident(fullName, isAdditionalIncident);
        fillOutIncidentDetails(isAdditionalIncident, driverForm, accident);
        if (accident.isAnyInjuries()) {
            clickElement(getLocalInjuryButton());
        }
        if (!accidentAdditionPassed) {
            Log.error("\nAccident addition failed");
        }
        return accidentAdditionPassed;
    }

    private boolean addViolation(String fullName, SqlIncident violation, boolean isAdditionalIncident) throws Exception {
        boolean violationAdditionPassed = true;
        String driverForm = getDriverCardXpathByFullName(fullName);
        violationAdditionPassed &= clickForAdditionalIncident(fullName, isAdditionalIncident);
        String localViolationToggleXpath = isAdditionalIncident ? driverForm + ADDITIONAL_INCIDENT_FORM_XPATH + VIOLATION_TOGGLE_XPATH : driverForm + VIOLATION_TOGGLE_XPATH;
        Locator violationToggle = locator(pwXPath(localViolationToggleXpath));
        scrollToElement(violationToggle);
        waitAndClickElement(violationToggle);
        violationAdditionPassed &= isButtonSelected(violationToggle);
        fillOutIncidentDetails(isAdditionalIncident, driverForm, violation);
        if (!violationAdditionPassed) {
            Log.error("\nViolation addition failed");
        }
        return violationAdditionPassed;
    }

    private boolean clickForAdditionalIncident(String fullName, boolean isAdditionalIncident) throws Exception {
        boolean passed = true;
        Locator accidentOrViolationCheckbox;
        if (isAdditionalIncident) {
            scrollAndClickOnElement(waitElementBeVisible(getAddAnotherIncidentLink(fullName)));
        } else {
            accidentOrViolationCheckbox = getAccidentAndViolationCheckbox(fullName);
            clickElement(accidentOrViolationCheckbox);
            passed &= isCheckboxChecked(accidentOrViolationCheckbox);
        }
        return passed;
    }

    public void fillOutIncidentDetails(boolean isAdditionalIncident, String driverForm, SqlIncident incident) throws Exception {
        String localDropDownXpath = getLocalDropDownXpathForIncident(isAdditionalIncident);
        String localDateInputField = getLocalDateInputField(isAdditionalIncident);
        Locator dateInputField = waitAndClickElement(locator(pwXPath(driverForm + localDateInputField)));
        if (doesElementHaveFocus(dateInputField)) {
            Log.info("Accident/Violation date input field has focus");
        } else {
            Log.error("Accident/Violation date input field does not have focus", true);
        }
        Locator dropDown = null;
        // using loop and try/catch as this is throwing stale element exception occasionally
        for (int i = 0; i <= 2; i++) {
            try {
                dropDown = locator(pwXPath(driverForm + localDropDownXpath));
                break;
            } catch (Exception e) {
                Log.info(e.getMessage());
            }
        }
        selectValueInDropDown(dropDown, incident.getDescription());
        sendKeys(dateInputField, incident.getDateOccured());
    }

    private boolean addFinancialFiling(AutoApplicant applicant, String fullName) throws Exception {
        boolean result = true;
        //Only perform these actions where Financial filing question is applicable
        if (!isFinancialFilingQuestionDisabled(applicant.getStateCode())) {
        	Locator financialFilingCheckbox = getFinancialFilingCheckbox(fullName);
        	scrollAndClickOnElement(financialFilingCheckbox);
        	result = isCheckboxChecked(financialFilingCheckbox);
        	if (!result) {
        		jsClickElement(financialFilingCheckbox);
            	result = isCheckboxChecked(financialFilingCheckbox);
        	}
        	if (applicant.getFinancialFiling().equals(SR_22_ANOTHER_STATE)) {
        		Locator anotherStateButton = getAnotherStateButton(fullName);
        		clickElement(anotherStateButton);
        	} else if (applicant.getStateCode().equals(FL)) {
        		// Florida has a button and a case file field
        		Locator floridaButton = locator(pwXPath(getDriverCardXpathByFullName(fullName) + "//button[contains(., 'Florida')]"));
        		clickElement(floridaButton);
        		Locator floridaCaseInputField = locator(pwXPath(getDriverCardXpathByFullName(fullName) + "//div[contains(@id, 'requiredFinancialResponsiblity')]//input[not(@type)]"));
        		Faker faker = new Faker();
        		enterValueInField(faker.expression("#{numerify '#########'}"), floridaCaseInputField, "Case number");
        	}
        }
        return result;
    }

    public Locator getFinancialFilingCheckbox(String fullName) throws Exception {
        return locator(pwXPath(getDriverCardXpathByFullName(fullName) + FINANCIAL_RESPONSIBILITY_CHECKBOX_XPATH));
    }

    public void clickOnFinancialFilingAnotherStateButton(String fullName) throws Exception {
        Locator financialFilingCheckbox = getFinancialFilingCheckbox(fullName);
        scrollAndClickOnElement(financialFilingCheckbox);
        wait.until(d-> isButtonSelected(financialFilingCheckbox));
        Locator anotherState = getAnotherStateButton(fullName);
        waitAndClickElement(anotherState);
    }

    public boolean addHadDriversLicense(String fullName, int ageLicensedAcquired) throws Exception {
        boolean result = true;
        Locator hadDriversLicenseCheckbox = getHadDriversLicenseCheckbox(fullName);
        if (!isCheckboxChecked(hadDriversLicenseCheckbox)) {
            clickElement(hadDriversLicenseCheckbox);
        }
        Locator driverLicenceAgeInputField = getDriverLicenceAgeInputField(fullName);
        sendKeysToElement(driverLicenceAgeInputField, String.valueOf(ageLicensedAcquired));
        sendKeysToElement(driverLicenceAgeInputField, Keys.TAB);
        if (!result) {
            Log.error("\nError in Has Had Driver License in less than 3 years checkbox");
        }
        return result;
    }

    public boolean addEmployment(String fullName, String occupation) throws Exception {
        if (isBDQFlowEnabled()) {
            return true;
        }

        if (StringUtils.isEmpty(occupation) || !isElementPresent(pwXPath(SEE_ELIGIBLE_OCCUPATIONS_XPATH))) {
            Log.info(StringUtils.isEmpty(occupation) ? "No occupation to add" : "'Let's find my occupation' link is not present.");
            selectEmploymentToggle(fullName, "No");
            return true;
        }

        selectEmploymentToggle(fullName, "Yes");

        String occupationLinkBy = pwXPath(getDriverCardXpathByFullName(fullName) + SEE_ELIGIBLE_OCCUPATIONS_XPATH);
        if(isElementDisplayed(occupationLinkBy)) {
            Locator occupationLink = locator(occupationLinkBy);
            scrollAndClickOnElement(occupationLink);
            ensureOccupationSideSheetOpen(occupationLink);
        }

        if (selectOccupation(occupation)) {
            scrollAndClickOnElement(addButton);
            handleAdditionalSelectionIfError();
        } else {
            closeOccupationSideSheet();
        }

        return true;
    }

    private void selectEmploymentToggle(String fullName, String option) throws Exception {
        String toggleXpath = String.format(getDriverCardXpathByFullName(fullName) + "//div[contains(@class,'discount-employed')]//mat-button-toggle[contains(.,'%s')]", option);
        if (isElementDisplayed(pwXPath(toggleXpath))) {
            Locator toggleElement = locator(pwXPath(toggleXpath));
            scrollAndClickOnElement(toggleElement);
        }
    }

    private void ensureOccupationSideSheetOpen(Locator occupationLink) throws Exception {
        if (!isOccupationSideSheetOpen()) {
            scrollAndClickOnElement(occupationLink);
        }
    }

    private boolean selectOccupation(String occupation) throws Exception {
        String occupationXpath = String.format("//mat-radio-button[contains(.,'%s')]", occupation);
        if (isElementDisplayed(pwXPath(occupationXpath))) {
            Locator occupationElement = locator(pwXPath(occupationXpath));
            scrollAndClickOnElement(occupationElement);
            return getAttributeData(occupationElement, CLASS).contains(CHECKED);
        }
        return false;
    }

    private void handleAdditionalSelectionIfError() throws Exception {
        if (isElementPresent(pwXPath("//app-occupation-list//mat-error"), 1)) {
            Locator additionalOption = locators(pwXPath("//mat-radio-button[not(contains(@class,'checked'))]//input")).get(0);
            scrollAndClickOnElement(additionalOption);
            scrollAndClickOnElement(addButton);
        }
    }

    private void closeOccupationSideSheet() throws Exception {
        if(isElementVisible(closeIcon, 1)) {
            waitAndClickElement(closeIcon);
        }
    }


    private boolean addFullTimeStudent(Optional<SqlAdditionalDriver> driverOptional, AutoApplicant applicant) throws Exception {
        boolean validated = true;

        //student checkbox is disabled for below state(s)
        if (applicant.getStateCode().equalsIgnoreCase(IA)) {
            return validated;
        }

        if (!applicant.getMaritalStatus().equals(MARRIED) && applicant.getAge() < MAX_YOUNG_AGE) {
            String applicantFullName = getApplicantFullName(applicant);
            Locator fullTimeStudentCheckbox = getFullTimeStudentCheckbox(applicantFullName);
            scrollToElement(fullTimeStudentCheckbox);
            clickElement(fullTimeStudentCheckbox);
//            if (applicant.isFullTimeStudentWithHighGPA()) {
//                Locator gpaCheckbox = getGPACheckbox(applicantFullName);
//                waitAndClickElement(gpaCheckbox);
//                validated &= isCheckboxChecked(gpaCheckbox);
//                validated &= isDiscountPresentInTheSideSheet("Good student");
//            }
        }

        if (driverOptional.isPresent() && driverOptional.get().getAge() <= MAX_YOUNG_AGE) {
            SqlAdditionalDriver driver = driverOptional.get();

            String fullName = getDriverFullName(driver);
            if(!driver.getRelationshipToApplicant().equals("Spouse")){
                Locator fullTimeStudentCheckbox = getFullTimeStudentCheckbox(fullName);
                scrollAndClickOnElement(fullTimeStudentCheckbox);
                validated &= isCheckboxChecked(fullTimeStudentCheckbox);
            }

            // add distant student if applicable
            if (driver.isAttendsDistantSchool() && applicant.getAge() >= MAX_YOUNG_AGE && isFlexState(applicant.getStateCode())) {
                Locator distantStudentCheckbox = getDistantStudentCheckbox(fullName);
                clickElement(distantStudentCheckbox);
                validated &= isCheckboxChecked(distantStudentCheckbox);
                if(!isOnBristolWest()) {
                    validated &= isDiscountPresentInTheSideSheet("Distant student");
                }
            }
        }
        if (!validated) {
            Log.error("\nError in addFullTimeStudent");
        }
        return validated;
    }

    public boolean setMaritalRelationship(String spouseOneFullName, String spouseTwoFullName) throws Exception {
        boolean validationResult = true;
        // click marital checkbox
        Locator pniMaritalCheckbox = getMaritalCheckbox(spouseOneFullName);
        scrollAndClickOnElement(pniMaritalCheckbox);
        validationResult &= isCheckboxChecked(pniMaritalCheckbox);

        //choose sni from the married to options
        Locator spouseToButton = getSpouseToButton(spouseTwoFullName);
        scrollAndClickOnElement(spouseToButton);
        // validate marital checkbox is disabled for sni
        validationResult &= isMaritalCheckboxDisabled(spouseTwoFullName);
        waitForUiSettled();
        // validate sni spouse to points to pni
        validationResult &= getTextFromElement(waitElementBeVisible(locator(pwXPath(getDriverCardXpathByFullName(spouseOneFullName) + "//div[contains(@id,'ordered-field-placeholder_maritalStatus')]//p")))).contains(spouseTwoFullName);
        if (!validationResult) {
            Log.error("Marital relationship setting was not successful between " + spouseOneFullName + " and" + spouseTwoFullName);
        }
        return validationResult;
    }

    public Locator getMaritalCheckbox(String pniFullName) throws Exception {
        return locator(pwXPath(getDriverCardXpathByFullName(pniFullName) + MARITAL_CHECKBOX_INPUT_XPATH));
    }

    private Locator getAccidentAndViolationCheckbox(String fullName) throws Exception {
        final String HAD_ACCIDENT_VIOLATION_CHECKBOX_XPATH = "//input[contains(@aria-label,'Had an accident')]";
        return locator(pwXPath(getDriverCardXpathByFullName(fullName) + HAD_ACCIDENT_VIOLATION_CHECKBOX_XPATH));
    }

    private Locator getAddAnotherIncidentLink(String fullName) throws Exception {
        final String ADD_ANOTHER_INCIDENT_XPATH = "//a[contains(@id,'addMoreIncident')]";
        return locator(pwXPath(getDriverCardXpathByFullName(fullName) + ADD_ANOTHER_INCIDENT_XPATH));
    }

    private List<Locator> getIncidentRemovalElement(String fullName) throws Exception {
        final String INCIDENT_REMOVAL_XPATH = "//app-incident//a[.='Remove']";
        return locators(pwXPath(getDriverCardXpathByFullName(fullName) + INCIDENT_REMOVAL_XPATH));
    }

    private List<Locator> getIncidentsAppsForGivenDriver(String fullName) throws Exception {
        return locators(pwXPath(getDriverCardXpathByFullName(fullName) + "//app-incident"));
    }

    private Locator getEmployedCheckbox(String fullName) throws Exception {
        final String EMPLOYED_CHECKBOX_XPATH = "//mat-checkbox[@formcontrolname='isEmployed']//input";
        return locator(pwXPath(getDriverCardXpathByFullName(fullName) + EMPLOYED_CHECKBOX_XPATH));
    }

    private Locator getOccupationInputField(String fullName) throws Exception {
        final String OCCUPATION_INPUT_FIELD_XPATH = "//occupation-typeahead//input";
        return locator(pwXPath(getDriverCardXpathByFullName(fullName) + OCCUPATION_INPUT_FIELD_XPATH));
    }

    private Locator getSafetyCourseCheckbox(String fullName) throws Exception {
        return locator(pwXPath(getDriverCardXpathByFullName(fullName) + SAFETY_COURSE_CHECKBOX_XPATH));
    }

    private Locator getFullTimeStudentCheckbox(String fullName) throws Exception {
        String studentCheckboxXpath = "//div[contains(@id,'fullTimeStudentGPA')]//input";
        return locator(pwXPath(getDriverCardXpathByFullName(fullName) + studentCheckboxXpath));
    }

    private Locator getGPACheckbox(String fullName) throws Exception {
        final String GPA_CHECKBOX_XPATH = "//div[contains(@id,'fullTimeStudentGPA')]//input";
        return locator(pwXPath(getDriverCardXpathByFullName(fullName) + GPA_CHECKBOX_XPATH));

    }

    private Locator getDistantStudentCheckbox(String fullName) throws Exception {
        final String DISTANT_STUDENT_XPATH = "//div[contains(text(),'Attends school more than 100 miles')]//input";
        return locator(pwXPath(getDriverCardXpathByFullName(fullName) + DISTANT_STUDENT_XPATH));
    }

    public String getDriverCardXpathByFullName(String fullName) throws Exception {
        return String.format("//h2[contains(.,\"%s\")]/ancestor::app-driver-review-card", fullName);
    }

    public List<String> getCheckboxesTextsForGivenDriver(String fullName) throws Exception {
        List<Locator> checkboxes = getCheckboxElementsForGivenDriver(fullName);
        return checkboxes.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    private List<Locator> getCheckboxElementsForGivenDriver(String fullName) throws Exception {
        final String CHECKBOXES = "//div[contains(@class,'safety-course-checkbox')]//label";
        List<Locator> checkboxes = locators(pwXPath(getDriverCardXpathByFullName(fullName) + CHECKBOXES));
        waitElementBeVisible(checkboxes.get(0));
        return checkboxes;
    }

    private void validateCheckboxesForGivenDriver(AutoApplicant applicant, String fullName) throws Exception {
        List<Locator> checkboxElementsForGivenDriver = getCheckboxElementsForGivenDriver(fullName);
    	int numberOfElements = checkboxElementsForGivenDriver.size();
        for (int i = 0; i< numberOfElements; i++){
            try {
                Locator currentCheckboxElement = checkboxElementsForGivenDriver.get(i);
                if (getTextFromElement(currentCheckboxElement).contains(MARRIED) && applicant.getMaritalStatus().equals(MARRIED)) {
                    continue;
                }
                waitAndClickElement(currentCheckboxElement);
                if (applicant.getAdditionalDrivers().isEmpty() && getTextFromElement(currentCheckboxElement).contains(DriverReviewPageCheckboxes.MARITAL.getCheckBoxText())) {
                    waitAndClickElement(editDriverDialogCloseLink);
                } else {
                    waitAndClickElement(currentCheckboxElement);
                }
            } catch (Exception e) {
                Log.error(e.getMessage());
            }
        }
    }

    public Locator getEditButtonByDriverFullName(String fullName) throws Exception {
        return waitElementBeVisible(locator(pwCss("[aria-label='" + fullName + " Edit opens in modal dialog box']")));
    }

    private String getLocalDropDownXpathForIncident(boolean isAdditionalIncident) {
        return !isAdditionalIncident ? ACCIDENT_OR_VIOLATION_DROPDOWN_XPATH : ADDITIONAL_INCIDENT_FORM_XPATH + ACCIDENT_OR_VIOLATION_DROPDOWN_XPATH;
    }

    private Locator getLocalInjuryButton() throws Exception {
        List<Locator> injuryElements = locators(pwXPath("//div[contains(@class,'injuries')]//input"));
        waitForUiSettled();
        return injuryElements.get(injuryElements.size() - 1);
    }

    private String getLocalDateInputField(boolean isAdditionalIncident) {
        return isAdditionalIncident ? ADDITIONAL_INCIDENT_FORM_XPATH + ACCIDENT_OR_VIOLATION_DATE_INPUT_FIELD_XPATH : ACCIDENT_OR_VIOLATION_DATE_INPUT_FIELD_XPATH;
    }

    public String getApplicantFullName(AutoApplicant applicant) {
        return getTheFullNameWithFirstLetterInCaps(applicant.getFirstName() + SPACE + applicant.getLastName());
    }

    public String getDriverFullName(SqlAdditionalDriver driver) {
        return getTheFullNameWithFirstLetterInCaps(driver.getFirstName() + SPACE + driver.getLastName());
    }

    private Locator getSpouseToButton(String fullName) throws Exception {
        return locator(pwXPath(String.format("//app-spouse-option[contains(.,'%s')]//input", fullName)));
    }

    private Locator getHadDriversLicenseCheckbox(String fullName) throws Exception {
        Locator driverLicenseAgeCheckbox = locator(pwXPath(getDriverCardXpathByFullName(fullName) + HAD_THEIR_DRIVER_LICENSE_CHECKBOX));
        scrollElementToMiddle(driverLicenseAgeCheckbox);
        return driverLicenseAgeCheckbox;
    }

    private Locator getDriverLicenceAgeInputField(String fullName) throws Exception {
        boolean askingDriverLicenseAgeState = isAskingDriverLicenseAgeState(getSessionStorageAppStore().getData().getLandingStateCode());

        final String AGE_INPUT_FIELD_XPATH = askingDriverLicenseAgeState ? "//input[@formcontrolname='ageFirstLicensed']" : "//input[@formcontrolname='minAgeLicense']";
        return waitElementBeVisible(locator(pwXPath(getDriverCardXpathByFullName(fullName) + AGE_INPUT_FIELD_XPATH)));
    }

    private Locator getDriverLicenseAgeConditionError(String fullName) throws Exception {
        final String AGE_ERROR_XPATH = "//mat-error[contains(@class,'age-license')]";
        return waitElementBeVisible(locator(pwXPath(getDriverCardXpathByFullName(fullName) + AGE_ERROR_XPATH)));
    }

    public void selectGender(String gender) throws Exception {
        waitAndClickElement(locator(pwXPath(String.format("//span[contains(.,'%s')]//ancestor::button", gender))));
    }

    public void selectIsLicensedInUSAOrInCanadaOption(String yesOrNo) throws Exception {
        waitAndClickElement(locator(pwXPath(String.format("//div[contains(@id,'licenseIssued')]//mat-radio-button[.//span[contains(text(),'%s')]]", yesOrNo))));
    }

    public DriverReviewPage selectSpouseAsSecondaryNameInsured(AutoApplicant applicant) throws Exception {
        String pniFullName = getApplicantFullName(applicant);
        String sniFullName = getSniFullName(applicant);
        setMaritalRelationship(pniFullName, sniFullName);
        return this;
    }

    public void selectRandomAdditionalDriverAndAssignToRandomSpouse(AutoApplicant applicant) throws Exception {
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers().stream().filter(additionalDriver -> !additionalDriver.getRelationshipToApplicant().equals(SPOUSE)).collect(Collectors.toList());
        Collections.shuffle(additionalDrivers);
        String spouseOne = additionalDrivers.get(0).getFirstName() + SPACE + additionalDrivers.get(0).getLastName();
        String spouseTwo = additionalDrivers.get(1).getFirstName() + SPACE + additionalDrivers.get(1).getLastName();

        setMaritalRelationship(spouseOne, spouseTwo);
    }

    public void clickOnDriversRevisionHyperlink() {
        waitAndClickElement(driversRevisionHyperlink);
    }

    public void saveQuote(AutoApplicant applicant) throws Exception {
        if (isAutoSaveDisabled()) {
            clickOnSaveQuoteButton();
            enterEmailInSaveQuoteModal(applicant.getEmail());
            isEmailConfirmationDisplayed(applicant.getEmail());
        }
    }

    private Locator getAnotherStateButton(String fullName) throws Exception {
        String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
        String xpathAnotherState = FINANCIAL_FILING_ANOTHER_STATE_BUTTON_XPATH;
        if(landingStateCode.equals(FL)) {
            xpathAnotherState = "//button[contains(.,'Another state')]";
        }
        return locator(pwXPath(getDriverCardXpathByFullName(fullName) + xpathAnotherState));
    }

    public void validateDisplayedOccupations(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        // returning if no available occupation is expected.
        String stateCode = applicant.getStateCode();
        if (isEmploymentDiscountDisabledState(stateCode)) {
            testStep("Skipping this test for the given state as occupation discount is not applicable for the state of " + applicant.getStateCode());
            return;
        }
        new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        isOnDriverReviewPage();
        Locator eligibleOccupations = locator(pwXPath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + SEE_ELIGIBLE_OCCUPATIONS_XPATH));
        waitAndClickElement(eligibleOccupations);
        waitElementBeVisible(eligibleOccupationModalHeader);
        waitForUiSettled();
        List<String> expectedEmployedOccupations = AceAutoSupportedOccupationByState.valueOf(stateCode).getSupportedEmployedOccupations().stream().map(Occupations::getOccupationName).collect(Collectors.toList());
        List<String> expectedRetiredOccupations = AceAutoSupportedOccupationByState.valueOf(stateCode).getSupportedRetiredOccupations().stream().map(Occupations::getOccupationName).collect(Collectors.toList());

        if (expectedEmployedOccupations.contains(MILITARY_PERSONNEL)) {
            clickOnHiddenElement(locator(pwXPath(String.format(OCCUPATION_RADIO_BUTTON_XPATH, Occupations.MILITARY_PERSONNEL.getOccupationName()))));
        }

        List<String> displayedEmployedOccupations = occupationRadioButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        Collections.sort(displayedEmployedOccupations);
        Collections.sort(expectedEmployedOccupations);

        waitAndClickElement(retiredToggle);
        if (expectedEmployedOccupations.contains(MILITARY_PERSONNEL)) {
            clickOnHiddenElement(locator(pwXPath(String.format(OCCUPATION_RADIO_BUTTON_XPATH, Occupations.MILITARY_PERSONNEL.getOccupationName()))));
        }
        Collections.sort(expectedRetiredOccupations);

        if (expectedEmployedOccupations.isEmpty()) {
            fsa.assertEquals(getTextFromElement(discountUnavailable), "We're sorry, but no professional discounts for retirees are currently available.", "discountUnavailable verification");
            fsa.assertEquals(getTextFromElement(locator(pwXPath(REMOVE_STATUS_XPATH))), "Close", "Close button verification");
        }

        List<String> displayedRetiredOccupations = occupationRadioButtons.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        Collections.sort(displayedRetiredOccupations);
        fsa.assertEquals(displayedEmployedOccupations, expectedEmployedOccupations, "List of Employed Occupations verification");
        fsa.assertEquals(displayedRetiredOccupations, expectedRetiredOccupations, "List of Retired Occupations verification");
    }

    public void validateOccupationCodes(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String stateCode = applicant.getStateCode();

        // returning if no available occupation is expected.
        if (isEmploymentDiscountDisabledState(stateCode)) {
            testStep("Skipping this test for the given state as occupation discount is not applicable for the state of " + applicant.getStateCode());
            return;
        }
        new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        isOnDriverReviewPage();
        Locator eligibleOccupations;
        waitForUiSettled();

        List<Occupations> supportedEmployedOccupations = AceAutoSupportedOccupationByState.valueOf(stateCode).getSupportedEmployedOccupations();
        supportedEmployedOccupations = !stateCode.equals(MI) ? supportedEmployedOccupations.stream().filter(occupation -> !occupation.equals(Occupations.MILITARY_PERSONNEL)).collect(Collectors.toList()) : supportedEmployedOccupations;

        // validate occupation codes for employed toggle
        for (int i = 0; i < supportedEmployedOccupations.size(); i++) {
            Occupations occupation = supportedEmployedOccupations.get(i);
            eligibleOccupations = locator(pwXPath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + SEE_ELIGIBLE_OCCUPATIONS_XPATH));
            waitAndClickElement(eligibleOccupations);
            waitElementBeVisible(eligibleOccupationModalHeader);
            String expectedEmployedDescription = occupation.getOccupationName().strip();
            if (clickMilitaryPersonnelIfNeeded(occupation)) {
                if(expectedEmployedDescription.equals(TWENTYFIRST_CENTURY)){
                    expectedEmployedDescription = "21st  Century Employees";
                }
                scrollAndClickOnElement(locator(pwXPath(String.format(OCCUPATION_RADIO_BUTTON_XPATH, expectedEmployedDescription))));
            }
            scrollAndClickOnElement(waitElementBeVisible(addButton));
            wait.until(Conditions.invisible(pwXPath(OCCUPATION_SIDE_PANEL_HEADER_XPATH)));
            // driver license age
            enterDriverLicenseAge(applicant, getApplicantFullName(applicant), applicant.getFirstAgeUnitedStatesDriverLicense());
            enterDriverLicenseAge_CA(getApplicantFullName(applicant), 16);
            addDriverLicenseNumber(applicant, getApplicantFullName(applicant));
            clickContinueButton();
            waitForSpinnerToBeGone();
            if (isSignalDiscountDisabledState(applicant.getStateCode())) {
                new ContactInfoAutoPage().isOnContactInfoAutoPage();
            } else {
                new SignalPageOneUI().isOnSignalPage();
            }
            AppStore.Auto.Driver driver = getSessionStorageAppStore().getAuto().getDrivers().get(0);
            String actualOccupationCode = driver.getFfqOccupationCode().strip();
            String actualOccupationName = driver.getFfqOccupationDescription().strip();
            String expectedEmployedCode = occupation.getEmployedCode();
            if (Arrays.asList(AZ, NM, OR, WI).contains(stateCode)) {
                if (expectedEmployedDescription.equals(EDUCATOR)) {
                    expectedEmployedCode = "HB";
                }
                if (expectedEmployedDescription.equals(FIREFIGHTER)) {
                    expectedEmployedCode = "HF";
                }
                if (expectedEmployedDescription.equals(NURSE)) {
                    expectedEmployedCode = "HI";
                }
                if (expectedEmployedDescription.equals(PHYSICIAN_SURGEON)) {
                    expectedEmployedCode = "HD";
                }
            }

            if (stateCode.equals(MI)) {
                if (expectedEmployedDescription.equals(DENTIST)) {
                    expectedEmployedCode = "DE";
                }
                if (expectedEmployedDescription.equals(EDUCATOR)) {
                    expectedEmployedCode = "FA";
                }
                if (expectedEmployedDescription.equals(ENGINEER)) {
                    expectedEmployedCode = "CC";
                }
                if (expectedEmployedDescription.equals(FARMERS_ZURICH_EMPLOYEE)) {
                    expectedEmployedCode = "G0";
                }
                if (expectedEmployedDescription.equals(NURSE)) {
                    expectedEmployedCode = "EA";
                }
                if (expectedEmployedDescription.equals(PHYSICIAN_SURGEON)) {
                    expectedEmployedCode = "DA";
                }
                if (expectedEmployedDescription.equals(MILITARY_PERSONNEL)) {
                    expectedEmployedCode = "IF";
                }
                if (expectedEmployedDescription.equals(ACCOUNTANT)) {
                    expectedEmployedCode = "AA";
                }


            }

            fsa.assertEquals(actualOccupationCode, expectedEmployedCode, "Occupation code in the DB verification");
            fsa.assertEquals(actualOccupationName, expectedEmployedDescription, "Occupation name in the DB verification");
            back();
            isOnDriverReviewPage();
            removeOccupation();
            isOnDriverReviewPage();
        }

        // validate occupation codes for retired toggle
        List<Occupations> supportedRetiredOccupations = AceAutoSupportedOccupationByState.valueOf(applicant.getStateCode()).getSupportedRetiredOccupations();
        //TODO: this need to be updated for MI state
        supportedRetiredOccupations = !stateCode.equals(MI) ? supportedRetiredOccupations.stream().filter(occupation -> !occupation.equals(Occupations.MILITARY_PERSONNEL)).collect(Collectors.toList()) : supportedRetiredOccupations;
        for (int i = 0; i < supportedRetiredOccupations.size(); i++) {
            Occupations occupation = supportedRetiredOccupations.get(i);
            eligibleOccupations = locator(pwXPath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + SEE_ELIGIBLE_OCCUPATIONS_XPATH));
            waitAndClickElement(eligibleOccupations);
            waitElementBeVisible(eligibleOccupationModalHeader);
            scrollAndClickOnElement(retiredToggle);
            if (clickMilitaryPersonnelIfNeeded(occupation)) {
                scrollAndClickOnElement(locator(pwXPath(String.format(OCCUPATION_RADIO_BUTTON_XPATH, occupation.getOccupationName()))));
            }
            waitAndClickElement(addButton);
            wait.until(Conditions.invisible(pwXPath(OCCUPATION_SIDE_PANEL_HEADER_XPATH)));
            clickContinueButton();
            waitForSpinnerToBeGone();
            new SignalPageOneUI().isOnSignalPage();
            AppStore.Auto.Driver driver = getSessionStorageAppStore().getAuto().getDrivers().get(0);
            String actualOccupationCode = driver.getFfqOccupationCode().strip();
            String actualOccupationName = driver.getFfqOccupationDescription().strip();
            String expectedRetiredCode = occupation.getRetiredCode();
            if (stateCode.equals(MI)) {
                if (actualOccupationName.equals(DENTIST)) {
                    expectedRetiredCode = "DE";
                }
                if (actualOccupationName.equals(EDUCATOR)) {
                    expectedRetiredCode = "FA";
                }
                if (actualOccupationName.equals(ENGINEER)) {
                    expectedRetiredCode = "CC";
                }
                if (actualOccupationName.equals(FARMERS_ZURICH_EMPLOYEE)) {
                    expectedRetiredCode = "R0";
                }
                if (actualOccupationName.equals(NURSE)) {
                    expectedRetiredCode = "EA";
                }
                if (actualOccupationName.equals(MILITARY_PERSONNEL)) {
                    expectedRetiredCode = "R9";
                }
                if (actualOccupationName.equals(PHYSICIAN_SURGEON)) {
                    expectedRetiredCode = "DA";
                }
            }
            fsa.assertEquals(actualOccupationCode, expectedRetiredCode, "Retired occupation code in the DB fverification");
            fsa.assertEquals(actualOccupationName, occupation.getOccupationName(), "Retired Occupation name in the DB verification");
            back();
            isOnDriverReviewPage();
            removeOccupation();
            isOnDriverReviewPage();
        }

    }

    public void enterDriverLicenseAge(AutoApplicant applicant, String fullName, int firstAgeUnitedStatesDriverLicense) throws Exception {
        String stateCode = applicant.getStateCode();
        if(stateCode.equals(CA)) {
            return;
        }
        if (isAskingDriverLicenseAgeState(stateCode)) {
            String inputBy = pwXPath(getDriverCardXpathByFullName(fullName) + LICENSE_AGE_INPUT_FIELD_XPATH);
            if(!isElementPresent(inputBy, 2)) {
                return;
            }
            Locator licenseAgeInputField = locator(inputBy);
            scrollElementToMiddle(licenseAgeInputField);
            waitAndClickElement(licenseAgeInputField);
            sendKeysToElement(licenseAgeInputField, firstAgeUnitedStatesDriverLicense);
            sendKeysToElement(licenseAgeInputField, Keys.TAB);
           // wait.until(Conditions.attributeContains(licenseAgeInputField, CLASS, NG_VALID));
        }
    }

    public void enterDriverLicenseAge_CA(String fullName, int licensedAge) throws Exception {
        if(!getSessionStorageAppStore().getData().getLandingStateCode().equals(CA)) {
            return;
        }
        String driverCardXpathByFullName = getDriverCardXpathByFullName(fullName);
        Locator ageElementForGivenDriver = locator(pwXPath(getDriverCardXpathByFullName(fullName) + DRIVER_AGE_XPATH_END));
        int driverAge = Integer.parseInt(getTextFromElement(ageElementForGivenDriver).replaceAll("[^\\d]", EMPTY_STRING));
        String localToggleXpath;
        String localInputFieldXpath;
        String keyToSend = EMPTY_STRING + licensedAge;
        if (driverAge - 16 < 4) {
            localToggleXpath = LICENSING_INFO_US_NO_TOGGLE_XPATH;
            LocalDate now = LocalDate.now();
            LocalDate oneMonthAgo = now.minusMonths(1);
            localInputFieldXpath = LICENSING_INFO_US_DL_DATE_INPUT_XPATH;
            keyToSend = oneMonthAgo.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));

        } else {
            localInputFieldXpath = LICENSING_INFO_US_DL_AGE_INPUT_XPATH;
            localToggleXpath = LICENSING_INFO_US_YES_TOGGLE_XPATH;
        }

        String toggleBy = pwXPath(driverCardXpathByFullName + localToggleXpath + "//button");
        if (!isElementPresent(toggleBy, 1)) {
            return; // for given driver licensing info is not available
        }
        Locator toggle = locator(toggleBy);
        clickElement(toggle);
        try {
            wait.until(d -> isButtonSelected(toggle));
        } catch (TimeoutError toe) {
            Log.warn(toe.getMessage());
            clickElement(toggle);
        }

        executeScript("arguments[0].dispatchEvent(new Event('change'));", toggle);
        String inputBy = pwXPath(driverCardXpathByFullName + localInputFieldXpath);
        wait.until(Conditions.visible(inputBy));
        Locator inputField = locator(inputBy);
        scrollElementToMiddle(inputField);
        executeScript(String.format("arguments[0].value = '%s';", keyToSend), inputField);
        executeScript("arguments[0].dispatchEvent(new Event('input'));", inputField);
        executeScript("arguments[0].dispatchEvent(new Event('change'));", inputField);
        wait.until(Conditions.attributeContains(inputField, CLASS, "ng-valid"));
        Log.info("Entered dl age for " + fullName + ". Dl age: " + keyToSend);
    }

    private boolean clickMilitaryPersonnelIfNeeded(Occupations occupation) throws Exception {
        boolean militaryJob = AceAutoSupportedOccupationByState.Constants.ONLY_MILITARY_PERSONNEL.contains(occupation);
        if (militaryJob) {
            clickOnHiddenElement(locator(pwXPath("//mat-radio-button[contains(.,'Military Personnel')]//input")));
            if (!occupation.equals(Occupations.MILITARY_PERSONNEL)) {
                scrollAndClickOnElement(locator(pwXPath(String.format(OCCUPATION_RADIO_BUTTON_XPATH, occupation.getOccupationName()))));
            }
        }
        return !militaryJob;
    }


    private boolean isNonBinaryGenderDisplayExpected(String stateCode) {
        //TODO: Update the list with all states that require Nonbinary as a gender option
        List<String> genderNonBinaryExpectedStates = new ArrayList<>(Arrays.asList(AR, AZ, CO, CT, GA, ID, IL, MI, MO, ND, NE, NJ, NM, OK, OR, PA, SD, TN, UT, TX, VA, WI, WY));
        return genderNonBinaryExpectedStates.contains(stateCode);
    }

    public void validateDriverLicenseAgeSection(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        List<String> displayedDriversFullNames = getDisplayedDrivers();

        for (String displayedDriversFullName : displayedDriversFullNames) {
            if (isADATestingEnabled()) {
                waitAndClickElement(continueButton);
                performADATesting(this.getClass().getSimpleName() + "_DriversAgeExposed", MARKETING_IT, ACE_AUTO);
                testStep("Driver Review page drivers age section exposed for ADA testing");
                return;
            }
            String currentDriverFullName = displayedDriversFullName;
            if (applicant.getStateCode().equals(CA)) {
                validateLicensingInfoSection(applicant, currentDriverFullName, fsa);
                return;
            }
            validateHelpInfoContentForDriverAgeSection(fsa);

            Locator currentDriverAgeInputField = getDriverLicenceAgeInputField(currentDriverFullName);
            scrollToElement(currentDriverAgeInputField);
            Locator notPermitMessage = locator(pwXPath("//strong[contains(.,'First full license')]"));

            // make sure message for valid entry is displayed
            waitAndClickElement(currentDriverAgeInputField);
            sendKeysToElement(currentDriverAgeInputField, 15);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(notPermitMessage)), "First full license, not learner's permit", "notPermitMessage verification");

            // validate error message if user enter less than 15
            sendKeysToElement(currentDriverAgeInputField, 14);
            scrollAndClickOnElement(continueButton);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(driverLicenseAgeError.nth(0))), PLEASE_ENTER_VALID_AGE, "age<15 driverLicenseAgeError verification");

            // validate error message if user enters higher than their age
            Locator ageElementForCurrentDriver = locator(pwXPath(getDriverCardXpathByFullName(currentDriverFullName) + DRIVER_AGE_XPATH_END));
            int invalidHighAge = Integer.parseInt(getTextFromElement(ageElementForCurrentDriver).replaceAll("[^\\d.]", "")) + 1;
            scrollToElement(currentDriverAgeInputField);
            sendKeysToElement(waitElementBeVisible(currentDriverAgeInputField), invalidHighAge);
            waitAndClickElement(continueButton);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(driverLicenseAgeError.nth(0))), "Age cannot be more than your current age", "invalid age driverLicenseAgeError verification");
            sendKeysToElement(currentDriverAgeInputField, 15);
            isOnDriverReviewPage();
        }
    }

    private void validateLicensingInfoSection(AutoApplicant applicant, String driverFullName, FarmersSoftAssert fsa) throws Exception {
        // validate the absence of driver licensing info section if user selected No for US/CA driver license on Who Should We Insure Page
        if (applicant.getFirstAgeForeignDriverLicense() == 18) {
            validateAbsenceOfForeignDlSection(getApplicantFullName(applicant), fsa);
        }
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();
        for (int i = 0; i < additionalDrivers.size(); i++) {
            SqlAdditionalDriver driver = additionalDrivers.get(i);
            if (driver.getLicenseToDriveInUSA().equals(NO)) {
                validateAbsenceOfForeignDlSection(getDriverFullName(driver), fsa);
            }
        }
        validateHelpInfoContentForLicensingInfoSection(applicant, fsa);
        validateLabelsForLicensingInfoSection(applicant, fsa);
        validateLicensingInfoSectionRulesAndErrorMessages(applicant, fsa);
    }

    private void validateAbsenceOfForeignDlSection(String fullName, FarmersSoftAssert fsa) throws Exception {
        fsa.assertTrue(!isElementPresent(pwXPath(getDriverCardXpathByFullName(fullName) + LICENSING_INFO_HEADER_XPATH), 2), "Driver licensing info section for " + fullName + " should not be visible for a driver with Foreign DL selected on who should insure page");
    }

    public void validateDriverLicenseNumberInputSection(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        new AceAutoNavigationHelper().navigateToDriverReviewPage(applicant);
        List<Locator> dlInputFields = locators(pwXPath(DRIVER_LICENSE_NUMBER_INPUT_XPATH));
        int numberOfElements = dlInputFields.size();
        for (int i = 0; i < numberOfElements; i++) {
            String xpathForErrorMessage = getDriverCardXpathByFullName(i == 0 ? getApplicantFullName(applicant) : getDriverFullName(applicant.getAdditionalDrivers().get(0))) + DRIVER_LICENSE_NUMBER_INPUT_ERROR_XPATH;
            String xpathForDlNumberInputField = getDriverCardXpathByFullName(i == 0 ? getApplicantFullName(applicant) : getDriverFullName(applicant.getAdditionalDrivers().get(0))) + DRIVER_LICENSE_NUMBER_INPUT_XPATH;

            if (isADATestingEnabled()) {
                waitAndClickElement(continueButton);
                performADATesting(this.getClass().getSimpleName() + "_DriverLicenseInput", MARKETING_IT, ACE_AUTO);
                testStep("Driver Review page drivers license section exposed for ADA testing");
                return;
            }
            // validate help info section
            validateHelpInfoContentForDriverLicenseSection(fsa);
            Locator currentDlEntryField = locator(pwXPath(xpathForDlNumberInputField));
            scrollToElement(currentDlEntryField);

            // validate no entry error message
            currentDlEntryField.fill("");
            scrollAndClickOnElement(continueButton);
            String expectedNoInputErrorMessage = "License # not valid for this state.";
            isElementPresent(pwXPath(xpathForErrorMessage), 2);
            fsa.assertEquals(getTextFromElement(locator(pwXPath(xpathForErrorMessage))), expectedNoInputErrorMessage, "driverLicenseNumberInputError no entry verification");

            // validate invalid entry error message
            String expectedInvalidEntryErrorMessage = "License # not valid for this state.";
            Faker faker = new Faker();
            String stateCode = applicant.getStateCode();
            String validDl = faker.drivingLicense().drivingLicense(stateCode);
            String invalidDl = validDl + "ABS";
            scrollElementToMiddle(currentDlEntryField);
            waitAndClickElement(currentDlEntryField);
            sendKeysToElement(currentDlEntryField, invalidDl);
            waitForSpinnerToBeGone();
            scrollAndClickOnElement(continueButton);
            waitForSpinnerToBeGone();
            isElementPresent(pwXPath(xpathForErrorMessage), 2);
            fsa.assertEquals(getTextFromElement(locator(pwXPath(xpathForErrorMessage))), expectedInvalidEntryErrorMessage, "driverLicenseNumberInput Error no entry verification");

            // validate valid entry
            scrollElementToTop(currentDlEntryField);
            sendKeysToElement(currentDlEntryField, validDl);
            waitForSpinnerToBeGone();
            scrollAndClickOnElement(continueButton);
            waitForSpinnerToBeGone();
            fsa.assertTrue(wait.until(Conditions.attributeContains(currentDlEntryField, CLASS, NG_VALID)), "Make sure input field is valid for DL number");
        }

        validateDuplicateErrorMessageIsDisappearedWhenCorrected(applicant, fsa);

        validateDuplicateErrorMessageIsNotImpactingOtherFields(applicant, fsa);

    }

    private void validateDuplicateErrorMessageIsDisappearedWhenCorrected(AutoApplicant applicant, FarmersSoftAssert softAssert) throws Exception {
        refreshPage();
        Locator pniDlInputField = locator(pwXPath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + DL_LICENSE_NUMBER_INPUT_FIELD_XPATH));
        Locator sniDlInputField = locator(pwXPath(getDriverCardXpathByFullName(getDriverFullName(applicant.getAdditionalDrivers().get(0))) + DL_LICENSE_NUMBER_INPUT_FIELD_XPATH));
        String duplicateDl = "M12343423";
        scrollElementToTop(pniDlInputField);
        sendKeysToElement(pniDlInputField, duplicateDl);
        waitForSpinnerToBeGone();
        sendKeysToElement(sniDlInputField, duplicateDl);
        waitForSpinnerToBeGone();
        scrollAndClickOnElement(continueButton);
        waitForSpinnerToBeGone();
        //reclick in case one click is not registered due to any reason to make sure error message is displayed
        scrollAndClickOnElement(continueButton);
        waitForSpinnerToBeGone();

        // validate duplicate error message
        String sniErrorMessageXpath = getDriverCardXpathByFullName(getDriverFullName(applicant.getAdditionalDrivers().get(0))) + DRIVER_LICENSE_NUMBER_INPUT_ERROR_XPATH;
        String pniErrorMessageXpath = getDriverCardXpathByFullName(getApplicantFullName(applicant)) + DRIVER_LICENSE_NUMBER_INPUT_ERROR_XPATH;
        String expectedDuplicateErrorMessage = "Duplicate license number entered.";
        softAssert.assertTrue(isElementPresent(pwXPath(sniErrorMessageXpath), 2), "Duplicate license number error message should be displayed for SNI when duplicate DL number is entered");
        softAssert.assertTrue(isElementPresent(pwXPath(pniErrorMessageXpath), 2), "Duplicate license number error message should be displayed for PNI when duplicate DL number is entered");
        softAssert.assertEquals(getTextFromElement(locator(pwXPath(sniErrorMessageXpath))), expectedDuplicateErrorMessage, "Duplicate license number error message should be displayed for SNI when duplicate DL number is entered");
        softAssert.assertEquals(getTextFromElement(locator(pwXPath(pniErrorMessageXpath))), expectedDuplicateErrorMessage, "Duplicate license number error message should be displayed for PNI when duplicate DL number is entered");

        // validate error message is disappeared when corrected
        scrollElementToTop(sniDlInputField);
        sendKeysToElement(sniDlInputField, "M12343424");
        waitForSpinnerToBeGone();
        scrollAndClickOnElement(continueButton);
        softAssert.assertTrue((driverLicenseNumberInputError.count() == 0), "Duplicate license number error message should be disappeared once corrected");

    }

    private void validateDuplicateErrorMessageIsNotImpactingOtherFields(AutoApplicant applicant, FarmersSoftAssert softAssert) throws Exception {
        // enter dl ages to avoid error messages related to missing dl age and validate only duplicate error message is displayed when duplicate DL numbers are entered
        enterDriverLicenseAge(applicant, getApplicantFullName(applicant), applicant.getFirstAgeUnitedStatesDriverLicense());
        SqlAdditionalDriver sqlAdditionalDriver = applicant.getAdditionalDrivers().get(0);
        enterDriverLicenseAge(applicant, getDriverFullName(sqlAdditionalDriver), sqlAdditionalDriver.getFirstAgeUnitedStatesDriverLicense());
        Locator pniDlInputField = locator(pwXPath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + DL_LICENSE_NUMBER_INPUT_FIELD_XPATH));
        Locator sniDlInputField = locator(pwXPath(getDriverCardXpathByFullName(getDriverFullName(sqlAdditionalDriver)) + DL_LICENSE_NUMBER_INPUT_FIELD_XPATH));
        String duplicateDl = "M12343423";
        scrollElementToTop(pniDlInputField);
        sendKeysToElement(pniDlInputField, duplicateDl);
        sendKeysToElement(sniDlInputField, duplicateDl);
        scrollAndClickOnElement(continueButton);
        List<Locator> pageErrorMessages = locators(pwTag("mat-error"));

        // validate page only shows duplicate error message and no other error message is displayed
        pageErrorMessages.forEach(each -> {
            String expectedDuplicateErrorMessage = "Duplicate license number entered.";
            softAssert.assertEquals(getTextFromElement(each), expectedDuplicateErrorMessage, "Only duplicate error message should be displayed when duplicate DL numbers are entered");
        });

        // correct duplicate error and validate user can proceed to next step without any issue
        sendKeysToElement(sniDlInputField, "M12343424");
        scrollAndClickOnElement(continueButton);
        softAssert.assertTrue(pageErrorMessages.isEmpty(), "No error message should be displayed once duplicate DL error is corrected");
        if (isSignalDiscountDisabledState(applicant.getStateCode())) {
            new ContactInfoAutoPage().isOnContactInfoAutoPage();
        } else {
            new SignalPageOneUI().isOnSignalPage();
        }
    }

    private void validateHelpInfoContentForDriverAgeSection(FarmersSoftAssert fsa) {
        String expectedHelpInfoHeader = "Driver's license age";
        String expectedAtWhatAgeText = "At what age was this driver first licensed to drive, whether in the United States or in a foreign country?";
        String expectedGapText = "If there has been a gap in licensing, please provide the age this driver first held a license to drive. This includes only a full driver's license, not a learner's permit.";
    	int numberOfElements = driverLicenseAgeInfoHeaderBrowser.count();
        for (int i = 0; i< numberOfElements; i++){
            if (isUseMobileViewEnabled()) {
                scrollToElement(driverLicenseAgeMobileHelpIcon.nth(i));
                waitAndClickElement(driverLicenseAgeMobileHelpIcon.nth(i));
                fsa.assertEquals(getTextFromElement(infoBoxHeader), expectedHelpInfoHeader, "infoBoxHeader verification");
                fsa.assertEquals(getTextFromElement(infoBoxContent), expectedAtWhatAgeText + SPACE + expectedGapText, "infoBoxContent verification");
                waitAndClickElement(infoBoxCloseButton);
            } else {
                scrollToElement(driverLicenseAgeInfoHeaderBrowser.nth(i));
                fsa.assertEquals(getTextFromElement(driverLicenseAgeInfoHeaderBrowser.nth(i)), expectedHelpInfoHeader, "driverLicenseAgeInfoHeaderBrowser verification");
                fsa.assertEquals(getTextFromElement(driverLicenseAtWhatAgeBrowser.nth(i)), expectedAtWhatAgeText, "driverLicenseAtWhatAgeBrowser verification");
                fsa.assertEquals(getTextFromElement(driverLicenseGapBrowser.nth(i)), expectedGapText, "driverLicenseGapBrowser verification");
            }
        }

    }

    private void validateHelpInfoContentForLicensingInfoSection(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String expectedHelpInfoHeader = "Licensing Info";
        String expectedAtWhatAgeText = "When was this driver first licensed to drive, both in the U.S. or Canada, and in a foreign country? (This includes a full driver's license, not a learner's permit.)";
        String expectedInYourStateText = "In your state, time licensed in the U.S. or Canada and in a foreign country are important for determining eligibility and rating for the policy.";
        String expectedDiscountText = "Drivers may also be eligible for certain discounts.";
        List<SqlAdditionalDriver> listOfAdditionalDriversWithUSOrCanada = applicant.getAdditionalDrivers().stream().filter(each -> each.getLicenseToDriveInUSA().equals(YES)).collect(Collectors.toList());
        boolean applicantLicensedInUsa = applicant.getFirstAgeForeignDriverLicense() != 18;
        int iteratorCount = listOfAdditionalDriversWithUSOrCanada.size() + (applicantLicensedInUsa ? 1 : 0);
        for (int i = 0; i < iteratorCount; i++) {
            if (isUseMobileViewEnabled()) {
                testStep("Validate \"Licensing info\" field info information mobile breakpoint");
                scrollToElement(driverLicensingInfoMobileHelpIcon.nth(i));
                waitAndClickElement(driverLicensingInfoMobileHelpIcon.nth(i));
                fsa.assertEquals(getTextFromElement(infoBoxHeader), expectedHelpInfoHeader, "Help info header validation mobile");
                fsa.assertEquals(getTextFromElement(infoBoxContent), expectedAtWhatAgeText + SPACE + expectedInYourStateText + SPACE + expectedDiscountText, "infoBoxContent verification");
                waitAndClickElement(infoBoxCloseButton);
            } else {
                testStep("Validate \"Licensing info\" field info information desktop breakpoint");
                scrollToElement(driverLicenseInfoInfoHeaderBrowser.nth(i));
                fsa.assertEquals(getTextFromElement(driverLicenseInfoInfoHeaderBrowser.nth(i)), expectedHelpInfoHeader, "Help info header validation");
                String helpInfoContent = getTextFromElement(licensingInfoHelpContent.nth(i));
                fsa.assertTrue(helpInfoContent.contains(expectedAtWhatAgeText), expectedAtWhatAgeText + " : contained in the help info content");
                fsa.assertTrue(helpInfoContent.contains(expectedInYourStateText), expectedInYourStateText + " : contained in the help info content");
                fsa.assertTrue(helpInfoContent.contains(expectedDiscountText), expectedDiscountText + " : contained in the help info content");
            }
        }

    }

    private void validateLabelsForLicensingInfoSection(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        String expectedLicensingInfoSectionHeader = "Licensing Info";
        String expectedLicensingInfoFirstQuestion = "Has this driver been licensed in a U.S. state, U.S. territory, or Canadian province for over 4 years?";
        String expectedLicensingInfoSecondCheckbox = "This driver is (or was) licensed to drive in a foreign country";
        String expectedLicensingInfoSecondQuestion = "Was this driver licensed in another country more than 4 years ago?";
        String dateLicensedInUsOrCaLabel = "Date licensed in U.S or Canada";
        String ageLicensedInUsOrCaLabel = "Age licensed in U.S or Canada";
        String ageLicensedInAnotherCountryLabel = "Age licensed in another country";
        String dateLicensedInAnotherCountryLabel = "Date licensed in another country";
        String fullLicenseNotPermitMessage = "First full license, not learner's permit";
        List<SqlAdditionalDriver> listOfAdditionalDriversWithUSOrCanada = applicant.getAdditionalDrivers().stream().filter(each -> each.getLicenseToDriveInUSA().equals(YES)).collect(Collectors.toList());
        boolean applicantLicensedInUsa = applicant.getFirstAgeForeignDriverLicense() != 18;
        int iteratorCount = listOfAdditionalDriversWithUSOrCanada.size() + (applicantLicensedInUsa ? 1 : 0);
        for (int i = 0; i < iteratorCount; i++) {
            List<String> usCaLicensedDrivers = listOfAdditionalDriversWithUSOrCanada.stream().map(each -> getDriverFullName(each)).collect(Collectors.toList());
            if (applicantLicensedInUsa) {
                usCaLicensedDrivers.add(getApplicantFullName(applicant));
            }
            String currentDriverFullName = usCaLicensedDrivers.get(i);
            String driverCardXpathByFullName = getDriverCardXpathByFullName(currentDriverFullName);
            // validate section header
            fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCardXpathByFullName + LICENSING_INFO_HEADER_XPATH))), expectedLicensingInfoSectionHeader, "Licensing info section header validation");
            // validate section first question /subheader
            fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCardXpathByFullName + LICENSING_INFO_SUB_HEADER_XPATH))), expectedLicensingInfoFirstQuestion, "Licensing info section first question validation");
            Locator usCaYesToggle = locator(pwXPath(driverCardXpathByFullName + LICENSING_INFO_US_YES_TOGGLE_XPATH));
            //validate Yes and No toggles texts
            fsa.assertEquals(getTextFromElement(usCaYesToggle), "Yes", "Licensing info section Yes toggle text validation");
            Locator usCaNoToggle = locator(pwXPath(driverCardXpathByFullName + LICENSING_INFO_US_NO_TOGGLE_XPATH));
            fsa.assertEquals(getTextFromElement(usCaNoToggle), "No", "Licensing info section No toggle text validation");
            waitAndClickElement(usCaYesToggle);
            wait.until(Conditions.attributeContains(usCaYesToggle, CLASS, "checked"));
            // validate Yes toggle section input label and hint validation
            fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCardXpathByFullName + LICENSING_INFO_US_DL_AGE_INPUT_LABEL_XPATH))), ageLicensedInUsOrCaLabel, "Licensing info section age input label text validation");
            fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCardXpathByFullName + LICENSING_INFO_US_DL_AGE_INPUT_HINT_XPATH))), fullLicenseNotPermitMessage, "Licensing info section age input sub message text validation");
            waitAndClickElement(usCaNoToggle);
            // validate No toggle section input label and hint validation
            wait.until(Conditions.attributeContains(usCaNoToggle, CLASS, "checked"));
            fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCardXpathByFullName + LICENSING_INFO_US_DL_DATE_INPUT_LABEL_XPATH))), dateLicensedInUsOrCaLabel, "Licensing info section date input label text validation");
            fsa.assertTrue(isElementPresent(pwXPath(driverCardXpathByFullName + LICENSING_INFO_US_DL_DATE_INPUT_DATE_PICKER_XPATH)), "Date picker for US/CA date input section");
            fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCardXpathByFullName + LICENSING_INFO_US_DL_DATE_INPUT_HINT_XPATH))), fullLicenseNotPermitMessage, "Licensing info section age input sub message text validation");
            // Foreign dl question and checkbox text validation
            Locator foreignDlCheckbox = locator(pwXPath(driverCardXpathByFullName + LICENSING_FOREIGN_DL_QUESTION_CHECKBOX_XPATH));
            clickElement(foreignDlCheckbox);
            wait.until(d -> getAttributeData(foreignDlCheckbox, CLASS).contains(MDC_CHECKBOX_SELECTED));
            fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCardXpathByFullName + LICENSING_FOREIGN_DL_QUESTION_CHECKBOX_LABEL_XPATH))), expectedLicensingInfoSecondCheckbox, "Licensing info section foreign dl checkbox label message text validation");
            fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCardXpathByFullName + LICENSING_FOREIGN_DL_QUESTION_HEADER_XPATH))), expectedLicensingInfoSecondQuestion, "Licensing info section foreign dl question text validation");
            Locator fldYesToggle = locator(pwXPath(driverCardXpathByFullName + LICENSING_INFO_FOREIGN_YES_TOGGLE_XPATH));
            Locator fldNoToggle = locator(pwXPath(driverCardXpathByFullName + LICENSING_INFO_FOREIGN_NO_TOGGLE_XPATH));
            fsa.assertEquals(getTextFromElement(fldYesToggle), "Yes", "Licensing info section foreign dl Yes toggle text validation");
            fsa.assertEquals(getTextFromElement(fldNoToggle), "No", "Licensing info section foreign dl No toggle text validation");
            waitAndClickElement(fldYesToggle);
            wait.until(d -> isButtonSelected(fldYesToggle));
            fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCardXpathByFullName + LICENSING_INFO_FOREIGN_DL_AGE_INPUT_LABEL_XPATH))), ageLicensedInAnotherCountryLabel, "Licensing info section foreign dl age input label  text validation");
            fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCardXpathByFullName + LICENSING_INFO_FOREIGN_DL_AGE_INPUT_HINT_XPATH))), fullLicenseNotPermitMessage, "Licensing info section foreign dl age input sub messsage text validation");
            waitAndClickElement(fldNoToggle);
            wait.until(d -> isButtonSelected(fldNoToggle));
            fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCardXpathByFullName + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_LABEL_XPATH))), dateLicensedInAnotherCountryLabel, "Licensing info section foreign dl date input label validation");
            fsa.assertTrue(isElementDisplayed(pwXPath(driverCardXpathByFullName + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_DATE_PICKER)), "Date picker is displayed for foreign dl date input field");
            fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCardXpathByFullName + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_HINT_XPATH))), fullLicenseNotPermitMessage, "Licensing info section foreign dl date input sub message validation");

        }

    }

    private void validateLicensingInfoSectionRulesAndErrorMessages(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {

        List<SqlAdditionalDriver> listOfAdditionalDriversWithUSOrCanada = applicant.getAdditionalDrivers().stream().filter(each -> each.getLicenseToDriveInUSA().equals(YES)).collect(Collectors.toList());
        boolean applicantLicensedInUsa = applicant.getFirstAgeForeignDriverLicense() != 18;
        int iteratorCount = listOfAdditionalDriversWithUSOrCanada.size() + (applicantLicensedInUsa ? 1 : 0);
        for (int i = 0; i < iteratorCount; i++) {
            List<String> usCaLicensedDrivers = listOfAdditionalDriversWithUSOrCanada.stream().map(each -> getDriverFullName(each)).collect(Collectors.toList());
            if (applicantLicensedInUsa) {
                usCaLicensedDrivers.add(getApplicantFullName(applicant));
            }
            String currentDriverFullName = usCaLicensedDrivers.get(i);
            String driverCardXpathByFullName = getDriverCardXpathByFullName(currentDriverFullName);
            int driverAge = Integer.parseInt(getTextFromElement(locator(pwXPath(driverCardXpathByFullName + DRIVER_AGE_XPATH_END))).replaceAll("\\D+", EMPTY_STRING));

            refreshPage();
            isOnDriverReviewPage();
            // validate user is not able to move on without making selection
            waitAndClickElement(continueButton);
            fsa.assertEquals(getTextFromElement(waitElementBeVisible(ctaErrorMessage)), CTA_ERROR_MESSAGE, "Cta error message is shown with not providing licensing info");

            validateRuleValidationsForUS_CA_AgeField(driverCardXpathByFullName, driverAge, fsa);
            validateRuleValidationsForUS_CA_DateField(driverCardXpathByFullName, driverAge, fsa);
            validateRuleValidationsForForeign_AgeField(driverCardXpathByFullName, driverAge, fsa);
            validateRuleValidationsForForeign_DateField(driverCardXpathByFullName, driverAge, fsa);

        }

    }

    private void validateRuleValidationsForUS_CA_AgeField(String driverCard, int driverAge, FarmersSoftAssert fsa) throws Exception {

        // US/CA yes toggle rules validation
        Locator usCaYesToggle = locator(pwXPath(driverCard + LICENSING_INFO_US_YES_TOGGLE_XPATH));
        waitAndClickElement(usCaYesToggle);
        waitForUiSettled();
        Locator usCaAgeInputField = locator(pwXPath(driverCard + LICENSING_INFO_US_DL_AGE_INPUT_XPATH));

        // validate error message for less than 4 years entering 3 years less from driver age
        sendKeysToElement(usCaAgeInputField, (driverAge - 3));
        sendKeysToElement(usCaAgeInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCard + LICENSING_INFO_US_DL_AGE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_ENTER_VALID_AGE, PLEASE_ENTER_VALID_AGE + " : error message should show when user enters less than 4 years ago age");

        //  validate error message should not show for valid age 15 and more (upper end edge case)
        sendKeysToElement(usCaAgeInputField, (driverAge - 4));
        sendKeysToElement(usCaAgeInputField, Keys.TAB);
        fsa.assertTrue(!isElementPresent(pwXPath(driverCard + LICENSING_INFO_US_DL_AGE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_ENTER_VALID_AGE + " : error messgae should NOT show when user enters   4 or more years age ago ");

        // validate less than 15 shows error
        sendKeysToElement(usCaAgeInputField, 14);
        sendKeysToElement(usCaAgeInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCard + LICENSING_INFO_US_DL_AGE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_ENTER_VALID_AGE, PLEASE_ENTER_VALID_AGE + " : error message should show when user enters less than 4 years ago age");


        // validate error message should not show for valid age 15 and more (lower end edge case)
        sendKeysToElement(usCaAgeInputField, 15);
        sendKeysToElement(usCaAgeInputField, Keys.TAB);
        fsa.assertTrue(!isElementPresent(pwXPath(driverCard + LICENSING_INFO_US_DL_AGE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_ENTER_VALID_AGE + " : error messgae should NOT show when user enters   4 or more years age ago ");


    }

    private void validateRuleValidationsForUS_CA_DateField(String driverCard, int driverAge, FarmersSoftAssert fsa) throws Exception {
        // US/CA yes toggle rules validation
        refreshPage();
        isOnDriverReviewPage();
        Locator usCaNoToggle = locator(pwXPath(driverCard + LICENSING_INFO_US_NO_TOGGLE_XPATH));
        waitAndClickElement(usCaNoToggle);
        waitForUiSettled();
        Locator usCaDateInputField = locator(pwXPath(driverCard + LICENSING_INFO_US_DL_DATE_INPUT_XPATH));
        LocalDate now = LocalDate.now();

        // upper edge case
        LocalDate fourYearsAgo = now.minusYears(4); // lower edge case
        LocalDate tomorrow = now.plusDays(4); // upper invalid edge case
        LocalDate fourYearsOneDayAgo = fourYearsAgo.minusDays(1); // lower invalid edge case

        // validate valid upper level edge case
        sendKeysToElement(usCaDateInputField, now.format(DateTimeFormatter.ofPattern("MM-dd-yyyy")));
        sendKeysToElement(usCaDateInputField, Keys.TAB);
        fsa.assertTrue(!isElementPresent(pwXPath(driverCard + LICENSING_INFO_US_DL_DATE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_PROVIDE_VALID_DATE + " : Error message should  NOT show  when valid input for date field");

        // validate upper invalid level
        clearOutFieldUsingBackSpace(usCaDateInputField);
        sendKeysToElement(usCaDateInputField, tomorrow.format(DateTimeFormatter.ofPattern("MM-dd-yyyy")));
        sendKeysToElement(usCaDateInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCard + LICENSING_INFO_US_DL_DATE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_PROVIDE_VALID_DATE, PLEASE_PROVIDE_VALID_DATE + " : Error message should  show when invalid input for date field");

        // validate valid lower edge case
        clearOutFieldUsingBackSpace(usCaDateInputField);
        sendKeysToElement(usCaDateInputField, fourYearsAgo.format(DateTimeFormatter.ofPattern("MM-dd-yyyy")));
        sendKeysToElement(usCaDateInputField, Keys.TAB);
        fsa.assertTrue(!isElementPresent(pwXPath(driverCard + LICENSING_INFO_US_DL_DATE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_PROVIDE_VALID_DATE + " : Error message should  NOT show when valid input for date field");

        // validate lower invalid level
        clearOutFieldUsingBackSpace(usCaDateInputField);
        sendKeysToElement(usCaDateInputField, fourYearsOneDayAgo.format(DateTimeFormatter.ofPattern("MM-dd-yyyy")));
        sendKeysToElement(usCaDateInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCard + LICENSING_INFO_US_DL_DATE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_PROVIDE_VALID_DATE, PLEASE_PROVIDE_VALID_DATE + " : Error message should show when invalid input for date field");

    }

    private void validateRuleValidationsForForeign_AgeField(String driverCard, int driverAge, FarmersSoftAssert fsa) throws Exception {

        // click foreing dl checkbox
        Locator foreignDlCheckbox = locator(pwXPath(driverCard + LICENSING_FOREIGN_DL_QUESTION_CHECKBOX_XPATH));
        scrollAndClickOnElement(foreignDlCheckbox);
        fsa.assertTrue(wait.until(d->isButtonSelected(foreignDlCheckbox)), "Validate foreign dl checkbox is checked");

        // Foreign yes toggle rules validation
        Locator foreignYesToggle = locator(pwXPath(driverCard + LICENSING_INFO_FOREIGN_YES_TOGGLE_XPATH));
        waitAndClickElement(foreignYesToggle);
        fsa.assertTrue(wait.until(d->isButtonSelected(foreignYesToggle)), "Foreign dl issued at least 4 years ago check");

        Locator foreingDlAgeInputField = locator(pwXPath(driverCard + LICENSING_INFO_FOREIGN_DL_AGE_INPUT_XPATH));
        // validate error message for less than 4 years entering 3 years less from driver age
        sendKeysToElement(foreingDlAgeInputField, (driverAge - 3));
        sendKeysToElement(foreingDlAgeInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCard + LICENSING_INFO_FOREIGN_DL_AGE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_ENTER_VALID_AGE, PLEASE_ENTER_VALID_AGE + " : error messgae should show when user enters less than 4 years ago age");

        //  validate error message should not show for valid age 15 and more (upper end edge case)
        sendKeysToElement(foreingDlAgeInputField, (driverAge - 4));
        sendKeysToElement(foreingDlAgeInputField, Keys.TAB);
        fsa.assertTrue(!isElementPresent(pwXPath(driverCard + LICENSING_INFO_FOREIGN_DL_AGE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_ENTER_VALID_AGE + " : error messgae should NOT show when user enters   4 or more years age ago ");

        // validate less than 15 shows error
        sendKeysToElement(foreingDlAgeInputField, 14);
        sendKeysToElement(foreingDlAgeInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCard + LICENSING_INFO_FOREIGN_DL_AGE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_ENTER_VALID_AGE, PLEASE_ENTER_VALID_AGE + " : error messgae should show when user enters less than 4 years ago age");

        // validate error message should not show for valid age 15 and more (lower end edge case)
        sendKeysToElement(foreignYesToggle, 15);
        sendKeysToElement(foreignYesToggle, Keys.TAB);
        fsa.assertTrue(!isElementPresent(pwXPath(driverCard + LICENSING_INFO_US_DL_AGE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_ENTER_VALID_AGE + " : error messgae should NOT show when user enters  4 or more years age ago ");
    }

    private void validateRuleValidationsForForeign_DateField(String driverCard, int driverAge, FarmersSoftAssert fsa) throws Exception {
        // US/CA yes toggle rules validation
        refreshPage();
        isOnDriverReviewPage();

        // click foreing dl checkbox
        Locator foreignDlCheckbox = locator(pwXPath(driverCard + LICENSING_FOREIGN_DL_QUESTION_CHECKBOX_XPATH));
        scrollAndClickOnElement(foreignDlCheckbox);
        wait.until(d->isButtonSelected(foreignDlCheckbox));
        fsa.assertTrue(isButtonSelected(foreignDlCheckbox), "Validate foreign dl checkbox is checked");

        Locator foreignNoToggle = locator(pwXPath(driverCard + LICENSING_INFO_FOREIGN_NO_TOGGLE_XPATH));
        scrollAndClickOnElement(foreignNoToggle);
        fsa.assertTrue(wait.until(d->isButtonSelected(foreignDlCheckbox)), "Validate foreign no toggle checkbox is checked");

        Locator foreignDateInputField = locator(pwXPath(driverCard + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_XPATH));
        LocalDate now = LocalDate.now();

        // upper edge case
        LocalDate fourYearsAgo = now.minusYears(4); // lower edge case
        LocalDate tomorrow = now.plusDays(4); // upper invalid edge case
        LocalDate fourYearsOneDayAgo = fourYearsAgo.minusDays(1); // lower invalid edge case

        // validate valid upper level edge case
        sendKeysToElement(foreignDateInputField, now.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        sendKeysToElement(foreignDateInputField, Keys.TAB);
        fsa.assertTrue(!isElementPresent(pwXPath(driverCard + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_PROVIDE_VALID_DATE + " : Error message should  NOT show  when valid input for date field");

        // validate upper invalid level
        clearOutFieldUsingBackSpace(foreignDateInputField);
        sendKeysToElement(foreignDateInputField, tomorrow.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        sendKeysToElement(foreignDateInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCard + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_PROVIDE_VALID_DATE, PLEASE_PROVIDE_VALID_DATE + " : Error message should  show when invalid input for date field");

        // validate valid lower edge case
        clearOutFieldUsingBackSpace(foreignDateInputField);
        sendKeysToElement(foreignDateInputField, fourYearsAgo.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        sendKeysToElement(foreignDateInputField, Keys.TAB);
        fsa.assertTrue(!isElementPresent(pwXPath(driverCard + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_ERROR_MESSAGE_XPATH), 1), PLEASE_PROVIDE_VALID_DATE + " : Error message should  NOT show when valid input for date field");

        // validate lower invalid level
        clearOutFieldUsingBackSpace(foreignDateInputField);
        sendKeysToElement(foreignDateInputField, fourYearsOneDayAgo.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        sendKeysToElement(foreignDateInputField, Keys.TAB);
        fsa.assertEquals(getTextFromElement(locator(pwXPath(driverCard + LICENSING_INFO_FOREIGN_DL_DATE_INPUT_ERROR_MESSAGE_XPATH))), PLEASE_PROVIDE_VALID_DATE, PLEASE_PROVIDE_VALID_DATE + " : Error message should show when invalid input for date field");
    }

    private void validateHelpInfoContentForDriverLicenseSection(FarmersSoftAssert fsa) {
        String expectedHelpInfoHeader = "Why do you need my driver's license number?";
        String expectedInfoText = "This is required to check your driving history and motor vehicle report.";
    	int numberOfElements = driverLicenseNumberInfoBoxHeaderBrowser.count();
        for (int i = 0; i< numberOfElements; i++){
            if (isUseMobileViewEnabled()) {
                testStep("Validate \"Driver's License Input field help icon\" field mobile breakpoint");
                scrollToElement(driverLicenseNumberInfoBoxMobileIcon.nth(i));
                waitAndClickElement(driverLicenseNumberInfoBoxMobileIcon.nth(i));
                fsa.assertEquals(getTextFromElement(waitElementBeVisible(infoBoxHeader)), expectedHelpInfoHeader, "HelpInfoContentForDriverLicenseSection header verification");
                fsa.assertEquals(getTextFromElement(infoBoxContent), expectedInfoText, "HelpInfoContentForDriverLicenseSection content verification");
                waitAndClickElement(infoBoxCloseButton);
            } else {
                testStep("Validate \"Driver's License Input field help icon\" field browser breakpoint");
                scrollToElement(driverLicenseNumberInfoBoxHeaderBrowser.nth(i));
                fsa.assertEquals(getTextFromElement(driverLicenseNumberInfoBoxHeaderBrowser.nth(i)), expectedHelpInfoHeader, "HelpInfoContentForDriverLicenseSection header verification");
                fsa.assertEquals(getTextFromElement(driverLicenseNumberInfoBoxTextBrowser.nth(i)), expectedInfoText, "HelpInfoContentForDriverLicenseSection content verification");
            }
        }
    }

    public void validateADA_DriverReviewPage() throws Exception {
        if (!isADATestingEnabled()) return;
        isOnDriverReviewPage();
        List<Locator> hadTheirDriverLicenseCheckboxes = locators(pwXPath(HAD_THEIR_DRIVER_LICENSE_CHECKBOX));
        List<Locator> financialFilingCheckboxes = locators(pwXPath(FINANCIAL_RESPONSIBILITY_CHECKBOX_XPATH));
        List<Locator> seeEligibleOccupations = locators(pwXPath(SEE_ELIGIBLE_OCCUPATIONS_XPATH));

        // expose had their dl in last three years input fields
        for (Locator hadTheirDriverLicenseCheckbox : hadTheirDriverLicenseCheckboxes) {
            clickElement(hadTheirDriverLicenseCheckbox);
        }

        if (!(accidentCheckboxes.count() == 0)) {
        	// validate ada for Violation section and then expose accident section
        	Locator accidentCheckbox = accidentCheckboxes.nth(0);
        	waitAndClickElement(accidentCheckbox);
        	wait.until(Conditions.attributeContains(accidentCheckbox, "aria-checked", "true"));
        	List<Locator> violationToggles = locators(pwXPath(VIOLATION_TOGGLE_XPATH));
        	waitAndClickElement(violationToggles.get(0));
        	scrollAndClickOnElement(continueButton);
        	performADATesting(this.getClass().getSimpleName() + "_ViolationToggleSection", MARKETING_IT, ACE_AUTO);
        	// reset back to accident toggle
        	List<Locator> accidentToggles = locators(pwXPath(ACCIDENT_TOGGLES_XPATH));
        	waitAndClickElement(accidentToggles.get(0));
        }

        // expose financial filing checkboxes
        for (Locator financialFilingCheckbox : financialFilingCheckboxes) {
            waitAndClickElement(financialFilingCheckbox);
        }

        scrollAndClickOnElement(continueButton);
        waitElementBeVisible(ctaErrorMessage);

        // ada validation with page as much as exposed
        performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);

        // set values to the default
        for (Locator hadTheirDriverLicenseCheckbox : hadTheirDriverLicenseCheckboxes) {
            waitAndClickElement(hadTheirDriverLicenseCheckbox);
        }

        waitAndClickElement(accidentCheckboxes.nth(0));


        for (Locator financialFilingCheckbox : financialFilingCheckboxes) {
            waitAndClickElement(financialFilingCheckbox);
        }

        // validate ADA for occupation sidesheet if present
        if (!seeEligibleOccupations.isEmpty()) {
            waitAndClickElement(seeEligibleOccupations.get(0));
            waitAndClickElement(retiredToggle);
            if (isElementVisible(addButton, 2)) {
                scrollAndClickOnElement(addButton);
            }
            performADATesting(this.getClass().getSimpleName() + "_OccupationSideSheetRetiredToggle", MARKETING_IT, ACE_AUTO);
            waitAndClickElement(employedToggle);
            scrollAndClickOnElement(addButton);
            performADATesting(this.getClass().getSimpleName() + "_OccupationSideSheetEmployedToggle", MARKETING_IT, ACE_AUTO);
            waitAndClickElement(closeIcon);
        }

        // validate ada for add spouse side sheet
        Locator maritalCheckbox = locator(pwXPath(MARITAL_CHECKBOX_XPATH + "//input"));
        scrollAndClickOnHiddenElement(maritalCheckbox);
        waitElementBeVisible(addDriverHeading);
        waitAndClickElement(listOfSaveButtons.nth(0));
        performADATesting(this.getClass().getSimpleName() + "_AddSpouseSideSheet", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(closeIcon);

        // validate ada for edit button
        Locator editDriverButton = editDriverButtons.nth(0);
        waitAndClickElement(editDriverButton);
        performADATesting(this.getClass().getSimpleName() + "_EditDriverSideSheet", MARKETING_IT, ACE_AUTO);
        waitAndClickElement(closeIcon);


    }

    public void validateGoodStudentOption(AutoApplicant applicant, boolean isDiscountSelected) throws Exception {

        String applicantFullName = getApplicantFullName(applicant);
        String applicantCardXpath = getDriverCardXpathByFullName(applicantFullName);
        String applicantHasGpaCheckboxXpath = applicantCardXpath + GPA_OVER_3_CHECKBOX_XPATH;
        String applicantGPASubTextLblWithLessThan10YearsLicenseXpath = applicantCardXpath + MUST_BE_A_FULL_TIME_STUDENT_AND_LICENSED_LESS_THAN_10_YEARS_XPATH;

        SqlAdditionalDriver sqlAdditionalDriver = applicant.getAdditionalDrivers().get(0);
        String additionalDriverFullName = sqlAdditionalDriver.getFirstName() + SPACE + sqlAdditionalDriver.getLastName();
        String additionalDriverCardXpath = getDriverCardXpathByFullName(additionalDriverFullName);
        String additionalDriverGPACheckboxXpath = additionalDriverCardXpath + GPA_OVER_3_CHECKBOX_XPATH;
        String additionalDriverGPAInputXpath = additionalDriverCardXpath + GPA_OVER_3_INPUT_XPATH;
        String additionalDriverGPASubTextLblXpath = additionalDriverCardXpath + MUST_BE_A_FULL_TIME_STUDENT_LABEL_XPATH;
        String additionalDriverGPASubTextLblWithLessThan10YearsLicenseXpath = additionalDriverCardXpath + MUST_BE_A_FULL_TIME_STUDENT_AND_LICENSED_LESS_THAN_10_YEARS_XPATH;

        String stateCode = applicant.getStateCode();

        testStepAssert(!isElementPresent(pwXPath(applicantHasGpaCheckboxXpath), 1), "Has a GPA over 3.0 checkbox should not displaying for the driver 25 years old or above");

        if (Arrays.asList(NC, MA).contains(stateCode)) {
            if (stateCode.equals(MA)) {
                enterDriverLicenseAge(applicant, applicantFullName, 24);
                enterDriverLicenseAge(applicant, additionalDriverFullName, sqlAdditionalDriver.getFirstAgeUnitedStatesDriverLicense());
                testStepAssert(isElementPresent(pwXPath(applicantGPASubTextLblWithLessThan10YearsLicenseXpath), 1), "Has a GPA over 3.0 subtitle expected");
                testStepAssert(isElementPresent(pwXPath(applicantHasGpaCheckboxXpath), 1), "Has a GPA over 3.0 checkbox should be present when Driver got DL in the last 10 years for the state of MA");
                enterDriverLicenseAge(applicant, applicantFullName, 23);
                testStepAssert(!isElementPresent(pwXPath(applicantGPASubTextLblWithLessThan10YearsLicenseXpath), 1), "Has a GPA over 3.0 subtitle expected");
                testStepAssert(!isElementPresent(pwXPath(applicantHasGpaCheckboxXpath), 1), "Has a GPA over 3.0 checkbox should NOT be present when Driver got DL more or 10 years ago");
            }

            if (stateCode.equals(NC)) {
                addHadDriversLicense(additionalDriverFullName, sqlAdditionalDriver.getFirstAgeUnitedStatesDriverLicense());
            }
            testStepAssert(isElementPresent(pwXPath(additionalDriverGPASubTextLblWithLessThan10YearsLicenseXpath), 1), "Has a GPA over 3.0 subtitle expected");
        } else {
            testStepAssert(isElementPresent(pwXPath(additionalDriverGPASubTextLblXpath), 1), "Has a GPA over 3.0 subtext expected");
        }
        testStepAssert(isElementPresent(pwXPath(additionalDriverGPACheckboxXpath), 1), "Has a GPA over 3.0 checkbox should be displaying for the driver 24 years old or less");

        setMaritalRelationship(applicantFullName, additionalDriverFullName);

        if (!stateCode.equals(MA)) {
            testStepAssert(stateCode.equals(MT) == isElementPresent(pwXPath(additionalDriverGPACheckboxXpath), 1),
                    "Has a GPA over 3.0 checkbox should not be displaying for the married driver regardless of the age except for MT");
        }

        removeMaritalRelation(getMaritalCheckbox(applicantFullName));

        testStepAssert(isElementPresent(pwXPath(additionalDriverGPACheckboxXpath), 1), "Has a GPA over 3.0 checkbox should be displaying for the driver 24 years old or less after removing the marital status");

        if (Arrays.asList(NC, MA).contains(stateCode)) {
            testStepAssert(isElementPresent(pwXPath(additionalDriverGPASubTextLblWithLessThan10YearsLicenseXpath), 1), "Has a GPA over 3.0 subtitle expected");
        } else {
            testStepAssert(isElementPresent(pwXPath(additionalDriverGPASubTextLblXpath), 1), "Has a GPA over 3.0 subtext expected");
        }

        reviewAllDrivers(applicant, Optional.empty());

        // checking the aria checked true/false as reviewAllDrivers is already making selection for good student checkbox
        Locator gpaCheckBox = locator(pwXPath(additionalDriverGPAInputXpath));
        if (isDiscountSelected) {
        	if(isCheckboxNotChecked(gpaCheckBox)) {
                scrollAndClickOnHiddenElement(gpaCheckBox);
        	}
        } else {
            if (isCheckboxChecked(gpaCheckBox)) {
                scrollAndClickOnHiddenElement(gpaCheckBox);
            }
        }
        reviewDiscountSection("Drivers-reviewPage");
        scrollAndClickOnHiddenElement(continueButton);
    }

    public void validateDistantStudentOption(AutoApplicant applicant, boolean discountSelected) throws Exception {

        String stateCode = applicant.getStateCode();
        List<SqlAdditionalDriver> additionalDrivers = applicant.getAdditionalDrivers();

        // additional driver one details and xpaths
        SqlAdditionalDriver twentyFourYearOldDriver = additionalDrivers.stream().filter(driver -> driver.getAge() == 24).collect(Collectors.toList()).get(0);
        String fullNameFor24 = twentyFourYearOldDriver.getFirstName() + SPACE + twentyFourYearOldDriver.getLastName();
        String driverCardFor24 = getDriverCardXpathByFullName(fullNameFor24);
        String distantStudentCheckboxXpathFor24 = driverCardFor24 + DISTANT_STUDENT_XPATH;
        String distantStudentSubtextXpathFor24 = driverCardFor24 + DISTANT_STUDENT_SUBTEXT_XPATH;

        //additional driver two details and xpaths
        SqlAdditionalDriver twentyThreeYearOldDriver = additionalDrivers.stream().filter(driver -> driver.getAge() == 23).collect(Collectors.toList()).get(0);
        String fullNameFor23 = twentyThreeYearOldDriver.getFirstName() + SPACE + twentyThreeYearOldDriver.getLastName();
        String driverCardFor23 = getDriverCardXpathByFullName(fullNameFor23);
        String distantStudentCheckboxXpathFor23 = driverCardFor23 + DISTANT_STUDENT_XPATH;
        String distantStudentSubtextXpathFor23 = driverCardFor23 + DISTANT_STUDENT_SUBTEXT_XPATH;

        // additional driver three details and xpaths
        SqlAdditionalDriver twentyTwoYearOldDriver = additionalDrivers.stream().filter(driver -> driver.getAge() == 22).collect(Collectors.toList()).get(0);
        String fullNameFor22 = twentyTwoYearOldDriver.getFirstName() + SPACE + twentyTwoYearOldDriver.getLastName();
        String driverCardFor22 = getDriverCardXpathByFullName(fullNameFor22);
        String distantStudentCheckboxXpathFor22 = driverCardFor22 + DISTANT_STUDENT_XPATH;
        String distantStudentSubtextXpathFor22 = driverCardFor22 + DISTANT_STUDENT_SUBTEXT_XPATH;

        // additional driver four details and xpaths
        SqlAdditionalDriver twentyOneYearOldDriver = additionalDrivers.stream().filter(driver -> driver.getAge() == 21).collect(Collectors.toList()).get(0);
        String fullNameFor21 = twentyOneYearOldDriver.getFirstName() + SPACE + twentyOneYearOldDriver.getLastName();
        String driverCardFor21 = getDriverCardXpathByFullName(fullNameFor21);
        String distantStudentCheckboxXpathFor21 = driverCardFor21 + DISTANT_STUDENT_XPATH;
        String distantStudentSubtextXpathFor21 = driverCardFor21 + DISTANT_STUDENT_SUBTEXT_XPATH;

        String expectedDistantStudentSubtext;

        if (isFlexState(stateCode)) {
            testStepAssert(isElementPresent(pwXPath(distantStudentCheckboxXpathFor24), 1), "Distant Student Checkbox should be present for 24 years old in FFPA-Flex- states, Please check for " + fullNameFor24);
            testStepAssert(isElementPresent(pwXPath(distantStudentCheckboxXpathFor23), 1), "Distant Student Checkbox should be present for 23 years old in FFPA-Flex- states, Please check for " + fullNameFor23);

            //subtext
            expectedDistantStudentSubtext = "Must be a full-time student";
            testStepAssert(getTextFromElement(locator(pwXPath(distantStudentSubtextXpathFor21))), expectedDistantStudentSubtext, "Flex state distant student subtext validated for " + fullNameFor21);
            testStepAssert(getTextFromElement(locator(pwXPath(distantStudentSubtextXpathFor22))), expectedDistantStudentSubtext, "Flex state distant student subtext validated for " + fullNameFor22);
            testStepAssert(getTextFromElement(locator(pwXPath(distantStudentSubtextXpathFor23))), expectedDistantStudentSubtext, "Flex state distant student subtext validated for " + fullNameFor23);
            testStepAssert(getTextFromElement(locator(pwXPath(distantStudentSubtextXpathFor24))), expectedDistantStudentSubtext, "Flex state distant student subtext validated for " + fullNameFor24);
        } else if (stateCode.equals(CA)) {
            enterDriverLicenseAge(applicant, getApplicantFullName(applicant), applicant.getFirstAgeUnitedStatesDriverLicense());
            enterDriverLicenseAge(applicant, fullNameFor24, 15);
            testStepAssert(!isElementPresent(pwXPath(distantStudentSubtextXpathFor24), 1), "Distant Student checkbox should not be visible when DL obtained 9 or more years ago for " + fullNameFor24);
            enterDriverLicenseAge(applicant, fullNameFor23, 15);
            enterDriverLicenseAge(applicant, fullNameFor22, 16);
            enterDriverLicenseAge(applicant, fullNameFor21, 17);
            testStepAssert(isElementPresent(pwXPath(distantStudentCheckboxXpathFor23), 1), "Distant Student checkbox should be visible when DL obtained 8 or less years ago for " + fullNameFor23);
            testStepAssert(isElementPresent(pwXPath(distantStudentCheckboxXpathFor22), 1), "Distant Student checkbox should be visible when DL obtained 8 or less years ago for " + fullNameFor22);
            testStepAssert(isElementPresent(pwXPath(distantStudentCheckboxXpathFor21), 1), "Distant Student checkbox should be visible when DL obtained 8 or less years ago for " + fullNameFor21);

            // Subtext
            expectedDistantStudentSubtext = "Must be a full-time student and licensed for less than 9 years.";
            testStepAssert(getTextFromElement(locator(pwXPath(distantStudentSubtextXpathFor21))), expectedDistantStudentSubtext, "CA state distant student subtext validated for " + fullNameFor21);
            testStepAssert(getTextFromElement(locator(pwXPath(distantStudentSubtextXpathFor22))), expectedDistantStudentSubtext, "CA state distant student subtext validated for " + fullNameFor22);
            testStepAssert(getTextFromElement(locator(pwXPath(distantStudentSubtextXpathFor23))), expectedDistantStudentSubtext, "CA state distant student subtext validated for " + fullNameFor23);

            setMaritalRelationship(fullNameFor22, fullNameFor21);
            // Distant Student Checkbox should still be visible after marriage as long as
            testStepAssert(isElementPresent(pwXPath(distantStudentCheckboxXpathFor22), 1), "Distant Student checkbox should be visible when DL obtained 8 or less years ago for " + fullNameFor22);
            testStepAssert(isElementPresent(pwXPath(distantStudentCheckboxXpathFor21), 1), "Distant Student checkbox should be visible when DL obtained 8 or less years ago for " + fullNameFor21);
            removeMaritalRelation(getMaritalCheckbox(fullNameFor22));

            // for these states distant student discount is not applicaple
        } else if (Arrays.asList(KY, LA, MA, MS, NC, RI).contains(stateCode)) {
            testStepAssert(!isElementPresent(pwXPath(distantStudentCheckboxXpathFor21), 1), "Distant student checkbox should not be visible for the given state: " + stateCode);
            reviewAllDrivers(applicant, Optional.empty());
            clickContinueButton();
            return;
        } else {
            testStepAssert(!isElementPresent(pwXPath(distantStudentCheckboxXpathFor24), 1), "Distant Student Checkbox should NOT be present for 24 years old in FSPA states, Please check for " + fullNameFor24);
            testStepAssert(!isElementPresent(pwXPath(distantStudentCheckboxXpathFor23), 1), "Distant Student Checkbox should NOT be present for 23 years old in FSPA states, Please check for " + fullNameFor23);

            expectedDistantStudentSubtext = String.format("Must be a full-time student and a child of %s (primary named insured)", applicant.getFirstName());
            testStepAssert(getTextFromElement(locator(pwXPath(distantStudentSubtextXpathFor21))), expectedDistantStudentSubtext, "FSPA state distant student subtext validated for " + fullNameFor21);
            testStepAssert(getTextFromElement(locator(pwXPath(distantStudentSubtextXpathFor22))), expectedDistantStudentSubtext, "FSPA state distant student subtext validated for " + fullNameFor22);

        }

        //these checks applicable to all states for Distant Student Discount
        testStepAssert(isElementPresent(pwXPath(distantStudentCheckboxXpathFor21), 1), "Distant Student Checkbox should be present for 21 years old. Driver fullName: " + fullNameFor21);
        testStepAssert(isElementPresent(pwXPath(distantStudentCheckboxXpathFor22), 1), "Distant Student Checkbox should be present for 22 years old. Driver fullName: " + fullNameFor22);

        // validate marital condition (Not applicaple for CA)
        if (!stateCode.equals(CA)) {
            setMaritalRelationship(fullNameFor22, fullNameFor21);
            testStepAssert(!isElementPresent(pwXPath(distantStudentCheckboxXpathFor22), 1), "Distant Student checkbox should not be visible when DL obtained 8 or less years ago when married for " + fullNameFor22);
            testStepAssert(!isElementPresent(pwXPath(distantStudentCheckboxXpathFor21), 1), "Distant Student checkbox should not be visible when DL obtained 8 or less years ago when married for " + fullNameFor21);
            removeMaritalRelation(getMaritalCheckbox(fullNameFor22));
            testStepAssert(isElementPresent(pwXPath(distantStudentCheckboxXpathFor22), 1), "Distant Student checkbox should be visible when DL obtained 8 or less years ago for " + fullNameFor22);
            testStepAssert(isElementPresent(pwXPath(distantStudentCheckboxXpathFor21), 1), "Distant Student checkbox should be visible when DL obtained 8 or less years ago for " + fullNameFor21);
        }

        if (discountSelected) {
            scrollAndClickOnHiddenElement(locator(pwXPath(getDriverCardXpathByFullName(fullNameFor21) + DISTANT_STUDENT_CHECKBOX_INPUT_XPATH)));
            reviewDiscountSection("Drivers-reviewPage");
        }

        reviewAllDrivers(applicant, Optional.empty());
        clickContinueButton();

    }

    public void validateSharedFamilyCarOption(boolean optionExpected, boolean optionSelected) throws Exception {
        Locator driverAgeElement = waitElementBeVisible(locator(pwXPath("(" + DRIVER_AGE_XPATH_END + ")[2]")));
        String ageText = getTextFromElement(driverAgeElement).trim();
        boolean sharedFamilyCarDisplayed = isElementDisplayed(lblSharesVehicleUsage, 5);
        String expectedModifier = optionExpected ? SPACE : NOT;
        String actualModifier = sharedFamilyCarDisplayed ? SPACE : NOT;
        testStepAssert(sharedFamilyCarDisplayed == optionExpected, "Expected: Shares vehicle usage in household checkbox should" + expectedModifier + "be displayed if driver age<25. Actual: Shares vehicle usage in household checkbox is" + actualModifier + "displayed for driver (" + ageText + ")");
        if (sharedFamilyCarDisplayed && optionSelected) {
            scrollAndClickOnElement(chkSharesVehicleUsage);
        }
    }

    public void enterAgeDriverReceivedTheirLicenseTxt_DriverReviewPage(AutoApplicant applicant) throws Exception {
        if (isAskingDriverLicenseAgeState(applicant.getStateCode())) {
            Locator driverAgeElement = waitElementBeVisible(locator(pwXPath("(" + DRIVER_AGE_XPATH_END + ")[1]")));
            String ageTextTmp = getTextFromElement(driverAgeElement).trim();
            String ageText = ageTextTmp.substring(ageTextTmp.length() - 2);
            int ageLicenseTmp = Integer.parseInt(ageText);
            int ageLicense = ageLicenseTmp - 8;
            Locator licenseAgeInputField = locator(pwXPath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + LICENSE_AGE_INPUT_FIELD_XPATH));
            sendKeysToElement(licenseAgeInputField, Integer.toString(ageLicense));
            sendKeysToElement(licenseAgeInputField, Keys.TAB);
            waitForSpinnerToBeGone();
        }
    }

    public void enterDriverLicenseInfoTxt_DriverReviewPage(AutoApplicant applicant) throws Exception {
        String pniFullName = getApplicantFullName(applicant);
        addDriverLicenseNumber(applicant, pniFullName);
    }

    public void clickHasDriverLicenseForLessThan3YrsChk_DriverReviewPage(AutoApplicant applicant) throws Exception {
        addHadDriversLicense(getApplicantFullName(applicant), applicant.getFirstAgeUnitedStatesDriverLicense());
    }

    public void proceedToQuoteSummaryPage(AutoApplicant applicant) throws Exception {
        if(!isBDQFlowEnabled() && !isOnBristolWest()){
            SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
            if (!signalPageOneUI.isSignalDiscountDisabledState(applicant.getStateCode())) {
                List<SqlDiscount> applicantDiscounts = applicant.getDiscounts();
                if (applicantDiscounts.isEmpty()) {
                    signalPageOneUI.processSignalPage(false);
                } else {
                    signalPageOneUI.processSignalPage(applicantDiscounts.get(0).isSignalSignup());
                }
            }
        }

        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        contactInfoAutoPage.isOnContactInfoAutoPage();
        contactInfoAutoPage.setValuesAndContinue(applicant);
        contactInfoAutoPage.waitForSpinnerToBeGone();
        QuoteSummaryAutoPage quoteSummaryAutoPage = new QuoteSummaryAutoPage();
        if (quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            return;
        }
        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            String stateCode = applicant.getStateCode();
            if (stateCode.equals(VA)) {
                vehicleDriverAssignmentPage.assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
            } else if (Arrays.asList(CA,NC).contains(stateCode)) {
                vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
            }
        }
        SelectAQuoteToReviewPage selectAQuoteToReviewPage = new SelectAQuoteToReviewPage();
        if (selectAQuoteToReviewPage.isOnSelectAQuoteToReviewPage()) {
            selectAQuoteToReviewPage.clickContinueMyQuote();
        }
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if(bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            bwFarmersQuotePresentmentPage.continueWithFarmers();
        }
        if (!quoteSummaryAutoPage.isOnQuoteSummaryAutoPage()) {
            throw new IllegalStateException("Did not reach QuoteSummaryAutoPage");
        }
    }

    public void fillOutDriverLicenseAges() throws Exception {
        if (getSessionStorageAppStore().getData().getLandingStateCode().equals(CA)) {
            List<String> displayedDrivers = getDisplayedDrivers();
            for (String displayedDriver : displayedDrivers) {
                enterDriverLicenseAge_CA(displayedDriver, 16);
            }
        }
        List<Locator> ageInputElements = locators(pwXPath(LICENSE_AGE_INPUT_FIELD_XPATH));
        for (Locator ageInputElement : ageInputElements) {
            scrollToElement(ageInputElement);
            sendKeysToElement(ageInputElement, 16);
        }

    }

    public List<String> getDisplayedDrivers() throws Exception {
        List<String> driversList = new ArrayList<>();
        for (Locator element : locators(pwXPath(LIST_OF_DRIVERS_XPATH))) {
            driversList.add(getTextFromElement(element));
        }
        return driversList;
    }

    public void validateDisplayedDrivers_ADPFData(ADPFApplicant applicant) throws Exception {
        if (isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
            Log.info("Vehicles Drivers consolidation is implemented for state: " + applicant.getStateCode() + ", skipping ADPF data validation on Drivers page.");
            return;
        }
        HeresWhatWeFoundPage heresWhatWeFoundPage = new AceAutoNavigationHelper().navigateToHeresWhatWeFoundPage(applicant);
        String applicantFullName = applicant.getFirstName() + SPACE + applicant.getLastName();
        heresWhatWeFoundPage.addADPFApplicant(Optional.empty(), applicantFullName, applicant.getGender(), applicant.getDateOfBirth());
        List<String> displayedCompleteDrivers = heresWhatWeFoundPage.getDisplayedCompleteDrivers();
        testStep("The displayed drivers from Here's what we found page is captured", true);
        heresWhatWeFoundPage.clickContinueButton();
        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        vehicleReviewPage.isOnVehiclesReviewPage();
        vehicleReviewPage.clickContinueButton();
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        testStepAssert(isOnDriverReviewPage(), "User is on the driver review page");
        List<String> displayedDriversOnDriversPage = driverReviewPage.getDisplayedDrivers();
        Log.info("List of complete drivers returned from adpf: " + displayedCompleteDrivers);
        Log.info("List of driver review page dispalyed drivers: " + displayedDriversOnDriversPage);
        testStepAssert(displayedCompleteDrivers.equals(displayedDriversOnDriversPage), "Validate multiple Drivers scenario- PNI +Spouse+Additional driver - ADPF(test scenario)", true);
    }

    public void validateDisplayedDrivers_NonAdpf(AutoApplicant applicant) throws Exception {
        applicant.setOccupation(EMPTY_STRING);
        WhoShouldWeInsurePage whoShouldWeInsurePage = (WhoShouldWeInsurePage) new AceAutoNavigationHelper().navigateToWhoShouldWeInsureOrHeresWhatWeFoundPage(applicant);
        whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
        whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
        whoShouldWeInsurePage.enterEmailAndPhoneNumber(applicant);
        List<String> displayedCompleteDriversWSWIPage = whoShouldWeInsurePage.getDisplayedCompleteDrivers();
        Log.info("Who Should We Insure page displayed vehicles: " + displayedCompleteDriversWSWIPage);
        testStep("Drivers from Who Should we insure page is captured", true);
        whoShouldWeInsurePage.clickOnContinueButton();
        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        vehicleReviewPage.isOnVehiclesReviewPage();
        vehicleReviewPage.setVehicleUsagesToPersonal();
        vehicleReviewPage.clickContinueButton();
        testStepAssert(isOnDriverReviewPage(), "User is on Driver Review page");
        reviewAllDrivers(applicant, Optional.empty());
        List<String> displayedDriversOnDriverReviewPage = getDisplayedDrivers();
        Log.info("Driver review page displayed vehicles: " + displayedDriversOnDriverReviewPage);
        testStepAssert(displayedCompleteDriversWSWIPage.equals(displayedDriversOnDriverReviewPage), "Validate multiple Drivers scenario- PNI +Spouse+Additional driver - Non- ADPF(test scenario)");

    }

    public void fillOutDriverLicenseNumbers() throws Exception {
        List<Locator> driverLicenseNumbersInputFields = locators(pwXPath(DRIVER_LICENSE_NUMBER_INPUT_XPATH));
        for (Locator inputFields : driverLicenseNumbersInputFields) {
            Faker faker = new Faker();
            scrollToElement(inputFields);
            String driverLicenseNumber = faker.drivingLicense().drivingLicense(getSessionStorageAppStore().getData().getLandingStateCode());
            sendKeysToElement(inputFields, driverLicenseNumber);
            sendKeysToElement(inputFields, Keys.TAB);
            waitForSpinnerToBeGone();
        }
    }

    private void updateIncidentsWithSessionStorageData(List<SqlIncident> incidents) throws Exception {
        List<String> accidentsAvailable = getSessionStorageAppStore().getAuto().getDriverReview().getFetchIncidentCategoryList().getIncidentTypeACC().getDropDownValues().stream().map(each -> each.getWebDesc()).collect(Collectors.toList());
        List<String> violationsAvailable = getSessionStorageAppStore().getAuto().getDriverReview().getFetchIncidentCategoryList().getIncidentTypeUCC().getDropDownValues().stream().map(each -> each.getWebDesc()).collect(Collectors.toList());
        for (SqlIncident incident : incidents) {
            if (incident.getIncidentType().equals(ACCIDENT)) {
                int randomIndex = new Random().nextInt(accidentsAvailable.size());
                String description = accidentsAvailable.get(randomIndex);
                if (description.equals("Accident was not driver's fault")) {
                    description = "Accident was not driver";
                }
                if (description.equals("At-fault accident resulting in Property Damage")) {
                    description = "fault accident resulting in Property Damage";
                }
                incident.setDescription(description);
            } else {
                int randomIndex = new Random().nextInt(violationsAvailable.size());
                incident.setDescription(violationsAvailable.get(randomIndex));
            }
        }
    }


    public void validateNonDriverFunctionality(AutoApplicant applicant, FarmersSoftAssert fsa, boolean randomWillBeDriving, boolean randomForeignDl) throws Exception {
        String stateCode = applicant.getStateCode();
        isOnDriverReviewPage();
        clickElement(getMaritalCheckbox(getApplicantFullName(applicant)));
        if (isElementPresent(pwXPath("//label[contains(.,'someone not listed here')]//ancestor::mat-radio-button//input"), 1)) {
            getAndClickSpouseTo("someone not listed here");
        }

        fsa.assertEquals(getTextFromElement(addDriverHeading), "Add a spouse", "Spouse side sheet header verification");
        enterSpouseInformation(applicant, randomWillBeDriving, randomForeignDl);
        AppStore.Auto.Driver sni = getSessionStorageAppStore().getAuto().getDrivers().stream().filter(each -> each.getPni().equals("X")).collect(Collectors.toList()).get(0);
        String spouseFullName = sni.getFirstName() + SPACE + sni.getLastName();

        fsa.assertTrue(isSnackBarMessageDisplayed("Your spouse has been added to policy."), "Your spouse has been added to policy snackbar showing correclty");
        waitAndClickElement(getEditButtonByDriverFullName(spouseFullName));
        for (Locator saveButton : listOfSaveButtons.all()) {
            waitForUiSettled();
            waitAndClickElement(saveButton);
        }
        testStep("Snackabr for spouse info adjustment", true);
        wait.until(Conditions.visible(snackBar));
        fsa.assertTrue(isSnackBarMessageDisplayed("Your spouse has been updated."), "Your spouse has been updated snackbar showing correctly");
        String nonDriverLabelXpath = "//span[@class='non-driver-label ng-star-inserted']";

        String driverCardXpathByFullName = getDriverCardXpathByFullName(spouseFullName);
        fsa.assertEquals(!randomWillBeDriving, isElementPresent(pwXPath(driverCardXpathByFullName + nonDriverLabelXpath), 2), "Non Driver label presence validation");

        //validate accident checkbox and occupation field is present for the spouse

        fsa.assertEquals(!isEmploymentDisabledState(stateCode) && randomWillBeDriving, isElementPresent(pwXPath(driverCardXpathByFullName + SEE_ELIGIBLE_OCCUPATIONS_XPATH), 1), "See eligible occupation link presence validated");
        int displayedDriverSizeOnDriverReviewPage = getDisplayedDrivers().size();
        fsa.assertEquals(randomWillBeDriving, accidentQuestions.count() == displayedDriverSizeOnDriverReviewPage, "Accident checkbox presence validated");


        if(displayedDriverSizeOnDriverReviewPage > 2) {
            // ad spouse for additional driver
            List<String> displayedDrivers = getDisplayedDrivers();
            displayedDrivers.remove(getApplicantFullName(applicant));
            displayedDrivers.remove(spouseFullName);
            clickElement(getMaritalCheckbox(displayedDrivers.get(0)));
            if (isElementPresent(pwXPath("//label[contains(.,'someone not listed here')]//ancestor::mat-radio-button//input"), 1)) {
                getAndClickSpouseTo("someone not listed here");
            }
            fsa.assertEquals(getTextFromElement(addDriverHeading), "Add a spouse", "Spouse side sheet header validation");
            enterSpouseInformation(applicant, randomWillBeDriving, randomForeignDl);
        }
        displayedDriverSizeOnDriverReviewPage = getDisplayedDrivers().size();

        List<String> drivingDrivers = getDisplayedDrivers().stream().filter(each -> !each.contains("Non-Driver")).collect(Collectors.toList());
        for (String drivingDriver : drivingDrivers) {
            enterDriverLicenseAge_CA(drivingDriver, 16);
        }

        // fill out occupation section if present
        fillOutOccupationAffinitySection();

        clickContinueButton();
        SignalPageOneUI signalPageOneUI = new SignalPageOneUI();
        if (!signalPageOneUI.isSignalDiscountDisabledState(stateCode)) {
            signalPageOneUI.processSignalPage(applicant.getDiscounts().get(0).isSignalSignup());
        }
        ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
        contactInfoAutoPage.setValuesAndContinue(applicant);

        VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
        if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
            vehicleDriverAssignmentPage.clickOnFirstVehicleMatSelection();
            List<String> displayedDriverList = vehicleDriverAssignmentPage.getAvailableDriverMatOptions().all().stream().map(this::getTextFromElement).collect(Collectors.toList());
            fsa.assertEquals(randomWillBeDriving, (displayedDriverList.contains(spouseFullName) && displayedDriverList.size() == displayedDriverSizeOnDriverReviewPage), "Is driver spouse listed as an option in the vehicle driver assignment page check");
            refreshPage();
            vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
        }
        BwFarmersQuotePresentmentPage bwFarmersQuotePresentmentPage = new BwFarmersQuotePresentmentPage();
        if (bwFarmersQuotePresentmentPage.isOnBwFarmersQuotePresentmentPage()) {
            bwFarmersQuotePresentmentPage.continueWithFarmers();
        }
        ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
        if (continueWithBristolWestPage.isOnContinueWithBristolWestPage()) {
            continueWithBristolWestPage.continueWithBwPopUp();
        }
    }

    public void validateIsRideShareDriverCheckbox(FarmersSoftAssert fsa, boolean isCheckboxExpected) throws Exception {
        List<String> displayedDrivers = getDisplayedDrivers();
        for (String displayedDriver : displayedDrivers) {
            String currentDriverIsRideShareBy = pwXPath(getDriverCardXpathByFullName(displayedDriver) + IS_A_RIDE_SHARE_XPATH);
            if(isCheckboxExpected) {
                fsa.assertEquals(getTextFromElement(locator(currentDriverIsRideShareBy)), "Is a rideshare driver", "RideShareDriverCheckbox verification");
                scrollAndClickOnHiddenElement(continueButton);
                fsa.assertEquals(getTextFromElement(ctaErrorMessage), "For Rideshare coverage, at least one driver must be selected as a Rideshare driver", "RideShareDriver error verification");
            } else {
                fsa.assertTrue(!isElementDisplayed(currentDriverIsRideShareBy), "Rideshare driver checkbox should not be displayed");
            }
        }
    }

    public void clickIsRideShareDriverCheckbox(String fullName) throws Exception {
        Locator isRideShareDriverCheckbox = locator(pwXPath(getDriverCardXpathByFullName(fullName) + IS_A_RIDE_SHARE_XPATH + "//input"));
        scrollAndClickOnElement(isRideShareDriverCheckbox);
    }

    public void selectNoForCurrentOrFormerProfessionalToggle() throws Exception {
        String noToggleXpath = "//fieldset//button[contains(.,'No')]";
        if (isElementPresent(pwXPath(noToggleXpath))) {
            for (Locator element : locators(pwXPath(noToggleXpath))) {
                scrollAndClickOnElement(element);
                wait.until(d -> isButtonSelected(element));
            }
        }
    }

    public void processDriverReviewPageForCrossSellAndPartnerFlow(AutoApplicant applicantAuto) throws Exception {
        String applicantFullName = applicantAuto.getFirstName() + SPACE + applicantAuto.getLastName();
        boolean isMarriedApplicant = applicantAuto.getMaritalStatus().equals(MARRIED);
        String spouseFullName = null;
        SqlAdditionalDriver sqlAdditionalDriver = new SqlAdditionalDriver();
        if (isMarriedApplicant) {
            sqlAdditionalDriver = applicantAuto.getAdditionalDrivers().get(0);
            spouseFullName = sqlAdditionalDriver.getFirstName() + SPACE + sqlAdditionalDriver.getLastName();
        }
        DriverReviewPage driverReviewPage = new DriverReviewPage();
        driverReviewPage.enterDriverLicenseAge(applicantAuto, applicantFullName, applicantAuto.getFirstAgeUnitedStatesDriverLicense());
        driverReviewPage.addDriverLicenseNumber(applicantAuto, applicantFullName);
        if (isMarriedApplicant) {
            driverReviewPage.enterDriverLicenseAge(applicantAuto, spouseFullName, sqlAdditionalDriver.getFirstAgeUnitedStatesDriverLicense());
            driverReviewPage.addDriverLicenseNumber(applicantAuto, spouseFullName);
            testStepAssert(driverReviewPage.getMaritalCheckbox(applicantFullName).isChecked(), "Marital checkbox should be checked for married driver");
            //testStepAssert(!driverReviewPage.getMaritalCheckbox(applicantFullName).isEnabled(), "Marital checkbox should be disabled for married driver");
            testStepAssert(driverReviewPage.getMaritalCheckbox(spouseFullName).isChecked(), "Marital checkbox should be checked for married driver");
            testStepAssert(!driverReviewPage.getMaritalCheckbox(spouseFullName).isEnabled(), "Marital checkbox should be disabled for married driver");
        }
        driverReviewPage.clickContinueButton();
    }

    public void validateFinancialFillingCaseNumberField(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
    	String applicantFullname = getApplicantFullName(applicant);
    	Locator financialFilingCheckbox = getFinancialFilingCheckbox(applicantFullname);
    	scrollAndClickOnElement(financialFilingCheckbox);
    	boolean isCheckboxChecked = isCheckboxChecked(financialFilingCheckbox);
    	if (!isCheckboxChecked) {
    		waitAndClickElement(financialFilingCheckbox);
    		isCheckboxChecked = isCheckboxChecked(financialFilingCheckbox);
    	}
    	fsa.assertTrue(isCheckboxChecked, "Financial filling checkbox checked");
    	if (isCheckboxChecked) {
    		Locator floridaButton = locator(pwXPath(getDriverCardXpathByFullName(applicantFullname) + "//button[contains(., 'Florida')]"));
    		Locator anotherStateButton = getAnotherStateButton(applicantFullname);
    		fsa.assertTrue(!floridaButton.isChecked() && !anotherStateButton.isChecked(), "None of the two buttons selected by default");
    		//DE273011 - Error not produced when no button selected, so skipping that test since we would continue to next page
//    		clickElement(continueButton);
//    		fsa.assertEquals(getTextFromElement(financialStateSelectionErrorLabel), "Please select which state requires filing", "Error message should show when no button selected");
    		clickElement(floridaButton);
    		clickElement(continueButton);
    		Locator floridaCaseInputFieldErrorLabel = locator(pwXPath(getDriverCardXpathByFullName(applicantFullname) + "//div[contains(@id, 'requiredFinancialResponsiblity')]//mat-error"));
    		fsa.assertEquals(getTextFromElement(floridaCaseInputFieldErrorLabel), ENTER_VALID_CASE_NUMBER, "Error message should show when no input for case number");
    		// Use invalid characters
    		clickElement(anotherStateButton);
    		clickElement(floridaButton);
    		Locator floridaCaseInputField = locator(pwXPath(getDriverCardXpathByFullName(applicantFullname) + "//div[contains(@id, 'requiredFinancialResponsiblity')]//input[not(@type)]"));
    		enterValueInField("ABC", floridaCaseInputField, "Invalid characters in case number");
    		clickElement(continueButton);
    		fsa.assertEquals(getTextFromElement(floridaCaseInputFieldErrorLabel), ENTER_VALID_CASE_NUMBER, "Error message should show when invalid characters in case number");
    		//Incomplete number
    		clickElement(anotherStateButton);
    		clickElement(floridaButton);
    		floridaCaseInputField = locator(pwXPath(getDriverCardXpathByFullName(applicantFullname) + "//div[contains(@id, 'requiredFinancialResponsiblity')]//input[not(@type)]"));
    		enterValueInField("1345780", floridaCaseInputField, "Incomplete case number");
    		clickElement(continueButton);
    		fsa.assertEquals(getTextFromElement(floridaCaseInputFieldErrorLabel), ENTER_VALID_CASE_NUMBER, "Error message should show when incomplete input for case number");
    		// Sequential number
    		clickElement(anotherStateButton);
    		clickElement(floridaButton);
    		floridaCaseInputField = locator(pwXPath(getDriverCardXpathByFullName(applicantFullname) + "//div[contains(@id, 'requiredFinancialResponsiblity')]//input[not(@type)]"));
    		enterValueInField("123456789", floridaCaseInputField, "Invalid case number");
    		clickElement(continueButton);
    		fsa.assertEquals(getTextFromElement(floridaCaseInputFieldErrorLabel), ENTER_VALID_CASE_NUMBER, "Error message should show when invalid input (sequential numbers) for case number");
    		// Repeated digit
    		clickElement(anotherStateButton);
    		clickElement(floridaButton);
    		floridaCaseInputField = locator(pwXPath(getDriverCardXpathByFullName(applicantFullname) + "//div[contains(@id, 'requiredFinancialResponsiblity')]//input[not(@type)]"));
    		String repeatedDigit = String.valueOf(new Random().nextInt(10)).repeat(9);
    		enterValueInField(repeatedDigit, floridaCaseInputField, "Repeat number");
    		clickElement(continueButton);
    		fsa.assertEquals(getTextFromElement(floridaCaseInputFieldErrorLabel), ENTER_VALID_CASE_NUMBER, "Error message should show when case number is same digit repeated: " + repeatedDigit);
    		// Valid case number
    		clickElement(anotherStateButton);
    		clickElement(floridaButton);
    		floridaCaseInputField = locator(pwXPath(getDriverCardXpathByFullName(applicantFullname) + "//div[contains(@id, 'requiredFinancialResponsiblity')]//input[not(@type)]"));
    		Faker faker = new Faker();
    		enterValueInField(faker.expression("#{numerify '#########'}"), floridaCaseInputField, "Case number");
    		clickContinueButton();
    	}
    }

    public void clickHasHadDriverLicenseLessThan3YearsCheckbox(String applicantFullName) throws Exception {
        Locator hasHadDriverLicenseLessThan3YearsCheckbox = getHadDriversLicenseCheckbox(applicantFullName);
        scrollAndClickOnElement(hasHadDriverLicenseLessThan3YearsCheckbox);
    }

    /**
     * Validates that Good Student and Distant Student discounts are NOT removed
     * when the "Has had driver's license for less than 3 years" checkbox is unchecked.
     *
     * Steps:
     * 1. Process all drivers (PNI + young additional driver) - this checks the license checkbox
     *    and the full-time student checkbox for the young additional driver.
     * 2. Ensure the Good Student (GPA > 3.0) checkbox is checked for the young driver.
     * 3. If visible, ensure the Distant Student checkbox is checked for the young driver.
     * 4. Uncheck "Has had driver's license for less than 3 years".
     * 5. Assert both Good Student and Distant Student selections are still present/checked.
     */
    public void validateStudentDiscountsNotRemovedOnLicenseCheckboxUncheck(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        // Process all drivers, which also checks the license checkbox and the full-time student
        // checkbox for the young additional driver (age <= MAX_YOUNG_AGE, license held < 3 years)
        reviewAllDrivers(applicant, Optional.empty());

        SqlAdditionalDriver youngDriver = applicant.getAdditionalDrivers().get(0);
        String youngDriverFullName = getDriverFullName(youngDriver);
        String youngDriverCardXpath = getDriverCardXpathByFullName(youngDriverFullName);
        String gpaCheckboxXpath = youngDriverCardXpath + GPA_OVER_3_CHECKBOX_XPATH;
        String gpaInputXpath = youngDriverCardXpath + GPA_OVER_3_INPUT_XPATH;
        String distantStudentCheckboxXpath = youngDriverCardXpath + DISTANT_STUDENT_XPATH;
        String distantStudentInputXpath = youngDriverCardXpath + DISTANT_STUDENT_CHECKBOX_INPUT_XPATH;

        // Verify Good Student (GPA > 3.0) checkbox is present for the young driver
        fsa.assertTrue(isElementPresent(pwXPath(gpaCheckboxXpath), 2),
                "Good Student (GPA > 3.0) checkbox should be present for the " + youngDriver.getAge() + "-year-old driver");

        // Ensure Good Student checkbox is checked
        Locator gpaInput = locator(pwXPath(gpaInputXpath));
        if (isCheckboxNotChecked(gpaInput)) {
            scrollAndClickOnHiddenElement(gpaInput);
        }
        fsa.assertTrue(isButtonSelected(locator(pwXPath(gpaInputXpath))), "Good Student discount should be checked before unchecking license checkbox");

        // Check Distant Student if visible for this driver and state
        boolean isDistantStudentVisible = isElementPresent(pwXPath(distantStudentCheckboxXpath), 2);
        Log.info("Distant Student checkbox visible for state " + applicant.getStateCode() + ": " + isDistantStudentVisible);
        if (isDistantStudentVisible) {
            Locator distantStudentInput = locator(pwXPath(distantStudentInputXpath));
            if (isCheckboxNotChecked(distantStudentInput)) {
                scrollAndClickOnHiddenElement(distantStudentInput);
            }
            fsa.assertTrue(isButtonSelected(locator(pwXPath(distantStudentInputXpath))), "Distant Student discount should be checked before unchecking license checkbox");
        }

        // Verify "Has had driver's license for less than 3 years" is currently checked (set by reviewAllDrivers)
        Locator licenseCheckbox = getHadDriversLicenseCheckbox(youngDriverFullName);
        fsa.assertTrue(isCheckboxChecked(licenseCheckbox),
                "Has had driver's license for less than 3 years checkbox should be checked for driver: " + youngDriverFullName);

        // UNCHECK "Has had driver's license for less than 3 years"
        waitAndClickElement(licenseCheckbox);
        fsa.assertFalse(isCheckboxChecked(getHadDriversLicenseCheckbox(youngDriverFullName)),
                "Has had driver's license for less than 3 years checkbox should now be unchecked");

        // === Key assertion: discounts should NOT be removed after unchecking ===
        fsa.assertTrue(isElementPresent(pwXPath(gpaCheckboxXpath), 2),
                "Good Student checkbox should still be visible after unchecking 'Has had driver's license for less than 3 years'");
        fsa.assertTrue(isButtonSelected(locator(pwXPath(gpaInputXpath))),
                "Good Student discount should NOT be removed when 'Has had driver's license for less than 3 years' is unchecked");

        if (isDistantStudentVisible) {
            fsa.assertTrue(isElementPresent(pwXPath(distantStudentCheckboxXpath), 2),
                    "Distant Student checkbox should still be visible after unchecking 'Has had driver's license for less than 3 years'");
            fsa.assertTrue(isButtonSelected(locator(pwXPath(distantStudentInputXpath))),
                    "Distant Student discount should NOT be removed when 'Has had driver's license for less than 3 years' is unchecked");
        }

        clickContinueButton();
    }

    // Validates error messages and navigation behavior for age licensed in a back-and-forth scenario.
    public void validateErrorsForAgeLicensedInBackAndForth(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        if (!isAskingDriverLicenseAgeState(applicant.getStateCode())) {
            clickHasHadDriverLicenseLessThan3YearsCheckbox(getApplicantFullName(applicant));
        }
        waitAndClickElement(continueButton);
        validateAddDriverLicenseAgeErrorMessage(fsa);

        reviewAllDrivers(applicant, Optional.empty());
        addDriverLicenseAgeBasedOnStateAndInputField(applicant);
        waitAndClickElement(continueButton);
        testStepAssert(new SignalPageOneUI().isOnSignalPage(), "User is navigated back to Driver Review page");
        navigateBack();
        testStepAssert(isOnDriverReviewPage(), "User is navigated back to Driver Review page");

        clearDriverLicenseAge(applicant.getStateCode(), getApplicantFullName(applicant));
        waitAndClickElement(continueButton);
        validateAddDriverLicenseAgeErrorMessage(fsa);
    }

    public void addDriverLicenseAgeBasedOnStateAndInputField(AutoApplicant applicant) throws Exception {
        String pniFullName = getApplicantFullName(applicant);
        int age = applicant.getAge();
        if (isAskingDriverLicenseAgeState(applicant.getStateCode())) {
            enterDriverLicenseAge(applicant, pniFullName, applicant.getFirstAgeUnitedStatesDriverLicense());
        } else if (age <= MAX_YOUNG_AGE && (age - applicant.getFirstAgeUnitedStatesDriverLicense() < 3)) {
            addHadDriversLicense(pniFullName, applicant.getFirstAgeUnitedStatesDriverLicense());
        }
    }

    public void clearDriverLicenseAge(String stateCode, String fullName) throws Exception {
        if(stateCode.equals(CA)) {
            return;
        }
        if (isAskingDriverLicenseAgeState(stateCode)) {
            String inputBy = pwXPath(getDriverCardXpathByFullName(fullName) + LICENSE_AGE_INPUT_FIELD_XPATH);
            if(!isElementPresent(inputBy, 2)) {
                return;
            }
            Locator licenseAgeInputField = locator(inputBy);
            clearOutFieldUsingBackSpace(licenseAgeInputField);
        } else{
            Locator driverLicenceAgeInputField = getDriverLicenceAgeInputField(fullName);
            if(!isElementDisplayed(driverLicenceAgeInputField, 2)) {
                return;
            }
            clearOutFieldUsingBackSpace(driverLicenceAgeInputField);
        }
    }

    public void validateAddDriverLicenseAgeErrorMessage(FarmersSoftAssert fsa){
        // CTA no longer shows generic message
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(driverLicenseAgeError.nth(0))), PLEASE_PROVIDE_AGE, PLEASE_PROVIDE_AGE + " error message validation");
    }
    public void validateSafetyCourseFunctionality(AutoApplicant applicant, boolean isSafetyCourseExpected, FarmersSoftAssert fsa) throws Exception {
        testStepAssert(isOnDriverReviewPage(), "User is on Driver Review Page", true);
        String applicantFullName = getApplicantFullName(applicant);

        // Validate checkbox presence
        validateSafetyCourseCheckboxPresence(applicant, fsa, isSafetyCourseExpected, applicantFullName);

        if (isSafetyCourseExpected) {
            // Validate subtext and discount functionality
            validateSafetyCourseSubtext(applicant, fsa, applicantFullName);
            validateSafetyCourseDiscountFunctionality(applicantFullName, fsa, applicant.getStateCode());
        }

        reviewAllDrivers(applicant, Optional.empty());
        clickContinueButton();
    }

    public void validateSafetyCourseCheckboxPresence(AutoApplicant applicant, FarmersSoftAssert fsa, boolean isSafetyCourseExpected, String applicantFullName) throws Exception {
        List<String> checkboxesTextsForGivenDriver = getCheckboxesTextsForGivenDriver(applicantFullName);
        String safetyCourseDisplayExpectation = isSafetyCourseExpected ? "should be" : "should not be";

        String actualSafetyCourseCheckboxText = Arrays.asList(CT, WY).contains(applicant.getStateCode())
                ? DriverReviewPageCheckboxes.SAFETY_COURSE_2_YEARS.getCheckBoxText()
                : DriverReviewPageCheckboxes.SAFETY_COURSE.getCheckBoxText();

        fsa.assertEquals(
                checkboxesTextsForGivenDriver.contains(actualSafetyCourseCheckboxText),
                isSafetyCourseExpected,
                String.format("Safety course %s displayed for %s", safetyCourseDisplayExpectation, applicantFullName)
        );
    }

    private void validateSafetyCourseSubtext(AutoApplicant applicant, FarmersSoftAssert fsa, String applicantFullName) throws Exception {
        String stateCode = applicant.getStateCode();
        String expectedSafetyCourseSubtext = getExpectedDefensiveDriverSubHeader(stateCode);

        if (!List.of(GA, KS, NJ, UT).contains(stateCode)) { // These states do not have subtext for the safety course checkbox
            Locator safetyCheckboxesSubText = getDriverSafetyCourseSubTextLocatorByFullName(applicantFullName);
            fsa.assertEquals(
                    getTextFromElement(safetyCheckboxesSubText),
                    expectedSafetyCourseSubtext,
                    "Safety course subtext verification"
            );
        }
    }

    private void validateSafetyCourseDiscountFunctionality(String applicantFullName, FarmersSoftAssert fsa, String stateCode) throws Exception {

        // if in any case safety course checkbox is already checked, uncheck it to validate both discount addition and removal in the same test execution
        Locator safetyCourseCheckbox = getSafetyCourseCheckbox(applicantFullName);
        if(safetyCourseCheckbox.getAttribute(CLASS).equals(CHECKBOX_CHECKED)) {
            clickElement(safetyCourseCheckbox);
            if(waitElementBeVisible(snackBar).isVisible()){
                wait.until(Conditions.invisible(snackBar));
            }
        }

        // Click safety course checkbox and validate discount added
        addSafetyCourse(applicantFullName);
        boolean isDefensiveDiscountEnabled = isDefensiveDriverDiscountEnabledOnDriverReview(stateCode);
        if (stateCode.equals(PA)) {
            validateDriverImprovementDiscountAddedSnackBar(fsa);
            if (!isBDQFlowEnabled()) {
                validateDriverImprovementDiscountPresent(fsa);
            }
        } else {
            validateMatureOrDefensiveDriverDiscountAddedSnackBar(fsa, isDefensiveDiscountEnabled);
            // For BDQ flow, the discount will be added in the backend but won't be displayed on UI, so skipping the validation of discount presence on UI for BDQ flow
            if (!isBDQFlowEnabled()) {
                validateMatureOrDefensiveDriverDiscountPresent(fsa, isDefensiveDiscountEnabled);
            }
        }


        // Click safety course checkbox again and validate discount removed
        waitElementBeInvisible(discountsSidesheetTitle);
        scrollElementToMiddle(safetyCourseCheckbox);
        waitAndClickElement(safetyCourseCheckbox);
        if (stateCode.equals(PA)) {
            validateDriverImprovementDiscountRemovedSnackBar(fsa);
            if (!isBDQFlowEnabled()) {
                validateDriverImprovementDiscountNotPresent(fsa);
            }
        } else {
            validateMatureOrDefensiveDriverDiscountRemovedSnackBar(fsa, isDefensiveDiscountEnabled);
            // For BDQ flow, the discount will be added in the backend but won't be displayed on UI, so skipping the validation of discount presence on UI for BDQ flow
            if (!isBDQFlowEnabled()) {
                validateMatureOrDefensiveDriverDiscountNotPresent(fsa, isDefensiveDiscountEnabled);
            }
        }
    }


    public boolean isDefensiveDriverDiscountEnabledOnDriverReview(String stateCode) throws Exception {
        if(stateCode.equals(AL) && !isBDQFlowEnabled() && !isOnBristolWest()){
            return false;
        }
        return Arrays.asList(AL, GA, KS, KY, MT, NJ).contains(stateCode);
    }

    private String getExpectedDefensiveDriverSubHeader(String stateCode){
        return stateCode.equals(KS) ? KS_DEFENSIVE_DRIVER_COURSE_SUBHEADER_TEXT
                : stateCode.equals(CT) ? CT_DEFENSIVE_DRIVER_SUBHEADER_TEXT
                : stateCode.equals(MA) ? MA_DEFENSIVE_DRIVER_SUBHEADER_TEXT
                : SPECIAL_DEFENSIVE_DRIVER_SUBHEADER_TEXT;
    }

    private Locator getDriverSafetyCourseSubTextLocatorByFullName(String applicantFullName) throws Exception {
        return locator(pwXPath(getDriverCardXpathByFullName(applicantFullName) + SAFETY_COURSE_SUBTEXT_XPATH_END));
    }
    private List<Locator> getDriverSafetyCourseSubTextLocators() throws Exception {
        return locators(pwXPath(SAFETY_COURSE_SUBTEXT_XPATH_END));
    }
    public void validateSafetyCourseCheckBoxNotPresent(FarmersSoftAssert fsa, String applicantFullName) throws Exception {
        fsa.assertFalse(isElementPresent(pwXPath(SAFETY_COURSE_CHECKBOX_XPATH)), "Safety course checkbox should not be displayed");
    }
    public void validateNoSnackBarDisplayed(FarmersSoftAssert fsa) throws Exception {
        fsa.assertFalse(isElementPresent(pwXPath("//a[@id='snackbarDesc']")), "mature or defensive driver discount snackbar should not be displayed");
    }

    public void validateSpouseNonDriverStatusDoesNotResetAfterRefresh(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        waitElementPresent(pwXPath(getDriverCardXpathByFullName(getApplicantFullName(applicant)) + MARITAL_CHECKBOX_INPUT_XPATH), 3);
        clickElement(getMaritalCheckbox(getApplicantFullName(applicant)));
        clickOnSpouseToIfExist(applicant);
        enterSpouseInformation(applicant, false, false);
        waitForSpinnerToBeGone();
        refreshPage();
        waitUntilAngular5Ready();
        AppStore.Auto.Driver sni = getSessionStorageAppStore().getAuto().getDrivers().stream().filter(each -> each.getPni().equals("X")).collect(Collectors.toList()).get(0);
        String spouseFullName = sni.getFirstName() + SPACE + sni.getLastName();
        String driverCardXpathByFullName = getDriverCardXpathByFullName(spouseFullName);
        String nonDriverLabelXpath = "//span[@class='non-driver-label ng-star-inserted']";
        fsa.assertTrue(isElementPresent(pwXPath(driverCardXpathByFullName + nonDriverLabelXpath), 2), "Non Driver label should be present");
        waitAndClickElement(getEditButtonByDriverFullName(spouseFullName));
        Locator noOptionSelected = locator(pwXPath(String.format(SPOUSE_DRIVING_VEHICLE_XPATH, NO) + "[contains(@class,'checked')]"));
        fsa.assertTrue(isElementDisplayed(noOptionSelected, 3));
        clickElement(editDriverDialogCloseLink);
    }
}
