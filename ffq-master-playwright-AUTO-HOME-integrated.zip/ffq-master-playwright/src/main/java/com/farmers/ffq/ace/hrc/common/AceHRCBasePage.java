package com.farmers.ffq.ace.hrc.common;








import com.farmers.framework.playwright.Keys;
import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.TimeoutError;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.ApplicantAceHome;
import com.farmers.ffq.datatransferobjects.SqlDiscount;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import lombok.Getter;
import org.testng.Assert;

import java.time.LocalDate;
import java.time.Year;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.ace.hrc.common.AceHRCAdditionalInfoBasePage.*;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCBasePage extends BasePage {

    //Page names
    public static final String PROPERTY_TYPE = "Property type";
    public static final String ADDRESS_PAGE = "Address page";
    public static final String PROPERTY_DETAILS = "Property details";
    public static final String QUALITY_GRADE = "Quality grade";
    public static final String ADDITIONAL_INFO = "Additional info";
    public static final String ABOUT_YOU = "About you";
    public static final String CONTACT_INFO = "Contact info";
    public static final String CUSTOM_COVERAGE = "Custom coverage";
    public static final String DWELLING_COVERAGE = "Dwelling coverage";
    public static final String ADDITIONAL_COVERAGES = "Additional coverages";
    public static final String JFMT_PAGE = "Just a few more things page";
    public static final String SELECT_PAYMENT = "Select payment";
    public static final String PAYMENT_PAGE = "Payment page";
    public static final String UNKNOWN_PAGE_NAME = "Unknown page name: ";

    //Discount names
    private static final String AUTO_HOME_DISCOUNT = "Auto & Home";
    private static final String FORTIFIED_HOME_DISCOUNT = "FORTIFIED home";
    private static final String WROUGHT_IRON_BARS_DISCOUNT = "Wrought iron bars";
    private static final String HOME_TRANSFER_DISCOUNT = "Home transfer";
    private static final String WILDFIRE_MITIGATION_DISCOUNT = "Wildfire mitigation";
    private static final String WATER_PROTECTION_DISCOUNT = "Water protection";
    private static final String THEFT_PROTECTION_DISCOUNT = "Theft protection";
    private static final String FIRE_PROTECTION_DISCOUNT = "Fire protection";
    private static final String PROFESSION_GROUP_DISCOUNT = "Profession group";
    private static final String PAPERLESS_DISCOUNT = "Paperless";
    private static final String CENTRAL_FIRE_ALARM_DISCOUNT = "Central fire alarm";
    private static final String CENTRAL_BURGLAR_ALARM_DISCOUNT = "Central burglar alarm";
    private static final String LOCAL_FIRE_ALARM_DISCOUNT = "Local fire alarm";
    private static final String LOCAL_BURGLAR_ALARM_DISCOUNT = "Local burglar alarm";
    private static final String NEW_HOME = "New home";
    private static final String CLAIM_FREE_DISCOUNT = "Claim free";
    private static final String GOOD_PAYER_DISCOUNT = "Good payer";
    private static final String HOME_PROTECTION_DISCOUNT = "Home protection and loss prevention";
    private static final String UL_ROOF_DISCOUNT = "UL roof";
    private static final String HOME_UMBRELLA_DISCOUNT = "Home & Umbrella";
    private static final String HOME_CEA_DISCOUNT = "Home CEA";
    private static final String HOME_LIFE_DISCOUNT = "Home & Life";
    private static final String HOME_BUYER_DISCOUNT = "Home buyer";
    private static final String HOME_RV_DISCOUNT = "Home & RV";
    private static final String HOME_OFF_ROAD_VEHICLE_DISCOUNT = "Home & Off-road vehicle";
    private static final String HOME_WATERCRAFT_DISCOUNT = "Home & Watercraft";
    private static final String HOME_BUSINESS_DISCOUNT = "Home & Business";
    private static final String EARLY_SHOPPING_DISCOUNT = "Early shopping";
    private static final String WINDSTORM_MITIGATION_DISCOUNT = "Windstorm mitigation";
    private static final String ELECTRICAL_SYSTEM_REPLACEMENT_DISCOUNT = "Electrical system replacement";
    private static final String PLUMBING_SYSTEM_REPLACEMENT_DISCOUNT = "Plumbing system replacement";
    private static final String HVAC_REPLACEMENT_DISCOUNT = "HVAC replacement";
    private static final String SPRINKLER_DISCOUNT = "Sprinkler discount";
    LocalDate today = getTodayDate();
    protected String EXPECTED_POLICY_START_DATE_ERROR = "Please select your policy effective date between " + getFormattedForPolicyStartDate(today.plusDays(1)) + " and " + getFormattedForPolicyStartDate(today.plusDays(59)) + ".";

    public static final String SEPARATOR = Property.getBrowser().equals(SAFARI) ? EMPTY_STRING : SPACE;
    protected static final String QUOTE_PRESENTMENT_DESKTOP_XPATH = "//mat-card[contains(@class,'tui-quote-presentment-desktop')]";
    protected static final String QUOTE_PRESENTMENT_MOBILE_XPATH = "//mat-card[contains(@class,'tui-quote-presentment-mobile')]";

        private Locator farmersLogoNavbar = locator(pwXPath("//tui-stepper-navbar//img[@data-test-id='TUI_LOGO_NO_LINK']"));

        protected Locator phoneLink = locator(pwXPath("//tui-stepper-navbar//a[@data-tui-tracking-id='navbar-phone-link']"));

        protected Locator stateDropDownOptions = locator(pwXPath("//mat-option"));

        private Locator navStepperDesktop = locator(pwXPath("//tui-stepper-navbar//div[@class='tui-desktop-nav-stepper']"));

        private Locator navStepperMobile = locator(pwXPath("//tui-stepper-navbar//div[@class='tui-mobile-nav-stepper']"));

        private Locator farmersLogoFooter = locator(pwXPath("//tui-oneui-footer//div[contains(@class,'tui-oneui-footer-logo-container')]/img"));

        private Locator footerPersonalInfoUseLink = locator(pwXPath("//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_personal-information-use']"));

        private Locator footerDigitalAccessibilityLink = locator(pwXPath("//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_digital-accessibility']"));

        private Locator footerTermsOfUseLink = locator(pwXPath("//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_terms-of-use']"));

        private Locator footerPrivacyCenterLink = locator(pwXPath("//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_privacy-center']"));

        private Locator footerNoticeOfInformationPracticesLink = locator(pwXPath("//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_notice-of-information-practices']"));

        private Locator footerDoNotSellLink = locator(pwXPath("//tui-oneui-footer//a[@data-tui-tracking-id='footer-farmers-links_do-not-sell']"));

        private Locator modalPrivacyChoicesTitle = locator(pwXPath("//div[@role='dialog']//h4[text()='Notice of Right to Opt-Out']"));

        private Locator modalPrivacyChoicesSaveButton = locator(pwXPath("//div[@role='dialog']//button[contains(@class,'save-preference-btn')]"));

        private Locator modalPrivacyChoicesCloseButton = locator(pwXPath("//div[@role='dialog']//button[@id='close-pc-btn-handler']"));

        private Locator discountsDescription = locator(pwXPath("//div[contains(@class,'discount-description')]/p[contains(@class,'tui-subtitle')]"));

        private Locator discountPiggyBankImageCard = locator(pwXPath("//app-home-discount//img[@alt='Discounts logo']"));

        protected Locator reviewDiscountsLink = locator(pwXPath("//p[contains(text(),'Review discount')]"));

        private Locator quoteProgressSavedText = locator(pwXPath("//div[contains(@class,'save-in-progress-section')]/p"));

    protected static final String DISCOUNT_NAMES_XPATH = "//app-home-discount-sidesheet//div/span[contains(@class,'discount-name')]";

        protected Locator closeDiscountsSidesheet = locator(pwXPath("//app-home-discount-sidesheet//mat-icon[text()='close']"));

        protected Locator footerDiscountsSidesheet = locator(pwXPath("//app-home-discount-sidesheet//div[contains(@class,'lightbulb-container')]/following-sibling::div"));

    protected static final String TRY_AGAIN_BUTTON_XPATH = "//button[text()='Try again']";
        protected Locator tryAgainButton = locator(pwXPath(TRY_AGAIN_BUTTON_XPATH));

        protected Locator addressListBox = locator(pwXPath("//div[@role='listbox']"));

    protected static final String ERROR_MESSAGE_XPATH = "//mat-error[not(@hidden)]";
        protected Locator errorMessage = locator(pwXPath(ERROR_MESSAGE_XPATH));
        private Locator saveInProgressFooter = locator(pwXPath("//div[contains(@class,'save-in-progress')]/p"));
        private Locator quoteNumberText = locator(pwXPath("//div[contains(@class,'save-quote')]"));
    private String QUOTE_TEXT_LINE_XPATH = "//*[contains(text(),'Quote number')]";
        private Locator termsESignContactInfoPage = locator(pwXPath("//a[normalize-space()='these ESIGN term and conditions']"));
        private Locator associatedEntitiesContactInfoPage = locator(pwXPath("//a[text()='associated entities']"));
    private static final String YOUR_AGENT = "Your agent";
        private Locator yourAgent = locator(pwXPath("//app-agent-details//div[contains(text(),'" + YOUR_AGENT + "')]"));
    private static final String AGENT_IMAGE_XPATH = "//app-agent-details//img[@class='agent-image']";
        private Locator agentsImage = locator(pwXPath(AGENT_IMAGE_XPATH));
        private Locator agentName = locator(pwXPath("//app-agent-details//div[contains(@class,'tui-body-bold')]"));
        private Locator agentPhoneLink = locator(pwXPath("//app-agent-details//a[contains(@class,'tui-link-footer') and contains(@href,'tel:')]"));
        private Locator agentEmailLink = locator(pwXPath("//app-agent-details//a[contains(@class,'tui-link-footer') and contains(@href,'mailto:')]"));
        private Locator agentAddressLink = locator(pwXPath("//app-agent-details//a[contains(@class,'tui-link-footer') and contains(@href,'maps')]"));
        private Locator tollFreeNumber2 = locator(pwXPath("//div[contains(@class,'agent-details-container')]//a[starts-with(@aria-label,'Contact farmers representative at')]"));
        protected Locator agentInfo = locator(pwXPath("//app-agent-details//div[contains(@class,'tui-agent-box')]"));
        private Locator sideSheet = locator(pwXPath("//mat-dialog-container/parent::div"));

    protected static final String PRIOR_HOME_ADDRESS_INPUT_FIELD_XPATH = "//address-autocomplete-input[@id='prior-address-autocomplete']//input";
    protected static final String PRIOR_HOME_CITY_INPUT_FIELD_XPATH = "//mat-form-field//input[@aria-label='City']";
    protected static final String PRIOR_HOME_UNIT_INPUT_FIELD_XPATH = "//mat-form-field//input[@aria-label='Unit number (optional)']";
    protected static final String PRIOR_HOME_STATE_SELECT_FIELD_XPATH = "//mat-form-field//mat-select[@aria-label='State']";
    protected static final String PRIOR_HOME_STATE_SELECT_OPTION_XPATH = "//mat-option";
    protected static final String PRIOR_HOME_ZIP_INPUT_FIELD_XPATH = "//mat-form-field//input[@aria-label='Zip code']";
        private Locator priorHomeAddressInputField = locator(pwXPath(PRIOR_HOME_ADDRESS_INPUT_FIELD_XPATH));
        public Locator priorHomeCityInputField = locator(pwXPath(PRIOR_HOME_CITY_INPUT_FIELD_XPATH));
        private Locator priorHomeUnitInputField = locator(pwXPath(PRIOR_HOME_UNIT_INPUT_FIELD_XPATH));
        public Locator priorHomeStateSelectField = locator(pwXPath(PRIOR_HOME_STATE_SELECT_FIELD_XPATH));
        public Locator priorHomeZipInputField = locator(pwXPath(PRIOR_HOME_ZIP_INPUT_FIELD_XPATH));

    private static final String PAYROLL_DEDUCTION_BANNER_XPATH = "//div[@class='fws-banner-content']";
        private Locator payrollDeductionBannerTitle = locator(pwXPath(PAYROLL_DEDUCTION_BANNER_XPATH + "//p[1]"));
        private Locator payrollDeductionBannerContent = locator(pwXPath(PAYROLL_DEDUCTION_BANNER_XPATH + "//p[2]"));
        private Locator payrollDeductionEmployer = locator(pwXPath(PAYROLL_DEDUCTION_BANNER_XPATH + "//b"));
        private Locator payrollDeductionBannerContactInfo = locator(pwXPath(PAYROLL_DEDUCTION_BANNER_XPATH + "//p[3]"));

    private static final String PAYROLL_DEDUCTION_BANNER_TITLE = "Thanks for shopping with Farmers!";
    private static final String PAYROLL_DEDUCTION_BANNER_CONTACT_INFO = "To buy, please call us at 855-503-1928.";

    protected static final String CONTACT_TEXT = "Contact farmers representative at %s";

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public AceHRCBasePage() throws Exception {
    }

    public void scrollAndClickOnContinueButton() {
        scrollAndClickOnElement(buttonContinue);
        waitForSpinnerToBeGone();
    }

    public void navigateBack(int times) throws Exception {
        for (int i = 0; i < times; i++) {
            back();
            waitForSpinnerToBeGone();
        }
    }

    public void validatePageLinksText(FarmersSoftAssert fsa, String expectedActiveStep) throws Exception {
    	Locator logoNavbarLocator = farmersLogoNavbar;
    	String logoCheckMessage = " in the Navbar.";
    	String expectedNavbarLogo = expectedActiveStep.equals(FOREMOST)? "Foremost Insurance logo" : "Farmers Insurance logo";
    	if (expectedActiveStep.contains(RETRIEVED)) {
    		expectedActiveStep = expectedActiveStep.replace(RETRIEVED, EMPTY_STRING);
    		logoNavbarLocator = locator(pwXPath("//app-basic-header//img"));
    		logoCheckMessage = " in the quote header.";
    		expectedNavbarLogo = "Farmers Insurance Logo";
    	} else {
    		String browserType = isUseMobileViewEnabled()? MOBILE_BROWSER : DESKTOP_BROWSER;
            Locator stepperElement = locator(pwXPath(String.format(NAV_BAR_STEPPER_XPATH, browserType)));
            if (List.of(DISABLED, FOREMOST).contains(expectedActiveStep)) {
            	fsa.assertTrue(!stepperElement.isVisible(), "Navigation Bar Stepper is not displayed.");
            } else {
            	fsa.assertTrue(stepperElement.isVisible(), "Nav Bar Stepper is displayed.");
            	fsa.assertEquals(getSelectedStepper(browserType), expectedActiveStep, "Nav Bar Stepper selected step.");
            }
    	}
    	String expectedFooterLogo = expectedActiveStep.equals(FOREMOST)? "Foremost logo" : "Farmers logo";
        fsa.assertEquals(getAttributeData(logoNavbarLocator, "alt"), expectedNavbarLogo, expectedNavbarLogo + logoCheckMessage);
        fsa.assertEquals(getAttributeData(farmersLogoFooter, "alt"), expectedFooterLogo, expectedFooterLogo + " in footer.");
        fsa.assertEquals(getTextFromElement(footerPersonalInfoUseLink), "Personal information use", "Personal information use footer link.");
        fsa.assertEquals(getTextFromElement(footerDigitalAccessibilityLink), "Digital accessibility", "Digital accessibility footer link.");
        fsa.assertEquals(getTextFromElement(footerTermsOfUseLink), "Terms of use", "Terms of use footer link.");
        fsa.assertEquals(getTextFromElement(footerPrivacyCenterLink), "Privacy center", "Privacy center footer link.");
        fsa.assertEquals(getTextFromElement(footerNoticeOfInformationPracticesLink), "Notice of information practices", "Notice of information practices footer link.");
        fsa.assertEquals(getTextFromElement(footerDoNotSellLink), "Do not sell or share my personal information", "Do not sell or share my personal information footer link.");
    }

    public void validateHeaderFooterHaveNoFarmersLogoAndLinks(FarmersSoftAssert fsa, String stepper, String pageName) throws Exception {
        if (!pageName.equals("AceHomeThankYouPage")) {
            String browserType = isUseMobileViewEnabled() ? MOBILE_BROWSER : DESKTOP_BROWSER;
            Locator weStepper = locator(pwXPath(String.format(NAV_BAR_STEPPER_XPATH, browserType)));
            if (!weStepper.isVisible()) {
                refreshPage();
                weStepper = locator(pwXPath(String.format(NAV_BAR_STEPPER_XPATH, browserType)));
            }
            fsa.assertTrue(weStepper.isVisible(), "Nav Bar Stepper is displayed: " + pageName);
            fsa.assertEquals(getSelectedStepper(browserType), stepper, "Nav Bar Stepper selected step: " + pageName);
        }
        boolean result = false;
        try {
            result = conditionalWait(5).until(Conditions.invisibilityOfAllElements(farmersLogoNavbar,phoneLink,farmersLogoFooter,footerPersonalInfoUseLink,
                    footerDigitalAccessibilityLink,footerTermsOfUseLink,footerPrivacyCenterLink,footerNoticeOfInformationPracticesLink,footerDoNotSellLink));
        } catch (TimeoutError e) {
            Log.error("Exception occurred: " + e.getMessage());
        }
        finally {
            fsa.assertTrue(result, "All of the Locators were invisible within the timeout: " + pageName);
       }
    }

    @Getter
    public static class PageLink {
        private final Locator linkElement;
        private final String page;
        private final String destinationPageTitleXpath;
        private final String destinationUrlPattern1;
        private final String destinationUrlPattern2;

        public PageLink(Locator linkElement, String page, String destinationPageTitleXpath, String destinationUrlPattern1, String destinationUrlPattern2) {
            this.linkElement = linkElement;
            this.page = page;
            this.destinationPageTitleXpath = destinationPageTitleXpath;
            this.destinationUrlPattern1 = destinationUrlPattern1;
            this.destinationUrlPattern2 = destinationUrlPattern2;
        }
    }

    private ArrayList<PageLink> getPageLinks() {
        ArrayList<PageLink> pageLinks = new ArrayList<>();
        PageLink pageLink = new PageLink(footerPersonalInfoUseLink, "Personal information use", "//h2[.='What information do we collect and how do we use it?']",
                "www.farmers.com/privacy-statement/", "#personaluse");
        pageLinks.add(pageLink);
        pageLink = new PageLink(footerDigitalAccessibilityLink, "Digital accessibility", "//h1[.='Digital Accessibility']",
                "www.farmers.com/accessibility/", EMPTY_STRING);
        pageLinks.add(pageLink);
        pageLink = new PageLink(footerTermsOfUseLink, "Terms of use", "//h1[.='Terms Of Use']",
                "www.farmers.com/terms-of-use/", EMPTY_STRING);
        pageLinks.add(pageLink);
        pageLink = new PageLink(footerPrivacyCenterLink, "Privacy center", "//h1[.='Privacy Center']",
                "www.farmers.com/privacy-center/", EMPTY_STRING);
        pageLinks.add(pageLink);
        pageLink = new PageLink(footerNoticeOfInformationPracticesLink, "Notice of information practices", "//h1[.='Notice of Information Practices']",
                "www.farmers.com/information-practices/general", EMPTY_STRING);
        pageLinks.add(pageLink);
        pageLink = new PageLink(footerDoNotSellLink, "Do not sell or share my personal information",
                "//h2[.='Do Not Sell/Share My Personal Information/Notice of Right to Opt Out']",
                "www.farmers.com/privacy-statement/", "#donotsell");
        pageLinks.add(pageLink);
        return pageLinks;
    }

    public void validateAgentSection(FarmersSoftAssert fsa, String pageName, String agentId, String lob) throws Exception {
        // F95970: FFQ - Display Agent Info only for Agent website traffic
        // F105732: Invoca Single Phone Number Consistency Across the Quote Flow
        List<String> pagesWithAgentData = new ArrayList<>(List.of(REVIEW_QUOTE, ADDITIONAL_COVERAGES, JFMT_PAGE, SELECT_PAYMENT, PAYMENT_PAGE));
        if (RENTERS.equals(lob)) {
            pagesWithAgentData.add(0, CONTACT_INFO);
        }
        if (!agentId.isBlank()) {
            fsa.assertTrue(!isElementDisplayed(phoneLink, 2), "Contact farmers representative phone number link should not be displayed.");
            validateAssignedAgentSection(this, fsa);
        } else {
            fsa.assertEquals(getAttributeData(phoneLink, ARIA_LABEL), String.format(CONTACT_TEXT, CALL_FARMERS), "Contact Farmers representative phone number link is displayed.");
            if (!pagesWithAgentData.contains(pageName)) {
                fsa.assertTrue((agentInfo.count() == 0), "Agent details section is not displayed for PA agent quote.");
            }
        }
    }

    protected void validateAgentSectionForMobileHome(FarmersSoftAssert fsa, boolean isAgentExpected) throws Exception {
        scrollToBottomOfPage();
        AppStore.Data.AgentData agentData = getSessionStorageAppStore().getData().getAgentData();
        fsa.assertTrue(isSafariBrowser()? isElementPresent(pwClass(AGENT_IMAGE_CLASS_NAME), 3) : isElementDisplayed(agentImage, 3), "Agent image found");
        fsa.assertTrue(!getAttributeData(agentImage, SRC).isEmpty(), "Agent image 'src' attribute is not empty");
        fsa.assertEquals(getTextFromElement(agentSectionYourAgent), "We're here to help! Call us to customize and purchase.", "Call us text verification");
        if (isAgentExpected) {
            String agentFullName = agentData.getFirstName() + SPACE + agentData.getLastName();
            String agentPhone = agentData.getCommunication().getPhoneNumber().getPhoneNumber();
            String agentMail = agentData.getCommunication().getEmailId().getEmailAddress();
            String agentStreet = String.valueOf(agentData.getAddress().getStreet()).replace("|", SPACE);
            String agentCity = String.valueOf(agentData.getAddress().getCity());
            String agentState = String.valueOf(agentData.getAddress().getState());
            String agentZipCode = String.valueOf(agentData.getAddress().getZip());
            String agentAddress = agentStreet + SPACE + agentCity + SPACE + agentState + SPACE + agentZipCode;
            fsa.assertEquals(getTextFromElement(agentSectionAgentName), agentFullName, "Agent full name verification");
            fsa.assertEquals(getTextFromElement(locator(pwXPath("//a[contains(@aria-label,'Contact') and contains(@class,'footer')]"))).replaceAll("[^0-9]", EMPTY_STRING).toLowerCase(), agentPhone.toLowerCase(), "Agent phoneNumber verification");
            if (!agentMail.isBlank()) {
                fsa.assertEquals(getTextFromElement(locator(pwXPath("//app-agent-details//a[contains(@aria-label, 'Email')]"))), agentMail, "Agent displayed email address verification");
			}
            fsa.assertEquals(getTextFromElement(locator(pwXPath("//div[contains(@class,'agent-details-container')]/p[@class]"))).replace(COMMA, EMPTY_STRING), agentAddress, "Agent address verification");
        } else {
        	//Default non-agent being used
            fsa.assertEquals(getTextFromElement(agentPhoneNumber), "888-902-1896", "Phone number verification");
        }
    }

    public void validatePageLinksNavigationTitles(FarmersSoftAssert fsa) throws Exception {
        ArrayList<PageLink> pageLinks = getPageLinks();
        Page baseWindow = currentPage();
        List<Page> originalOpenWindowHandles = pages();
        int numberOfOpenWindows = originalOpenWindowHandles.size();
        for (PageLink pageLink : pageLinks) {
            scrollToBottomOfPage();
            Log.info(">> Going to check: " + pageLink.getPage());
            clickElement(pageLink.getLinkElement());
            conditionalWait(10).until(Conditions.pageCount(numberOfOpenWindows+1));
            List<Page> newHandles = pages();
            newHandles.removeAll(originalOpenWindowHandles);
            for (Page handle : newHandles) {
                if (!baseWindow.equals(handle)) {
                    switchToPage(handle);
                    waitForPageToBeReady();
                    String currentURL = page().url();
                    Log.info("Current page URL: " + currentURL);
                    fsa.assertTrue((pageLink.getDestinationUrlPattern2().isBlank() || currentURL.contains(pageLink.getDestinationUrlPattern2())),
                            pageLink.getPage() + " Url - contains: " + pageLink.getDestinationUrlPattern2());
                    conditionalWait(10).until(Conditions.visibilityOfAllElementsLocatedBy(pwXPath(pageLink.getDestinationPageTitleXpath())));
                    closeCurrentPage();
                    conditionalWait(10).until(Conditions.pageCount(numberOfOpenWindows));
                }
            }
            switchToPage(baseWindow);
        }
    }

    protected void enterGoogleAddressAceHome(Locator addressField, Locator cityField, ApplicantAceHome applicant) throws Exception {
        String address = applicant.getAddress() + ", " + applicant.getCity();
        scrollAndClickOnElement(addressField);
        if (isSafariBrowser()) {
            sendKeysToElement(addressField, address);
        } else {
            sendKeysToElementUsingClipboard(addressField, address);
        }
        if (getElementValue(addressField, "address field").isBlank()) {
            sendKeysToElement(addressField, address);
        }
        if (isElementDisplayed(addressListBox, 3)) {
            sendKeys(addressField, Keys.ARROW_DOWN);
            sendKeys(addressField, Keys.RETURN);
        } else {
            if (cityField != null) {
                sendKeysToElement(cityField, applicant.getCity());
            } else {
                clearOutFieldUsingBackSpace(addressField);
                enterValueInField(applicant.getAddress().substring(0, 3), addressField, "Entering First 3 characters of the address: ");
                if (isElementDisplayed(addressListBox, 3)) {
                    sendKeys(addressField, Keys.ARROW_DOWN);
                    sendKeys(addressField, Keys.RETURN);
                }
            }
        }
    }

    public void enterCurrentOrPriorAddress(ApplicantAceHome applicant) throws Exception {
        scrollToElement(priorHomeAddressInputField);
        enterGoogleAddressAceHome(priorHomeAddressInputField, priorHomeCityInputField, applicant);
        if (getValueFromLocator(waitElementBeVisible(priorHomeCityInputField, 2)).isBlank()) {
            sendKeysToElement(priorHomeCityInputField, applicant.getCity());
        }
        if (getTextFromElement(priorHomeStateSelectField).isBlank()) {
            waitAndClickElement(priorHomeStateSelectField);
            waitAndClickElement(locator(pwXPath(PRIOR_HOME_STATE_SELECT_OPTION_XPATH + "[.='" + applicant.getStateCode() + "']")));
        }
        if (getValueFromLocator(priorHomeZipInputField).isBlank()) {
            sendKeysToElement(priorHomeZipInputField, applicant.getZipCode());
        }
        if (!applicant.getUnit().isBlank()) {
            sendKeysToElement(priorHomeUnitInputField, applicant.getUnit());
        }
    }

    public List<String> getPageErrors() throws Exception {
        return locators(pwXPath(ERROR_MESSAGE_XPATH)).stream()
                .map(this::getTextFromElement).map(String::strip).collect(Collectors.toList());
    }

    public List<String> getPageAlerts() throws Exception {
        return locators(pwXPath("//p[@role='alert']")).stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public void validateQuoteSavedText(String quoteNumber, FarmersSoftAssert fsa) {
        final String EXPECTED_QUOTE_PROGRESS_SAVED = "Quote progress is saved!";
        fsa.assertEquals(getTextFromElement(saveInProgressFooter), EXPECTED_QUOTE_PROGRESS_SAVED, "Validate text: " + EXPECTED_QUOTE_PROGRESS_SAVED);
        String quoteNumberDisplayed = getTextFromElement(quoteNumberText).replaceAll("\\D", EMPTY_STRING);
        fsa.assertEquals(quoteNumberDisplayed, quoteNumber, "Quote number and Quote progress is saved text are displayed.");
    }

    public void validateQuoteText(String pageName, String quoteNumber, FarmersSoftAssert fsa, boolean isQuoteContentApplicable) throws Exception {
        if(!isQuoteContentApplicable) {
            fsa.assertTrue(!isElementDisplayed(pwXPath(QUOTE_TEXT_LINE_XPATH)), pageName + " - Quote number text line is not displayed.");
        } else {
            String quoteNumberDisplayed = getTextFromElement(quoteNumberText).replaceAll("\\D", EMPTY_STRING);
            fsa.assertEquals(quoteNumberDisplayed, quoteNumber, "Quote number and Quote progress is saved text are displayed.");
            if (!pageName.equals(ADDITIONAL_COVERAGES)) {
                final String EXPECTED_QUOTE_PROGRESS_SAVED = "Quote progress is saved!";
                fsa.assertEquals(getTextFromElement(saveInProgressFooter), EXPECTED_QUOTE_PROGRESS_SAVED, pageName + " - Quote progress is saved.");
            }
        }
    }

    public void validateDiscounts(String pageName, ApplicantAceHome applicant, String lobType, FarmersSoftAssert fsa) throws Exception {
        List<String> expectedDiscounts = new ArrayList<>();
        if (isWelcomeDiscountApplicableInHRC(applicant.getStateCode())) {
            expectedDiscounts.add(WELCOME);
        }
        if (!isNoPropertyClaimsQuestionOnAddressPage(applicant.getStateCode()) && !lobType.equals(RENTERS)) {
            expectedDiscounts.add(CLAIM_FREE_DISCOUNT);
        }
        if (!isNoGoodPayerDiscountState(applicant.getStateCode())) {
            expectedDiscounts.add(GOOD_PAYER_DISCOUNT);
        }
        switch (lobType) {
            case HOME:
            case TOWNHOME:
            case DUPLEX:
                getListOfExpectedDiscountsFromHomePage(pageName, applicant, expectedDiscounts);
                break;
            case CONDO:
                getListOfExpectedDiscountsFromCondoPage(pageName, applicant, expectedDiscounts);
                break;
            case RENTERS:
                getListOfExpectedDiscountsFromRentersPage(pageName, applicant, expectedDiscounts);
                break;
            default:
                Log.error("Unknown property type: " + lobType);
                break;
        }
        expectedDiscounts = expectedDiscounts.stream().distinct().sorted().collect(Collectors.toList());
        int numberOfDiscounts = expectedDiscounts.size();
        if (isElementDisplayed(discountsDescription, 2)) {
        	String discountsFoundExpectedLabel = numberOfDiscounts == 1? "1 discount applied" : numberOfDiscounts + " discounts applied";
            fsa.assertEquals(getTextFromElement(discountsDescription),  discountsFoundExpectedLabel, pageName + " page - Discounts applied subtitle text.");
            fsa.assertTrue(isElementDisplayed(discountPiggyBankImage, 3), pageName + " - Discounts piggy bank image");
        }
        List<String> appliedDiscounts = openSideSheetAndGetDiscounts();
        fsa.assertEquals(getTextFromElement(discountsSidesheetTitle), numberOfDiscounts == 1? "Discount applied" : "Discounts applied", pageName + " page - Discounts Side sheet Title.");
        fsa.assertEquals(getTextFromElement(discountsSidesheetSubTitle), "All discounts applied to the quote.", pageName + " page - Discounts Side sheet SubTitle.");
        fsa.assertEquals(getTextFromElement(discountsSidesheetAppliedText), String.format("Applied (%s)", expectedDiscounts.size()),
                pageName + " - Discounts Side sheet Discounts Applied text.");
        List<String> appStoreDiscounts = getSessionStorageAppStore().getHome().getDiscounts().stream().map(AppStore.Home.Discounts::getName).sorted().collect(Collectors.toList());
        Log.info("Expected discounts: " + expectedDiscounts);
        Log.info("Applied discounts: " + appliedDiscounts);
        Log.info("Discounts from Session Storage appStore: " + appStoreDiscounts);
        fsa.assertEquals(appliedDiscounts, expectedDiscounts, pageName + " page - Discounts Side sheet, Expected discounts list.");
        fsa.assertEquals(appStoreDiscounts, expectedDiscounts, pageName + " page - Discounts Side sheet, Expected discounts vs. appStore list.");
        if (!pageName.equals(PROPERTY_DETAILS) && !pageName.equals(QUALITY_GRADE)) {
            String separator = isSafariBrowser() ? EMPTY_STRING : SPACE;
            String discountsFooterNote = String.format("Please note%sWe may ask for supporting documents related to these discounts after you purchase a policy.", separator);
            fsa.assertEquals(getTextFromElement(footerDiscountsSidesheet), discountsFooterNote, pageName + " page - Discounts side-sheet footer note is found.");
        }
        closeSideSheetByEscKey(fsa);
    }

    public void getListOfExpectedDiscountsFromHomePage(String pageName, ApplicantAceHome applicant, List<String> expectedDiscounts) throws Exception {
        AppStore.Home.Quote homeQuote = getSessionStorageAppStore().getHome().getQuote();
        String roofCoverType = getSessionStorageAppStore().getHome().getPropertyDetailsForm()
                .getFields().stream().filter(i -> i.getFieldName().equals("roofCover")).findFirst()
                .map(f -> f.getValues().get(0).getWebDesc())
                .orElse(EMPTY_STRING);
        String stateCode = applicant.getStateCode();
        switch (pageName) {
            case ADDITIONAL_COVERAGES:
            case REVIEW_QUOTE:
                if (homeQuote.getSelectedPaymentMode().equals("PIF") && !stateCode.equals(CA)) {
                    expectedDiscounts.add(PREFERRED_PAYMENT_PLAN);
                }
                if (stateCode.equals(OK)) {
                    expectedDiscounts.remove(CLAIM_FREE_DISCOUNT);
                } else {
                    expectedDiscounts.add(CLAIM_FREE_DISCOUNT);
                }
                if (((Year.now().minusYears(applicant.getYearBuilt())).getValue() < 14) &&
                        (isSPHOState(stateCode))) {
                    expectedDiscounts.add(NEW_HOME);
                }
                if (isPaperlessDiscountStateHome(stateCode)) {
                    expectedDiscounts.add(PAPERLESS_DISCOUNT);
                }
                if (applicant.getStateCode().equals(MD)) {
                    expectedDiscounts.remove(GOOD_PAYER_DISCOUNT);
                }
                if (stateCode.equals(KS)) {
                    expectedDiscounts.remove(THEFT_PROTECTION_DISCOUNT);
                }
                if (!homeQuote.getRateQuoteResponses().get(0).getPersHomePolicy().getDiscount().isEmpty()) {
                    for (AppStore.Home.Discount discount : homeQuote.getRateQuoteResponses().get(0).getPersHomePolicy().getDiscount()) {
                        if (discount.getName().equals(SPRINKLER_DISCOUNT)) {
                            expectedDiscounts.add(SPRINKLER_DISCOUNT);
                            break;
                        }
                    }
                }
                // fallthrough
            case DWELLING_COVERAGE:
                if ((applicant.getEarlyShoppingFactor().equalsIgnoreCase(TRUE) ||
                        !applicant.getEarlyShoppingFactor().isBlank())
                        && !applicant.getEarlyShoppingFactor().equalsIgnoreCase(FALSE)
                        && !stateCode.equals(CA)) {
                    expectedDiscounts.add(EARLY_SHOPPING_DISCOUNT);
                }
                // fallthrough
            case CONTACT_INFO:
                List<SqlDiscount> discounts = applicant.getDiscounts();
                SqlDiscount discount = discounts.stream().findFirst().get();
                if (discount.isAutoInsurance()) {
                    expectedDiscounts.add(AUTO_HOME_DISCOUNT);
                }
                if (discount.isLifeInsurance() && !isNoLifeBundleState(stateCode)) {
                    expectedDiscounts.add(HOME_LIFE_DISCOUNT);
                }
                if (discount.isUmbrellaInsurance() && isUmbrellaAvailableState(stateCode)) {
                    expectedDiscounts.add(HOME_UMBRELLA_DISCOUNT);
                }
                if (stateCode.equals(CA) && discount.isMultiPolicyCEA()) {
                    expectedDiscounts.add(HOME_CEA_DISCOUNT);
                }
                if (discount.isBusinessInsurance() && isAdditionalHomeBundleDiscountsState(stateCode)) {
                    expectedDiscounts.add(HOME_BUSINESS_DISCOUNT);
                }
                if (discount.isRecreationalBoatWatercraftInsurance() && isAdditionalHomeBundleDiscountsState(stateCode)) {
                    expectedDiscounts.add(HOME_WATERCRAFT_DISCOUNT);
                }
                if (discount.isMotorcycleInsurance() && isAdditionalHomeBundleDiscountsState(stateCode)) {
                    expectedDiscounts.add(HOME_OFF_ROAD_VEHICLE_DISCOUNT);
                }
                if (discount.isMotorHome() && isAdditionalHomeBundleDiscountsState(stateCode)) {
                    expectedDiscounts.add(HOME_RV_DISCOUNT);
                }
                if (stateCode.equals(CA) && !applicant.getWildFireRisk().isBlank()) {
                    expectedDiscounts.add(WILDFIRE_MITIGATION_DISCOUNT);
                }
                // fallthrough
            case ABOUT_YOU:
                if (!applicant.getOccupation().isBlank() && !isNoEligibleOccupationState(stateCode) && !stateCode.equals(TN)) {
                    expectedDiscounts.add(PROFESSION_GROUP_DISCOUNT);
                }
                // fallthrough
            case ADDITIONAL_INFO:
                if ((!applicant.getFireAlarm().isBlank() || !applicant.getSprinklerSystem().isBlank()) &&
                        !isCentralFireAlarmState(stateCode)) {
                    expectedDiscounts.add(FIRE_PROTECTION_DISCOUNT);
                }
                if (applicant.isCentralFireAlarm() && isCentralFireAlarmState(stateCode)) {
                    expectedDiscounts.add(CENTRAL_FIRE_ALARM_DISCOUNT);
                }
                if (!applicant.getBurglarAlarm().isBlank() && !isCentralBurglarAlarmState(stateCode)) {
                    expectedDiscounts.add(THEFT_PROTECTION_DISCOUNT);
                }
                if (applicant.isCentralBurglarAlarm() && isCentralBurglarAlarmState(stateCode)) {
                    expectedDiscounts.add(CENTRAL_BURGLAR_ALARM_DISCOUNT);
                }
                if (!applicant.getWaterLeakProtection().isBlank() && !isOtherHomeProtectionFeaturesState(stateCode)) {
                    expectedDiscounts.add(WATER_PROTECTION_DISCOUNT);
                }
                if ((applicant.getWaterLeakProtection().contains("Whole house") || applicant.getFortifiedHome().contains("FORTIFIED Home")) &&
                        isOtherHomeProtectionFeaturesState(stateCode)) {
                    expectedDiscounts.add(HOME_PROTECTION_DISCOUNT);
                }
                if (!applicant.getFortifiedHome().isBlank() && !isOtherHomeProtectionFeaturesState(stateCode)) {
                    if (!stateCode.equals(MS)) {
                        expectedDiscounts.add(FORTIFIED_HOME_DISCOUNT);
                    } else {
                        expectedDiscounts.add(WINDSTORM_MITIGATION_DISCOUNT);
                    }
                }
                if (applicant.isWroughtIronBars()) {
                    expectedDiscounts.add(WROUGHT_IRON_BARS_DISCOUNT);
                }
                if (!applicant.getPreviousInsurance().isBlank()) {
                    expectedDiscounts.add(HOME_TRANSFER_DISCOUNT);
                }
                if (!applicant.getWildFireRisk().isBlank() && (!stateCode.equals(CA))) {
                    expectedDiscounts.add(WILDFIRE_MITIGATION_DISCOUNT);
                }
                if (applicant.isNonSmoker()) {
                    expectedDiscounts.add("Non-smoker");
                }
                if (!applicant.getAlarmSystem().isBlank() && !isOtherHomeProtectionFeaturesState(stateCode)) {
                    expectedDiscounts.add(HOME_PROTECTION_DISCOUNT);
                }
                if (!applicant.getElectricalUpdated().isBlank() && isElectricalPlumbingHvacState(stateCode) && !stateCode.equals(MN)) {
                    expectedDiscounts.add(ELECTRICAL_SYSTEM_REPLACEMENT_DISCOUNT);
                }
                if (!applicant.getPlumbingUpdated().isBlank() && isElectricalPlumbingHvacState(stateCode) && !stateCode.equals(MN)) {
                    expectedDiscounts.add(PLUMBING_SYSTEM_REPLACEMENT_DISCOUNT);
                }
                if (!applicant.getHvacUpdated().isBlank() && isElectricalPlumbingHvacState(stateCode) && !stateCode.equals(MN)) {
                    expectedDiscounts.add(HVAC_REPLACEMENT_DISCOUNT);
                }
                if (List.of(ARCHITECTURAL_SHINGLE, THREE_TAB_SHINGLE, IMPACT_RESISTANT_SHINGLE).contains(roofCoverType) && isUlRoofState(stateCode)) {
                    if (applicant.getUlRoof().contains("Class 3") || applicant.getUlRoof().contains("Class 4")) {
                        expectedDiscounts.add(UL_ROOF_DISCOUNT);
                    }
                }
                // fallthrough
            case PROPERTY_DETAILS:
            case QUALITY_GRADE:
                if (applicant.isNewlyOwned() && isHomeFlexState(stateCode)) {
                    expectedDiscounts.add(HOME_BUYER_DISCOUNT);
                }
                break;
            default:
                Log.error(UNKNOWN_PAGE_NAME + pageName);
                break;
        }
    }

	public void getListOfExpectedDiscountsFromCondoPage(String pageName, ApplicantAceHome applicant, List<String> expectedDiscounts) {
        String stateCode = applicant.getStateCode();
        switch (pageName) {
            case ADDITIONAL_COVERAGES:
            case REVIEW_QUOTE:
                if (stateCode.equals(OK)) {
                    expectedDiscounts.remove(CLAIM_FREE_DISCOUNT);
                } else {
                    expectedDiscounts.add(CLAIM_FREE_DISCOUNT);
                }
                if (stateCode.equals(MD)) {
                    expectedDiscounts.remove(GOOD_PAYER_DISCOUNT);
                }
                // fallthrough
            case CUSTOM_COVERAGE:
                if (applicant.getEarlyShoppingFactor().equalsIgnoreCase(TRUE)) {
                    expectedDiscounts.add(EARLY_SHOPPING_DISCOUNT);
                }
                // fallthrough
            case CONTACT_INFO:
                List<SqlDiscount> discounts = applicant.getDiscounts();
                SqlDiscount discount = discounts.stream().findFirst().get();
                if (discount.isAutoInsurance()) {
                    expectedDiscounts.add(AUTO_HOME_DISCOUNT);
                }
                /* DE302978 - Life discount is getting dropped in verify call (if user is not a life insurance policyholder.
                    To avoid the test failures, we are updating Life insurance as false in discount sheet.
                */
                if (discount.isLifeInsurance() && !isNoLifeBundleState(stateCode)) {
                    expectedDiscounts.add(HOME_LIFE_DISCOUNT);
                }
                if (discount.isUmbrellaInsurance() && isUmbrellaAvailableState(stateCode)) {
                    expectedDiscounts.add(HOME_UMBRELLA_DISCOUNT);
                }
                if (discount.isBusinessInsurance()) {
                    expectedDiscounts.add(HOME_BUSINESS_DISCOUNT);
                }
                if (discount.isRecreationalBoatWatercraftInsurance()) {
                    expectedDiscounts.add(HOME_WATERCRAFT_DISCOUNT);
                }
                if (discount.isMotorcycleInsurance()) {
                    expectedDiscounts.add(HOME_OFF_ROAD_VEHICLE_DISCOUNT);
                }
                if (discount.isMotorHome()) {
                    expectedDiscounts.add(HOME_RV_DISCOUNT);
                }
                // fallthrough
            case ABOUT_YOU:
                if (!applicant.getOccupation().isBlank() && !isNoEligibleOccupationState(stateCode)) {
                    expectedDiscounts.add(PROFESSION_GROUP_DISCOUNT);
                }
                // fallthrough
            case ADDITIONAL_INFO:
                if (!List.of(KY, LA, MA, MS).contains(stateCode)) {
                    if (applicant.isCentralFireAlarm()) {
                        expectedDiscounts.add(CENTRAL_FIRE_ALARM_DISCOUNT);
                    }
                    if (applicant.isCentralBurglarAlarm()) {
                        expectedDiscounts.add(CENTRAL_BURGLAR_ALARM_DISCOUNT);
                    }
                    if (stateCode.equals(NC)) {
                        if (!applicant.getSprinklerSystem().isBlank() || applicant.getSmokeAlarm().equals(YES)) {
                            expectedDiscounts.add(FIRE_PROTECTION_DISCOUNT);
                        }
                        if (applicant.isLocalBurglarAlarm()) {
                            expectedDiscounts.add(LOCAL_BURGLAR_ALARM_DISCOUNT);
                        }
                        if (applicant.isLocalFireAlarm()) {
                            expectedDiscounts.add(LOCAL_FIRE_ALARM_DISCOUNT);
                        }
                        if (!applicant.getWaterLeakProtection().isBlank()) {
                            expectedDiscounts.add(WATER_PROTECTION_DISCOUNT);
                        }
                    }
                } else {
                    if ((!applicant.getFireAlarm().isBlank() || !applicant.getSprinklerSystem().isBlank()) &&
                            !isCentralFireAlarmState(stateCode)) {
                        expectedDiscounts.add(FIRE_PROTECTION_DISCOUNT);
                    }
                    if (!applicant.getBurglarAlarm().isBlank()) {
                        expectedDiscounts.add(THEFT_PROTECTION_DISCOUNT);
                    }
                    if (!applicant.getWaterLeakProtection().isBlank()) {
                        expectedDiscounts.add(WATER_PROTECTION_DISCOUNT);
                    }
                }
                // fallthrough
            case PROPERTY_DETAILS:
            case QUALITY_GRADE:
                if (isWelcomeDiscountStateRC(stateCode)) {
                    expectedDiscounts.add(WELCOME);
                }
                if (!List.of(CA, KY, LA, MA, MS, NC).contains(stateCode)) {
                    expectedDiscounts.add(PAPERLESS_DISCOUNT);
                }
                break;
            default:
                Log.error(UNKNOWN_PAGE_NAME + pageName);
                break;
        }
        if (List.of(REVIEW_QUOTE, ADDITIONAL_COVERAGES).contains(pageName) && stateCode.equals(WA)) {
            expectedDiscounts.remove(PROFESSION_GROUP_DISCOUNT);
        }
    }

    public void getListOfExpectedDiscountsFromRentersPage(String pageName, ApplicantAceHome applicant, List<String> expectedDiscounts) {
        String stateCode = applicant.getStateCode();
        switch (pageName) {
            case ADDITIONAL_COVERAGES:
            case REVIEW_QUOTE:
                if (stateCode.equals(OK)) {
                    expectedDiscounts.remove(CLAIM_FREE_DISCOUNT);
                } else {
                    expectedDiscounts.add(CLAIM_FREE_DISCOUNT);
                }
                if (applicant.getStateCode().equals(MD)) {
                    expectedDiscounts.remove(GOOD_PAYER_DISCOUNT);
                }
                // fallthrough
            case CUSTOM_COVERAGE:
            case CONTACT_INFO:
                List<SqlDiscount> discounts = applicant.getDiscounts();
                SqlDiscount discount = discounts.stream().findFirst().get();
                if (discount.isAutoInsurance()) {
                    expectedDiscounts.add(AUTO_HOME_DISCOUNT);
                }
                if (discount.isLifeInsurance() && !isNoLifeBundleState(stateCode)) {
                    expectedDiscounts.add(HOME_LIFE_DISCOUNT);
                }
                if (discount.isUmbrellaInsurance() && isUmbrellaAvailableState(stateCode)) {
                    expectedDiscounts.add(HOME_UMBRELLA_DISCOUNT);
                }
                if (discount.isBusinessInsurance()) {
                    expectedDiscounts.add(HOME_BUSINESS_DISCOUNT);
                }
                if (discount.isRecreationalBoatWatercraftInsurance()) {
                    expectedDiscounts.add(HOME_WATERCRAFT_DISCOUNT);
                }
                if (discount.isMotorcycleInsurance()) {
                    expectedDiscounts.add(HOME_OFF_ROAD_VEHICLE_DISCOUNT);
                }
                if (discount.isMotorHome()) {
                    expectedDiscounts.add(HOME_RV_DISCOUNT);
                }
                // fallthrough
            case ABOUT_YOU:
            case PROPERTY_DETAILS:
                if (isWelcomeDiscountStateRC(stateCode)) {
                    expectedDiscounts.add(WELCOME);
                }
                if (!List.of(KY, LA, MA, MS, NC).contains(stateCode)) {
                    expectedDiscounts.add(PAPERLESS_DISCOUNT);
                }
                break;
            default:
                Log.error(UNKNOWN_PAGE_NAME + pageName);
                break;
        }
    }

    public void validateDiscounts(String pageName, List<String> expectedDiscounts, FarmersSoftAssert fsa) throws Exception {
        if (isElementVisible(discountsDescription, 2)) {
            fsa.assertTrue(getTextFromElement(discountsDescription).contains(String.valueOf(expectedDiscounts.size())), "discounts applied" + pageName + " page - Discounts applied subtitle.");
            fsa.assertTrue(discountPiggyBankImage.isVisible(), pageName + " - Discounts piggy bank image");
            waitAndClickElement(reviewDiscountsLink);
        } else {
//TODO: Check discounts and savings lines in the quote presentment card for mobile and desktop views.

        }
        fsa.assertEquals(getTextFromElement(discountsSidesheetTitle), "Discounts applied", pageName + "page - Discounts Side sheet Title.");
        fsa.assertEquals(getTextFromElement(discountsSidesheetSubTitle), "All discounts applied to the quote.", pageName + " page - Discounts Side sheet SubTitle.");
        fsa.assertEquals(getTextFromElement(discountsSidesheetAppliedText), String.format("Applied (%s)", expectedDiscounts.size()),
                pageName + " - Discounts Side sheet Discounts Applied text.");
        List<String> appliedDiscounts = locators(pwXPath(DISCOUNT_NAMES_XPATH)).stream().map(this::getTextFromElement).map(String::strip).collect(Collectors.toList());
        Collections.sort(expectedDiscounts);
        Collections.sort(appliedDiscounts);
        List<String> appStoreDiscounts = getSessionStorageAppStore().getHome().getDiscounts().stream().map(AppStore.Home.Discounts::getName).sorted().collect(Collectors.toList());
        Log.info("Expected discounts: " + expectedDiscounts);
        Log.info("Applied discounts: " + appliedDiscounts);
        Log.info("Discounts from Session Storage appStore: " + getSessionStorageAppStore().getHome().getDiscounts());
        fsa.assertEquals(appliedDiscounts, expectedDiscounts, pageName + " page - Discounts Side sheet, Expected discounts list.");
        fsa.assertEquals(appStoreDiscounts, expectedDiscounts, pageName + " page - Discounts Side sheet, Expected discounts vs. appStore list.");
        closeSideSheetByEscKey(fsa);
    }

    public List<String> getDiscounts() throws Exception {
        List<String> appliedDiscounts = openSideSheetAndGetDiscounts();
        waitAndClickElement(closeDiscountsSidesheet);
        return appliedDiscounts;
    }

    public List<String> openSideSheetAndGetDiscounts() throws Exception {
        waitAndClickElement(reviewDiscountsLink, 5);
        if (!isElementVisible(discountsSidesheetAppliedText, 10)) {
            waitAndClickElement(reviewDiscountsLink, 5);
        }
        List<String> appliedDiscounts = locators(pwXPath(DISCOUNT_NAMES_XPATH)).stream().
                map(this::getTextFromElement).map(String::strip).sorted().collect(Collectors.toList());
        Log.info("Displayed discounts: " + appliedDiscounts);
        return appliedDiscounts;
    }

    public void saveQuoteSubmit(String email) throws Exception {
        clickOnSaveQuoteButton();
        if (isElementDisplayed(saveQuoteModalEmailInputField, 2)) {
            if (getValueFromLocator(saveQuoteModalEmailInputField).isBlank()) {
                waitAndClickElement(saveQuoteModalEmailInputField);
                sendKeysToElement(saveQuoteModalEmailInputField, email);
            }
            clickSaveQuoteModalSubmitButton();
            waitForSpinnerToBeGone();
        }
    }

    public int randomNumberBetweenTwoNumbers(int low, int high) {
        Random r = new Random();
        return r.nextInt(high - low) + low;
    }

    public int roundToThousand(int number) {
        return (number / 1000) * 1000;
    }

    protected void logQuoteNumber(ApplicantAceHome applicant, String lob, String quoteNumber) {
        writeRatedQuoteInformationToFile("Ace " + lob + " - " + quoteNumber + SPACE + applicant.getFirstName() + SPACE + applicant.getLastName() +
                SPACE + applicant.getAddress() + SPACE + applicant.getCity() + SPACE + applicant.getStateCode() + SPACE + applicant.getZipCode());
    }


    public int getIntCurrencyValueFromStringCurrencyValue(String currencyValue) {
        return Integer.parseInt(currencyValue.replaceAll("[$,]", ""));
    }

    public void validateBrowserForwardButtonIsDisabled(FarmersSoftAssert fsa, String currentPageUrlEnd) throws Exception {
        forward();
        waitForPageToBeReady();
        fsa.assertEquals(page().url().endsWith(currentPageUrlEnd), true, "Browser forward button should be disabled.");
    }

    protected void checkUncheckMatCheckbox(String checkboxXpath, boolean check) throws Exception {
        Locator checkBoxWe = locator(pwXPath(checkboxXpath));
        boolean selected = getAttributeData(checkBoxWe, CLASS).contains(CHECKBOX_CHECKED);
        if (selected != check) {
            scrollAndClickOnElement(checkBoxWe);
            checkBoxWe = locator(pwXPath(checkboxXpath));
            selected = getAttributeData(checkBoxWe, CLASS).contains(CHECKBOX_CHECKED);
            if (selected != check) {
                checkBoxWe = locator(pwXPath(checkboxXpath + "/descendant::label"));
                scrollAndClickOnElement(checkBoxWe);
            }
        }
    }

    public String getSelectedPackageName() throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        String selectedPackageCode = appStore.getHome().getQuote().getSelectedPackageCode();
        String selectedPackageName = EMPTY_STRING;
        switch (selectedPackageCode) {
            case "S":
                selectedPackageName = "Standard";
                break;
            case "E":
                selectedPackageName = "Enhanced";
                break;
            case "P":
                selectedPackageName = "Premier";
                break;
            case "C":
                selectedPackageName = "Custom";
                break;
            default:
                Log.error("Unknown package code: " + selectedPackageCode);
                break;
        }
        return selectedPackageName;
    }

    public void validateQuoteProgressSavedContent(FarmersSoftAssert fsa) {
        final String QUOTE_PROGRESS_TEXT = "Quote progress is saved!";
        fsa.assertEquals(getTextFromElement(quoteProgressSavedText), QUOTE_PROGRESS_TEXT, "Quote Progress text verification.");
    }

    public String getSelectedPaymentMode() throws Exception {
        return getSessionStorageAppStore().getHome().getQuote().getSelectedPaymentMode();
    }

    public boolean isValidateWroughtIronBarSection(ApplicantAceHome applicantAceHome) {
        return applicantAceHome.getStateCode().equals(NM) && applicantAceHome.isWroughtIronBars();
    }

    public boolean isAdditionalHomeBundleDiscountsState(String stateCode) {
        List<String> listStates = new ArrayList<>(Arrays.asList(KS, KY, LA, MA, MS, NC, IN, IA, MD, MN, MT, OH, WA));
        return listStates.contains(stateCode);
    }

    public boolean isStormShuttersEnabledState(String stateCode) {
        return Arrays.asList(PA, TX, VA, NC).contains(stateCode);
    }

    public boolean isSPHOState(String stateCode) {
        return List.of(KS, KY, LA, MA, MS, NC).contains(stateCode);
    }

    public boolean isNonUmbrellaState(String stateCode) {
        return List.of(KY, LA, MA, MS, NC).contains(stateCode);
    }

    public boolean isNoEligibleOccupationState(String stateCode) {
        return List.of(KY, LA, MA, MN, MS, NC, TN).contains(stateCode);
    }

    public boolean isNoSolarPanelsState(String stateCode) {
        return List.of(NM, OR, KS, KY, LA, MA, MN, MS, NC, IA, IN, MD, MN, MT, OH, WA, GA, CT).contains(stateCode);
    }

    public boolean isNoHomeShareState(String stateCode) {
        return List.of(KS, IA, IN, MD, MN, MT, OH, WA).contains(stateCode);
    }

    public boolean isOtherHomeProtectionFeaturesState(String stateCode) {
        return List.of(KS, IA, IN, MD, MN, MT, OH, WA).contains(stateCode);
    }

    public boolean isNonSmokerState(String stateCode) {
        return List.of(KS, IA, IN, MD, MN, MT, OH, WA).contains(stateCode);
    }

    public boolean isCentralFireAlarmState(String stateCode) {
        return List.of(IA, IN, MD, MN, MT, OH, WA).contains(stateCode);
    }

    public boolean isCentralBurglarAlarmState(String stateCode) {
        return List.of(IA, IN, MD, MN, MT, OH, WA).contains(stateCode);
    }

    public boolean isNoWelcomeDiscountState(String stateCode) {
        return List.of(ND, IA, IN, KS, KY, LA, MD, MA, MN, MS, NC, OH, WA).contains(stateCode);
    }

    public boolean isWelcomeDiscountApplicableInHRC(String stateCode) {
        return List.of(OK, PA, UT, AZ, IL, TX, CO, MO, NJ, NV, GA, ID, NE, NM, OR, TN, WI, WY, AL, AR, CT, MI, SD, VA).contains(stateCode);
    }

    public boolean isWelcomeDiscountStateRC(String stateCode) {
        return List.of(OH, IA, IN, KS, MD, MN, NY).contains(stateCode);
    }

    public boolean hasTemporaryRentalSectionOption(String stateCode) {
        return List.of(IA, IN, KS, MD, MN, OH, WA).contains(stateCode);
    }

    public boolean isLocalBurglarAlarmState(String stateCode) {
        return List.of(NC).contains(stateCode);
    }

    public boolean isLocalFireAlarmState(String stateCode) {
        return List.of(NC).contains(stateCode);
    }

    public boolean isNoLifeBundleState(String stateCode) {
        return List.of(AL, CA, CT).contains(stateCode);
    }

    public boolean isEmergencyMortgageAssistanceState(String stateCode) {
        return List.of(AL, AR, AZ, CO, CT, GA, ID, IL, MI, MO, NE, NM, ND, OK, OR, PA, SD, TN, TX, UT, VA, WI, WY).contains(stateCode);
    }

    public boolean isPrimaryResidenceHasFourOptions(String stateCode) {
        return List.of(AZ, GA, MO, PA).contains(stateCode);
    }

    public boolean isAccessThroughFoundationsAndWallsState(String stateCode) {
        return List.of(AR, IA, ID, IL, MI, NE, NM, OK, OR, TX, WA).contains(stateCode);
    }

    // to handle A/B testing for Property claims question (AZ,GA,IL,TX) F83275 - US947028 (the test is paused)
    public boolean isNoPropertyClaimsQuestionOnAddressPage(String stateCode) {
        return false; // List.of(AZ,GA,IL,TX).contains(stateCode);
    }

    public boolean isNoGoodPayerDiscountState(String stateCode) {
        return List.of(CA, NC).contains(stateCode);
    }

    public boolean isHomeFlexState(String stateCode) {
        return List.of(AL, AR, AZ, CA, CO, CT, GA, ID, IL, MI, MO, ND, NE, NM, OK, OR, PA, SD, TN, TX, UT, VA, WI, WY).contains(stateCode);
    }

    private boolean isUmbrellaAvailableState(String stateCode) {
		return !List.of(KY).contains(stateCode);
	}

    public boolean isNamedPerilsState(String stateCode) {
        return List.of(AL, AZ, CO, CT, GA, ID, KS, IL, LA, MI, MS, MT, NM, OH, OK, OR, PA, SD, TN, TX, UT, WA, WI, WY).contains(stateCode);
    }

    public boolean isExtendedDeductibleOptionsState(String stateCode) {
        // F82552, F82553 - NM, ID, OR - added 1.5% and 3% All peril deductibles
        return List.of(AZ, ID, IL, MO, NM, OR, UT).contains(stateCode);
    }

    public boolean isPaperlessDiscountStateHome(String stateCode) {
        return List.of(IA, IN, MN, MT, OH, WA).contains(stateCode);
    }

    public boolean isEditPrimaryCoveragesState(String stateCode) {
        return List.of(AR,AZ,CO,ID,IL,MO,ND,NE,NM,OK,OR,PA,SD,UT,VA).contains(stateCode);
    }

    public boolean isRCTOneMilLimitState(String stateCode) {
        return List.of(AR, CA, OK, TX).contains(stateCode);
    }

    public boolean isUlRoofState(String stateCode) {
        // MD state removed after PO confirmed it was removed from F95512 last minute before R12/2025 release
        return List.of(KS, IA, IN, MN, MT, OH, WA).contains(stateCode);
    }

    public boolean isQnBState(String stateCode) {
        return List.of(ME, MS, NH, VT, WV).contains(stateCode);
    }

    public boolean isHomeToAutoBundleEligibleAndEnabled(String stateCode) throws Exception {
        //  US1111653: Home Monoline#1 - Check Bundle eligibility based on zip and hide bundle option in Contact info
        boolean isHomeToAutoBundleEligible = getSessionStorageAppStore().getData().isHomeToAutoBundleEligible();
        return List.of(AZ, GA, OR).contains(stateCode) && isHomeToAutoBundleEligible;
    }

    public boolean isElectricalPlumbingHvacState(String stateCode) {
        return List.of(MN, WA).contains(stateCode);
    }

    protected void reportKnockout() throws Exception {
        if (page().url().endsWith("/knockout")) {
            AppStore appStore = getSessionStorageAppStore();
            List<AppStore.KnockOut> knockouts = appStore.getKnockouts();
            if (!knockouts.isEmpty()) {
                try {
                    AppStore.KnockOut knockOut = knockouts.stream().filter(k -> (k.getErrorCode() != null)).findFirst().get();
                    Log.error("The quote was knocked-out with error code: " + knockOut.getErrorCode());
                } catch (Exception e) {
                    Log.error("The quote received a knock-out.");
                }
            }
        }
    }

    public List<String> getKnockoutErrors() throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        List<AppStore.KnockOut> knockouts = appStore.getKnockouts();
        return knockouts.stream()
                .map(AppStore.KnockOut::getErrorCode)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    public List<String> getKnockoutCodes() throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        List<AppStore.KnockOut> knockouts = appStore.getKnockouts();
        return knockouts.stream()
                .map(AppStore.KnockOut::getKnockoutCode)
                .filter(Objects::nonNull).sorted()
                .collect(Collectors.toList());
    }

    protected static final String TRY_AGAIN_ATTEMPTS_LIMIT_EXCEEDED = "Limit of 'Try again' attempts reached";
    protected boolean isTryAgainPagePresent() {
        return isElementPresent(pwXPath(TRY_AGAIN_BUTTON_XPATH), 3);
    }

    protected boolean wasTryAgainSuccessful() {
        boolean tryAgainSuccessful = false;
        for (int i=0; i < 3; i++) {
            Log.info("Click 'Try again', attempt: " + (i+1));
            scrollAndClickOnElement(tryAgainButton);
            waitForSpinnerToBeGone();
            waitForSkeletonToBeGone();
            waitForOneMomentPageToBeGone();
            if (!isTryAgainPagePresent()) {
                tryAgainSuccessful = true;
                break;
            }
        }
        return tryAgainSuccessful;
    }

    public void closeSideSheetByEscKey(FarmersSoftAssert fsa) {
        pressEscKey();
        fsa.assertTrue(waitElementBeInvisible(sideSheet), "Side sheet is displaying");
    }

    public void updateApplicantForProdValidation(ApplicantAceHome applicant) {
        if (isProdEnvironment()) {
            applicant.setFirstName(PRODUCTION_APPLICANT_FIRST_NAME);
            applicant.setLastName(PRODUCTION_APPLICANT_LAST_NAME);
            applicant.setEmailAddress(PRODUCTION_APPLICANT_EMAIL);
        }
    }

    //Mobile home common header elements
        private Locator foremostLogoIcon = locator(pwXPath("//img[@alt = 'Foremost logo']"));
        private Locator foremostPageHeader = locator(pwXPath("//div[contains(@class, 'mobilehome-logo-body')]"));
    protected void verifyMobileHomeCommonHeader(FarmersSoftAssert fsa) throws Exception {
    	fsa.assertTrue(foremostLogoIcon.isVisible(), "Foremost icon displayed in page");
    	fsa.assertTrue(getAttributeData(foremostLogoIcon, SRC).contains("foremost"), "Foremost icon using expected image");
    	fsa.assertEquals(getTextFromElement(foremostPageHeader), "Mobile home policy insured and serviced by Foremost, a Farmers company", "Foremost header content");
    }

    public void validateQuoteSourceInd(FarmersSoftAssert fsa, ApplicantAceHome applicant, String lob, String page) throws Exception {
        String expectedSourceIndicator = AP;
        if (lob.equals(MEDIA_ALPHA)) {
            expectedSourceIndicator = ME; // used here as a sourceIndicator
        } else if (applicant.getAgentId().isBlank()) {
            expectedSourceIndicator = FC;
        }
        validateQuoteSourceIndicator(fsa, expectedSourceIndicator, page);
    }

    public boolean isPayrollDeductionBannerDisplayed() {
        return isElementDisplayed(payrollDeductionBannerContent, 5);
    }

    public void validatePayrollDeductionPopup(FarmersSoftAssert fsa, String pageName) throws Exception {
        Assert.assertTrue(isPayrollDeductionBannerDisplayed(), "Payroll deduction banner should be displayed on " + pageName);
        String EMPLOYER_NAME = getSessionStorageAppStore().getData().getSubmitCustomerResponse().getEmployerName();
        String PAYROLL_DEDUCTION_BANNER_CONTENT = String.format("You may be eligible to enroll in payroll deduction and other benefits through your employment at %s." +
                " A representative can discuss all your options and check for additional discounts.", EMPLOYER_NAME) ;
        fsa.assertEquals(getTextFromElement(payrollDeductionBannerTitle), PAYROLL_DEDUCTION_BANNER_TITLE, "Payroll deduction banner Title verification on " + pageName);
        fsa.assertEquals(getTextFromElement(payrollDeductionBannerContent), PAYROLL_DEDUCTION_BANNER_CONTENT, "Payroll deduction banner content verification on " + pageName);
        fsa.assertEquals(getTextFromElement(payrollDeductionBannerContactInfo), PAYROLL_DEDUCTION_BANNER_CONTACT_INFO, "Payroll deduction banner contact info verification on " + pageName);
    }
}
