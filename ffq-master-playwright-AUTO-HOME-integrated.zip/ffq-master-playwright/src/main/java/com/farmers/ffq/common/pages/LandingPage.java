package com.farmers.ffq.common.pages;




import com.microsoft.playwright.options.ViewportSize;
import com.microsoft.playwright.options.Cookie;
import com.microsoft.playwright.TimeoutError;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.ace.life.AceLifeNameAndDOBPage;
import com.farmers.ffq.ace.life.AceLifePersonalInfoPage;
import com.farmers.ffq.ace.life.AceLifeReviewQuotePage;
import com.farmers.ffq.auto.pages.legacy.*;
import com.farmers.ffq.dataproviders.AutoDataProviders;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.datatransferobjects.hqm.ApplicantHQM;
import com.farmers.ffq.datatransferobjects.hqm.LeadTypeHQM;
import com.farmers.ffq.home.pages.*;
import com.farmers.ffq.utils.AESHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.playwright.PlaywrightArtifacts;
import com.farmers.framework.report.Log;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.testng.Assert;
import org.testng.SkipException;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;


/**
 * Farmers Fast Quote (FFQ) - FFQ Landing page - legacy version.
 */
public class LandingPage extends BasePage {

		private Locator landingPageDisclaimer = locator(pwClass("ffq-landing-disclaimer"));

		private Locator startMyQuoteButton = locator(pwXPath("//div[contains(@class,'landing-button-start')]//button[@type='submit' or @data-gtm='FFQ_Auto_Landing_Newquote_Startmyquote_button'] | //button[@title='Start My Quote']"));

		private Locator getNewQuoteRadioButton = locator(pwId("landing:DecideQuote:0"));

		private Locator retrieveSavedQuoteRadioButton = locator(pwId("landing:DecideQuote:1"));

		private Locator dropdownLOBLabel = locator(pwId("landing:quoteTypeLbl"));

		private Locator dropdownLOB = locator(pwId("landing:quoteType"));

		private Locator zipCodeLabel = locator(pwId("landing:zipCodeLbl"));

	private static final String XPATH_TO_ZIP_CODE_FIELD = "//input[@aria-label='Zip code']";
		private Locator zipCodeField = locator(pwXPath(XPATH_TO_ZIP_CODE_FIELD));

	private static final String XPATH_TO_SUBMIT_BUTTON = "//div[contains(@class,'landing-button-start')]//button[@type='submit' or @data-gtm='FFQ_Auto_Landing_Newquote_Startmyquote_button'] | //button[@title='Start My Quote']";
		private Locator submitButton = locator(pwXPath(XPATH_TO_SUBMIT_BUTTON));

		private Locator lastNameLabel = locator(pwId("landing:lastNameLbl"));

		private Locator lastNameField = locator(pwXPath("//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Lastname_field']//input"));

		private Locator dateOfBirthLabel = locator(pwId("landing:dateOfBirthLbl"));

		private Locator dateOfBirthField = locator(pwXPath("//lib-date-picker[@data-gtm='FFQ_Auto_Landing_Retrievequote_Dateofbirth_field']//input[string-length(@aria-label)>0]"));

		private Locator quoteNumberLabel = locator(pwId("landing:emailquotenumberLbl"));

		private Locator quoteNumberField = locator(pwXPath("//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Quotenumber_field']//input"));

		private Locator zipCodeForRetrieveLabel = locator(pwId("landing:zipcode2Lbl"));

		private Locator zipCodeForRetrieveField = locator(pwXPath("//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Zipcode_field']//input"));

	private static final String UNABLE_TO_LOCATE_QUOTE_ID_STRING = "landingErrorInfoHeading";
		private Locator unableToLocateQuoteDialog = locator(pwId(UNABLE_TO_LOCATE_QUOTE_ID_STRING));

	private static final String XPATH_TO_RETRIEVE_BUTTON = "//button[@title='Retrieve Your Quote' or @data-gtm='FFQ_Auto_Landing_Retrievequote_button' or normalize-space()='Retrieve your quote' or normalize-space()='Retrieve Your Quote']";
		private Locator retrieveQuoteButton = locator(pwXPath(XPATH_TO_RETRIEVE_BUTTON));

		private Locator footerStaticText = locator(pwXPath("//*[@id='DisclaimerLanding']/p/span"));

		private Locator quoteTypeErrorMessage = locator(pwId("quoteTypeError"));

		private Locator zipCodeEntryErrorMessage = locator(pwXPath("//div[@id='ffq-landing-zip-code']//mat-error"));

		private Locator zipCodeErrorMessage = locator(pwXPath("//div[@class='ffq-landing-show-zip-err ng-star-inserted'] | //p[@id='zipCodeError']"));

		private Locator lastNameErrorMessage = locator(pwXPath("//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Lastname_field']//mat-error"));

		private Locator dateOfBirthErrorMessage = locator(pwXPath("//lib-date-picker[@data-gtm='FFQ_Auto_Landing_Retrievequote_Dateofbirth_field']//mat-error"));

		private Locator emailQuoteNumberErrorMessage = locator(pwXPath("//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Quotenumber_field']//mat-error"));

		private Locator zipCodeInRetrieveErrorMessage = locator(pwXPath("//lib-input-text[@data-gtm='FFQ_Auto_Landing_Retrievequote_Zipcode_field']//mat-error"));

		private Locator quoteRetrievalErrorMessage = locator(pwXPath("//div[h2[contains(text(),'We were unable to locate your quote')]]"));

		private Locator buttonCloseErrorDialog = locator(pwXPath("//div[h2[contains(text(),'We were unable to locate your quote')]]//button[text()='CLOSE']"));

		private Locator getNewQuoteTab = locator(pwId("landing-quote"));

		private Locator retrieveSavedQuoteTab = locator(pwId("landing-retrieve"));

		private Locator selectProductErrorMessage = locator(pwXPath("//div/p[@class='ffq-landing-showproduct-err ng-star-inserted']"));

		private Locator autoLOBButton = locator(pwXPath("//*[@value='auto']"));

		private Locator homeLOBButton = locator(pwXPath("//*[@value='home']"));

		private Locator lifeLOBButton = locator(pwXPath("//*[@value='life']"));

		private Locator businessLOBButton = locator(pwXPath("//*[@value='business']"));

		private Locator rentersLOBButton = locator(pwXPath("//*[@value='renter']"));

		private Locator mobileHomeLOBButton = locator(pwXPath("//*[@value='mobilehome']"));

		private Locator condoLOBButton = locator(pwXPath("//*[@value='condo']"));

		private Locator autoHomeBundleButton = locator(pwXPath("//*[@value='autoHome']"));

		private Locator autoRentersBundleButton = locator(pwXPath("//*[@value='autoRenters']"));

		private Locator autoCondoBundleButton = locator(pwXPath("//*[@value='autoCondo']"));

		private Locator infoDialogContent = locator(pwCss("#infoContent"));

		private Locator infoDialogCloseButton = locator(pwCss(".dialog__info-dialog-button-close"));

	private static final String COLOR_ERROR_MSG = " error message color is one of " + RED_RGB + SPACE + RED_RGBA + SPACE + RED_RGB_AUTO_REDESIGN + SPACE + RED_RGBA_AUTO_REDESIGN + SPACE + DARK_RED_RGBA + " or " + DARK_RED_RGB;
	private static final String ZIP_CODE_MSG = "Zip code error message";
	private static final String ENTER_ZIP_CODE = "Please enter ZIP Code.";
	private static final String ENTER_5DIGIT_ZIP_CODE = "Please enter a 5-digit ZIP Code.";
	private static final String PRODUCT_REQUIRED = "Please select a product.";
	private static final String LAST_NAME_REQUIRED = "Please enter Last Name.";
	private static final String DOB_REQUIRED = "Please enter Date of Birth.";
	private static final String QUOTE_OR_EMAIL_REQUIRED = "Please enter Quote Number Or Email Address.";
	private static final String ERROR_FOUND_MSG = "Error message found is: ";
	private static final String NO_POLICIES_OFFERED = "We apologize for this inconvenience, Farmers does not currently offer policies in ";
	private static final String NO_BUNDLE_POLICIES_OFFERED = "We're sorry, we are not able to offer a bundle quote in your area at this time.";
	private static final String CANT_COMPLETE_QUOTE_ONILNE = "We're sorry, a quote cannot be completed online at this time. Please contact your local Farmers Agent for a quote.";
	private static final String ONLINE_QUOTING_UNAVAILABLE = "Farmers online quoting is currently unavailable in your state. Contact Your Farmers Agent or call 1-800-FARMERS.";
	private static final String CLICK_TO_RETURN = ". Click here to return to Farmers.com.";
	private static final String PAGE_DOESNT_EXIST = " page doesn't exist";
	private static final String RETRIEVE_QUOTE_HASHMAP_MISING_KEY = "Retrieve Quote Concurrent Hash Map doesn't contain key: ";
	private static final String LINE_OF_BUSINESS_DOESNT_EXIST = " line of business doesn't exist";
	private static final String UNCHECKED = "unchecked";

	private static final String AWS_ZIP = "?Lob=&Zip_Code=";
	private static final String AWS_STATE = "&platform=LG&Source_Indicator=AS&State_Code=";
	private static final String AWS_AGENTCODE = "&Agent_Code=";
	private static final String AWS_FORMATTING_STRING = "?Lob=%s&Source_Indicator=AP&State_Code=%s&AOR=%s&Zip_Code=%s";

	public LandingPage() throws Exception {
		intializeLandingPage(Property.getUri(), false, false);
	}

	public LandingPage(int justCreateALandingPageObject) throws Exception {
		//This empty constructor is to just get us a landing page object without any navigation or settings associated with other constructors.
	}

	public LandingPage(String url) throws Exception {
		intializeLandingPage(url, false, false);
	}

	public LandingPage(boolean useMobile) throws Exception {
		intializeLandingPage(Property.getUri(), useMobile, false);
	}

	public LandingPage(String url, boolean useMobile) throws Exception {
		intializeLandingPage(url, useMobile, false);
	}

	public LandingPage(boolean useMobile, boolean useFarmersDotCom) throws Exception {
		intializeLandingPage(Property.getUri(), useMobile, useFarmersDotCom);
	}

	public LandingPage(String zipCode, LeadTypeHQM leadType, String browserType) throws Exception {
		conditionalWait(1);
		String url = Property.getEnvironmentProperty("uri_hqm") + "&ZIP=" + zipCode;
		switch (leadType.getLeadType()) {
			case AS:
				if (leadType.getAgentId().isEmpty()) {
					url += "&SRC=FC000000001&Source_Indicator=FC&Data=nQsC4nLgvwtwxXVvMclU1cAEK5hjNkZynMKx1LEdlduyOUoIdGlS0xYjwrNV3YkGHz4SH3Q%2FzUDSgM81sUrMDA%3D%3D";
				} else {
					url += "&AOR=" + leadType.getAgentId() +
							"&SRC=AS000000001&Source_Indicator=AS&Data=%2BfDrl4rHuotPUXhs3tXXGMAEK5hjNkZynMKx1LEdldvDUgqXLcLVEx4BOCJeq27dHz4SH3Q%2FzUDSgM81sUrMDA%3D%3D";
				}
				break;
			case FC:
				url += "&SRC=FC000000001&Source_Indicator=FC&Data=nQsC4nLgvwtwxXVvMclU1cAEK5hjNkZynMKx1LEdlduyOUoIdGlS0xYjwrNV3YkGHz4SH3Q%2FzUDSgM81sUrMDA%3D%3D";
				break;
			case RQ:
				url = Property.getUri();
				break;
			case QQ:
			case QQNPS:
				if (leadType.getLeadType().equals(QQ)) {
					url += "&SRC=QQQARHQKFQ0000001&PpcSrc=QQ&Source_Indicator=QQ&Data=";
				} else {
					url += "&SRC=QQQARHQKFQ0000001&Source_Indicator=QQ&Data=";
				}
				ObjectMapper mapper = new ObjectMapper();
				String customerData = mapper.writeValueAsString(leadType);
				Log.info("Customer Data:"  + customerData);
				url += AESHelper.encryptWithOutIV(customerData);
				break;
			case AEM:
				url += "&SRC=" + leadType.getCampaignId() + "&Data=31MtZKRTa8w0iUjKiF71w%3D%3D";
				break;
			default:
				Log.error("Unknown leadType parameter: " + leadType);
		}
		setWindowDimensions(browserType.startsWith(MOBILE_BROWSER));
		url = Property.ensureFastQuoteEntry(url);
		addAuthCookieIfConfigured();
		Log.info("Navigating to " + url);
		navigate(url);
		assertNotRedirectedToCssTv();
	}

	public LandingPage(String zipCode, LeadTypeHQM leadType, String browserType, String lob) throws Exception {
		conditionalWait(1);
		String lobUrl = lob.equals(RENTERS) ? lob.substring(0, lob.length()-1) : lob;
		String url = Property.getUri() + "?LOB=" + lobUrl.toUpperCase() + "&ZIP=" + zipCode;
		if (Arrays.asList(AUTO, CONDO, RENTERS, LIFE).contains(lob)) {
			url += "&SRC=" + leadType.getLeadType() + "000000001" + "&Source_Indicator=" + leadType.getLeadType() + "&param=";
			if (!lob.equals(AUTO)) {
				String[] dob = leadType.getDob().split("/");
				leadType.setDob(dob[2] + "-" + dob[0] + "-" + dob[1]);
			}
			ObjectMapper mapper = new ObjectMapper();
			LeadTypeCSS leadTypeCSS = new LeadTypeCSS(leadType, lob.toLowerCase());
			String customerData = mapper.writeValueAsString(leadTypeCSS);
			Log.info("Customer Data:" + customerData);
			url += AESHelper.encryptWithOutIV(customerData);
		} else {
			Log.error("Unknown lob parameter: " + lob);
		}
		setWindowDimensions(browserType.startsWith(MOBILE_BROWSER));
		url = Property.ensureFastQuoteEntry(url);
		addAuthCookieIfConfigured();
		Log.info("Navigating to " + url);
		navigate(url);
		assertNotRedirectedToCssTv();
	}

	public LandingPage(Object object) throws Exception {
		String awsURL;
		String applicantType = object.getClass().getSimpleName();
		synchronized (this) {
			switch (applicantType) {
				case AUTO_APPLICANT:
					SqlApplicant autoApplicant = (SqlApplicant) object;
					String agentStateCode = autoApplicant.getStateCode().equals(CA)? autoApplicant.getRepresentative().getAddress() : autoApplicant.getStateCode();
					awsURL = Property.getUri() + AWS_ZIP + autoApplicant.getZipCode() + AWS_STATE + agentStateCode + AWS_AGENTCODE + autoApplicant.getRepresentative().getAor();
					break;
				case ACE_AUTO_APPLICANT:
					AutoApplicant aceAutoApplicant = (AutoApplicant) object;
					awsURL = String.format(Property.getUri() + AWS_FORMATTING_STRING, "A", aceAutoApplicant.getStateCode(), getAgentData(aceAutoApplicant.getStateCode(), new AutoDataProviders()).getAgentOfRecords(), aceAutoApplicant.getZipCode());
					break;
				case ACE_AUTO_ADPF_APPLICANT:
					ADPFApplicant adpfApplicant = (ADPFApplicant) object;
					awsURL = String.format(Property.getUri() + AWS_FORMATTING_STRING, "A", adpfApplicant.getStateCode(), getAgentData(adpfApplicant.getStateCode(), new AutoDataProviders()).getAgentOfRecords(), adpfApplicant.getZipCode());
					break;
				case ACE_BUNDLE_APPLICANT:
					AceBundleApplicant bundleApplicant = (AceBundleApplicant) object;
					AutoApplicant autoBundleApplicant = bundleApplicant.getAutoApplicant();
					awsURL = String.format(Property.getUri() + AWS_FORMATTING_STRING, autoBundleApplicant.getTestScenario(), autoBundleApplicant.getStateCode(), getAgentData(autoBundleApplicant.getStateCode(), new AutoDataProviders()).getAgentOfRecords(), autoBundleApplicant.getZipCode());
					break;
				case ACE_HOME_APPLICANT:
					//actually for the Mobile Home LOB since they share same object with H/R/C
					ApplicantAceHome aceMobilehomeApplicant = (ApplicantAceHome) object;
					if (aceMobilehomeApplicant.getTestCategory().equals(FOREMOST)) {
						awsURL = String.format("https://" + new URL(Property.getUri()).getHost() + "/quote/?Source_Indicator=FRMS&Zip=%s&Lob=M&SRC=FRMS00\u2026", aceMobilehomeApplicant.getZipCode());
					} else {
						awsURL = String.format(Property.getUri() + AWS_FORMATTING_STRING, "M", aceMobilehomeApplicant.getStateCode(), getAgentData(aceMobilehomeApplicant.getStateCode(), new AutoDataProviders()).getAgentOfRecords(), aceMobilehomeApplicant.getZipCode());
					}
					break;
				case BUSINESS_APPLICANT:
					ApplicantBusiness businessApplicant = (ApplicantBusiness) object;
					awsURL = String.format(Property.getUri() + AWS_FORMATTING_STRING, "B", businessApplicant.getStateCode(), getAgentData(businessApplicant.getStateCode(), new AutoDataProviders()).getAgentOfRecords(), businessApplicant.getZipCode());
					break;
				case HOME_APPLICANT:
					ApplicantHome homeApplicant = (ApplicantHome) object;
					awsURL = String.format(Property.getUri() + AWS_FORMATTING_STRING, "H", homeApplicant.getStateCode(), homeApplicant.getSameStateZipCode(), homeApplicant.getZipCode());
					break;
				case HQM_APPLICANT:
					ApplicantHQM hqmApplicant = (ApplicantHQM) object;
					awsURL = Property.getUri() + AWS_ZIP + hqmApplicant.getZipCode() + AWS_STATE + hqmApplicant.getStateCode() + AWS_AGENTCODE + hqmApplicant.getAgentId();
					break;
				case LIFE_APPLICANT:
					ApplicantLife lifeApplicant = (ApplicantLife) object;
					awsURL = String.format(Property.getUri() + AWS_FORMATTING_STRING, "L", lifeApplicant.getStateCode(), getAgentData(lifeApplicant.getStateCode(), new AutoDataProviders()).getAgentOfRecords(), lifeApplicant.getZipCode());
					break;
				default:
					throw new IllegalArgumentException("Invalid object specified: " + object.getClass().getSimpleName());
			}
		}
		intializeLandingPage(awsURL, isUseMobileViewEnabled(), false);
	}

	private void intializeLandingPage(String url, boolean useMobile, boolean useFarmersDotCom) throws Exception {
		setWindowDimensions(useMobile);
		openLandingPage(url, useFarmersDotCom);
	}

	private void setWindowDimensions(boolean useMobile) throws Exception {
		if (useMobile) {
			setViewportSize(PlaywrightArtifacts.MOBILE.width(), PlaywrightArtifacts.MOBILE.height());
		} else if ("true".equals(Property.getTestProperty("headless"))) {
			// Headless needs explicit dimensions to avoid defaulting to mobile version of the site
			setViewportSize(1920, 1080);
		} else {
			maximizeWindow();
		}
	}

	private void openLandingPage(String url, boolean useFarmersDotCom) throws Exception {
		if (!isSafariBrowser()) {
			clearCookies();
		}

		// This extracted project is intentionally limited to the Home and Auto FFQ
		// applications. Even legacy callers that requested Farmers.com must start
		// from the environment-specific FastQuote entry point.
		if (useFarmersDotCom) {
			Log.warn("Farmers.com landing was requested; routing to the configured FastQuote entry point instead.");
			url = Property.getUri();
		}

		url = Property.ensureFastQuoteEntry(url);
		addAuthCookieIfConfigured();
		Log.info("Navigating to: " + url + " | environment=" + Property.ENVIRONMENT);
		navigate(url);
		assertNotRedirectedToCssTv();
		acceptCookies();
	}

	private AgentFlowData getAgentData(String stateCode, AutoDataProviders autoDataProviders) throws Exception {
		List<AgentFlowData> listOfAgentFlowData = autoDataProviders.listOfAgentFlowData();
		List<AgentFlowData> agentDataList = listOfAgentFlowData.stream().filter(data -> data.getStateCode().equals(stateCode)).collect(Collectors.toList());
		if (agentDataList.isEmpty()) {
			throw new SkipException("Skipping this test as there is no data for " + stateCode + " in the 'agentFlow' data sheet");
		}
		AgentFlowData agentFlowData = agentDataList.get(0);
		return agentFlowData;
	}

	public void clickGetNewQuoteTab() {
		scrollToElement(waitElementBeVisible(landingPageDisclaimer));
		if (isElementPresent(pwXPath(XPATH_TO_RETRIEVE_BUTTON), 2)) {
			waitAndClickElement(getNewQuoteTab);
		}
	}

	public void clickRetrieveSavedQuoteTab() {
		waitAndClickElement(retrieveSavedQuoteTab);
	}

	private void clickRetrieveQuoteButton() {
		waitAndClickElement(retrieveQuoteButton);
	}

	private void clickRetrieveQuoteButtonAndContinue() {
		clickRetrieveQuoteButton();
		waitForSpinnerToBeGone();
		waitForLegacySpinnerToBeGone();
		if (!isElementPresentByID(unableToLocateQuoteDialog)) {
			longWaitForElementToBeGoneByXpath(XPATH_TO_RETRIEVE_BUTTON);
		}
	}

	public void validateUnableToRetrieveContent(FarmersSoftAssert softAssert, String expectedContent) {
		softAssert.assertTrue(isQuoteNotFoundPopUpPresent(), "Unable to locate quote dialog displayed");
		softAssert.assertTrue(isExpectedTextContainedInElement(infoDialogContent, expectedContent), expectedContent + " found in dialog");
	}

	public void selectLOB(String lob) {
		switch (lob) {
			case LOB_AUTO:
				waitAndClickElement(autoLOBButton);
				break;
			case LOB_BUSINESS:
				waitAndClickElement(businessLOBButton);
				break;
			case LOB_CONDO:
				waitAndClickElement(condoLOBButton);
				break;
			case LOB_HOME:
				waitAndClickElement(homeLOBButton);
				break;
			case LOB_LIFE:
				waitAndClickElement(lifeLOBButton);
				break;
			case LOB_MOBILE_HOME:
				waitAndClickElement(mobileHomeLOBButton);
				break;
			case LOB_RENTERS:
				waitAndClickElement(rentersLOBButton);
				break;
			case AUTO_HOME_BUNDLE:
				waitAndClickElement(autoHomeBundleButton);
				break;
			case AUTO_RENTERS_BUNDLE:
				waitAndClickElement(autoRentersBundleButton);
				break;
			case AUTO_CONDO_BUNDLE:
				waitAndClickElement(autoCondoBundleButton);
				break;
			default:
				throw new IllegalArgumentException(lob + LINE_OF_BUSINESS_DOESNT_EXIST);
		}
		scrollToTopOfPage();
	}

	public boolean isLOBButtonAvailable(String lob) throws Exception {
		boolean usingDefaultLandingPage = isElementPresent(pwXPath(XPATH_TO_ZIP_CODE_FIELD), 2);
		Locator buttonToCheck;
		if (!usingDefaultLandingPage) {
            return isElementDisplayed(pwXPath(String.format(LOB_BUTTON_XPATH, lob)));
		} else {
			switch (lob) {
				case LOB_AUTO:
					buttonToCheck = autoLOBButton;
					break;
				case LOB_BUSINESS:
					buttonToCheck = businessLOBButton;
					break;
				case LOB_CONDO:
					buttonToCheck = condoLOBButton;
					break;
				case LOB_HOME:
					buttonToCheck = homeLOBButton;
					break;
				case LOB_LIFE:
					buttonToCheck = lifeLOBButton;
					break;
				case LOB_MOBILE_HOME:
					buttonToCheck = mobileHomeLOBButton;
					break;
				case LOB_RENTERS:
					buttonToCheck = rentersLOBButton;
					break;
				case AUTO_HOME_BUNDLE:
					buttonToCheck = autoHomeBundleButton;
					break;
				case AUTO_RENTERS_BUNDLE:
					buttonToCheck = autoRentersBundleButton;
					break;
				case AUTO_CONDO_BUNDLE:
					buttonToCheck = autoCondoBundleButton;
					break;
				default:
					throw new IllegalArgumentException(lob + LINE_OF_BUSINESS_DOESNT_EXIST);
			}
		}
		return (isElementDisplayed(buttonToCheck, 3));
	}

	public void enterZip(String zip) {
		sendKeysToElement(zipCodeField, zip);
		Log.info("Zip code entered: " + zip);
	}

	public void clickSubmit() {
		scrollAndClickOnElement(submitButton);
		if (isSafariBrowser()) {
			waitForUiSettled();
		}
	}

	public void enterLandingPageDataAndContinue(String lob, String zip) throws Exception {
		enterLandingPageData(lob, zip);
		waitForSpinnerToBeGone();
		waitForLegacySpinnerToBeGone();
		waitForPageToBeDismissed();
	}

	private void waitForPageToBeDismissed() {
		if (!isElementVisible(infoDialogCloseButton, 3)) {
			if (isElementPresent(pwXPath(XPATH_TO_SUBMIT_BUTTON), 3)) {
				clickSubmit();
				longWaitForElementToBeGoneByXpath(XPATH_TO_SUBMIT_BUTTON);
			}
		}
	}

	public void enterLandingPageDataAndRemainInPage(String lob, String zip) throws Exception {
		enterLandingPageData(lob, zip);
	}

	public void enterLandingPageData(String lob, String zip) throws Exception {
		boolean usingDefaultLandingPage = isElementPresent(pwXPath(XPATH_TO_ZIP_CODE_FIELD), 2);
		if (usingDefaultLandingPage) {
			enterZip(zip);
			selectLOB(lob);
			clickSubmit();
		} else {
			enterZipOnFarmersDotCom(zip);
			selectFarmersDotComLOB(lob);
			clickGetMyQuoteButton();
		}
	}

	public void landingPageValidation(FarmersSoftAssert fsa) throws Exception {
		verifyStaticFooterText(fsa);
		verifyLOBButtons(fsa);
		checkAllURLsAndImages(findAllURLsAndImages());
	}

	private void verifyLOBButtons(FarmersSoftAssert fsa) {
		Log.info("Verifying LOB selection buttons");
		fsa.assertTrue(autoLOBButton.isVisible(), "Automobile insurance button displayed");
		fsa.assertTrue(homeLOBButton.isVisible(), "Home insurance button displayed");
		fsa.assertTrue(mobileHomeLOBButton.isVisible(), "Mobile Home insurance button displayed");
		fsa.assertTrue(businessLOBButton.isVisible(), "Business insurance button displayed");
		fsa.assertTrue(rentersLOBButton.isVisible(), "Renters insurance button displayed");
		fsa.assertTrue(lifeLOBButton.isVisible(), "Life insurance button displayed");
		fsa.assertTrue(autoHomeBundleButton.isVisible(), "Auto & Home insurance button displayed");
		fsa.assertTrue(autoRentersBundleButton.isVisible(), "Auto & Renters insurance button displayed");
	}

	private void verifyStaticFooterText(FarmersSoftAssert fsa) {
		String disclaimerText = getTextFromElement(landingPageDisclaimer);
		Log.info("Verifying Footer static text " + disclaimerText);
		fsa.assertEquals(disclaimerText, "A preliminary rate (\"quote\") is for insurance coverage you select. Certain assumptions may have been made that will influence the quote you receive. " +
				"A quote is not an offer for insurance, an offer of an insurance contract, nor is it an insurance contract, binder or an application to purchase insurance. The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract. " +
				"Rates quoted reflect the rates in effect as of the date of this quote and are subject to revision. Your actual premium may vary based upon additional information you provide or we obtain, the coverages and deductibles that you select, any additional underwriting criteria, " +
				"and removal of any assumptions. Farmers reserves the right to accept, reject, or modify this quote after review of the application and other underwriting information. All applications are subject to underwriting approval. " +
				"Farmers online quotes are for new customers only. Existing customers are requested to contact their local agent to make changes to their policy. Quoted rates do not include fees permitted by state law.", "Footer static text verification");
	}

	private void verifyErrorMessagesRedAndVisibleForGetAQuoteElements(FarmersSoftAssert fsa) {
		fsa.assertEquals(getTextFromElement(selectProductErrorMessage), PRODUCT_REQUIRED, "selectProductErrorMessage verification");
		fsa.assertTrue(checkErrorColorForElement(selectProductErrorMessage), PRODUCT_REQUIRED + COLOR_ERROR_MSG);
		fsa.assertEquals(getTextFromElement(zipCodeEntryErrorMessage), ENTER_ZIP_CODE, "No zip code entered verification");
		fsa.assertTrue(checkErrorColorForElement(zipCodeEntryErrorMessage), ENTER_ZIP_CODE + COLOR_ERROR_MSG);
		enterZip("799");
		clickSubmit();
		fsa.assertEquals(getTextFromElement(zipCodeEntryErrorMessage), ENTER_5DIGIT_ZIP_CODE, "Partial zip code entered verification");
		fsa.assertTrue(checkErrorColorForElement(zipCodeEntryErrorMessage), ENTER_5DIGIT_ZIP_CODE + COLOR_ERROR_MSG);
	}

	private void verifyErrorMessagesRedAndVisibleForRetrieveQuoteElements(FarmersSoftAssert fsa) {
		waitElementBeVisible(zipCodeInRetrieveErrorMessage);
		fsa.assertEquals(getTextFromElement(lastNameErrorMessage), LAST_NAME_REQUIRED, "Retrieve Quote lastNameErrorMessage verification");
		fsa.assertTrue(checkErrorColorForElement(lastNameErrorMessage), "Last Name" + COLOR_ERROR_MSG);
		fsa.assertEquals(getTextFromElement(dateOfBirthErrorMessage), DOB_REQUIRED, "Retrieve Quote dateOfBirthErrorMessage verification");
		fsa.assertTrue(checkErrorColorForElement(dateOfBirthErrorMessage), "Date of Birth" + COLOR_ERROR_MSG);
		fsa.assertEquals(getTextFromElement(emailQuoteNumberErrorMessage), QUOTE_OR_EMAIL_REQUIRED, "Retrieve Quote emailQuoteNumberErrorMessage verification");
		fsa.assertTrue(checkErrorColorForElement(emailQuoteNumberErrorMessage), "Quote/Email" + COLOR_ERROR_MSG);
		fsa.assertEquals(getTextFromElement(zipCodeInRetrieveErrorMessage), ENTER_ZIP_CODE, "Retrieve Quote zipCodeInRetrieveErrorMessage verification");
		fsa.assertTrue(checkErrorColorForElement(zipCodeInRetrieveErrorMessage), ZIP_CODE_MSG + COLOR_ERROR_MSG);
	}

	private boolean checkErrorColorForElement(Locator element) {
		String elementColor = (String) element.evaluate("(e,p)=>getComputedStyle(e).getPropertyValue(p)", COLOR);
		boolean result = Arrays.asList(RED_RGB, RED_RGBA, DARK_RED_RGBA, DARK_RED_RGB, RED_RGB_AUTO_REDESIGN, RED_RGBA_AUTO_REDESIGN).contains(elementColor);
		if (!result) {
			Log.warn(elementColor + "not in expected list of colors");
		}
		return result;
	}

	public boolean isNotOfferedInStateErrorMessageRedAndVisible(String state) {
		return checkZIPErrorMessage(NO_POLICIES_OFFERED + state + CLICK_TO_RETURN);
	}

	public boolean cantBeCompletedOnlineErrorMessageRedAndVisible() {
		return checkZIPErrorMessage(CANT_COMPLETE_QUOTE_ONILNE);
	}

	public boolean bundleIsNotOfferedErrorMessageRedAndVisible() {
		return checkZIPErrorMessage(NO_BUNDLE_POLICIES_OFFERED);
	}

	public boolean isNoOnlineQuotingErrorMessageRedAndVisible() {
		return checkZIPErrorMessage(ONLINE_QUOTING_UNAVAILABLE);
	}

	public boolean invalidZipCodeErrorMessageRedAndVisible() {
		return checkZIPErrorMessage("Please enter a valid Zip Code.");
	}

	private boolean checkZIPErrorMessage(String errorMessage) {
		waitElementBeVisible(zipCodeErrorMessage);
		String zipErrorMessage = getTextFromElement(zipCodeErrorMessage);
		boolean result = checkErrorColorForElement(zipCodeErrorMessage) && zipErrorMessage.contains(errorMessage);
		if (!zipErrorMessage.contains(errorMessage)) {
			Log.warn(ERROR_FOUND_MSG + "<" + zipErrorMessage + "> EXPECTED <" + errorMessage + ">");
		}
		return result;
	}

	public void landingPageErrorValidation(FarmersSoftAssert fsa) {
		clickSubmit();
		verifyErrorMessagesRedAndVisibleForGetAQuoteElements(fsa);
		clickRetrieveSavedQuoteTab();
		clickRetrieveQuoteButton();
		verifyErrorMessagesRedAndVisibleForRetrieveQuoteElements(fsa);
		clickGetNewQuoteTab();
	}

	private void enterDateOfBirth(int age) {
		Log.info("Entering Date of Birth calculated from age: " +  age);
		enterDateOfBirth(calculateDateOfBirthFromAge(age));
	}

	public void enterDateOfBirth(String dob) {
		Log.info("Entering Date of Birth: " + dob);
		sendKeysToElement(dateOfBirthField, dob);
	}

	private void enterZipCodeRetrieve(String zip) {
		sendKeysToElement(zipCodeForRetrieveField, zip);
	}

	private void enterQuoteNumber(String quote) {
		sendKeysToElement(quoteNumberField, quote);
	}

	private void enterLastName(String lastName) {
		sendKeysToElement(lastNameField, lastName);
	}

	public <T extends BasePage> T enterRetrieveQuote(Object object, String quoteNumber) throws Exception {
		clickRetrieveSavedQuoteTab();
		waitForRetreiveQuotePageLoad();
		synchronized (this) {
			switch (object.getClass().getSimpleName()) {
				case AUTO_APPLICANT:
					return enterRetrieveSavedQuoteForAuto((SqlApplicant) object);
				case HOME_APPLICANT:
					return enterRetrieveSavedQuoteForHome((ApplicantHome) object);
				case LIFE_APPLICANT:
					return enterRetrieveSavedQuoteForLife((ApplicantLife) object, quoteNumber);
				default:
					throw new IllegalArgumentException("Invalid object specified: " + object.getClass().getSimpleName());
			}
		}
	}

	public void retrieveQuoteFromLandingPage(AutoApplicant applicant, String emailOrQuoteNumber) {
		Log.info("Retrieving quote data: Zipcode: " + applicant.getZipCode() + ", Last name: " + applicant.getLastName() + ". Birth date: " + applicant.getDateOfBirth() + ", Email or Quote Number: " + emailOrQuoteNumber);
		enterQuoteInformationAndRetrieve(applicant.getLastName(), applicant.getDateOfBirth(), emailOrQuoteNumber, applicant.getZipCode());
		waitForSpinnerToBeGone();
	}

	public void retrieveQuoteFromLandingPage(ADPFApplicant adfpApplicant, String emailOrQuoteNumber) {
		Log.info("Retrieval data: Zipcode: " + adfpApplicant.getZipCode() + ", Last name: " + adfpApplicant.getLastName() + ". Birth date: " + adfpApplicant.getDateOfBirth() + ", Email or Quote Number: " + emailOrQuoteNumber);
		enterQuoteInformationAndRetrieve(adfpApplicant.getLastName(), adfpApplicant.getDateOfBirth(), emailOrQuoteNumber, adfpApplicant.getZipCode());
		waitForSpinnerToBeGone();
	}

	public void retrieveQuoteFromLandingPage(String lastName, String dateOfBirth, String emailOrQuoteNumber, String zipCode) {
		Log.info("Retrieval data: Zipcode: " + zipCode + ", Last name: " + lastName + ". Birth date: " + dateOfBirth + ", Email or Quote Number: " + emailOrQuoteNumber);
		enterQuoteInformationAndRetrieve(lastName, dateOfBirth, emailOrQuoteNumber, zipCode);
		waitForSpinnerToBeGone();
	}

	private void enterQuoteInformationAndRetrieve(String lastName, String dateOfBirth, String emailOrQuoteNumber, String zipcode ) {
		boolean usingDefaultLandingPage = isElementPresent(pwXPath(XPATH_TO_ZIP_CODE_FIELD), 2);
		if (usingDefaultLandingPage) {
			if (isElementVisible(retrieveSavedQuoteTab,3)) {
				waitAndClickElement(retrieveSavedQuoteTab);
			}
		} else {
			scrollAndClickOnElement(retrieveSavedQuoteLink);
		}
		waitForRetreiveQuotePageLoad();
		sendKeysToElement(lastNameField, lastName);
		sendKeysToElement(dateOfBirthField, dateOfBirth);
		sendKeysToElement(quoteNumberField, emailOrQuoteNumber);
		sendKeysToElement(zipCodeForRetrieveField, zipcode);
		clickElement(retrieveQuoteButton);
	}

	public void retrieveQuoteWithLink(AutoApplicant applicant, String quoteNumber) throws Exception {
		navigate(String.format(Property.getUri() + "/?retrieve=true&quoteNumber=%s", quoteNumber));
		waitForRetreiveQuotePageLoad();
		waitElementBeVisible(lastNameField).fill("");
		sendKeys(waitElementBeVisible(lastNameField), applicant.getLastName());
		waitElementBeVisible(dateOfBirthField).fill("");
		sendKeys(waitElementBeVisible(dateOfBirthField), applicant.getDateOfBirth());
		waitElementBeVisible(quoteNumberField).fill("");
		sendKeys(waitElementBeVisible(quoteNumberField), quoteNumber);
		waitElementBeVisible(zipCodeForRetrieveField).fill("");
		sendKeys(waitElementBeVisible(zipCodeForRetrieveField), applicant.getZipCode());
		waitAndClickElement(retrieveQuoteButton);
		waitForSpinnerToBeGone();
	}

	@SuppressWarnings(UNCHECKED)
	private <T extends BasePage> T enterRetrieveSavedQuoteForAuto(SqlApplicant applicant) throws Exception {
		String quoteKey = applicant.getLastName() + applicant.getZipCode();
		if (returningQuoteConcurrentHashMap.containsKey(quoteKey)) {
			ApplicantRetQuote applicantRetQuote = returningQuoteConcurrentHashMap.get(quoteKey);
			enterLastName(applicantRetQuote.getLastName());
			if (applicant.getDateOfBirth() != null) {
				enterDateOfBirth(applicant.getDateOfBirth());
			} else {
				enterDateOfBirth(applicantRetQuote.getAge());
			}
			enterQuoteNumber(applicantRetQuote.getQuoteNumber());
			enterZipCodeRetrieve(applicantRetQuote.getZipCode());
			applicant.setApplicantRetQuote(applicantRetQuote);
			returningQuoteConcurrentHashMap.remove(quoteKey, applicantRetQuote);
			clickRetrieveQuoteButtonAndContinue();
			switch (applicantRetQuote.getPageLeftOn()) {
				case VEHICLES_PAGE_AUTO:
					return (T) new VehiclesPage();
				case DRIVERS_PAGE_AUTO:
					return (T) new DriversPage();
				case DISCOUNTS_PAGE_AUTO:
					return (T) new DiscountsPage();
				case QUOTE_PAGE_AUTO :
					return (T) new QuotePageAuto();
				default:
					throw new IllegalArgumentException(applicantRetQuote.getPageLeftOn() + PAGE_DOESNT_EXIST);
			}
		} else {
			throw new IllegalArgumentException(RETRIEVE_QUOTE_HASHMAP_MISING_KEY + quoteKey);
		}
	}

	@SuppressWarnings(UNCHECKED)
	private <T extends BasePage> T enterRetrieveSavedQuoteForHome(ApplicantHome applicantHome) throws Exception {
		String quoteKey = applicantHome.getLastName() + applicantHome.getZipCode();
		if (returningQuoteConcurrentHashMap.containsKey(quoteKey)) {
			ApplicantRetQuote applicantRetQuote = returningQuoteConcurrentHashMap.get(quoteKey);
			enterLastName(applicantRetQuote.getLastName());
			enterDateOfBirth(applicantRetQuote.getAge());
			enterQuoteNumber(applicantRetQuote.getQuoteNumber());
			enterZipCodeRetrieve(applicantRetQuote.getZipCode());
			applicantHome.setApplicantRetQuote(applicantRetQuote);
			returningQuoteConcurrentHashMap.remove(quoteKey, applicantRetQuote);
			clickRetrieveQuoteButtonAndContinue();
			if (applicantHome.getState().equals(WISCONSIN)) {
				return (T) new PropertyPage();
			} else {
				switch (applicantRetQuote.getPageLeftOn()) {
					case YOUR_INFO_PAGE_HOME:
						return (T) new YourInfoPageHome();
					case PROPERTY_PAGE_HOME:
						return (T) new PropertyPage();
					case CHOOSE_YOUR_COVERAGE_PAGE:
						return (T) new ChooseYourCoveragePage();
					case QUOTE_PAGE_HOME:
						return (T) new QuotePageHome(applicantHome);
					default:
						throw new IllegalArgumentException(applicantRetQuote.getPageLeftOn() + PAGE_DOESNT_EXIST);
				}
			}
		} else {
			throw new IllegalArgumentException(RETRIEVE_QUOTE_HASHMAP_MISING_KEY + quoteKey);
		}
	}

	public void enterRetrieveSavedQuoteForHQM(ApplicantHQM applicant, String quoteNumber) {
		enterLastName(applicant.lastName);
		enterDateOfBirth(applicant.dateOfBirth);
		enterQuoteNumber(quoteNumber);
		enterZipCodeRetrieve(applicant.zipCode);
		clickRetrieveQuoteButton();
	}

	@SuppressWarnings(UNCHECKED)
	private <T extends BasePage> T enterRetrieveSavedQuoteForLife(ApplicantLife applicant, String quoteNumber) throws Exception {
		String quoteKey = applicant.getLastName() + applicant.getZipCode() + quoteNumber;
		if (returningQuoteConcurrentHashMap.containsKey(quoteKey)) {
			ApplicantRetQuote applicantRetQuote = returningQuoteConcurrentHashMap.get(quoteKey);
			enterLastName(applicantRetQuote.getLastName());
			enterDateOfBirth(applicantRetQuote.getAge());
			enterQuoteNumber(applicantRetQuote.getQuoteNumber());
			enterZipCodeRetrieve(applicantRetQuote.getZipCode());
			applicant.setApplicantRetQuote(applicantRetQuote);
			clickRetrieveQuoteButtonAndContinue();
			if (isElementPresentByID(unableToLocateQuoteDialog)) {
				returningQuoteConcurrentHashMap.remove(quoteKey, applicantRetQuote);
				return (T) this;
			}
			// sometimes we get back to the landing page, so try it again
			if (isElementPresentByXPath(XPATH_TO_SUBMIT_BUTTON)) {
				Log.warn("Back on Landing page, trying to retrieve one more time");
				clickRetrieveSavedQuoteTab();
				enterLastName(applicantRetQuote.getLastName());
				enterDateOfBirth(applicantRetQuote.getAge());
				enterQuoteNumber(applicantRetQuote.getQuoteNumber());
				enterZipCodeRetrieve(applicantRetQuote.getZipCode());
				clickRetrieveQuoteButtonAndContinue();
			}
			if (isElementPresentByXPath(XPATH_TO_SUBMIT_BUTTON)) {
				Assert.fail("Retrieve quote keeps returning to Landing page");
			}
			returningQuoteConcurrentHashMap.remove(quoteKey, applicantRetQuote);
			switch (applicantRetQuote.getPageLeftOn()) {
				case ACE_LIFE_NAME_DOB_PAGE:
					return (T) new AceLifeNameAndDOBPage();
				case ACE_LIFE_PERSONAL_INFO_PAGE:
					return (T) new AceLifePersonalInfoPage();
				case ACE_LIFE_REVIEW_QUOTE_PAGE:
					return (T) new AceLifeReviewQuotePage();
				default:
					throw new IllegalArgumentException(applicantRetQuote.getPageLeftOn()+ PAGE_DOESNT_EXIST);
			}
		} else {
			throw new IllegalArgumentException(RETRIEVE_QUOTE_HASHMAP_MISING_KEY + quoteKey);
		}
	}

	public boolean isQuoteRetrievalErrorMessage() {
		boolean bErrorMessage = true;
		try {
			waitElementBeVisible(quoteRetrievalErrorMessage);
			clickElement(buttonCloseErrorDialog);
		} catch (TimeoutError e) {
			bErrorMessage = false;
		}
		return bErrorMessage;
	}

	private void waitForRetreiveQuotePageLoad() {
		waitElementBeVisible(lastNameField);
		waitElementBeVisible(dateOfBirthField);
		waitElementBeVisible(quoteNumberField);
		waitElementBeVisible(zipCodeForRetrieveField);
		waitElementBeVisibleClickable(retrieveQuoteButton);
	}

	private static void addAuthCookieIfConfigured() {
		String configuredCookie = Property.getSyntheticAgentCookie();
		if (configuredCookie.isBlank()) {
			Log.info("No synthetic_agent cookie configured; continuing with direct FastQuote navigation.");
			return;
		}

		Cookie cookie = new Cookie("synthetic_agent", resolveSyntheticAgentCookieValue(configuredCookie))
				.setDomain(".farmers.com")
				.setPath("/");
		addCookie(cookie);
	}

	private static String resolveSyntheticAgentCookieValue(String configuredCookie) {
		String cookieDefinition = configuredCookie.trim().split(";", 2)[0].trim();
		int separatorIndex = cookieDefinition.indexOf('=');
		if (separatorIndex <= 0) {
			return cookieDefinition;
		}

		String cookieName = cookieDefinition.substring(0, separatorIndex).trim();
		if (!"synthetic_agent".equalsIgnoreCase(cookieName)) {
			return cookieDefinition;
		}

		return cookieDefinition.substring(separatorIndex + 1).trim();
	}

	private static void assertNotRedirectedToCssTv() {
		String currentUrl = page().url();
		if (Property.isCssTvUrl(currentUrl)) {
			throw new IllegalStateException("FastQuote navigation was redirected to CSSTV: " + currentUrl
					+ ". Expected environment entry point: " + Property.getUri());
		}
	}

	public String getInfoDialogContent() {
		return getTextFromElement(waitElementBeVisible(infoDialogContent));
	}

	public boolean isQuoteNotFoundPopUpPresent() {
		return isElementVisible(unableToLocateQuoteDialog,3);
	}

	// farmers.com members and methods
	private static final String LOB_BUTTON_XPATH = "//div//button[@aria-label='%s']";
	private static final String FARMERS_DOT_COM_LOB_CONTAINER_XPATH = "//*[@id='policy-buttons' and @role='listbox']";
	private static final String FARMERS_DOT_COM_LOB_OPTIONS_XPATH = "//*[@id='policy-buttons' and @role='listbox']//button[@role='option' and contains(@class,'policy-btn')]";
		private Locator buttonAuto = locator(pwXPath("//div//button[@data-id='Auto']"));

		private Locator buttonHome = locator(pwXPath("//div//button[@data-id='Home']"));

		private Locator buttonRenters = locator(pwXPath("//div//button[@data-id='Renter']"));

		private Locator zipCodeInput = locator(pwXPath("//form//input[@name='Zip_Code']"));

		private Locator buttonGetMyQuoteMobile = locator(pwXPath("//form//button[contains(@class,'button-cta--mobile') and contains(.,'Get my quote')]"));

		private Locator buttonGetMyQuoteDesktop = locator(pwXPath("//form//button[contains(@class,'button-cta--desktop') and contains(.,'Get my quote')]"));

		private Locator retrieveSavedQuoteLink = locator(pwXPath("//a[@data-gtm='Farmers_GroupLandingPage_ProductGrid_MobileTextDataLink_Body']"));

	public void selectFarmersDotComLOB(String lob) throws Exception {
		Locator lobContainer = locator(pwXPath(FARMERS_DOT_COM_LOB_CONTAINER_XPATH));
		waitElementBeVisible(lobContainer, 5);

		for (String requiredOption : farmersDotComOptionsFor(lob)) {
			selectVisibleFarmersDotComOption(requiredOption, lob);
		}
	}

	private List<String> farmersDotComOptionsFor(String lob) {
		return switch (lob) {
			case AUTO_HOME_BUNDLE, AUTO_CONDO_BUNDLE -> List.of("Auto", "Home");
			case AUTO_RENTERS_BUNDLE -> List.of("Auto", "Renters");
			default -> List.of(lob);
		};
	}

	private void selectVisibleFarmersDotComOption(String requiredOption, String requestedLob) {
		Locator lobOptions = locator(pwXPath(FARMERS_DOT_COM_LOB_OPTIONS_XPATH));
		String expectedOption = normalizeFarmersDotComLobName(requiredOption);
		List<String> availableOptions = new ArrayList<>();

		int optionCount = lobOptions.count();
		for (int index = 0; index < optionCount; index++) {
			Locator option = lobOptions.nth(index);
			if (!option.isVisible()) {
				continue;
			}

			String visibleName = normalizedVisibleLobName(option);
			if (!visibleName.isBlank()) {
				availableOptions.add(visibleName);
			}

			if (matchesFarmersDotComLob(option, expectedOption)) {
				option.scrollIntoViewIfNeeded();
				option.click();
				return;
			}
		}

		Log.warn("Available Farmers.com lines of business: " + availableOptions);
		throw new IllegalArgumentException(
				"Unable to select " + requestedLob + ". Missing required option: " + requiredOption
						+ ". Available options: " + availableOptions);
	}

	private boolean matchesFarmersDotComLob(Locator option, String expectedOption) {
		String ariaLabel = option.getAttribute("aria-label");
		if (expectedOption.equals(normalizeFarmersDotComLobName(ariaLabel))) {
			return true;
		}

		if (expectedOption.equals(normalizeFarmersDotComLobName(normalizedVisibleLobName(option)))) {
			return true;
		}

		String dataId = option.getAttribute("data-id");
		return expectedOption.equals(normalizeFarmersDotComLobName(dataId));
	}

	private String normalizedVisibleLobName(Locator option) {
		String ariaLabel = normalizeVisibleLobName(option.getAttribute("aria-label"));
		if (!ariaLabel.isBlank() && !isMaterialIconToken(ariaLabel)) {
			return ariaLabel;
		}

		String visibleText = normalizeVisibleLobName(option.innerText());
		if (!visibleText.isBlank()) {
			return visibleText;
		}

		return normalizeVisibleLobName(option.getAttribute("data-id"));
	}

	private String normalizeVisibleLobName(String value) {
		if (value == null) {
			return "";
		}

		String normalized = value.replaceAll("\\s+", " ").trim();
		for (String iconToken : List.of(
				"add_circle_outline", "add_circle", "expand_more",
				"keyboard_arrow_down", "check_circle", "chevron_right")) {
			normalized = normalized.replaceAll("(?i)(^|\\s)" + iconToken + "(?=\\s|$)", " ");
		}
		return normalized.replaceAll("\\s+", " ").trim();
	}

	private boolean isMaterialIconToken(String value) {
		String normalized = value.toLowerCase(Locale.ROOT).trim();
		return List.of("add_circle_outline", "add_circle", "expand_more",
				"keyboard_arrow_down", "check_circle", "chevron_right").contains(normalized);
	}

	private String normalizeFarmersDotComLobName(String value) {
		return normalizeVisibleLobName(value)
				.replaceAll("([a-z])([A-Z])", "$1 $2")
				.toLowerCase(Locale.ROOT)
				.replace("&", " and ")
				.replace("+", " and ")
				.replaceAll("\\binsurance\\b", " ")
				.replaceAll("[^a-z0-9]+", " ")
				.replaceAll("\\band\\b", " ")
				.replaceAll("\\s+", " ")
				.trim();
	}

	public void enterZipOnFarmersDotCom(String zipCode) {
		scrollToElement(zipCodeInput);
		sendKeysToElement(zipCodeInput, zipCode);
		Log.info("Zip code entered: " + zipCode);
	}

	public void clickGetMyQuoteButton() {
		if (isUseMobileViewEnabled()) {
			scrollAndClickOnElement(buttonGetMyQuoteMobile);
		} else {
			scrollAndClickOnElement(buttonGetMyQuoteDesktop);
		}
	}

}
