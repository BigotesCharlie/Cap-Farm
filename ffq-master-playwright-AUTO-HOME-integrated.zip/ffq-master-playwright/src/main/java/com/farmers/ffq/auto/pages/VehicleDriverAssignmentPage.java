package com.farmers.ffq.auto.pages;






import com.farmers.framework.playwright.Keys;
import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;

import lombok.Getter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static com.farmers.ffq.utils.GlobalVariables.*;

@Getter
public class VehicleDriverAssignmentPage extends AutoBasePage {

    private static final String VEHICLE_DRIVER_ASSIGNMENT_PAGE_XPATH = "//div[contains(@class,'vehicle-driver-assignment-container')]";
    private static final String VEHICLE_SECTION_XPATH = "//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-details')]";
    Random randomNumberGenerator = new Random();

        private Locator vehicleDriverAssignmentPageTitle = locator(pwXPath("//app-vehicle-driver-assignment//h1"));
        private Locator vehicleDriverAssignmentPageSubTitle = locator(pwXPath(VEHICLE_DRIVER_ASSIGNMENT_PAGE_XPATH + "//p"));
        private Locator vehicleList = locator(pwXPath(VEHICLE_SECTION_XPATH));

        private Locator listOfErrorLabels = locator(pwXPath("//mat-error"));
        private Locator requiredFieldDataMissingLabel = locator(pwXPath("//*[contains(@class, 'vehicles-driver-assignment-fields-missing')]"));

        private Locator saveButton = locator(pwXPath("//div[@class='continue-button']//button"));
        private Locator resetButton = locator(pwXPath("//div[@class='continue-button']//span"));
        private Locator vehicleMatSelections = locator(pwXPath("//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-details row')]//mat-select[@aria-invalid]"));
        private Locator availableDriverMatOptions = locator(pwXPath("//mat-option[@aria-disabled='false']"));

    private static final String SELECT_A_DRIVER_DROPDOWN_FOR_VEHICLE_XPATH = "//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-details') and contains(.,'%s') and contains(.,'%s')]//mat-select";
    private static final String SELECT_A_VEHICLE_DROPDOWN_FOR_DRIVER_XPATH = "//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-details') and contains(.,'%s')]//mat-select";
//    private static final String DRIVER_SECTION_XPATH = "//div[contains(@class,'auto-vehicles-drivers-review__vehicles-list-details')]/p[%d]";

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public VehicleDriverAssignmentPage() throws Exception {
    }

    public boolean isOnVehicleDriverAssignmentPage() {
        return isElementVisible(vehicleDriverAssignmentPageTitle, 10);
    }

    public boolean quickIsOnVehicleDriverAssignmentPage() {
        return isElementVisible(vehicleDriverAssignmentPageTitle, 3);
    }

    public void assignDriversForVehiclesRandomlyAndSave() throws Exception {

    	int numberOfElements = vehicleMatSelections.count();
        for (int i = 0; i< numberOfElements; i++){
    		waitAndClickElement(vehicleMatSelections.nth(i));
    		waitForUiSettled();
    		if (!getAttributeData(vehicleMatSelections.nth(i), "aria-expanded").equals(LOWERCASE_TRUE)) {
    			jsClickElement(vehicleMatSelections.nth(i));
    		}
    		if (i == 0) {
    			AppStore.Data.CustomerData customerData = getSessionStorageAppStore().getData().getCustomerData();
    			String fullNamePNI = customerData.getFirstName() + SPACE + customerData.getLastName();
    			List<Locator> firstSelection = locators(pwXPath(String.format("//mat-option[contains(.,\"%s\")]", fullNamePNI)));
    			if (!firstSelection.isEmpty()) {
    				waitAndClickElement(firstSelection.get(i));
    			} else {
    				List<Locator> availableMatOptions = locators(pwXPath("//mat-option[@aria-disabled='false']"));
        			if (!availableMatOptions.isEmpty()) {
        				waitAndClickElement(availableMatOptions.get(randomNumberGenerator.nextInt(availableMatOptions.size())));
        			}
    			}
    		} else {
    			List<Locator> availableMatOptions = locators(pwXPath("//mat-option[@aria-disabled='false']"));
    			if (!availableMatOptions.isEmpty()) {
    				waitAndClickElement(availableMatOptions.get(randomNumberGenerator.nextInt(availableMatOptions.size())));
    			}
    		}
    	}
    	scrollToElement(saveButton);
    	waitAndClickElement(saveButton);
    	waitForSkeletonToBeGone();
    }

    public void assignDriversForVehiclesRandomlyAndSave(ADPFApplicant applicant) throws Exception {
        AppStore.Auto auto = getSessionStorageAppStore().getAuto();
        List<AppStore.Auto.AppStoreVehicle> vehicles = auto.getVehicles();
        ArrayList<AppStore.Auto.Driver> drivers = auto.getDrivers();
    	int numberOfElements = vehicleMatSelections.count();
        for (int i = 0; i< numberOfElements; i++){
            AppStore.Auto.AppStoreVehicle vehicle = vehicles.get(i);
            Locator selectDriverDropDown = locator(pwXPath(String.format(SELECT_A_DRIVER_DROPDOWN_FOR_VEHICLE_XPATH, vehicle.getYear(), vehicle.getMakeDesc())));
            waitAndClickElement(selectDriverDropDown);
            testStepAssert(getAttributeData(selectDriverDropDown, "aria-expanded").equals(LOWERCASE_TRUE), "Drop down for vehicle should be expanded");
            if(i == 0) {
                String applicantFullName = applicant.getFirstName() + SPACE + applicant.getLastName();
                Locator dropDownOption = locator(pwXPath(String.format("//mat-option[contains(.,'%s')]", applicantFullName)));
                waitAndClickElement(dropDownOption);
            } else {
                drivers.removeIf(driver -> driver.getFirstName().equals(applicant.getFirstName()) && driver.getLastName().equals(applicant.getLastName()));
                AppStore.Auto.Driver randomDriver = drivers.get(randomNumberGenerator.nextInt(drivers.size()));
                Locator dropDownOption = locator(pwXPath(String.format("//mat-option[contains(.,'%s')]", randomDriver.getFirstName() + SPACE + randomDriver.getLastName())));
                waitAndClickElement(dropDownOption);
            }
            waitAndClickElement(saveButton);
            waitForSpinnerToBeGone();
            waitForSkeletonToBeGone();
        }
        if (isElementDisplayed(saveButton, 2)) {
        	clickElement(saveButton);
        	waitForSpinnerToBeGone();
        	waitForSkeletonToBeGone();
        }
    }

    public boolean isPageTitleCorrect() {
        return (getTextFromElement(vehicleDriverAssignmentPageTitle).equals("Who drives what?"));
    }

    public boolean isPageSubtitleCorrect() {
        return (getTextFromElement(vehicleDriverAssignmentPageSubTitle).equals("Please assign drivers to the appropriate vehicle."));
    }

    public boolean areNoDriversSelectedErrorMessagesPresent() {
        clickResetButton();
        clickElement(saveButton);
        if(isADATestingEnabled()) {
            performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
            return true;
        }
        boolean driverDetailsErrorLabelsOK = listOfErrorLabels.count() == vehicleList.count();
        return checkErrorLabels(driverDetailsErrorLabelsOK);
    }

    public boolean someDriversSelectedErrorMessagesPresent(AutoApplicant applicant) throws Exception {
        selectARandomDriverForARandomVehicle(applicant);
        clickElement(saveButton);
        boolean driverDetailsErrorLabelsOK = listOfErrorLabels.count() == vehicleList.count() - 1;
        return checkErrorLabels(driverDetailsErrorLabelsOK);
    }

    public boolean isSelectedDriverListedForOtherVehicles(int vehicleSelected, boolean checkForDisabled) throws Exception {
        boolean driverIsFound = false;
        Locator driverDropdownForVehicleSelected = locator(pwXPath(VEHICLE_SECTION_XPATH + "[" + vehicleSelected + "]//mat-select"));
        String driverUsed = getTextFromElement(driverDropdownForVehicleSelected);
        List<Locator> listOfSelectADriverDropdowns = locators(pwXPath(VEHICLE_SECTION_XPATH + "//mat-select"));
    	int numberOfElements = listOfSelectADriverDropdowns.size();
        for (int dropdownNumber = 0; dropdownNumber< numberOfElements; dropdownNumber++){
            if (dropdownNumber != vehicleSelected - 1) {
                waitAndClickElement(listOfSelectADriverDropdowns.get(dropdownNumber));
                String matOptionClass = checkForDisabled ? "[contains(@class, 'mat-option-disabled')]" : EMPTY_STRING;
                Locator lookForDriver = locator(pwXPath("//mat-option" + matOptionClass + "/span[contains(text(), '" + driverUsed + "')]"));
                driverIsFound = getTextFromElement(lookForDriver).equals(driverUsed);
                if (!driverIsFound) {
                    Log.error("Selected driver [" + lookForDriver + "] should be " + (checkForDisabled ? "disabled" : "enabled"));
                    break;
                }
                sendKeys(listOfSelectADriverDropdowns.get(dropdownNumber), Keys.ESCAPE);

            }
        }
        return driverIsFound;
    }

    public boolean areAllDriversListedOnAllSelectionDropdowns(AutoApplicant applicant) throws Exception {
        List<String> listOfDrivers = getListOfDriverFullNames(applicant);
        List<Locator> listOfSelectADriverDropdowns = locators(pwXPath(VEHICLE_SECTION_XPATH + "//mat-select"));
        boolean allDriversListed = true;
        for (Locator selectDriverDropDown : listOfSelectADriverDropdowns) {
            List<String> driversListed = new ArrayList<>();
            scrollAndClickOnElement(selectDriverDropDown);
            List<Locator> listOfDriverOptionElements = locators(pwXPath("//mat-option"));
            listOfDriverOptionElements.forEach(element -> driversListed.add(getTextFromElement(element)));
            allDriversListed = listOfDrivers.equals(driversListed);
            if (!allDriversListed) {
                Log.error("Expected list of drivers " + listOfDrivers + " does not match drivers listed " + driversListed);
            }
            sendKeys(selectDriverDropDown, Keys.ESCAPE);
            wait.until(Conditions.invisibilityOfAllElements(listOfDriverOptionElements));
        }
        return allDriversListed;
    }

    public boolean areAllVehiclesListedOnPage(AutoApplicant applicant) throws Exception {
        List<String> listOfExpectedVehicles = getListOfVehicles(applicant);
        List<String> listOfVehiclesListed = new ArrayList<>();
        List<Locator> listOfVehicleElements = locators(pwXPath(VEHICLE_SECTION_XPATH + "//p"));
        for (Locator vehicleDescription : listOfVehicleElements) {
            listOfVehiclesListed.add(getTextFromElement(vehicleDescription));
        }
        boolean allVehiclesListed = listOfExpectedVehicles.equals(listOfVehiclesListed);
        if (!allVehiclesListed) {
            Log.error("Expected list of vehicles " + listOfExpectedVehicles + " does not match vehicles listed " + listOfVehiclesListed);
        }
        return allVehiclesListed;
    }

    public int selectARandomDriverForAVehicle(int vehicleToSelect) throws Exception {
        Locator randomVehicleSelectADriverDropdown = locator(pwXPath(VEHICLE_SECTION_XPATH + "[" + vehicleToSelect + "]//mat-select"));
        waitAndClickElement(randomVehicleSelectADriverDropdown);
        List<Locator> listOfDriverOptionElements = locators(pwXPath("//mat-option[not(contains(@class, 'mat-option-disabled'))]"));
        int driverToSelect = randomNumberGenerator.nextInt(listOfDriverOptionElements.size());
        waitAndClickElement(listOfDriverOptionElements.get(driverToSelect));
        wait.until(Conditions.invisibilityOfAllElements(listOfDriverOptionElements));
        return vehicleToSelect;
    }

    public int selectASpecificDriverForAVehicle(int vehicleToSelect, int driverToSelect) throws Exception {
        Locator randomVehicleSelectADriverDropdown = locator(pwXPath(VEHICLE_SECTION_XPATH + "[" + vehicleToSelect + "]//mat-select"));
        waitAndClickElement(randomVehicleSelectADriverDropdown);
        List<Locator> listOfDriverOptionElements = locators(pwXPath("//mat-option[not(contains(@class, 'mat-option-disabled'))]"));
        waitAndClickElement(listOfDriverOptionElements.get(driverToSelect));
        wait.until(Conditions.invisibilityOfAllElements(listOfDriverOptionElements));
        return vehicleToSelect;
    }

    public boolean saveAndCheckForNoErrors() {
        scrollAndClickOnElement(saveButton);
        waitForSpinnerToBeGone();
        if(isElementVisible(saveButton,1)) {
            scrollAndClickOnElement(saveButton);
            waitForSpinnerToBeGone();
        }
        return (listOfErrorLabels.count() == 0) && !isOnVehicleDriverAssignmentPage();
    }

    public void clickResetButton() {
        scrollAndClickOnElement(resetButton);
    }

    private List<String> getListOfDriverFullNames(AutoApplicant applicant) {
        List<String> listOfDriversFullnames = new ArrayList<>();
        listOfDriversFullnames.add(applicant.getFirstName() + SPACE + applicant.getLastName());
        applicant.getAdditionalDrivers().forEach(additionalDriver -> listOfDriversFullnames.add(additionalDriver.getFirstName() + SPACE + additionalDriver.getLastName()));
        return listOfDriversFullnames;
    }

    private List<String> getListOfVehicles(AutoApplicant applicant) {
        List<String> listOfVehicles = new ArrayList<>();
        int numberOfVehicles = limitVehicleCountToMaxAllowed(applicant.getStateCode(), applicant.getVehicles().size());
        for (int i = 0; i < numberOfVehicles; i++) {
            Vehicle vehicle = applicant.getVehicles().get(i);
            String vehicleModel = vehicle.getVehicleModel().replace("QUATTRO", "QUAT");
            listOfVehicles.add(vehicle.getVehicleYear() + SPACE + vehicle.getVehicleMake() + SPACE + vehicleModel);
        }
        return listOfVehicles;
    }

    private int selectARandomDriverForARandomVehicle(AutoApplicant applicant) throws Exception {
        return selectARandomDriverForAVehicle(randomNumberGenerator.nextInt(applicant.getVehicles().size()) + 1);
    }

    private boolean checkErrorLabels(boolean driverDetailsErrorLabelsOK) {
        final String missingSelectedDriverErrrorMesssage = "Please provide your driver details.";
        final String incompletePageDataMessage = "One or more required fields is incomplete or incorrect. Please review.";
        if (driverDetailsErrorLabelsOK) {
            for (Locator label : listOfErrorLabels.all()) {
                driverDetailsErrorLabelsOK = getTextFromElement(label).equals(missingSelectedDriverErrrorMesssage);
                if (!driverDetailsErrorLabelsOK) {
                    Log.error("Error message \"" + getTextFromElement(label) + "\" not \"" + missingSelectedDriverErrrorMesssage + "\"");
                    break;
                }
            }
        } else {
            Log.error("Number of assignment error messages not matching expected ");
        }
        boolean oneOrMoreErrorLabelOK = getTextFromElement(requiredFieldDataMissingLabel).equals(incompletePageDataMessage);
        if (!oneOrMoreErrorLabelOK) {
            Log.error("Error message \"" + getTextFromElement(requiredFieldDataMissingLabel) + " not \"" + incompletePageDataMessage + "\"");
        }
        return driverDetailsErrorLabelsOK && oneOrMoreErrorLabelOK;
    }

    public void assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage() throws Exception {
        AppStore.Auto auto = getSessionStorageAppStore().getAuto();
        ArrayList<AppStore.Auto.Driver> drivers = auto.getDrivers();
        List<Locator> driversOnThePage = locators(pwXPath(VEHICLE_SECTION_XPATH));


        String strDriverName = "";
        for (int i = 0; i < driversOnThePage.size(); i++) {
            strDriverName=drivers.get(i).getFirstName()+ " " +drivers.get(i).getLastName();
            Locator selectDriverDropDown = locator(pwXPath(String.format(SELECT_A_VEHICLE_DROPDOWN_FOR_DRIVER_XPATH, strDriverName)));
            waitAndClickElement(selectDriverDropDown);
            Locator driverDropDownOption = locator(pwXPath(String.format("//mat-option[contains(@class,'%s')]", "mdc-option-active")));
            waitAndClickElement(driverDropDownOption);
            sendKeysToElement(driverDropDownOption, Keys.TAB);
        }
        waitAndClickElement(saveButton);
        waitForSkeletonToBeGone();
    }

    public void processVehiclesDriversAssignmentPageIfNeeded() throws Exception {
    	if (isOnVehicleDriverAssignmentPage()) {
    		Reporter.pass("Navigated to Auto Vehicle Driver Assignment page");
    		if (getSessionStorageAppStore().getData().getLandingStateCode().equals(VA)) {
    			assignVehiclesForDriversAndSave_VehicleDriverAssignmentPage();
    		} else {
    			assignDriversForVehiclesRandomlyAndSave();
    		}
    		longWaitForElementToBeGoneByXpath("//app-rc2-loading");
    		waitForSpinnerToBeGone();
    	}
    }

    public void validateUserSuccessfullySubmittedVehicleDriverAssignmentPage(FarmersSoftAssert softAssert) {
        waitForSpinnerToBeGone();
        waitForUiSettled();
        softAssert.assertTrue(!isOnVehicleDriverAssignmentPage(), "User should be navigated away from Vehicle Driver Assignment page after saving");
    }

    public void clickOnFirstVehicleMatSelection() {
        clickElement(vehicleMatSelections.nth(0));
   }
}


