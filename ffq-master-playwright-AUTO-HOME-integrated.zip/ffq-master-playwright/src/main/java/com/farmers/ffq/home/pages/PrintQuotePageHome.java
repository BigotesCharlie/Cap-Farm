package com.farmers.ffq.home.pages;





import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;

import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.MONTHLY_AMOUNT_TEXT;
import static com.farmers.ffq.utils.GlobalVariables.QUOTE_DISCLAIMER_STATIC_TEXT2;
public class PrintQuotePageHome extends BasePage {
        private Locator printQuotePageHeaderText = locator(pwXPath("//*[@id='Header']/h1"));

        private Locator subHeaderContent = locator(pwXPath("//*[@id='Header']/p[string-length(@class)=0]"));

        private Locator premiumAmountPayInFull = locator(pwXPath("//*[@id='Premium']/tr[2]/td"));

        private Locator premiumAmountPayMonthly = locator(pwXPath("//*[@id='Premium']/tr[1]/td"));

        private Locator discountList = locator(pwXPath("//th[@class='cover' and text()='Type']/../../../tbody/tr/td"));

        private Locator propertyCoveragesList = locator(pwXPath("//table[@id='SummarySplit']/tbody[1]/tr/td/table/tbody/tr[not(contains(@style,'display:none'))]/td[1]"));

        private Locator propertyCoveragesLimitsList = locator(pwXPath("//table[@id='SummarySplit']/tbody[1]/tr/td/table/tbody/tr[not(contains(@style,'display:none'))]/td[2]"));

        private Locator liabilityCoveragesList = locator(pwXPath("//*[@id='homeAlingn']/span/span"));

        private Locator liabilityCoveragesLimitsList = locator(pwXPath("//*[@id='homesAlingn']/span"));

        private Locator policyFeaturesAndBenefitsList = locator(pwXPath("//td[@id='homeAlingn' and @class='Coverage' and not(descendant::span)]"));

        private Locator disclamerText = locator(pwXPath("//div[@class='Disclaimer']"));

    private static final String DISPLAYED = "> displayed.";
    private static final String FARMERS_INSURANCE = "FARMERS INSURANCE\u00ae";
    
    /**
     * Constructor.
     *
     * @throws Exception
     */
    public PrintQuotePageHome() throws Exception {
        super();
    }

    private void verifyContentOfThePage() {
        wait.until(Conditions.visible(printQuotePageHeaderText));
        FarmersSoftAssert fsa = new FarmersSoftAssert();
        fsa.assertTrue(getTextFromElement(printQuotePageHeaderText).contains(FARMERS_INSURANCE), FARMERS_INSURANCE + " matches " + getTextFromElement(printQuotePageHeaderText));
        fsa.assertTrue(getTextFromElement(subHeaderContent).contains("for choosing Farmers. Below is a summary of your online Home insurance quote. Please refer to your quote number to purchase your quote online or purchase your policy with one of our friendly Farmers insurance agents."), "Print quote page sub header text doesn't match ");
        fsa.assertTrue(premiumAmountPayInFull.isVisible(), "Premium amount pay in full not displayed");
        fsa.assertTrue(premiumAmountPayMonthly.isVisible(), "Premium amount pay monthly not displayed");

        for (Locator discount: discountList.all()) {
        	String discountString = getTextFromElement(discount);
            fsa.assertTrue(discount.isVisible(), "Discount <" + discountString + DISPLAYED);
        }

        for (Locator coverage: propertyCoveragesList.all()) {
        	String coverageString = getTextFromElement(coverage);
            fsa.assertTrue(coverage.isVisible(), "Coverage <" + coverageString + DISPLAYED);
        }

        for (Locator coverageLimit: propertyCoveragesLimitsList.all()) {
        	String coverageLimitString = getTextFromElement(coverageLimit);
            fsa.assertTrue(coverageLimit.isVisible(), "Coverage limit <" + coverageLimitString + DISPLAYED);
        }

        for (Locator liabilityCoverage: liabilityCoveragesList.all()) {
        	String liabilityCoverageString = getTextFromElement(liabilityCoverage);
            fsa.assertTrue(liabilityCoverage.isVisible(), "Liability coverage <" + liabilityCoverageString + DISPLAYED);
        }

        for (Locator liabilityCoverageLimit: liabilityCoveragesLimitsList.all()) {
        	String liabilityCoverageLimitString = getTextFromElement(liabilityCoverageLimit);
            fsa.assertTrue(liabilityCoverageLimit.isVisible(), "Liability coverage limit <" + liabilityCoverageLimitString + DISPLAYED);
        }
        String disclaimerString = getTextFromElement(disclamerText);
        fsa.assertTrue(disclaimerString.contains(MONTHLY_AMOUNT_TEXT), "Disclaimer contains: " + MONTHLY_AMOUNT_TEXT);
        fsa.assertTrue(disclaimerString.contains(QUOTE_DISCLAIMER_STATIC_TEXT2), "Disclaimer contains: " +  QUOTE_DISCLAIMER_STATIC_TEXT2);
        fsa.assertAll();
    }

    protected void verifyPrintQuotePage() {
        Log.info("Verifying print quote page...");
        verifyContentOfThePage();
    }
}
