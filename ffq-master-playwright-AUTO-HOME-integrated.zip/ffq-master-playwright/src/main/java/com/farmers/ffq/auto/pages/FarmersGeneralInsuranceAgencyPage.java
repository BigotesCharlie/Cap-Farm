package com.farmers.ffq.auto.pages;






import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.framework.report.Log;
import com.farmers.ffq.utils.FarmersSoftAssert;

import java.util.List;

public class FarmersGeneralInsuranceAgencyPage extends AutoBasePage {

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public FarmersGeneralInsuranceAgencyPage() throws Exception {
    }

        private Locator fgiaPromptPageHeader = locator(pwXPath("//div[contains(@class,'fgia-page-container')]/h1"));

        private Locator fgiaPromptPageSubHeader = locator(pwXPath("//div[contains(@class,'fgia-page-container')]/div/div/p"));

        private Locator fgiaPromptPageContinueButton = locator(pwXPath("//button/span[contains(text(),'Continue to FGIA')]"));

        private Locator fgiaPromptPageNoThanksButton = locator(pwXPath("*//button[contains(text(),'No, thanks')]"));

        private Locator pageHeaderText = locator(pwXPath("//h1/span[contains(text(),'Welcome to the Farmers General')]"));

        private Locator pageSubHeaderText_1 = locator(pwXPath("//h2/span[contains(text(),'What insurance')]"));

        private Locator pageSubHeaderText_2 = locator(pwXPath("//fieldset[@id='in_insurance_type']/legend/h3"));

        private Locator autoLOBCard = locator(pwXPath("//div[@class=' s12 10m l7 clm center']/ul/li[1]"));

        private Locator homeOwnersLOBCard = locator(pwXPath("//div[@class=' s12 10m l7 clm center']/ul/li[2]"));

        private Locator rentersLOBCard = locator(pwXPath("//div[@class=' s12 10m l7 clm center']/ul/li[3]"));

        private Locator personalInfromationUseLink = locator(pwXPath("//a[@class='personal-info-farmers']/div"));

        private Locator continueButton = locator(pwXPath("//button[contains(text(),'Tell us about yourself')]"));

        private Locator fgiaTryAgain = locator(pwXPath("//button[contains(@aria-label,'Try That Again')]"));

        private Locator fgiaTellUsAboutYourselfButton = locator(pwXPath("//button[@class='button medium action fill primary-btn next-step next']"));

        private Locator fgiaZipCode = locator(pwXPath("//div[@id='container_in_alt_address']//div//span//span[2]"));


    public static final String FGIA_PROMPT_PAGE_HEADER = "Continue your quote request with Farmers General Insurance Agency, Inc.";
    public static final String FGIA_PROMPT_PAGE_HEADER_2 = "Continue your quote with Farmers General Insurance Agency, Inc.";

    public static final String FGIA_PROMPT_PAGE_SUB_HEADER = "We are unable to offer you an online quote for a Farmers-branded policy at this time. However, Farmers General Insurance Agency, Inc. (FGIA) may be able to offer you a quote through other companies.";

    private static final String PAGE_TITLE = "Farmers Insurance Choice | Enter ZIP Code";
    private static final String PAGE_HEADER_TEXT = "Welcome to the Farmers General Insurance Agency quoting tool. Answer a few quick questions about yourself and we'll share customized quotes that can help you find the coverage you want -- and may save you money too. Let's get started! ";
    private static final String PAGE_SUB_HEADER_TEXT_1 = "What insurance do you need today?";
    private static final String PAGE_SUB_HEADER_TEXT_2 = "Looking for more than one policy? Select exactly what you need, even if it's more than one.";

    public void validateFGIAPromptPage(FarmersSoftAssert fsa, boolean continueToFGIA, String zipCode) throws Exception {
        fsa.assertEquals(getTextFromElement(waitElementBeVisible(fgiaPromptPageHeader)), FGIA_PROMPT_PAGE_HEADER_2, this.getClass().getSimpleName() + " Page header validation");
        fsa.assertEquals(getTextFromElement(fgiaPromptPageSubHeader), FGIA_PROMPT_PAGE_SUB_HEADER, this.getClass().getSimpleName() + " Page subheader validation");
        fsa.assertTrue(fgiaPromptPageContinueButton.isEnabled() && fgiaPromptPageContinueButton.isVisible(), "Continue to FGIA  button is displayed and enabled");
        testStep("FGIA prompt page validation", true);
        // Click on Continue to land on FGIA Page
        if (continueToFGIA) {
            waitAndClickElement(fgiaPromptPageContinueButton);
            waitForUiSettled();
            if(!(fgiaTryAgain.count() == 0)) {
                waitAndClickElement(fgiaTryAgain.nth(0));
            }
            wait.until(Conditions.titleContains("Farmers General Insurance Agency, Inc. | Select insurance type"));
            fsa.assertTrue(page().url().contains(String.format("zipcode=%s", zipCode )), "Zipcode in the url is matching");
            waitAndClickElement(fgiaTellUsAboutYourselfButton);
            fsa.assertTrue(isElementPresent(pwXPath(String.format("//span[@class='text-right zip-text h4']//span[contains(.,'%s')]", zipCode)),5), "Zip code on the page is matching");
            testStep("FGIA page title validated", true);
        }
    }

}
