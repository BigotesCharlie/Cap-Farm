package com.farmers.ffq.auto.pages;



import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;

import java.util.Arrays;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class CurrentlyInsuredPage extends AutoBasePage {


    /**
     * Constructor.
     *
     * @throws Exception
     */
    public CurrentlyInsuredPage() throws Exception {
    }

        private Locator getStartedHeading = locator(pwXPath("//h1[@class='tui-h1 insured-Model__title']"));

        private Locator currentlyInsuredOrNot = locator(pwXPath("//div[@class='interstitial-page-inner-padding']/p"));

        private Locator yesButton = locator(pwXPath("*//button[contains(text(),'Yes')]"));

        private Locator noButton = locator(pwXPath("*//button[contains(text(),'No')]"));

    private static final String PAGE_HEADER_TEXT = "Before you get started";
    private static final String PAGE_CONTENT_TEXT = "Have you been continuously insured for the past 6 months?";

    private static final String PAGE_CONTENT_TEXT_CT = "Are you currently covered by an auto insurance policy?";

    public boolean isOnCurrentlyInsuredPage() {
        return isElementVisible(getStartedHeading, 10);
    }

    public void validateCurrentlyInsuredPage(AutoApplicant applicant, FarmersSoftAssert fsa) {
        fsa.assertEquals(getTextFromElement(getStartedHeading), PAGE_HEADER_TEXT, this.getClass().getSimpleName() + " Page header validation");
        boolean autoInsuredRedStates = Arrays.asList(CT, NV).contains(applicant.getStateCode());
        if (autoInsuredRedStates) {
            fsa.assertEquals(getTextFromElement(currentlyInsuredOrNot), PAGE_CONTENT_TEXT_CT, this.getClass().getSimpleName() + " Have you been continuously insured for the past 6 months? text validation");
        } else {
            fsa.assertEquals(getTextFromElement(currentlyInsuredOrNot), PAGE_CONTENT_TEXT, this.getClass().getSimpleName() + " Are you currently insured text validation");
        }
        fsa.assertTrue(yesButton.isEnabled() && yesButton.isVisible(), "Yes button is displayed and enabled");
        fsa.assertTrue(noButton.isEnabled() && noButton.isVisible(), "No button is displayed and enabled");
        testStep("Currently insured page validation", true);
    }


    public void processCurrentlyInsuredPage(boolean isCurrentlyInsured) {
        if (isCurrentlyInsured) {
            waitAndClickElement(yesButton);
        } else {
            waitAndClickElement(noButton);
        }
        waitForSpinnerToBeGone();
    }

}
