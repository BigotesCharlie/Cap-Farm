package com.farmers.ffq.common.pages;






import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.auto.pages.AutoBasePage;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class PaymentSelectionBasePage extends AutoBasePage {
    protected static final String BANK_PAYMENT = "Bank payment";
    public static final String CARD = "Card";
    public static final String PAY_IN_FULL = "Pay in full";
    public static final String MONTHLY_AUTOPAY = "Monthly Autopay";
    public static final String PAY_IN_FULL_BANK_DEBIT = "Pay in full – bank or debit card";
    public static final String PAY_IN_FULL_CREDIT_CARD = "Pay in full – credit card";
    protected static final String VIEW_CREDIT_CARD_PRICE = "View credit card price";
    protected static final String TOTAL_PRICE_UPDATED = "Total price updated";
    protected static final String CREDIT_CARD = "Credit card";
    protected static final String DEBIT_CARD = "Debit card";
    protected static final String PAYMENT_METHOD = "Payment method";
    protected static final String ADD_YOUR_PREFERRED_PAYMENT_METHOD = "Add your preferred payment method.";
    protected static final String CHANGE_TO_NEW_PAYMENT_METHOD = "Change to a new payment method";
    protected static final String EDIT_PAYMENT_METHOD = "Edit payment method";
    protected static final String EXCLUDE_TAXES_TEXT= "Excludes taxes, fees, and surcharges";

        protected Locator payInFullHeader = locator(pwXPath("//h2[contains(text(), '" + PAY_IN_FULL + "')]"));
    protected static final String HOW_WOULD_YOU_LIKE_TO_PAY = "How would you like to pay?";
        protected Locator howWouldYouLikeToPay = locator(pwXPath("//h1[contains(text(), '" + HOW_WOULD_YOU_LIKE_TO_PAY + "')]"));
        protected Locator consolidatedPaymentPageHeader = locator(pwXPath("//app-payment-consolidated//h1"));
        protected Locator consolidatedPaymentPageHeaderBw = locator(pwXPath("//app-payment-overview//h1"));
    protected static final String BEST_VALUE_SUBHEADER = "Best value";
        protected Locator bestValueSubHeader = locator(pwXPath("//p[contains(text(), '" + BEST_VALUE_SUBHEADER + "')]"));
    protected static final String ONE_TIME_PAYMENT = "One-time payment";
        protected Locator oneTimePaymentSubHeader = locator(pwXPath("//p[contains(text(), '" + ONE_TIME_PAYMENT + "')]"));

    protected static final String SELECT_SETUP_PAYMENT = "Select & set up payment";
        protected Locator selectAndSetUpPayment = locator(pwXPath("//mat-tab-group//button[contains(text(), '" + SELECT_SETUP_PAYMENT + "')]"));

        protected Locator disclaimerChargeText = locator(pwXPath("//*[contains(@class,'disclaimers-charge-text')]"));

    // Preferred payment plan savings
    protected static final String PREFERRED_PAYMENT_PLAN_SAVINGS = "Preferred payment plan savings";
        protected Locator preferredPayPlanSavings = locator(pwXPath("//p[contains(text(), '" + PREFERRED_PAYMENT_PLAN_SAVINGS + "')]"));


    private static final String PAYMENTUS_MANAGE_PAYMENT = "Paymentus Manage Payments";
        private Locator paymentUsIframe = locator(pwXPath("//iframe[@title = '" + PAYMENTUS_MANAGE_PAYMENT + "']"));

    //No service charge
    protected static final String NO_SERVICE_CHARGE = "No service charge";
        protected Locator noServiceChargeWhenPayInFull = locator(pwXPath("//h2[contains(text(), '" + PAY_IN_FULL +"')]/ancestor::mat-card//p[contains(text(),'" + NO_SERVICE_CHARGE + "')]"));

        protected Locator excludeFeesSurchargePayInFull = locator(pwXPath("//h2[contains(text(), '" + PAY_IN_FULL +"')]/ancestor::mat-card//p[contains(text(),'" + EXCLUDE_TAXES_TEXT + "')]"));

        protected Locator includeAllFeesPayInFull = locator(pwXPath("//h2[contains(text(), '" + PAY_IN_FULL +"')]/ancestor::mat-card//p[contains(text(),'" + INCLUDES_ALL_FEES + "')]"));

    protected static final String BANK_DEBIT_CREDIT_PAYMENT = "Bank payment, debit card, or credit card";
        protected Locator bankDebitCreditCardPayment = locator(pwXPath("//p[contains(text(), '" + BANK_DEBIT_CREDIT_PAYMENT + "')]"));

    protected static final String MONTHLY_AUTO_PAY_BANK_HEADER = "Monthly autopay - bank";
    protected static final String MONTHLY_AUTO_PAY_CARD_HEADER = "Monthly autopay - card";
    public static final String MONTHLY_DIRECT_BILL = "Monthly - direct bill";

    protected static final String MONTHLY_PAY_BANK_HEADER = "Monthly - bank";
    protected static final String MONTHLY_PAY_CARD_HEADER = "Monthly - card";

        protected Locator payInMonthlyPayBankHeader = locator(pwXPath("//h2[contains(text(), '" + MONTHLY_AUTO_PAY_BANK_HEADER + "')]"));

    protected static final String CONVENIENT = "Convenient";
        protected Locator convenientHeader = locator(pwXPath("//p[contains(text(), '" + CONVENIENT + "')]"));

    protected static final String AUTO_PAY_SAVINGS_TEXT = "Autopay savings";
    protected String AUTO_PAY_SAVINGS_XPATH = "//p[contains(@class,'payment-overview-icon-padding')]";
    protected String AUTO_PAY_SAVINGS_XPATH_GREEN_CHECKMARK = "//mat-icon[contains(@class,'payment-overview-green-mark')]";
    protected static final String DOWN_PAYMENT_XPATH = "//div[@class='tui-payplan']";
    protected static final String TOTAL_PAYMENT_OVERVIEW_CARD_PREMIUM_XPATH = "//div[contains(@class,'payment-overview-card-premium-font')]";

    protected static final String MONTHLY_SERVICE_CHARGE = "Monthly service charge:";
    protected static final String INCLUDES_ALL_FEES = "(includes all fees)";
        protected Locator includedAllFeesLabel = locator(pwXPath("//p[contains(text(), '" + INCLUDES_ALL_FEES + "')]"));

    protected static final String CHANGE_LINK = "Change";
        protected Locator changeLink = locator(pwXPath("//a[contains(text(), '" + CHANGE_LINK + "')]"));
    private static final String BANK_OF_AMERICA = "BANK OF AMERICA, N.A. SFNB";
        private Locator bankNameLabel = locator(pwXPath("//span[@class='pm-display-bank-name bank-found']"));
    private static final String BANK_PAYMENT_ACCOUNT_ADDED = "Bank payment account added.";
        private Locator bankPaymentAddedMessage = locator(pwXPath("//span[text() = '" + BANK_PAYMENT_ACCOUNT_ADDED + "']"));

        private Locator bankIcon = locator(pwXPath("//i[@class='tui-icon tui-icon-generic-payment ng-star-inserted']"));

    private static final String SAVING_LABEL = "Savings";
        private Locator savingsLabel = locator(pwXPath("//label[text() = '" + SAVING_LABEL + "']"));

    private static final String BUSINESS_CHECKING_LABEL = "Business Checking";
        private Locator businessCheckingLabel = locator(pwXPath("//label[text() = '" + BUSINESS_CHECKING_LABEL + "']"));

    // paymentus iframe locators
        protected Locator paymentusIframeHeader = locator(pwXPath("//*[@aria-label='Edit payment method' and not(@role='dialog')]"));
    protected static final String BANK_PAYMENT_TOGGLE_BUTTON_TITLE = "Bank payment";
        protected Locator paymentusBankPaymentToggle = locator(pwXPath("//div[@role='tab'][contains(.,'" + BANK_PAYMENT_TOGGLE_BUTTON_TITLE + "')]"));
        protected Locator paymentusBankPaymentToggleButton = locator(pwXPath("//div[@role='tab'][contains(.,'" + BANK_PAYMENT_TOGGLE_BUTTON_TITLE + "')]/span"));
    protected static final String DEBIT_CREDIT_CARD_TOGGLE_BUTTON_TITLE = "Debit / Credit card";
        protected Locator paymentusDebitCreditCardToggle = locator(pwXPath("//div[@role='tab'][contains(.,'" + DEBIT_CREDIT_CARD_TOGGLE_BUTTON_TITLE + "')]"));
        protected Locator paymentusDebitCreditCardToggleButton = locator(pwXPath("//div[@role='tab'][contains(.,'" + DEBIT_CREDIT_CARD_TOGGLE_BUTTON_TITLE + "')]/div"));
        protected Locator paymentusBankAccountTypeHeader = locator(pwXPath("//legend"));
        protected Locator paymentusCheckingAccountRadioButton = locator(pwXPath("//fieldset//input[@id='checking']"));
        protected Locator paymentusSavingsAccountRadioButton = locator(pwXPath("//fieldset//input[@id='savings']"));
        protected Locator paymentusBusinessCheckingAccountRadioButton = locator(pwXPath("//fieldset//input[@id='busChecking']"));
        protected Locator paymentusCheckingAccountLabel = locator(pwXPath("//fieldset//label[@for='busChecking']"));
        protected Locator paymentusSavingsAccountLabel = locator(pwXPath("//fieldset//label[@for='savings']"));
        protected Locator paymentusBusinessCheckingAccountLabel = locator(pwXPath("//fieldset//label[@for='busChecking']"));
        protected Locator paymentusAccountHolderInput = locator(pwXPath("//input[@id='accountHolderField']"));
        private Locator visaCardIcon = locator(pwXPath("//span[contains(@class,'pm-display-logo-visa')]"));
        private Locator cardNumberInputField = locator(pwXPath("//input[@id='cardNumberField']"));
        private Locator masterCardIcon = locator(pwXPath("//span[contains(@class,'pm-display-logo-mc')]"));
        private Locator discoverCardIcon = locator(pwXPath("//span[contains(@class,'pm-display-logo-disc')]"));
        private Locator amexCardIcon = locator(pwXPath("//span[contains(@class,'pm-display-logo-amex')]"));

        protected Locator paymentusAccountHolderLabel = locator(pwXPath("//label[@for='accountHolderField']"));
        protected Locator paymentusCardHolderInput = locator(pwXPath("//input[@id='cardHolderField']"));
        protected Locator paymentusCardHolderLabel = locator(pwXPath("//label[@for='cardHolderField']"));
        protected Locator paymentusRoutingNumberInput = locator(pwXPath("//input[@id='routingNumberField']"));
        protected Locator paymentusRoutingNumberLabel = locator(pwXPath("//label[@for='routingNumberField']"));
        protected Locator paymentusCardNumberInput = locator(pwXPath("//input[@id='cardNumberField']"));
        protected Locator paymentusCardNumberLabel = locator(pwXPath("//label[@for='cardNumberField']"));
        protected Locator paymentusVisaCardIcon = locator(pwXPath("//div[contains(@class,'methodVisa')]"));
        protected Locator paymentusMasterCardIcon = locator(pwXPath("//div[contains(@class,'methodMastercard')]"));
        protected Locator paymentusDiscoverCardIcon = locator(pwXPath("//div[contains(@class,'methodDiscover')]"));
        protected Locator paymentusAmexCardIcon = locator(pwXPath("//div[contains(@class,'methodAmex')]"));
        protected Locator paymentusAccountNumberInput = locator(pwXPath("//input[@id='bankAccountField']"));
        protected Locator paymentusAccountNumberLabel = locator(pwXPath("//label[@for='bankAccountField']"));
        protected Locator paymentusCardExpirationDateInput = locator(pwXPath("//input[@id='ccExpirationDate']"));
        protected Locator paymentusCardExpirationDateLabel = locator(pwXPath("//label[@for='ccExpirationDate']"));
        protected Locator paymentusCardCVVFieldInput = locator(pwXPath("//input[@id='cardCVVField']"));
        protected Locator paymentusCardCVVFieldLabel = locator(pwXPath("//label[@for='cardCVVField']"));
        protected Locator paymentusZipCodeInput = locator(pwXPath("//input[@id='zipCode']"));
        protected Locator paymentusZipCodeLabel = locator(pwXPath("//label[@for='zipCode']"));
        protected Locator paymentusConfirmAccountNumberInput = locator(pwXPath("//input[@id='confirmBankAccountField']"));
        protected Locator paymentusConfirmAccountNumberLabel = locator(pwXPath("//label[@for='confirmBankAccountField']"));
        protected Locator paymentusAddButton = locator(pwXPath("//button[@name='submitBtn']"));
        protected Locator changePaymentMethodLink = locator(pwXPath("//a[contains(.,'Change')]"));

    private static final String ENTER_VALID_ACCOUNT_HOLDER_NAME_ERROR = "Please enter a valid account holder name.";
        private Locator enterValidAccountHolderNameError = locator(pwXPath("//span[text() = '" + ENTER_VALID_ACCOUNT_HOLDER_NAME_ERROR + "']"));

    private static final String ENTER_VALID_ROUTING_NUMBER_ERROR = "Please enter a valid routing number.";
        private Locator enterValidRoutingNumberError = locator(pwXPath("//span[text() = '" + ENTER_VALID_ROUTING_NUMBER_ERROR + "']"));

    private static final String ENTER_VALID_ACCOUNT_NUMBER_ERROR = "Please enter a valid bank account number.";
        private Locator enterValidAccountNumberError = locator(pwXPath("//span[text() = '" + ENTER_VALID_ACCOUNT_NUMBER_ERROR + "']"));

    private static final String BANK_ACCOUNT_NUMBERS_DO_NOT_MATCH_ERROR = "The bank account numbers do not match. Please re-enter your bank account number.";
        private Locator bankAccountNumbersDoNotMatchError = locator(pwXPath("//span[text() = '" + BANK_ACCOUNT_NUMBERS_DO_NOT_MATCH_ERROR + "']"));

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public PaymentSelectionBasePage() throws Exception {
    }

    public String getDownPayment(AppStore appStore, String payPlanDescription) throws Exception {
        List<AppStore.VerifyResponse.PaymentSchedule> monthlyEffectivePayPlan = filterListOfPaymentScheduleByPayPlan(appStore.getVerifyResponse().getPaymentSchedules(), payPlanDescription);
        return monthlyEffectivePayPlan.get(0).getDownPayment().getAmount().getAmount();
    }

    protected String getInstallmentAmountFarmers(String paymentMethod) throws Exception {
        if (paymentMethod.equals(PAY_IN_FULL)) {
            return getFullTermPremiumAmountFarmers(paymentMethod);
        }
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPayPlanCode().equals(convertPaymentMethodToPayPlanCodeFarmers(paymentMethod))).findFirst().get().getInstallments().get(0).getCurrencyAmount();
    }

    protected String getInstallmentAmountBw(String paymentMethod) throws Exception {
        if (paymentMethod.equals(PAY_IN_FULL)) {
            return getFullTermPremiumAmountBW(paymentMethod);
        }
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPaymentMethod().equals(convertPaymentMethodToPayPlanCodeBW(paymentMethod))).findFirst().get().getInstallmentAmount();
    }

    protected String getFullTermPremiumAmountFarmers(String paymentMethod) throws Exception {
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPaymentMethod().equals(convertPaymentMethodToPayPlanCodeFarmers(paymentMethod))).findFirst().get().getFullTermPremium();
    }

    protected String getFullTermPremiumAmountBW(String paymentMethod) throws Exception {
        List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules = getAutoVerifyRateResponse().getPaymentSchedules();
        return paymentSchedules.stream().filter(each -> each.getPaymentMethod().equals(convertPaymentMethodToPayPlanCodeBW(paymentMethod))).findFirst().get().getFullTermPremium();
    }

    public String convertPaymentMethodToPayPlanCodeBW(String paymentMethod) {
        switch (paymentMethod) {
            case PAY_IN_FULL:
                return "PIF";
            case MONTHLY_AUTO_PAY_BANK_HEADER:
                return "EFTB";
            case MONTHLY_AUTO_PAY_CARD_HEADER:
                return "EFTC";
            case MONTHLY_DIRECT_BILL:
                return "NON";
            case MONTHLY_AUTOPAY:
                return "MTEF";
            default:
                Log.error("Please provide acceptable payment method");
                return null;
        }
    }

    public String convertPaymentMethodToPayPlanCodeFarmers(String paymentMethod) {
        switch (paymentMethod) {
            case PAY_IN_FULL:
                return "A1";
            case MONTHLY_AUTO_PAY_BANK_HEADER:
            case MONTHLY_EFT:
                return "MTEF";
            case MONTHLY_AUTO_PAY_CARD_HEADER:
                return "MTPC";
            case MONTHLY_AUTOPAY:
            case MONTHLY_DEBIT_CARD_DESCRIPTION:
                return "MTPD";
            default:
                Log.error("Please provide acceptable payment method");
                return null;
        }
    }

    public List<AppStore.VerifyResponse.PaymentSchedule> filterListOfPaymentScheduleByPayPlan(List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules, String payPlanDescription){
        System.out.println("Payment schedules " + paymentSchedules);
        return  paymentSchedules.stream().filter(c -> c.getPayPlanDescription().equals(payPlanDescription)).collect(Collectors.toList());
    }

    public Double doublePolicyFeeAmount(String policyFee){
        Double doublePolicyFees = 0.0;
        if(!policyFee.equals("")){
            doublePolicyFees = Double.parseDouble(policyFee);
        }
        return doublePolicyFees;
    }

    public List<String> splitAmountByDecimalPoint(String fullAmount){
        String[] splitAmountByDecimalPoint = fullAmount.split("\\.");

        List<String> splittedAmountList = null;
        if(splitAmountByDecimalPoint.length == 2){
            splittedAmountList = Arrays.asList(splitAmountByDecimalPoint[0], splitAmountByDecimalPoint[1]);
        }else{
            splittedAmountList = Arrays.asList(splitAmountByDecimalPoint[0]);
        }
        return splittedAmountList;
    }
    public List<Locator> listOfFullAmountLocators(String amount, String htmlElement, boolean isCurrencyFormat) throws Exception {
        String currencyFormatAmount = CurrencyFormat.convertStringIntoCurrencyFormat(amount);
        String amountOnePayXpath = "";
        if(isCurrencyFormat){
            amountOnePayXpath  = "//" + htmlElement + "[contains(text(), '" + currencyFormatAmount + "')]";
        }else{
            amountOnePayXpath  = "//" + htmlElement + "[contains(text(), '" + String.format("%,d", Integer.parseInt(amount)) + "')]";
        }

        return locators(pwXPath(amountOnePayXpath));
    }

    public void isElementListSizeGreaterThanZero(List<Locator> elementList, String message, FarmersSoftAssert fsa){
        fsa.assertTrue(!elementList.isEmpty(), message);
    }

    protected Locator getPaymentCardSubHeaderByGivenPayMethod(String payMethod) throws Exception {
        return locator(pwXPath(getPaymentCardXPathByGivenPayMethod(payMethod) + "//div[contains(@class,'tui-presentment-card-header-row-1')]//p"));
    }

    protected String getPaymentCardXPathByGivenPayMethod(String payMethod) {
        return String.format("//mat-card[contains(.,'%s')]", payMethod);
    }

    public int getAdministrativeFeeForGivenPayPlanDescription(List<AppStore.VerifyResponse.PaymentSchedule> paymentSchedules, String payPlanDescription) {
        AppStore.VerifyResponse.PaymentSchedule paymentSchedule = filterListOfPaymentScheduleByPayPlan(paymentSchedules, payPlanDescription).stream().findFirst().get();
        String currencyAmount = paymentSchedule.getAdministrativeCharges().getCurrencyAmount();
        return (int) Double.parseDouble(currencyAmount);
    }

    public String getFormattedDecimal(double number) {
        DecimalFormat decimalFormat = new DecimalFormat("#,###.00");
        return decimalFormat.format(number);
    }


    public void addCardPaymentMethod(String cardNumber, String zipCode) throws Exception {
        clickPaymentusIframeCardToggle();
        switchToPaymentUsIframe();
        String cvv = cardNumber.equals(AMERICAN_EXPRESS_CARD) ? "1234" : CVV_NUMBER;
        enterCardNumber(cardNumber);
        Log.info("Card number has been entered: " + cardNumber);

        if (isSafariBrowser()) {
            executeScript(String.format("arguments[0].value='%s';", EXP_DATE), paymentusCardExpirationDateInput);
        } else {
            enterExpDate(EXP_DATE);
        }

        Log.info("Exp date has been entered: " + EXP_DATE);
        sendKeysToElement(waitElementBeVisible(paymentusCardCVVFieldInput), cvv);
        Log.info("Cvv has been entered: " + cvv);
        sendKeysToElement(waitElementBeVisible(paymentusZipCodeInput), zipCode);
        Log.info("Zipcode has been entered: " + zipCode);
        waitAndClickElement(paymentusAddButton);
        switchToParentWindow();
        waitForSpinnerToBeGone();
    }

    private void clickPaymentusIframeCardToggle() {
        if (isElementDisplayed(paymentusDebitCreditCardToggle, 5)) {
            int retry = 3;
            while (!getAttributeData(paymentusDebitCreditCardToggle, ARIA_SELECTED).equals(LOWERCASE_TRUE) && retry > 0) {
                waitAndClickElement(paymentusDebitCreditCardToggleButton);
                retry--;
                waitForUiSettled();
            }
        }
    }

    public void addCheckingAccountPaymentMethod(String routingNumber, String accountNumber) throws Exception {
        switchToPaymentUsIframe();
        enterRoutingNumber(routingNumber);
        Log.info("Routing Number has been entered: " + routingNumber);
        enterAccountNumber(accountNumber);
        Log.info("Account Number has been entered: " + accountNumber);
        sendKeysToElement(waitElementBeVisible(paymentusConfirmAccountNumberInput), accountNumber);
        waitAndClickElement(paymentusAddButton);
        switchToParentWindow();
        waitForSpinnerToBeGone();
    }

    public void switchToPaymentUsIframe() throws Exception {
        waitElementBeVisible(paymentUsIframe);
        switchToFrame(paymentUsIframe);
        wait.until(Conditions.clickable(paymentusAddButton));
    }

    public void isDisclaimerChargeTextCorrect(FarmersSoftAssert fsa, String expectedChargeMessage) {
        fsa.assertEquals(getTextFromElement(disclaimerChargeText), expectedChargeMessage, "Payment method charge disclaimer text validation");
    }

    public void enterCardNumber(String cardNumber){
        sendKeysToElement(waitElementBeVisible(paymentusCardNumberInput), cardNumber);
    }

    public void enterExpDate(String expDate){
        sendKeysToElement(waitElementBeVisible(paymentusCardExpirationDateInput), expDate);
    }

    public void enterRoutingNumber(String routingNumber){
        sendKeysToElement(waitElementBeVisible(paymentusRoutingNumberInput), routingNumber);
    }

    public void enterAccountNumber(String accountNumber){
        sendKeysToElement(waitElementBeVisible(paymentusAccountNumberInput), accountNumber);
    }

    public boolean isEditPaymentMethodLabelCorrect(){
        wait.until(Conditions.visible(paymentusIframeHeader));
        return isExpectedTextDisplayed(paymentusIframeHeader, EDIT_PAYMENT_METHOD);
    }

    public void clickChangeLink(){
        waitAndClickElement(changeLink);
    }

    public boolean isBOFABankNameLabelCorrect(){
        wait.until(Conditions.visible(bankNameLabel));
        return isExpectedTextDisplayed(bankNameLabel, BANK_OF_AMERICA);
    }

    public boolean isBankPaymentAccountAddedMsgCorrect() throws Exception {
        switchToDefaultContent();
        wait.until(Conditions.visible(bankPaymentAddedMessage));
        waitForUiSettled();
        return isExpectedTextDisplayed(bankPaymentAddedMessage, BANK_PAYMENT_ACCOUNT_ADDED);
    }

    public boolean isBankIconDisplayed(){
        wait.until(Conditions.visible(bankIcon));
        return bankIcon.isVisible();
    }

    public void clickSavingsRadioButton(){
        waitAndClickElement(savingsLabel);
    }


    public void clickBusinessCheckingRadioButton(){
        waitAndClickElement(businessCheckingLabel);
    }

    public boolean isSavingsLabelCorrect(){
        return isExpectedTextDisplayed(savingsLabel, SAVING_LABEL);
    }

    public boolean isBusinessCheckingLabelCorrect(){
        return isExpectedTextDisplayed(businessCheckingLabel, BUSINESS_CHECKING_LABEL);
    }

    public void clearOutAccountHolderInputField(){
        paymentusAccountHolderInput.fill("");
    }
    public boolean isEnterValidAccountHolderNameErrorCorrect(){
        wait.until(Conditions.visible(enterValidAccountHolderNameError));
        return isExpectedTextDisplayed(enterValidAccountHolderNameError, ENTER_VALID_ACCOUNT_HOLDER_NAME_ERROR);
    }

    public boolean isEnterValidRoutingNumberErrorCorrect(){
        wait.until(Conditions.visible(enterValidRoutingNumberError));
        return isExpectedTextDisplayed(enterValidRoutingNumberError, ENTER_VALID_ROUTING_NUMBER_ERROR);
    }

    public boolean isEnterValidBankAccountNumberErrorCorrect(){
        return isExpectedTextDisplayed(enterValidAccountNumberError, ENTER_VALID_ACCOUNT_NUMBER_ERROR);
    }

    public boolean isBankAccountNumbersNotMatchingErrorCorrect(){
        return isExpectedTextDisplayed(bankAccountNumbersDoNotMatchError, BANK_ACCOUNT_NUMBERS_DO_NOT_MATCH_ERROR);
    }

    public boolean isAccountHolderNameMatching(String fullName){
        String accountHolderNameFromInputField = getAttributeData(paymentusAccountHolderInput, VALUE);
        boolean isAccountHolderNameMatching = fullName.equals(accountHolderNameFromInputField);
        return isAccountHolderNameMatching;
    }

    public boolean isVisaCardIconDisplayed(){
        return visaCardIcon.isVisible();
    }

    public void clearOutCardNumberInputField(){
        waitAndClickElement(cardNumberInputField);
        cardNumberInputField.fill("");
    }

    public boolean isMasterCardIconDisplayed(){
        return masterCardIcon.isVisible();
    }

    public boolean isDiscoverCardIconDisplayed(){
        return discoverCardIcon.isVisible();
    }

    public boolean isAmexCardIconDisplayed(){
        return amexCardIcon.isVisible();
    }

    public AppStore.VerifyResponse getAutoVerifyRateResponse() throws Exception {
        return getSessionStorageAppStore().getAuto().getVerifyResponse();
    }

}
