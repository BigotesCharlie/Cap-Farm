package com.farmers.ffq.auto.pages;



import com.microsoft.playwright.Locator;
public class ThankForRetreivingQuotePage extends AutoBasePage {

		private Locator thankYouForRetreivingYourQuoteText = locator(pwClass("auto-module__retrieve-confirmation-header-text"));

		private Locator continueButton = locator(pwXPath("//mat-dialog-actions/button"));
		
	public ThankForRetreivingQuotePage() throws Exception {
		super();
		waitForSpinnerToBeGone();
		continueToBristolWest(true);
		waitElementBeVisible(thankYouForRetreivingYourQuoteText);
	}
	
	public void clickContinueButton() {
		waitElementBeVisibleClickable(continueButton);
		continueButton.click();
		waitForSpinnerToBeGone();
	}

}
