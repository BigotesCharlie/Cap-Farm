package com.farmers.ffq.datatransferobjects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Collections;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class RateQuoteServiceInitiated {
    private CalculateQuotePremium calculateQuotePremium;

    @JsonProperty("GWRateRequest")
    private GWRateRequest gwRateRequest;

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class GWRateRequest {
        private CalculateQuotePremium calculateQuotePremium;

        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class CalculateQuotePremium {
            private RateQuoteServiceInitiated.CalculateQuotePremium.AutoQuoteDetails autoQuoteDetails;
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class CalculateQuotePremium {
        private QuoteDetails quoteDetails;
        private AutoQuoteDetails autoQuoteDetails;

        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class QuoteDetails {
            private List<Customer> customer;

            @Data
            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class Customer {
                private List<Address> address;

                @Data
                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class Address {
                    private String addressStandardizedIndicator;
                }
            }
        }

        @Data
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class AutoQuoteDetails {
            private List<DriverVehicleDetails> driverVehicleDetails;

            @Data
            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class DriverVehicleDetails {
                private List<Driver> driver;

                @Data
                @JsonIgnoreProperties(ignoreUnknown = true)
                public static class Driver {
                    private String signal;
                    private String firstName;
                    private String lastName;
                    private String nonDriverReason;
                    private List<SafetyCourseDetail> safetyCourseDetails = Collections.emptyList();

                    @Data
                    @JsonIgnoreProperties(ignoreUnknown = true)
                    public static class SafetyCourseDetail {
                        private String courseDate;
                        private String safetyCourseCode;
                    }
                }
            }
        }
    }

}



