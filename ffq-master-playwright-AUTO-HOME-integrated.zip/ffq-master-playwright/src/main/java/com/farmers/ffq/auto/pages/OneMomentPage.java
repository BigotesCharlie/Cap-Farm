package com.farmers.ffq.auto.pages;


import com.microsoft.playwright.Locator;
public class OneMomentPage extends AutoBasePage {

        private Locator pageContent = locator(pwXPath("//p[contains(@class, 'auto-spinner__subheading')]"));
        private Locator pageTitle = locator(pwXPath("//app-one-moment//h1"));

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public OneMomentPage() throws Exception {
    }

    public boolean isOnOneMomentPage() {
        return isElementVisible(pageTitle, 5);
    }

    public String getOneMomentPageContent() {
	return getTextFromElement(pageContent);
    }

    public String getOneMomentPageTitle() {
        return getTextFromElement(pageTitle);
    }

    public void waitPageTitleAppear() {
        waitElementBeVisible(pageTitle);
    }

}
