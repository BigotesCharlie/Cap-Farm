package com.farmers.ffq.homevideoflow.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;
import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.WaitForSelectorState;

public abstract class BaseHomePage {
    protected final Page page;
    protected BaseHomePage(Page page) { this.page = page; }

    protected Locator button(String name) {
        return page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName(name).setExact(false));
    }

    protected void assertHeading(String text) {
        Locator h = page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName(text).setExact(false));
        if (h.count() > 0) {
            // For heading role, use the first visible one
            for (int i = 0; i < h.count(); i++) {
                Locator elem = h.nth(i);
                if (elem.isVisible()) {
                    PlaywrightAssertions.assertThat(elem).isVisible();
                    return;
                }
            }
            // If no visible heading found, assert the first one (may timeout)
            PlaywrightAssertions.assertThat(h.first()).isVisible();
        } else {
            // Fall back to text search
            Locator textLoc = page.getByText(text, new Page.GetByTextOptions().setExact(false));
            if (textLoc.count() > 0) {
                // Find the first visible text element
                for (int i = 0; i < textLoc.count(); i++) {
                    Locator elem = textLoc.nth(i);
                    if (elem.isVisible()) {
                        PlaywrightAssertions.assertThat(elem).isVisible();
                        return;
                    }
                }
                // If no visible text found, assert the first one
                PlaywrightAssertions.assertThat(textLoc.first()).isVisible();
            } else {
                throw new IllegalStateException("Heading not found: " + text + " @ " + page.url());
            }
        }
    }

    protected void clickText(String text) {
        Locator l = page.getByText(text, new Page.GetByTextOptions().setExact(false));
        if (l.count() == 0) throw new IllegalStateException("Text not found: " + text + " @ " + page.url());
        l.first().click();
    }

    protected void clickButton(String text) {
        Locator b = button(text);
        if (b.count() == 0) throw new IllegalStateException("Button not found: " + text + " @ " + page.url());
        b.first().click();
    }

    protected Locator visibleInputByLabel(String label) {
        Locator l = page.getByLabel(label, new Page.GetByLabelOptions().setExact(false));
        if (l.count() > 0) return l.first();
        return page.locator("input:visible").first();
    }

    protected void selectTextOption(String value) {
        Locator roleRadio = page.getByRole(AriaRole.RADIO, new Page.GetByRoleOptions().setName(value).setExact(false));
        if (roleRadio.count() > 0) { roleRadio.first().click(); return; }
        Locator text = page.getByText(value, new Page.GetByTextOptions().setExact(false));
        if (text.count() > 0) { text.first().click(); return; }
        throw new IllegalStateException("Option not found: " + value + " @ " + page.url());
    }

    protected void waitForBodyReady() {
        page.locator("body").waitFor();
    }

    protected void waitForSpinnerToClear() {
        page.locator(".tui-spinner-app-background")
                .waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN));
    }
}
