package com.farmers.ffq.auto.pages;






import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;

import com.farmers.framework.report.Log;
import lombok.SneakyThrows;
import static com.farmers.ffq.utils.GlobalVariables.*;

import java.util.Arrays;
import java.util.List;

public class ContinueWithBristolWestPage extends AutoBasePage {
		private Locator farmersLogoImage = locator(pwId("TUI_FARMERS_LOGO"));

		private Locator arrowImage = locator(pwId("TUI_ARROW_LOGO"));

		private Locator bristolWestLogoImage = locator(pwXPath("//img[@alt='Bristol West logo' and contains(@src,'svg')]"));

		private Locator continueToBWDialog = locator(pwXPath("//app-brightline-bw-popup"));
		private Locator continueToBWDialogTitleElement = locator(pwId("bwHeaderTitle"));
		private Locator continueToBWDialogTextElement = locator(pwXPath("//div[contains(@class, 'brightline-to-bw-page-body')]"));

		private Locator bwPageHeaderText = locator(pwClass("brightline-to-bw-page__header"));
    	private Locator bwPageSubheadingText = locator(pwXPath("//div[contains(@class,'brightline-to-bw-page__subheading')] | //div[@class='brightline-to-bw-page-body'] | //h4[contains(@class,'tui-subtitle-text')]"));
		private Locator bwAlternatePageSubheadingText = locator(pwXPath("//div[@class='row']/h4"));
        private Locator firstParagraphOfDisclaimerText = locator(pwXPath("//p[contains(@class,'disclaimer-text')][1]"));
        private Locator secondParagraphOfDisclaimerText = locator(pwXPath("//p[contains(@class,'disclaimer-text')][2]"));
		private Locator bwPageContentText = locator(pwXPath("//p[@data-test-id='DSCL_TEXT']"));

		private Locator bwPageAgreeToTermsText = locator(pwXPath("//div[contains(@class, 'brightline-to-bw-page__continue-button')]//p"));

		private Locator bwPageContinueButton = locator(pwXPath("//button[@data-test-id='BTN_TEXT']"));
		private Locator bwAlternatePageContinueButton = locator(pwXPath("//div/button[contains(text(),'Continue')]"));
		private Locator bwPageScrollboxText = locator(pwClass("brightline-to-bw-page__scroll-content"));

		private Locator thanksForChoosingBWDialog = locator(pwXPath("//app-thank-you-brightline-bw-popup"));
		private Locator thanksForChoosingBWDialogCloseButton = locator(pwXPath("//div[contains(@aria-labelledby, 'thankYouBW')]//button"));

	// links in page
		private Locator bwContactAnAgentLink = locator(pwXPath("//div[@class='brightline-to-bw-page__scroll-content']/p[1]/a"));
		private Locator bwConsumerDisclosureLink = locator(pwXPath("//div[@class='brightline-to-bw-page__scroll-content']/p[2]/a[2]"));
		private Locator bwPrivacyNoticeLink = locator(pwXPath("//div[@class='brightline-to-bw-page__scroll-content']/p[3]/a"));
		private Locator bwSummaryOfRightsLink = locator(pwXPath("//div[@class='brightline-to-bw-page__scroll-content']/p[4]/a"));
		private Locator bwDialogTitle = locator(pwId("bwHeaderTitle"));
		private Locator bwAlternatePageDialogTitle = locator(pwXPath("//div[@class='brightline-to-bw-page-container']/h1"));
		private Locator bwDialogBodyContent = locator(pwClass("brightline-to-bw-page-body"));
		private Locator bwDialogBodyContentpara1 = locator(pwXPath("//div[@class='brightline-to-bw-page-container']//div/p[1]"));
		private Locator bwDialogBodyContentpara2 = locator(pwXPath("//div[@class='brightline-to-bw-page-container']//div/p[2]"));
		private Locator bwDialogCancelButton = locator(pwXPath("//div[contains(@class, 'blbw__actions-cancel-button')]"));
		private Locator bwDialogAlternatePageCancelButton = locator(pwXPath("//div/a[contains(text(),'No, thanks')]"));
	private static final String THANK_YOU_FOR_INTEREST = "Thank you for your interest in Farmers auto insurance.";
	private static final String BASED_ON_THE_INFORMATION = "Based on the information you provided, Farmers is unable to offer you a quote.";
	private static final String BASED_ON_THE_INFORMATION_ALTERNATE = "Based on the information you provided, we may be able to offer you a quote through Bristol West, which is part of Farmers";
	private static final String DUE_TO_PRIOR_INSURANCE_REQUIREMENTS = "Due to prior insurance requirements, including length of continuous coverage and/or prior liability limits ";
	private static final String INSURANCE_REQUIREMENTS_BEGIN_ALTERNATE = THANK_YOU_FOR_INTEREST + SPACE + DUE_TO_PRIOR_INSURANCE_REQUIREMENTS;
	private static final String INSURANCE_REQUIREMENTS_END = " does not meet Farmers underwriting requirements and we are unable to offer you a quote.";
	private static final String ABLE_TO_OFFER_YOU_A_QUOTE = "We may be able to offer you a quote through Bristol West, which is part of Farmers";
	private static final String driverAdjustment = Property.getTestProperty("browser").equals(SAFARI) ? EMPTY_STRING : SPACE;

	private static final String CONTINUE_YOUR_QUOTE_REQUEST_HEADER = "Continue your quote request with Bristol West®, a part of the Farmers Insurance Group®";
	private static final String GET_A_QUOTE_WITH_FARMERS_AFFILIATE_HEADER = "Get a quote with Farmers\u00AE affiliate Bristol West\u00AE";
	private static final String CONTINUE_YOUR_QUOTE_HEADER = "Continue your quote with Farmers\u00AE affiliate Bristol West\u00AE";
	private static final String BW_DIALOG_SUBHEADER_TEXT = "We are unable to offer you an online quote for a Farmers-branded policy at this time. We may be able to offer you a quote through Bristol West\u00ae, " +
			"which is part of the Farmers organization, or you can contact a Farmers agent in your area.";
	private static final String BW_DIALOG_ALTERNATEPAGE_SUBHEADER_TEXT = THANK_YOU_FOR_INTEREST + SPACE + BASED_ON_THE_INFORMATION + SPACE + ABLE_TO_OFFER_YOU_A_QUOTE;
	private static final String BW_DIALOG_ALTERNATE_HEADER_TEXT = "Continue your quote request with Farmers\u00ae affiliate Bristol West\u00ae";
	private static final String BW_DIALOG_ALTERNATE_SUBHEADER_TEXT = BASED_ON_THE_INFORMATION + "* " + ABLE_TO_OFFER_YOU_A_QUOTE;
	private static final String BW_DIALOG_DISCLAIMER_TEXT = "String continuing this quote process, you are agreeing to receive a quote provided by a company that is part of the Bristol West Insurance Group\u00ae. " +
			"You also agree that in connection with your quote for insurance, a Bristol West carrier affiliate may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. " +
			"The Bristol West carrier affiliate may use a third party with the development of your insurance score." + driverAdjustment + "If available, a Bristol West Insurance Group entity may access from a third party a driving score based on vehicle data such as hard braking, acceleration, and speeds above 80 mph. " +
			"Bristol West may use this driving data in connection with the rating and underwriting of your auto insurance policy. Your driving history data may be shared with third parties only in connection with a lawful request by a regulatory body. " +
			"Bristol West will archive this data indefinitely for compliance auditing purposes. String proceeding, you authorize a Bristol West Insurance Group entity to obtain and use this data. " +
			"Upon your request, Bristol West will inform you of the name and address of the consumer reporting agency that will furnish this score. " +
			"Under the Fair Credit Reporting Act, you have the right to obtain a free copy of your report from LexisNexis Consumer Center, P.O. Box 105108, Atlanta, GA 30348-5108, 1-800-456-6004 " +
			"Consumer Disclosure. This request must be made no later than 60 days after you receive this notice. In addition, if you find any inaccurate or incomplete information in the report, you may dispute the report with the consumer reporting agency. " +
			"Please note the consumer reporting agency provided the report but did not make any decision regarding your eligibility and would not be able to provide an explanation of the reasons for our action.If you have any questions, please contact Farmers Insurance\u00ae. " +
			"Privacy Notice" + driverAdjustment + "You may also contact a representative if you have any questions.";
	private static final String BW_DIALOG_DISCLAIMER_TEXT2 = "*Under the Fair Credit Reporting Act, you have the right to obtain a free copy of your report from LexisNexis Consumer Center, P.O."+
			" Box 105108, Atlanta, GA 30348-5108 1-800-456-6004 consumer disclosure. This request must be made no later than 60 days after you receive this notice."+
			" In addition, if you find any inaccurate or incomplete information in the report, you may dispute the report with the consumer reporting agency."+
			" Please note the consumer reporting agency provided the report but did not make any decision regarding your eligibility and would not be able to provide an explanation of the reasons for our action. If you have any questions, please contact Farmers Insurance.";
	private static final String BW_ALTERNATE_PAGE_SUBHEADER_TEXT = THANK_YOU_FOR_INTEREST + SPACE + BASED_ON_THE_INFORMATION  + " We may be able to offer you a quote through Bristol West, which is part of Farmers";
	private static final String BW_PAGE_CONTENT_TEXT = "String continuing this quote process, you are agreeing to receive a quote provided by one of the member companies of the Bristol West Insurance Group. " +
			"You also agree that in connection with your quote for insurance, a Bristol West affiliate may review your credit report or obtain or use a credit-based insurance score based on the information contained in that credit report. " +
			"The Bristol West affiliate may use a third party with the development of your insurance score.";
	private static final String BW_PAGE_SCROLLBOX_TEXT_BEGIN = "You may also contact a representative if you have any questions. ";
	private static final String BW_PAGE_SCROLLBOX_TEXT_END = "*Under the Fair Credit Reporting Act, you have the right to obtain a free copy of your report from LexisNexis Consumer Center, P.O. Box 105108, Atlanta, GA 30348-5108 1-800-456-6004 consumer disclosure. " +
			"This request must be made no later than 60 days after you receive this notice. In addition, if you find any inaccurate or incomplete information in the report, you may dispute the report with the consumer reporting agency. " +
			"Please note the consumer reporting agency provided the report but did not make any decision regarding your eligibility and would not be able to provide an explanation of the reasons for our action. " +
			"If you have any questions, please contact Farmers Insurance";
	private static final String BW_PAGE_SCROLLBOX_TEXT_END_WITH_DOT = "*Under the Fair Credit Reporting Act, you have the right to obtain a free copy of your report from LexisNexis Consumer Center, P.O. Box 105108, Atlanta, GA 30348-5108 1-800-456-6004 consumer disclosure. " +
			"This request must be made no later than 60 days after you receive this notice. In addition, if you find any inaccurate or incomplete information in the report, you may dispute the report with the consumer reporting agency. " +
			"Please note the consumer reporting agency provided the report but did not make any decision regarding your eligibility and would not be able to provide an explanation of the reasons for our action. " +
			"If you have any questions, please contact Farmers Insurance.";
	private static final String BW_PAGE_SCROLLBOX_TEXT = BW_PAGE_SCROLLBOX_TEXT_BEGIN + BW_PAGE_SCROLLBOX_TEXT_END;
	private static final String BW_PAGE_SCROLLBOX_ALTERNATE_TEXT = BW_PAGE_SCROLLBOX_TEXT_BEGIN + "Privacy Notice " + BW_PAGE_SCROLLBOX_TEXT_END;
	public ContinueWithBristolWestPage() throws Exception {
	}

	public void validatePageContent(FarmersSoftAssert fsa) {
		final String disclaimerContains = "Disclaimer content contains: ";
		fsa.assertEquals(getTextFromElement(bwPageHeaderText), BW_DIALOG_ALTERNATE_HEADER_TEXT, "Page header content matches: " + BW_DIALOG_ALTERNATE_HEADER_TEXT);
		fsa.assertTrue(testExpectedTextContentContainsForElement(bwPageSubheadingText, BW_ALTERNATE_PAGE_SUBHEADER_TEXT), "Page subheader contains: " + BW_ALTERNATE_PAGE_SUBHEADER_TEXT);
		fsa.assertTrue(testExpectedTextContentContainsForElement(bwPageSubheadingText, BW_PAGE_CONTENT_TEXT), disclaimerContains + BW_PAGE_CONTENT_TEXT);
		fsa.assertTrue(testExpectedTextContentContainsForElement(bwPageSubheadingText, BW_PAGE_SCROLLBOX_TEXT), disclaimerContains + BW_PAGE_SCROLLBOX_TEXT);
		fsa.assertTrue(isBristolWestDialogTextContentCorrect(), disclaimerContains + BW_DIALOG_SUBHEADER_TEXT);
	}

	public void validateDialogContent(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
		validatePageHeader(fsa);
		final String subeheaderContains = "Dialog subheader contains: ";
		final String disclaimerContains = "Disclaimer content contains: ";
		if (Arrays.asList(AL, AR, CO, CT, GA, IA, ID, IN, KY, LA, MA, MD, MI, MS, NE, NM, OH, SD, TN, UT, WA, WY, WI).contains(applicant.getStateCode())) {
			if (applicant.getStateCode().equals(GA)) {
				fsa.assertTrue(testExpectedTextContentContainsForElement(continueToBWDialogTextElement, BASED_ON_THE_INFORMATION_ALTERNATE), subeheaderContains + BASED_ON_THE_INFORMATION_ALTERNATE);
			} else {
				fsa.assertTrue(testExpectedTextContentContainsForElement(continueToBWDialogTextElement, BW_DIALOG_ALTERNATE_SUBHEADER_TEXT), subeheaderContains + BW_DIALOG_ALTERNATE_SUBHEADER_TEXT);
			}
		} else if(applicant.getStateCode().equalsIgnoreCase(OR)) {
			fsa.assertTrue(testExpectedTextContentContainsForElement(continueToBWDialogTextElement, THANK_YOU_FOR_INTEREST + " Unfortunately, this quote request does not meet our underwriting requirements for the following reasons: Insureds who require financial responsibility filings are not eligible for coverage with Farmers"),
					subeheaderContains + THANK_YOU_FOR_INTEREST + " Unfortunately, this quote request does not meet our underwriting requirements for the following reasons: Insureds who require financial responsibility filings are not eligible for coverage with Farmers");

		} else {
			fsa.assertTrue(testExpectedTextContentContainsForElement(continueToBWDialogTextElement, INSURANCE_REQUIREMENTS_BEGIN_ALTERNATE + getTheFullNameWithFirstLetterInCaps(applicant.getFirstName() + SPACE + applicant.getLastName()) + INSURANCE_REQUIREMENTS_END),
					subeheaderContains + INSURANCE_REQUIREMENTS_BEGIN_ALTERNATE + getTheFullNameWithFirstLetterInCaps(applicant.getFirstName() + SPACE + applicant.getLastName()) + INSURANCE_REQUIREMENTS_END);
		}
		fsa.assertTrue(testExpectedTextContentContainsForElement(continueToBWDialogTextElement, BW_PAGE_CONTENT_TEXT), disclaimerContains + BW_PAGE_CONTENT_TEXT);
		if (applicant.getStateCode().equals(GA)) {
			fsa.assertTrue(testExpectedTextContentContainsForElement(continueToBWDialogTextElement, BW_PAGE_SCROLLBOX_ALTERNATE_TEXT), disclaimerContains + BW_PAGE_SCROLLBOX_ALTERNATE_TEXT);
		} else {
			fsa.assertTrue(testExpectedTextContentContainsForElement(continueToBWDialogTextElement, BW_PAGE_SCROLLBOX_TEXT), disclaimerContains + BW_PAGE_SCROLLBOX_TEXT);
		}
	}

	private void validatePageHeader(FarmersSoftAssert fsa) throws Exception {
		String validationMessage = "BW switch header validation";
		String landingStateCode = getSessionStorageAppStore().getData().getLandingStateCode();
		String expectedHeader = null;

		if (Arrays.asList(WI, ID, VA, TN, GA, MO, CO, TX, MA, MS, MN, NM, IA, AL, WA, CT, KS, IN, NE, OK, KY, ND, OH, LA, SD, MD, MI, WY, OR, PA, AR, UT).contains(landingStateCode)) {
			expectedHeader = CONTINUE_YOUR_QUOTE_HEADER;
		} else if (Arrays.asList(AZ, IL, NV).contains(landingStateCode)) {
			expectedHeader = GET_A_QUOTE_WITH_FARMERS_AFFILIATE_HEADER;
		} else {
			throw new IllegalStateException("Unexpected state code: " + landingStateCode);
		}
		fsa.assertEquals(getTextFromElement(bwDialogTitle), expectedHeader, validationMessage);
	}


	public void validatePageContentForNJ(FarmersSoftAssert fsa) {
		final String disclaimerContains = "Disclaimer content contains: ";
		fsa.assertEquals(getTextFromElement(waitElementBeVisible(bwPageHeaderText)), GET_A_QUOTE_WITH_FARMERS_AFFILIATE_HEADER, "Page header content matches: " + GET_A_QUOTE_WITH_FARMERS_AFFILIATE_HEADER);
		fsa.assertTrue(testExpectedTextContentContainsForElement(waitElementBeVisible(bwPageSubheadingText), BW_ALTERNATE_PAGE_SUBHEADER_TEXT), "Page subheader contains: " + BW_ALTERNATE_PAGE_SUBHEADER_TEXT);
		fsa.assertTrue(testExpectedTextContentContainsForElement(waitElementBeVisible(firstParagraphOfDisclaimerText), BW_PAGE_CONTENT_TEXT), disclaimerContains + BW_PAGE_CONTENT_TEXT);
		fsa.assertTrue(testExpectedTextContentContainsForElement(waitElementBeVisible(secondParagraphOfDisclaimerText), BW_PAGE_SCROLLBOX_TEXT_END_WITH_DOT), disclaimerContains + BW_PAGE_SCROLLBOX_TEXT_END_WITH_DOT);
	}

	public boolean isBwLogoImageDisplayed() {
		return bristolWestLogoImage.isVisible();
	}

	public boolean isBwPageHeaderTextMatching() {
		return isExpectedTextContainedInElement(bwPageHeaderText, CONTINUE_YOUR_QUOTE_REQUEST_HEADER);
	}

	public boolean isOnContinueWithBristolWestPage() {
		return isOnContinueWithBristolWestPage(25);
	}

	public boolean isOnContinueWithBristolWestPage(int secondsToWait) {
		waitForSpinnerToBeGone();
		return isElementVisible(bwPageContinueButton, secondsToWait);
	}

	public boolean isOnGetAQuoteFromBristolWestPage() {
		waitForSpinnerToBeGone();
		return isElementVisible(bwDialogTitle, 10) && List.of(CONTINUE_YOUR_QUOTE_HEADER, GET_A_QUOTE_WITH_FARMERS_AFFILIATE_HEADER).contains(getTextFromElement(bwDialogTitle));
	}

	public QuoteSummaryAutoPage continueWithBwPopUp() throws Exception {
		scrollAndClickOnElement(bwPageContinueButton);
		waitForSpinnerToBeGone();
        Log.info("User chose to continue with BW from pop up", true);
		return new QuoteSummaryAutoPage();
	}

	public void continueWithBWPage(boolean continueWithBW) throws Exception {
		if (continueWithBW) {
			clickElement(bwAlternatePageContinueButton);
		} else {
            clickElement(bwDialogAlternatePageCancelButton);
		}
	}

	public boolean isOnThanksForChoosingBristolWestDialog() {
		return isElementVisible(thanksForChoosingBWDialog, 5);
	}

	public boolean isThanksForChoosingBristolWestDialogContentCorrect() {
		return getTextFromElement(thanksForChoosingBWDialog).equals(
				"Bristol West is a Farmers affiliate and can offer competitive rates for your auto insurance. " +
				"Bristol West coverage options may be different from the ones you reviewed for the Farmers auto quote, but you’ll be able to re-review all the coverages and limits and edit them as you wish. " +
				"The bundle discount for your Farmers property policy may also change, so we’re recalculating both quotes for your review. " +
				"Thank you for your patience as we recalculate your quotes. We’ll load them shortly (about 30 seconds). )");
	}

	public void closeThanksForChoosingBristolWestDialog() {
		scrollAndClickOnElement(thanksForChoosingBWDialogCloseButton);
		waitForSpinnerToBeGone();
	}

	@SneakyThrows
	public void navigateBack() {
		back();
	}

	public boolean isBristolWestAlternatePageDialogTitleCorrect(String stateCode) throws Exception {
		waitElementBeVisible(bwDialogTitle, 3);
		String expectedHeader = Arrays.asList(CT, FL, MA, NV).contains(stateCode) ? "Get a quote with Farmers\u00AE affiliate Bristol West\u00AE" : CONTINUE_YOUR_QUOTE_HEADER;
		return isExpectedTextDisplayed(bwDialogTitle, expectedHeader);
    }

	public boolean isBristolWestDialogTextContentCorrect() {
		return isExpectedTextContainedInElement(bwDialogBodyContent, BW_DIALOG_SUBHEADER_TEXT);
	}

	public boolean isBristolWestAlternatePageDialogTextContentCorrect() {
		waitElementBeVisible(bwAlternatePageSubheadingText, 3);
		return isExpectedTextContainedInElement(bwAlternatePageSubheadingText, BW_DIALOG_ALTERNATEPAGE_SUBHEADER_TEXT);
	}

	public boolean isBristolWestAlternatePageForFL_DialogDisclaimerCorrect() {
		String disclaimerAdjustment = Property.getTestProperty("browser").equals(SAFARI) ? BW_DIALOG_SUBHEADER_TEXT : EMPTY_STRING;
		waitElementBeVisible(bwDialogBodyContentpara1,3);
		waitElementBeVisible(bwDialogBodyContentpara2,3);
		return isExpectedTextContainedInElement(bwDialogBodyContentpara1, disclaimerAdjustment + BW_PAGE_CONTENT_TEXT) && isExpectedTextContainedInElement(bwDialogBodyContentpara2, disclaimerAdjustment + BW_DIALOG_DISCLAIMER_TEXT2);
	}

	public boolean isBristolWestAlternatePageDialogDisclaimerCorrect() {
		waitElementBeVisible(bwDialogBodyContentpara2,3);
		return isExpectedTextContainedInElement(bwDialogBodyContentpara2, BW_DIALOG_DISCLAIMER_TEXT2);
	}

	public boolean areBristolWestAlternatePageDialogButtonsCorrect() {
		waitElementBeVisible(bwDialogAlternatePageCancelButton,3);
		return isExpectedTextDisplayed(bwDialogAlternatePageCancelButton, "No, thanks") && isExpectedTextDisplayed(bwAlternatePageContinueButton, "Continue");
	}

	public void validateADA_ContinueWitBristoWestPage() {
		if(isADATestingEnabled()) {
			performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);
		}
	}

	public void clickNoThanksButton() {
			waitAndClickElement(bwDialogCancelButton);
	}

	public boolean isContinueWithBristolWestDialogDisplayed() {
		waitForSpinnerToBeGone();
		return (isElementDisplayed(continueToBWDialog, 3));
	}

    public void validateRedirectionToBwInterstitialPage(AutoApplicant applicant) throws Exception {
        FarmersSoftAssert sa = new FarmersSoftAssert();
        sa.assertTrue(wait.until(Conditions.urlContains("interstitial")), "User is not redirected to Bristol West interstitial page");
        sa.assertEquals(getTextFromElement(continueToBWDialogTitleElement), "Get a quote with Farmers\u00ae affiliate Bristol West\u00ae", "Dialog title is not as expected");
        sa.assertEquals(getTextFromElement(bwPageSubheadingText),  "Thank you for your interest in Farmers auto insurance. Based on the information you provided, Farmers is unable to offer you a quote. We may be able to offer you a quote through Bristol West, which is part of Farmers", "Bw Interstitial page subheader text is not as expected");
        sa.assertTrue(isElementVisible(bwDialogAlternatePageCancelButton,1), "No, thanks button is not visible on BW interstitial page");
        continueWithBWPage(true);
        NameAndDobPage nameAndDobPage = new NameAndDobPage();
        sa.assertTrue(nameAndDobPage.isOnNameAndDobPage(), "User is not navigated to Name and DOB page after clicking continue on BW dialog");
        sa.assertTrue(nameAndDobPage.isOnBristolWest(), "User is not navigated to Bristol West page after clicking continue on BW dialog");
        nameAndDobPage.filloutApplicantForm(applicant);
        AutoEnterAddressPage autoEnterAddressPage = new AutoEnterAddressPage();
        sa.assertTrue(autoEnterAddressPage.isOnEnterAddressPage(), "User is on the Enter Address page after filling out name and dob page");
        sa.assertAll();
    }
}
