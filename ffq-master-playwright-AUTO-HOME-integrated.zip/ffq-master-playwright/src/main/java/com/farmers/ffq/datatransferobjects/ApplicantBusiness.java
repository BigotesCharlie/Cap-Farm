package com.farmers.ffq.datatransferobjects;
import java.util.Collections;
import java.util.List;

import com.farmers.ffq.dataproviderframework.DataObjectBase;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ApplicantBusiness extends DataObjectBase{

	private int businessId;
	private String industry;
	private String businessName;
	private String address1;
	private String address2;
	private String city;
	private String stateCode;
	private String zipCode;
	private String website;
	private boolean currentlyInsured;
	private boolean hasEmployees;
	private boolean usesVehicles;
	private String yearBusinessStarted;
	private String firstName;
	private String lastName;
	private int age;
	private String email;
	private String phoneNumber;
	private String extension;
	private String agentOfRecord;

	//In memory data members
	public enum insuranceStatusValues {HAVE, DONT_HAVE, INTERESTED};
	public enum contactMethods {PHONE, EMAIL, NOPREFERENCE};
	public enum contactTimes {MORNING, AFTERNOON, NOPREFERENCE};
	private List<String> listOfPolicyTypes = Collections.emptyList();
	private String additionalDetails = "";
	private insuranceStatusValues currentInsuranceStatus = insuranceStatusValues.HAVE;
	private contactMethods contactMethodPreference = contactMethods.NOPREFERENCE;
	private contactTimes contactTimePreference = contactTimes.NOPREFERENCE;

    public String toString() {
        return String.format("%s %s - %s - %s %s %s", firstName,lastName, businessName, city, stateCode, zipCode );
    }

	public boolean getHasEmployees() {
		return hasEmployees;
	}

	public boolean getUsesVehicles() {
		return usesVehicles;
	}
}
