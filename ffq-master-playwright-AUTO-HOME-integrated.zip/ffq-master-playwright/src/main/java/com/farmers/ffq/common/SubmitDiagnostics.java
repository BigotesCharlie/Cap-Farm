package com.farmers.ffq.common;

import com.microsoft.playwright.ConsoleMessage;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Request;
import com.microsoft.playwright.Response;

import java.net.URI;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

public final class SubmitDiagnostics implements AutoCloseable {
    private static final int MAX_LINES = 500;

    private final Page page;
    private final List<String> networkEvents = new ArrayList<>();
    private final List<String> consoleEvents = new ArrayList<>();
    private final List<String> pageErrors = new ArrayList<>();
    private final List<String> requestFailures = new ArrayList<>();

    private Consumer<Request> onRequest;
    private Consumer<Response> onResponse;
    private Consumer<Request> onRequestFailed;
    private Consumer<ConsoleMessage> onConsole;
    private Consumer<String> onPageError;

    private volatile boolean active;
    private long startedAtMs;

    public SubmitDiagnostics(Page page) {
        this.page = page;
    }

    public void start(String label) {
        startedAtMs = System.currentTimeMillis();
        active = true;
        addLine(networkEvents, now() + " | WINDOW_START | label=" + sanitizeText(label) + " | url=" + sanitizeUrl(page.url()));

        onRequest = request -> {
            if (!active) return;
            if (!isTrackedRequest(request)) return;
            addLine(networkEvents, now() + " | REQUEST | method=" + safe(request.method())
                    + " | resource=" + safe(request.resourceType())
                    + " | url=" + sanitizeUrl(request.url()));
        };

        onResponse = response -> {
            if (!active) return;
            Request request = response.request();
            if (!isTrackedRequest(request)) return;
            addLine(networkEvents, now() + " | RESPONSE | status=" + response.status()
                    + " | statusText=" + sanitizeText(response.statusText())
                    + " | method=" + safe(request.method())
                    + " | resource=" + safe(request.resourceType())
                    + " | requestUrl=" + sanitizeUrl(request.url())
                    + " | responseUrl=" + sanitizeUrl(response.url()));
        };

        onRequestFailed = request -> {
            if (!active) return;
            if (!isTrackedRequest(request)) return;
            String reason = sanitizeText(request.failure());
            addLine(requestFailures, now() + " | REQUEST_FAILED | method=" + safe(request.method())
                    + " | resource=" + safe(request.resourceType())
                    + " | reason=" + reason
                    + " | url=" + sanitizeUrl(request.url()));
            addLine(networkEvents, now() + " | REQUEST_FAILED | method=" + safe(request.method())
                    + " | resource=" + safe(request.resourceType())
                    + " | reason=" + reason
                    + " | url=" + sanitizeUrl(request.url()));
        };

        onConsole = message -> {
            if (!active) return;
            addLine(consoleEvents, now() + " | CONSOLE | type=" + safe(message.type())
                    + " | location=" + sanitizeUrl(message.location())
                    + " | text=" + sanitizeText(message.text()));
        };

        onPageError = error -> {
            if (!active) return;
            addLine(pageErrors, now() + " | PAGE_ERROR | " + sanitizeText(error));
        };

        page.onRequest(onRequest);
        page.onResponse(onResponse);
        page.onRequestFailed(onRequestFailed);
        page.onConsoleMessage(onConsole);
        page.onPageError(onPageError);
    }

    public void stop(String label) {
        if (!active) return;
        active = false;
        addLine(networkEvents, now() + " | WINDOW_END | label=" + sanitizeText(label)
                + " | elapsedMs=" + (System.currentTimeMillis() - startedAtMs)
                + " | url=" + sanitizeUrl(page.url()));
    }

    public String networkEventsText() {
        return join(networkEvents);
    }

    public String consoleEventsText() {
        return join(consoleEvents);
    }

    public String pageErrorsText() {
        return join(pageErrors);
    }

    public String requestFailuresText() {
        return join(requestFailures);
    }

    @Override
    public void close() {
        if (onRequest != null) page.offRequest(onRequest);
        if (onResponse != null) page.offResponse(onResponse);
        if (onRequestFailed != null) page.offRequestFailed(onRequestFailed);
        if (onConsole != null) page.offConsoleMessage(onConsole);
        if (onPageError != null) page.offPageError(onPageError);
    }

    private boolean isTrackedRequest(Request request) {
        String resourceType = safe(request.resourceType()).toLowerCase(Locale.ROOT);
        if ("xhr".equals(resourceType) || "fetch".equals(resourceType) || "document".equals(resourceType)) {
            return true;
        }
        String url = safe(request.url()).toLowerCase(Locale.ROOT);
        return url.contains("/quote/")
                || url.contains("/api/")
                || url.contains("customer")
                || url.contains("applicant")
                || url.contains("rating");
    }

    private static String join(List<String> lines) {
        if (lines.isEmpty()) return "";
        return String.join(System.lineSeparator(), lines) + System.lineSeparator();
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    private static String sanitizeUrl(String rawUrl) {
        if (rawUrl == null || rawUrl.isBlank()) return "";
        try {
            URI uri = URI.create(rawUrl);
            String scheme = uri.getScheme() == null ? "" : uri.getScheme();
            String host = uri.getHost() == null ? "" : uri.getHost();
            int port = uri.getPort();
            String path = uri.getPath() == null ? "" : uri.getPath();
            StringBuilder out = new StringBuilder();
            if (!scheme.isEmpty()) out.append(scheme).append("://");
            out.append(host);
            if (port > 0) out.append(':').append(port);
            out.append(path);
            return out.toString();
        } catch (RuntimeException ex) {
            int q = rawUrl.indexOf('?');
            return q >= 0 ? rawUrl.substring(0, q) : rawUrl;
        }
    }

    private static String sanitizeText(String text) {
        if (text == null) return "";
        String trimmed = text.trim().replaceAll("\\s+", " ");
        String lower = trimmed.toLowerCase(Locale.ROOT);
        if (lower.contains("authorization")
                || lower.contains("cookie")
                || lower.contains("bearer ")
                || lower.contains("token")) {
            return "[REDACTED_SENSITIVE_TEXT]";
        }
        if (trimmed.length() > 400) {
            return trimmed.substring(0, 400) + "...";
        }
        return trimmed;
    }

    private static String now() {
        return Instant.now().toString();
    }

    private static void addLine(List<String> target, String line) {
        if (target.size() >= MAX_LINES) return;
        target.add(line);
    }
}
