package com.farmers.ffq.auto.pages;


import com.microsoft.playwright.Locator;
public class ThankYouPageAce extends AutoBasePage {

        private Locator pageTitle = locator(pwXPath("//div[@class='thank-you__title']//h1"));

        private Locator pageSubTitle = locator(pwXPath("//div[@class='tui-body thank-you__subtitle']//p"));

        private Locator thankYouPageQuoteNumber = locator(pwXPath("//div[@class='thank-you__quote-number ng-star-inserted']//span[2]"));

        private Locator bristolWestIcon = locator(pwXPath("//img[@alt='Bristol West logo']"));

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public ThankYouPageAce() throws Exception {
    }

    public boolean isOnThankYouPage() {
        return isElementVisible(pageTitle, 15);
    }

    public boolean quickIsOnThankYouPage() {
        return isElementVisible(pageTitle, 3);
    }

    public boolean showsBristolWestIcon() {
        return isElementVisible(bristolWestIcon, 3);
    }

    public String getThankYouPageQuoteNumber() {
        scrollToElement(thankYouPageQuoteNumber);
        return getTextFromElement(thankYouPageQuoteNumber);
    }

    public String getThankYouPageTitle() {
    	return getTextFromElement(pageTitle);
    }

    public String getThankYouPageSubtitle() {
    	return getTextFromElement(pageSubTitle);
    }
}
