package com.farmers.ffq.common.enums;

import lombok.Getter;

import static com.farmers.ffq.utils.GlobalVariables.EMPTY_STRING;
import static com.farmers.ffq.utils.GlobalVariables.SAFARI;
import static com.farmers.ffq.utils.GlobalVariables.SPACE;

import java.util.Arrays;
import java.util.List;

import com.farmers.framework.Property;

@Getter
public enum CoveragesNameVsDescriptionInfoSideSheetAceHome {


    ENHANCED_PRIMARY_COVERAGE_HEADER_IN_SIDE_SHEET(Arrays.asList(CoverageInfoDetails.DWELLING_EXTENDED_REPLACEMENT_COST, CoverageInfoDetails.ROOF_MATERIAL_COV_HEADER,
            CoverageInfoDetails.SEPARATE_STRUCTURES, CoverageInfoDetails.PERSONAL_PROPERTY, CoverageInfoDetails.LOSS_OF_USE_ADDITIONAL_LIVING_EXPENSE, CoverageInfoDetails.PERSONAL_LIABILITY,
            CoverageInfoDetails.MEDICAL_PAYMENT_TO_OTHERS)),

    ENHANCED_PRIMARY_COVERAGE_HEADER_IN_SIDE_SHEET_KS(Arrays.asList(CoverageInfoDetails.DWELLING_EXTENDED_REPLACEMENT_COST, CoverageInfoDetails.ROOF_MATERIAL_COV_HEADER,
            CoverageInfoDetails.SEPARATE_STRUCTURES, CoverageInfoDetails.PERSONAL_PROPERTY, CoverageInfoDetails.LOSS_OF_USE_ADDITIONAL_LIVING_EXPENSE, CoverageInfoDetails.PERSONAL_LIABILITY,
            "Guest Medical")),

    ENHANCED_PRIMARY_COVERAGE_HEADER_IN_SIDE_SHEET_MD(Arrays.asList(CoverageInfoDetails.DWELLING_EXTENDED_REPLACEMENT_COST, CoverageInfoDetails.ROOF_MATERIAL_COV_HEADER,
            CoverageInfoDetails.SEPARATE_STRUCTURES, CoverageInfoDetails.PERSONAL_PROPERTY, CoverageInfoDetails.LOSS_OF_USE_ADDITIONAL_LIVING_EXPENSE, CoverageInfoDetails.PERSONAL_LIABILITY, CoverageInfoDetails.MEDICAL_PAYMENT_TO_OTHERS)),

    ENHANCED_PRIMARY_COVERAGE_HEADER_IN_SIDE_SHEET_VA(Arrays.asList(CoverageInfoDetails.DWELLING_EXTENDED_REPLACEMENT_COST, CoverageInfoDetails.ROOF_MATERIAL_COV_HEADER,
            CoverageInfoDetails.SEPARATE_STRUCTURES, CoverageInfoDetails.PERSONAL_PROPERTY, CoverageInfoDetails.LOSS_OF_USE, CoverageInfoDetails.PERSONAL_LIABILITY, CoverageInfoDetails.MEDICAL_PAYMENT_TO_OTHERS)),

    ENHANCED_PRIMARY_COVERAGE_DESCRIPTION_IN_SIDE_SHEET(Arrays.asList(CoverageInfoDetails.DWELLING_EXTENDED_REPLACEMENT_COST_DESCRIPTION, CoverageInfoDetails.ROOF_MATERIAL_COV_DESCRIPTION,
            CoverageInfoDetails.SEPARATE_STRUCTURES_DESCRIPTION, CoverageInfoDetails.PERSONAL_PROPERTY_DESCRIPTION, CoverageInfoDetails.LOSS_OF_USE_ADDITIONAL_LIVING_EXPENSE_DESCRIPTION,
            CoverageInfoDetails.PERSONAL_LIABILITY_DESCRIPTION, CoverageInfoDetails.MEDICAL_PAYMENT_TO_OTHERS_DESCRIPTION)),

    ENHANCED_PRIMARY_COVERAGE_DESCRIPTION_IN_SIDE_SHEET_MD(Arrays.asList(CoverageInfoDetails.DWELLING_EXTENDED_REPLACEMENT_COST_DESCRIPTION, CoverageInfoDetails.ROOF_MATERIAL_COV_DESCRIPTION,
            CoverageInfoDetails.SEPARATE_STRUCTURES_DESCRIPTION, CoverageInfoDetails.PERSONAL_PROPERTY_DESCRIPTION, CoverageInfoDetails.LOSS_OF_USE_ADDITIONAL_LIVING_EXPENSE_DESCRIPTION, CoverageInfoDetails.PERSONAL_LIABILITY_DESCRIPTION,
            CoverageInfoDetails.MEDICAL_PAYMENT_TO_OTHERS_DESCRIPTION)),

    ENHANCED_PRIMARY_COVERAGE_DESCRIPTION_IN_SIDE_SHEET_VA(Arrays.asList(CoverageInfoDetails.DWELLING_EXTENDED_REPLACEMENT_COST_DESCRIPTION, CoverageInfoDetails.ROOF_MATERIAL_COV_DESCRIPTION,
            CoverageInfoDetails.SEPARATE_STRUCTURES_DESCRIPTION, CoverageInfoDetails.PERSONAL_PROPERTY_DESCRIPTION_CONTACT_FARMERS_REPRESENTATIVE, CoverageInfoDetails.LOSS_OF_USE_DESCRIPTION, CoverageInfoDetails.PERSONAL_LIABILITY_DESCRIPTION,
            CoverageInfoDetails.MEDICAL_PAYMENT_TO_OTHERS_DESCRIPTION)),

    ENHANCED_PRIMARY_COVERAGE_DESCRIPTION_IN_SIDE_SHEET_WITH_PERILS(Arrays.asList(CoverageInfoDetails.DWELLING_EXTENDED_REPLACEMENT_COST_DESCRIPTION, CoverageInfoDetails.ROOF_MATERIAL_COV_DESCRIPTION,
            CoverageInfoDetails.SEPARATE_STRUCTURES_DESCRIPTION, CoverageInfoDetails.PERSONAL_PROPERTY_DESCRIPTION_WITH_PERIL, CoverageInfoDetails.LOSS_OF_USE_ADDITIONAL_LIVING_EXPENSE_DESCRIPTION, CoverageInfoDetails.PERSONAL_LIABILITY_DESCRIPTION,
            CoverageInfoDetails.MEDICAL_PAYMENT_TO_OTHERS_DESCRIPTION)),

    ENHANCED_ADDITIONAL_COVERAGE_HEADER_WITH_SIDING_AND_ROOF_HOME_SHARING_MINE(Arrays.asList(CoverageInfoDetails.FENCE_COV_HEADER, CoverageInfoDetails.BUILDING_ORDINANCE_COV_HEADER,
            CoverageInfoDetails.SIDING_ROOF_COV_HEADER, CoverageInfoDetails.CYBER_IDENTITY_COV_HEADER, CoverageInfoDetails.HOME_SHARING_COV_HEADER,CoverageInfoDetails.MINE_SUBSIDENCE_COV_HEADER)),

    ENHANCED_ADDITIONAL_COVERAGE_HEADER_WITH_HOME_SHARING_MINE(Arrays.asList(CoverageInfoDetails.FENCE_COV_HEADER, CoverageInfoDetails.BUILDING_ORDINANCE_COV_HEADER,
            CoverageInfoDetails.CYBER_IDENTITY_COV_HEADER, CoverageInfoDetails.HOME_SHARING_COV_HEADER,CoverageInfoDetails.MINE_SUBSIDENCE_COV_HEADER)),

    ENHANCED_ADDITIONAL_COVERAGE_HEADER_WITH_SIDING_AND_ROOF_MINE(Arrays.asList(CoverageInfoDetails.FENCE_COV_HEADER, CoverageInfoDetails.BUILDING_ORDINANCE_COV_HEADER,
            CoverageInfoDetails.SIDING_ROOF_COV_HEADER, CoverageInfoDetails.CYBER_IDENTITY_COV_HEADER, CoverageInfoDetails.MINE_SUBSIDENCE_COV_HEADER)),

    ENHANCED_ADDITIONAL_COVERAGE_HEADER_WITH_SIDING_AND_ROOF_HOME_SHARING(Arrays.asList(CoverageInfoDetails.FENCE_COV_HEADER, CoverageInfoDetails.BUILDING_ORDINANCE_COV_HEADER,
            CoverageInfoDetails.SIDING_ROOF_COV_HEADER, CoverageInfoDetails.CYBER_IDENTITY_COV_HEADER, CoverageInfoDetails.HOME_SHARING_COV_HEADER)),

    ENHANCED_ADDITIONAL_COVERAGE_HEADER_WITH_SIDING_AND_ROOF(Arrays.asList(CoverageInfoDetails.FENCE_COV_HEADER, CoverageInfoDetails.BUILDING_ORDINANCE_COV_HEADER,
            CoverageInfoDetails.SIDING_ROOF_COV_HEADER, CoverageInfoDetails.CYBER_IDENTITY_COV_HEADER)),

    ENHANCED_ADDITIONAL_COVERAGE_HEADER_WITH_HOME_SHARING(Arrays.asList(CoverageInfoDetails.FENCE_COV_HEADER, CoverageInfoDetails.BUILDING_ORDINANCE_COV_HEADER,
            CoverageInfoDetails.CYBER_IDENTITY_COV_HEADER, CoverageInfoDetails.HOME_SHARING_COV_HEADER)),

    ENHANCED_ADDITIONAL_COVERAGE_HEADER_WITH_MINE(Arrays.asList(CoverageInfoDetails.FENCE_COV_HEADER, CoverageInfoDetails.BUILDING_ORDINANCE_COV_HEADER,
            CoverageInfoDetails.CYBER_IDENTITY_COV_HEADER, CoverageInfoDetails.MINE_SUBSIDENCE_COV_HEADER)),

    ENHANCED_ADDITIONAL_COVERAGE_HEADER(Arrays.asList(CoverageInfoDetails.FENCE_COV_HEADER, CoverageInfoDetails.BUILDING_ORDINANCE_COV_HEADER,
            CoverageInfoDetails.CYBER_IDENTITY_COV_HEADER)),

    ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION_WITH_SIDING_AND_ROOF_HOME_SHARING_MINE(Arrays.asList(CoverageInfoDetails.FENCE_COV_DESCRIPTION, CoverageInfoDetails.BUILDING_ORDINANCE_COV_DESCRIPTION,
            CoverageInfoDetails.SIDING_ROOF_COV_DESCRIPTION, CoverageInfoDetails.CYBER_IDENTITY_COV_DESCRIPTION, CoverageInfoDetails.HOME_SHARING_COV_DESCRIPTION,CoverageInfoDetails.MINE_SUBSIDENCE_COV_DESCRIPTION)),

    ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION_WITH_HOME_SHARING_MINE(Arrays.asList(CoverageInfoDetails.FENCE_COV_DESCRIPTION, CoverageInfoDetails.BUILDING_ORDINANCE_COV_DESCRIPTION,
            CoverageInfoDetails.CYBER_IDENTITY_COV_DESCRIPTION, CoverageInfoDetails.HOME_SHARING_COV_DESCRIPTION,CoverageInfoDetails.MINE_SUBSIDENCE_COV_DESCRIPTION)),

    ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION_WITH_SIDING_AND_ROOF_MINE(Arrays.asList(CoverageInfoDetails.FENCE_COV_DESCRIPTION, CoverageInfoDetails.BUILDING_ORDINANCE_COV_DESCRIPTION,
            CoverageInfoDetails.SIDING_ROOF_COV_DESCRIPTION, CoverageInfoDetails.CYBER_IDENTITY_COV_DESCRIPTION, CoverageInfoDetails.MINE_SUBSIDENCE_COV_DESCRIPTION)),

    ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION_WITH_SIDING_AND_ROOF_HOME_SHARING(Arrays.asList(CoverageInfoDetails.FENCE_COV_DESCRIPTION, CoverageInfoDetails.BUILDING_ORDINANCE_COV_DESCRIPTION,
            CoverageInfoDetails.SIDING_ROOF_COV_DESCRIPTION, CoverageInfoDetails.CYBER_IDENTITY_COV_DESCRIPTION, CoverageInfoDetails.HOME_SHARING_COV_DESCRIPTION)),

    ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION_WITH_SIDING_AND_ROOF(Arrays.asList(CoverageInfoDetails.FENCE_COV_DESCRIPTION, CoverageInfoDetails.BUILDING_ORDINANCE_COV_DESCRIPTION,
            CoverageInfoDetails.SIDING_ROOF_COV_DESCRIPTION, CoverageInfoDetails.CYBER_IDENTITY_COV_DESCRIPTION)),

    ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION_WITH_HOME_SHARING(Arrays.asList(CoverageInfoDetails.FENCE_COV_DESCRIPTION, CoverageInfoDetails.BUILDING_ORDINANCE_COV_DESCRIPTION,
            CoverageInfoDetails.CYBER_IDENTITY_COV_DESCRIPTION, CoverageInfoDetails.HOME_SHARING_COV_DESCRIPTION)),

    ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION_WITH_MINE(Arrays.asList(CoverageInfoDetails.FENCE_COV_DESCRIPTION, CoverageInfoDetails.BUILDING_ORDINANCE_COV_DESCRIPTION,
            CoverageInfoDetails.CYBER_IDENTITY_COV_DESCRIPTION, CoverageInfoDetails.MINE_SUBSIDENCE_COV_DESCRIPTION)),

    ENHANCED_ADDITIONAL_COVERAGE_DESCRIPTION(Arrays.asList(CoverageInfoDetails.FENCE_COV_DESCRIPTION, CoverageInfoDetails.BUILDING_ORDINANCE_COV_DESCRIPTION,
            CoverageInfoDetails.CYBER_IDENTITY_COV_DESCRIPTION));

    public static class CoverageInfoDetails
    {
    	public static final String separator = Property.getBrowser().equals(SAFARI)? EMPTY_STRING : SPACE;
        private static final String DWELLING_EXTENDED_REPLACEMENT_COST = "Dwelling + Extended replacement cost";
        private static final String ROOF_MATERIAL_COV_HEADER = "Roof materials";
        private static final String SEPARATE_STRUCTURES = "Separate structures";
        private static final String PERSONAL_PROPERTY = "Personal property";
        private static final String LOSS_OF_USE_ADDITIONAL_LIVING_EXPENSE = "Loss of use + additional living expenses";
        private static final String LOSS_OF_USE = "Loss of use";
        private static final String PERSONAL_LIABILITY = "Personal liability";
        private static final String MEDICAL_PAYMENT_TO_OTHERS = "Medical payments to others";
        public static final String FENCE_COV_HEADER = "Fences";
        public static final String CARPET_COV_HEADER = "Carpet";

        public static final String BUILDING_ORDINANCE_COV_HEADER = "Building ordinance or law";
        private static final String SIDING_ROOF_COV_HEADER = "Limited matching coverage for siding and roof materials";
        public static final String CYBER_IDENTITY_COV_HEADER = "Cyber & identity shield";
        private static final String HOME_SHARING_COV_HEADER = "Home sharing business";
        private static final String MINE_SUBSIDENCE_COV_HEADER = "Mine subsidence";
        public static final String FENCES_LOSS_COV_HEADER = "Fences (loss settlement)";
        public static final String CARPET_LOSS_COV_HEADER = "Carpet (loss settlement)";
        public static final String LIMITED_MATCHING_UNDAMAGED_PROPERTY_COV_HEADER = "Limited matching of undamaged property";
        public static final String DWELLING_COST_DESCRIPTION = "Dwelling coverage, also known as Coverage A, can apply to many types and causes of loss, subject to your policy provisions, which include, but are not limited to, common exclusions such as, wear and tear, earth movement, earthquake, mold, flood and nuclear hazard.";
        public static final String MOBILE_HOME_COVERAGE_DESCRIPTION = "Mobile home coverage, also known as Coverage A, can apply to many types and causes of loss, subject to your policy provisions, which include, but are not limited to, common exclusions such as, wear and tear, earth movement, earthquake, mold, flood and nuclear hazard.";;
        private static final String DWELLING_EXTENDED_REPLACEMENT_COST_DESCRIPTION = DWELLING_COST_DESCRIPTION + separator + "Extended replacement cost coverage increases your Coverage A (Dwelling) limit to repair or replace covered damage to your home by the percentage option you select.";
        public static final String EXTENDED_REPLACEMENT_COST = "Extended replacement cost coverage extends your Coverage A (Dwelling) limit if needed to repair or replace covered damage to your home by the percentage option you select.";
        private static final String ROOF_MATERIAL_COV_DESCRIPTION = "Scheduled payment - The amount we may pay to repair or replace your roof is limited to a scheduled roof payment percentage, which is determined by the age and actual roof surface material types on each part of the roof at the time of a loss. Replacement cost value (RCV) - The amount we may pay for repair or replacement does not deduct for depreciation.";
        public static final String ROOF_MATERIAL_ACV_DESCRIPTION = "Actual cash value (ACV) - The amount we may pay to repair or replace your roof is limited to an actual cash value basis which is determined by the amount it would cost to repair, rebuild, or replace the roof at the time of the loss minus a deduction for depreciation. Replacement cost value (RCV) - The amount we may pay for repair or replacement does not deduct for depreciation.";
        public static final String SEPARATE_STRUCTURES_DESCRIPTION = "This coverage, also known as Coverage B, can apply to other structures on your property (such as a detached garage or tool shed) other than those used for business purposes, subject to your policy provisions, in an amount that is a percentage of the coverage limit on your house.";
        private static final String PERSONAL_PROPERTY_DESCRIPTION = "This coverage can help replace possessions owned or used by an insured anywhere in the world, subject to the policy provisions and special limits for things like jewelry, watches, furs, firearms and computers. For a complete list, please check with your Farmers\u00ae representative. Coverage for personal property is settled at Replacement Cost Value (RCV). Farmers also offers settlement at Actual Cash Value, please contact your Farmers agent for additional details on these options prior to purchase.";
        private static final String PERSONAL_PROPERTY_DESCRIPTION_CONTACT_FARMERS_REPRESENTATIVE = "This coverage can help replace possessions owned or used by an insured anywhere in the world, subject to the policy provisions and special limits for things like jewelry, watches, furs, firearms and computers. For a complete list, please check with your Farmers\u00ae representative. Coverage for personal property is settled at Replacement Cost Value (RCV). Farmers also offers settlement at Actual Cash Value, please contact your Farmers\u00ae representative for additional details on these options prior to purchase.";
        public static final String PERSONAL_PROPERTY_DESCRIPTION_COVERAGE_C = "This coverage, also known as Coverage C, can help replace your possessions owned or used by an insured anywhere in the world subject to the policy provisions and special limits for things like jewelry, watches, furs, firearms and computers. For a complete list, please check with your Farmers\u00ae representative."+ separator +
        		"Actual cash value (ACV) - The amount we may pay for repair or replacement is reduced to account for depreciation." + separator + "Replacement cost value (RCV) - The amount we may pay for repair or replacement does not deduct for depreciation.";
        private static final String MOBILE_HOME_COVERAGE_C_DESCRIPTION = "This coverage, also known as Coverage C, can help replace your possessions owned or used by an insured anywhere in the world subject to the policy provisions and special limits for things like jewelry, watches, furs, firearms and computers. For a complete list, please check with your Insurance Representative." + separator +
        		"Actual cash value (ACV) - The amount we may pay for repair or replacement is reduced to account for depreciation. ";
        public static final String PERSONAL_PROPERTY_MOBILE_HOME_DESCRIPTION = MOBILE_HOME_COVERAGE_C_DESCRIPTION + "Personal Property Replacement Cost (PPRC) - The amount we may pay for repair or replacement does not deduct for depreciation.";
        public static final String PERSONAL_EFFECTS_MOBILE_HOME_DESCRIPTION = MOBILE_HOME_COVERAGE_C_DESCRIPTION + "Personal Effects Replacement Cost (PERC) - The amount we may pay for repair or replacement does not deduct for depreciation.";
        public static final String PERSONAL_PROPERTY_DESCRIPTION_WITH_PERIL = PERSONAL_PROPERTY_DESCRIPTION_COVERAGE_C + separator + "Broad named perils coverage for personal property only provides coverage for those causes of loss identified in the endorsement." + separator + "Open perils coverage for personal property provides coverage for all causes of loss not specifically excluded in the policy." + separator + "For additional details on these options, please contact a Farmers\u00ae representative prior to purchase.";
        public static final String LOSS_OF_USE_DESCRIPTION = "Loss of use coverage, also known as Coverage D, can pay you for an increase in living expenses (housing, food, etc.) you incur while your residence is being repaired as a result of a covered loss up to the number of months allowed in Additional living expenses.";
        private static final String ADDITIONAL_LIVING_EXPENSES = "Additional living expenses is the maximum amount of time the Loss of use coverage can pay you for an increase in living expenses (housing, food, etc.) you incur while your residence is being repaired as a result of a covered loss.";
        public static final String ADDITIONAL_LIVING_EXPENSES_MOBILE_HOME_DESCRIPTION = "Additional living expenses, also known as Coverage D, can pay you for an increase in living expenses (housing, food, etc.) you incur while your residence is being repaired as a result of a covered loss up to the policy limit.";
        public static final String LOSS_OF_USE_ADDITIONAL_LIVING_EXPENSE_DESCRIPTION = LOSS_OF_USE_DESCRIPTION + separator + ADDITIONAL_LIVING_EXPENSES;
        private static final String PERSONAL_LIABILITY_DESCRIPTION = "This coverage, also known as Coverage E, can pay damages an insured becomes legally obligated to pay because of bodily injury or property damage to others.";
        private static final String MEDICAL_PAYMENT_TO_OTHERS_DESCRIPTION = "This coverage, also known as Coverage F, can pay medical costs, up to the limit selected by you, for guests who are injured at your residence, regardless of your legal liability.";
        public static final String FENCE_COV_DESCRIPTION = "Actual cash value (ACV) - The amount we may pay for repair or replacement is reduced to account for depreciation." + separator + "Replacement cost value (RCV) - The amount we may pay for repair or replacement does not deduct for depreciation.";
        public static final String BUILDING_ORDINANCE_COV_DESCRIPTION = "Provides coverage when a home is repaired or rebuilt and additional cost is incurred resulting from the enforcement of any government ordinance, code, regulation, or law.";
        private static final String SIDING_ROOF_COV_DESCRIPTION = "Provides coverage to replace undamaged, obsolete or discontinued siding and/or composition roof materials in the event of a covered loss.";
        public static final String CYBER_IDENTITY_COV_DESCRIPTION = "Provides coverage for a wide range of identity theft or cyber events, including ransomware support service, identity theft restoration, data recovery and system restoration, wire transfer fraud, and internet clean-up.";
        private static final String HOME_SHARING_COV_DESCRIPTION = "Provides coverage for a home-sharing business of the residence for a specific period of time by any insured to a home-sharing occupant, either directly or through the use of a home-sharing network platform or rental agency.";
        private static final String MINE_SUBSIDENCE_COV_DESCRIPTION = "Covers loss to the residence or living unit caused by Mine subsidence.";
        public static final String CARPET_LOSS_COV_DESCRIPTION = "Actual cash value (ACV) - The amount we may pay for repair or replacement is reduced to account for depreciation." + separator + "Replacement cost value (RCV) - The amount we may pay for repair or replacement does not deduct for depreciation.";
        public static final String LIMITED_MATCHING_UNDAMAGED_PROPERTY_COV_DESCRIPTION = "Provides coverage to replace undamaged, obsolete or discontinued siding and/or composition roof materials in the event of a covered loss.";
    	public static final String ACCESS_THROUGH_FOUNDATION_WALL_DESCRIPTION = "This coverage eliminates the $2,000 limit on the costs to tunnel under, cut into, or tear out and replace any part or portion of a foundation; slab; concrete floor, pad or patio, or the like; or the foundation or retaining wall.";

    }



    private final List<String> coveragesHeaderDescriptionInInfoSideSheet;

    CoveragesNameVsDescriptionInfoSideSheetAceHome(List<String> coveragesHeaderDescriptionInInfoSideSheet) {
        this.coveragesHeaderDescriptionInInfoSideSheet = coveragesHeaderDescriptionInInfoSideSheet;
    }

}
