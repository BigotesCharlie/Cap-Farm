package com.farmers.ffq.ace.bundle;



import com.microsoft.playwright.TimeoutError;
import com.microsoft.playwright.Page;
import com.farmers.ffq.ace.home.AceHomeContactInfoPage;
import com.farmers.ffq.ace.hrc.common.*;
import com.farmers.ffq.ace.renters.AceRentersAboutYouPage;
import com.farmers.ffq.auto.pages.*;
import com.farmers.ffq.auto.pages.bindpages.AdditionalInfoPolicyStartDateOneUI;
import com.farmers.ffq.auto.pages.bindpages.EcheckoutSuccessfulPageOneUI;
import com.farmers.ffq.auto.pages.bw.BristolWestAdditionalDiscountsPage;
import com.farmers.ffq.common.pages.BasePage;
import com.farmers.ffq.common.pages.KnockoutInconveniencePage;
import com.farmers.ffq.common.pages.LandingPage;
import com.farmers.ffq.common.pages.PolicyPaymentBasePage;
import com.farmers.ffq.datatransferobjects.*;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import com.farmers.framework.report.Reporter;
import lombok.Getter;
import lombok.Setter;
import org.testng.SkipException;

import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static com.farmers.ffq.common.pages.PaymentSelectionBasePage.MONTHLY_AUTOPAY;
import static com.farmers.ffq.utils.GlobalVariables.*;

@Setter
@Getter
public class AceBundleNavigationHelper extends BasePage {
	private String bundleType;
	private String propertyType;
	private boolean monoline;
	private String resumeFromPage;
	private String bundleQuoteNumber;
	private static final String DID_NOT_REACH = "Did not reach ";
	private static final String CONTACT_INFO_PAGE = "ContactInfoPage";

	public static final String BUNDLE_QUOTE_SUMMARY_PAGE = "BundleQuoteSummaryPage";

	public AceBundleNavigationHelper(String kindOfBundle) throws Exception {
		super();
		setBundleType(kindOfBundle);
		setPropertyType(HOME);
		setMonoline(false);
		setResumeFromPage(EMPTY_STRING);
		setBundleQuoteNumber(EMPTY_STRING);
	}

	public EcheckoutSuccessfulPageOneUI navigateToECheckoutPage(AceBundleApplicant bundleApplicant) throws Exception {
		AceHRCPaymentSelectionPage aceHRCPaymentSelectionPage = navigateToPayForPropertyPage(bundleApplicant);
		AceHRCPaymentBasePage aceHRCPaymentBasePage = new AceHRCPaymentBasePage();
		PolicyPaymentBasePage policyPaymentBasePage = new PolicyPaymentBasePage();
		try {
			if (getBundleType().equals(AUTO_HOME_BUNDLE)) {
				aceHRCPaymentSelectionPage.clickSelectAndSetUpPaymentPayInFullCard(getPropertyType());
				policyPaymentBasePage.clickSetUpPaymentButtonBundle();
			} else {
				AceHRCConsolidatedPaymentPage aceHRCConsolidatedPaymentPage = new AceHRCConsolidatedPaymentPage();
				aceHRCConsolidatedPaymentPage.selectPaymentMethodFromPaymentCards(MONTHLY_AUTOPAY);
				aceHRCConsolidatedPaymentPage.clickCardRadioButton();
			}
			if (aceHRCPaymentBasePage.isSamePaymentModalDisplayed()) {
				aceHRCPaymentBasePage.clickSameButtonSamePaymentModal();
			} else {
				policyPaymentBasePage.clickDebitCreditCardButton();
				aceHRCPaymentBasePage.enterCreditOrDebitCardInfoAndClickAddButton(MASTER_CARD);
			}
		} catch (TimeoutError e) {
			throw new NavigationException(aceHRCPaymentBasePage.getClass().getSimpleName(), bundleApplicant);
		}
		aceHRCPaymentBasePage.waitForSpinnerToBeGone();
		aceHRCPaymentBasePage.clickCompletePurchaseButton();
		EcheckoutSuccessfulPageOneUI echeckoutPage = new EcheckoutSuccessfulPageOneUI();
		//So all work is not lost if payment fails we will let the page return if no other error is detected
		if (!new KnockoutInconveniencePage().isQuoteKnockedOut()) {
			if (echeckoutPage.isPaymentSuccessfulMessageCorrect()) {
				Reporter.pass("Navigated to eCheckout page");
			} else {
				throw new NavigationException(echeckoutPage.getClass().getSimpleName(), bundleApplicant);
			}
		}
		return echeckoutPage;
	}

	public AceHRCPaymentSelectionPage navigateToPayForPropertyPage(AceBundleApplicant bundleApplicant) throws Exception {
		AceBundleAutoPaymentPage payForAutoQuotePage = navigateToPayForAutoPage(bundleApplicant);
		payForAutoQuotePage.fillOutAutoPaymentPageAndContinue(bundleApplicant.getAutoApplicant());
		AceHRCPaymentSelectionPage payForPropertyQuotePage = new AceHRCPaymentSelectionPage();
		if (payForPropertyQuotePage.quickIsOnPaymentPage()) {
			Reporter.pass("Navigated to Bundle Pay For Property page");
		} else {
			throw new NavigationException(payForPropertyQuotePage.getClass().getSimpleName(), bundleApplicant);
		}
		return payForPropertyQuotePage;
	}

	public AceBundleAutoPaymentPage navigateToPayForAutoPage(AceBundleApplicant bundleApplicant) throws Exception {
		AceBundleFinalReviewPage finalReviewPage = navigateToFinalReviewPage(bundleApplicant);
		finalReviewPage.clickContinueButton();
		finalReviewPage.waitForSpinnerToBeGone();
		AceBundleAutoPaymentPage payForAutoQuotePage = new AceBundleAutoPaymentPage();
		if (payForAutoQuotePage.isOnAceBundleAutoPaymentPage()) {
			Reporter.pass("Navigated to Bundle Pay For Auto Quote page");
		} else {
			throw new NavigationException(payForAutoQuotePage.getClass().getSimpleName(), bundleApplicant);
		}
		return payForAutoQuotePage;
	}

	public AceBundleFinalReviewPage navigateToFinalReviewPage(AceBundleApplicant bundleApplicant) throws Exception {
		AceHRCJustAFewMoreThingsBasePage propertyJFMTPage = navigateToBundlePropertyJustAFewMoreThingsPage(bundleApplicant);
		propertyJFMTPage.fillOutBundleJFMTPageAndContinue(bundleApplicant.getHrcApplicant(), getPropertyType());
		AceBundleFinalReviewPage bundleFinalReviewQuotePage = new AceBundleFinalReviewPage();
		if (bundleFinalReviewQuotePage.isOnFinalReviewPage()) {
			Reporter.pass("Navigated to Bundle Final Quote Review page");
		} else {
			throw new NavigationException(bundleFinalReviewQuotePage.getClass().getSimpleName(), bundleApplicant);
		}
		return bundleFinalReviewQuotePage;
	}

	public AceHRCJustAFewMoreThingsBasePage navigateToBundlePropertyJustAFewMoreThingsPage(AceBundleApplicant bundleApplicant) throws Exception {
		AdditionalInfoPolicyStartDateOneUI autoAdditionalInfoPage = navigateToBundleJustAFewMoreThingsPage(bundleApplicant);
		autoAdditionalInfoPage.fillOutAdditionalInfoPage(true);
		ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
		contactInfoAutoPage.waitForRC2ScreenToFinish();
		boolean quoteReset = checkForPropertyKnockoutAndReset(bundleApplicant, new AceHRCDwellingCoverageBasePage());
		if (quoteReset) {
			navigateToBundleQuoteReviewPageUsingDefaults();
		}
		ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
		if (continueWithBristolWestPage.isOnContinueWithBristolWestPage(5)) {
			quoteReset = true;
			continueWithBristolWestPage.continueWithBwPopUp();
			contactInfoAutoPage.waitForRC2ScreenToFinish();
			Reporter.pass("Navigated to Bristol West");
			if (continueWithBristolWestPage.isOnThanksForChoosingBristolWestDialog()) {
				//This section will probably fail until we can get the elements from this dialog
				if (continueWithBristolWestPage.isThanksForChoosingBristolWestDialogContentCorrect()) {
					Reporter.pass("Thanks For Choosing Bristol West dialog content correct");
				} else {
					Reporter.fail("Thanks For Choosing Bristol West dialog content incorrect", true);
				}
				continueWithBristolWestPage.closeThanksForChoosingBristolWestDialog();
			}
			if (new KnockoutInconveniencePage().isQuoteKnockedOut()) {
				//Reset page in an attempt to clear issue
				Log.warn("BWAuto quote portion possibly knocked out, attempt to correct issue");
				String hostName = new URL(Property.getUri()).getHost();
				navigate("https://" + hostName + "/quote/auto/contact-info");
				waitForSpinnerToBeGone();
			}
			if (contactInfoAutoPage.isOnBundlePolicyStartDatePage()) {
				contactInfoAutoPage.clickContactInfoPageCTAButton();
				contactInfoAutoPage.waitForRC2ScreenToFinish();
			}
		}
		DriverMismatchPage driverMismatchPage = new DriverMismatchPage();
		if (driverMismatchPage.isOnDriverMismatchPage()) {
			Reporter.pass("Navigated to Driver mismatch page");
			driverMismatchPage.randomlySelectReasonForNonInclusion();
			driverMismatchPage.clickContinueButton();
		}
		if (quoteReset) {
			setResumeFromPage(BUNDLE_QUOTE_SUMMARY_PAGE);
			QuoteSummaryAutoPage quoteSummaryPage = new QuoteSummaryAutoPage();
			if (!new AceBundleReviewQuotesPage().isOnBundleReviewQuotesPage()) {
				if (quoteSummaryPage.notAbleToOfferBundle()) {
					Log.warn("Bundling not available for " + getBundleQuoteNumber() + ", skipping test", true);
					throw new SkipException("Bundling not available for " + getBundleQuoteNumber() + " , skipping test");
				}
				completeAutoQuoteNavigation(bundleApplicant); //To handle pre-bundle quote review pages
			}
			if (contactInfoAutoPage.qualifiesForAdditionalDiscountsPagePresent()) {
				contactInfoAutoPage.clickContinueButton();
			}
			if (quoteSummaryPage.notAbleToOfferBundle()) {
				Log.warn("Bundling not available for " + getBundleQuoteNumber() + ", skipping test", true);
				throw new SkipException("Bundling not available for " + getBundleQuoteNumber() + " , skipping test");
			}
			if (quoteSummaryPage.quickIsOnQuoteSummaryAutoPage()) {
				setResumeFromPage(quoteSummaryPage.getClass().getSimpleName());
			}
			navigateToBundleJustAFewMoreThingsPage(bundleApplicant); //To handle post bundle quote review pages
			autoAdditionalInfoPage.fillOutAdditionalInfoPage(true);
			contactInfoAutoPage.waitForRC2ScreenToFinish();
		}
		AceHRCJustAFewMoreThingsBasePage bundlePropertyJustAFewMoreThingsPage = new AceHRCJustAFewMoreThingsBasePage();
		if (bundlePropertyJustAFewMoreThingsPage.isOnBundleJMFTPage()) {
			Reporter.pass("Navigated to " + getPropertyType() + " JFMAT page");
		} else {
			throw new NavigationException(bundlePropertyJustAFewMoreThingsPage.getClass().getSimpleName(), bundleApplicant);
		}
		return bundlePropertyJustAFewMoreThingsPage;
	}

	public AdditionalInfoPolicyStartDateOneUI navigateToBundleJustAFewMoreThingsPage(AceBundleApplicant bundleApplicant) throws Exception {
		if (isShortcutToPurchaseState(bundleApplicant.getAutoApplicant().getStateCode())) {
			AceBundleReviewQuotesPage bundleQuoteReviewPage = navigateToBundleQuoteReviewPage(bundleApplicant);
			bundleQuoteReviewPage.clickNextButton();
		} else {
			AceHRCAdditionalCoveragesBasePage propertyOptionalCoveragesPage = navigateToBundlePropertyOptionalCoveragesPage(bundleApplicant);
			propertyOptionalCoveragesPage.scrollAndClickOnContinueButton();
		}
		if (new ThankYouPageAce().quickIsOnThankYouPage()) {
			Log.warn("Binding not available for " + getBundleQuoteNumber() + ", skipping test", true);
			throw new SkipException("Binding not available for " + getBundleQuoteNumber() + " , skipping test");
		}
		AdditionalInfoPolicyStartDateOneUI bundleAutoJustAFewMoreThingsPage = new AdditionalInfoPolicyStartDateOneUI();
		if (bundleAutoJustAFewMoreThingsPage.isOnAdditionalInfoPage()) {
			Reporter.pass("Navigated to Bundle Auto - Policy start date page");
		} else {
			throw new NavigationException(bundleAutoJustAFewMoreThingsPage.getClass().getSimpleName(), bundleApplicant);
		}
		return bundleAutoJustAFewMoreThingsPage;
	}

	public AceHRCAdditionalCoveragesBasePage navigateToBundlePropertyOptionalCoveragesPage(AceBundleApplicant bundleApplicant) throws Exception {
		AceHRCReviewQuoteBasePage propertySummaryQuotePage = navigateToBundlePropertyQuoteReviewPage(bundleApplicant);
		propertySummaryQuotePage.clickContinueToMoreCoveragesButton();
		waitForSpinnerToBeGone();
		AceHRCAdditionalCoveragesBasePage propertyOptionalCoveragesPage = new AceHRCAdditionalCoveragesBasePage();
		if (propertyOptionalCoveragesPage.isOnBundlePropertyOptionalCoveragesPage()) {
			Reporter.pass("Navigated to " + getPropertyType() + " optional coverages page");
		} else {
			throw new NavigationException(propertyOptionalCoveragesPage.getClass().getSimpleName(), bundleApplicant);
		}
		return propertyOptionalCoveragesPage;
	}

	public AceHRCReviewQuoteBasePage navigateToBundlePropertyQuoteReviewPage(AceBundleApplicant bundleApplicant) throws Exception {
		AceHRCReviewQuoteBasePage propertySummaryQuotePage = new AceHRCReviewQuoteBasePage();
		if (isShortcutToPurchaseState(bundleApplicant.getAutoApplicant().getStateCode())) {
			AceBundleReviewQuotesPage bundleQuoteReviewPage = navigateToBundleQuoteReviewPage(bundleApplicant);
			bundleQuoteReviewPage.clickReviewUpdatePropertyQuote();
		} else {
			QuoteSummaryAutoPage autoQuoteSummaryPage = navigateToBundleAutoQuoteReviewPage(bundleApplicant);
			autoQuoteSummaryPage.clickNextToReviewPropertyCoveragePage();
		}
		if (propertySummaryQuotePage.isOnBundlePropertyReviewQuotePage()) {
			Reporter.pass("Navigated to " + getPropertyType() + " review quote page");
		} else {
			throw new NavigationException(propertySummaryQuotePage.getClass().getSimpleName(), bundleApplicant);
		}
		return propertySummaryQuotePage;
	}

	public QuoteSummaryAutoPage navigateToBundleAutoQuoteReviewPage(AceBundleApplicant bundleApplicant) throws Exception {
		QuoteSummaryAutoPage autoQuoteSummaryPage = new QuoteSummaryAutoPage();
		if (getResumeFromPage().equals(autoQuoteSummaryPage.getClass().getSimpleName()) && autoQuoteSummaryPage.quickIsOnQuoteSummaryAutoPage()) {
			return autoQuoteSummaryPage;
		}
		AceBundleReviewQuotesPage bundleQuoteReviewPage = navigateToBundleQuoteReviewPage(bundleApplicant);
		if (isShortcutToPurchaseState(bundleApplicant.getAutoApplicant().getStateCode())) {
			bundleQuoteReviewPage.clickReviewUpdateAutoQuote();
		} else {
			bundleQuoteReviewPage.clickNextButton();
		}
		if (autoQuoteSummaryPage.quickIsOnQuoteSummaryAutoPage()) {
			Reporter.pass("Navigated to Auto review quote page");
		} else {
			throw new NavigationException(autoQuoteSummaryPage.getClass().getSimpleName(), bundleApplicant);
		}
		return autoQuoteSummaryPage;
	}

	public AceBundleReviewQuotesPage navigateToBundleQuoteReviewPage(AceBundleApplicant bundleApplicant) throws Exception {
		AceBundleReviewQuotesPage bundleQuoteReviewPage = new AceBundleReviewQuotesPage();
		if (getResumeFromPage().equals(BUNDLE_QUOTE_SUMMARY_PAGE) && bundleQuoteReviewPage.isOnBundleReviewQuotesPage()) {
			return bundleQuoteReviewPage;
		}
		AceHRCDwellingCoverageBasePage hrcDwellingCoveragePage = navigateToHRCReviewDwellingCoveragePage(bundleApplicant);
		if (!getBundleType().equals(AUTO_RENTERS_BUNDLE)) {
			hrcDwellingCoveragePage.scrollAndClickOnContinueButton();
			waitForSpinnerToBeGone();
			//having to do this twice
			if (hrcDwellingCoveragePage.quickIsOnDwellingCoveragePage()) {
				hrcDwellingCoveragePage.scrollAndClickOnContinueButton();
			}
		}
		checkForPropertyKnockoutAndReset(bundleApplicant, hrcDwellingCoveragePage);
		waitForSkeletonToBeGone();
		while (hrcDwellingCoveragePage.isOnRC2LoadingPage(2)) {
			//keep waiting for the RC2 page to be dismissed...
			waitForUiSettled();
		}
		if (getResumeFromPage().equals("BundlingNotAvailable")) {
			//Exit out and let caller handle result
			return bundleQuoteReviewPage;
		} else if (new QuoteSummaryAutoPage().notAbleToOfferBundle()) {
			Log.warn("Bundling not available for " + getBundleQuoteNumber() + ", skipping test", true);
			throw new SkipException("Bundling not available for " + getBundleQuoteNumber() + " , skipping test");
		} else {
			if (bundleQuoteReviewPage.isOnBundleReviewQuotesPage()) {
				Reporter.pass("Navigated to Bundle Quote Summary page");
				if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
					FarmersSoftAssert tempFsa = new FarmersSoftAssert();
					bundleQuoteReviewPage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
					validateAssignedAgentSection(bundleQuoteReviewPage, tempFsa);
				}
				writeRatedQuoteInformationToFile(getBundleType() + SPACE + getBundleQuoteNumber() + SPACE + bundleApplicant);
			} else {
				throw new NavigationException(bundleQuoteReviewPage.getClass().getSimpleName(), bundleApplicant);
			}
		}
		return bundleQuoteReviewPage;
	}

	private boolean checkForPropertyKnockoutAndReset(AceBundleApplicant bundleApplicant, AceHRCDwellingCoverageBasePage hrcDwellingCoveragePage) throws Exception {
		boolean resetQuote = false;
		if (new KnockoutInconveniencePage().isQuoteKnockedOut()) {
			//Reset page in an attempt to clear issue
			Log.warn(getPropertyType() + " quote portion possibly knocked out, attempt to correct issue");
			String hostName = new URL(Property.getUri()).getHost();
			if (getBundleType().equals(AUTO_HOME_BUNDLE)) {
				navigate("https://" + hostName + "/quote/home/custom-coverage");
				waitForSpinnerToBeGone();
				if (hrcDwellingCoveragePage.quickIsOnDwellingCoveragePage()) {
					Reporter.pass("Resuming from Review your dwelling coverage page");
					hrcDwellingCoveragePage.scrollAndClickOnContinueButton();
				}
			} else {
				navigate("https://" + hostName + "/quote/home/contact-info");
				waitForSpinnerToBeGone();
				Reporter.pass("Resuming from Property policy start page");
				hrcDwellingCoveragePage.scrollAndClickOnContinueButton();
			}
			if (new KnockoutInconveniencePage().isQuoteKnockedOut()) {
				//Reset attempt failed, still getting knocked out
				throw new NavigationException(getPropertyType() + " quote rate: Reset attempt failed", bundleApplicant);
			}
			resetQuote = true;
		}
		return resetQuote;
	}

	public AceHRCDwellingCoverageBasePage navigateToHRCReviewDwellingCoveragePage(AceBundleApplicant bundleApplicant) throws Exception {
		AceHRCDwellingCoverageBasePage hrcDwellingCoveragePage = new AceHRCDwellingCoverageBasePage();
		if (getResumeFromPage().equals(hrcDwellingCoveragePage.getClass().getSimpleName())) {
			return hrcDwellingCoveragePage;
		}
		ApplicantAceHome hrcApplicant = bundleApplicant.getHrcApplicant();
		AceHomeContactInfoPage hrcPropertyPolicyStartPage = navigateToHRCPolicyStartPage(bundleApplicant);
		hrcPropertyPolicyStartPage.enterPolicyStartDate(hrcApplicant);
		hrcApplicant.setEarlyShoppingFactor(hrcPropertyPolicyStartPage.getPolicyStartDate());
		bundleApplicant.setHrcApplicant(hrcApplicant);
		hrcPropertyPolicyStartPage.enterFireHydrantData(hrcApplicant);
		if (isMonoline()) {
			hrcPropertyPolicyStartPage.enterEmailIdAndPhoneNumberInContactInfoPage(hrcApplicant);
		}
		hrcPropertyPolicyStartPage.clickOnAgreeAndSubmitButton();
		waitForSpinnerToBeGone();
		waitForSpinnerToBeGone(); //Page seems to be submitted twice
		if (getResumeFromPage().equals("switchToMonoline")) {
			//Exit out and let caller handle result
			return hrcDwellingCoveragePage;
		}
		if (new QuoteSummaryAutoPage().notAbleToOfferBundle()) {
			Log.warn("Bundling not available for " + getBundleQuoteNumber() + ", skipping test", true);
			throw new SkipException("Bundling not available for " + getBundleQuoteNumber() + ", skipping test");
		}
		if (!getBundleType().equals(AUTO_RENTERS_BUNDLE)) {
			if (hrcDwellingCoveragePage.quickIsOnDwellingCoveragePage()) {
				Reporter.pass("Navigated to Review your dwelling coverage page");
				if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
					FarmersSoftAssert tempFsa = new FarmersSoftAssert();
					hrcDwellingCoveragePage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
					validateAssignedAgentSection(hrcDwellingCoveragePage, tempFsa);
				}
			} else {
				throw new NavigationException(hrcDwellingCoveragePage.getClass().getSimpleName(), bundleApplicant);
			}
		}
		return hrcDwellingCoveragePage;
	}

	public AceHomeContactInfoPage navigateToHRCPolicyStartPage(AceBundleApplicant bundleApplicant) throws Exception {
		ApplicantAceHome hrcApplicant = bundleApplicant.getHrcApplicant();
		AceHRCAboutYouBasePage hrcAboutYouPage = navigateToAceHRCAboutYouPage(bundleApplicant);
		if (hrcAboutYouPage.isOnAboutYouPage(false)) {
			if (getBundleType().equals(AUTO_RENTERS_BUNDLE) && isMonoline()) {
				new AceRentersAboutYouPage().fillOutTheDataInAboutYouPageRenters(hrcApplicant, true);
			} else {
				hrcAboutYouPage.fillOutTheDataInAboutYouPage(hrcApplicant, true);
			}
		}
		AceHomeContactInfoPage hrcPropertyPolicyStartPage = new AceHomeContactInfoPage();
		if (hrcPropertyPolicyStartPage.isOnBundlePolicyStartDatePage()) {
			Reporter.pass("Navigated to Property policy start Page");
			if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
				FarmersSoftAssert tempFsa = new FarmersSoftAssert();
				hrcPropertyPolicyStartPage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
				validateAssignedAgentSection(hrcPropertyPolicyStartPage, tempFsa);
			}
			return hrcPropertyPolicyStartPage;
		} else {
			throw new NavigationException(hrcPropertyPolicyStartPage.getClass().getSimpleName(), bundleApplicant);
		}
	}

	public AceHRCAboutYouBasePage navigateToAceHRCAboutYouPage(AceBundleApplicant bundleApplicant) throws Exception {
		ApplicantAceHome hrcApplicant = bundleApplicant.getHrcApplicant();
		if (getBundleType().equals(AUTO_RENTERS_BUNDLE)) {
			AceHRCAddressBasePage hrcPropertyQuestionsPage = navigateToAceHRCPropertyQuestionsPage(bundleApplicant);
			if (isMonoline()) {
				hrcPropertyQuestionsPage.enterAddress(bundleApplicant.getHrcApplicant());
			} else {
				hrcPropertyQuestionsPage.selectNumberOfPropertyLosses(NONE);
			}
			hrcPropertyQuestionsPage.clickContinueButton();
		} else {
			AceHRCAdditionalInfoBasePage hrcAdditionalHomeInformationPage = navigateToAdditionalHomeInformationPage(bundleApplicant);
			hrcAdditionalHomeInformationPage.fillOutAdditionalInfoPageHomeLob(hrcApplicant, false);
			if (hrcApplicant.isNewlyOwned() && !isMonoline()) {
				new AceHRCAboutYouBasePage().enterCurrentOrPriorAddressInBundle(hrcApplicant);
			}
			hrcAdditionalHomeInformationPage.scrollAndClickOnContinueButton();
		}
		waitForSpinnerToBeGone();
		AceHRCAboutYouBasePage hrcAboutYouPage = new AceHRCAboutYouBasePage();
		if (hrcAboutYouPage.isOnAboutYouPageHome(false)) {
			Reporter.pass("Navigated to About you page");
			if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
				FarmersSoftAssert tempFsa = new FarmersSoftAssert();
				hrcAboutYouPage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
				validateAssignedAgentSection(hrcAboutYouPage, tempFsa);
			}
		}
		return hrcAboutYouPage;
	}

	public AceHRCAdditionalInfoBasePage navigateToAdditionalHomeInformationPage(AceBundleApplicant bundleApplicant) throws Exception {
		AceHRCAdditionalInfoBasePage hrcAdditionalInfoPage = new AceHRCAdditionalInfoBasePage();
		if (getResumeFromPage().equals(hrcAdditionalInfoPage.getClass().getSimpleName())) {
			return hrcAdditionalInfoPage;
		}
		ApplicantAceHome hrcApplicant = bundleApplicant.getHrcApplicant();
		AceHRCPropertyDetailsBasePage hrcHeresWhatWeHaveSoFarPage = navigateToAceHRCHeresWhatWeHaveSoFarPage(bundleApplicant);
		hrcHeresWhatWeHaveSoFarPage.enterPropertyDetails(hrcApplicant);
		hrcHeresWhatWeHaveSoFarPage.scrollAndClickOnContinueButton();
		if (hrcAdditionalInfoPage.isOnAdditionalInfoPage()) {
			Reporter.pass("Navigated to Additional Home Information page");
			if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
				FarmersSoftAssert tempFsa = new FarmersSoftAssert();
				hrcAdditionalInfoPage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
				validateAssignedAgentSection(hrcAdditionalInfoPage, tempFsa);
			}
			return hrcAdditionalInfoPage;
		} else {
			throw new NavigationException(hrcAdditionalInfoPage.getClass().getSimpleName(), bundleApplicant);
		}
	}

	public AceHRCPropertyDetailsBasePage navigateToAceHRCHeresWhatWeHaveSoFarPage(AceBundleApplicant bundleApplicant) throws Exception {
		ApplicantAceHome hrcApplicant = bundleApplicant.getHrcApplicant();
		AceHRCPropertyDetailsBasePage hrcHeresWhatWeHaveSoFarPage = new AceHRCPropertyDetailsBasePage();
		if (getResumeFromPage().equals(hrcHeresWhatWeHaveSoFarPage.getClass().getSimpleName())) {
			return hrcHeresWhatWeHaveSoFarPage;
		}
		AceHRCQualityGradeBasePage hrcQualityGradeBasePage = navigateToAceHRCHomeQualityPage(bundleApplicant);
		hrcQualityGradeBasePage.dismissCheckYourCoverageDialog();
		hrcQualityGradeBasePage.fillOutQualityGradePage(hrcApplicant, getSessionStorageAppStore().getHome().getHomeQualityGradeForm());
		if (hrcHeresWhatWeHaveSoFarPage.isOnPropertyDetailsPage()) {
			Reporter.pass("Navigated to Here's what we have so far page");
			if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
				FarmersSoftAssert tempFsa = new FarmersSoftAssert();
				hrcHeresWhatWeHaveSoFarPage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
				validateAssignedAgentSection(hrcHeresWhatWeHaveSoFarPage, tempFsa);
			}
			return hrcHeresWhatWeHaveSoFarPage;
		} else {
			throw new NavigationException(hrcHeresWhatWeHaveSoFarPage.getClass().getSimpleName(), bundleApplicant);
		}
	}

	public AceHRCQualityGradeBasePage navigateToAceHRCHomeQualityPage(AceBundleApplicant bundleApplicant) throws Exception {
		AceHRCQualityGradeBasePage hrcQualityGradePage = new AceHRCQualityGradeBasePage();
		if (getResumeFromPage().equals(hrcQualityGradePage.getClass().getSimpleName())) {
			return hrcQualityGradePage;
		}
		ApplicantAceHome hrcApplicant = bundleApplicant.getHrcApplicant();
		AceHRCAddressBasePage hrcPropertyQuestionsPage = navigateToAceHRCPropertyQuestionsPage(bundleApplicant);
		if (isMonoline()) {
			hrcPropertyQuestionsPage.enterAddress(bundleApplicant.getHrcApplicant());
		}
		hrcPropertyQuestionsPage.enterAvailableFields(bundleApplicant.getHrcApplicant());
		if (hrcPropertyQuestionsPage.clickContinue()) {
			AceHRCPropertyBasePage tellUsMorePage = new AceHRCPropertyBasePage();
			tellUsMorePage.enterPropertyPageFields(hrcApplicant);
			tellUsMorePage.scrollAndClickOnContinueButton();
		}
		if (hrcQualityGradePage.isOnQualityGradePage()) {
			Reporter.pass("Navigated to Quality grade page");
			if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
				FarmersSoftAssert tempFsa = new FarmersSoftAssert();
				hrcQualityGradePage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
			}
			return hrcQualityGradePage;
		} else {
			throw new NavigationException(hrcQualityGradePage.getClass().getSimpleName(), bundleApplicant);
		}
	}

	public AceHRCAddressBasePage navigateToAceHRCPropertyQuestionsPage(AceBundleApplicant bundleApplicant) throws Exception {
		if (isMonoline()) {
			AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
			autoApplicant.setZipCode(bundleApplicant.getHrcApplicant().getZipCode());
			bundleApplicant.setAutoApplicant(autoApplicant);
			launchApplication(bundleApplicant);
			setBundleQuoteNumber(getQuoteNumberFromStorage());
			AceBundleLimitedAvailabilityDialog limitedAvailabilityDialog = new AceBundleLimitedAvailabilityDialog();
			if (limitedAvailabilityDialog.isLimitedAvailabilityDialogDisplayed()) {
				if (limitedAvailabilityDialog.isDefaultMonolineDialog()) {
					limitedAvailabilityDialog.selectYesContinue();
				} else {
					limitedAvailabilityDialog.selectHRCPolicyAndContinue();
				}
				if (!getBundleQuoteNumber().isEmpty()) {
					Reporter.pass("Property monoline quote number " + getBundleQuoteNumber());
					bundleApplicant.getHrcApplicant().setQuoteNumber(getBundleQuoteNumber());
				}
				if (getBundleType().equals(AUTO_HOME_BUNDLE)) {
					AceHRCPropertyTypeBasePage hrcPropertyTypePage = new AceHRCPropertyTypeBasePage();
					if (hrcPropertyTypePage.quickIsOnPropertyTypePageCheck()) {
						hrcPropertyTypePage.selectPropertyType(getPropertyType());
					} else {
						throw new NavigationException(hrcPropertyTypePage.getClass().getSimpleName(), bundleApplicant);
					}
				}
			} else {
				throw new NavigationException(limitedAvailabilityDialog.getClass().getSimpleName(), bundleApplicant);
			}
		} else {
			AceHRCPropertyTypeBasePage hrcPropertyTypePage = navigateToAceHRCPropertyTypePage(bundleApplicant);
			if (getBundleType().equals(AUTO_HOME_BUNDLE)) {
				hrcPropertyTypePage.selectPropertyType(getPropertyType());
			} else if (getBundleType().equals(AUTO_CONDO_BUNDLE)
					&& hrcPropertyTypePage.quickIsOnPropertyTypePageCheck()) {
				// Farmers.com exposes Auto + Home for this composite request. If the
				// application presents the property-type chooser, explicitly continue
				// through the Condo branch instead of defaulting to Home.
				hrcPropertyTypePage.selectPropertyType(CONDO);
			}
		}
		//Repurpose property type to LOB
		setPropertyType(setLOBForMessaging());
		AceHRCAddressBasePage hrcPropertyQuestionsPage = new AceHRCAddressBasePage();
		if (isMonoline() || hrcPropertyQuestionsPage.isOnBundlePropertyQuestionsPage()) {
			if (!isMonoline()) {
				Reporter.pass("Navigated to Property Questions page");
			}
			if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
				FarmersSoftAssert tempFsa = new FarmersSoftAssert();
				hrcPropertyQuestionsPage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
				// this page does not have the assigned agent section
			}
			return hrcPropertyQuestionsPage;
		} else {
			throw new NavigationException(hrcPropertyQuestionsPage.getClass().getSimpleName(), bundleApplicant);
		}
	}

	public AceHRCPropertyTypeBasePage navigateToAceHRCPropertyTypePage(AceBundleApplicant bundleApplicant) throws Exception {
		AceHRCPropertyTypeBasePage hrcPropertyTypePage = new AceHRCPropertyTypeBasePage();
		if (!getResumeFromPage().equals(hrcPropertyTypePage.getClass().getSimpleName())) {
			completeAutoQuoteNavigation(bundleApplicant);
		}
		if (!getBundleType().equals(AUTO_HOME_BUNDLE) || hrcPropertyTypePage.quickIsOnPropertyTypePageCheck()) {
			if (getBundleType().equals(AUTO_HOME_BUNDLE)) {
				Reporter.pass("Navigated to Property Type page");
			}
			if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
				hrcPropertyTypePage.validateTFNIsNotDisplayedInAgentFlow(new FarmersSoftAssert());
			}
			return hrcPropertyTypePage;
		} else {
			throw new NavigationException(hrcPropertyTypePage.getClass().getSimpleName(), bundleApplicant);
		}
	}

	// Auto side of bundle process
	public void completeAutoQuoteNavigation(AceBundleApplicant bundleApplicant) throws Exception {
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		if (!Arrays.asList(BUNDLE_QUOTE_SUMMARY_PAGE, CONTACT_INFO_PAGE).contains(getResumeFromPage())) {
			ContactInfoAutoPage contactInfoAutoPage = navigateToPolicyStartDatePage(bundleApplicant);
			contactInfoAutoPage.enterValuesForBundleAutoQuoteAndContinue(autoApplicant);
			waitForSpinnerToBeGone();
			if (hasCompletedAutoQuoteNavigation()) {
				return;
			}
		}
		ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
		if (continueWithBristolWestPage.isOnContinueWithBristolWestPage(10)) {
			continueWithBristolWestPage.continueWithBwPopUp();
		}
		if (hasCompletedAutoQuoteNavigation()) {
			return;
		}
		BristolWestAdditionalDiscountsPage bristolWestAdditionalDiscountsPage = new BristolWestAdditionalDiscountsPage();
		if (bristolWestAdditionalDiscountsPage.isOnBristolWestAdditionalDiscountsPage()) {
			bristolWestAdditionalDiscountsPage.clickContinue();
		}
		if (hasCompletedAutoQuoteNavigation()) {
			return;
		}
		VehicleDriverAssignmentPage vehicleDriverAssignmentPage = new VehicleDriverAssignmentPage();
		if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
			vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
			waitForSpinnerToBeGone();
			new ContactInfoAutoPage().waitForRC2ScreenToFinish();
			if (vehicleDriverAssignmentPage.isOnVehicleDriverAssignmentPage()) {
				vehicleDriverAssignmentPage.assignDriversForVehiclesRandomlyAndSave();
				waitForSpinnerToBeGone();
			}
		}
		if (hasCompletedAutoQuoteNavigation()) {
			return;
		}
		BwFarmersQuotePresentmentPage chooseFarmersOrBWQuotePage = new BwFarmersQuotePresentmentPage();
		if (chooseFarmersOrBWQuotePage.quickIsOnBwFarmersQuotePresentmentPage()) {
			// We may want to change this to something else, but for now use testScenario
			if (autoApplicant.getTestScenario().contains("BW")) {
				chooseFarmersOrBWQuotePage.continueWithBw();
			} else {
				chooseFarmersOrBWQuotePage.continueWithFarmers();
			}
			waitForSpinnerToBeGone();
		}
		if (new KnockoutInconveniencePage().isQuoteKnockedOut()) {
			if (getResumeFromPage().equals(CONTACT_INFO_PAGE)) {
				//Reset attempt failed, still getting knocked out
				throw new NavigationException("Auto quote rate: Reset attempt failed", bundleApplicant);
			} else {
				//Reset page in an attempt to clear issue
				Log.warn("Auto quote portion possibly knocked out, attempt to correct issue");
				String hostName = new URL(Property.getUri()).getHost();
				navigate("https://" + hostName + "/quote/auto/contact-info");
				waitForSpinnerToBeGone();
				new ContactInfoAutoPage().clickContactInfoPageCTAButton();
				setResumeFromPage(CONTACT_INFO_PAGE);
				completeAutoQuoteNavigation(bundleApplicant);
			}
		}
	}

	private boolean hasCompletedAutoQuoteNavigation() throws Exception {
		boolean quoteCompleted = false;
		if (!isMonoline()) {
			new ContactInfoAutoPage().waitForRC2ScreenToFinish();
			if (new AceBundleReviewQuotesPage().isOnBundleReviewQuotesPage() // for when bundle started with property
					|| new AceHRCPropertyTypeBasePage().quickIsOnPropertyTypePageCheck() || new AceHRCAddressBasePage().isOnBundlePropertyQuestionsPage()) {
				quoteCompleted = true;
			}
		}
		return quoteCompleted;
	}

	public ContactInfoAutoPage navigateToPolicyStartDatePage(AceBundleApplicant bundleApplicant) throws Exception {
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		SignalPageOneUI signalPage = navigateToSignalPage(bundleApplicant);
		List<SqlDiscount> applicantDiscounts = autoApplicant.getDiscounts();
		if (isSignalState(autoApplicant.getStateCode())) {
			if (applicantDiscounts.isEmpty()) {
				signalPage.processSignalPage(false);
			} else {
				signalPage.processSignalPage(applicantDiscounts.get(0).isSignalSignup());
			}
			waitForSpinnerToBeGone();
		}
		ContactInfoAutoPage contactInfoAutoPage = new ContactInfoAutoPage();
		if (!isSignalState(autoApplicant.getStateCode()) && contactInfoAutoPage.isOnOtherAutoPolicyDetailsPage()) {
			Reporter.pass("Navigated to Other Auto Policy Details page");
		} else if (contactInfoAutoPage.isOnBundlePolicyStartDatePage()) {
			Reporter.pass("Navigated to Policy Start Date page");
		} else {
			throw new NavigationException(contactInfoAutoPage.getClass().getSimpleName(), bundleApplicant);
		}
		if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
			FarmersSoftAssert tempFsa = new FarmersSoftAssert();
			contactInfoAutoPage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
			validateAssignedAgentSection(contactInfoAutoPage, tempFsa);
		}
		return contactInfoAutoPage;
	}

	public SignalPageOneUI navigateToSignalPage(AceBundleApplicant bundleApplicant) throws Exception {
		SignalPageOneUI signalPage = new SignalPageOneUI();
		if (getResumeFromPage().equals(signalPage.getClass().getSimpleName())) {
			return signalPage;
		}
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		DriverReviewPage driverReviewPage = navigateToDriverReviewPage(bundleApplicant);
		if (!isVehiclesDriversConsolidationImpl(autoApplicant.getStateCode())) {
			driverReviewPage.reviewAllDrivers(autoApplicant, Optional.empty());
		}
		driverReviewPage.clickContinueButton();
		waitForSpinnerToBeGone();
		if (isSignalState(autoApplicant.getStateCode())) {
			if (signalPage.isOnSignalPage()) {
				Reporter.pass("Navigated to Signal page");
				if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
					FarmersSoftAssert tempFsa = new FarmersSoftAssert();
					signalPage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
					validateAssignedAgentSection(signalPage, tempFsa);
				}
				return signalPage;
			} else {
				throw new NavigationException(signalPage.getClass().getSimpleName(), bundleApplicant);
			}
		} else {
			return signalPage;
		}
	}

	private boolean isSignalState(String stateCode) {
		return !Arrays.asList(CA, CT, MA).contains(stateCode);
	}

	public DriverReviewPage navigateToDriverReviewPage(AceBundleApplicant bundleApplicant) throws Exception {
		VehicleReviewPage vehicleReviewPage = navigateToVehicleReviewPage(bundleApplicant);
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		if (isVehiclesDriversConsolidationImpl(autoApplicant.getStateCode())) {
			return new DriverReviewPage();
		}
		vehicleReviewPage.addVehicleDetails(autoApplicant);
		vehicleReviewPage.setVehicleUsagesToPersonal();
		vehicleReviewPage.clickOnContinueButton();
		if (areElementsDisplayed(locators(pwXPath(vehicleReviewPage.getCTA_ERROR_MESSAGE_XPATH())), 2)) {
			vehicleReviewPage.setGarageAddressesToDefault();
			if (isSafariBrowser() || autoApplicant.getStateCode().equals(CA)) {
				vehicleReviewPage.setVehicleUsagesToPersonal();
			}
			vehicleReviewPage.clickOnContinueButton();
		}
		DriverReviewPage driverReviewPage = new DriverReviewPage();
		if (driverReviewPage.isOnDriverReviewPage()) {
			Reporter.pass("Navigated to Drivers review page");
			if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
				FarmersSoftAssert tempFsa = new FarmersSoftAssert();
				driverReviewPage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
				validateAssignedAgentSection(driverReviewPage, tempFsa);
			}
			return driverReviewPage;
		} else {
			throw new NavigationException(driverReviewPage.getClass().getSimpleName(), bundleApplicant);
		}
	}

    public VehicleReviewPage navigateToVehicleReviewPage(AceBundleApplicant bundleApplicant) throws Exception {
        AutoApplicant applicant = bundleApplicant.getAutoApplicant();
        Object autoPage = navigateToWhoShouldWeInsurePage(bundleApplicant);
        if (autoPage.getClass().getSimpleName().equals("WhoShouldWeInsurePage")) {
            WhoShouldWeInsurePage whoShouldWeInsurePage = WhoShouldWeInsurePage.class.cast(autoPage);
            if (isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
                Reporter.pass("Navigated to Vehicles And Drivers Review page");
                VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
                vehiclesDriversInfoPage.addVehiclesWhenNoneFound(applicant);
                vehiclesDriversInfoPage.addDriversWhenNoneFound(applicant);
                if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
                    FarmersSoftAssert tempFsa = new FarmersSoftAssert();
                    vehiclesDriversInfoPage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
                    validateAssignedAgentSection(vehiclesDriversInfoPage, tempFsa);
                }
                vehiclesDriversInfoPage.clickOnDoneAddingDriversButton();
                vehiclesDriversInfoPage.clickContinueButton();
                return new VehicleReviewPage();
            } else {
                whoShouldWeInsurePage.addVehiclesWhenNoneAreFound(applicant);
                whoShouldWeInsurePage.addDriversWhenNoneAreFound(applicant);
                whoShouldWeInsurePage.enterEmailAndPhoneNumber(applicant);
                whoShouldWeInsurePage.clickOnContinueButton();
            }
        } else {
            HeresWhatWeFoundPage heresWhatWeFoundPage = HeresWhatWeFoundPage.class.cast(autoPage);
            if (isVehiclesDriversConsolidationImpl(applicant.getStateCode())) {
                Reporter.pass("Navigated to Vehicles And Drivers Review page");
                VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
                vehiclesDriversInfoPage.selectAndEditDefaultAdpfVehicles();
                vehiclesDriversInfoPage.selectAndEditDefaultAdpfDrivers(List.of(applicant.getFinancialFiling(), applicant.getCurrentlyInsuredStatus()));
                if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
                    FarmersSoftAssert tempFsa = new FarmersSoftAssert();
                    validateAssignedAgentSection(vehiclesDriversInfoPage, tempFsa);
                    vehiclesDriversInfoPage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
                }
                vehiclesDriversInfoPage.clickContinueButton();
                return new VehicleReviewPage();
            } else {
                String fullName = applicant.getFirstName() + SPACE + applicant.getLastName();
                if (heresWhatWeFoundPage.getListOfCheckedVehicles().isEmpty()) {
                    String randomVIN = heresWhatWeFoundPage.getRandomVinNumber(2);
                    if (randomVIN.isEmpty()) {
                        randomVIN = applicant.getVehicles().get(FIRST_AVAILABLE_OPTION).getVehicleVIN();
                    }
                    heresWhatWeFoundPage.addRandomNewVehicle(randomVIN);
                }
                heresWhatWeFoundPage.addVehiclesWhenNoneAreFound(applicant);
                heresWhatWeFoundPage.addADPFApplicant(Optional.of(applicant), fullName, applicant.getGender(), applicant.getDateOfBirth());
                heresWhatWeFoundPage.addAdditionalDrivers(applicant);
                heresWhatWeFoundPage.clickOnDoneAddingDriversButton();
                int vehicleCountFromDataProvider = applicant.getVehicles().size();
                if (vehicleCountFromDataProvider == 1) {
                    heresWhatWeFoundPage.uncheckVehiclesOnlyForOne();
                }
                heresWhatWeFoundPage.excludeDriversEqualOrLessThan15();
                heresWhatWeFoundPage.limitCheckedDriversToMaxAllowed();
                heresWhatWeFoundPage.clickContinueButton();
            }
        }
        VehicleReviewPage vehicleReviewPage = new VehicleReviewPage();
        vehicleReviewPage.waitForSpinnerToBeGone();
        if (vehicleReviewPage.isOnVehiclesReviewPage()) {
            Reporter.pass("Navigated to Vehicles Review page");
            if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
                FarmersSoftAssert tempFsa = new FarmersSoftAssert();
                vehicleReviewPage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
                validateAssignedAgentSection(vehicleReviewPage, tempFsa);
            }
            return vehicleReviewPage;
        } else {
            throw new NavigationException(vehicleReviewPage.getClass().getSimpleName(), bundleApplicant);
        }
    }
	@SuppressWarnings(UNCHECKED)
	public <T extends AutoBasePage> T navigateToWhoShouldWeInsurePage(AceBundleApplicant bundleApplicant) throws Exception {
		WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
		if (!getResumeFromPage().equals(whoShouldWeInsurePage.getClass().getSimpleName())) {
			NameAndDobPage letsBeginNameAndDobPage = navigateToAutoLetsBeginPage(bundleApplicant);
			AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
			AutoEnterAddressPage addressPage = new AutoEnterAddressPage();
			addressPage.dismissMovingIntoBundleDialog();
			letsBeginNameAndDobPage.enterFirstNameLastNameDOB(autoApplicant.getFirstName(), autoApplicant.getLastName(), autoApplicant.getDateOfBirth());
			if (isMonoline() || !addressPage.addressFieldsAreActive()) {
				letsBeginNameAndDobPage.clickContinueButton();
				waitForSpinnerToBeGone();
			}
			addressPage.fillOutEmailAndPhoneIfPresent(autoApplicant.getEmail(), autoApplicant.getPhoneNumber());
			addressPage.enterAddress(autoApplicant.getResidentAddress(), autoApplicant.getCity(), autoApplicant.getStateCode().equals(MA));
		}
		HeresWhatWeFoundPage heresWhatWeFoundPage = new HeresWhatWeFoundPage();
		if (whoShouldWeInsurePage.isOnWhoShouldWeInsurePageShort()) {
			Reporter.pass("Navigated to Auto Who should we insure page");
			if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
				whoShouldWeInsurePage.validateTFNIsNotDisplayedInAgentFlow(new FarmersSoftAssert());
			}
			return (T) whoShouldWeInsurePage;
		} else if(heresWhatWeFoundPage.isOnHeresWhatWeFoundPageShort()){
			Reporter.pass("Navigated to Auto Here is what we found page");
			if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
				FarmersSoftAssert tempFsa = new FarmersSoftAssert();
				heresWhatWeFoundPage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
				validateAssignedAgentSection(heresWhatWeFoundPage, tempFsa);
			}
			return (T) heresWhatWeFoundPage;
		} else {
			throw new NavigationException(DID_NOT_REACH + whoShouldWeInsurePage.getClass().getSimpleName() + " for quote " + getBundleQuoteNumber(), bundleApplicant);
		}
	}

	public NameAndDobPage navigateToAutoLetsBeginPage(AceBundleApplicant bundleApplicant) throws Exception {
		NameAndDobPage letsBeginNameAndDobPage = new NameAndDobPage();
		if (!getResumeFromPage().equals(letsBeginNameAndDobPage.getClass().getSimpleName())) {
			launchApplication(bundleApplicant);
			if (isMonoline()) {
				AceBundleLimitedAvailabilityDialog limitedAvailabilityDialog = new AceBundleLimitedAvailabilityDialog();
				if (limitedAvailabilityDialog.isLimitedAvailabilityDialogDisplayed()) {
					if (limitedAvailabilityDialog.isDefaultMonolineDialog()) {
						limitedAvailabilityDialog.selectYesContinue();
					} else {
						limitedAvailabilityDialog.selectAutoPolicyAndContinue();
					}
					//For states like MA that directly navigate to a continue with BW page
					ContinueWithBristolWestPage continueWithBristolWestPage = new ContinueWithBristolWestPage();
					if (continueWithBristolWestPage.isOnGetAQuoteFromBristolWestPage()) {
						continueWithBristolWestPage.continueWithBWPage(true);
					}
				} else {
					setBundleQuoteNumber(getQuoteNumberFromStorage());
					throw new NavigationException(limitedAvailabilityDialog.getClass().getSimpleName(), bundleApplicant);
				}
			}
		}
		setBundleQuoteNumber(getQuoteNumberFromStorage());
		bundleApplicant.getHrcApplicant().setQuoteNumber(getBundleQuoteNumber());
		if (letsBeginNameAndDobPage.isOnNameAndDobPage()) {
			writeCreatedQuoteInformationToFile(getBundleType() + SPACE + getBundleQuoteNumber() + SPACE + bundleApplicant);
			Reporter.pass("Navigated to Auto Let's begin page for quote "+  getBundleQuoteNumber());
			if (bundleApplicant.getAutoApplicant().getTestCategory().equals(AWS_SCENARIOS)) {
				FarmersSoftAssert tempFsa = new FarmersSoftAssert();
				letsBeginNameAndDobPage.validateTFNIsNotDisplayedInAgentFlow(tempFsa);
				validateAssignedAgentSection(letsBeginNameAndDobPage, tempFsa);
			}
			return letsBeginNameAndDobPage;
		} else {
			throw new NavigationException(letsBeginNameAndDobPage.getClass().getSimpleName(), bundleApplicant);
		}
	}

	public void navigateToSpeakToRepresentative(AceBundleApplicant bundleApplicant) throws Exception {
		AceBundleLimitedAvailabilityDialog limitedAvailabilityDialog = navigateToLimitedAvailabilityDialog(bundleApplicant);
		if (limitedAvailabilityDialog.isDefaultMonolineDialog()) {
			limitedAvailabilityDialog.selectNoThanks();
		} else {
			limitedAvailabilityDialog.selectNeitherAndContinue();
		}
	}

	public AceBundleLimitedAvailabilityDialog navigateToLimitedAvailabilityDialog(AceBundleApplicant bundleApplicant) throws Exception {
		launchApplication(bundleApplicant);
		AceBundleLimitedAvailabilityDialog limitedAvailabilityDialog = new AceBundleLimitedAvailabilityDialog();
		if (limitedAvailabilityDialog.isLimitedAvailabilityDialogDisplayed()) {
			Reporter.pass("Navigated to limited availability dialog");
			return limitedAvailabilityDialog;
		} else {
			setBundleQuoteNumber(getQuoteNumberFromStorage());
			throw new NavigationException(limitedAvailabilityDialog.getClass().getSimpleName(), bundleApplicant);
		}
	}

	public void navigateToRestricted(AceBundleApplicant bundleApplicant) throws Exception{
		launchApplication(bundleApplicant);
	}

	private void launchApplication(AceBundleApplicant bundleApplicant) throws Exception {
		AutoApplicant autoApplicant = bundleApplicant.getAutoApplicant();
		if (autoApplicant.getTestCategory().equals(AWS_SCENARIOS)) {
			if (getBundleType().equals(AUTO_HOME_BUNDLE)) {
				autoApplicant.setTestScenario("AutoHome");
			} else {
				autoApplicant.setTestScenario("AutoRenters");
			}
			bundleApplicant.setAutoApplicant(autoApplicant);
			new LandingPage(bundleApplicant);
			Reporter.pass("Application launched in AWS mode");
			waitForSpinnerToBeGone();
		} else {
			LandingPage landingPage = new LandingPage(isUseMobileViewEnabled(), true);
			if (getResumeFromPage().equals("interstitial")) {
				landingPage.enterLandingPageDataAndContinue(LOB_AUTO, autoApplicant.getZipCode());
				InterstitialBundlePage interstitialBundlePage = new InterstitialBundlePage();
				if (interstitialBundlePage.isOnInterstitialBundlePage()) {
					interstitialBundlePage.continueWithBundle();
					waitForSpinnerToBeGone();
				} else {
					throw new NavigationException(interstitialBundlePage.getClass().getSimpleName(), bundleApplicant);
				}
			} else if (List.of(LOB_HOME, LOB_RENTERS).contains(getResumeFromPage())) {
				// CA is the model, property quotes get transformed into bundles.
				landingPage.enterLandingPageDataAndContinue(getResumeFromPage(), autoApplicant.getZipCode());
			} else {
				landingPage.enterLandingPageDataAndContinue(getBundleType(), autoApplicant.getZipCode());
			}
		}
	}

	private String getQuoteNumberFromStorage() throws Exception {
		String quoteNumber = EMPTY_STRING;
		if (getItemFromSessionStorage("appStore") != null) {
			quoteNumber = getSessionStorageAppStore().getData().getQuoteNumber();
		}
		if (quoteNumber==null) {
			quoteNumber = EMPTY_STRING;
		}
		return quoteNumber;
	}

	private String setLOBForMessaging() {
		switch (getBundleType()) {
			case AUTO_CONDO_BUNDLE:
				return CONDO;
			case AUTO_HOME_BUNDLE:
				return HOME;
			case AUTO_RENTERS_BUNDLE:
				return RENTERS;
			default:
				return getPropertyType();
		}
	}

	public static synchronized void saveBundleQuoteDataForRetrieval(AceBundleApplicant bundleApplicant, String pageLeftOn, String quoteNumber) {
		ApplicantRetQuote returnQuoteData = new ApplicantRetQuote();
		AutoApplicant applicant = bundleApplicant.getAutoApplicant();
		returnQuoteData.setLastName(applicant.getLastName());
		returnQuoteData.setAge(applicant.getAge());
		returnQuoteData.setZipCode(applicant.getZipCode());
		returnQuoteData.setEmailAddress(applicant.getEmail());
		returnQuoteData.setQuoteNumber(quoteNumber);
		returnQuoteData.setPageLeftOn(pageLeftOn);
		returningQuoteConcurrentHashMap.put(applicant.getLastName() + applicant.getZipCode() + quoteNumber, returnQuoteData);
		Log.info("Successfully saved data model object: " + returnQuoteData);
	}

	public boolean retrieveAceBundleQuote(AceBundleApplicant bundleApplicant, String quoteNumber) throws Exception {
		boolean quoteRetrieved = false;
		AutoApplicant applicant = bundleApplicant.getAutoApplicant();
		LandingPage ffqLandingPage = new LandingPage(isUseMobileViewEnabled());
		ffqLandingPage.retrieveQuoteFromLandingPage(applicant.getLastName(), applicant.getDateOfBirth(), quoteNumber, applicant.getZipCode());
		if (ffqLandingPage.isQuoteNotFoundPopUpPresent()) {
			Reporter.fail("Unable to retrieve quote " + quoteNumber);
		} else {
			Reporter.pass("Retrieved quote " + quoteNumber);
			quoteRetrieved = true;
		}
		return quoteRetrieved;
	}

	//DE285581 - Temporarily disable consolidated vehicle/driver page check for BDQ
	private boolean isVehiclesDriversConsolidationImpl(String stateCode) throws Exception {
		return List.of(AR, AZ, CO, ID, IL, IN, MI, MN, MO, NM, OH, OK, OR, TN, VA, WA).contains(stateCode);
	}

	private class NavigationException extends Exception {
		private static final long serialVersionUID = 1L;

		@SuppressWarnings("finally")
		public NavigationException(String originatingPage, AceBundleApplicant bundleApplicant) {
			String message = DID_NOT_REACH + originatingPage;
			try {
				if (new KnockoutInconveniencePage().isQuoteKnockedOut()) {
					String errorDetailString = "unknown";
					AppStore.Error error = getSessionStorageAppStore().getError();
					if (error != null) {
						StringBuilder errorMessageString = new StringBuilder();
						if (error.getErrorInfo() != null) {
							if (error.getErrorInfo().getErrorCode() != null) {
								errorMessageString.append("errorCode=" + error.getErrorInfo().getErrorCode() + SPACE);
							}
							if (error.getErrorInfo().getErrorMessage() != null) {
								errorMessageString.append("errorInfoMessage=" + error.getErrorInfo().getErrorMessage() + SPACE);
							}
						}
						if (error.getMessage()!= null) {
							errorMessageString.append("errorMessage=" + error.getMessage() + SPACE);
						}
						if (error.getServiceName()!= null) {
							errorMessageString.append("errorServiceName=" + error.getServiceName() + SPACE);
						}
						if (error.getStatus()!= null) {
							errorMessageString.append("errorStatus=" + error.getStatus() + SPACE);
						}
						if (!errorMessageString.toString().isEmpty()) {
							errorDetailString = errorMessageString.toString();
						}
					}
					message = message + " -- Knocked out reason: " + errorDetailString;
				}
				writeDataToKnockoutLogFile(getBundleType() + SPACE + getBundleQuoteNumber() + SPACE + bundleApplicant + " - " + message);
			} catch (Exception e) {
				Log.error("Exception encountered, reason: " + e);
			} finally {
				throw new IllegalStateException(message);
			}
		}
	}

	public void navigateToBundleQuoteReviewPageUsingDefaults() throws Exception {
		// This method tries to reach bundle review quote page by clicking continue/agree & submit on the current page to navigate to the next one
		// The assumption is that all fields on the page have been previously filled.
		AceBundleReviewQuotesPage bundleQuoteReviewPage = new AceBundleReviewQuotesPage();
		QuoteSummaryAutoPage autoQuoteSummarPage = new QuoteSummaryAutoPage();
		KnockoutInconveniencePage koPage = new KnockoutInconveniencePage();
		AceHRCPropertyTypeBasePage hrcPropertyTypePage = new AceHRCPropertyTypeBasePage();
		int maxPages = 12; // anything more and we're probably in a loop
		while (maxPages>0 && !bundleQuoteReviewPage.isOnBundleReviewQuotesPage() && !koPage.isQuoteKnockedOut()	&& !autoQuoteSummarPage.notAbleToOfferBundle()) {
			BasePage basePage = new BasePage();
			if (isElementVisible(buttonContinue, 2)) {
				basePage.clickContinueButton();
			} else if (hrcPropertyTypePage.quickIsOnPropertyTypePageCheck()) {
				hrcPropertyTypePage.selectPropertyType(getPropertyType());
			}
			waitForSpinnerToBeGone();
			maxPages--;
		}
		if (bundleQuoteReviewPage.isOnBundleReviewQuotesPage()) {
			Reporter.pass("Navigated to Bundle Quote Summary page");
		} else if (autoQuoteSummarPage.notAbleToOfferBundle()) {
			Log.warn("Bundling not available for " + getBundleQuoteNumber() + ", skipping test", true);
			throw new SkipException("Bundling not available for " + getBundleQuoteNumber() + " , skipping test");
		} else {
			throw new IllegalStateException("Unable to reach Bundle Quote Summary page");
		}
	}
}
