package com.farmers.ffq.auto.pages;






import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class AutoCallForQuotePage extends AutoBasePage {


        private Locator callForAQuotePageTitle = locatorAny(pwXPath("//span[@class='h1-alt1']"), pwXPath("//span[@class='h1-alt2']"));
        private Locator letsGetStartedText = locator(pwXPath("//span[contains(.,'get started')]"));
        private Locator pageDescription = locator(pwCss("span[class='p-style']"));
        private Locator quickAndEasy = locator(pwXPath("//span[@class='font-blue']//span[@class='h4-alt1']"));
        private Locator farmersImage = locator(pwXPath("//img[contains(@src,'auto-landing')]"));
        private Locator tileSectionImages = locator(pwXPath("//div[contains(@class,'tile tile--one-col col-12 mt-3 mb-1')]//img"));
        private Locator tileSectionTexts = locator(pwXPath("//div[contains(@class,'tile tile--one-col col-12 mt-3 mb-1')]//section"));
        private Locator noteSectionText = locator(pwXPath("//p[contains(.,'NOTE')]"));
        private Locator savingPercentageNote = locator(pwXPath("//span[contains(.,'*')]"));
        private Locator disclaimers = locator(pwXPath("//div[@class='footernav__notes-section row pt-3 pb-5']"));

    public AutoCallForQuotePage() throws Exception {
    }

    public boolean isOnCallForQuotePage() {
        return isElementVisible(callForAQuotePageTitle, 10);
    }

    public void validateCallForAQuotePage(FarmersSoftAssert fsa) throws Exception {
        fsa.assertEquals(getTextFromElement(callForAQuotePageTitle), "Call for your quote", "FWS page title validated");
        fsa.assertEquals(getTextFromElement(letsGetStartedText), "Let's get started!", "Let's get started text validated");
        fsa.assertEquals(getTextFromElement(pageDescription), "If you'd like to continue your quote and see how much you could save, please give us a call.", "Page description text validated");
//        fsa.assertEquals(getTextFromElement(quickAndEasy), "It's quick and easy to start saving today.", "Farmers GroupSelect Quikc and Easy title validated");
//        fsa.assertTrue(isElementDisplayed(farmersImage,1),  "Farmers image is displayed");
//        fsa.assertTrue(tileSectionImages.count() == 3, "There should be three images in the bullet points");
//        List<String> expectedBulletPointTexts = new ArrayList<>(Arrays.asList("Others have saved 23%* on average by switching their auto insurance", "String bundling policies, you could save even more", "Get special employee or association member discounts"));
//        for (int i = 0; i < tileSectionTexts.count(); i++) {
//            String actualText = getTextFromElement(tileSectionTexts.nth(i));
//            String expectedText = expectedBulletPointTexts.get(i);
//            fsa.assertEquals(actualText, expectedText, "tile texts are not matching");
//        }
//
//        fsa.assertTrue(isElementPresent(pwXPath("//span[contains(.,'Get your quote to find out how much you can save.')]")), "Get your quote to find out ... text should be present");
//        String callButtonMobileAdjustment = isUseMobileViewEnabled() ? "mobile" : "desktop";
//        Locator callButton = locator(pwXPath(String.format("//a[contains(@class,' button-cta button-cta--%s') and Conditions.not(contains(.,'rather'))]", callButtonMobileAdjustment)));
//        fsa.assertTrue(isElementVisible(callButton,1), "Call Button is visible");
//        fsa.assertEquals(getTextFromElement(noteSectionText), "NOTE: The employee/affinity member discounts are only available by calling Farmers GroupSelect at the number indicated above.", "Note section text validated");
//        fsa.assertEquals(getTextFromElement(savingPercentageNote), "*Savings based on the average nationwide annual savings in 2022 reported by new customers who called the Farmers GroupSelect employee and affinity member call center, switched their auto insurance to Farmers® branded auto insurance policies issued the Farmers GroupSelect employee or affinity member program, and realized savings. Potential savings vary by customer and may vary by state and product. Statistics do not reflect sales of products sold on Agent360SM.", "Saving percentage text validated");
//        fsa.assertTrue(isElementVisible(disclaimers, 1), "Page disclaimer section is present");
    }
}
