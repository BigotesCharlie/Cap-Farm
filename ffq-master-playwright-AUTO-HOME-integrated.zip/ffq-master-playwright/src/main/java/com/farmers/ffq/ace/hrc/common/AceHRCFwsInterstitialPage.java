package com.farmers.ffq.ace.hrc.common;



import com.microsoft.playwright.Page;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.utils.FarmersSoftAssert;
import static com.farmers.ffq.utils.GlobalVariables.*;

public class AceHRCFwsInterstitialPage extends AceHRCBasePage {

    private static final String FWS_INTERSTITIAL_PAGE_TITLE_TEXT = "You're eligible for special discounts!";
    private static final String FWS_INTERSTITIAL_PAGE_CONTENT = "Complete your quote online on our Farmers Insurance Choice site to apply your eligible discounts.";
    private static final String FWS_REPRESENTATIVE_CONTACT_INFO = "Or speak with a representative at 866-586-6048";
    private static final String FWS_INTERSTITIAL_COLP_PAGE_CONTENT = "Give us a quick call" + SEPARATOR + "to take advantage of this offer." + SEPARATOR + "Call 833-895-9822";
    private static final String FWS_DIALOG_CONTAINER_CONTENT = "String clicking \"Agree and continue\", I expressly authorize Farmers Insurance\u00ae to share my information with Farmers General Insurance Agency, Inc. (FGIA) and its affiliates for the purpose of generating insurance quotes.";
    private static final String FWS_INTERSTITIAL_QNB_PAGE_CONTENT = "To apply your special discounts, click the \"get my quote\" button " +
            "to complete your quote online on our Farmers Insurance Group Quote site." + SEPARATOR +
            "Or call 855-793-0094 to speak with a licensed representative and complete your quote by phone.";
        private Locator fwsInterstitialPageTitle = locator(pwXPath("//app-fws-eligibility//h1"));
        private Locator farmersChoicePageContent = locator(pwXPath("//app-fws-eligibility//span[contains(text(), 'Farmers Insurance Choice')]"));
        private Locator fwsInterstitialGroupQuoteContent = locator(pwXPath("//app-fws-eligibility//span[contains(text(), 'Farmers Insurance Group Quote site')]"));
        private Locator fwsRepresentativeContactNumber = locator(pwXPath("//app-fws-eligibility//p[contains(@class,'fws-card-content')]"));
        private Locator applyDiscountsButton = locator(pwXPath("//app-fws-eligibility//button[text()='Apply Discounts']"));
        private Locator fwsInterstitialDialogContainerTitle = locator(pwXPath("//mat-dialog-container/div[contains(@class,'mat-dialog-title')]"));
        private Locator fwsInterstitialDialogContainerContent = locator(pwXPath("//mat-dialog-container/mat-dialog-content[contains(@class,'mat-dialog-content')]"));
        private Locator fwsDialogContainerAgreeButton = locator(pwXPath("//mat-dialog-container//button[contains(@class, 'consent-dialog-agree-button')]"));
        private Locator fwsDialogContainerContinueWithoutDataButton = locator(pwXPath("//mat-dialog-container//button[contains(@class, 'consent-dialog-cwd-button')]"));
        private Locator continueWithoutDiscountLink = locator(pwXPath("//app-fws-eligibility//p[contains(@class,'without-discount-button')]/button"));
        private Locator selectedInsuranceType = locator(pwXPath("//span[@class='selected-indicator']/preceding-sibling::span"));
    private static final String FWS_INTERSTITIAL_PAGE_CARD_CONTENT_XPATH = "//app-fws-eligibility//div[contains(@class,'fws-card')]";
        private Locator fwsInterstitialPageContent = locator(pwXPath(FWS_INTERSTITIAL_PAGE_CARD_CONTENT_XPATH));
        private Locator fwsColpCallButton = locator(pwXPath(FWS_INTERSTITIAL_PAGE_CARD_CONTENT_XPATH + "//button"));
        private Locator fwsGetMyQuoteButton = locator(pwXPath(FWS_INTERSTITIAL_PAGE_CARD_CONTENT_XPATH + "//span[@class = 'get_my_quote_text']"));
        private Locator qnbPageHeader = locator(pwXPath("//div[contains(@class, 'qnbContent')]//h1"));
    private static final String FWS_COLP_PAGE_SUBTITLE_XPATH = "//app-fws-eligibility//h5";
        private Locator fwsPageSubtitle = locator(pwXPath(FWS_COLP_PAGE_SUBTITLE_XPATH));
        private Locator fwsPageDynamicContent = locator(pwXPath(FWS_COLP_PAGE_SUBTITLE_XPATH + "/b"));

    /**
     * Constructor.
     *
     * @throws Exception
     */
    public AceHRCFwsInterstitialPage() throws Exception {
    }

    public void validateFwsFarmersChoicePage(FarmersSoftAssert fsa) {
    	waitForPageToBeReady();
        fsa.assertEquals(getTextFromElement(fwsInterstitialPageTitle), FWS_INTERSTITIAL_PAGE_TITLE_TEXT, "FWS Interstitial page - Page title is not as expected.");
        String dynamicContent = getTextFromElement(fwsPageDynamicContent);
        fsa.assertEquals(getTextFromElement(fwsPageSubtitle), String.format("As part of %s, you could save hundreds!", dynamicContent), "FWS Interstitial - Farmers choice page subtitle is not as expected.");
        fsa.assertEquals(getTextFromElement(farmersChoicePageContent), FWS_INTERSTITIAL_PAGE_CONTENT, "FWS Interstitial page - Farmers insurance choice content is not as expected.");
        fsa.assertEquals(getTextFromElement(fwsRepresentativeContactNumber), FWS_REPRESENTATIVE_CONTACT_INFO, "FWS Interstitial page - Representative contact info is not as expected.");
        fsa.assertTrue(isElementVisible(applyDiscountsButton, 5), "FWS Interstitial page - Apply discounts button is not visible.");
        fsa.assertTrue(isElementVisible(continueWithoutDiscountLink, 5), "FWS Interstitial page - Continue without discount link is not visible.");
    }

    public void validateFWSInterstitialDialogContent(FarmersSoftAssert fsa) {
        fsa.assertTrue(isElementVisible(fwsInterstitialDialogContainerTitle, 5), "FWS Interstitial page - Consent dialog title is not visible.");
        fsa.assertEquals(getTextFromElement(fwsInterstitialDialogContainerContent), FWS_DIALOG_CONTAINER_CONTENT, "FWS Interstitial page - Consent dialog content is not as expected.");
        fsa.assertTrue(isElementVisible(fwsDialogContainerAgreeButton, 3), "FWS Interstitial page - Consent dialog Agree and continue button is not visible.");
        fsa.assertTrue(isElementVisible(fwsDialogContainerContinueWithoutDataButton, 3), "FWS Interstitial page - Consent dialog Continue without data button is not visible.");
    }

    public void validateFwsColpPage(FarmersSoftAssert fsa) {
    	waitForPageToBeReady();
        fsa.assertEquals(getTextFromElement(fwsInterstitialPageTitle), FWS_INTERSTITIAL_PAGE_TITLE_TEXT, "FWS Interstitial - COLP page title is not as expected.");
        String dynamicContent = getTextFromElement(fwsPageDynamicContent);
        fsa.assertEquals(getTextFromElement(fwsPageSubtitle), String.format("As part of %s, you could save hundreds!", dynamicContent), "FWS Interstitial - COLP page subtitle is not as expected.");
        fsa.assertEquals(getTextFromElement(fwsInterstitialPageContent), FWS_INTERSTITIAL_COLP_PAGE_CONTENT, "FWS Interstitial - COLP page content is not as expected.");
        fsa.assertTrue(isElementVisible(fwsColpCallButton, 5), "FWS Interstitial page - Call button is not visible.");
        fsa.assertTrue(isElementVisible(continueWithoutDiscountLink, 5), "FWS Interstitial page - Continue without discount link is not visible.");
    }

    public void validateFwsQnBPage(FarmersSoftAssert fsa) {
    	waitForPageToBeReady();
        fsa.assertEquals(getTextFromElement(fwsInterstitialPageTitle), FWS_INTERSTITIAL_PAGE_TITLE_TEXT, "FWS Interstitial - QnB Page title is not as expected.");
        String dynamicContent = getTextFromElement(fwsPageDynamicContent);
        fsa.assertEquals(getTextFromElement(fwsPageSubtitle), String.format("As part of %s, you could save hundreds!", dynamicContent), "FWS Interstitial - QnB page subtitle is not as expected.");
        fsa.assertTrue(getTextFromElement(fwsInterstitialPageContent).contains(FWS_INTERSTITIAL_QNB_PAGE_CONTENT), "FWS Interstitial - QnB page content is not as expected.");
        fsa.assertTrue(isElementVisible(fwsGetMyQuoteButton, 5), "FWS Interstitial page - QnB - Get My Quote button is not visible.");
        fsa.assertFalse(isElementVisible(continueWithoutDiscountLink, 5), "FWS Interstitial page - QnB - Continue without discount link is visible.");
    }

    public boolean isOnFarmersChoiceInterstitialPage() {
        return isElementVisible(farmersChoicePageContent, 5);
    }

    public boolean isOnColpInterstitialPage() { return isExpectedTextDisplayed(fwsInterstitialPageContent, FWS_INTERSTITIAL_COLP_PAGE_CONTENT); }

    public boolean isOnQnBInterstitialPage() { return isElementVisible(fwsInterstitialGroupQuoteContent, 5); }

    public void clickOnApplyDiscountButton() {
        waitAndClickElement(applyDiscountsButton, 3);
    }

    public void clickOnGetMyQuoteButton() {
        waitAndClickElement(fwsGetMyQuoteButton, 3);
    }

    public void clickOnDialogContainerAgreeButton() {
        waitAndClickElement(fwsDialogContainerAgreeButton, 3);
    }

    public boolean isOnBindableChoicePage(int seconds) {
        return isElementVisible(selectedInsuranceType, seconds);
    }

    public void validateSelectedInsuranceType(FarmersSoftAssert fsa, String lobType) throws Exception {
        String currentUrl = page().url();
        String EXPECTED_DOMAIN = "farmersinsurancechoice.com";
        fsa.assertTrue(currentUrl.contains(EXPECTED_DOMAIN), "Current URL does not contain expected domain. Current URL: " + currentUrl);
        if (!lobType.equals(RENTERS)) {
            fsa.assertEquals(getTextFromElement(selectedInsuranceType), "Homeowners", "Selected insurance type is not as expected on bindable choice page.");
        } else {
            fsa.assertEquals(getTextFromElement(selectedInsuranceType), RENTERS, "Selected insurance type is not as expected on bindable choice page.");
        }
    }

    public boolean isOnQnBSite() { return isElementVisible(qnbPageHeader, 30); }

    public void validateQnBUrl(FarmersSoftAssert fsa) throws Exception {
        String currentUrl = page().url();
        String EXPECTED_URL = "/quote-and-buy-farmers";
        fsa.assertTrue(currentUrl.contains(EXPECTED_URL), "Current URL does not contain expected url keywords. Current URL: " + currentUrl);
    }

    public void clickContinueWithoutDiscount() throws Exception {
        waitAndClickElement(continueWithoutDiscountLink, 3);
    }

    public boolean isOnFwsFarmersInsuranceChoicePage() {
        return isElementPresent(pwCss("button[data-uid='pg_intro_next_btn']"), 4);
    }
}
