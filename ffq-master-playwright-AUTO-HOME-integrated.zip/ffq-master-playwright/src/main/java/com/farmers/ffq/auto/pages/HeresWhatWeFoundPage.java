package com.farmers.ffq.auto.pages;






import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.datatransferobjects.ADPFApplicant;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AutoApplicant;
import com.farmers.ffq.datatransferobjects.SqlAdditionalDriver;
import com.farmers.ffq.datatransferobjects.Vehicle;
import com.farmers.ffq.utils.DbHelper;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.report.Log;
import lombok.SneakyThrows;
import net.datafaker.Faker;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.GlobalVariables.*;

public class HeresWhatWeFoundPage extends WhoShouldWeInsurePage {
    private static final String ADPF_DRIVERS_FOUND_XPATH = "//ul[@class='auto-vehicles-drivers-review__drivers-list-section']";
    private static final String ADPF_VEHICLES_FOUND_XPATH = "//div[@class='auto-vehicles-drivers-review__vehicles-list-section']";
    private static final String CHECKBOX_XPATH = "//li//input";
    private static final String CHECKED_DRIVERS_XPATH = ADPF_DRIVERS_FOUND_XPATH + CHECKBOX_XPATH + "[contains(@class,'mdc-checkbox--selected')]";
    private static final String DRIVER_AGE_XPATH = "//div/span";
    private static final String DRIVER_NAME_XPATH = "//label";
    private static final String CHECKED_VEHICLES_XPATH = ADPF_VEHICLES_FOUND_XPATH + MATCHECKBOX_XPATH + INPUT_XPATH + "[contains(@class,'" + MDC_CHECKBOX_SELECTED + "')]";
    private static final String PNI_DRIVER_SECTION = "//li[.//mat-checkbox[@id='driver__checkbox1']]";
    private static final String SECTIONS_ANCESTOR_LI_XPATH = "//ancestor::li"; // represents each driver sections as webElements
    private static final String UNCHECKED_DRIVERS_XPATH = ADPF_DRIVERS_FOUND_XPATH + CHECKBOX_XPATH + "[@aria-checked='false']";
    private static final String UNCHECKED_VEHICLES_XPATH = ADPF_VEHICLES_FOUND_XPATH + MATCHECKBOX_XPATH + INPUT_XPATH + "[not(contains(@class,'mdc-checkbox--selected'))]";
    private static final int VIN_LAST_DIGITS_LENGTH = 3;
    private final String adpfVehicleName = pwCss(".mdc-label");
    private final String adpfVehicleVin = pwCss("[class*='vin']");
    private final String FIRST_NAME = "First name";
    private final String LAST_NAME = "Last name";
    private final String XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_INPUT_FIELDS = "//mat-form-field[.//mat-label[contains(text(),'%s')]]//input";
    private final String XPATH_FOR_DO_YOU_HAVE_MORE_VEHICLES_POPUP = "//mat-dialog-container[@id='addMoreVehiclesDialog']//h4[contains(text(), 'Do you have more vehicles?')]";
        private Locator addAnotherVehicleLink = locator(pwXPath("//div[contains(@class, 'auto-vehicles-drivers-review__vehicles-list')]//a[contains(text(), 'Add another vehicle')]"));
        private Locator addVehicleDialog = locator(pwId("addVehicleDialog"));
        private Locator checkBoxOfPNIDriver = locator(pwXPath(PNI_DRIVER_SECTION + MATCHECKBOX_XPATH));
        private Locator continueToDriversButton = locator(pwXPath("//div[@class='auto-vehicles-drivers-review__continue-button-section']/button"));
        private Locator dateOfBirthEntryField = locator(pwXPath("//mat-form-field//input[contains(@aria-label, 'Date of birth')]"));
        private Locator driversSectionTitle = locator(pwXPath("//h2[text()='Drivers']"));
        private Locator editButtonOfPNIDriver = locator(pwXPath(PNI_DRIVER_SECTION + EDIT_BUTTON));
        private Locator editDriverDialogHeader = locator(pwId("addDriverHeading"));
        private Locator errorMessage = locator(pwCss("p.auto-vehicles-drivers-review__error-message"));
        public Locator duplicateDriverErrorMessage = locator(pwXPath("//p[contains(@class, 'auto-add-driver__error-message') and contains(text(), 'The person you are adding appears to already be listed on your quote')]"));
        private Locator heresWhatWeFoundPageHeader = locator(pwXPath("//h1[contains(@class,'auto-vehicles-drivers-review__heading tui-h1') or contains(text(), 'what we found') or @class='tui-h1 page-title ng-star-inserted']"));
        private Locator heresWhatWeFoundPageDescription = locator(pwXPath("//div[contains(@class, 'auto-vehicles-drivers-review__subheading')]"));
        private Locator heresWhatWeFoundPageTitle = locator(pwClass("tui-h1"));
        private Locator listOfADPFDriversWithAges = locator(pwXPath(ADPF_DRIVERS_FOUND_XPATH + "/li"));
        private Locator listOfADPFVehicles = locator(pwCss("div.auto-vehicles-drivers-review__vehicles-list-details"));
        private Locator listOfADPFVehiclesCheckboxes = locator(pwXPath(ADPF_VEHICLES_FOUND_XPATH + MATCHECKBOX_XPATH + INPUT_XPATH));
        private Locator listOfADPFVehiclesNames = locator(pwXPath(ADPF_VEHICLES_FOUND_XPATH + "//mat-checkbox/label/span[2]"));
        private Locator listOfAllDriverAges = locator(pwXPath(ADPF_DRIVERS_FOUND_XPATH + CHECKBOX_XPATH + SECTIONS_ANCESTOR_LI_XPATH + DRIVER_AGE_XPATH));
        private Locator listOfAllDriverDetailsSections = locator(pwXPath(ADPF_DRIVERS_FOUND_XPATH + CHECKBOX_XPATH + SECTIONS_ANCESTOR_LI_XPATH));
        private Locator listOfAllDriverNames = locator(pwXPath(ADPF_DRIVERS_FOUND_XPATH + CHECKBOX_XPATH + SECTIONS_ANCESTOR_LI_XPATH + DRIVER_NAME_XPATH));
        private Locator listOfAllEditButtonOfAdditionalDriverDetails = locator(pwXPath("//ul[contains(@class,'drivers-list-section')]//mat-checkbox[not(@id='driver__checkbox1')]" + "/../..//a"));
        private Locator listOfCheckedDriverAges = locator(pwXPath(CHECKED_DRIVERS_XPATH + SECTIONS_ANCESTOR_LI_XPATH + DRIVER_AGE_XPATH));
        private Locator listOfCheckedDriverNames = locator(pwXPath(CHECKED_DRIVERS_XPATH + SECTIONS_ANCESTOR_LI_XPATH + DRIVER_NAME_XPATH));
        private Locator listOfCheckedDrivers = locator(pwXPath("//mat-checkbox[contains(@id,'driver__checkbox') and contains(@class,'checked')]"));
        private Locator listOfUncheckedDriverAges = locator(pwXPath(UNCHECKED_DRIVERS_XPATH + SECTIONS_ANCESTOR_LI_XPATH + DRIVER_AGE_XPATH));
        private Locator listOfUncheckedDriverNames = locator(pwXPath("//mat-checkbox[contains(@id,'driver') and not(contains(@class,'mat-mdc-checkbox-checked'))]"));
        private Locator selectedCurrentlyInsuredRadioButton = locator(pwCss(".auto-add-driver-currently-insured__section.row mat-radio-button.mat-radio-checked"));
        private Locator selectedDriverLicenseIssuedInUs = locator(pwCss("mat-radio-button.mat-radio-checked"));
        private Locator selectedGenderButton = locator(pwCss("mat-button-toggle-group[aria-label*='gender'] mat-button-toggle[class*='checked']"));
        private Locator sniApplicantRemovalNotification = locator(pwXPath("//li[.//mat-checkbox[@id='driver__checkbox2']]/div[2]//div"));
        private Locator vehiclesSectionTitle = locator(pwXPath("//h2[text()='Vehicles']"));


    public HeresWhatWeFoundPage() throws Exception {
    }

    @SneakyThrows
    public boolean AreAllAdpfVehicleVinProperlyMasked() {
        for (Locator adpfVehicle : listOfADPFVehicles.all()) {
            String vinText = "";
            boolean isVinMasked = false;
            int attempts = 0;
            while (attempts < 2) {
                try {
                    Locator vinElement = adpfVehicle.locator(adpfVehicleVin);
                    vinText = getTextFromElement(vinElement);
                    isVinMasked = isMaskedExceptLastDigits(vinText);
                    break;
                } catch (PlaywrightException e) {
                    // Handle stale element reference exception by re-finding the element
                    adpfVehicle = locator(pwId(getAttributeData(adpfVehicle, CLASS)));
                }
                attempts++;
            }

            if (!isVinMasked) {
                Log.info("VIN not properly masked: " + vinText); // Log the incorrect VIN
                return false; // VIN is not properly masked
            }
        }
        return true; // All VINs are properly masked
    }

    public void addADPFApplicants(ADPFApplicant adpfApplicant) throws Exception {
        String applicantFullName = adpfApplicant.getFirstName() + SPACE + adpfApplicant.getLastName();
        addADPFApplicant(Optional.empty(), applicantFullName, adpfApplicant.getGender(), adpfApplicant.getDateOfBirth());
        addAdditionalADPFApplicants(adpfApplicant.getListOfAdditionalApplicants());
    }

    public void addAllExcludedDrivers() throws Exception {
        List<Locator> listOfExcludedDrivers = locators(pwXPath(UNCHECKED_DRIVERS_XPATH));
        for (Locator excludedDriverCheckbox : listOfExcludedDrivers) {
            setCheckboxTo(excludedDriverCheckbox, true);
        }
    }

    public void addAllExcludedVehicles() throws Exception {
        for (Locator vehicleCheckbox : listOfADPFVehiclesCheckboxes.all()) {
            setCheckboxTo(vehicleCheckbox, true);
        }
    }

    public void addFirstExcludedDriver(ADPFApplicant adpfApplicant) throws Exception {
        List<Locator> listOfExcludedDrivers = locators(pwXPath(UNCHECKED_DRIVERS_XPATH));
        if (!listOfExcludedDrivers.isEmpty()) {
            setCheckboxTo(listOfExcludedDrivers.get(0), true);
            WhoShouldWeInsurePage editDriverPane = new WhoShouldWeInsurePage();
            if (isElementVisible(dateOfBirthEntryField, 2)) {
                editDriverPane.addADPFDriverDetails(Optional.empty(), adpfApplicant.getGender(), adpfApplicant.getDateOfBirth());
            }
        }
    }

    public void addFirstExcludedVehicle() throws Exception {
        List<Locator> listOfExcludedDrivers = getListOfUnCheckedVehicles();
        if (!listOfExcludedDrivers.isEmpty()) {
            setCheckboxTo(listOfExcludedDrivers.get(0), true);
        }
    }

    public boolean areAllFirstNameLastNameAndDobFieldsEditable() {
        for (Locator additionalDriverEditButton : listOfAllEditButtonOfAdditionalDriverDetails.all()) {
            waitAndClickElement(additionalDriverEditButton);
            if (!isFirstNameEditable() && !isLastNameEditable() && !isDobEditable()) {
                return false;
            }
        }
        return true;
    }

    public boolean areVehicleMakeModelYearAndVinDisplayed() throws Exception {
        Map<String, String> actualMapOfVinAndVehicle = extractActualVinAndVehicleDetails();
        Map<String, String> expectedMapOfVinAndVehicle = extractExpectedVinAndVehicleDetails();
        Log.info("actualMapOfVinAndVehicle -> " + actualMapOfVinAndVehicle);
        Log.info("expectedMapOfVinAndVehicle -> " + expectedMapOfVinAndVehicle);
        return actualMapOfVinAndVehicle.equals(expectedMapOfVinAndVehicle);
    }

    public void checkRandomIncompleteDriverBox() throws Exception {
        int size = getListOfUnCheckedDrivers().size();
        Locator checkBox = getListOfUnCheckedDrivers().get(new Random().nextInt(size));
        setCheckboxTo(checkBox, true);
    }

    public void checkRandomIncompleteVehicleBox() throws Exception {
        int size = getListOfUnCheckedVehicles().size();
        if(size == 0) {
            return;
        }
        Locator checkBox = getListOfUnCheckedVehicles().get(new Random().nextInt(size));
        setCheckboxTo(checkBox, true);
    }

    public void clickContinueButton() {
        scrollAndClickOnElement(continueToDriversButton);
        waitForSpinnerToBeGone();
    }

    public void clickOnEditButtonOfPNIDriver() {
        waitAndClickElement(editButtonOfPNIDriver);
    }

    public void clickRandomCompleteVehicleEditButton() throws Exception {
        int size = (int) listOfEditButtonsOfCheckedVehicles.count();
        if(size > 0) {
            setDefinedNumberUncheckVehiclesToTrue(1);
        }
        Locator editButton = listOfEditButtonsOfCheckedVehicles.nth(new Random().nextInt(size));
        scrollToElement(editButton);
        waitAndClickElement(editButton);
    }

    public void disableADPFDiscoveredVehicles() {
        for (Locator checkbox : listOfADPFVehiclesCheckboxes.all()) {
            setCheckboxTo(checkbox, false);
        }
    }

    public List<Locator> getCheckedDriverNames() {
        return listOfCheckedDriverNames.all();
    }

    public List<Locator> getCheckedDrivers() {
        return listOfCheckedDrivers.all();
    }

    public String getCheckedDriverNamesXpath() {
        return CHECKED_DRIVERS_XPATH + SECTIONS_ANCESTOR_LI_XPATH + DRIVER_NAME_XPATH;
    }

    public String getCheckedVehiclesXpath() {
        return CHECKED_VEHICLES_XPATH;
    }

    public String getDateOfBirthValue() {
        return getInputFieldValue(dateOfBirthEntryField);
    }

    public String getErrorMessage() {
        return getTextFromElement(waitElementBeVisible(errorMessage));
    }

    public LinkedHashMap<String, String> getListOfDrivers(String filterDriversBy) throws Exception {
        LinkedHashMap<String, String> namesAndAges = new LinkedHashMap<>();
        scrollToElement(driversSectionTitle);
        switch (filterDriversBy) {
            case CHECKED:
            	int numberOfCheckedDriversNames = listOfCheckedDriverNames.count();
            	int numberOfCheckedDriverAges = listOfCheckedDriverAges.count();
                for (int index = 0; index < numberOfCheckedDriversNames && index < numberOfCheckedDriverAges; index++) {
                    String checkedDriverAge = getTextFromElement(listOfCheckedDriverAges.nth(index)).replaceAll(COLON, EMPTY_STRING);
                    if (checkedDriverAge.contains("--")) {
                        checkedDriverAge = EMPTY_STRING;
                    }
                    namesAndAges.put(getTextFromElement(listOfCheckedDriverNames.nth(index)).toLowerCase(Locale.US), checkedDriverAge);
                }
                break;
            case UNCHECKED:
            	int numberOfUncheckedDriversNames = listOfUncheckedDriverNames.count();
            	int numberOfUncheckedDriverAges = listOfUncheckedDriverAges.count();
                for (int index = 0; index < numberOfUncheckedDriversNames && index < numberOfUncheckedDriverAges; index++) {
                    String uncheckedDriverAge = getTextFromElement(listOfUncheckedDriverAges.nth(index)).replaceAll(COLON, EMPTY_STRING);
                    if (uncheckedDriverAge.contains("--")) {
                        uncheckedDriverAge = EMPTY_STRING;
                    }
                    namesAndAges.put(getTextFromElement(listOfUncheckedDriverNames.nth(index)).toLowerCase(Locale.US), uncheckedDriverAge);
                }
                break;
            case NO_FILTER:
            	int numberOfDriversNames = listOfAllDriverNames.count();
            	int numberOfDriverAges = listOfAllDriverAges.count();
                for (int index = 0; index < numberOfDriversNames && index < numberOfDriverAges; index++) {
                    String driverAge = getTextFromElement(listOfAllDriverNames.nth(index)).replaceAll(COLON, EMPTY_STRING);
                    if (driverAge.contains("--")) {
                        driverAge = EMPTY_STRING;
                    }
                    namesAndAges.put(getTextFromElement(listOfAllDriverNames.nth(index)).toLowerCase(Locale.US), driverAge);
                }
                break;
            default:
                Log.error("getListOfDrivers undefined filter: " + filterDriversBy);
        }
        return namesAndAges;
    }

    public List<Locator> getListOfUnCheckedDrivers() throws Exception {
        return locators(pwXPath(UNCHECKED_DRIVERS_XPATH));
    }

    public List<Locator> getListOfUnCheckedVehicles() throws Exception {
        return locators(pwXPath("//mat-checkbox[contains(@class,'mat-mdc-checkbox auto-vehicles-drivers-review__vehicles-list-details-checkbox mat-accent') and not(contains(@class,'mat-mdc-checkbox-checked'))]"));
    }

    public List<Locator> getEditButtonsForUncheckedVehicles() throws Exception {
        return locators(pwXPath("//mat-checkbox[@class='mat-checkbox auto-vehicles-drivers-review__vehicles-list-details-checkbox mat-accent']/..//a"));
    }

    public List<Locator> getEditButtonsForCheckedVehicles() throws Exception {
        return locators(pwXPath("//mat-checkbox[contains(@class,'vehicles-list-details') and (contains(@class,'mat-mdc-checkbox-checked'))]/..//a"));
    }

    public void setDefinedNumberUncheckVehiclesToTrue(int num) throws Exception {
        for (int i = 0; i < num; i++) {
            List<Locator> uncheckedVehicles = locators(pwXPath("//mat-checkbox[contains(@class,'vehicles-list-details') and not(contains(@class,'mat-checkbox-checked'))]//input"));
            if(!uncheckedVehicles.isEmpty() && !(getVehicleDescriptionForCheckedVehicles().size() > 4)) {
                scrollAndClickOnElement(uncheckedVehicles.get(i));
            }
        }
    }

    @Override
    public void addAdditionalDrivers(AutoApplicant applicant) throws Exception {
    	for (SqlAdditionalDriver additionalDriver : applicant.getAdditionalDrivers()) {
    		boolean ableToAddDrivers = false;
    		if (isElementDisplayed(addAnotherDriverButton, 2)) {
    			clickAddAnotherDriverButton();
    			ableToAddDrivers = true;
    		} else if (isElementDisplayed(addAnotherDriverButtonSideSheet, 2)) {
    			clickOnAddAnotherDriverButtonSideSheet();
    			ableToAddDrivers = true;
    		}
    		if (ableToAddDrivers) {
    			waitElementBeVisible(editDriverDialogHeader);
    			enterAdditionalDriverData(applicant, additionalDriver);
    			clickOnSaveButton();
    			waitForSpinnerToBeGone();
    		}
    	}
    	clickOnDoneAddingDriversButton();
    }

    public void uncheckVehiclesOnlyForOne () throws Exception {
        //check only one vehicle
        int allVehicles = locators(pwXPath("//mat-checkbox[contains(@id,'vehicle__checkbox')]")).size();
        String vehicleCheckboxXpath = "//mat-checkbox[contains(@id,'vehicle__checkbox%s')]//input";
        int tryCount = 3;
        for (int i = 1; i <= allVehicles; i++) {
            Locator element = locator(pwXPath(String.format(vehicleCheckboxXpath, i)));
            if (i == 1) {
                while (isCheckboxNotChecked(element) && tryCount > 0) {
                    clickElement(element);
                    waitForUiSettled();
                    element = locator(pwXPath(String.format(vehicleCheckboxXpath, i)));
                    tryCount--;
                }
            } else {
                while (isCheckboxChecked(element) && tryCount > 0) {
                    scrollAndClickOnElement(element);
                    waitForUiSettled();
                    element = locator(pwXPath(String.format(vehicleCheckboxXpath, i)));
                    tryCount--;
                }
            }

        }
    }

    public int getNumberOfCheckedDrivers() {
        return listOfCheckedDriverNames.count();
    }

    public int getNumberOfCheckedVehicles() {
        return (int) listOfCheckedVehicles.count();
    }

    public int getNumberOfUncheckedDrivers() {
        return listOfUncheckedDriverNames.count();
    }

    public int getNumberOfUncheckedVehicles() throws Exception {
        return getListOfUnCheckedVehicles().size();
    }

    public String getPniDriverRemovalNotificationText() throws Exception {
        return getTextFromElement(locator(pwXPath(PNI_DRIVER_SECTION + "/div[2]//div")));
    }

    public String getSniDriverRemovalNotificationText() {
        return getTextFromElement(sniApplicantRemovalNotification);
    }

    public List<Locator> getUnCheckedDriverNames() {
        return listOfUncheckedDriverNames.all();
    }

    public String getUnCheckedDriverNamesXpath() {
        return UNCHECKED_DRIVERS_XPATH + SECTIONS_ANCESTOR_LI_XPATH + DRIVER_NAME_XPATH;
    }

    public String getUnCheckedVehiclesXpath() {
        return UNCHECKED_VEHICLES_XPATH;
    }

    public boolean isAddAnotherVehicleLinkDisplayed() {
        return isElementVisible(addAnotherVehicleLink, 7);
    }

    public boolean isDobEditable() {
        return !isInputFieldReadOnly(dateOfBirthEntryField);
    }

    public boolean isEditDriverModuleOpened() {
        return isElementVisible(editDriverDialogHeader, 10);
    }

    public boolean isEditVehicleModuleOpened() {
        return isElementVisible(addVehicleDialog, 10);
    }

    public boolean isFirstNameEditable() {
        return !isInputFieldReadOnly(getFormInputFieldLocator(FIRST_NAME));
    }

    public boolean isLastNameEditable() {
        return !isInputFieldReadOnly(getFormInputFieldLocator(LAST_NAME));
    }

    public boolean isOnHeresWhatWeFoundPage() {
        return isElementVisible(heresWhatWeFoundPageHeader, 55);
    }

    public boolean isOnHeresWhatWeFoundPageShort() {
        return isElementVisible(heresWhatWeFoundPageHeader, 2);
    }

    public boolean isUpdatedVehicleDisplayedCorrectly() throws Exception {

        Vehicle vehicleInfo = updateYearOfRandomCompleteVehicleAndReturnVehicleDetails();
        String updatedVehicleInfo = String.join(" ", vehicleInfo.getVehicleYear(), vehicleInfo.getVehicleMake(), vehicleInfo.getVehicleModel());

        WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
        boolean isOnStreamlineFlow = whoShouldWeInsurePage.isVehiclesDriversConsolidationImpl(getSessionStorageAppStore().getData().getLandingStateCode());
        List<String> actualDisplayedVehicles = new ArrayList<>();
        if (isOnStreamlineFlow) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            actualDisplayedVehicles = vehiclesDriversInfoPage.getDisplayedVehicles();
        } else {
            actualDisplayedVehicles = whoShouldWeInsurePage.getActualListOfDisplayedVehicles();
        }
        return actualDisplayedVehicles.contains(updatedVehicleInfo);
    }

    public void removeNonPNIApplicants(ADPFApplicant adpfApplicant) throws Exception {
        String applicantName = adpfApplicant.getFirstName().toLowerCase() + SPACE + adpfApplicant.getLastName().toLowerCase();
        for (Locator checkedDriver : listOfCheckedDriverNames.all()) {
            if (!applicantName.equals(getTextFromElement(checkedDriver).toLowerCase())) {
                clickElement(checkedDriver);
            }
        }
    }

    public void uncheckRandomAdditionalDriverCheckbox() throws Exception {
        List<Locator> webElements = locators(pwXPath("//mat-checkbox[@class='mat-mdc-checkbox tui-disabled-checkbox-only mat-accent mat-mdc-checkbox-checked']//input"));
        Collections.shuffle(webElements);
        clickOnHiddenElement(webElements.get(0));
    }

    public Vehicle updateYearOfRandomCompleteVehicleAndReturnVehicleDetails() throws Exception {
        boolean vehiclesDriversConsolidationImpl = isVehiclesDriversConsolidationImpl(getSessionStorageAppStore().getData().getLandingStateCode());

        if (!vehiclesDriversConsolidationImpl) {
            waitAndClickElement(getEditButtonsForCheckedVehicles().stream().findFirst().get());
            WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
            whoShouldWeInsurePage.clickOnYMMButton();
            return whoShouldWeInsurePage.updateApplicantRandomVehicleYear();
        } else {
            // Grab make & model from session storage before opening the edit side sheet
            AppStore.Auto.AppStoreVehicle firstVehicle = getSessionStorageAppStore().getAuto().getVehicles().get(0);
            String make = firstVehicle.getMakeDesc();
            String model = firstVehicle.getModelDesc();
            String vehicleType = firstVehicle.getVehicleType();

            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();

            waitAndClickElement(vehiclesDriversInfoPage.getEditButtonsForCheckedVehicles().get(0));

            // Pick a random year from the last 20 years, excluding the pre-filled value
            String prefilledYear = vehiclesDriversInfoPage.getPrefilledVehicleYear();
            String randomYear = pickRandomYearExcluding(prefilledYear);
            Log.info("Pre-filled vehicle year: " + prefilledYear + " → updating to: " + randomYear);

            vehiclesDriversInfoPage.fillOutVehicleYear(randomYear);
            vehiclesDriversInfoPage.fillOutVehicleMake(make);
            vehiclesDriversInfoPage.fillOutVehicleModel(model);
            vehiclesDriversInfoPage.fillOutVehicleType(vehicleType);
            vehiclesDriversInfoPage.clickVehicleSaveChangesButton();
            waitForSpinnerToBeGone();

            Vehicle vehicleInfo = new Vehicle();
            vehicleInfo.setVehicleYear(randomYear);
            vehicleInfo.setVehicleMake(make);
            vehicleInfo.setVehicleModel(model);
            vehicleInfo.setVehicleType(vehicleType);
            return vehicleInfo;
        }
    }

    /**
     * Returns a random year string from the last 20 years (inclusive of current year),
     * guaranteed to differ from {@code excludeYear}.
     */
    private String pickRandomYearExcluding(String excludeYear) {
        int currentYear = LocalDateTime.now().getYear();
        List<String> candidates = new ArrayList<>();
        for (int y = currentYear - 19; y <= currentYear; y++) {
            String year = String.valueOf(y);
            if (!year.equals(excludeYear)) {
                candidates.add(year);
            }
        }
        if (candidates.isEmpty()) {
            throw new IllegalStateException("No candidate years available after excluding: " + excludeYear);
        }
        return candidates.get(new Random().nextInt(candidates.size()));
    }

    public boolean validateDriverFirstNameLastNameAndAgeDisplayed(ADPFApplicant applicant) throws Exception {
        Map<String, String> actualDriverDetails = new HashMap<>();
        if(isVehiclesDriversConsolidationImpl(applicant.getStateCode()))
        {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            actualDriverDetails = vehiclesDriversInfoPage.getActualMapOfListedDriverDetails();
        }
        else {
            actualDriverDetails = getActualMapOfListedDriverDetails();
        }
        Map<String, String> expectedDriverDetails = getExpectedMapOfListedDriverDetails();
        return actualDriverDetails.equals(expectedDriverDetails);
    }

    public boolean validateDriverPNICheckboxStatus() {
        clickOnEditButtonOfPNIDriver();
        // making sure the side panel is open
        waitElementBeVisible(dateOfBirthEntryField);
        boolean isPniDriverCheckboxChecked = getAttributeData(checkBoxOfPNIDriver, CLASS).contains(CHECKED);

        if (isPniDriverCheckboxChecked) {
            return isPniDriverDetailsPopulatedAndChecked(); // All details should be populated
        } else {
            return isPniDriverDetailsPartiallyOrNotPopulated(); // At least one detail should not be populated
        }
    }

    private void addAdditionalADPFApplicants(List<ADPFApplicant> listOfAdditionalApplicants) throws Exception {
        if (!listOfAdditionalApplicants.isEmpty()) {
            for (ADPFApplicant additionalApplicant : listOfAdditionalApplicants) {
                String fullName = additionalApplicant.getFirstName() + SPACE + additionalApplicant.getLastName();
                addADPFApplicant(Optional.empty(), fullName, additionalApplicant.getGender(), additionalApplicant.getDateOfBirth());
            }
        }
    }

    // Helper method to check all conditions for a single driver
    private boolean checkDriverDetails() {
        waitAndClickElement(editButtonOfPNIDriver);
        waitElementBeVisible(dateOfBirthEntryField);

        boolean isFirstNameNotEmpty = !getInputFieldValue(getFormInputFieldLocator(FIRST_NAME)).isEmpty();
        boolean isLastNameNotEmpty = !getInputFieldValue(getFormInputFieldLocator(LAST_NAME)).isEmpty();
        boolean isDOBNotEmpty = !getInputFieldValue(dateOfBirthEntryField).isEmpty();
        boolean isSelectedGenderButtonVisible = isElementVisible(selectedGenderButton, 5);
        boolean isSelectedLicenseButtonVisible = isElementVisible(selectedDriverLicenseIssuedInUs, 5);
        boolean isSelectedInsuranceButtonVisible = isElementVisible(selectedCurrentlyInsuredRadioButton, 5);

        return isFirstNameNotEmpty &&
                isLastNameNotEmpty &&
                isDOBNotEmpty &&
                isSelectedGenderButtonVisible &&
                isSelectedLicenseButtonVisible &&
                isSelectedInsuranceButtonVisible;
    }

    protected Map<String, String> extractActualVinAndVehicleDetails() {
        Map<String, String> mapOfVinAndVehicle = new HashMap<>();
        listOfADPFVehicles.all().forEach(adpfVehicle -> {
            String vin = getTextFromElement(adpfVehicle.locator(adpfVehicleVin));
            String lastThreeDigitsOfVin = getLastDigitsOfVin(vin);
            String vehicleDetails = getTextFromElement(adpfVehicle.locator(adpfVehicleName));
            mapOfVinAndVehicle.put(lastThreeDigitsOfVin, vehicleDetails);
        });
        return mapOfVinAndVehicle;
    }

    Map<String, String> extractExpectedVinAndVehicleDetails() throws Exception {
        AppStore retrieveQuoteResponseSessionStorage = getSessionStorageAppStore();
        List<AppStore.Auto.AppStoreVehicle> expectedListOfVehicles = retrieveQuoteResponseSessionStorage.getAuto().getVehicles();
        Map<String, String> expectedMapOfVinAndVehicle = new HashMap<>();

        expectedListOfVehicles.forEach(vehicle -> {
            String vin = vehicle.getVin();
            String lastThreeDigitsOfVin = getLastDigitsOfVin(vin);
            String vehicleDetails = String.join(" ", vehicle.getYear(), vehicle.getMakeDesc(), vehicle.getModelDesc());
            expectedMapOfVinAndVehicle.put(lastThreeDigitsOfVin, vehicleDetails);
        });
        return expectedMapOfVinAndVehicle;
    }

    private Map<String, String> getActualMapOfListedDriverDetails() throws Exception {
        // extracting driver first name and associated age.
        Map<String, String> actualMapOfListedDriverDetails = new HashMap<>();

        actualMapOfListedDriverDetails.putAll(getListOfDrivers(UNCHECKED));
        actualMapOfListedDriverDetails.putAll(getListOfDrivers(CHECKED));
        actualMapOfListedDriverDetails.replaceAll((fullName, age) -> age.equals(EMPTY_STRING) ? "0" : age.substring(age.length() - 2));

        return actualMapOfListedDriverDetails;

    }

    private Map<String, String> getExpectedMapOfListedDriverDetails() throws Exception {
        // extracting driver first name and associated age from session storage as expected data.
        Map<String, String> expectedMapOfListedDriverDetails = new HashMap<>();

        AppStore retrieveQuoteResponseSessionStorage = getSessionStorageAppStore();

        retrieveQuoteResponseSessionStorage.getAuto().getDrivers().forEach(driver -> {

            String driverFullName = String.join(" ", driver.getFirstName().toLowerCase(), driver.getLastName().toLowerCase());
            String driverAge = String.valueOf(driver.getAge());

            expectedMapOfListedDriverDetails.put(driverFullName, driverAge);
        });
        return expectedMapOfListedDriverDetails;
    }

    @SneakyThrows
    private Locator getFormInputFieldLocator(String label) {
        Locator webElement = locator(pwXPath(String.format(XPATH_FOR_VEHICLES_OR_DRIVERS_DIALOG_INPUT_FIELDS, label)));
        waitElementBeVisible(webElement);
        return webElement;
    }

    private String getLastDigitsOfVin(String vin) {
        if (vin.length() < VIN_LAST_DIGITS_LENGTH) {
            return vin;
        }
        return vin.substring(vin.length() - VIN_LAST_DIGITS_LENGTH);
    }

    public boolean isInputFieldReadOnly(Locator webElement) {
        String attribute = getAttributeData(webElement, "readonly");
        if (attribute == null) {
            return false;
        } else {
            return attribute.equals("true");
        }
    }

    private boolean isMaskedExceptLastDigits(String vin) {
        String maskedPart = vin.substring(0, vin.length() - VIN_LAST_DIGITS_LENGTH);
        return maskedPart.chars().noneMatch(Character::isDigit);
    }

    // Check PNI driver details are incomplete and unchecked
    private boolean isPniDriverDetailsPartiallyOrNotPopulated() {
        return !checkDriverDetails();
    }

    // Check PNI driver details are completed and checked
    private boolean isPniDriverDetailsPopulatedAndChecked() {
        return checkDriverDetails();
    }

    public void validateADA_HeresWhatWeFoundPage() {
        isOnHeresWhatWeFoundPage();
        if(isADATestingEnabled()) {
            performADATesting(this.getClass().getSimpleName(), MARKETING_IT, ACE_AUTO);

        }
    }

    public List<String> getVehicleDescriptionForCheckedVehicles() throws Exception {
        List<Locator> checkedVehicles = locators(pwXPath("//mat-checkbox[contains(@class,'mat-checkbox auto-vehicles-drivers-review__vehicles-list-details-checkbox mat-accent mat-checkbox-checked')]"));
        return checkedVehicles.stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public void addAnotherRandomDriver(int age) throws Exception {
        addDriverDetails(age);
        clickOnSaveButton();
    }

    public void addDriverDetails(int age) throws Exception {
        Faker faker = new Faker();
        String firstName = faker.name().firstName();
        String lastName = faker.name().lastName();
        String dateOfBirth = "01/01/" + (LocalDateTime.now().getYear() - age);
        sendKeysToElement(getInputElementByAriaLabel("First name"), firstName);
        sendKeysToElement(getInputElementByAriaLabel("Last name"), lastName);
        sendKeysToElement(getInputElementByAriaLabel("Date of birth"), dateOfBirth);
        selectGenderTabButton("Male");
        selectUsOrCanadaLicensedRadioButton("Yes");
    }

    private Locator getInputElementByAriaLabel(String ariaLabel) throws Exception {
        return locator(pwXPath(String.format("//input[@aria-label='%s']", ariaLabel)));
    }

    public void validateIncompleteDriverIsNotChecked(ADPFApplicant applicant) throws Exception {
        String applicantFullName = applicant.getFirstName() + SPACE + applicant.getLastName();
        Locator editButtonForPNI = getDriverEditCheckboxesInputButtonByFullName(applicantFullName).get(0);
        scrollAndClickOnElement(editButtonForPNI);
        clickDriverSaveChangesButton();
        isSaveDriverCtaIsPresent();
        clickCloseIcon();
        testStepAssert(!isElementVisible(editDriverDialogHeader,2), "Edit driver side sheet is closed");
        editButtonForPNI = getDriverEditCheckboxesInputButtonByFullName(applicantFullName).get(0);
        testStepAssert(isButtonNotSelected(editButtonForPNI), "Incomplete driver is not checked");

    }

    public void validateIncompleteVehicleIsNotChecked() throws Exception {
        waitAndClickElement(getListOfUnCheckedVehicles().get(0));
        testStepAssert(isElementVisible(addVehicleDialogHeader, 2), "Edit Vehicle side sheet opened");
        clickOnYMMButton();
        clickVehicleSaveChangesButton();
        testStepAssert(isElementVisible(ctaErrorMessageForVehicleEditSideSheet, 2), "Save button click triggers error message as there is a missing info");
        clickCloseIcon();
        testStepAssert(!isElementVisible(addVehicleDialogHeader, 2), "Edit Vehicle side sheet closed");
        testStepAssert(!getAttributeData(getListOfUnCheckedVehicles().get(0), CLASS).contains(MAT_CHECKBOX_CHECKED), "Checkbox is not checked for incomplete vehicle");

    }

    public void editCheckedVehicleAndvalidateNoErrorDisplayed() throws Exception {
        waitAndClickElement(getListOfCheckedVehicles().get(0));
        testStepAssert(isElementVisible(addVehicleDialogHeader, 2), "Edit Vehicle side sheet opened");
        clickVehicleSaveChangesButton();
        testStepAssertTrue(!isElementVisible(fieldErrorMessage, 1), "Save button click does not trigger error message");
        testStepAssert(!isElementVisible(addVehicleDialogHeader, 1), "Save button click closed Edit Vehicle side sheet");
    }

    public void validateVehicleEditClicksOpenSideSheet() throws Exception {
        waitAndClickElement(getEditButtonsForUncheckedVehicles().get(0));
        testStepAssert(isEditVehicleModuleOpened(), "Side sheet open for Edit Vehicle");
        clickCloseIcon();
        testStepAssert(!isElementVisible(editDriverDialogHeader,2), "Side sheet open for Edit Vehicle");
    }

    public void validateLessThanFiveCompleteVehiclesAreChecked() throws Exception {
        testStepAssert(!getListOfCheckedVehicles().isEmpty(), "Checked vehicle size should be more than zero");
        testStepAssert(getListOfUnCheckedVehicles().isEmpty(), "NON Checked vehicle size should be zero");
    }

    public void limitCheckedDriversToMaxAllowed() {
    	int checkedDriverCount = getNumberOfCheckedDrivers();
    	if (checkedDriverCount > MAX_NUMBER_OF_ADDITIONALDRIVERS + 1) {
    		List<Locator> listOfAllCheckedDrivers = getCheckedDrivers();
    		for (int driverNumber = MAX_NUMBER_OF_ADDITIONALDRIVERS + 1; driverNumber < checkedDriverCount; driverNumber++) {
    			Locator driverToUncheck = listOfAllCheckedDrivers.get(driverNumber);
    			scrollElementToMiddle(driverToUncheck);
    			setMatcheckboxTo(driverToUncheck, false);
    		}
    	}
    }

    public String getFullVinOfVehicleUsingQuoteNumberAndMaskedVin() throws Exception {
        AppStore sessionStorage = getSessionStorageAppStore();
        String quoteNumber = sessionStorage.getData().getQuoteNumber();
        List<AppStore.Auto.AppStoreVehicle> vehicles = sessionStorage.getAuto().getVehicles();
        if (vehicles == null || vehicles.isEmpty()) {
            throw new IllegalStateException("No vehicles available in session storage AppStore to retrieve VIN.");
        }
        String maskedVin = vehicles.stream().filter(i -> i.getVin() != "").collect(Collectors.toList()).get(0).getVin();
        String sqlQueryToGetFullVin = String.format("select vin from ffqdb.tquote_vehicles tv where quote_number='%s' and masked_vin='%s'", quoteNumber, maskedVin);
        return DbHelper.queryPostgresGetFirstRow(sqlQueryToGetFullVin);
    }

    public Map<String, String> getDriverDetailsUsingQuoteNumberMaskedFirstNameAndMaskedDOB() throws Exception {
        AppStore sessionStorage = getSessionStorageAppStore();
        String quoteNumber = sessionStorage.getData().getQuoteNumber();
        List<AppStore.Auto.Driver> drivers = sessionStorage.getAuto().getDrivers();
        if (drivers == null || drivers.isEmpty()) {
            throw new IllegalStateException("No drivers available in session storage AppStore.");
        }
        List<AppStore.Auto.Driver> driversWithMaskedFirstNameAndOtherMandatoryDetails = drivers.stream().filter(i -> i.getFirstName() != null && i.getFirstName().contains("**") && i.getLastName() != null && !i.getLastName().isEmpty() && i.getDateOfBirth() != null && !i.getDateOfBirth().isEmpty() && i.getGender() != null && !i.getGender().isEmpty() && (i.isLicenseIssuedInUS() == true || i.isLicenseIssuedInUS() == false)).collect(Collectors.toList());
        if (driversWithMaskedFirstNameAndOtherMandatoryDetails.isEmpty()) {
            throw new IllegalStateException("No driver available with a masked first name and other mandatory details.");
        }
        AppStore.Auto.Driver firstDriverWithMaskedFirstName = driversWithMaskedFirstNameAndOtherMandatoryDetails.get(0);
        String maskedFirstName = firstDriverWithMaskedFirstName.getFirstName();
        String lastName = firstDriverWithMaskedFirstName.getLastName();
        String maskedDOB = firstDriverWithMaskedFirstName.getDateOfBirth();
        String gender = firstDriverWithMaskedFirstName.getGender();
        String isLicenseIssuedInUS = firstDriverWithMaskedFirstName.isLicenseIssuedInUS() ? "Yes" : "No";
        String sqlQueryToGetUnmaskedFirstName = String.format("SELECT first_name FROM ffqdb.tquote_drivers WHERE quote_number='%s' AND masked_first_name='%s' AND last_name='%s' AND masked_date_of_birth='%s'", quoteNumber, maskedFirstName.replace("'", "''"), lastName.replace("'", "''"), maskedDOB);
        String unmaskedFirstName = DbHelper.queryPostgresGetFirstRow(sqlQueryToGetUnmaskedFirstName);
        String sqlQueryToGetUnmaskedDOB = String.format("SELECT date_of_birth FROM ffqdb.tquote_drivers WHERE quote_number='%s' AND masked_first_name='%s' AND last_name='%s' AND masked_date_of_birth='%s'", quoteNumber, maskedFirstName.replace("'", "''"), lastName.replace("'", "''"), maskedDOB);
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = inputFormat.parse(DbHelper.queryPostgresGetFirstRow(sqlQueryToGetUnmaskedDOB));
        SimpleDateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy");
        String unmaskedDOB = outputFormat.format(date);
        Map<String, String> driverDetails = new HashMap<>();
        driverDetails.put("firstName", unmaskedFirstName.substring(0, 1).toUpperCase() + unmaskedFirstName.substring(1).toLowerCase());
        driverDetails.put("lastName", lastName.substring(0, 1).toUpperCase() + lastName.substring(1).toLowerCase());
        driverDetails.put("dob", unmaskedDOB);
        driverDetails.put("gender", gender.equals("M") ? "Male" : "Female");
        driverDetails.put("isLicenseIssuedInUS", isLicenseIssuedInUS);
        return driverDetails;
    }

    public boolean isDriverFirstNameUnmasked(Map<String, String> driverDetails) throws Exception {
        String xpath = "//*[text()[contains(.,'" + driverDetails.get("firstName") + " " + driverDetails.get("lastName") + "')]]";
        List<Locator> elements = locators(pwXPath(xpath));
        return !elements.isEmpty() && isElementVisible(elements.get(0), 3);
    }

    public boolean isVehicleAddedSuccessfully(String expectedSnackbarSuccessMessage, boolean isStreamlinedState) throws Exception {
        if (isSnackBarMessageDisplayed(expectedSnackbarSuccessMessage)) {
            return true;
        } else if (isElementDisplayed(pwXPath(XPATH_FOR_DO_YOU_HAVE_MORE_VEHICLES_POPUP))) {
            clickCloseIcon();
            return true;
        } else if (isStreamlinedState) {
            VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
            if (vehiclesDriversInfoPage.isAddVehicleSideSheetOpen()) {
                return false;
            } else {
                return true; // Success snackbar is not displayed but the side sheet is closed which means vehicle got added hence return true
            }
        } else if (!isStreamlinedState) {
            WhoShouldWeInsurePage whoShouldWeInsurePage = new WhoShouldWeInsurePage();
            if (whoShouldWeInsurePage.isVehicleAdditionSideSheetVisible()) {
                return false;
            } else {
                return true; // Success snackbar is not displayed but the side sheet is closed which means vehicle got added hence return true
            }
        } else {
            return false;
        }
    }

    public boolean isDuplicateDriverErrorMessageDisplayed() {
        return isElementDisplayed(duplicateDriverErrorMessage, 2);
    }

    public void addVehicleDetailsWith2027YMM(AutoApplicant applicant, FarmersSoftAssert fsa) throws Exception {
        VehiclesDriversInfoPage vehiclesDriversInfoPage = new VehiclesDriversInfoPage();
        boolean isStreamlinedState = vehiclesDriversInfoPage.isVehiclesDriversConsolidationImpl(applicant.getStateCode());

        if (isStreamlinedState) {
            vehiclesDriversInfoPage.clickFirstVehicleEditLink();
            vehiclesDriversInfoPage.clickRemoveVinButton();
        } else {
            clickFirstVehicleEditLink();
            vehiclesDriversInfoPage.clickOnYMMButton();
        }
        vehiclesDriversInfoPage.check2027YearDetailsUsingYMM(applicant, fsa);
        vehiclesDriversInfoPage.clickVehicleSaveChangesButton();
    }
}
