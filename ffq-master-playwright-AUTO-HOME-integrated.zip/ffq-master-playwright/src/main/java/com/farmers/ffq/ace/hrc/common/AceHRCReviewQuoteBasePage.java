package com.farmers.ffq.ace.hrc.common;







import com.farmers.framework.playwright.WaitCondition;
import com.farmers.framework.playwright.PlaywrightWait;
import com.farmers.framework.playwright.Conditions;
import com.microsoft.playwright.TimeoutError;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.Locator;
import com.farmers.ffq.datatransferobjects.AppStore;
import com.farmers.ffq.datatransferobjects.AppStore.Home.Dropdowns.Quote.CoverageValue;
import com.farmers.ffq.utils.CurrencyFormat;
import com.farmers.ffq.utils.FarmersSoftAssert;
import com.farmers.framework.Property;
import com.farmers.framework.report.Log;
import java.util.*;
import java.util.stream.Collectors;

import static com.farmers.ffq.utils.CurrencyFormat.convertCurrencyStringToDouble;
import static com.farmers.ffq.utils.GlobalVariables.*;


public class AceHRCReviewQuoteBasePage extends AceHRCBasePage {

    //Static variables
    public static final String DEDUCTIBLES = "Deductibles";
    public static final String ALL_PERILS_COVERAGE_CODE = "A";

    private static final String PAGE_TITLE1 = "Here are your quotes";
    private static final String PAGE_TITLE2 = "Here is your quote";
    protected static final String EXPECTED_EDIT_DEDUCTIBLES_LINK_TEXT = "Edit deductibles";

    protected static final String EXPECTED_RECALCULATE_BUTTON_TEXT = "Recalculate";
    protected static final String EXPECTED_RESET_CHANGES_LINK_TEXT = "Reset changes";

    public static final String SCHEDULED_PAYMENT = "Scheduled payment";
    public static final String REPLACEMENT_COST = "Replacement cost";

    private static final String SEPARATING_STRING = Property.getTestProperty("browser").equals(SAFARI)? EMPTY_STRING : SPACE;
    protected static final String EXPECTED_PERSONAL_PROPERTY_DESCRIPTION = "This coverage, also known as Coverage C, can help replace your possessions " +
            "owned or used by an insured anywhere in the world subject to the policy provisions and special limits for things like jewelry, watches, " +
            "furs, firearms and computers. For a complete list, please check with your Farmers\u00ae representative." + SEPARATING_STRING +
            "Actual cash value (ACV) - The amount we may pay for repair or replacement is reduced to account for depreciation." + SEPARATING_STRING +
            "Replacement cost value (RCV) - The amount we may pay for repair or replacement does not deduct for depreciation.";
    protected static final String EXPECTED_PERSONAL_PROPERTY_DESCRIPTION_VA = "This coverage can help replace possessions owned or used by an insured " +
            "anywhere in the world, subject to the policy provisions and special limits for things like jewelry, watches, furs, firearms and computers. " +
            "For a complete list, please check with your Farmers\u00ae representative. Coverage for personal property is settled at Replacement Cost Value (RCV). " +
            "Farmers also offers settlement at Actual Cash Value, please contact your Farmers® representative for additional details on these options prior to purchase.";
    private static final String PAGE_TITLE_XPATH = "//app-home-quote-review//h1[text()=('" + PAGE_TITLE1 + "' or '" + PAGE_TITLE2 + "')]";
        private Locator quoteSummaryHeading = locator(pwXPath(PAGE_TITLE_XPATH));

        private Locator quoteSummarySubheading = locator(pwXPath("//app-home-quote-review//div[contains(@class,'tui-stacking-top-xl')]/div[contains(@class,'tui-stacking-top-md')]"));

    private static final String CHANGE_COVERAGE_XPATH = "//a[contains(text(),'coverage')]";
        private Locator linkChangeCoverage = locator(pwXPath(CHANGE_COVERAGE_XPATH));

        private Locator quotePriceOnCardDesktop = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tui-price"));
        private Locator quotePriceOnCardMobile = locator(pwXPath(QUOTE_PRESENTMENT_MOBILE_XPATH + "//tui-price"));

        protected Locator buttonContinueDesktop = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[contains(text(),'Continue')]"));
        protected Locator buttonContinueMobile = locator(pwXPath(QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[contains(text(),'Continue')]"));

        protected Locator buttonContinueMobileAtPageBottom = locator(pwXPath("//div[contains(@class,'quote-mobile-display')]//button[contains(text(),'Continue')]"));

    private static final String PRIMARY_COVERAGES_XPATH = "//tr/td[starts-with(text(),'Primary coverages')]/following-sibling::td";
        private Locator primaryCoveragesPriceOnCardDesktop = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + PRIMARY_COVERAGES_XPATH));
        private Locator primaryCoveragesPriceOnCardMobile = locator(pwXPath(QUOTE_PRESENTMENT_MOBILE_XPATH + PRIMARY_COVERAGES_XPATH));

    private static final String OPTIONAL_COVERAGES_XPATH = "//tr/td[starts-with(text(),'Optional coverages')]/following-sibling::td";
        private Locator quoteOptionalCoveragesPriceOnCardDesktop = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + OPTIONAL_COVERAGES_XPATH));
        private Locator quoteOptionalCoveragesPriceOnCardMobile = locator(pwXPath(QUOTE_PRESENTMENT_MOBILE_XPATH + OPTIONAL_COVERAGES_XPATH));

        private Locator quoteDiscountsOnCardDesktop = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//mat-list-item//div"));
        private Locator quoteDiscountsOnCardMobile = locator(pwXPath(QUOTE_PRESENTMENT_MOBILE_XPATH + "//mat-list-item//div"));

    private static final String VIEW_MONTHLY_PRICING_LINK_DESKTOP_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[text()='View monthly pricing']";
        private Locator linkViewMonthlyPricingDesktop = locator(pwXPath(VIEW_MONTHLY_PRICING_LINK_DESKTOP_XPATH));
    private static final String VIEW_MONTHLY_PRICING_LINK_MOBILE_XPATH = QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[text()='View monthly pricing']";
        private Locator linkViewMonthlyPricingMobile = locator(pwXPath(VIEW_MONTHLY_PRICING_LINK_MOBILE_XPATH));

        protected Locator expandQuoteCard = locator(pwXPath(QUOTE_PRESENTMENT_MOBILE_XPATH + "//mat-icon[@aria-label='expand quote card']"));
        protected Locator minimizeQuoteCard = locator(pwXPath(QUOTE_PRESENTMENT_MOBILE_XPATH + "//mat-icon[@aria-label='minimize quote card']"));

        private Locator dialogButtonOk = locator(pwXPath("//mat-dialog-container//button[text()='OK']"));

    private static final String PRESENTMENT_CARD_PRICE_HEADER_XPATH = "//div[contains(@class,'price-description')]";
        private Locator presentmentCardPriceHeaderDesktop = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + PRESENTMENT_CARD_PRICE_HEADER_XPATH));
        private Locator presentmentCardPriceHeaderMobile = locator(pwXPath(QUOTE_PRESENTMENT_MOBILE_XPATH + PRESENTMENT_CARD_PRICE_HEADER_XPATH));

    protected static final String RECALCULATE_BUTTON_DESKTOP_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[text()='Recalculate']";
        protected Locator recalculateButtonDesktop = locator(pwXPath(RECALCULATE_BUTTON_DESKTOP_XPATH));
    protected static final String RECALCULATE_BUTTON_MOBILE_XPATH = QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[text()='Recalculate']";
        protected Locator recalculateButtonMobile = locator(pwXPath(RECALCULATE_BUTTON_MOBILE_XPATH));

    private static final String VIEW_PAY_IN_FULL_PRICING_LINK_DESKTOP_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//div[starts-with(text(),'View pay-in-full pricing')]";
        private Locator linkViewPayInFullPricingDesktop = locator(pwXPath(VIEW_PAY_IN_FULL_PRICING_LINK_DESKTOP_XPATH));
    private static final String VIEW_PAY_IN_FULL_PRICING_LINK_MOBILE_XPATH = QUOTE_PRESENTMENT_MOBILE_XPATH + "//button[starts-with(text(),'View pay-in-full pricing')]";
        private Locator linkViewPayInFullPricingMobile = locator(pwXPath(VIEW_PAY_IN_FULL_PRICING_LINK_MOBILE_XPATH));

    private static final String PRESENTMENT_CARD_PRICE_HEADER = "12-month plan starting at";

        private Locator presentmentCardPriceHeader = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + PRESENTMENT_CARD_PRICE_HEADER_XPATH));

    private static final String VIEW_MONTHLY_PRICING_LINK_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//div[text()='View monthly pricing']";
        private Locator linkViewMonthlyPricing = locator(pwXPath(VIEW_MONTHLY_PRICING_LINK_XPATH));

    private static final String VIEW_PAY_IN_FULL_PRICING_LINK_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//div[starts-with(text(),'View pay-in-full pricing')]";
        private Locator linkViewPayInFullPricing = locator(pwXPath(VIEW_PAY_IN_FULL_PRICING_LINK_XPATH));

        private Locator linkPriceAlternative = locator(pwXPath("//button[@data-test-id='PRICE-ALTERNATIVE-BUTTON']"));

        private Locator quotePackagePriceOnCard = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[starts-with(text(),'Included coverages')]/following-sibling::td"));

        private Locator quoteAllOtherCoveragesPriceOnCard = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//tr/td[text()='Optional coverages']/following-sibling::td"));

        private Locator quoteDiscountsOnCard = locator(pwXPath(QUOTE_PRESENTMENT_DESKTOP_XPATH + "//mat-list-item//div"));
        private Locator policyDeductibleHeader = locator(pwXPath("//div[contains(@class,'main-content')]/div[1]"));
        protected Locator outOfPocketLossForCoveredLoss = locator(pwXPath("//div[contains(@class,'main-content')]/div[contains(@class,'tui-stacking-top-sm')]"));
        private Locator deductibleLabels = locator(pwXPath("//div[contains(@class,'deductible-label')]"));
        private Locator deductibleAmount = locator(pwXPath("//div[contains(@class,'deductible-amount')]"));
        private Locator allPerilsDeductibleInfoIcon = locator(pwXPath("//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_A']"));
        private Locator windAndHailDeductibleInfoIcon = locator(pwXPath("//button[@data-test-id='DEDUCTIBLE_INFO_BUTTON_W']"));
        private Locator deductibleMatDividers = locator(pwXPath("//div[contains(@class,'deductibles')]//mat-divider"));
        protected Locator editDeductibleIcon = locator(pwXPath("//button[contains(@class,'edit-deductibles-button')]//mat-icon"));
        protected Locator editDeductibleText = locator(pwXPath("//button[contains(@class,'edit-deductibles-button')]//span"));
        protected Locator editDeductibleButton = locator(pwXPath("//button[contains(@class,'edit-deductibles-button')]"));
        private Locator policyDeductibleHeaderInSideSheet = locator(pwXPath("//app-home-coverages-and-deductibles-info-dialog//h1"));
        private Locator closeIconPolicyDeductibleSideSheet = locator(pwXPath("//app-home-coverages-and-deductibles-info-dialog//button[@aria-label='Close']"));
        private Locator policyDeductibleTitlesInSideSheet = locator(pwXPath("//mat-panel-title//div"));
        private Locator policyDeductibleExplanationInSideSheet = locator(pwXPath("//div[contains(@class,'mat-expansion-panel-body')]//p[contains(@class,'tui-caption-text')][1]"));
        private Locator policyDeductibleSideSheetDividers = locator(pwXPath("//mat-accordion//mat-divider"));
        private Locator deductibleHeader = locator(pwXPath("//app-edit-home-deductibles-side-sheet//h1"));
        private Locator closeIconInDeductibleSideSheet = locator(pwXPath("//app-edit-home-deductibles-side-sheet//button//mat-icon"));
        private Locator allPerilLossesHeader = locator(pwXPath("//app-edit-home-deductibles-side-sheet//h2[1]"));
        private Locator allPerilLossesDescription = locator(pwXPath("//div[contains(@class,'tui-caption-text')][1]"));
        private Locator allPerilLossesRadioButtons = locator(pwXPath("//mat-radio-group[@name='allPerilsCoverageSelection']//mat-radio-button"));
        private Locator windAndHailLossesHeader = locator(pwXPath("//app-edit-home-deductibles-side-sheet//h2[2]"));
        private Locator windAndHailLossesDescription = locator(pwXPath("//div[contains(@class,'tui-caption-text')][2]"));
        private Locator windAndHailLossesRadioButtons = locator(pwXPath("//mat-radio-group[@name='windAndHailCoverageSelection']//mat-radio-button"));
        private Locator matDividerInDeductiblesSideSheet = locator(pwXPath("//app-edit-home-deductibles-side-sheet//mat-divider"));
    protected static final String RECALCULATE_BUTTON_XPATH = QUOTE_PRESENTMENT_DESKTOP_XPATH + "//button[text()='Recalculate']";
        private Locator recalculateButtonHomeLobSideSheet = locator(pwXPath("//button[@data-test-id='RECALCULATE_BUTTON']"));

        private Locator resetChangesButton = locator(pwXPath("//button[@data-test-id='OPEN_CONFIRM_RESET_DIALOG_BUTTON']"));
        private Locator recalculateButtonRentersCondoInSideSheet = locator(pwXPath("//button[contains(@class,'edit-coverage-dialog-submit-button')]"));
        private Locator resetChangesButtonRentersCondoInSideSheet = locator(pwXPath("//div[contains(@class,'coverages-docked-buttons')]//button[2]"));

        private Locator resetChangesHeader = locator(pwXPath("//h2[contains(@class,'reset-changes-heading')]"));
        private Locator areYouSureYouWantToResetChangesQuestion = locator(pwXPath("//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-content"));
        private Locator keepEditingButton = locator(pwXPath("//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-actions//button[1]"));
        private Locator resetButton = locator(pwXPath("//mat-dialog-container[@aria-label='Reset Changes Dialog']//tui-simple-dialog-actions//button[2]"));
        private Locator windAndHailDeductibleCannotBeLowerThanAllPerilError = locator(pwXPath("//mat-error[contains(@class,'home-quote-deductible__error-label')]"));
        private Locator closeIconInPolicyDeductibleSideSheet = locator(pwXPath("//app-home-coverages-and-deductibles-info-dialog//button[@aria-label='Close']"));
        private Locator standardPackageButton = locator(pwXPath("//div[@aria-label='Standard package']"));
        private Locator enhancedPackageButton = locator(pwXPath("//div[@aria-label='Enhanced package']"));
        private Locator premierPackageButton = locator(pwXPath("//div[@aria-label='Premier package']"));
        private Locator packageNameHeader = locator(pwXPath("//div[contains(@class,'package-body-content')]/div[1]"));
        private Locator packageSubTotalHeader = locator(pwXPath("//div[contains(@class,'package-body-content')]/div[2]"));
        private Locator packagePremiumAmount = locator(pwXPath("//div[contains(@class,'package-body-content')]/div[3]"));
        private Locator reducedCoverageForReducedPriceLabel = locator(pwXPath("//div[contains(@class,'package-body-content')]/div[4]"));
        private Locator comparePackageDoubleArrowIcon = locator(pwXPath("//button[contains(@class,'compare-button')]//mat-icon"));
        private Locator comparePackageButton = locator(pwXPath("//button[contains(@class,'compare-button')]"));
        private Locator coverageTypeLabels = locator(pwXPath("//div[contains(@class,'coverage-section-label')]"));
        private Locator coveragesLabels = locator(pwXPath("//div[contains(text(),'Coverages')]"));
        private Locator limitLabels = locator(pwXPath("//div[contains(text(),'Limits')]"));
        private Locator coverageNames = locator(pwXPath("//div[contains(@class,'coverage-description')]"));
        private Locator showSpecialLimitsLinkButton = locator(pwXPath("//button[@id='specialLimitsButton']//span"));
        private Locator showSpecialLimitsLinkPlusIcon = locator(pwXPath("//button[@id='specialLimitsButton']//mat-icon[text()='add' or text()='keyboard_arrow_down']"));
        private Locator coverageAmountValues = locator(pwXPath("//div[contains(@class,'coverage-amount')]"));

        private Locator coveragesHeader = locator(pwXPath("//div[@id='editCoverageDialogHeading']"));
        private Locator closeIconOnCoveragesSideSheet = locator(pwXPath("//div[contains(@class,'edit-coverage-dialog-heading')]//mat-icon"));
        private Locator allPerilsHeaderInCoverageSideSheet = locator(pwXPath("//div[contains(@class,'quote-coverages-slide-toggle__container')]/label"));

        private Locator allPerilExplanation = locator(pwXPath("//div[contains(@class,'quote-coverage__description')]"));
        private Locator allPerilMatRadioButtonInCoverageSideSheet = locator(pwXPath("//mat-radio-group[@id='__A__radio']//mat-radio-button"));

        private Locator uncheckedPerilMatRadioButtonInCoverageSideSheet = locator(pwXPath("//mat-radio-group[@id='__A__radio']//mat-radio-button[not(contains(@class,'checked'))]"));

    protected static final String EXPECTED_ALL_PERILS_HEADER_TEXT = "All perils";
    private static final String PACKAGE_TABS_XPATH = "//mat-tab-group//div[@role='tab' and @aria-label]";
    protected static final String EXPECTED_OUT_OF_POCKET_COST_FOR_COVERED_LOSS = "Your out-of-pocket cost for a covered loss.";
    protected static final String EXPECTED_ALL_PERILS_EXPLANATION_TEXT = "This deductible applies to all causes of loss, unless a separate deductible for a certain cause of loss is shown and selected.";

        private Locator saveInProgressFooter = locator(pwXPath("//div[contains(@class,'save-in-progress')]/p"));

        private Locator quoteNumberText = locator(pwXPath("//div[contains(@class,'save-quote')]"));

        private Locator continueButtonMobile = locator(pwXPath("//button[contains(@class,'tui-quote-presentment-minimized-button')] | //tui-quote-presentment//button"));

        private Locator continueButtonDesktop = locator(pwXPath("//tui-quote-presentment//button[not(contains(@class, 'inserted'))]"));

        private Locator coveragesLabel = locator(pwXPath("//div[contains(@class,'condo-renters-quote-coverages')]//p[1]"));
        private Locator limitsLabel = locator(pwXPath("//div[contains(@class,'condo-renters-quote-coverages')]//p[2]"));
        protected Locator condoRentersCoveragesNamesOnReviewQuotePage = locator(pwXPath("//div[contains(@class,'condo-renters-quote-coverages')]//div[contains(@class,'row')]/div[contains(@class,'tui-body') and not(contains(@class,'coverage-price-column'))]"));
        protected Locator condoRentersCoveragesAmountOnReviewQuotePage = locator(pwXPath("//div[contains(@class,'condo-renters-quote-coverages')]//div[contains(@class,'row')]/div[contains(@class,'tui-body') and contains(@class,'coverage-price-column')]"));
        protected Locator condoRentersAddEditCoverageLink = locator(pwXPath("//button[@id='editCoverageLink' and contains(text(),'Add/edit coverages')]"));
        protected Locator condoRentersCoverageSideSheetHeader = locator(pwXPath("//div[@id='editCoverageDialogHeading']"));
        protected Locator coverageHintEditCoverageSideSheet = locator(pwXPath("//app-edit-coverage//div[contains(@class,'tui-caption-text') and contains(@class,'mt-3')]"));
    protected static final String COVERAGE_DESCRIPTION_XPATH = "/ancestor::coverage-data-card//div[contains(@class,'quote-coverage__description')]";
    protected static final String PERSONAL_PROPERTY = "Personal property";
    protected static final String PERSONAL_PROPERTY_LABEL_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + PERSONAL_PROPERTY +"')]";
        protected Locator personalPropertyLabelInEditCoverageSideSheet = locator(pwXPath(PERSONAL_PROPERTY_LABEL_XPATH));
        protected Locator personalPropertyDescriptionLocator = locator(pwXPath(PERSONAL_PROPERTY_LABEL_XPATH + COVERAGE_DESCRIPTION_XPATH));
    protected static final String UNIT_OWNER_BUILDING_PROPERTY = "Unit owner's building property";
    protected static final String UNIT_OWNER_BUILDING_PROPERTY_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), 'building property')]";
        protected Locator unitOwnerBuildingPropertyLabelInEditCoverageSideSheet = locator(pwXPath(UNIT_OWNER_BUILDING_PROPERTY_XPATH));
        protected Locator unitOwnerBuildingPropertyDescriptionLocator = locator(pwXPath(UNIT_OWNER_BUILDING_PROPERTY_XPATH + COVERAGE_DESCRIPTION_XPATH));

    protected static final String LOSS_OF_USE_TEXT = "Loss of use";
    protected static final String LOSS_OF_USE = LOSS_OF_USE_TEXT + " (Additional living expense term)";
    protected static final String LOSS_OF_USE_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + LOSS_OF_USE_TEXT + "')]";
        protected Locator lossOfUseLabelInEditCoverageSideSheet = locator(pwXPath(LOSS_OF_USE_XPATH));
        protected Locator lossOfUseDescriptionLocator = locator(pwXPath(LOSS_OF_USE_XPATH + COVERAGE_DESCRIPTION_XPATH));
        protected Locator lossOfUseDropDownLocator = locator(pwXPath(LOSS_OF_USE_XPATH + "/ancestor::coverage-data-card//mat-select"));
        protected Locator lossOfUseDropDownPlaceHolder = locator(pwXPath(LOSS_OF_USE_XPATH + "/ancestor::coverage-data-card//mat-label"));
        protected Locator lossOfUseDropDownOptions = locator(pwXPath("//mat-option"));
        protected Locator lossOfUseDropDownOption = locator(pwXPath("//mat-option"));
        protected Locator selectedLossOfUseOptionLocator = locator(pwXPath("//mat-option[contains(@class,'item--selected')]"));

    protected static final String PERSONAL_LIABILITY = "Personal liability";
    protected static final String PERSONAL_LIABILITY_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + PERSONAL_LIABILITY + "')]";
        protected Locator personalLiabilityLabelInEditCoverageSideSheet = locator(pwXPath(PERSONAL_LIABILITY_XPATH));
        protected Locator personalLiabilityDescriptionLocator = locator(pwXPath(PERSONAL_LIABILITY_XPATH + COVERAGE_DESCRIPTION_XPATH));
        protected Locator personalLiabilityRadioButtonElements = locator(pwXPath(PERSONAL_LIABILITY_XPATH + "//ancestor::coverage-data-card//mat-radio-button"));
        protected Locator selectedPersonalLiabilityRadioButtonElement = locator(pwXPath(PERSONAL_LIABILITY_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]"));

    protected static final String MEDICAL_PAYMENT_TO_OTHERS = "Medical payments to others";
    protected static final String MEDICAL_PAYMENT_TO_OTHERS_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + MEDICAL_PAYMENT_TO_OTHERS + "')]";
        protected Locator medicalPaymentToOthersLabelInEditCoverageSideSheet = locator(pwXPath(MEDICAL_PAYMENT_TO_OTHERS_XPATH));
        protected Locator medicalPaymentToOthersDescriptionLocator = locator(pwXPath(MEDICAL_PAYMENT_TO_OTHERS_XPATH + COVERAGE_DESCRIPTION_XPATH));
        protected Locator medicalPaymentToOthersRadioButtonElements = locator(pwXPath(MEDICAL_PAYMENT_TO_OTHERS_XPATH + "//ancestor::coverage-data-card//mat-radio-button"));
        protected Locator selectedMedicalPaymentToOthersRadioButtonElement = locator(pwXPath(MEDICAL_PAYMENT_TO_OTHERS_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]"));

    public static final String LIMITED_MOLD = "Limited mold";
    protected static final String LIMITED_MOLD_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//span[contains(text(), '" + LIMITED_MOLD + "')]";
        protected Locator limitedMoldToggleButtonInEditCoverageSideSheet = locator(pwXPath(LIMITED_MOLD_XPATH + "//ancestor::mat-slide-toggle"));
        protected Locator limitedMoldLabelInEditCoverageSideSheet = locator(pwXPath(LIMITED_MOLD_XPATH));
        protected Locator limitedMoldDescriptionLocator = locator(pwXPath(LIMITED_MOLD_XPATH + COVERAGE_DESCRIPTION_XPATH));
        protected Locator limitedMoldRadioButtonElements = locator(pwXPath(LIMITED_MOLD_XPATH + "//ancestor::coverage-data-card//mat-radio-button"));
        protected Locator selectedLimitedMoldRadioButtonElement = locator(pwXPath(LIMITED_MOLD_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'mat-radio-checked')]"));

    protected static final String MINE_SUBSIDENCE = "Mine subsidence";
    protected static final String MINE_SUBSIDENCE_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + MINE_SUBSIDENCE + "')]";
        protected Locator mineSubsidenceLabelInEditCoverageSideSheet = locator(pwXPath(MINE_SUBSIDENCE_XPATH));
        protected Locator mineSubsidenceDescriptionLocator = locator(pwXPath(MINE_SUBSIDENCE_XPATH + COVERAGE_DESCRIPTION_XPATH));
        protected Locator mineSubsidenceCoveredValueLocator = locator(pwXPath(MINE_SUBSIDENCE_XPATH + COVERAGE_DESCRIPTION_XPATH + "//following::div[1]"));

    protected static final String INCREASE_LOSS_ASSESSMENT = "Increase of loss assessment";
    protected static final String INCREASE_LOSS_ASSESSMENT_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//span[contains(text(), '" + INCREASE_LOSS_ASSESSMENT + "')]";
        protected Locator increaseLossAssessmentToggleButtonInEditCoverageSideSheet = locator(pwXPath(INCREASE_LOSS_ASSESSMENT_XPATH + "//ancestor::mat-slide-toggle"));
        protected Locator increaseLossAssessmentLabelInEditCoverageSideSheet = locator(pwXPath(INCREASE_LOSS_ASSESSMENT_XPATH));
        protected Locator increaseLossAssessmentDescriptionLocator = locator(pwXPath(INCREASE_LOSS_ASSESSMENT_XPATH + COVERAGE_DESCRIPTION_XPATH));
        protected Locator increaseLossAssessmentCoverageLimitLocator = locator(pwXPath(INCREASE_LOSS_ASSESSMENT_XPATH + "/ancestor::coverage-data-card//p[contains(@class,'quote-coverage-limit')]"));
        protected Locator increaseLossAssessmentRadioButtonElements = locator(pwXPath(INCREASE_LOSS_ASSESSMENT_XPATH + "//ancestor::coverage-data-card//mat-radio-button"));
        protected Locator selectedIncreaseLossAssessmentRadioButtonElement = locator(pwXPath(INCREASE_LOSS_ASSESSMENT_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]"));

        protected Locator selectedDollarIncreaseLossAssessmentValue = locator(pwXPath(INCREASE_LOSS_ASSESSMENT_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]//p[1]"));
    protected static final String BUILDING_ORDINANCE = "Building ordinance or law";
    protected static final String BUILDING_ORDINANCE_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//span[contains(text(), '" + BUILDING_ORDINANCE + "')]";
        protected Locator buildingOrdinanceToggleButtonInEditCoverageSideSheet = locator(pwXPath(BUILDING_ORDINANCE_XPATH + "//ancestor::mat-slide-toggle"));
        protected Locator buildingOrdinanceLabelInEditCoverageSideSheet = locator(pwXPath(BUILDING_ORDINANCE_XPATH));
        protected Locator buildingOrdinanceDescriptionLocator = locator(pwXPath(BUILDING_ORDINANCE_XPATH + COVERAGE_DESCRIPTION_XPATH));
        protected Locator buildingOrdinanceRadioButtonElements = locator(pwXPath(BUILDING_ORDINANCE_XPATH + "//ancestor::coverage-data-card//mat-radio-button"));
        protected Locator selectedBuildingOrdinanceRadioButtonElement = locator(pwXPath(BUILDING_ORDINANCE_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]"));

        protected Locator selectedDollarBuildingOrdinanceValue = locator(pwXPath(BUILDING_ORDINANCE_XPATH + "//ancestor::coverage-data-card//mat-radio-button[contains(@class,'" + RADIO_BUTTON_CHECKED + "')]//p[1]"));


    protected static final String HOME_SHARING = "Home sharing business";
    protected static final String HOME_SHARING_XPATH = "//div[contains(@class,'quote-coverages-slide-toggle__container')]//label[contains(text(), '" + HOME_SHARING + "')]";
        protected Locator homeSharingLabelInEditCoverageSideSheet = locator(pwXPath(HOME_SHARING_XPATH));
        protected Locator homeSharingDescriptionLocator = locator(pwXPath(HOME_SHARING_XPATH + COVERAGE_DESCRIPTION_XPATH));
        protected Locator homeShariongCoveredValueLocator = locator(pwXPath(HOME_SHARING_XPATH + COVERAGE_DESCRIPTION_XPATH + "//following::div[1]"));

        private Locator youGetAllTheseWithYourHomePolicyTitle = locator(pwXPath("//app-home-policy-banner//mat-card/p[1]"));
    private static final String DEDUCTIBLES_SECTION_BASE = "//app-home-policy-banner//mat-card//div[contains(@class,'home-policy-banner_list-card')][1]";
        private Locator decliningDeductiblesIcon = locator(pwXPath(DEDUCTIBLES_SECTION_BASE + "//img"));
        private Locator decliningDeductiblesTitle = locator(pwXPath(DEDUCTIBLES_SECTION_BASE + "//span"));
        private Locator decliningDeductiblesDescription = locator(pwXPath(DEDUCTIBLES_SECTION_BASE + "//p[2]"));
    private static final String CLAIM_FORGIVENESS_SECTION_BASE = "//app-home-policy-banner//mat-card//div[contains(@class,'home-policy-banner_list-card')][2]";
    private static final String CLAIM_FORGIVENESS_SECTION_BASE_RENTERS = "//app-home-policy-banner//mat-card//div[contains(@class,'home-policy-banner_list-card')][1]";

        private Locator claimForgivenessIcon = locator(pwXPath(CLAIM_FORGIVENESS_SECTION_BASE + "//mat-icon"));
        private Locator claimForgivenessTitle = locator(pwXPath(CLAIM_FORGIVENESS_SECTION_BASE + "//div//p[1]"));
        private Locator claimForgivenessDescription = locator(pwXPath(CLAIM_FORGIVENESS_SECTION_BASE + "//div//p[2]"));
    private static final String CLAIM_FREE_SECTION_BASE = "//app-home-policy-banner//mat-card//div[contains(@class,'home-policy-banner_list-card')][3]";
    private static final String CLAIM_FREE_SECTION_BASE_RENTERS = "//app-home-policy-banner//mat-card//div[contains(@class,'home-policy-banner_list-card')][2]";

        private Locator claimFreeDiscountIcon = locator(pwXPath(CLAIM_FREE_SECTION_BASE + "//i"));
        private Locator claimFreeDiscountTitle = locator(pwXPath(CLAIM_FREE_SECTION_BASE + "//p[1]"));
        private Locator claimFreeDiscountDescription = locator(pwXPath(CLAIM_FREE_SECTION_BASE + "//p[2]"));
        protected Locator acvToggleButtonUnderPersonalProperty = locator(pwXPath("//button[@aria-label='ACV']"));
        protected Locator rcvToggleButtonUnderPersonalProperty = locator(pwXPath("//button[@aria-label='RCV']"));

    private static final String XPATH_TO_BUNDLE_PAGE_HEADER = "//h1";
        private Locator bundlePropertyQuoteReviewPageTitle = locator(pwXPath(XPATH_TO_BUNDLE_PAGE_HEADER));

        private Locator bundlePropertyQuoteReviewPageSubtitle = locator(pwXPath(XPATH_TO_BUNDLE_PAGE_HEADER + "/following-sibling::*[contains(@class, 'tui-stacking')]"));
    protected static final String PERSONAL_PROPERTY_KEY_WITH_RCV = PERSONAL_PROPERTY + " (Replacement cost value)";
    protected static final String PERSONAL_PROPERTY_KEY_WITH_ACV = PERSONAL_PROPERTY + " (Actual cost value)";
        protected Locator nextMorePropertyCoveragesButton = locator(pwXPath("//button[contains(text(),'Next: Review more')]"));
        protected Locator reviewMoreRentersCoveragesButton = locator(pwCss("button[class='tui-btn tui-btn-primary home-quote-start-checkout-button']"));
    protected static final String MONTHLY_AMOUNT_TEXT_XPATH = "//div[contains(text(),'" + MONTHLY_AMOUNT_TEXT + "')]";
        protected Locator monthlyAmountText = locator(pwXPath("//div[contains(text(),'*The amount shown applies when premium is paid automatically')]"));

    protected static final String MONTHLY_AMOUNT_TEXT_2_XPATH = "//div[contains(text(),'" + MONTHLY_AMOUNT_TEXT_PART2 + "')]";
        protected Locator monthlyAmount2Text = locator(pwXPath("//div[contains(text(),'is for insurance coverage you select')]"));
        protected Locator viewPricingLink = locator(pwXPath("//button[@id='priceAlternativeButton']"));

    protected static final String PERSONAL_PROPERTY_LIMIT = "Limit";

    /**
     * Constructor.
     *
     * @throws Exception if page() call fails
     */
    public AceHRCReviewQuoteBasePage() throws Exception {
    }

    public boolean isOnReviewQuotePage(boolean longWait) {
        waitForSkeletonToBeGone();
        if (longWait) {
            try {
                wait.until(Conditions.or(
                        Conditions.visible(linkChangeCoverage),
                        Conditions.visible(tryAgainButton)));
            } catch (TimeoutError te) {
                return false;
            }
        }
        return isElementVisible(linkChangeCoverage, 3);
    }

    public boolean isOnBundlePropertyReviewQuotePage() throws Exception {
        try {
            conditionalWait(5);
            wait.until(Conditions.or(
                    Conditions.visible(linkChangeCoverage),
                    Conditions.visible(editDeductibleButton)));
        } catch (TimeoutError te) {
            return false;
        }
        return true;
    }

    public String getQuotePriceOnCard() {
        if (isUseMobileViewEnabled()) {
            waitElementBeVisible(quotePriceOnCardMobile);
            return getTextFromElement(quotePriceOnCardMobile);
        } else {
            waitElementBeVisible(quotePriceOnCardDesktop);
            return getTextFromElement(quotePriceOnCardDesktop);
        }
    }

    public void clickOnContinueButton() {
        if (isUseMobileViewEnabled()) {
            waitAndClickElement(buttonContinueMobile);
        } else {
            waitAndClickElement(buttonContinueDesktop);
        }
    }

    public void clickContinueToMoreCoveragesButton() {
        scrollToBottomOfPage();
        clickElement(nextMorePropertyCoveragesButton);
    }

    public void clickReviewMoreRentersCoveragesButton() {
        scrollToBottomOfPage();
        clickElement(reviewMoreRentersCoveragesButton);
    }

    public String getPrimaryCoveragesOnCard() {
        try {
            if (isUseMobileViewEnabled()) {
                if (isElementDisplayed(expandQuoteCard, 2)) {
                    waitAndClickElement(expandQuoteCard);
                }
                waitElementBeVisible(primaryCoveragesPriceOnCardMobile);
            } else {
                waitElementBeVisible(primaryCoveragesPriceOnCardDesktop);
            }
        } catch (PlaywrightException e) {
            waitForUiSettled();
        }
        if (isUseMobileViewEnabled()) {
            return getTextFromElement(primaryCoveragesPriceOnCardMobile);
        } else {
            return getTextFromElement(primaryCoveragesPriceOnCardDesktop);
        }
    }

    public String getAllOtherCoveragesPriceOnCard() {
        try {
            if (isUseMobileViewEnabled()) {
                if (isElementDisplayed(expandQuoteCard, 2)) {
                    waitAndClickElement(expandQuoteCard);
                }
                waitElementBeVisible(quoteOptionalCoveragesPriceOnCardMobile);
            } else {
                waitElementBeVisible(quoteOptionalCoveragesPriceOnCardDesktop);
            }
        } catch (PlaywrightException e) {
            waitForUiSettled();
        }
        if (isUseMobileViewEnabled()) {
            return getTextFromElement(quoteOptionalCoveragesPriceOnCardMobile);
        } else {
            return getTextFromElement(quoteOptionalCoveragesPriceOnCardDesktop);
        }
    }

    public String getDiscountsOnCard() {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard,2)) {
                waitAndClickElement(expandQuoteCard);
            }
            waitElementBeVisible(quoteDiscountsOnCardMobile);
            return getTextFromElement(quoteDiscountsOnCardMobile);
        } else {
            waitElementBeVisible(quoteDiscountsOnCardDesktop);
            return getTextFromElement(quoteDiscountsOnCardDesktop);
        }
    }

    public void clickViewMonthlyPricing() {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard,2)) {
                waitAndClickElement(expandQuoteCard);
            }
            waitAndClickElement(linkViewMonthlyPricingMobile);
        } else {
            waitAndClickElement(linkViewMonthlyPricingDesktop);
        }
    }

    public void clickPriceAlternative() {
        clickElement(linkPriceAlternative);
    }

    public boolean isViewMonthlyPricingLink() throws Exception {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard,2)) {
                waitAndClickElement(expandQuoteCard);
            }
            return isElementPresent(pwXPath(VIEW_MONTHLY_PRICING_LINK_MOBILE_XPATH));
        } else {
            return isElementPresent(pwXPath(VIEW_MONTHLY_PRICING_LINK_DESKTOP_XPATH));
        }
    }

    public boolean isViewPayInFullPricingLink() throws Exception {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard,2)) {
                waitAndClickElement(expandQuoteCard);
            }
            return isElementPresent(pwXPath(VIEW_PAY_IN_FULL_PRICING_LINK_MOBILE_XPATH));
        } else {
            return isElementPresent(pwXPath(VIEW_PAY_IN_FULL_PRICING_LINK_DESKTOP_XPATH));
        }
    }

    public void clickViewPayInFullPricing() {
        if (isUseMobileViewEnabled()) {
            if (isElementDisplayed(expandQuoteCard,2)) {
                waitAndClickElement(expandQuoteCard);
            }
            waitAndClickElement(linkViewPayInFullPricingMobile);
        } else {
            waitAndClickElement(linkViewPayInFullPricingDesktop);
        }
    }

    public boolean isPresentmentCardPriceHeader() {
        if (isUseMobileViewEnabled()) {
            return getTextFromElement(presentmentCardPriceHeaderMobile).equals(PRESENTMENT_CARD_PRICE_HEADER);
        } else {
            return getTextFromElement(presentmentCardPriceHeaderDesktop).equals(PRESENTMENT_CARD_PRICE_HEADER);
        }
    }

    public void waitContinueButtonVisibleClickable() {
        if (isUseMobileViewEnabled()) {
            waitElementBeVisibleClickable(buttonContinueMobile);
        } else {
            waitElementBeVisibleClickable(buttonContinueDesktop);
        }
    }

    public boolean isViewMonthlyPricingLinkPresent() throws Exception {
        return isElementPresent(pwXPath(VIEW_MONTHLY_PRICING_LINK_XPATH));
    }

    public void selectRatePackage(String ratePackage) throws Exception {
        Locator we = locator(pwXPath(PACKAGE_TABS_XPATH + "[.='" + ratePackage + "']"));
        waitAndClickElement(we);
    }

    public void clickEditDeductiblesLink() {
        Log.info("Clicking on edit deductible button");
        waitAndClickElement(editDeductibleButton);
    }

    public void clickOnCloseIconInPolicyDeductibleSideSheet() {
        waitAndClickElement(closeIconPolicyDeductibleSideSheet);
    }

    public int getNumberOfPackageTabs() throws Exception {
        return locators(pwXPath(PACKAGE_TABS_XPATH)).size();
    }

    public String getSelectedPackage() throws Exception {
        List<Locator> packageTabs = locators(pwXPath(PACKAGE_TABS_XPATH));
        for (Locator tab : packageTabs) {
            if (getAttributeData(tab, ARIA_SELECTED).equals(LOWERCASE_TRUE)) {
                return getTextFromElement(tab);
            }
        }
        return null;
    }

    public void clickRecalculateButtonHomeLobInSideSheet() {
        waitAndClickElement(recalculateButtonHomeLobSideSheet);
        Log.info("Clicked recalculate button in the side sheet.");
        waitForPageToBeReady();
        if (isTryAgainPagePresent() && !wasTryAgainSuccessful()) {
            waitAndClickElement(tryAgainButton);
        }
    }
    public void clickRecalculateButtonCondoRentersInSideSheet() {
        waitAndClickElement(recalculateButtonRentersCondoInSideSheet);
        Log.info("Clicked recalculate button in side sheet.");
        waitForPageToBeReady();
        if (isTryAgainPagePresent() && !wasTryAgainSuccessful()) {
            waitAndClickElement(tryAgainButton);
        }
    }

    public void clickResetChangesButtonCondoRentersInSideSheet() {
        waitAndClickElement(resetChangesButtonRentersCondoInSideSheet);
        Log.info("Clicking reset changes button in side sheet.");
    }



    public void clickResetChangesButtonHomeLob() {
        waitAndClickElement(resetChangesButton);
    }

    public void clickKeepEditingButton() {
        waitAndClickElement(keepEditingButton);
        Log.info("Clicking keep editing button in reset changes pop up.");
    }

    public void clickResetValueButton() {
        waitAndClickElement(resetButton);
        Log.info("Clicking reset button in reset changes pop up.");
    }

    public void clickCloseIconOnDeductibleSideSheet() {
        waitAndClickElement(closeIconInDeductibleSideSheet);
    }

    public void clickOnStandardPackage() {
        waitAndClickElement(standardPackageButton);
    }
    public void clickOnEnhancedPackage() {
        waitAndClickElement(enhancedPackageButton);
    }
    public void clickOnPremierPackage() {
        waitAndClickElement(premierPackageButton);
    }

    public void changeBundleQuotePricing(String pricing) {
        if (isElementDisplayed(bundleQuoteContainer, 3)) {
            String breakpoint = isUseMobileViewEnabled() || isMobileApplication() ? "mobile" : "desktop";
            try {
                Locator fullPriceForPropertyLink = bundleQuoteContainer.locator(pwXPath(String.format(CARD_XPATH_STRING + "//a", breakpoint)));
                if (getTextFromElement(fullPriceForPropertyLink).contains(pricing.toLowerCase())) {
                    clickElement(fullPriceForPropertyLink);
                }
            } catch (Exception e) {
                Log.info("findElement exception, continue");
            }
        }
    }

    public void showOrHideSpecialLimitsSection(boolean showSection) {
        if (isElementDisplayed(showSpecialLimitsLinkPlusIcon, 2) == showSection) {
            scrollAndClickOnElement(showSpecialLimitsLinkButton);
        }
    }

    public void clickOnLossOfUseDropDown(){
        waitAndClickElement(lossOfUseDropDownLocator);
    }

    protected Locator getCheckedAllPerilLossesCoverageValue(Locator allPerilLossesRadioButtons) {
        List<Locator> checkedCoverageElement = allPerilLossesRadioButtons.all().stream().filter(i -> getAttributeData(i, CLASS).contains(RADIO_BUTTON_CHECKED)).collect(Collectors.toList());
        return checkedCoverageElement.get(0);
    }

    protected List<String> expectedCoveragesValue(String coverageCode, String lobType) throws Exception {
        AppStore.Home appStore = getSessionStorageAppStore().getHome();
        List<CoverageValue> coverageValues = appStore.getDropdowns().getQuote().getCoverageValues().stream().filter(i -> i.getCoverageCode().equals(coverageCode)).collect(Collectors.toList());
        List<String> expectedCoverageValues = coverageValues.get(0).getValues().stream().map(CoverageValue.Value::getAmount).collect(Collectors.toList());
        if(lobType.equals(CONDO) || lobType.equals(RENTERS)){
            expectedCoverageValues.sort(Comparator.comparing(Integer::parseInt));
        }

        String valueToSet;
        int dwellingCoverageValue = 0;
        if (appStore.getDwellingCoverage() != null) {
            dwellingCoverageValue = Integer.parseInt(appStore.getDwellingCoverage());
        }
        int numberOfExpectedValues = expectedCoverageValues.size();
        for (int i = 0; i < numberOfExpectedValues; i++) {
            String expectedCoverageValuesInPercentage = expectedCoverageValues.get(i);
            if (expectedCoverageValuesInPercentage.contains("%")) {
                String stringMultiplier = expectedCoverageValuesInPercentage.replaceAll("[%]", EMPTY_STRING);
                double multiplier = Double.valueOf(stringMultiplier);

                // convert 1.0% into 1% etc
                if(expectedCoverageValuesInPercentage.length() >= 3){
                    expectedCoverageValuesInPercentage = expectedCoverageValuesInPercentage.replaceAll("\\.0", EMPTY_STRING);
                }

                valueToSet = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf((multiplier * dwellingCoverageValue) / 100)) +
                        SPACE + "(" + expectedCoverageValuesInPercentage + " of Dwelling limit)";

                expectedCoverageValues.set(i, valueToSet);
            } else {
                valueToSet = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(expectedCoverageValues.get(i));
                expectedCoverageValues.set(i, valueToSet);
            }
        }
        return expectedCoverageValues.stream()
                .sorted(Comparator.comparingDouble(s -> Double.parseDouble(s.split(SPACE)[0].replaceAll("[^\\d.]", EMPTY_STRING))))
                .collect(Collectors.toList());
    }

    public void validateContentOfResetChangesPopUp(FarmersSoftAssert sa) {
        String expectedResetChangesHeader = "Reset changes";
        sa.assertEquals(getTextFromElement(resetChangesHeader), expectedResetChangesHeader, "Reset changes header check in reset changes pop up.");

        String expectedAreYouSureYouWantToResetValuesQuestion = "Are you sure you want to reset all to default values?";
        sa.assertEquals(getTextFromElement(areYouSureYouWantToResetChangesQuestion), expectedAreYouSureYouWantToResetValuesQuestion, "Are you sure you want to reset all to default values? question text check");

        String expectedKeepEditingText = "Keep editing";
        sa.assertEquals(getTextFromElement(keepEditingButton), expectedKeepEditingText, "Keep editing button text check");

        String expectedResetValueText = "Reset value";
        sa.assertEquals(getTextFromElement(resetButton), expectedResetValueText, "Reset value text check");
    }

    public void validateQuoteSavedText(String quoteNumber, FarmersSoftAssert sa) {
        final String EXPECTED_QUOTE_PROGRESS_SAVED = "Quote progress is saved!";
        sa.assertEquals(getTextFromElement(saveInProgressFooter), EXPECTED_QUOTE_PROGRESS_SAVED, "Quote progress text is verified.");
        String quoteNumberDisplayed = getTextFromElement(quoteNumberText).replaceAll("\\D", EMPTY_STRING);
        sa.assertEquals(quoteNumberDisplayed, quoteNumber, "Quote number and Quote progress is saved text are displayed.");
    }

    public void clickCloseIconOnCoveragesSideSheet() {
        waitAndClickElement(closeIconOnCoveragesSideSheet);
    }

    public void clickOnLimitedMoldToggleButton(){
        scrollToElement(limitedMoldToggleButtonInEditCoverageSideSheet);
        waitAndClickElement(limitedMoldToggleButtonInEditCoverageSideSheet);
    }
    public void clickOnIncreaseLossAssessmentToggleButton(){
        scrollToElement(increaseLossAssessmentToggleButtonInEditCoverageSideSheet);
        waitAndClickElement(increaseLossAssessmentToggleButtonInEditCoverageSideSheet);
    }
    public void clickOnBuildingOrdinanceToggleButton(){
        scrollToElement(buildingOrdinanceToggleButtonInEditCoverageSideSheet);
        waitAndClickElement(buildingOrdinanceToggleButtonInEditCoverageSideSheet);
    }


    public void validateContentOfDeductiblesSideSheet(FarmersSoftAssert fsa, String lobType) throws Exception {
        fsa.assertEquals(getTextFromElement(coveragesHeader), DEDUCTIBLES, "Coverages header text check - " + lobType + " lob.");
        waitElementBeVisible(closeIconOnCoveragesSideSheet);
        fsa.assertTrue(closeIconOnCoveragesSideSheet.isVisible(), "Close icon displayed in coverage side sheet - " + lobType + " lob.");

        fsa.assertEquals(getTextFromElement(allPerilsHeaderInCoverageSideSheet), EXPECTED_ALL_PERILS_HEADER_TEXT, "All peril header inside condo coverage side sheet check - " + lobType + " lob.");
        fsa.assertEquals(getTextFromElement(allPerilExplanation), EXPECTED_ALL_PERILS_EXPLANATION_TEXT, "All peril explanation inside condo coverage side sheet check - " + lobType + " lob.");
        Log.info("Validating deductibles header, close icon, all perils header, all peril description in deductible side sheet for " + lobType);

        List<String> foundCoverageValuesForAllPerilLosses = allPerilMatRadioButtonInCoverageSideSheet.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        fsa.assertEquals(getSortedList(foundCoverageValuesForAllPerilLosses), getSortedList(expectedCoveragesValue(ALL_PERILS_COVERAGE_CODE, lobType)), "All peril losses coverage values matching - " + lobType + " lob.");
        Log.info("Validating all peril loss radio button options are displayed as expected in deductible side sheet for " + lobType);

        // select first unchecked radio button
        Locator firstUncheckedMatRadioButton = uncheckedPerilMatRadioButtonInCoverageSideSheet.nth(0);

        String firstToBeSelectedRadioButtonText = getTextFromElement(firstUncheckedMatRadioButton);
        waitAndClickElement(firstUncheckedMatRadioButton);
        if(!getAttributeData(firstUncheckedMatRadioButton, CLASS).contains(RADIO_BUTTON_CHECKED)) {
            waitAndClickElement(firstUncheckedMatRadioButton);
        }
        Log.info("Selecting all peril loss button in side sheet to " + firstToBeSelectedRadioButtonText + " in order to validate recalculate and reset text in deductible side sheet.");
        validateRecalculateResetButtonTextInSideSheet(fsa, lobType);

        clickResetChangesButtonCondoRentersInSideSheet();
        validateContentOfResetChangesPopUp(fsa);
        clickKeepEditingButton();
        clickResetChangesButtonCondoRentersInSideSheet();
        clickResetValueButton();
        firstUncheckedMatRadioButton = uncheckedPerilMatRadioButtonInCoverageSideSheet.nth(0);
        waitAndClickElement(firstUncheckedMatRadioButton);
        if(!getAttributeData(firstUncheckedMatRadioButton, CLASS).contains(RADIO_BUTTON_CHECKED)) {
            waitAndClickElement(firstUncheckedMatRadioButton);
        }
        Log.info("Selecting all peril loss button in side sheet to " + firstToBeSelectedRadioButtonText + " in order to validate the updated deductible value in main review quote page.");
        waitForUiSettled();
        clickRecalculateButtonCondoRentersInSideSheet();
        waitForSpinnerToBeGone();
        waitForUiSettled();
        String deductibleAmountValue = getAllPerilDeductible();
        fsa.assertEquals(deductibleAmountValue, firstToBeSelectedRadioButtonText, "Default all peril losses selection check - " + lobType + " lob.");
    }


    public void validateRecalculateResetButtonTextInSideSheet(FarmersSoftAssert sa, String lobType){
        sa.assertTrue(recalculateButtonRentersCondoInSideSheet.isVisible(), "Recalculate button displayed - " + lobType + " lob.");
        sa.assertTrue(resetChangesButtonRentersCondoInSideSheet.isVisible(), "Reset changes button displayed - " + lobType + " lob.");
        sa.assertEquals(getTextFromElement(recalculateButtonRentersCondoInSideSheet), EXPECTED_RECALCULATE_BUTTON_TEXT, "Recalculate button text check - " + lobType + " lob.");
        sa.assertEquals(getTextFromElement(resetChangesButtonRentersCondoInSideSheet), EXPECTED_RESET_CHANGES_LINK_TEXT, "Reset changes button text check - " + lobType + " lob.");
    }

    public String editDeductiblesSideSheet() {
        String allPeril = getTextFromElement(waitElementBeVisible(deductibleAmount.nth(1)));

        clickEditDeductiblesLink();
        Locator we = allPerilMatRadioButtonInCoverageSideSheet.all().stream().filter(el -> !getTextFromElement(el).equals(allPeril)).findAny().get();
        Log.info("Randomly selecting All perils deductible value: " + getTextFromElement(we));
        waitAndClickElement(we);
        waitAndClickElement(we);
        clickRecalculateButtonCondoRentersInSideSheet();
        waitForSpinnerToBeGone();
        waitForUiSettled();
        return getAllPerilDeductible();
    }

    public String getAllPerilDeductible() {
        return getTextFromElement(deductibleAmount.nth(1));
    }

    public String getPersonalPropertyValue() throws Exception {
        return getSessionStorageAppStore().getHome().getCoverageForPackage("C", "EFT").getCvgInfoForCvgDesc(PERSONAL_PROPERTY).getCvgAmt();
    }

    @Override
    public void clickContinueButton() {
        if (isUseMobileViewEnabled()) {
            scrollAndClickOnElement(continueButtonMobile);
            if (this.isOnReviewQuotePage(false)) {
                waitAndClickElement(continueButtonMobile);
            }
        } else {
        	scrollAndClickOnElement(continueButtonDesktop);
            if (this.isOnReviewQuotePage(false)) {
                waitAndClickElement(continueButtonDesktop);
            }
        }
        waitForSpinnerToBeGone();
        testStep("Clicked continue button on Review quote page");
    }

    public void clickOnAddEditCoverageLinkButton(){
        waitAndClickElement(condoRentersAddEditCoverageLink);
        Log.info("Clicking add edit coverage link for Condo/Renters lob.");
    }

    public List<String> getCoverageValuesByCoverageDescription(String coverageDescription) throws Exception {
        List<CoverageValue> coverageValues = getSessionStorageAppStore().getHome().getDropdowns().getQuote().getCoverageValues();
        CoverageValue coverageValueByDescription = coverageValues.stream().filter(i -> i.getCoverageDescription().equalsIgnoreCase(coverageDescription)).collect(Collectors.toList()).get(0);
        List<String> coverageValueAmount = coverageValueByDescription.getValues().stream().map(i -> i.getAmount()).collect(Collectors.toList());
        List<String> coverageValueAmountNoCoverageAmount = coverageValueAmount.stream().filter(i -> !i.equals("No Coverage")).collect(Collectors.toList());
        return coverageValueAmountNoCoverageAmount;
    }

    public void validateCommonContentFromEditCoverageSideSheetCondoRentersLob(FarmersSoftAssert sa, String lobType, String expectedRentersCoveragesHeader){
        waitElementBeVisible(condoRentersCoverageSideSheetHeader);
        sa.assertEquals(getTextFromElement(condoRentersCoverageSideSheetHeader), expectedRentersCoveragesHeader, lobType + " coverages header check - " + lobType);
        //        sa.assertTrue(closeIconInCondoRentersCoverageSideSheet.isVisible(), "Close icon is not visible in condo edit coverage side sheet - " + lobType);

        String expectedCoveragesHintInEditCoverageSideSheet = "The coverage descriptions provided are general descriptions of available coverage and are not a statement of contract.";
        sa.assertEquals(getTextFromElement(coverageHintEditCoverageSideSheet), expectedCoveragesHintInEditCoverageSideSheet, lobType + " coverages hint text check - " + lobType);

        Log.info("Validating condo/renters header and description in Renters/Condo side sheet");
    }
    protected String getCoveragePriceByNameFromScreen (String coverageName) throws Exception {
        String COVERAGE_VALUE_XPATH = "//div[contains(@class,'tui-body') and contains(text(),'" + coverageName + "')]/following-sibling::div[contains(@class,'coverage-price-column')]";
        return getTextFromElement(locator(pwXPath(COVERAGE_VALUE_XPATH)));
    }

    public void validateLossOfUseSection(FarmersSoftAssert sa, Map<String, String> coverageAmountKeyValuePair, String stateCode, String lobType) throws Exception {
        String LOSS_OF_USE = getLossOfUseCoverageName(stateCode);
        sa.assertTrue(lossOfUseLabelInEditCoverageSideSheet.isVisible(), LOSS_OF_USE + " label displayed in edit coverage side sheet - " + lobType);
        String lossOfUseDescription = "This coverage, also known as Coverage D, may pay you for an increase in living expenses (housing, food, etc.)" +
                " you incur while your residence is being repaired as a result of a covered loss up to the number of months selected.";
        sa.assertEquals(getTextFromElement(lossOfUseDescriptionLocator), lossOfUseDescription, LOSS_OF_USE + " description check - " + lobType);

        sa.assertTrue(lossOfUseDropDownLocator.isVisible(), LOSS_OF_USE + " drop down element is not present in side sheet - " + lobType);

        String expectedLossOfUsePlaceHolderText = "Loss of use / additional living expenses";
        sa.assertEquals(getTextFromElement(lossOfUseDropDownPlaceHolder), expectedLossOfUsePlaceHolderText, LOSS_OF_USE + " drop down element place holder text check in side sheet - " + lobType);

        clickOnLossOfUseDropDown();

        if (lobType.equals(RENTERS)) {
            validateLossOfUseDropdownValue(sa, stateCode);
        }
        List<String> foundLossOfUseDropDownOptions = lossOfUseDropDownOptions.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
        String lossOfUseCoverageValue = coverageAmountKeyValuePair.get(LOSS_OF_USE);
        List<String> lossOfUseDropDownOptionsWithCurrencyFormat = getFormattedDropDownOptionsForLossOfUse(stateCode);
        sa.assertEquals(lossOfUseDropDownOptionsWithCurrencyFormat,foundLossOfUseDropDownOptions, LOSS_OF_USE + " drop down values are not matching - " + lobType);
        sa.assertEquals(getTextFromElement(selectedLossOfUseOptionLocator).replace("/ ", EMPTY_STRING), lossOfUseCoverageValue.replaceAll("[()]", EMPTY_STRING),
                LOSS_OF_USE + " drop down selected values are not matching - " + lobType);
        waitAndClickElement(selectedLossOfUseOptionLocator);
    }

    public List<String> getFormattedDropDownOptionsForLossOfUse(String stateCode) throws Exception {
        List<String> lossOfUseAmountWithoutNoCoverageAmount = getCoverageValuesByCoverageDescription(getLossOfUseCoverageName(stateCode));
        List<String> lossOfUseAmountWithoutDollarSign = lossOfUseAmountWithoutNoCoverageAmount.stream().map(i -> i.replace("$", "")).collect(Collectors.toList());
        List<Integer> lossOfUseAmountInNumericForm = lossOfUseAmountWithoutDollarSign.stream().map(Integer::parseInt).collect(Collectors.toList());

        int personalPropertyValue = getPersonalPropertyValueFromAppStore();

        List<String> lossOfUseDropDownOptionsWithCurrencyFormat = new ArrayList<>();
        if(stateCode.equals(VA)){
            for (int i = 0; i < lossOfUseAmountInNumericForm.size(); i++){
            int lossOfUseCoverageAmount = personalPropertyValue*lossOfUseAmountInNumericForm.get(i)/100;
            String currencyFormatAmount = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(lossOfUseCoverageAmount));
            lossOfUseDropDownOptionsWithCurrencyFormat.add(currencyFormatAmount);
            }
        }else{
            List<String> lossOfUseTerms = stateCode.equals(CO) ? Arrays.asList("24 months") : Arrays.asList("12 months", "24 months");
            for (int i = 0; i < lossOfUseTerms.size(); i++){
            for (int j = 0; j < lossOfUseAmountInNumericForm.size(); j++){
                int lossOfUseCoverageAmount = personalPropertyValue*lossOfUseAmountInNumericForm.get(j)/100;
                String currencyFormatAmount = CurrencyFormat.convertStringIntoCurrencyFormatWithoutDecimal(String.valueOf(lossOfUseCoverageAmount));
                lossOfUseDropDownOptionsWithCurrencyFormat.add(currencyFormatAmount + " / " + lossOfUseTerms.get(i));
            }
            }
        }
        return lossOfUseDropDownOptionsWithCurrencyFormat;
    }

    public void validatePersonalLiabilitySection(FarmersSoftAssert sa, Map<String, String> coverageAmountKeyValuePair, String lobType) throws Exception {
        sa.assertTrue(personalLiabilityLabelInEditCoverageSideSheet.isVisible(), PERSONAL_LIABILITY + " label displayed in edit coverage side sheet - " + lobType );
        String personalLiabilityDescription = "As set forth in your policy, this coverage, also known as Coverage E, " +
            "can pay damages an insured becomes legally obligated to pay because of bodily injury or property damage to others that results from an occurrence.";
        sa.assertEquals(getTextFromElement(personalLiabilityDescriptionLocator), personalLiabilityDescription, PERSONAL_LIABILITY + " description check - " + lobType);
        String personalLiabilityCoverageValue = coverageAmountKeyValuePair.get(PERSONAL_LIABILITY);

        List<String> foundPersonalLiabilityRadioOptions = personalLiabilityRadioButtonElements.all().stream().map(this::getTextFromElement).collect(Collectors.toList());

        List<String> personalLiabilityCoverageValueAmountFromAppStore = getCoverageValuesByCoverageDescription(PERSONAL_LIABILITY);
        sa.assertEquals(personalLiabilityCoverageValueAmountFromAppStore, foundPersonalLiabilityRadioOptions, PERSONAL_LIABILITY + " coverage amount options are not matching in the radio selection group - " + lobType);
        sa.assertEquals(getTextFromElement(selectedPersonalLiabilityRadioButtonElement), personalLiabilityCoverageValue, PERSONAL_LIABILITY + " selected coverage amount radio button is not checked - " + lobType);
        Log.info("Validating " + PERSONAL_LIABILITY + " coverage header/description, available coverages radio button options and selected radio button value on coverages side sheet.");
    }

    public void validateMedicalPaymentToOthersSection(FarmersSoftAssert sa, Map<String, String> coverageAmountKeyValuePair, String lobType) throws Exception {
        sa.assertTrue(medicalPaymentToOthersLabelInEditCoverageSideSheet.isVisible(), MEDICAL_PAYMENT_TO_OTHERS + " label displayed in edit coverage side sheet - " + lobType );
        String medicalPaymentToOthersDescription = "This coverage, also known as Coverage F, can pay medical costs, " +
            "up to the limit selected by you, for guests who are injured at your residence, regardless of your legal liability.";
        sa.assertEquals(getTextFromElement(medicalPaymentToOthersDescriptionLocator), medicalPaymentToOthersDescription, MEDICAL_PAYMENT_TO_OTHERS + " description check - " + lobType);
        String medicalPaymentToOthersCoverageValue = coverageAmountKeyValuePair.get(MEDICAL_PAYMENT_TO_OTHERS);

        List<String> foundMedicalPaymentToOthersRadioOptions = medicalPaymentToOthersRadioButtonElements.all().stream().map(i -> getTextFromElement(i)).collect(Collectors.toList());

        List<String> medicalPaymentToOthersCoverageValueAmountFromAppStore = getCoverageValuesByCoverageDescription(MEDICAL_PAYMENT_TO_OTHERS);

        sa.assertEquals(medicalPaymentToOthersCoverageValueAmountFromAppStore, foundMedicalPaymentToOthersRadioOptions, MEDICAL_PAYMENT_TO_OTHERS + " coverage amount options are not matching in the radio selection group - " + lobType);
        sa.assertEquals(getTextFromElement(selectedMedicalPaymentToOthersRadioButtonElement), medicalPaymentToOthersCoverageValue, MEDICAL_PAYMENT_TO_OTHERS + " selected coverage amount radio button is not checked - " + lobType);
        Log.info("Validating " + MEDICAL_PAYMENT_TO_OTHERS + " coverage header/description, available coverages radio button options and selected radio button value on coverages side sheet.");
    }

    public String randomlySelectLossOfUseFromDropDown(){
        scrollAndClickOnElement(lossOfUseDropDownLocator);
        waitElementBeVisible(lossOfUseDropDownOption);
        Random random = new Random();
        int index = random.nextInt(lossOfUseDropDownOptions.count());
        waitAndClickElement(lossOfUseDropDownOptions.nth(index));
        return getTextFromElement(lossOfUseDropDownLocator).replace(" /", EMPTY_STRING);
    }

    public String randomlySelectPersonalLiabilityRadioButton(){
        scrollToElement(personalLiabilityDescriptionLocator);
        Random random = new Random();
        int index = random.nextInt(personalLiabilityRadioButtonElements.count());
        waitAndClickElement(personalLiabilityRadioButtonElements.nth(index));
        return getTextFromElement(selectedPersonalLiabilityRadioButtonElement);
    }

    public String randomlySelectMedicalPaymentRadioButton(){
        scrollToElement(medicalPaymentToOthersLabelInEditCoverageSideSheet);
        Random random = new Random();
        int index = random.nextInt(medicalPaymentToOthersRadioButtonElements.count());
        waitAndClickElement(medicalPaymentToOthersRadioButtonElements.nth(index));
        return getTextFromElement(selectedMedicalPaymentToOthersRadioButtonElement);
    }

    public void validateEditedCoverageValueUpdatedOnMainScreen(FarmersSoftAssert sa, Map<String, String> coverageAmountKeyValuePair, String lobType){
        List<String> foundPrimaryCoverageName = getCondoRentersCoveragesNamesOnReviewQuotePage(lobType);
        List<String> foundPrimaryCoverageAmount = getCondoRentersCoveragesAmountOnReviewQuotePage();
        if (lobType.equals(CONDO)){
            foundPrimaryCoverageAmount.set(2, foundPrimaryCoverageAmount.get(2).replaceAll("[()]", ""));
        } else {
            for (int i = 0; i < foundPrimaryCoverageAmount.size(); i++) {
                if (foundPrimaryCoverageAmount.get(i).contains("(") || foundPrimaryCoverageAmount.get(i).contains(")")) {
                    foundPrimaryCoverageAmount.set(i, foundPrimaryCoverageAmount.get(i).replaceAll("[()]", EMPTY_STRING));
                    break;
                }
            }
        }
        List<String> expectedCoverageNames = getSortedList(new ArrayList<>(coverageAmountKeyValuePair.keySet()));
        sa.assertEquals(foundPrimaryCoverageName, expectedCoverageNames, "Coverage names after edited from side sheet - " + lobType);
        sa.assertEquals(getSortedList(foundPrimaryCoverageAmount), getSortedList(new ArrayList<>(coverageAmountKeyValuePair.values())), "Coverage amount values after edited from side sheet - " + lobType);
        Log.info("Validate if edited coverages value and coverage names on main review quote page are matching on click of recalculate button in edit coverage side sheet.");
    }

    public List<String> getCondoRentersCoveragesAmountOnReviewQuotePage(){
        Log.info("Preparing the list of found coverages on main review quote page from the xpath.");
        return condoRentersCoveragesAmountOnReviewQuotePage.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public List<String> getCondoRentersCoveragesNamesOnReviewQuotePage(String lobType){
        Log.info("Preparing the list of found coverages amount on main review quote page from the xpath.");
        List<String> coverageNames = getCondoRentersCoverageNamesFromCovNameLocators();
        if (coverageNames.contains(PERSONAL_PROPERTY + " (Replacement cost value)")) {
            coverageNames.remove(PERSONAL_PROPERTY + " (Replacement cost value)");
            coverageNames.add(PERSONAL_PROPERTY);
        }
        if (lobType.equals(RENTERS) && coverageNames.contains("Limit")) {
            coverageNames.add(coverageNames.indexOf("Limit"), PERSONAL_PROPERTY);
            coverageNames.remove("Limit");
        }
        return getSortedList(coverageNames);
    }

    public List<String> getCondoRentersCoverageNamesFromCovNameLocators(){
        return condoRentersCoveragesNamesOnReviewQuotePage.all().stream().map(this::getTextFromElement).collect(Collectors.toList());
    }

    public void validateYouGetAllTheseWithYourPolicySection(FarmersSoftAssert sa, String lobType) throws Exception {
        String expectedYouGetAllTheseWithYourHomePolicyTitle = "";
        String expectedDecliningDeductiblesDescription = "";
        String expectedClaimForgivenessTitle = "Claim Forgiveness";
        String expectedClaimForgivenessDescription = "We won't raise your premium because of a claim once you've gone claim-free with Farmers for five years.";
        String expectedClaimFreeDiscountTitle = "Claim Free Discount";
        String expectedClaimFreeDiscountDescription = "";
        if (lobType.equals(HOME) || lobType.equals(CONDO)) {
            String expectedClaimFreeYears = isHomeFlexState(getStateCodeFromAppStore()) && lobType.equals(HOME) ? "one year" : "three years";  // F96137/US1071553
            expectedClaimFreeDiscountDescription = String.format("You will receive a discount on your %s insurance if you've been claim-free for %s.", lobType, expectedClaimFreeYears);
            lobType = lobType.toLowerCase();
            expectedYouGetAllTheseWithYourHomePolicyTitle = "You get all this with your " + lobType + " policy";
            String expectedDecliningDeductibleTitle = "Declining Deductibles\u00ae";
            sa.assertEquals(decliningDeductiblesIcon.isVisible(), true, expectedDecliningDeductibleTitle + " icon displayed - " + lobType);
            sa.assertEquals(getTextFromElement(decliningDeductiblesTitle), expectedDecliningDeductibleTitle, expectedDecliningDeductibleTitle + " header check - " + lobType);
            expectedDecliningDeductiblesDescription = "Earn $50 toward your " + lobType + " deductible each year your "+ lobType.toLowerCase() + " policy is in force.";
            sa.assertEquals(getTextFromElement(decliningDeductiblesDescription), expectedDecliningDeductiblesDescription,
                    "Earn $50 toward description check - " + lobType);

            claimForgivenessIcon = locator(pwXPath(CLAIM_FORGIVENESS_SECTION_BASE + "//img"));
            claimForgivenessTitle = locator(pwXPath(CLAIM_FORGIVENESS_SECTION_BASE + "//div//p[1]"));
            claimForgivenessDescription = locator(pwXPath(CLAIM_FORGIVENESS_SECTION_BASE + "//div//p[2]"));

            claimFreeDiscountIcon = locator(pwXPath(CLAIM_FREE_SECTION_BASE + "//img"));
            claimFreeDiscountTitle = locator(pwXPath(CLAIM_FREE_SECTION_BASE + "//p[1]"));
            claimFreeDiscountDescription = locator(pwXPath(CLAIM_FREE_SECTION_BASE + "//p[2]"));

        } else {
            expectedClaimFreeDiscountDescription = "You will receive a discount on your Home insurance if you've been claim-free for three years.";
            expectedYouGetAllTheseWithYourHomePolicyTitle = "You get all this with your renters policy";
            claimForgivenessIcon = locator(pwXPath(CLAIM_FORGIVENESS_SECTION_BASE_RENTERS + "//img"));
            claimForgivenessTitle = locator(pwXPath(CLAIM_FORGIVENESS_SECTION_BASE_RENTERS + "//div//p[1]"));
            claimForgivenessDescription = locator(pwXPath(CLAIM_FORGIVENESS_SECTION_BASE_RENTERS + "//div//p[2]"));

            claimFreeDiscountIcon = locator(pwXPath(CLAIM_FREE_SECTION_BASE_RENTERS + "//img"));
            claimFreeDiscountTitle = locator(pwXPath(CLAIM_FREE_SECTION_BASE_RENTERS + "//p[1]"));
            claimFreeDiscountDescription = locator(pwXPath(CLAIM_FREE_SECTION_BASE_RENTERS + "//p[2]"));
        }

        sa.assertEquals(getTextFromElement(youGetAllTheseWithYourHomePolicyTitle), expectedYouGetAllTheseWithYourHomePolicyTitle,
                "You get all these with your home policy title check - " + lobType);
        sa.assertEquals(claimForgivenessIcon.isVisible(), true, expectedClaimForgivenessTitle + " icon displayed - " + lobType);
        sa.assertEquals(getTextFromElement(claimForgivenessTitle), expectedClaimForgivenessTitle, expectedClaimForgivenessTitle + " header check - " + lobType);
        sa.assertEquals(getTextFromElement(claimForgivenessDescription), expectedClaimForgivenessDescription,
                expectedClaimForgivenessTitle + " description check - " + lobType);


        sa.assertEquals(claimFreeDiscountIcon.isVisible(), true, expectedClaimFreeDiscountTitle + " icon displayed - " + lobType);
        sa.assertEquals(getTextFromElement(claimFreeDiscountTitle), expectedClaimFreeDiscountTitle, expectedClaimFreeDiscountTitle + " header check - " + lobType);
        sa.assertEquals(getTextFromElement(claimFreeDiscountDescription), expectedClaimFreeDiscountDescription,
                expectedClaimFreeDiscountTitle + " description check - " + lobType);
    }

    public int getDwellingCoverageInInt(AppStore appStore) {
        return Integer.parseInt(appStore.getHome().getDwellingCoverage());
    }

    public String getSelectedPackage(AppStore appStore){
        return appStore.getHome().getQuote().getSelectedPackageCode();
    }

    public void verifyBundlePropertyQuoteReviewPage(String propertyType, FarmersSoftAssert fsa) {
        String expectedPageTitle = propertyType + " coverages";
        fsa.assertEquals(getTextFromElement(bundlePropertyQuoteReviewPageTitle), expectedPageTitle, propertyType + " quote review page title verification");
        //DE258998 - Renters no longer has a subtitle
        if (propertyType.equals(HOME)) {
            String subtitleContent = getTextFromElement(bundlePropertyQuoteReviewPageSubtitle);
            fsa.assertTrue(subtitleContent.contains("Coverages are based on your selected dwelling coverage of") || subtitleContent.contains("Quote is based on your selected dwelling coverage of")
                    , propertyType + " quote review page subtitle content verification");
        } else {
            fsa.assertTrue(!isElementVisible(bundlePropertyQuoteReviewPageSubtitle, 2), "Renters quote review page does not have a subtitle");
        }
        String expectedContinueToMoreCoveragesButtonText = propertyType.equals(HOME) ? "Next: Review more home coverages" : "Next: Review more renters coverages";
        fsa.assertEquals(getTextFromElement(nextMorePropertyCoveragesButton), expectedContinueToMoreCoveragesButtonText, expectedContinueToMoreCoveragesButtonText + " button text validation");

        verifyBundleQuoteLedgerComponent(propertyType, propertyType, fsa);
    }

    protected String getPersonalPropertyKey(){
        boolean personalPropertyContainsRCV = getCondoRentersCoverageNamesFromCovNameLocators().contains(PERSONAL_PROPERTY_KEY_WITH_RCV);
        boolean personalPropertyContainsACV = getCondoRentersCoverageNamesFromCovNameLocators().contains(PERSONAL_PROPERTY_KEY_WITH_ACV);
        if(personalPropertyContainsRCV){
            return PERSONAL_PROPERTY_KEY_WITH_RCV;
        }else if(personalPropertyContainsACV){
            return PERSONAL_PROPERTY_KEY_WITH_ACV;
        }else{
            return PERSONAL_PROPERTY;
        }
    }
    public List<AppStore.Home.CvgInfo> getCovInfoFromAppStore(AppStore appStore, String selectedPaymentMode, String stateCode){
        AppStore.Home.RateQuoteResponse rateQuoteResponse = appStore.getHome().getQuote().getRateQuoteResponses().stream().filter(i -> i.getPaymentMode().equals(selectedPaymentMode)).collect(Collectors.toList()).get(0);
        List<AppStore.Home.CvgInfo> cvgInfo = rateQuoteResponse.getPersHomePolicy().getPersHomeCoverage().getCustomCoverages().getCvgInfo();
        List<AppStore.Home.CvgInfo> listOfPrimaryCoverageFromAppStore = cvgInfo.stream().filter(i -> i.getCvgSection().equals("Primary")).collect(Collectors.toList());
        // KS state personal liability and building additional and alteration index is different from other states
        if(stateCode.equals(KS)){
            Collections.swap(listOfPrimaryCoverageFromAppStore, 3, 4);
        }
        return listOfPrimaryCoverageFromAppStore;
    }
    public int getPersonalPropertyValueFromAppStore() throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        List<AppStore.Home.CvgInfo> covInfoFromAppStore = getCovInfoFromAppStore(appStore, getSelectedPaymentMode(), appStore.getData().getLandingStateCode());
        AppStore.Home.CvgInfo personalPropertyCvg = covInfoFromAppStore.stream().filter(i -> i.getCvgDesc().equals(PERSONAL_PROPERTY)).collect(Collectors.toList()).get(0);
        return getIntCurrencyValueFromStringCurrencyValue(personalPropertyCvg.getCvgAmt());
    }

    public String getOptionalCoverageSumFromAppStore() throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        String selectedPaymentMode = getSelectedPaymentMode();
        String selectedPackage = getSelectedPackage(appStore);
        List<AppStore.Home.CvgInfo> optionalCoverages = appStore.getHome().getCoverageForPackage(selectedPackage, selectedPaymentMode).getCvgInfo().stream()
                .filter(i -> i.getCvgSection().equals("Optional")).collect(Collectors.toList());
        double optionalCoverageSum = 0.0;
        for (AppStore.Home.CvgInfo coverage : optionalCoverages) {
            if ((coverage.getPremiumAmt() != null) && (coverage.getDisplayPremium() != null)) {
                optionalCoverageSum += Double.parseDouble(coverage.getPremiumAmt());
            }
        }
        if (selectedPaymentMode.equals("EFT")) {
            optionalCoverageSum = optionalCoverageSum / 12;
        }
        return CurrencyFormat.convertDoubleToCurrencyStringNoDecimals(optionalCoverageSum);
    }

    public void validateContinueButtonAtPageBottom(FarmersSoftAssert fsa) {
        if (isUseMobileViewEnabled()) {
            fsa.assertTrue(isElementVisibleAndClickable(buttonContinueMobileAtPageBottom,2), "Review quote page - Continue button is displayed at page bottom in mobile view.");
        } else {
            fsa.assertFalse(isElementVisibleAndClickable(buttonContinueMobileAtPageBottom,2), "Review quote page - Continue button is displayed at page bottom in desktop view.");
        }
    }
    public List<AppStore.Home.RateQuoteResponse> getPackageFromRateResponse(String packageCode) throws Exception {
        AppStore appStore = getSessionStorageAppStore();
        AppStore.Home.Quote quote = appStore.getHome().getQuote();
        List<AppStore.Home.RateQuoteResponse> rateQuoteResponses = quote.getRateQuoteResponses();
        List<AppStore.Home.RateQuoteResponse> rateQuoteResponsesWithoutKnockOut = rateQuoteResponses.stream().filter(i -> i.getKnockOutBeanList() == null).collect(Collectors.toList());
        return rateQuoteResponsesWithoutKnockOut.stream().filter(i -> i.getRatePackage().equals(packageCode.toUpperCase())).collect(Collectors.toList());
    }

    public void validateFooterTextOnReviewQuotePage(FarmersSoftAssert fsa){
        waitElementBeVisible(monthlyAmountText);
        fsa.assertEquals(getTextFromElement(monthlyAmountText).equals(MONTHLY_AMOUNT_TEXT), true, "Monthly amount text validation");
        fsa.assertEquals(getTextFromElement(monthlyAmount2Text).equals(MONTHLY_AMOUNT_TEXT_PART2), true, "Monthly amount text 2 validation");

    }

    public void clickOnViewPricingLink(){
        clickElement(viewPricingLink);
    }

    public String getLossOfUseCoverageName(String stateCode) {
        return stateCode.equals(CT) ? LOSS_OF_USE_TEXT : LOSS_OF_USE;
    }

    // F89863 - validate that the difference between dropdown values is consistent to 10% of coverage limit
    public void validateLossOfUseDropdownValue(FarmersSoftAssert fsa, String stateCode) throws Exception {
        List<Double> lossOfUseOptions = new ArrayList<>();
        for (Locator option : lossOfUseDropDownOptions.all()) {
            String text = getTextFromElement(option).replaceAll(" .*$", EMPTY_STRING);
            lossOfUseOptions.add(convertCurrencyStringToDouble(text));
        }
        // Values can be duplicated for different month options (ex. 10% can be for 12 months and 24 months), so we need to get distinct values only.
        List<Double> uniqueOptions = lossOfUseOptions.stream().distinct().collect(Collectors.toList());
        Log.info("List of unique Loss of Use dropdown options values: " + uniqueOptions);
        double coverageLimit =  convertCurrencyStringToDouble(getCoveragePriceByNameFromScreen(PERSONAL_PROPERTY_LIMIT));
        int step = (int) (coverageLimit * 0.1); // 10%-100% in 10% increments
        double initialPercentage = isTwentyPerLossOfUseStateRenters(stateCode) ? 0.2 : 0.1;
        double expectedValue = coverageLimit * initialPercentage;
        for(double option : uniqueOptions){
            double expectedRounded = Math.round(expectedValue / 100.0) * 100.0; // to round to the nearest hundred
            fsa.assertEquals(option, expectedRounded, "Validating Loss of Use dropdown option value. Expected: " + expectedValue + ", Actual: " + option);
            expectedValue += step;
        }
    }

    public boolean isTwentyPerLossOfUseStateRenters(String stateCode) {
        return List.of(VA, CT, NC).contains(stateCode);
    }

}
