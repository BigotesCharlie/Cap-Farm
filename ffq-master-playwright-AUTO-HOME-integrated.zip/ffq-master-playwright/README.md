# ffq-master-playwright

Independent **Gradle + Java 17 + Playwright + TestNG** project containing only the functional **Home**, **Auto**, and **Auto–Home Bundle** suites.

Gradle project name and generated artifact base name: `ffq-master-playwright`.

## Environment routing

The standard landing entry is now restricted to these exact URLs:

| Selection | Internal environment | FastQuote entry |
|---|---|---|
| QA | `test` | `https://ffqautouiqa.farmers.com/fastquote/` |
| UAT | `regression` | `https://ffqautouiuat.farmers.com/fastquote/` |

`QA` and `UAT` are accepted as friendly aliases. The framework normalizes them to `test` and `regression`.

The extracted Home/Auto suites no longer use `csstv.farmers.com` as an entry point. A legacy call requesting Farmers.com is routed to the selected FastQuote URL, and an unexpected redirect to CSSTV produces a clear runtime error.

## Local IntelliJ configuration

Copy:

```text
ffq-local.properties.example
```

to:

```text
ffq-local.properties
```

For QA:

```properties
environment=QA
browser=chrome
headless=false
syntheticAgentCookie=
```

For UAT:

```properties
environment=UAT
browser=chrome
headless=false
syntheticAgentCookie=
```

The cookie is optional. Leave it blank unless the selected environment actually requires the `synthetic_agent` cookie. The real local file is ignored by Git.

## Scope integrity

- Target test methods preserved 1:1: **2,370**.
- Target test source files: **129**.
- Supporting test files: `BaseTest` and `AceBundleTestHelper`.
- All required XLSX, XML, and KEY resources remain byte-for-byte identical.
- Playwright lifecycle coverage is applied to every class containing `@Test` methods.

## Confirm the selected URL

```bash
./gradlew showEnvironment
```

This prints the effective normalized environment and FastQuote URL without opening a browser.

## Build validation

```bash
./gradlew clean validateBuild --stacktrace
```

`validateBuild` compiles production/test code and runs:

- `verifyPlaywrightOnly`
- `verifyEnvironmentRouting`
- resource and source processing

## Test execution

Home:

```bash
./gradlew clean homeTest -Denvironment=QA --stacktrace
```

Auto:

```bash
./gradlew clean autoTest -Denvironment=QA --stacktrace
```

Auto–Home Bundle:

```bash
./gradlew clean autoHomeBundleTest -Denvironment=QA --stacktrace
```

Change `QA` to `UAT` as required. Tests can also be launched from the IntelliJ TestNG **Play** button; `ffq-local.properties` is read from the project root.

## Configuration priority

Runtime values are resolved in this order:

1. JVM property such as `-Denvironment=QA`
2. JVM property prefixed with `ffq.`
3. Environment variable
4. Untracked `ffq-local.properties`
5. `properties.json`

A stale `baseUrl` or `FFQ_BASE_URL` that does not match the selected QA/UAT FastQuote URL is rejected before tests start.

## Essential test data

The required resources remain under `src/test/resources`, including the Home and Auto XLSX files, XML web-service data, and AES test keys.

## Offline validation

```bash
python scripts/verify_extraction.py
python scripts/verify_project.py
```

## Suite-wide CopyDOM and AutoDebug resiliency

AUTO and HOME tests inherit a central Playwright resiliency layer through `PlaywrightSession` and `LazyLocator`. It captures DOM evidence across page transitions and failures, detects Inconvenience/Knockout/Try Again states, and performs bounded recovery only when a UI interaction is blocked. See `AUTODEBUG_COPYDOM.md` for artifacts, recovery order and configuration.


## Integrated acceptance E2E flows

The master project includes the proven acceptance flows imported from the dedicated AUTO and HOME projects while retaining the original +2300 regression tests:

- AUTO BristolWest deterministic: `./gradlew autoBristolE2E`
- HOME Happy Path: `./gradlew homeHappyPathE2E`
- HOME payment/video flow: `./gradlew homeVideoFlowE2E`
- Both HOME acceptance scenarios: `./gradlew homeAcceptanceE2E`

All integrated E2E tests use the shared Playwright Java lifecycle. CopyDOM/AutoDebug remains suite-wide; HOME keeps its proven flow-level state/recovery guard as an additional functional safety layer.
