# Project Rename Report

The integrated Playwright Java project has been refactored to use the canonical project name `ffq-master-playwright`.

- Project directory: `ffq-master-playwright`
- Gradle `rootProject.name`: `ffq-master-playwright`
- Generated JAR base name: `ffq-master-playwright`
- AUTO BristolWest deterministic E2E integration: preserved
- CopyDOM / AutoDebug / Recovery framework integration: preserved
- Selenium runtime: not introduced

This rename is identity-only and does not change test behavior, functional data, Playwright flows, or recovery behavior.
