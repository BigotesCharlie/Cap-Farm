# Environment Routing and Authentication Failure Correction

## Root causes confirmed

1. `properties.json` already contained the correct standard entry URLs:
   - QA (`test`): `https://ffqautouiqa.farmers.com/fastquote/`
   - UAT (`regression`): `https://ffqautouiuat.farmers.com/fastquote/`
2. The same environment sections also contained a separate `farmers_com_url` value that pointed to CSSTV.
3. `LandingPage.openLandingPage(...)` used `farmers_com_url` whenever a legacy caller passed `useFarmersDotCom=true`.
4. `LandingPage` unconditionally required `syntheticAgentCookie` for every standard landing-page navigation. The missing-cookie exception therefore occurred even when the intended FastQuote URL was correct.
5. The `ffq-local.properties` file was not read by the `corrected` project, so local `environment`, `browser`, `headless`, and cookie values had no effect.
6. Two executable Auto-test paths still contained a hardcoded UAT host instead of deriving the host from the selected environment.
7. Nine test classes in the corrected package did not inherit the Playwright lifecycle base, causing the earlier `No Page is active` failures.

## Corrections applied

- Added `ffq-local.properties` support with parent-directory lookup for IntelliJ TestNG execution.
- Added aliases: `QA -> test` and `UAT -> regression`.
- Protected the exact standard entry routes in `Property.getUri()`.
- Added fail-fast validation for stale `baseUrl` or `FFQ_BASE_URL` overrides.
- Repointed QA/UAT `farmers_com_url` values to their FastQuote entry URL.
- Removed runtime use of `getEnvironmentProperty("farmers_com_url")` from `LandingPage`.
- Forced legacy Farmers.com landing requests to the selected FastQuote entry.
- Made `synthetic_agent` optional; it is added before navigation only when configured.
- Added a clear guard if the application itself redirects to CSSTV.
- Replaced executable hardcoded UAT URLs with `Property.getUri()` or `Property.getEnvironmentUrl(...)`.
- Restored Playwright lifecycle inheritance for all 127 classes containing tests.
- Added Gradle tasks `verifyEnvironmentRouting` and `showEnvironment`.

## Integrity validation

- Test methods before: 2,370
- Test methods after: 2,370
- Class and method-name manifest: exact 1:1 match
- Test descriptions: 2,370
- Java files: 358
- Test classes with Playwright lifecycle: 127 of 127
- Immutable external resources: 8 of 8 unchanged
- Offline extraction validation: PASS
- Offline structural validation: PASS
- Environment-routing validation: PASS

## Gradle execution boundary

A Gradle build was attempted with:

```text
./gradlew clean validateBuild --stacktrace
```

The wrapper could not download Gradle 8.2.1 because the isolated validation environment cannot resolve `services.gradle.org`. No compilation failure from the project source was observed; full Gradle compilation must be rerun in the corporate environment where the earlier corrected package already resolved its dependencies successfully.
