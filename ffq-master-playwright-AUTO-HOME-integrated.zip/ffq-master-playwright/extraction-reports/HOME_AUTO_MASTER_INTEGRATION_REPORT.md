# ffq-master-playwright — AUTO + HOME Integration Report

## Integrated acceptance E2E scenarios

- AUTO: `com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest.bristolWestE2EDeterministic`
- HOME Happy Path: `com.farmers.ffq.home.e2e.HomeHappyPathE2ETest.homeDomHappyPathE2E`
- HOME payment/video flow: `com.farmers.ffq.home.e2e.validatePaymentByChangingPayInFullBankToMonthlyPayCardAceHome.reproduceVideoFlowE2E`

## Integration rules applied

- `ffq-master-playwright` remains the master project and Gradle structure.
- `properties.json` was restored byte-for-byte from the original `ffq-auto-home-playwright-java-23` source supplied at the beginning of the work.
- HOME source logic was imported selectively; HOME's standalone Gradle/browser lifecycle was not imported.
- HOME acceptance tests now extend the shared `AutomationFramework` and reuse `PlaywrightSession`.
- Existing AUTO production/test source trees and AUTO workbooks were not modified during HOME integration.
- HOME CopyDOM evidence is stored under `build/artifacts/dom/home-functional/...` and also checkpoints the suite-wide `AutoDebugManager`.
- HOME's proven state-machine/recovery behavior remains available for its flows while the master suite-wide AutoDebug/CopyDOM lifecycle remains active.
- Four `Thread.sleep()` calls from the HOME source were replaced with Playwright `page.waitForTimeout(...)`.

## Structural validation

- 2,373 `@Test` annotations
- 2,373 test descriptions
- 411 Java files total
- 8 immutable essential resources verified
- QA/UAT routing validation: PASS
- Selenium/prohibited runtime scan: PASS
- `properties.json` SHA-256: `ad4a3697fe0e1f9e18fe3d05d61e833670f5e6001964e9b8f69538cbbe284fa8`

## AUTO preservation check

The AUTO source/test trees and functional workbooks are byte-identical to the pre-HOME `ffq-master-playwright` package:

- `src/main/java/com/farmers/ffq/auto`: SAME
- `src/test/java/com/farmers/ffq/auto`: SAME
- `AutoTestData.xlsx`: SAME (`e263cc8dced9a04cad722f0a082571019854ca30b5a9becde2a089f3b4d78b37`)
- `OneUIAutoTestData.xlsx`: SAME

## Runtime compile status in this environment

The Gradle wrapper could not start because this sandbox cannot resolve `services.gradle.org` to download Gradle 8.2.1. Therefore compilation and live browser execution are not claimed as completed here. Offline structural validation passed.

## Acceptance commands

```bash
./gradlew clean compileJava compileTestJava verifyPlaywrightOnly verifyEnvironmentRouting
./gradlew autoBristolE2E
./gradlew homeHappyPathE2E
./gradlew homeVideoFlowE2E
./gradlew homeAcceptanceE2E
```
