# AUTO BristolWest Deterministic Integration Report

## Integration target
Base: ffq-master-playwright with suite-wide Playwright Java CopyDOM + AutoDebug + Recovery.
Source of functional truth: ffq-AutoBind-E2E.

## Guaranteed integration goal
Preserve the known-working deterministic AUTO scenario:
- Class: `com.farmers.ffq.auto.e2e.BindOneUIEndToEndTest`
- Test: `bristolWestE2EDeterministic()`
- Scenario label: `BristolWest E2E`
- Deterministic applicant: Yvonne Fisher

## What was integrated
- Known-working BristolWest deterministic test implementation and purchase flow.
- BristolWest-specific navigation and quote recovery improvements.
- Deterministic VIN and driver-license handling.
- Additional-info handling that accepts the deterministic applicant values.
- Checkout/payment robustness and BristolWest success-page detection.
- Contact-info, YMM, quote-presentment, payment-summary and landing/retrieve-quote locator improvements used by the passing source project.
- Updated `AutoTestData.xlsx` from the known-working AutoBind project.
- Formula evaluation support in `ExcelDataProvider` required by the updated workbook.
- AUTO-specific diagnostic state classification adapted to call the suite-wide central CopyDOM layer.

## Central framework deliberately preserved
The following base-project behavior was NOT replaced by the older/local AutoBind implementation:
- `PlaywrightSession` suite-wide AutoDebug lifecycle.
- `LazyLocator` automatic locator-failure interception and one-time action retry.
- `AutoDebugManager`.
- `CopyDom`.
- `PageStateDetector`.
- `RecoveryManager`.

This means BristolWest uses the same central recovery infrastructure as the rest of AUTO/HOME rather than creating a second runtime recovery engine.

## Explicit runtime configuration
`properties.json` now exposes:
- `autoDebug = true`
- `autoDebug.maxRecovery = 2`
- `autoDebug.backOnBlocker = true`
- `autoDebug.reloadOnBlocker = true`
- `autoDebug.restartOnBlocker = true`

## Validation
PASS: offline project validation completed; 2371 tests, 2371 descriptions, 364 Java files, 8 immutable resources.
PASS: 2371 tests, 2371 descriptions, scope and resource hashes verified.
PASS: QA/UAT FastQuote routing, optional cookie handling, local configuration, and lifecycle coverage verified.
PASS: prohibited Selenium token scan returned no Selenium runtime usage.

## Compile/runtime limitation in this environment
A Gradle compile was attempted. The Gradle wrapper requires `gradle-8.2.1-bin.zip` from `services.gradle.org`; this sandbox cannot resolve that host, so Gradle compilation/browser execution cannot be completed here. This is an environment/network limitation, not a project validation failure.

## Next integration step
HOME can be integrated on top of this exact project artifact when its source project becomes available in a transferable form.
