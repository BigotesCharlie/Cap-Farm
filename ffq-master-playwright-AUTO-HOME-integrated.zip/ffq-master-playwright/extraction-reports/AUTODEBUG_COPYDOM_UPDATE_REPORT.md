# CopyDOM / AutoDebug Project-Wide Update

## Scope

Applied centrally to the complete extracted AUTO + HOME Playwright Java project. No individual test method was rewritten and no Selenium runtime was introduced.

## Framework changes

- Added `AutoDebugManager` for thread-local execution diagnostics and bounded recovery.
- Added `CopyDom` for per-execution HTML + metadata snapshots.
- Added `PageStateDetector` for AUTO/HOME/Inconvenience/Knockout/Try Again state classification.
- Added `RecoveryManager` with recovery order: Try Again -> Back -> Reload -> FastQuote restart.
- Integrated lifecycle through `PlaywrightSession` so every test inheriting `AutomationFramework` participates automatically.
- Integrated locator-failure interception through `LazyLocator`; the original locator operation is retried only when blocker recovery actually succeeds.
- Preserved existing Playwright screenshots/traces, TestNG listeners, Page Objects, test data and Happy Path logic.

## Coverage

- 127 test-bearing classes are covered through `AutomationFramework` directly or through `BaseTest` / `DefaultCoverageBaseTest`.
- Existing FFQ source uses the shared lazy `locator(...)` abstraction extensively (5,833 occurrences in the audited AUTO/HOME source), so locator failures flow through the central AutoDebug hook.
- TestNG parallel execution remains isolated via `ThreadLocal` debug state and unique execution directories.

## Validation

- Offline project validator: PASS — 2,370 tests, 2,370 descriptions, 362 Java files, 8 immutable resources.
- Extraction validator: PASS — test scope and resource hashes verified.
- Environment routing validator: PASS — QA/UAT FastQuote routing and lifecycle coverage verified.
- Selenium prohibited-token scan: PASS — no Selenium/WebDriver runtime reintroduced.
- New/modified Java structural delimiter scan: PASS.

## Runtime artifact layout

`build/artifacts/dom/<Class.test>/<execution-id>/`

The directory contains CopyDOM HTML, metadata and `debug-summary.txt`. Existing screenshots and traces remain in their prior artifact locations.
