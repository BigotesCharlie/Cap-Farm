$ErrorActionPreference = "Stop"
Write-Host "Starting FFQ-AI..."
mvn spring-boot:run
