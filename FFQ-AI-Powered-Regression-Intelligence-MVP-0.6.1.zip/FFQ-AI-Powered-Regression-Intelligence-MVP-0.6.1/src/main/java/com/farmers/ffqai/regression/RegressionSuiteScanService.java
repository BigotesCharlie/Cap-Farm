package com.farmers.ffqai.regression;

import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@Service
public class RegressionSuiteScanService {
    private static final Pattern URL_PATTERN = Pattern.compile("https?://[^\\s<\\\"']+", Pattern.CASE_INSENSITIVE);
    private static final Set<String> STOP = Set.of(
            "the","and","that","this","with","from","into","for","are","was","were","will","would",
            "should","could","have","has","had","your","their","there","then","when","where","what",
            "user","story","want","can","so","to","of","in","on","a","an","is","be","as","it");
    private final HttpClient http = HttpClient.newBuilder()
            .followRedirects(HttpClient.Redirect.NORMAL)
            .connectTimeout(Duration.ofSeconds(20))
            .build();

    public ScanResult scan(ScanRequest request) {
        String localFile = System.getenv("FARMERS_REGRESSION_SUITE_FILE");

        String source = firstNonBlank(
                localFile,
                request.sourceUrl(),
                extractUrl(request.description())
        );

        if (source == null || source.isBlank()) {
            throw new IllegalArgumentException(
                    "No Regression Suite source was configured. " +
                    "Set FARMERS_REGRESSION_SUITE_FILE or provide a SharePoint URL."
            );
        }

        byte[] workbook = readWorkbook(source);

        List<SheetData> sheets = parseXlsx(workbook);
        String query = stripHtml(firstNonBlank(request.userStoryTitle(), "") + " " + firstNonBlank(request.description(), ""));
        Set<String> queryTokens = tokens(query);

        List<SheetResult> results = new ArrayList<>();
        int automated = 0;
        int manual = 0;
        int total = 0;

        for (SheetData sheet : sheets) {
            List<TestCaseMatch> matches = matchSheet(sheet, queryTokens, query);
            if (matches.isEmpty()) continue;
            int autoSheet = (int) matches.stream().filter(tc -> "AUTOMATED".equals(tc.type())).count();
            int manualSheet = matches.size() - autoSheet;
            automated += autoSheet;
            manual += manualSheet;
            total += matches.size();
            results.add(new SheetResult(sheet.name(), autoSheet, manualSheet, matches));
        }

        if (results.isEmpty()) {
            throw new IllegalStateException("The workbook was read successfully, but no Test Cases matched the selected User Story description.");
        }

        return new ScanResult(source, sheets.size(), total, automated, manual, results,
                "Regression Suite scanned and matched against " + firstNonBlank(request.userStoryId(), "selected User Story") + ".");
    }

    public String extractUrl(String html) {
        if (html == null) return null;
        Matcher m = URL_PATTERN.matcher(html.replace("&amp;", "&"));
        String first = null;
        while (m.find()) {
            String candidate = m.group();
            if (first == null) first = candidate;
            String lc = candidate.toLowerCase(Locale.ROOT);
            if (lc.contains("sharepoint.com") || lc.contains(".xlsx")) return trimUrl(candidate);
        }
        return trimUrl(first);
    }

    private String trimUrl(String value) {
        if (value == null) return null;
        return value.replaceAll("[\\)\\]>,.;]+$", "");
    }

    private byte[] readWorkbook(String sourceUrl) {
        try {
            if (sourceUrl.startsWith("file:")) {
                return Files.readAllBytes(Path.of(URI.create(sourceUrl)));
            }
            if (!sourceUrl.startsWith("http://") && !sourceUrl.startsWith("https://")) {
                Path local = Path.of(sourceUrl);
                if (Files.exists(local)) return Files.readAllBytes(local);
            }

            List<String> candidates = new ArrayList<>();
            candidates.add(sourceUrl);
            if (sourceUrl.contains("sharepoint.com") && !sourceUrl.contains("download=1")) {
                candidates.add(sourceUrl + (sourceUrl.contains("?") ? "&" : "?") + "download=1");
            }

            String cookie = System.getenv("FARMERS_SHAREPOINT_COOKIE");
            String bearer = System.getenv("FARMERS_SHAREPOINT_BEARER_TOKEN");
            String lastProblem = "";

            for (String candidate : candidates) {
                HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(candidate))
                        .timeout(Duration.ofSeconds(45))
                        .header("User-Agent", "FFQ-AI/0.5.9")
                        .header("Accept", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/octet-stream,*/*")
                        .GET();
                if (cookie != null && !cookie.isBlank()) builder.header("Cookie", cookie);
                if (bearer != null && !bearer.isBlank()) builder.header("Authorization", "Bearer " + bearer);

                HttpResponse<byte[]> response = http.send(builder.build(), HttpResponse.BodyHandlers.ofByteArray());
                String contentType = response.headers().firstValue("content-type").orElse("").toLowerCase(Locale.ROOT);
                byte[] body = response.body();
                if (response.statusCode() >= 200 && response.statusCode() < 300 && isZip(body)) return body;
                lastProblem = "HTTP " + response.statusCode() + " / " + contentType;
            }

            throw new IllegalStateException(
                    "Unable to download the Regression Suite workbook from SharePoint (" + lastProblem + "). " +
                    "The scanner supports direct-access links and authenticated requests through FARMERS_SHAREPOINT_COOKIE " +
                    "or FARMERS_SHAREPOINT_BEARER_TOKEN when corporate SSO blocks server-side download.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Regression Suite download was interrupted.", e);
        } catch (Exception e) {
            if (e instanceof IllegalStateException ise) throw ise;
            throw new IllegalStateException("Unable to read Regression Suite workbook: " + e.getMessage(), e);
        }
    }

    private boolean isZip(byte[] data) {
        return data != null && data.length > 4 && data[0] == 'P' && data[1] == 'K';
    }

    private List<SheetData> parseXlsx(byte[] bytes) {
        try {
            Map<String, byte[]> entries = unzip(bytes);
            List<String> shared = parseSharedStrings(entries.get("xl/sharedStrings.xml"));
            Map<String,String> rels = parseRelationships(entries.get("xl/_rels/workbook.xml.rels"));
            Document workbook = xml(entries.get("xl/workbook.xml"));
            NodeList sheetNodes = workbook.getElementsByTagName("sheet");
            List<SheetData> sheets = new ArrayList<>();

            for (int i=0;i<sheetNodes.getLength();i++) {
                Element sheet=(Element)sheetNodes.item(i);
                String name=sheet.getAttribute("name");
                String rid=sheet.getAttribute("r:id");
                if (rid.isBlank()) rid=sheet.getAttribute("id");
                String target=rels.get(rid);
                if (target==null) continue;
                String path=target.startsWith("/") ? target.substring(1) : "xl/" + target.replace("../", "");
                byte[] sheetXml=entries.get(path);
                if (sheetXml==null) continue;
                sheets.add(new SheetData(name, parseSheet(sheetXml, shared)));
            }
            return sheets;
        } catch (Exception e) {
            throw new IllegalStateException("The downloaded file is not a readable XLSX Regression Suite: " + e.getMessage(), e);
        }
    }

    private Map<String, byte[]> unzip(byte[] data) throws Exception {
        Map<String,byte[]> entries=new HashMap<>();
        try (ZipInputStream zis=new ZipInputStream(new ByteArrayInputStream(data))) {
            ZipEntry entry;
            while((entry=zis.getNextEntry())!=null) {
                if(entry.isDirectory()) continue;
                ByteArrayOutputStream out=new ByteArrayOutputStream();
                zis.transferTo(out);
                entries.put(entry.getName(), out.toByteArray());
            }
        }
        return entries;
    }

    private Document xml(byte[] data) throws Exception {
        if(data==null) throw new IllegalStateException("Missing XLSX XML part.");
        var factory=DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(false);
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        return factory.newDocumentBuilder().parse(new ByteArrayInputStream(data));
    }

    private List<String> parseSharedStrings(byte[] xml) throws Exception {
        List<String> values=new ArrayList<>();
        if(xml==null) return values;
        Document doc=xml(xml);
        NodeList items=doc.getElementsByTagName("si");
        for(int i=0;i<items.getLength();i++) {
            Element si=(Element)items.item(i);
            NodeList ts=si.getElementsByTagName("t");
            StringBuilder b=new StringBuilder();
            for(int j=0;j<ts.getLength();j++) b.append(ts.item(j).getTextContent());
            values.add(b.toString());
        }
        return values;
    }

    private Map<String,String> parseRelationships(byte[] xml) throws Exception {
        Map<String,String> rels=new HashMap<>();
        Document doc=xml(xml);
        NodeList items=doc.getElementsByTagName("Relationship");
        for(int i=0;i<items.getLength();i++) {
            Element e=(Element)items.item(i);
            rels.put(e.getAttribute("Id"),e.getAttribute("Target"));
        }
        return rels;
    }

    private List<List<String>> parseSheet(byte[] xml, List<String> shared) throws Exception {
        Document doc=xml(xml);
        NodeList rows=doc.getElementsByTagName("row");
        List<List<String>> result=new ArrayList<>();
        for(int r=0;r<rows.getLength();r++) {
            Element row=(Element)rows.item(r);
            NodeList cells=row.getElementsByTagName("c");
            Map<Integer,String> rowMap=new HashMap<>();
            int max=-1;
            for(int i=0;i<cells.getLength();i++) {
                Element cell=(Element)cells.item(i);
                int col=columnIndex(cell.getAttribute("r"));
                max=Math.max(max,col);
                String type=cell.getAttribute("t");
                String value="";
                if("inlineStr".equals(type)) {
                    NodeList t=cell.getElementsByTagName("t");
                    if(t.getLength()>0) value=t.item(0).getTextContent();
                } else {
                    NodeList v=cell.getElementsByTagName("v");
                    if(v.getLength()>0) value=v.item(0).getTextContent();
                    if("s".equals(type) && !value.isBlank()) {
                        int idx=Integer.parseInt(value);
                        value=idx>=0 && idx<shared.size()?shared.get(idx):value;
                    }
                }
                rowMap.put(col,value==null?"":value.trim());
            }
            if(max>=0) {
                List<String> vals=new ArrayList<>();
                for(int i=0;i<=max;i++) vals.add(rowMap.getOrDefault(i,""));
                result.add(vals);
            }
        }
        return result;
    }

    private int columnIndex(String ref) {
        int col=0;
        for(int i=0;i<ref.length();i++) {
            char ch=ref.charAt(i);
            if(!Character.isLetter(ch)) break;
            col=col*26+(Character.toUpperCase(ch)-'A'+1);
        }
        return Math.max(0,col-1);
    }

    private List<TestCaseMatch> matchSheet(SheetData sheet, Set<String> queryTokens, String queryText) {
        if(sheet.rows().isEmpty()) return List.of();
        int headerIndex=findHeaderRow(sheet.rows());
        List<String> headers=normalizeHeaders(sheet.rows().get(headerIndex));
        List<TestCaseMatch> candidates=new ArrayList<>();

        for(int r=headerIndex+1;r<sheet.rows().size();r++) {
            List<String> row=sheet.rows().get(r);
            String joined=String.join(" | ",row).trim();
            if(joined.isBlank() || row.stream().filter(v->!v.isBlank()).count()<2) continue;
            Set<String> rowTokens=tokens(joined);
            int overlap=0;
            for(String token:queryTokens) if(rowTokens.contains(token)) overlap++;
            double score=queryTokens.isEmpty()?0:(100.0*overlap/queryTokens.size());
            String rowLc=joined.toLowerCase(Locale.ROOT);
            if(queryText.toLowerCase(Locale.ROOT).contains("automation") && rowLc.contains("automation")) score+=5;
            if(rowLc.contains("regression")) score+=2;

            Map<String,String> fields=new LinkedHashMap<>();
            for(int i=0;i<row.size();i++) {
                String h=i<headers.size()?headers.get(i):"column "+(i+1);
                if(!row.get(i).isBlank()) fields.put(h,row.get(i));
            }
            String id=findField(fields,"test case id","testcase id","tc id","id","test id");
            String name=findField(fields,"test case","testcase","scenario","test scenario","name","title","description");
            if(name==null || name.isBlank()) name=row.stream().filter(v->!v.isBlank()).skip(id==null?0:1).findFirst().orElse(joined);
            if(id==null || id.isBlank()) id=safeId(sheet.name())+"-ROW-"+(r+1);
            String type=classify(fields,joined);
            if(overlap>=2 || score>=7.5) candidates.add(new TestCaseMatch(id,name,type,Math.min(100.0,score),joined));
        }

        candidates.sort(Comparator.comparingDouble(TestCaseMatch::matchScore).reversed());
        return candidates.size()>100 ? candidates.subList(0,100) : candidates;
    }

    private int findHeaderRow(List<List<String>> rows) {
        int best=0,bestScore=-1;
        for(int i=0;i<Math.min(rows.size(),20);i++) {
            int score=0;
            for(String value:rows.get(i)) {
                String v=value.toLowerCase(Locale.ROOT).trim();
                if(v.matches(".*(test|case|scenario|name|title|automation|manual|expected|step|status|id).*")) score++;
            }
            if(score>bestScore){bestScore=score;best=i;}
        }
        return best;
    }

    private List<String> normalizeHeaders(List<String> row) {
        List<String> h=new ArrayList<>();
        for(int i=0;i<row.size();i++) {
            String v=row.get(i).trim();
            h.add(v.isBlank()?"column "+(i+1):v.toLowerCase(Locale.ROOT));
        }
        return h;
    }

    private String findField(Map<String,String> fields,String... keys) {
        for(String key:keys) {
            for(var e:fields.entrySet()) if(e.getKey().equals(key) || e.getKey().contains(key)) return e.getValue();
        }
        return null;
    }

    private String classify(Map<String,String> fields,String joined) {
        StringBuilder hint=new StringBuilder();
        for(var e:fields.entrySet()) {
            String k=e.getKey();
            if(k.contains("automation")||k.contains("automated")||k.contains("type")||k.contains("framework")||k.contains("status")||k.contains("execution")) hint.append(' ').append(e.getValue());
        }
        String text=(hint+" "+joined).toLowerCase(Locale.ROOT);
        if(text.contains("manual")) return "MANUAL";
        if(text.contains("automated")||text.contains("automation")||text.contains("playwright")||text.contains("selenium")||text.contains("script")) return "AUTOMATED";
        return "MANUAL";
    }

    private Set<String> tokens(String value) {
        Set<String> out=new LinkedHashSet<>();
        if(value==null) return out;
        for(String token:value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+"," ").split("\\s+")) {
            if(token.length()>=3 && !STOP.contains(token) && !token.matches("\\d+")) out.add(token);
        }
        return out;
    }

    private String stripHtml(String value) {
        if(value==null) return "";
        return value.replaceAll("(?is)<script.*?</script>"," ")
                .replaceAll("(?is)<style.*?</style>"," ")
                .replaceAll("(?is)<[^>]+>"," ")
                .replaceAll("https?://\\S+"," ")
                .replace("&nbsp;"," ").replace("&amp;","&");
    }

    private String safeId(String value){return value.replaceAll("[^A-Za-z0-9]+","-").replaceAll("^-|-$","");}
    private String firstNonBlank(String... values){for(String v:values) if(v!=null&&!v.isBlank()) return v; return null;}

    public record ScanRequest(String userStoryId,String userStoryTitle,String description,String sourceUrl) {}
    public record ScanResult(String sourceUrl,int sheetsScanned,int totalMatches,int automatedCount,int manualCount,List<SheetResult> sheets,String message) {}
    public record SheetResult(String sheetName,int automatedCount,int manualCount,List<TestCaseMatch> testCases) {}
    public record TestCaseMatch(String id,String name,String type,double matchScore,String details) {}
    private record SheetData(String name,List<List<String>> rows) {}
}
