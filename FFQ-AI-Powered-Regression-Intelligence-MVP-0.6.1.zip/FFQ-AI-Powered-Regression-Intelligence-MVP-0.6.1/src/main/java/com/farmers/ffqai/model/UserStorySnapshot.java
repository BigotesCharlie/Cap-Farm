package com.farmers.ffqai.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.LinkedHashMap;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserStorySnapshot {

    private String objectId;
    private String formattedId;
    private String name;
    private String description;
    private String notes;
    private String acceptanceCriteria;
    private String owner;
    private String project;
    private String scheduleState;
    private String flowState;
    private Double planEstimate;
    private String parent;
    private String feature;
    private String release;
    private String iteration;
    private String creationDate;
    private String lastUpdateDate;
    private Boolean blocked;
    private String tags;
    private Map<String, Object> rawFields = new LinkedHashMap<>();

    public String getObjectId() { return objectId; }
    public void setObjectId(String objectId) { this.objectId = objectId; }

    public String getFormattedId() { return formattedId; }
    public void setFormattedId(String formattedId) { this.formattedId = formattedId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getAcceptanceCriteria() { return acceptanceCriteria; }
    public void setAcceptanceCriteria(String acceptanceCriteria) { this.acceptanceCriteria = acceptanceCriteria; }

    public String getOwner() { return owner; }
    public void setOwner(String owner) { this.owner = owner; }

    public String getProject() { return project; }
    public void setProject(String project) { this.project = project; }

    public String getScheduleState() { return scheduleState; }
    public void setScheduleState(String scheduleState) { this.scheduleState = scheduleState; }

    public String getFlowState() { return flowState; }
    public void setFlowState(String flowState) { this.flowState = flowState; }

    public Double getPlanEstimate() { return planEstimate; }
    public void setPlanEstimate(Double planEstimate) { this.planEstimate = planEstimate; }

    public String getParent() { return parent; }
    public void setParent(String parent) { this.parent = parent; }

    public String getFeature() { return feature; }
    public void setFeature(String feature) { this.feature = feature; }

    public String getRelease() { return release; }
    public void setRelease(String release) { this.release = release; }

    public String getIteration() { return iteration; }
    public void setIteration(String iteration) { this.iteration = iteration; }

    public String getCreationDate() { return creationDate; }
    public void setCreationDate(String creationDate) { this.creationDate = creationDate; }

    public String getLastUpdateDate() { return lastUpdateDate; }
    public void setLastUpdateDate(String lastUpdateDate) { this.lastUpdateDate = lastUpdateDate; }

    public Boolean getBlocked() { return blocked; }
    public void setBlocked(Boolean blocked) { this.blocked = blocked; }

    public String getTags() { return tags; }
    public void setTags(String tags) { this.tags = tags; }

    public Map<String, Object> getRawFields() { return rawFields; }
    public void setRawFields(Map<String, Object> rawFields) { this.rawFields = rawFields; }
}
