package com.farmers.ffqai.rally.oauth;

import com.farmers.ffqai.config.RallyOAuthProperties;
import org.springframework.stereotype.Service;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class RallyOAuthService {
    private final RallyOAuthProperties properties;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;

    public RallyOAuthService(RallyOAuthProperties properties, ObjectMapper objectMapper) {
        this.properties = properties;
        this.objectMapper = objectMapper;
        this.httpClient = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .build();
    }

    public String newState() { return UUID.randomUUID().toString(); }

    public String createAuthorizationUrl(String state) {
        requireConfigured();
        return properties.getAuthorizationUrl()
                + "?state=" + enc(state)
                + "&response_type=code"
                + "&redirect_uri=" + enc(properties.getRedirectUri())
                + "&client_id=" + enc(properties.getClientId())
                + "&scope=" + enc(properties.getScope());
    }

    public TokenResponse exchangeAuthorizationCode(String code) {
        requireConfigured();
        try {
            Map<String,String> fields = new LinkedHashMap<>();
            fields.put("code", code);
            fields.put("redirect_uri", properties.getRedirectUri());
            fields.put("grant_type", "authorization_code");
            fields.put("client_id", properties.getClientId());
            fields.put("client_secret", properties.getClientSecret());

            StringBuilder body = new StringBuilder();
            for (Map.Entry<String,String> e : fields.entrySet()) {
                if (!body.isEmpty()) body.append('&');
                body.append(enc(e.getKey())).append('=').append(enc(e.getValue()));
            }

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(properties.getTokenUrl()))
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .header("Accept", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                    .build();

            HttpResponse<String> response =
                    httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IllegalStateException("Rally token endpoint returned HTTP "
                        + response.statusCode() + ".");
            }

            JsonNode json = objectMapper.readTree(response.body());
            String accessToken = json.path("access_token").asText("");
            if (accessToken.isBlank()) {
                throw new IllegalStateException("Rally token response did not contain access_token.");
            }

            Long expires = json.has("expires_in") && json.get("expires_in").canConvertToLong()
                    ? json.get("expires_in").asLong()
                    : null;

            return new TokenResponse(accessToken, expires);

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("OAuth token exchange interrupted.", e);
        } catch (Exception e) {
            if (e instanceof IllegalStateException ise) throw ise;
            throw new IllegalStateException("Unable to exchange Rally authorization code: " + e.getMessage(), e);
        }
    }

    private String enc(String v) {
        return URLEncoder.encode(v, StandardCharsets.UTF_8);
    }

    private void requireConfigured() {
        if (!properties.isConfigured()) {
            throw new IllegalStateException("Set RALLY_CLIENT_ID and RALLY_CLIENT_SECRET first.");
        }
    }

    public record TokenResponse(String accessToken, Long expiresInSeconds) {}
}
