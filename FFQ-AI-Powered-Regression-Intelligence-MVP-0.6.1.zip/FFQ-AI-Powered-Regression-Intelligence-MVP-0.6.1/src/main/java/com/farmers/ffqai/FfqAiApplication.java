package com.farmers.ffqai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class FFQ-AIApplication {

    public static void main(String[] args) {
        SpringApplication.run(FFQ-AIApplication.class, args);
    }
}
