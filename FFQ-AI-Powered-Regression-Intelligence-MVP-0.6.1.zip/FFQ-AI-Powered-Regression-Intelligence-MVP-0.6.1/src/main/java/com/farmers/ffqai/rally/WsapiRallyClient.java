package com.farmers.ffqai.rally;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.farmers.ffqai.config.RallyProperties;
import com.farmers.ffqai.model.UserStorySnapshot;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
public class WsapiRallyClient implements RallyClient {

    private static final String FETCH =
            "ObjectID,FormattedID,Name,Description,Notes,AcceptanceCriteria," +
            "Owner,Project,ScheduleState,FlowState,PlanEstimate,Parent,Feature," +
            "Release,Iteration,Milestones,CreationDate,LastUpdateDate,Blocked,Tags";

    private final RallyProperties properties;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;

    public WsapiRallyClient(RallyProperties properties, ObjectMapper objectMapper) {
        this.properties = properties;
        this.objectMapper = objectMapper;
        this.httpClient = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .build();
    }

    @Override
    public List<UserStorySnapshot> findUserStoriesBySprint(String project, String sprint) {
        requireCredentials();

        try {
            String query = "((Iteration.Name = \"" + escapeQuery(sprint) + "\") AND " +
                    "(Project.Name = \"" + escapeQuery(project) + "\"))";

            String url = properties.getBaseUrl()
                    + "/slm/webservice/v2.0/hierarchicalrequirement"
                    + "?query=" + encode(query)
                    + "&fetch=" + encode(FETCH)
                    + "&pagesize=" + properties.getPageSize()
                    + "&start=1";

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Accept", "application/json")
                    .header("zsessionid", properties.getApiKey())
                    .GET()
                    .build();

            HttpResponse<String> response =
                    httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IllegalStateException(
                        "Rally returned HTTP " + response.statusCode()
                                + ". Response: " + response.body());
            }

            return parseResults(response.body());

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Rally scan interrupted.", e);
        } catch (Exception e) {
            throw new IllegalStateException("Unable to scan Rally sprint: " + e.getMessage(), e);
        }
    }

    private List<UserStorySnapshot> parseResults(String body) throws Exception {
        JsonNode root = objectMapper.readTree(body);
        JsonNode queryResult = root.path("QueryResult");

        JsonNode errors = queryResult.path("Errors");
        if (errors.isArray() && !errors.isEmpty()) {
            throw new IllegalStateException("Rally WSAPI errors: " + errors);
        }

        List<UserStorySnapshot> stories = new ArrayList<>();
        for (JsonNode node : queryResult.path("Results")) {
            stories.add(toSnapshot(node));
        }
        return stories;
    }

    private UserStorySnapshot toSnapshot(JsonNode n) {
        UserStorySnapshot us = new UserStorySnapshot();

        us.setObjectId(text(n, "ObjectID"));
        us.setFormattedId(text(n, "FormattedID"));
        us.setName(text(n, "Name"));
        us.setDescription(text(n, "Description"));
        us.setNotes(text(n, "Notes"));
        us.setAcceptanceCriteria(text(n, "AcceptanceCriteria"));
        us.setOwner(refName(n.path("Owner")));
        us.setProject(refName(n.path("Project")));
        us.setScheduleState(text(n, "ScheduleState"));
        us.setFlowState(refName(n.path("FlowState")));

        if (n.hasNonNull("PlanEstimate") && n.get("PlanEstimate").isNumber()) {
            us.setPlanEstimate(n.get("PlanEstimate").asDouble());
        }

        us.setParent(refName(n.path("Parent")));
        us.setFeature(refName(n.path("Feature")));
        us.setRelease(refName(n.path("Release")));
        us.setIteration(refName(n.path("Iteration")));
        us.setCreationDate(text(n, "CreationDate"));
        us.setLastUpdateDate(text(n, "LastUpdateDate"));

        if (n.hasNonNull("Blocked")) {
            us.setBlocked(n.get("Blocked").asBoolean());
        }

        us.setTags(tags(n.path("Tags")));

        Map<String, Object> raw = objectMapper.convertValue(n, LinkedHashMap.class);
        us.setRawFields(raw);

        return us;
    }

    private String tags(JsonNode tagsNode) {
        if (tagsNode.isMissingNode() || tagsNode.isNull()) {
            return "";
        }
        JsonNode tags = tagsNode.path("_tagsNameArray");
        if (!tags.isArray()) {
            return "";
        }
        List<String> names = new ArrayList<>();
        for (JsonNode tag : tags) {
            String name = tag.path("Name").asText("");
            if (!name.isBlank()) {
                names.add(name);
            }
        }
        return String.join(", ", names);
    }

    private String refName(JsonNode ref) {
        if (ref == null || ref.isMissingNode() || ref.isNull()) {
            return "";
        }
        if (ref.isTextual()) {
            return ref.asText("");
        }
        String name = ref.path("_refObjectName").asText("");
        if (!name.isBlank()) {
            return name;
        }
        return ref.path("Name").asText("");
    }

    private String text(JsonNode node, String field) {
        return node.path(field).isNull() ? "" : node.path(field).asText("");
    }

    private void requireCredentials() {
        if (properties.getApiKey() == null || properties.getApiKey().isBlank()) {
            throw new IllegalStateException(
                    "RALLY_API_KEY is missing. Use a read-only Rally API key or run in mock mode.");
        }
    }

    private String encode(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8);
    }

    private String escapeQuery(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
