package com.farmers.ffqai.scanner;

import com.farmers.ffqai.FFQ-AIApplication;
import com.farmers.ffqai.model.SprintScanResult;
import com.farmers.ffqai.model.UserStorySnapshot;
import com.farmers.ffqai.service.SprintScannerService;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class SprintScannerLauncher {

    public static void main(String[] args) {
        printBanner();

        Map<String, String> arguments = parseArgs(args);

        try (Scanner input = new Scanner(System.in);
             ConfigurableApplicationContext context =
                     new SpringApplicationBuilder(FFQ-AIApplication.class)
                             .web(WebApplicationType.NONE)
                             .run()) {

            String project = valueOrAsk(arguments.get("project"), input, "Project", "SWAT");
            String sprint = valueOrAsk(arguments.get("sprint"), input, "Sprint", null);
            Boolean mock = arguments.containsKey("mock")
                    ? Boolean.parseBoolean(arguments.get("mock"))
                    : null;

            System.out.println();
            System.out.println("Project : " + project);
            System.out.println("Sprint  : " + sprint);
            System.out.println("Mode    : " + (Boolean.TRUE.equals(mock) ? "MOCK" :
                    Boolean.FALSE.equals(mock) ? "RALLY" : "CONFIG"));
            System.out.println();
            System.out.println("Starting scan...");

            SprintScannerService scanner =
                    context.getBean(SprintScannerService.class);

            SprintScanResult result = scanner.scan(project, sprint, mock);

            printResult(result);

        } catch (Exception e) {
            System.err.println();
            System.err.println("SCAN FAILED");
            System.err.println(e.getMessage());
            System.exit(1);
        }
    }

    private static void printResult(SprintScanResult result) {
        System.out.println();
        System.out.println("=======================================");
        System.out.println(" SCAN COMPLETE");
        System.out.println("=======================================");
        System.out.println("Project      : " + result.getProject());
        System.out.println("Sprint       : " + result.getSprint());
        System.out.println("Mode         : " + (result.isMock() ? "MOCK" : "RALLY"));
        System.out.println("User Stories : " + result.getUserStories().size());
        System.out.println();

        for (UserStorySnapshot story : result.getUserStories()) {
            System.out.println("---------------------------------------");
            System.out.println(story.getFormattedId() + " | " + story.getName());
            System.out.println("Owner       : " + story.getOwner());
            System.out.println("State       : " + story.getScheduleState());
            System.out.println("Flow State  : " + story.getFlowState());
            System.out.println("Iteration   : " + story.getIteration());
        }

        if (!result.getWarnings().isEmpty()) {
            System.out.println();
            System.out.println("Warnings:");
            result.getWarnings().forEach(w -> System.out.println("- " + w));
        }

        System.out.println();
        System.out.println("100% COMPLETE");
    }

    private static String valueOrAsk(
            String supplied, Scanner scanner, String label, String defaultValue) {

        if (supplied != null && !supplied.isBlank()) {
            return supplied;
        }

        while (true) {
            System.out.print(label);
            if (defaultValue != null) {
                System.out.print(" [" + defaultValue + "]");
            }
            System.out.print(": ");

            String value = scanner.nextLine().trim();
            if (!value.isBlank()) {
                return value;
            }
            if (defaultValue != null) {
                return defaultValue;
            }
        }
    }

    private static Map<String, String> parseArgs(String[] args) {
        Map<String, String> parsed = new HashMap<>();
        for (String arg : args) {
            if (arg.startsWith("--") && arg.contains("=")) {
                String[] parts = arg.substring(2).split("=", 2);
                parsed.put(parts[0].trim().toLowerCase(), parts[1].trim());
            }
        }
        return parsed;
    }

    private static void printBanner() {
        System.out.println("=======================================");
        System.out.println(" FFQ-AI - RALLY SCANNER");
        System.out.println(" MVP 0.1 - READ ONLY");
        System.out.println("=======================================");
    }
}
