package com.farmers.ffqai.web;

import com.farmers.ffqai.config.RallyProperties;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    private final RallyProperties properties;

    public DashboardController(RallyProperties properties) {
        this.properties = properties;
    }

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("defaultProject", properties.getProject());
        model.addAttribute("mockMode", properties.isMockMode());
        return "index";
    }

    @GetMapping("/rally-analysis")
    public String rallyAnalysis() { return "rally-analysis"; }

    @GetMapping("/test-case-editor")
    public String testCaseEditor() { return "test-case-editor"; }

    @GetMapping("/rally-publish")
    public String rallyPublish() { return "rally-publish"; }

    @GetMapping("/automation-workspace")
    public String automationWorkspace() { return "automation-workspace"; }

    @GetMapping("/copilot-generation")
    public String copilotGeneration() { return "copilot-generation"; }

    @GetMapping("/execution-traceability")
    public String executionTraceability() { return "execution-traceability"; }
}
