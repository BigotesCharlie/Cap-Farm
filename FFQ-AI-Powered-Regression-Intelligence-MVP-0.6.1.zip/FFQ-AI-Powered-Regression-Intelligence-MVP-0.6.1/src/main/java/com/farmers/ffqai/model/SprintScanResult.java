package com.farmers.ffqai.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class SprintScanResult {

    private String project;
    private String sprint;
    private Instant scannedAt = Instant.now();
    private boolean mock;
    private List<UserStorySnapshot> userStories = new ArrayList<>();
    private List<String> warnings = new ArrayList<>();

    public String getProject() { return project; }
    public void setProject(String project) { this.project = project; }

    public String getSprint() { return sprint; }
    public void setSprint(String sprint) { this.sprint = sprint; }

    public Instant getScannedAt() { return scannedAt; }
    public void setScannedAt(Instant scannedAt) { this.scannedAt = scannedAt; }

    public boolean isMock() { return mock; }
    public void setMock(boolean mock) { this.mock = mock; }

    public List<UserStorySnapshot> getUserStories() { return userStories; }
    public void setUserStories(List<UserStorySnapshot> userStories) { this.userStories = userStories; }

    public List<String> getWarnings() { return warnings; }
    public void setWarnings(List<String> warnings) { this.warnings = warnings; }
}
