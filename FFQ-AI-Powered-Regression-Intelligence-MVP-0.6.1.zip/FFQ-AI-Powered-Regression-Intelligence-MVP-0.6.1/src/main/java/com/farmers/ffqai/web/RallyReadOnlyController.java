package com.farmers.ffqai.web;

import com.farmers.ffqai.rally.oauth.RallyOAuthWsapiService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tools.jackson.databind.JsonNode;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/rally")
public class RallyReadOnlyController {

    private final RallyOAuthWsapiService wsapiService;

    public RallyReadOnlyController(
            RallyOAuthWsapiService wsapiService) {
        this.wsapiService = wsapiService;
    }

    @GetMapping("/projects")
    public ResponseEntity<JsonNode> projects(HttpSession session) {
        return ResponseEntity.ok(wsapiService.getProjects(session));
    }

    @GetMapping("/iterations")
    public ResponseEntity<JsonNode> iterations(
            @RequestParam String project,
            HttpSession session) {

        return ResponseEntity.ok(
                wsapiService.getIterations(session, project));
    }

    @GetMapping("/milestones")
    public ResponseEntity<List<String>> milestones(
            @RequestParam String project,
            @RequestParam String iteration,
            HttpSession session) {
        return ResponseEntity.ok(
                wsapiService.getMilestones(session, project, iteration));
    }

    @GetMapping("/features")
    public ResponseEntity<List<Map<String, Object>>> features(
            @RequestParam String project,
            @RequestParam String iteration,
            @RequestParam(required = false) String milestone,
            HttpSession session) {

        return ResponseEntity.ok(
                wsapiService.getFeaturesForIteration(
                        session,
                        project,
                        iteration,
                        milestone));
    }

    @GetMapping("/user-stories")
    public ResponseEntity<JsonNode> userStories(
            @RequestParam String project,
            @RequestParam String iteration,
            @RequestParam(required = false) Long featureObjectId,
            @RequestParam(required = false) String milestone,
            HttpSession session) {

        return ResponseEntity.ok(
                wsapiService.getUserStories(
                        session,
                        project,
                        iteration,
                        featureObjectId,
                        milestone));
    }

    @GetMapping("/user-story/{formattedId}")
    public ResponseEntity<JsonNode> userStory(
            @PathVariable String formattedId,
            HttpSession session) {

        return ResponseEntity.ok(
                wsapiService.getUserStory(session, formattedId));
    }
}
