package com.farmers.ffqai.rally;

import com.farmers.ffqai.model.UserStorySnapshot;

import java.util.List;

public interface RallyClient {
    List<UserStorySnapshot> findUserStoriesBySprint(String project, String sprint);
}
