package com.farmers.ffqai.playwright;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.AriaRole;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

/**
 * Playwright foundation for FFQ-AI UI testing.
 *
 * Enable after the Spring Boot application is running locally.
 */
class FFQ-AIPlaywrightSmokeTest {

    @Test
    @Disabled("Enable after FFQ-AI is running at http://localhost:8080")
    void dashboardLoads() {
        try (Playwright playwright = Playwright.create()) {
            Browser browser = playwright.chromium().launch(
                    new BrowserType.LaunchOptions().setHeadless(false));

            Page page = browser.newPage();
            page.navigate("http://localhost:8080");

            assertThat(page.getByRole(
                    AriaRole.HEADING,
                    new Page.GetByRoleOptions().setName("FFQ-AI")))
                    .isVisible();

            browser.close();
        }
    }
}
