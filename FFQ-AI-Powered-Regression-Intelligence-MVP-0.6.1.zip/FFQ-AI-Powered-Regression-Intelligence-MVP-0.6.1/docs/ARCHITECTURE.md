# FFQ-AI Architecture — MVP 0.1

```text
Rally WSAPI
    |
    v
WsapiRallyClient
    |
    v
SprintScannerService
    |
    +----> JSON Snapshot Repository
    |
    +----> Spring MVC Dashboard
    |
    +----> REST API
```

Future:

```text
Rally
  |
  v
Scanner
  |
  v
Change Detector
  |
  v
Requirement Analyzer
  |
  +--------------------+
  |                    |
  v                    v
Task Generator     Test Case Generator
  |                    |
  +---------+----------+
            |
            v
       Review/Edit UI
            |
            v
      Human Approval
            |
            v
      Rally Publisher
```

## Design principles

1. Rally is the source of truth.
2. Scanner is read-only.
3. Generated QA artifacts are editable in FFQ-AI.
4. Nothing is written to Rally without explicit approval.
5. API keys stay outside source control.
6. Playwright is for application/UI validation, not the primary Rally data transport.
7. Rally WSAPI is the primary integration layer.
8. All scans are versionable snapshots.
