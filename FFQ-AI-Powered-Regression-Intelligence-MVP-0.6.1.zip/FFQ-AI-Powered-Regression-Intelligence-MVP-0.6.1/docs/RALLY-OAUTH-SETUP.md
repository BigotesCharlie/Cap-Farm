# Rally OAuth Setup — FFQ-AI MVP 0.5

Registered OAuth Client:
- Name: FFQ-AI
- Callback: `http://localhost:8080/oauth/rally/callback`

Runtime:
```powershell
$env:RALLY_CLIENT_ID="..."
$env:RALLY_CLIENT_SECRET="..."
$env:RALLY_REDIRECT_URI="http://localhost:8080/oauth/rally/callback"
mvn spring-boot:run
```

Flow:
FFQ-AI → Rally OAuth → Okta/Rally SSO → callback → authorization-code exchange → access token → server-side HTTP session → WSAPI GET.

Security:
- Client Secret stays server-side.
- Access token stays server-side.
- OAuth `state` is validated.
- MVP 0.5 is read-only.
- Rally publish operations remain disabled.
