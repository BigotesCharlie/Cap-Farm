# ffq-HomeHappyPath-e2e

Clean Playwright Java happy-path project built from the supplied `HomeDOM` HTML captures and screenshots.

## Scope

One deterministic E2E scenario only:

`HomeHappyPathE2ETest.homeDomHappyPathE2E`

The flow is state-driven rather than a generic `advance()` loop:

1. Property Type (when the application presents it)
2. What's the address?
3. Your home quality grade
4. Here's what we have so far
5. Additional home information
6. About you
7. Last step before your quote
8. Review your dwelling coverage
9. Home coverages
10. Thank you for choosing Farmers Insurance

The reference HTML and screenshots supplied by the user are retained under `reference/HomeDOM/`.

## Scenario values

- Address: `2331 Aperture Cir, San Diego, CA 92108`
- Less than one year: `No`
- Primary residence: `Yes`
- Claims in last 3 years: `None`
- Applicant: `Kuman Vontach`
- DOB: `06/09/1973`
- Gender: `Male`
- Occupation: `Engineer`
- Property summary: 2015, 1,585 sq ft, 2 stories, 3 bathrooms, zero-clearance fireplace, Carpet/Hardwood/Stone & tile, Attached/Built-in 2-car garage, Traditional hard coat, Concrete slab, Architectural shingle, Single family attached end unit
- Quality grade: `Above Average` (as shown in the supplied flow)
- Roof replaced last 10 years: `No`
- Pool: `Yes`, fenced
- Solar panels: `Yes`
- Trampoline: `No`
- Fire alarm: `Yes`, professionally monitored
- Dwelling coverage: `$518,000`
- Policy start: `08/15/2026`
- Email: `kumal_vontach@farminsqa.testinator.com`
- Phone: `(828) 523-4748`

## Environment

The default start URL comes directly from the supplied screenshot:

`https://ffqautouiuat.farmers.com/quote/home/personal-info`

Override it without changing code:

```powershell
.\gradlew.bat homeHappyPathE2E -DbaseUrl="<HOME URL>" -Dheaded=true
```

## First run

```powershell
.\gradlew.bat playwrightInstall
.\gradlew.bat testClasses
.\gradlew.bat homeHappyPathE2E -Dheaded=true
```

## Copy-DOM artifacts

Each run writes state evidence to:

`artifacts/dom/HomeDOM-HappyPath/<execution-id>/`

On a failure it always writes:

- `failure-current-page.html`
- `failure-current-page.png`
- `failure-current-page-url.txt`
- `failure-current-page-headings.txt`

Use those files for the next manual locator/debugging change.

## Anti-flakiness

`KNOCKOUT` and `INCONVENIENCE` are detected independently of normal page states.

Recovery order:

1. Click a DOM-proven `Try Again` control when present.
2. Restart the same application flow with the same scenario data.

Maximum recovery attempts: 2.

## Design rule

No Selenium, no WebDriver, no WebElement, no `Thread.sleep()`, no DataProvider, and no random/fabricated scenario data are used in this project.
