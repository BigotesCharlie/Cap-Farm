package com.farmers.ffq.homehappypath.pages;

import com.farmers.ffq.homehappypath.config.HomeScenarioData;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public final class AboutYouPage extends BaseHomePage {
    public AboutYouPage(Page page) { super(page); }

    public void complete(HomeScenarioData data) {
        page.getByLabel("First name").fill(data.firstName());
        page.getByLabel("Last name").fill(data.lastName());
        page.getByLabel("Date of birth in the format of mmddyyyy.").fill(data.dob().replace("/", ""));
        page.getByRole(AriaRole.RADIO, new Page.GetByRoleOptions().setName(data.gender()).setExact(true)).click();

        Locator occupationButton = page.locator("#primaryOccupation");
        if (occupationButton.count() > 0) {
            occupationButton.click();
            page.getByText("Employed", new Page.GetByTextOptions().setExact(true)).first().click();
            Locator engineer = page.getByRole(AriaRole.RADIO,
                    new Page.GetByRoleOptions().setName(data.occupation()).setExact(true));
            if (engineer.count() > 0) {
                engineer.click();
            } else {
                page.getByText(data.occupation(), new Page.GetByTextOptions().setExact(true)).first().click();
            }
            // Drawer normally closes after selection; Escape is a harmless fallback if it remains open.
            page.keyboard().press("Escape");
        }
        continueButton();
    }
}
