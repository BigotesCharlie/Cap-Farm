package com.farmers.ffq.homehappypath.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public abstract class BaseHomePage {
    protected final Page page;

    protected BaseHomePage(Page page) {
        this.page = page;
    }

    protected Locator button(String name) {
        return page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName(name).setExact(true));
    }

    protected Locator radio(String name) {
        return page.getByRole(AriaRole.RADIO, new Page.GetByRoleOptions().setName(name).setExact(true));
    }

    protected void clickButton(String name) {
        button(name).first().click();
    }

    protected void clickText(String text) {
        page.getByText(text, new Page.GetByTextOptions().setExact(true)).first().click();
    }

    protected void clickRadioIn(String containerCss, String option) {
        page.locator(containerCss)
                .getByRole(AriaRole.RADIO, new Locator.GetByRoleOptions().setName(option).setExact(true))
                .click();
    }

    protected void continueButton() {
        Locator c = button("Continue");
        if (c.count() > 0) {
            c.last().click();
            return;
        }
        throw new IllegalStateException("Continue button not found on " + page.url());
    }

    protected void waitForBodyReady() {
        page.locator("body").waitFor();
    }
}
