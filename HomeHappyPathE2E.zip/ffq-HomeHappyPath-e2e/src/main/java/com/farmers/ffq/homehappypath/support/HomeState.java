package com.farmers.ffq.homehappypath.support;

public enum HomeState {
    PROPERTY_TYPE,
    ADDRESS,
    QUALITY_GRADE,
    PROPERTY_SUMMARY,
    ADDITIONAL_INFO,
    ABOUT_YOU,
    CONTACT_INFO,
    DWELLING_COVERAGE,
    HOME_COVERAGES,
    THANK_YOU,
    KNOCKOUT,
    INCONVENIENCE,
    UNKNOWN
}
