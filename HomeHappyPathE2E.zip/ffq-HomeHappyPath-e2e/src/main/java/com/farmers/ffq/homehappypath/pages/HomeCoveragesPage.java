package com.farmers.ffq.homehappypath.pages;

import com.farmers.ffq.homehappypath.config.HomeScenarioData;
import com.microsoft.playwright.Page;

public final class HomeCoveragesPage extends BaseHomePage {
    public HomeCoveragesPage(Page page) { super(page); }

    public void verifyAndContinue(HomeScenarioData data) {
        String body = page.locator("body").innerText();
        if (!body.contains("Home coverages")) throw new AssertionError("Home coverages page not displayed");
        if (!body.contains(data.dwellingCoverage())) {
            throw new AssertionError("Home coverages does not show expected dwelling coverage");
        }
        if (!body.contains("Quote number")) throw new AssertionError("Quote number section not visible");
        continueButton();
    }
}
