package com.farmers.ffq.homehappypath.support;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public final class RecoveryManager {
    private static final int MAX_RECOVERY = 2;
    private final Page page;
    private final HomeStateDetector detector;
    private final DomArtifacts artifacts;
    private final String startUrl;
    private int recoveries;

    public RecoveryManager(Page page, HomeStateDetector detector, DomArtifacts artifacts, String startUrl) {
        this.page = page;
        this.detector = detector;
        this.artifacts = artifacts;
        this.startUrl = startUrl;
    }

    public boolean recoverIfNeeded() {
        HomeState state = detector.detect();
        if (state != HomeState.KNOCKOUT && state != HomeState.INCONVENIENCE) return false;
        if (recoveries >= MAX_RECOVERY) {
            throw new IllegalStateException("Exceeded MAX_RECOVERY=" + MAX_RECOVERY + " on " + state);
        }
        recoveries++;
        artifacts.capture("recovery-" + recoveries + "-" + state);

        Locator tryAgain = page.getByRole(AriaRole.BUTTON,
                new Page.GetByRoleOptions().setName("Try Again").setExact(true));
        if (tryAgain.count() == 0) {
            tryAgain = page.getByText("Try Again", new Page.GetByTextOptions().setExact(true));
        }
        if (tryAgain.count() > 0 && tryAgain.first().isVisible()) {
            System.out.printf("[RECOVERY] %s -> Try Again (attempt %d/%d)%n", state, recoveries, MAX_RECOVERY);
            tryAgain.first().click();
            page.waitForTimeout(500);
            return true;
        }

        System.out.printf("[RECOVERY] %s -> deterministic application restart (attempt %d/%d)%n",
                state, recoveries, MAX_RECOVERY);
        page.navigate(startUrl);
        return true;
    }
}
