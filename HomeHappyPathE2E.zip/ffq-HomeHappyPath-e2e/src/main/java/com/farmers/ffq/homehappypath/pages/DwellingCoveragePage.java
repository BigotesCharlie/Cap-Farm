package com.farmers.ffq.homehappypath.pages;

import com.farmers.ffq.homehappypath.config.HomeScenarioData;
import com.microsoft.playwright.Page;

public final class DwellingCoveragePage extends BaseHomePage {
    public DwellingCoveragePage(Page page) { super(page); }

    public void verifyAndContinue(HomeScenarioData data) {
        String body = page.locator("body").innerText();
        if (!body.contains(data.dwellingCoverage())) {
            throw new AssertionError("Expected dwelling coverage " + data.dwellingCoverage() + " was not shown");
        }
        continueButton();
    }
}
