package com.farmers.ffq.homehappypath.flow;

import com.farmers.ffq.homehappypath.config.HomeScenarioData;
import com.farmers.ffq.homehappypath.pages.*;
import com.farmers.ffq.homehappypath.support.*;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.LoadState;

import java.util.EnumSet;

public final class HomeHappyPathFlow {
    private static final int MAX_TRANSITIONS = 24;

    private final Page page;
    private final HomeScenarioData data;
    private final HomeStateDetector detector;
    private final DomArtifacts artifacts;
    private final RecoveryManager recovery;
    private final EnumSet<HomeState> visited = EnumSet.noneOf(HomeState.class);

    public HomeHappyPathFlow(Page page, HomeScenarioData data, String startUrl) {
        this.page = page;
        this.data = data;
        this.detector = new HomeStateDetector(page);
        this.artifacts = new DomArtifacts(page, "HomeDOM-HappyPath");
        this.recovery = new RecoveryManager(page, detector, artifacts, startUrl);
    }

    public void run(String startUrl) {
        System.out.println("[HOME HAPPY PATH] Starting: " + startUrl);
        page.navigate(startUrl);
        page.waitForLoadState(LoadState.DOMCONTENTLOADED);

        for (int transition = 1; transition <= MAX_TRANSITIONS; transition++) {
            if (recovery.recoverIfNeeded()) {
                continue;
            }

            HomeState state = detector.detect();
            System.out.printf("[HOME HAPPY PATH] Transition %02d | state=%s | url=%s%n", transition, state, page.url());
            artifacts.capture(state.name());
            visited.add(state);

            try {
                switch (state) {
                    case PROPERTY_TYPE -> new PropertyTypePage(page).chooseHome();
                    case ADDRESS -> new AddressPage(page).complete(data);
                    case QUALITY_GRADE -> new QualityGradePage(page).reviewAndContinue(data);
                    case PROPERTY_SUMMARY -> new PropertySummaryPage(page).verifyAndContinue(data);
                    case ADDITIONAL_INFO -> new AdditionalInfoPage(page).complete();
                    case ABOUT_YOU -> new AboutYouPage(page).complete(data);
                    case CONTACT_INFO -> new ContactInfoPage(page).complete(data);
                    case DWELLING_COVERAGE -> new DwellingCoveragePage(page).verifyAndContinue(data);
                    case HOME_COVERAGES -> new HomeCoveragesPage(page).verifyAndContinue(data);
                    case THANK_YOU -> {
                        new ThankYouPage(page).verifyComplete();
                        artifacts.capture("PASS-THANK-YOU");
                        System.out.println("[HOME HAPPY PATH] PASS - Thank You page reached.");
                        return;
                    }
                    case KNOCKOUT, INCONVENIENCE -> {
                        // Recovery is evaluated at the top of the loop.
                    }
                    case UNKNOWN -> throw new IllegalStateException(
                            "Unknown HOME state at " + page.url() + ". Inspect failure-current-page.html");
                }

                // Give the SPA a short Playwright-side transition window, then let the detector drive the next action.
                page.waitForTimeout(500);
            } catch (RuntimeException | AssertionError failure) {
                artifacts.captureFailure();
                throw failure;
            }
        }

        artifacts.captureFailure();
        throw new IllegalStateException("Exceeded " + MAX_TRANSITIONS + " state transitions. Visited=" + visited);
    }
}
