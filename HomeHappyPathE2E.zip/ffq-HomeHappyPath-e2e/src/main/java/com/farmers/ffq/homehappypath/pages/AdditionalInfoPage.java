package com.farmers.ffq.homehappypath.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public final class AdditionalInfoPage extends BaseHomePage {
    public AdditionalInfoPage(Page page) { super(page); }

    public void complete() {
        // DOM-proven selections from AdditionalInfo1/2 screenshots.
        clickRoofReplacedNo();
        ensureCheckbox("It has a swimming pool.", true);
        page.getByLabel("The pool is fenced").check();
        ensureCheckbox("It has solar panels.", true);
        ensureCheckbox("It has a trampoline.", false);
        ensureCheckbox("Fire alarm", true);
        chooseProfessionalMonitoring();
        ensureCheckbox("Burglar alarm", false);
        ensureCheckbox("Water leak protection", false);
        ensureCheckbox("FORTIFIED Home certification", false);
        continueButton();
    }

    private void clickRoofReplacedNo() {
        Locator section = page.locator("text=The roof has been fully replaced in the last 10 years.").locator("..");
        Locator no = section.getByRole(AriaRole.BUTTON, new Locator.GetByRoleOptions().setName("No").setExact(true));
        if (no.count() == 0) {
            no = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("No").setExact(true)).first();
        }
        no.click();
    }

    private void ensureCheckbox(String label, boolean expectedChecked) {
        Locator cb = page.getByLabel(label, new Page.GetByLabelOptions().setExact(true));
        if (cb.count() == 0) return;
        if (expectedChecked && !cb.isChecked()) cb.check();
        if (!expectedChecked && cb.isChecked()) cb.uncheck();
    }

    private void chooseProfessionalMonitoring() {
        Locator option = page.getByRole(AriaRole.RADIO,
                new Page.GetByRoleOptions().setName("Professionally monitored").setExact(true));
        if (option.count() == 0) {
            option = page.getByText("Professionally monitored", new Page.GetByTextOptions().setExact(true));
        }
        option.first().click();
    }
}
