package com.farmers.ffq.homehappypath.pages;

import com.microsoft.playwright.Page;

public final class ThankYouPage extends BaseHomePage {
    public ThankYouPage(Page page) { super(page); }

    public void verifyComplete() {
        String body = page.locator("body").innerText();
        if (!body.contains("Thank you for choosing Farmers Insurance")) {
            throw new AssertionError("Final Farmers thank-you page not reached");
        }
    }
}
