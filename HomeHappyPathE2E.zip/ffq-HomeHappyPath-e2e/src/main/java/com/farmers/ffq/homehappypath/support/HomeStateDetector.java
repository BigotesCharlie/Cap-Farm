package com.farmers.ffq.homehappypath.support;

import com.microsoft.playwright.Page;

public final class HomeStateDetector {
    private final Page page;

    public HomeStateDetector(Page page) {
        this.page = page;
    }

    public HomeState detect() {
        String body = safeBody().toLowerCase();
        String url = page.url().toLowerCase();

        if (contains(body, "thank you for choosing farmers insurance")) return HomeState.THANK_YOU;
        if (contains(body, "what type of property is it?")) return HomeState.PROPERTY_TYPE;
        if (contains(body, "what’s the address?") || contains(body, "what's the address?")) return HomeState.ADDRESS;
        if (contains(body, "your home quality grade")) return HomeState.QUALITY_GRADE;
        if (contains(body, "here’s what we have so far") || contains(body, "here's what we have so far")) return HomeState.PROPERTY_SUMMARY;
        if (contains(body, "additional home information")) return HomeState.ADDITIONAL_INFO;
        if (contains(body, "about you")) return HomeState.ABOUT_YOU;
        if (contains(body, "last step before your quote")) return HomeState.CONTACT_INFO;
        if (contains(body, "review your dwelling coverage")) return HomeState.DWELLING_COVERAGE;
        if (contains(body, "home coverages")) return HomeState.HOME_COVERAGES;
        if (url.contains("inconvenience") || contains(body, "inconvenience")) return HomeState.INCONVENIENCE;
        if (url.contains("knockout") || contains(body, "knockout") || contains(body, "unable to continue")) return HomeState.KNOCKOUT;
        return HomeState.UNKNOWN;
    }

    private String safeBody() {
        try {
            return page.locator("body").innerText();
        } catch (RuntimeException ex) {
            return "";
        }
    }

    private boolean contains(String value, String expected) {
        return value.contains(expected.toLowerCase());
    }
}
