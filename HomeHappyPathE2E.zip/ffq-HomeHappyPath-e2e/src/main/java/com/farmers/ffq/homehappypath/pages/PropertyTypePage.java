package com.farmers.ffq.homehappypath.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public final class PropertyTypePage extends BaseHomePage {
    public PropertyTypePage(Page page) { super(page); }

    public void chooseHome() {
        Locator homeCard = page.locator("[data-test-id='IMAGE_CARD']")
                .filter(new Locator.FilterOptions().setHas(page.locator("img[alt='Home']")));
        if (homeCard.count() == 0) {
            homeCard = page.locator("[data-test-id='IMAGE_CARD']")
                    .filter(new Locator.FilterOptions().setHasText("Home"));
        }
        homeCard.first().click();
    }
}
