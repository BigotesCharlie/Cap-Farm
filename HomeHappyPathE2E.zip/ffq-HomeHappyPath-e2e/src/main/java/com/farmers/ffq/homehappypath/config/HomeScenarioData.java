package com.farmers.ffq.homehappypath.config;

public record HomeScenarioData(
        String street,
        String city,
        String zip,
        String firstName,
        String lastName,
        String dob,
        String gender,
        String occupation,
        String policyStartDate,
        String email,
        String phone,
        String dwellingCoverage
) {
    public static HomeScenarioData domHappyPath() {
        return new HomeScenarioData(
                "2331 Aperture Cir",
                "San Diego",
                "92108",
                "Kuman",
                "Vontach",
                "06/09/1973",
                "Male",
                "Engineer",
                "08/15/2026",
                "kumal_vontach@farminsqa.testinator.com",
                "(828) 523-4748",
                "$518,000"
        );
    }

    public String mailingAddress() {
        return "2331 APERTURE CIR, SAN DIEGO, CA 92108";
    }
}
