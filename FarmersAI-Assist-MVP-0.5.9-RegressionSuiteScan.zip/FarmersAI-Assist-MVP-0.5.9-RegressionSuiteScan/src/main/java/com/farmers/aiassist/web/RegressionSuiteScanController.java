package com.farmers.aiassist.web;

import com.farmers.aiassist.regression.RegressionSuiteScanService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/regression-scan")
public class RegressionSuiteScanController {
    private final RegressionSuiteScanService service;
    public RegressionSuiteScanController(RegressionSuiteScanService service) { this.service = service; }

    @PostMapping
    public ResponseEntity<?> scan(@RequestBody RegressionSuiteScanService.ScanRequest request) {
        try {
            return ResponseEntity.ok(service.scan(request));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(java.util.Map.of("error", e.getMessage()));
        } catch (IllegalStateException e) {
            return ResponseEntity.internalServerError().body(java.util.Map.of("error", e.getMessage()));
        }
    }
}
