"""v2.6 API regression; no Copilot, browsers or Farmers calls."""
import os, tempfile, subprocess, pathlib, json, time, urllib.request, urllib.parse, shutil
root=pathlib.Path(tempfile.mkdtemp(prefix='igero_v26_api_'))
base=pathlib.Path(__file__).resolve().parents[1]
java=root/'java'; ts=root/'pw'; launcher=root/'launcher'
f=java/'src/test/java/com/farmers/ffq/acehome/AceHomeStatusTest.java'; f.parent.mkdir(parents=True)
f.write_text('''public class AceHomeStatusTest {
 @Test(enabled=false, groups={"Home"})
 public void testDisabledOne() { }
 @Test(groups={"Home"})
 public void testEnabledOne() { }
 @Ignore
 @Test
 public void testIgnoredOne() { }
}''')
(ts/'node_modules/.bin').mkdir(parents=True);(ts/'node_modules/@playwright/test').mkdir(parents=True)
(ts/'node_modules/@playwright/test/package.json').write_text('{}'); (ts/'node_modules/.bin/playwright').touch()
launcher.mkdir()
mockbin=root/'bin';mockbin.mkdir()
(mockbin/'npm').write_text('#!/bin/sh\necho mocked-typescript-ok\nexit 0\n')
(mockbin/'npm').chmod(0o755)
env=os.environ.copy();env['PATH']=str(mockbin)+os.pathsep+env['PATH']
for name in ('server.mjs','index.html','app.js','lob-catalog.mjs','focused-test-resolver.mjs','playwright-launcher.mjs','registry-isolation.mjs'):
 shutil.copy2(base/name,launcher/name)
env['IGERO_PANEL_PORT']='18893'
proc=subprocess.Popen(['node','server.mjs'],cwd=launcher,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
def api(url,data=None):
 r=urllib.request.Request('http://127.0.0.1:18893'+url,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(r,timeout=12) as response:return json.load(response)
try:
 for i in range(60):
  try:api('/api/job');break
  except Exception:time.sleep(.1)
 api('/api/config',{'javaRoot':str(java),'playwrightRoot':str(ts),'testEnv':'MA11','autoTypecheck':True,'autoFunctionalCheck':True})
 catalog=api('/api/lob-catalog?refresh=1')
 home=next(x for x in catalog['lobs'] if x['id']=='home')
 skipped=next(x for x in home['suites'] if x['label']=='SKIPPED SCENARIOS')
 normal=next(x for x in home['suites'] if x['label']=='AceHomeStatusTest')
 special=api('/api/methods?'+urllib.parse.urlencode({'lob':'home','suite':skipped['id']}))
 active=api('/api/methods?'+urllib.parse.urlencode({'lob':'home','suite':normal['id']}))
 assert {m['id'] for m in special['methods']}=={'AceHomeStatusTest#testDisabledOne','AceHomeStatusTest#testIgnoredOne'},special
 assert len(active['methods'])==1 and active['methods'][0]['id']=='AceHomeStatusTest#testEnabledOne',active
 assert all(m['skipped'] and m['suite']==skipped['id'] for m in special['methods'])
 assert not active['methods'][0]['skipped']
 print('PASS: Java disabled methods isolated in exclusive virtual SKIPPED SCENARIOS suite')
 mid='AceHomeStatusTest#testDisabledOne'
 preview=api('/api/method-preview?id='+urllib.parse.quote(mid))
 assert preview['skipped'] and preview['skipReason']=='@Test(enabled=false)'
 print('PASS: source skip reason visible on selection')
 # Functional-only request would require system readiness, so verify the skip classification
 # cannot be affected by the TS mapping; no runnable spec is necessary in this fixture.
 # The disabled source must never launch Chrome, even on an explicit functional click.
 artifacts=ts/'migration/pervez-json/AceHomeStatusTest__testDisabledOne'
 artifacts.mkdir(parents=True)
 (artifacts/'contract.json').write_text(json.dumps({'className':'AceHomeStatusTest','methodName':'testDisabledOne','assertions':[],'steps':[]}))
 (artifacts/'prompt.md').write_text('Preserve the source disabled test. Never claim a functional pass.')
 start=api('/api/start',{'methodId':mid,'mode':'functional','lob':'home','suite':skipped['id']})
 assert start['started']
 for _ in range(150):
  state=api('/api/job')
  if state and state['status']!='running':break
  time.sleep(.1)
 assert state['status']=='partial',state
 assert state['functional']['verdict']=='SOURCE_TEST_SKIPPED',state
 assert state['functional']['counts']['total']==0,state
 assert state['steps'][5]['status']=='skipped',state['steps']
 print('PASS: source-disabled Java TC is classified SKIPPED and no browser launches')
 assert (launcher/'config.local.json').exists()
 print('PASS: local config stored in launcher copy, original repository untouched')
finally:
 proc.terminate()
 try:proc.wait(timeout=4)
 except Exception:proc.kill()
 shutil.rmtree(root,ignore_errors=True)
